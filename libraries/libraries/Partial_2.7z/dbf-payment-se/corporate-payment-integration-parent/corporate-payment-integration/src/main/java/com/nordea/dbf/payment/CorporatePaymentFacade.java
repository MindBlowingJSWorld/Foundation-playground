package com.nordea.dbf.payment;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.filter.Filters;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.InternalServerErrorException;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.messaging.Observables;
import com.nordea.dbf.payment.common.PaymentFacade;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.integration.CorporatePaymentIntegration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.unWrapId;
import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.wrapId;

public class CorporatePaymentFacade implements PaymentFacade {
    private static final Logger LOGGER = LoggerFactory.getLogger(CorporatePaymentFacade.class);

    @Autowired
    private M8ImsConnector m8ImsConnector;

    @Autowired
    private CorporatePaymentIntegration corporateCorporatePaymentIntegration;

    @Override
    public Observable<Payment> createPayment(ServiceData serviceData, Payment payment) {
        return createPaymentBasedOnType(serviceData, payment)
                // Create only returns the ID, lookup the newly created payment directly
                .flatMap(createdPayment -> getPayment(serviceData, payment.setId(createdPayment.getId())));
    }

    private Observable<Payment> createPaymentBasedOnType(ServiceData serviceData, Payment payment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        switch (payment.getType()) {
            case bankgiro:
            case plusgiro:
            case lban:
            case salary:
            case pension:
                return Observables.manage(connection).on(corporateCorporatePaymentIntegration.createCorporateDomesticPayment(connection, serviceData, payment));
            case crossborder:
                return Observables.manage(connection).on(corporateCorporatePaymentIntegration.createCorporateCrossBorderPayment(connection,serviceData, payment));
            default:
                throw new IllegalArgumentException("Invalid payment type " + payment.getType());
        }
    }

    @Override
    public Observable<Payment> changePayment(ServiceData serviceData, Payment payment, Payment originalPayment) {
        return changePaymentBasedOnType(serviceData, payment, originalPayment)
                // Change only returns the ID, lookup the changed payment directly
                .flatMap(changePayment -> getPayment(serviceData, payment.setId(changePayment.getId())));
    }

    private Observable<Payment> changePaymentBasedOnType(ServiceData serviceData, Payment payment, Payment originalPayment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        switch (payment.getType()) {
            case plusgiro:
            case bankgiro:
            case lban:
            case salary:
            case pension:
                return Observables.manage(connection).on(corporateCorporatePaymentIntegration.changeCorporateDomesticPayment(connection, serviceData, payment));
            case crossborder:
                return Observables.manage(connection).on(corporateCorporatePaymentIntegration.changeCorporateCrossBorderPayment(connection, serviceData, payment));
            default:
                throw new IllegalArgumentException("Invalid payment type " + payment.getType());
        }
    }

    @Override
    public Observable<Payment> deletePayment(ServiceData serviceData, Payment payment) {
        if (Stream.of(Payment.TypeEnum.plusgiro, Payment.TypeEnum.bankgiro, Payment.TypeEnum.lban, Payment.TypeEnum.crossborder, Payment.TypeEnum.salary, Payment.TypeEnum.pension)
            .noneMatch(validType -> validType == payment.getType())) {
            throw new IllegalArgumentException("Invalid payment type " + payment.getType());
        }
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(this.corporateCorporatePaymentIntegration.deleteCorporatePayment(connection, serviceData, payment)
                // Just return the original payment
                .map(dummy -> payment));
    }

    @Override
    public Observable<Payment> completePayment(ServiceData serviceData, Payment payment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(corporateCorporatePaymentIntegration.confirmCorporatePayment(connection, serviceData, payment).flatMap(confirmedPayment -> {
            payment.setId(confirmedPayment.getId());
            return getPayment(serviceData, wrapId(payment));
        }));
    }

    @Override
    public Observable<List<Payment>> getPayments(ServiceData serviceData, PaymentFilter paymentFilter) {
        List<AccountKey> fromAccounts = paymentFilter.getFromAccounts().getValues();
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(getPaymentsHelper(connection, serviceData, fromAccounts, paymentFilter)
            .filter(paymentFilter.applyFilter())
            .toList()
            .defaultIfEmpty(Collections.emptyList()));
    }

    /**
     * The backend only support 50 accounts at a time, this method recursively ensure that the calls are executed accordingly.
     */
    private Observable<Payment> getPaymentsHelper(M8ImsConnection connection, ServiceData serviceData, List<AccountKey> fromAccounts, PaymentFilter paymentFilter) {
        List<AccountKey> filterAccounts = fromAccounts.subList(0, fromAccounts.size() > 50 ? 50 : fromAccounts.size());
        paymentFilter.setFromAccounts(Filters.listFilterOf(filterAccounts));
        Observable<Payment> paymentObservable = corporateCorporatePaymentIntegration.getConfirmedPayments(connection, serviceData, paymentFilter)
            .concatWith(corporateCorporatePaymentIntegration.getUnconfirmedPayments(connection, serviceData, paymentFilter))
            .concatWith(corporateCorporatePaymentIntegration.getRejectedPayments(connection, serviceData, paymentFilter));
        if (fromAccounts.size() > 50) {
            return paymentObservable.concatWith(getPaymentsHelper(connection, serviceData, fromAccounts.subList(50, fromAccounts.size()), paymentFilter));
        } else {
            return paymentObservable;
        }
    }

    @Override
    public Observable<Payment> getPayment(ServiceData serviceData, Payment payment) {
        Payment paymentWithDetails;
        if (null == payment.getFrom()) {
            paymentWithDetails = unWrapId(payment);
        } else {
            paymentWithDetails = payment;
        }
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(corporateCorporatePaymentIntegration.getConfirmedPayment(connection, serviceData, paymentWithDetails)
                .concatWith(corporateCorporatePaymentIntegration.getUnconfirmedPayment(connection, serviceData, paymentWithDetails))
                .concatWith(corporateCorporatePaymentIntegration.getRejectedPayment(connection, serviceData, paymentWithDetails))
                .filter(p -> p != null)
                .toList()
                .map(payments -> validateSinglePaymentList(payment, payments)));
    }

    private Payment validateSinglePaymentList(Payment queriedPayment, List<Payment> paymentList) {
        if (paymentList.isEmpty()) {
            LOGGER.error("Payment '{}' not found. Responding with a 404/Not found.", queriedPayment.getId());
            throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(queriedPayment.getId()))));
        } else if (paymentList.size() > 1) {
            LOGGER.warn("Request for payment '{}' resulted in more than one (1) result. Responding with a 500/Internal server error.", queriedPayment.getId());
            throw new InternalServerErrorException(new Error().setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR).setErrorDescription("Payment data inconsistency"));
        }
        return paymentList.get(0);
    }
}
