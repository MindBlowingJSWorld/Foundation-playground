package com.nordea.dbf.payment.converters.helpers;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.api.model.accountkey.NordeaAccountKey;

public class PaymentIdConverter {

    public static Payment unWrapId(Payment payment) {
        if (payment.getFrom() != null) {
            throw new IllegalArgumentException("Should not be unwrapped.");
        }

        String[] paymentIdParts = payment.getId().split(":");
        NordeaAccountKey nordeaAccountKey = new NordeaAccountKey(new AccountNumber(paymentIdParts[2]), paymentIdParts[1], "SE");

        payment.setId(paymentIdParts[0]);
        payment.setFrom(nordeaAccountKey.toString());
        return payment;
    }

    public static Payment wrapId(Payment payment) {
        AccountKey accountKey = AccountKey.fromString(payment.getFrom());
        return payment.setId(payment.getId() + ":" + accountKey.getCurrencyCode().get() + ":" + accountKey.getAccountNumber().getAccountNumber());
    }
}
