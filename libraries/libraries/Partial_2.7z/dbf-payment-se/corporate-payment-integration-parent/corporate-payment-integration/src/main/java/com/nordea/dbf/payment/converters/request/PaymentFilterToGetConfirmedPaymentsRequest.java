package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.PaymentFilterType;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.GetConfirmedPaymentsRequestAccountsSegment;
import com.nordea.dbf.payment.record.corporate.payment.GetConfirmedPaymentsRequestRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PaymentFilterToGetConfirmedPaymentsRequest implements Converter<PaymentFilter, GetConfirmedPaymentsRequestRecord> {

    private static final String CONFIRMED_PAYMENTS_REQUEST_TRANSACTION_CODE = "ESC006";
    private static final long AVS_KTO_FORTS = 0L;
    private static final int INDEX_FORTS = 0;
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentFilterToGetConfirmedPaymentsRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public GetConfirmedPaymentsRequestRecord convert(ServiceData serviceData, PaymentFilter paymentFilter) {
        final GetConfirmedPaymentsRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new GetConfirmedPaymentsRequestRecord());
        requestRecord.setTransactionCode(CONFIRMED_PAYMENTS_REQUEST_TRANSACTION_CODE);

        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.STATUS)
                && (!paymentFilter.getStatuses().contains(Payment.StatusEnum.confirmed)
                && !paymentFilter.getStatuses().contains(Payment.StatusEnum.inprogress))) {
            return null;
        }

        requestRecord.setAvsKtoForts(AVS_KTO_FORTS);
        requestRecord.setIndexForts(INDEX_FORTS);
        requestRecord.setTid(StringUtils.EMPTY);

        requestRecord.setUserId(serviceData.getUserId());
        requestRecord.setAnvId(Long.parseLong(serviceData.getUserId()));

        // TODO: Verify that the below assumption is valid
        if (serviceData.getAgreementOwner().length() == 12) {
            requestRecord.setAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner().substring(2, 12)));
        } else {
            requestRecord.setAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner()));
        }

        requestRecord.setTechId(serviceData.getRacfId());

        for (final AccountKey account : (List<AccountKey>) paymentFilter.getFromAccounts().getValues()) {
            final GetConfirmedPaymentsRequestAccountsSegment segment = requestRecord.addAccounts();

            segment.setAvsKonto(Long.parseLong(account.getAccountNumber().getAccountNumber()));
            segment.setValKodAvsKto(account.getCurrencyCode().orElse(null));
        }
        return requestRecord;
    }
}
