package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.PaymentFilterType;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.record.corporate.payment.GetRejectedPaymentsRequestAccountsSegment;
import com.nordea.dbf.payment.record.corporate.payment.GetRejectedPaymentsRequestRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PaymentFilterToGetRejectedPaymentsRequest implements Converter<PaymentFilter, GetRejectedPaymentsRequestRecord> {

    private static final String GET_REJECTED_PAYMENTS_REQUEST_TRANSACTION_CODE = "ESC016";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentFilterToGetRejectedPaymentsRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public GetRejectedPaymentsRequestRecord convert(ServiceData serviceData, PaymentFilter paymentFilter) {
        final GetRejectedPaymentsRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new GetRejectedPaymentsRequestRecord());
        requestRecord.setTransactionCode(GET_REJECTED_PAYMENTS_REQUEST_TRANSACTION_CODE);

        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.STATUS) &&
                !(paymentFilter.getStatuses().contains(Payment.StatusEnum.rejected)
                        || paymentFilter.getStatuses().contains(Payment.StatusEnum.stopped))) {
            return null;
        }

        requestRecord.setTid(StringUtils.EMPTY);
        requestRecord.setUserId(serviceData.getUserId());
        requestRecord.setUser(Long.parseLong(serviceData.getUserId()));

        // TODO: Verify that the below assumption is valid
        if (serviceData.getAgreementOwner().length() == 12) {
            requestRecord.setAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner().substring(2, 12)));
        } else {
            requestRecord.setAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner()));
        }

        requestRecord.setTechId(serviceData.getRacfId());

        for (final AccountKey account : (List<AccountKey>) paymentFilter.getFromAccounts().getValues()) {
            final GetRejectedPaymentsRequestAccountsSegment segment = requestRecord.addAccounts();
            segment.setPgKtoNr(Long.parseLong(account.getAccountNumber().getAccountNumber()));
        }
        return requestRecord;
    }
}
