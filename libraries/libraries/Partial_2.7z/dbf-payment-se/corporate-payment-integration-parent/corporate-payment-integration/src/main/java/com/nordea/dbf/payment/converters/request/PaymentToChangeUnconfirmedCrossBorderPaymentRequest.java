package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.CorporatePayment;
import com.nordea.dbf.payment.model.CorporatePaymentType;
import com.nordea.dbf.payment.model.CrossBorderChargePaidBy;
import com.nordea.dbf.payment.model.PaymentSpeed;
import com.nordea.dbf.payment.record.corporate.payment.ChangeUnconfirmedCrossBorderPaymentRequestRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;

@Component
public class PaymentToChangeUnconfirmedCrossBorderPaymentRequest implements Converter<Payment, ChangeUnconfirmedCrossBorderPaymentRequestRecord> {

    private static final String EMPTY_STRING = StringUtils.EMPTY;
    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.##");
    private static final String CHANGE_UNCONFIRMED_CROSS_BORDER_PAYMENT_REQUEST_TRANSACTION_CODE = "ESC004";

    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToChangeUnconfirmedCrossBorderPaymentRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public ChangeUnconfirmedCrossBorderPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        final ChangeUnconfirmedCrossBorderPaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new ChangeUnconfirmedCrossBorderPaymentRequestRecord());
        requestRecord.setTransactionCode(CHANGE_UNCONFIRMED_CROSS_BORDER_PAYMENT_REQUEST_TRANSACTION_CODE);

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());
        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());

        CrossBorder crossBorderRequest = payment.getCrossBorder();
        // FIXME: Verify if this is validated in the backend.
        if (crossBorderRequest == null) {
            crossBorderRequest = new CrossBorder();
        }

        // TODO: Verify that the below assumption is valid
        if (serviceData.getAgreementOwner().length() == 12) {
            requestRecord.setInAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner().substring(2, 12)));
        } else {
            requestRecord.setInAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner()));
        }

        requestRecord.setInTechId(serviceData.getRacfId());

        requestRecord.setInTidChangePay(payment.getId());

        requestRecord.setInAnvId(Long.valueOf(serviceData.getUserId().substring(2, 12)));
        requestRecord.setInAvsKto(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setInFicka(fromAccountKey.getCurrencyCode().orElse(null));
        requestRecord.setInMottKto(toAccountKey.getAccountNumber().getAccountNumber());

        requestRecord.setInSwiftKod(crossBorderRequest.getBic() != null ? crossBorderRequest.getBic() : EMPTY_STRING);
        requestRecord.setInLandKod(crossBorderRequest.getBankCountry() != null ? crossBorderRequest.getBankCountry() : EMPTY_STRING);
        requestRecord.setInSortCode(crossBorderRequest.getBranchCode() != null ? crossBorderRequest.getBranchCode() : EMPTY_STRING);

        requestRecord.setInUadr(EMPTY_STRING);
        requestRecord.setInUadr2(EMPTY_STRING);
        requestRecord.setInBankNamn(crossBorderRequest.getBankName() != null ? crossBorderRequest.getBankName() : EMPTY_STRING);

        for (int i = 0; i < crossBorderRequest.getAddress().size(); i++) {
            switch (i) {
                case 0:
                    requestRecord.setInAdrBghx1(crossBorderRequest.getAddress().get(i));
                    break;
                case 1:
                    requestRecord.setInAdrBghx2(crossBorderRequest.getAddress().get(i));
                    break;
                case 2:
                    requestRecord.setInAdrBghx3(crossBorderRequest.getAddress().get(i));
                    break;
            }
        }
        requestRecord.setInBel(formatAmount(payment.getAmount().doubleValue()));
        requestRecord.setInValKod(payment.getCurrency());

        requestRecord.setInBegartBokfDat(CorporatePayment.formatAsDateWithoutCentury(payment.getDue()));
        requestRecord.setInMottMed(payment.getMessage());
        requestRecord.setInEffTyp(PaymentSpeed.get(payment.getSpeed() != null ? payment.getSpeed() : Payment.SpeedEnum.normal).toString());

        requestRecord.setInBetalare(CrossBorderChargePaidBy.get(crossBorderRequest.getChargePaidBy()).toString());
        requestRecord.setInRbKod(crossBorderRequest.getCentralBankReportingCode());
        requestRecord.setInMottNamn(payment.getRecipientName() != null ? payment.getRecipientName() : StringUtils.EMPTY);
        requestRecord.setInSepa(crossBorderRequest.getSepaReference() != null ? crossBorderRequest.getSepaReference() : EMPTY_STRING);

        requestRecord.setInPaySubTypeExt(CorporatePaymentType.CROSSBORDER_SEPA.getLegacyCode()); // valid also for non SEPA cross border payments
        return requestRecord;
    }

    private String formatAmount(Double amount) {
        return DECIMAL_FORMAT.format(amount).replace(".", ",");
    }
}
