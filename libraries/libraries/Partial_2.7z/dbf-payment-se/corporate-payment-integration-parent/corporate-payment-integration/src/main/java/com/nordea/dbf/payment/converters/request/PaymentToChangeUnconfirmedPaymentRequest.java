package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.CorporatePayment;
import com.nordea.dbf.payment.model.LegacyPaymentType;
import com.nordea.dbf.payment.record.corporate.payment.ChangeUnconfirmedPaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;

@Component
public class PaymentToChangeUnconfirmedPaymentRequest implements Converter<Payment, ChangeUnconfirmedPaymentRequestRecord> {

    private static final String CHANGE_UNCONFIRMED_PAYMENT_REQUEST_TRANSACTION_CODE = "ESC020";
    private static final String IN_ADD_RECIP = "N";
    private static final String IN_MOTT_NAMN = "";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToChangeUnconfirmedPaymentRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public ChangeUnconfirmedPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        final ChangeUnconfirmedPaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new ChangeUnconfirmedPaymentRequestRecord());
        requestRecord.setTransactionCode(CHANGE_UNCONFIRMED_PAYMENT_REQUEST_TRANSACTION_CODE);

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());
        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());

        // TODO: Verify that the below assumption is valid
        if (serviceData.getAgreementOwner().length() == 12) {
            requestRecord.setInAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner().substring(2, 12)));
        } else {
            requestRecord.setInAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner()));
        }

        requestRecord.setInTechId(serviceData.getRacfId());

        requestRecord.setInAnvId(serviceData.getUserId().substring(2, 12));
        requestRecord.setInAvsKto(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setInFicka(fromAccountKey.getCurrencyCode().orElse(null));

        requestRecord.setInMottKto(toAccountKey.getAccountNumber().getAccountNumber());

        requestRecord.setInBel(formatAmount(payment.getAmount().doubleValue()));
        requestRecord.setInValKod(payment.getCurrency());

        requestRecord.setInBegartBokfDat(CorporatePayment.formatAsDateWithoutCentury(payment.getDue()));
        requestRecord.setInMottMed(payment.getMessage());
        requestRecord.setInRefVs(payment.getOwnMessage());
        requestRecord.setInTidChangePay(payment.getId());

        requestRecord.setInAddRecip(IN_ADD_RECIP); // Don't handle beneficiaries
        requestRecord.setInMottNamn(IN_MOTT_NAMN); // Don't set a beneficiary

        requestRecord.setInPaySubTypeExt(LegacyPaymentType.codeFromPaymentType(payment.getType()));
        return requestRecord;
    }

    private String formatAmount(Double amount) {
        return new DecimalFormat("#.##").format(amount).replace(".", ",");
    }
}
