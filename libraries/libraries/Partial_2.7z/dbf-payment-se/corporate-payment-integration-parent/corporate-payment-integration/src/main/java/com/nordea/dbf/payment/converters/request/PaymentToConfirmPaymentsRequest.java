package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.ConfirmPaymentsRequestPaymentsSegment;
import com.nordea.dbf.payment.record.corporate.payment.ConfirmPaymentsRequestRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToConfirmPaymentsRequest implements Converter<Payment, ConfirmPaymentsRequestRecord> {

    private static final String CONFIRM_PAYMENTS_REQUEST_TRANSACTION_CODE = "ESC005";
    private static final String BET_KOD_CROSSBORDER = "U";
    private static final String BET_KOD_DOMESTIC = "I";
    private static final String CONFIRM_PAYMENTS_REQUEST_FILKLUMP_N = "N";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToConfirmPaymentsRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public ConfirmPaymentsRequestRecord convert(ServiceData serviceData, Payment payment) {
        final ConfirmPaymentsRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new ConfirmPaymentsRequestRecord());
        requestRecord.setTransactionCode(CONFIRM_PAYMENTS_REQUEST_TRANSACTION_CODE);

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());

        // FIXME: If agreementHolderId is an organization number pad the beginning of what we send with "00"
        if (serviceData.getAgreementOwner().length() == 12) {
            requestRecord.setAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner().substring(2, 12)));
        } else {
            requestRecord.setAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner()));
        }
        requestRecord.setInTechId(serviceData.getRacfId());

        requestRecord.setInAnvandare(serviceData.getUserId());
        requestRecord.setInAvsKto(fromAccountKey.getAccountNumber().getAccountNumber());
        requestRecord.setInFicka(fromAccountKey.getCurrencyCode().orElse(StringUtils.EMPTY));
        requestRecord.setInBetKod(setBetKod(payment.getType()));
        requestRecord.setInKtoDoublesign(""); // This field should be 2 if double sign is required otherwise ""

        // FIXME: Currently batch confirmation is not supported
        final ConfirmPaymentsRequestPaymentsSegment paymentSegment = requestRecord.addPayments();
        paymentSegment.setInTidSign(payment.getId());
        paymentSegment.setInYOmDetEEnFilKlump(CONFIRM_PAYMENTS_REQUEST_FILKLUMP_N);
        return requestRecord;
    }

    private String setBetKod(Payment.TypeEnum type) {
        return type == Payment.TypeEnum.crossborder ? BET_KOD_CROSSBORDER : BET_KOD_DOMESTIC;
    }
}
