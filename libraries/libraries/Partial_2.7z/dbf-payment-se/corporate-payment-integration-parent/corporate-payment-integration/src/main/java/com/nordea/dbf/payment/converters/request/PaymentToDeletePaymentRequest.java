package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.DeletePaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToDeletePaymentRequest implements Converter<Payment, DeletePaymentRequestRecord> {

    private static final String DELETE_PAYMENT_REQUEST_TRANSACTION_CODE = "ESC017";
    private static final String PAYMENT_STATUS_SIGNED = "Y";
    private static final String PAYMENT_STATUS_UNSIGNED = "N";
    private static final String PAYMENT_STATUS_REJECTED = "R";
    private static final String PAYMENT_TYPE_CROSSBORDER = "U";
    private static final String PAYMENT_TYPE_DOMESTIC = "I";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToDeletePaymentRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public DeletePaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        final DeletePaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new DeletePaymentRequestRecord());
        requestRecord.setTransactionCode(DELETE_PAYMENT_REQUEST_TRANSACTION_CODE);

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());

        requestRecord.setInTechId(serviceData.getRacfId());
        requestRecord.setInUserId(serviceData.getUserId());

        requestRecord.setInTid(payment.getId());

        requestRecord.setInAvsKto(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setInFicka(fromAccountKey.getCurrencyCode().get());
        requestRecord.setInBetTyp(setDomesticOrCrossBorder(payment)); // Domestic / Crossborder
        requestRecord.setInSign(setSignedOrNotSigned(payment)); //  Signed or not signed

        return requestRecord;
    }

    private String setSignedOrNotSigned(Payment existingPayment) {
        switch (existingPayment.getStatus()) {
            case confirmed:
                return PAYMENT_STATUS_SIGNED;
            case rejected:
                return PAYMENT_STATUS_REJECTED;
            default:
                return PAYMENT_STATUS_UNSIGNED;
        }
    }

    private String setDomesticOrCrossBorder(Payment existingPayment) {
        switch (existingPayment.getType()) {
            case crossborder:
                return PAYMENT_TYPE_CROSSBORDER;
            default:
                return PAYMENT_TYPE_DOMESTIC;
        }
    }
}
