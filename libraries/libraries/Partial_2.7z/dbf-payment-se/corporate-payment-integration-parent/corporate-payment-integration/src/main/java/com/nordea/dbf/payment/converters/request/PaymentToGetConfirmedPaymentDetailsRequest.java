package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.GetConfirmedPaymentDetailsRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToGetConfirmedPaymentDetailsRequest implements Converter<Payment, GetConfirmedPaymentDetailsRequestRecord> {

    private static final String CONFIRMED_PAYMENT_DETAILS_REQUEST_TRANSACTION_CODE = "ESC018";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToGetConfirmedPaymentDetailsRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public GetConfirmedPaymentDetailsRequestRecord convert(ServiceData serviceData, Payment payment) {
        GetConfirmedPaymentDetailsRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new GetConfirmedPaymentDetailsRequestRecord());
        requestRecord.setTransactionCode(CONFIRMED_PAYMENT_DETAILS_REQUEST_TRANSACTION_CODE);

        final AccountKey accountKey = AccountKey.fromString(payment.getFrom());

        requestRecord.setInUserid(serviceData.getUserId().substring(2, 12));

        requestRecord.setInTechId(serviceData.getRacfId());
        requestRecord.setInTid(payment.getId());
        requestRecord.setInAvsKto(Long.parseLong(accountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setInFicka(accountKey.getCurrencyCode().orElse(null));
        return requestRecord;
    }
}
