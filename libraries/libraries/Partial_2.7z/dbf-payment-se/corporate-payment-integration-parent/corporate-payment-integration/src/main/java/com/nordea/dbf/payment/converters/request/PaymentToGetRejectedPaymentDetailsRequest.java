package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.GetRejectedPaymentsRequestAccountsSegment;
import com.nordea.dbf.payment.record.corporate.payment.GetRejectedPaymentsRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToGetRejectedPaymentDetailsRequest implements Converter<Payment, GetRejectedPaymentsRequestRecord> {

    private static final String GET_REJECTED_PAYMENTS_REQUEST_TRANSACTION_CODE = "ESC016";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToGetRejectedPaymentDetailsRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public GetRejectedPaymentsRequestRecord convert(ServiceData serviceData, Payment payment) {
        final GetRejectedPaymentsRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new GetRejectedPaymentsRequestRecord());
        requestRecord.setTransactionCode(GET_REJECTED_PAYMENTS_REQUEST_TRANSACTION_CODE);

        requestRecord.setTid(payment.getId());
        requestRecord.setUserId(serviceData.getUserId());
        requestRecord.setUser(Long.parseLong(serviceData.getUserId()));

        // TODO: Verify that the below assumption is valid
        if (serviceData.getAgreementOwner().length() == 12) {
            requestRecord.setAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner().substring(2, 12)));
        } else {
            requestRecord.setAgreementHolderId(Long.valueOf(serviceData.getAgreementOwner()));
        }

        requestRecord.setTechId(serviceData.getRacfId());

        final GetRejectedPaymentsRequestAccountsSegment segment = requestRecord.addAccounts();
        segment.setPgKtoNr(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
        return requestRecord;
    }
}
