package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.record.corporate.payment.GetUnconfirmedPaymentDetailsRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToGetUnconfirmedPaymentDetailsRequest implements Converter<Payment, GetUnconfirmedPaymentDetailsRequestRecord> {

    private static final String UNCONFIRMED_PAYMENT_DETAILS_REQUEST_TRANSACTION_CODE = "ESC019";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToGetUnconfirmedPaymentDetailsRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public GetUnconfirmedPaymentDetailsRequestRecord convert(ServiceData serviceData, Payment payment) {
        GetUnconfirmedPaymentDetailsRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new GetUnconfirmedPaymentDetailsRequestRecord());
        requestRecord.setTransactionCode(UNCONFIRMED_PAYMENT_DETAILS_REQUEST_TRANSACTION_CODE);

        final AccountKey accountKey = AccountKey.fromString(payment.getFrom());

        requestRecord.setInUserid(serviceData.getUserId().substring(2, 12));

        requestRecord.setInTechId(serviceData.getRacfId());
        requestRecord.setInTid(payment.getId());
        requestRecord.setInAvsKto(Long.parseLong(accountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setInFicka(accountKey.getCurrencyCode().orElse(null));
        return requestRecord;
    }
}
