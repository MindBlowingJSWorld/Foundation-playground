package com.nordea.dbf.payment.converters.response;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BackendException;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.record.corporate.payment.ConfirmPaymentsResponsePaymentsSegment;
import com.nordea.dbf.payment.record.corporate.payment.ConfirmPaymentsResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import com.nordea.dbf.api.model.Error;

@Component
public class ConfirmPaymentsResponseRecordConverter implements ResponseConverter<ConfirmPaymentsResponseRecord, Payment> {
    @Autowired
    @Qualifier("corporateErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public Payment responseConvert(ServiceData serviceData, ConfirmPaymentsResponseRecord responseRecord) {
        // Fixme: This should be changed once the implementation support multiple confirmations.
        if (responseRecord.getUtAntFel() > 0) {
            throw new BackendException(new Error().setError(ErrorResponses.Types.BACKEND_ERROR).setErrorDescription("Errors occurred during confirmation. "));
        } else if (responseRecord.getUtAntRatt() < 1) {
            throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found."));
        }

        ConfirmPaymentsResponsePaymentsSegment segment = (ConfirmPaymentsResponsePaymentsSegment) responseRecord.getPayments().next();
        return new Payment().setId(segment.getUtTidSign());
    }
}
