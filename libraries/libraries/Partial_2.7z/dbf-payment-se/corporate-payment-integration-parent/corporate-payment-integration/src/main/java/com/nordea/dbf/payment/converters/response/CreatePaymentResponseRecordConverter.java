package com.nordea.dbf.payment.converters.response;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.record.corporate.payment.CreatePaymentResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

@Component
public class CreatePaymentResponseRecordConverter implements ResponseConverter<CreatePaymentResponseRecord, Payment> {
    @Autowired
    @Qualifier("corporateErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public Payment responseConvert(ServiceData serviceData, CreatePaymentResponseRecord responseRecord) {
        final Payment payment = new Payment();
        payment.setId(responseRecord.getPayKey());
        return payment;
    }
}
