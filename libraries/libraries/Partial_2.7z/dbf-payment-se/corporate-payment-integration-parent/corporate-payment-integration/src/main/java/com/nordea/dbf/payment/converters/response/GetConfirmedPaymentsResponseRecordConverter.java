package com.nordea.dbf.payment.converters.response;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentModifyFields;
import com.nordea.dbf.api.model.PaymentPermissions;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.CorporatePaymentType;
import com.nordea.dbf.payment.model.CrossBorderChargePaidBy;
import com.nordea.dbf.payment.model.LegacyPaymentType;
import com.nordea.dbf.payment.record.corporate.payment.GetConfirmedPaymentsResponsePaymentsSegment;
import com.nordea.dbf.payment.record.corporate.payment.GetConfirmedPaymentsResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.wrapId;
import static com.nordea.dbf.payment.model.CorporateAccountKeyCreator.createFromAccountKey;
import static com.nordea.dbf.payment.model.CorporateAccountKeyCreator.createToAccountKey;
import static com.nordea.dbf.payment.model.CorporateTimeConverter.convertTimestamp;

@Component
public class GetConfirmedPaymentsResponseRecordConverter implements ResponseConverter<GetConfirmedPaymentsResponseRecord, List<Payment>> {

    @Autowired
    @Qualifier("corporateErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public List<Payment> responseConvert(ServiceData serviceData, GetConfirmedPaymentsResponseRecord getConfirmedPaymentsResponseRecord) {
        final List<Payment> payments = new ArrayList<>();
        final Iterator responseRecordPayments = getConfirmedPaymentsResponseRecord.getPayments();
        while (responseRecordPayments.hasNext()) {
            final GetConfirmedPaymentsResponsePaymentsSegment responseRecordPayment =
                    (GetConfirmedPaymentsResponsePaymentsSegment) responseRecordPayments.next();

            // Ignore payments that we cannot map
            if (null == responseRecordPayment.getEsc006uSubType() || null == LegacyPaymentType.fromCode(responseRecordPayment.getEsc006uSubType())) {
                continue;
            }

            final AccountKey toAccountKey = createToAccountKey(responseRecordPayment.getEsc006uSubType(), responseRecordPayment.getEsc006uMottKto(),
                    responseRecordPayment.getEsc006uValKod(), Optional.of(responseRecordPayment.getEsc006uSwiftKod()));
            final Payment payment = new Payment().setEntryDate(convertTimestamp(responseRecordPayment.getEsc006uRegistrTidp()))
                    .setId(responseRecordPayment.getEsc006uTid())
                    .setFrom(createFromAccountKey(responseRecordPayment.getEsc006uAvsKto(), responseRecordPayment.getEsc006uValKodAvsKto()))
                    .setTo(toAccountKey.toString())
                    .setDue(LocalDate.parse(responseRecordPayment.getEsc006uBegartBokfDat()))
                    .setAmount(BigDecimal.valueOf(responseRecordPayment.getEsc006uBel()))
                    .setCurrency(responseRecordPayment.getEsc006uValKod())
                    .setType(CorporatePaymentType.fromLegacyCode(responseRecordPayment.getEsc006uSubType(), toAccountKey.getPrefix()))
                    .setPermissions(new PaymentPermissions()
                            .setCopy(true).setDelete(parseYesNo(responseRecordPayment.getEsc006uFlDelete()))
                            .setModify(new PaymentModifyFields().setAmount(false).setDue(false).setFrom(false).setMessage(false)
                                    .setRecurringCount(false).setRecurringInterval(false).setRecurringLastday(false).setRecurringRepeats(false)
                                    .setTo(false).setType(false)))
                    .setStatus(parsePaymentType(responseRecordPayment.getEsc006uFlDelete()))
                    .setMessage(responseRecordPayment.getEsc006MottMed())
                    .setOwnMessage(responseRecordPayment.getEsc006RefAvs())
                    .setRecipientName(responseRecordPayment.getEsc006uMottNamn());
            if (Payment.TypeEnum.crossborder.equals(payment.getType())) {
                payment.setCrossBorder(setCrossBorderInformation(responseRecordPayment));
            }
            payments.add(wrapId(payment));
        }
        return payments;
    }

    private Payment.StatusEnum parsePaymentType(String deleteFlag) {
        if (deleteFlag.equals("P")) {
            return Payment.StatusEnum.inprogress;
        }
        return Payment.StatusEnum.confirmed;
    }

    protected boolean parseYesNo(String yesNo) {
        return "y".equals(yesNo.toLowerCase());
    }

    private CrossBorder setCrossBorderInformation(GetConfirmedPaymentsResponsePaymentsSegment responseRecordSegment) {
        return new CrossBorder()
                .setAddress(Arrays.asList(responseRecordSegment.getEsc006uAdrBghx(), responseRecordSegment.getEsc006uPoNr(), responseRecordSegment.getEsc006uPostOrt()))
                .setBankCountry(responseRecordSegment.getEsc006uLandKod())
                .setChargePaidBy(StringUtils.isEmpty(responseRecordSegment.getEsc006uBetalare()) ? CrossBorderChargePaidBy.O.getChargePaidByPayment()
                        : CrossBorderChargePaidBy.valueOf(responseRecordSegment.getEsc006uBetalare()).getChargePaidByPayment())
                .setBic(responseRecordSegment.getEsc006uSwiftKod())
                .setBranchCode(responseRecordSegment.getEsc006uSortCode())
                .setCentralBankReportingCode(responseRecordSegment.getEsc006uRbKod())
                .setSepaReference(responseRecordSegment.getEsc006uSepaRef());
    }
}

