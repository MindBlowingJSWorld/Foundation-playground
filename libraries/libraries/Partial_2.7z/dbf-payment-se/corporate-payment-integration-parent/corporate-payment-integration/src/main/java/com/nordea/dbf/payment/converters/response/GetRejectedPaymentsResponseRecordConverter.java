package com.nordea.dbf.payment.converters.response;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentModifyFields;
import com.nordea.dbf.api.model.PaymentPermissions;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.CorporatePaymentFacade;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.model.CorporatePaymentType;
import com.nordea.dbf.payment.model.CrossBorderChargePaidBy;
import com.nordea.dbf.payment.model.LegacyPaymentType;
import com.nordea.dbf.payment.record.corporate.payment.GetRejectedPaymentsResponsePaymentsSegment;
import com.nordea.dbf.payment.record.corporate.payment.GetRejectedPaymentsResponseRecord;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.wrapId;
import static com.nordea.dbf.payment.model.CorporateAccountKeyCreator.createFromAccountKey;
import static com.nordea.dbf.payment.model.CorporateAccountKeyCreator.createToAccountKey;
import static com.nordea.dbf.payment.model.CorporateTimeConverter.convertTimestamp;

@Component
public class GetRejectedPaymentsResponseRecordConverter implements ResponseConverter<GetRejectedPaymentsResponseRecord, List<Payment>> {

    @Autowired
    @Qualifier("corporateErrorHandler")
    BackendErrorHandler backendErrorHandler;

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CorporatePaymentFacade.class);

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public List<Payment> responseConvert(ServiceData serviceData, GetRejectedPaymentsResponseRecord getRejectedPaymentsResponseRecord) {
        final List<Payment> payments = new ArrayList<>();
        final Iterator responseRecordPayments = getRejectedPaymentsResponseRecord.getPayments();
        while (responseRecordPayments.hasNext()) {
            final GetRejectedPaymentsResponsePaymentsSegment responseRecordPayment =
                    (GetRejectedPaymentsResponsePaymentsSegment) responseRecordPayments.next();

            // Ignore payments that we cannot map
            if (null == responseRecordPayment.getEsc016uSubType() || null == LegacyPaymentType.fromCode(responseRecordPayment.getEsc016uSubType())) {
                LOGGER.warn("Payment with ID '{}' contained no type, skipping.", responseRecordPayment.getEsc016uTid());
                continue;
            }

            final AccountKey toAccountKey = createToAccountKey(responseRecordPayment.getEsc016uSubType(), responseRecordPayment.getEsc016uKtoMott(), responseRecordPayment.getEsc016uKodVltaOrig());
            final Payment payment = new Payment().setEntryDate(convertTimestamp(responseRecordPayment.getEsc016uTid()))
                    .setId(responseRecordPayment.getEsc016uTid())
                    .setFrom(createFromAccountKey(responseRecordPayment.getEsc016uPgKtoNr(), responseRecordPayment.getEsc016uKodVltaOrig()))
                    .setTo(toAccountKey.toString())
                    .setAmount(BigDecimal.valueOf(responseRecordPayment.getEsc016uBel()))
                    .setCurrency(responseRecordPayment.getEsc016uVltaFickKod())
                    .setType(CorporatePaymentType.fromLegacyCode(responseRecordPayment.getEsc016uSubType(), toAccountKey.getPrefix()))
                    .setRecipientName(responseRecordPayment.getEsc016uNamnMott());
            if (Payment.TypeEnum.crossborder.equals(payment.getType())) {
                payment.setCrossBorder(setCrossBorderInformation(responseRecordPayment));
            }

            if ("03".equals(responseRecordPayment.getEsc016uTypFel())
                    || "04".equals(responseRecordPayment.getEsc016uTypFel())
                    || "05".equals(responseRecordPayment.getEsc016uTypFel())) {
                payment.setStatusMessage("Payment not successful due to low funds ");
            } else {
                payment.setStatusMessage("Payment not successful due to account error");
            }

            switch (responseRecordPayment.getEsc016uStatuskod()) {
                case "H":
                    payment.setStatus(Payment.StatusEnum.stopped);
                    payment.setDateStopped(responseRecordPayment.getEsc016uDatHejd());
                    payment.setPermissions(new PaymentPermissions()
                                    .setCopy(false)
                                    .setDelete(false)
                                    .setModify(setModifyConditions()));
                    payments.add(wrapId(payment));
                    break;
                case "M":
                    payment.setStatus(Payment.StatusEnum.rejected);
                    payment.setDateStopped(responseRecordPayment.getEsc016uDatHejd());
                    payment.setDateRejected(responseRecordPayment.getEsc016uDatMak());
                    payment.setPermissions(new PaymentPermissions()
                            .setCopy(false)
                            .setDelete(true)
                            .setModify(setModifyConditions()));
                    payments.add(wrapId(payment));
                    break;
                default:
                    LOGGER.warn("Payment with ID '{}' contained unsupported status code (not rejected or stopped), skipping.", responseRecordPayment.getEsc016uTid());
            }
        }
        return payments;
    }

    private CrossBorder setCrossBorderInformation(GetRejectedPaymentsResponsePaymentsSegment responseRecordSegment) {
        return new CrossBorder()
                .setAddress(Collections.emptyList())
                .setBankCountry("")
                .setChargePaidBy(CrossBorderChargePaidBy.O.getChargePaidByPayment())
                .setBic("")
                .setBranchCode("")
                .setCentralBankReportingCode("")
                .setSepaReference("");
    }

    private PaymentModifyFields setModifyConditions() {
        return new PaymentModifyFields().setAmount(false).setDue(false).setFrom(false).setMessage(false)
                .setRecurringCount(false).setRecurringInterval(false).setRecurringLastday(false).setRecurringRepeats(false)
                .setTo(false).setType(false);
    }
}
