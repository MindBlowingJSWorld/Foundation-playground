package com.nordea.dbf.payment.converters.response;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.model.CrossBorderChargePaidBy;
import com.nordea.dbf.payment.model.LegacyPaymentType;
import com.nordea.dbf.payment.model.PaymentSpeed;
import com.nordea.dbf.payment.record.corporate.payment.GetUnconfirmedPaymentDetailsResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;

import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.wrapId;
import static com.nordea.dbf.payment.model.CorporateAccountKeyCreator.createFromAccountKey;
import static com.nordea.dbf.payment.model.CorporateAccountKeyCreator.createToAccountKey;
import static com.nordea.dbf.payment.model.CorporateTimeConverter.convertTimestamp;

@Component
public class GetUnconfirmedPaymentDetailsResponseRecordConverter implements ResponseConverter<GetUnconfirmedPaymentDetailsResponseRecord, Payment> {
    @Autowired
    @Qualifier("corporateErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        if (kbearb == 4 && krc == 4) {
            // Ignore payment not found
            return;
        }
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public Payment responseConvert(ServiceData serviceData, GetUnconfirmedPaymentDetailsResponseRecord responseRecord) {
        Optional<String> bicCode = StringUtils.isNotEmpty(responseRecord.getSwiftKod()) ? Optional.of(responseRecord.getSwiftKod()) : Optional.empty();
        if (responseRecord.getKbearb() == 4 && responseRecord.getKrc() == 4) {
            // Ignore payment not found
            return null;
        }

        // Ignore payments that we cannot map
        if (null == LegacyPaymentType.fromCode(responseRecord.getSubType())) {
            return null;
        }

        Payment payment = new Payment();
        payment.setId(responseRecord.getTid());
        payment.setFrom(createFromAccountKey(responseRecord.getAvsKto(), responseRecord.getValKodAvsKto()));
        payment.setTo(createToAccountKey(responseRecord.getSubType(), responseRecord.getMottKto(), responseRecord.getValKod(), bicCode).toString());
        payment.setMessage(responseRecord.getMottMed());
        payment.setOwnMessage(responseRecord.getRefAvs());
        payment.setAmount(BigDecimal.valueOf(responseRecord.getBel()));
        payment.setEntryDate(convertTimestamp(responseRecord.getTid()));
        payment.setType(LegacyPaymentType.fromCode(responseRecord.getSubType()).toPaymentType());
        payment.setStatus(Payment.StatusEnum.unconfirmed);
        payment.setDue(LocalDate.parse(responseRecord.getBegartBokfDat()));
        payment.setCurrency(responseRecord.getValKod());
        payment.setSpeed(PaymentSpeed.fromCode(responseRecord.getEffTyp()));
        // FIXME: Permissions is only passed in the listing.
        //payment.setPermissions(originalPayment.getPermissions());
        if (Payment.TypeEnum.crossborder.equals(payment.getType())) {
            payment.setCrossBorder(setCrossBorderInformation(responseRecord));
        }
        payment.setRecipientName(responseRecord.getMottNamn());
        return wrapId(payment);
    }

    private CrossBorder setCrossBorderInformation(GetUnconfirmedPaymentDetailsResponseRecord responseRecord) {
        CrossBorder crossBorder = new CrossBorder();
        crossBorder.setAddress(Arrays.asList(responseRecord.getAdrBgxh(), responseRecord.getPonr(), responseRecord.getPostOrt()));
        crossBorder.setBankCountry(responseRecord.getLandKod());
        crossBorder.setChargePaidBy(StringUtils.isEmpty(responseRecord.getBetalare()) ? CrossBorderChargePaidBy.O.getChargePaidByPayment()
                : CrossBorderChargePaidBy.valueOf(responseRecord.getBetalare()).getChargePaidByPayment());
        crossBorder.setBic(responseRecord.getSwiftKod());
        crossBorder.setCentralBankReportingCode(responseRecord.getRbKod());
        crossBorder.setSepaReference(responseRecord.getSepaMed());
        crossBorder.setBankName(responseRecord.getBanknamn());
        crossBorder.setBranchCode(responseRecord.getMottBankkod());
        return crossBorder;
    }
}
