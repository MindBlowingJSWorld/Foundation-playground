package com.nordea.dbf.payment.converters.response;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentModifyFields;
import com.nordea.dbf.api.model.PaymentPermissions;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.CorporatePaymentFacade;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.model.CorporatePaymentType;
import com.nordea.dbf.payment.model.CrossBorderChargePaidBy;
import com.nordea.dbf.payment.model.LegacyPaymentType;
import com.nordea.dbf.payment.record.corporate.payment.GetUnconfirmedPaymentsResponsePaymentsSegment;
import com.nordea.dbf.payment.record.corporate.payment.GetUnconfirmedPaymentsResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.wrapId;
import static com.nordea.dbf.payment.model.CorporateAccountKeyCreator.createFromAccountKey;
import static com.nordea.dbf.payment.model.CorporateAccountKeyCreator.createToAccountKey;
import static com.nordea.dbf.payment.model.CorporateTimeConverter.convertTimestamp;

@Component
public class GetUnconfirmedPaymentsResponseRecordConverter implements ResponseConverter<GetUnconfirmedPaymentsResponseRecord, List<Payment>> {

    @Autowired
    @Qualifier("corporateErrorHandler")
    BackendErrorHandler backendErrorHandler;

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CorporatePaymentFacade.class);

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public List<Payment> responseConvert(ServiceData serviceData, GetUnconfirmedPaymentsResponseRecord getUnconfirmedPaymentsResponseRecord) {
        final List<Payment> payments = new ArrayList<>();
        final Iterator responseRecordPayments = getUnconfirmedPaymentsResponseRecord.getPayments();
        while (responseRecordPayments.hasNext()) {
            final GetUnconfirmedPaymentsResponsePaymentsSegment responseRecordPayment =
                    (GetUnconfirmedPaymentsResponsePaymentsSegment) responseRecordPayments.next();

            // Ignore payments that we cannot map
            if (null == responseRecordPayment.getEsc003uSubType() || null == LegacyPaymentType.fromCode(responseRecordPayment.getEsc003uSubType())) {
                LOGGER.warn("Payment with ID '{}' contained no type, skipping.", responseRecordPayment.getEsc003uTid());
                continue;
            }

            final AccountKey toAccountKey = createToAccountKey(responseRecordPayment.getEsc003uSubType(), responseRecordPayment.getEsc003uMottKto(),
                    responseRecordPayment.getEsc003uValKod(), Optional.of(responseRecordPayment.getEsc003uSwiftKod()));

            final Payment payment = new Payment();
            payment.setEntryDate(convertTimestamp(responseRecordPayment.getEsc003uRegistrTidp()));
            payment.setFrom(createFromAccountKey(responseRecordPayment.getEsc003uAvsKto(), responseRecordPayment.getEsc003uValKodAvsKto()));
            payment.setTo(toAccountKey.toString());
            payment.setDue(LocalDate.parse(responseRecordPayment.getEsc003uBegartBokfDat()));
            payment.setAmount(BigDecimal.valueOf(responseRecordPayment.getEsc003uBel()));
            payment.setCurrency(responseRecordPayment.getEsc003uValKod());
            payment.setPermissions(new PaymentPermissions()
                    .setCopy(true).setDelete(parseYesNo(responseRecordPayment.getEsc003uFlDelete()))
                    .setModify(getModifyConditions(responseRecordPayment)));
            payment.setStatus(Payment.StatusEnum.unconfirmed);
            payment.setType(CorporatePaymentType.fromLegacyCode(responseRecordPayment.getEsc003uSubType(), toAccountKey.getPrefix()));
            payment.setMessage(responseRecordPayment.getEsc003uMottMed());
            payment.setId(responseRecordPayment.getEsc003uTid());
            payment.setRecipientName(responseRecordPayment.getEsc003uMottNamn());
            if (Payment.TypeEnum.crossborder.equals(payment.getType())) {
                payment.setCrossBorder(setCrossBorderInformation(responseRecordPayment));
            }
            payment.setOwnMessage(responseRecordPayment.getEsc003uRefAvs());
            payments.add(wrapId(payment));
        }
        return payments;
    }

    protected PaymentModifyFields getModifyConditions(GetUnconfirmedPaymentsResponsePaymentsSegment responseRecordPayment) {
        final boolean allowedToChange = parseYesNo(responseRecordPayment.getEsc003uFlChange());
        if (allowedToChange) {
            return new PaymentModifyFields().setAmount(true).setDue(true).setFrom(true).setMessage(true)
                    .setRecurringCount(true).setRecurringInterval(true).setRecurringLastday(true).setRecurringRepeats(true)
                    .setTo(true).setType(true);
        } else {
            return null;
        }
    }

    protected boolean parseYesNo(String yesNo) {
        return "y".equals(yesNo.toLowerCase());
    }

    private CrossBorder setCrossBorderInformation(GetUnconfirmedPaymentsResponsePaymentsSegment responseRecordSegment) {
        return new CrossBorder()
                .setAddress(Arrays.asList(responseRecordSegment.getEsc003uAdrBghx(), responseRecordSegment.getEsc003uPoNr(), responseRecordSegment.getEsc003uPostOrt()))
                .setBankCountry(responseRecordSegment.getEsc003uLandKod())
                .setChargePaidBy(StringUtils.isEmpty(responseRecordSegment.getEsc003uBetalare()) ? CrossBorderChargePaidBy.O.getChargePaidByPayment()
                        : CrossBorderChargePaidBy.valueOf(responseRecordSegment.getEsc003uBetalare()).getChargePaidByPayment())
                .setBic(responseRecordSegment.getEsc003uSwiftKod())
                .setBranchCode(responseRecordSegment.getEsc003uSortCode())
                .setCentralBankReportingCode(responseRecordSegment.getEsc003uRbKod())
                .setSepaReference(responseRecordSegment.getEsc003uSepaRef());
    }
}
