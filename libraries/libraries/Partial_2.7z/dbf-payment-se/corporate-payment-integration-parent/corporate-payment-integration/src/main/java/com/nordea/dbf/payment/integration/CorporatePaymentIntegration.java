package com.nordea.dbf.payment.integration;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.util.M8RequestResponseWrapper;
import com.nordea.dbf.payment.converters.request.*;
import com.nordea.dbf.payment.converters.response.*;
import com.nordea.dbf.payment.record.corporate.payment.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.util.Iterator;
import java.util.List;

/**
 * This is primarily a wrapper class to encapsulate the logic required to distinguish between CrossBorder / Domestic / Own-Transfer from the facade.
 */
public class CorporatePaymentIntegration {
    private static final Logger LOGGER = LoggerFactory.getLogger(CorporatePaymentIntegration.class);
    
    @Autowired
    private M8RequestResponseWrapper m8RequestResponseWrapper;

    /*
       Converters autowired below
     */
    @Autowired
    private PaymentFilterToGetConfirmedPaymentsRequest paymentFilterToGetConfirmedPaymentsRequest;
    @Autowired
    private PaymentFilterToGetRejectedPaymentsRequest paymentFilterToGetRejectedPaymentsRequest;
    @Autowired
    private PaymentFilterToGetUnconfirmedPaymentsRequest paymentFilterToGetUnconfirmedPaymentsRequest;
    @Autowired
    private PaymentToGetConfirmedPaymentDetailsRequest paymentToGetConfirmedPaymentDetailsRequest;
    @Autowired
    private PaymentToGetUnconfirmedPaymentDetailsRequest paymentToGetUnconfirmedPaymentDetailsRequest;
    @Autowired
    private PaymentToGetRejectedPaymentDetailsRequest paymentToGetRejectedPaymentDetailsRequest;
    @Autowired
    private GetConfirmedPaymentDetailsResponseRecordConverter getConfirmedPaymentDetailsResponseRecordConverter;
    @Autowired
    private GetUnconfirmedPaymentDetailsResponseRecordConverter getUnconfirmedPaymentDetailsResponseRecordConverter;
    @Autowired
    private GetRejectedPaymentDetailsResponseRecordConverter getRejectedPaymentDetailsResponseRecordConverter;
    @Autowired
    private GetConfirmedPaymentsResponseRecordConverter getConfirmedPaymentsResponseRecordConverter;
    @Autowired
    private GetRejectedPaymentsResponseRecordConverter getRejectedPaymentsResponseRecordConverter;
    @Autowired
    private GetUnconfirmedPaymentsResponseRecordConverter getUnconfirmedPaymentsResponseRecordConverter;
    @Autowired
    private PaymentToCreateCrossborderPaymentRequest paymentToCreateCrossborderPaymentRequest;
    @Autowired
    private CreateCrossborderPaymentResponseRecordConverter createCrossborderPaymentResponseRecordConverter;
    @Autowired
    private PaymentToCreatePaymentRequest paymentToCreatePaymentRequest;
    @Autowired
    private CreatePaymentResponseRecordConverter createPaymentResponseRecordConverter;
    @Autowired
    private PaymentToConfirmPaymentsRequest paymentToConfirmPaymentsRequest;
    @Autowired
    private ConfirmPaymentsResponseRecordConverter confirmPaymentsResponseRecordConverter;
    @Autowired
    private PaymentToChangeUnconfirmedPaymentRequest paymentToChangeUnconfirmedPaymentRequest;
    @Autowired
    private PaymentToChangeUnconfirmedCrossBorderPaymentRequest paymentToChangeUnconfirmedCrossBorderPaymentRequest;
    @Autowired
    private ChangeUnconfirmedPaymentResponseConverter changeUnconfirmedPaymentResponseConverter;
    @Autowired
    private ChangeUnconfirmedCrossBorderPaymentResponseConverter changeUnconfirmedCrossBorderPaymentResponseConverter;
    @Autowired
    private PaymentToDeletePaymentRequest paymentToDeletePaymentRequest;
    @Autowired
    private DeletePaymentResponseConverter deletePaymentResponseConverter;

    @HystrixCommand(groupKey = "JCA", commandKey = "getRejectedCorporatePaymets")
    public Observable<Payment> getRejectedPayments(M8ImsConnection connection, ServiceData serviceData, PaymentFilter paymentFilter) {
        GetRejectedPaymentsRequestRecord req = paymentFilterToGetRejectedPaymentsRequest.convert(serviceData, paymentFilter);
        return getRejectedPaymentsWithContinuation(connection, serviceData, req);
    }

    private Observable<Payment> getRejectedPaymentsWithContinuation(M8ImsConnection connection, ServiceData serviceData, GetRejectedPaymentsRequestRecord req) {
        if (req == null) {
            return Observable.empty();
        }
        return connection.execute(req, GetRejectedPaymentsResponseRecord.class)
            .flatMap(res -> {
            List<Payment> paymentList = getRejectedPaymentsResponseRecordConverter.convert(serviceData, res);
            if ("Y".equals(res.getMorerec())) {
                Iterator<GetRejectedPaymentsResponsePaymentsSegment> i = res.getPayments();
                String largestPaymentId = StringUtils.EMPTY;
                while (i.hasNext()) {
                    GetRejectedPaymentsResponsePaymentsSegment segment = i.next();
                    largestPaymentId = largestPaymentId.compareTo(segment.getEsc016uTid()) < 0 ? segment.getEsc016uTid() : largestPaymentId;
                }
                // TODO: Why is the continuation handled differently for rejected ?
                req.setTid(largestPaymentId);
                return Observable.from(paymentList).mergeWith(getRejectedPaymentsWithContinuation(connection, serviceData, req));
            } else {
                return Observable.from(paymentList);
            }
        });
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getConfirmedCorporatePayments")
    public Observable<Payment> getConfirmedPayments(M8ImsConnection connection, ServiceData serviceData, PaymentFilter paymentFilter) {
        GetConfirmedPaymentsRequestRecord req = paymentFilterToGetConfirmedPaymentsRequest.convert(serviceData, paymentFilter);
        return getConfirmedPaymentsWithContinuation(connection, serviceData, req);
    }

    private Observable<Payment> getConfirmedPaymentsWithContinuation(M8ImsConnection connection, ServiceData serviceData, GetConfirmedPaymentsRequestRecord req) {
        if (req == null) {
            return Observable.empty();
        }
        return connection.execute(req, GetConfirmedPaymentsResponseRecord.class).flatMap(res -> {
            List<Payment> paymentList = getConfirmedPaymentsResponseRecordConverter.convert(serviceData, res);
            if ("Y".equals(res.getMorerec())) {
                Iterator<GetConfirmedPaymentsResponsePaymentsSegment> i = res.getPayments();
                while (i.hasNext()) {
                    GetConfirmedPaymentsResponsePaymentsSegment segment = i.next();
                    req.setAvsKtoForts(segment.getEsc006uAvsKto());
                    req.setValKodAvsForts(segment.getEsc006uValKodAvsKto());
                    req.setTid(segment.getEsc006uTid());
                }
                req.setIndexForts(res.getIndexFortUt());
                return Observable.from(paymentList).mergeWith(getConfirmedPaymentsWithContinuation(connection, serviceData, req));
            } else {
                return Observable.from(paymentList);
            }
        });
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getUnconfirmedCorporatePayments")
    public Observable<Payment> getUnconfirmedPayments(M8ImsConnection connection, ServiceData serviceData, PaymentFilter paymentFilter) {
        GetUnconfirmedPaymentsRequestRecord req = paymentFilterToGetUnconfirmedPaymentsRequest.convert(serviceData, paymentFilter);
        return getUnconfirmedPaymentsWithContinuation(connection, serviceData, req);
    }

    private Observable<Payment> getUnconfirmedPaymentsWithContinuation(M8ImsConnection connection, ServiceData serviceData, GetUnconfirmedPaymentsRequestRecord req) {
        if (req == null) {
            return Observable.empty();
        }
        return connection.execute(req, GetUnconfirmedPaymentsResponseRecord.class).flatMap(res -> {
            List<Payment> paymentList = getUnconfirmedPaymentsResponseRecordConverter.convert(serviceData, res);
            if ("Y".equals(res.getMorerec())) {
                Iterator<GetUnconfirmedPaymentsResponsePaymentsSegment> i = res.getPayments();
                while (i.hasNext()) {
                    GetUnconfirmedPaymentsResponsePaymentsSegment segment = i.next();
                    req.setAvsKtoForts(segment.getEsc003uAvsKto());
                    req.setValKodAvsKtoForts(segment.getEsc003uValKodAvsKto());
                    req.setTid(segment.getEsc003uTid());
                }
                req.setIndexForts(res.getIndexFortsUt());
                return Observable.from(paymentList).mergeWith(getUnconfirmedPaymentsWithContinuation(connection, serviceData, req));
            } else {
                return Observable.from(paymentList);
            }
        });
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getConfirmedCorporatePayment")
    public Observable<Payment> getConfirmedPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToGetConfirmedPaymentDetailsRequest, getConfirmedPaymentDetailsResponseRecordConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getUnconfirmedCorporatePayment")
    public Observable<Payment> getUnconfirmedPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToGetUnconfirmedPaymentDetailsRequest, getUnconfirmedPaymentDetailsResponseRecordConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getRejectedCorporatePayment")
    public Observable<Payment> getRejectedPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToGetRejectedPaymentDetailsRequest, getRejectedPaymentDetailsResponseRecordConverter, p -> {
            if (p != null && p.getId().equals(payment.getId())) {
                return p;
            } else {
                return null;
            }
        });
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "createCorporateDomesticPayment")
    public Observable<Payment> createCorporateDomesticPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToCreatePaymentRequest, createPaymentResponseRecordConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "createCorporateCrossBorderPayment")
    public Observable<Payment> createCorporateCrossBorderPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToCreateCrossborderPaymentRequest, createCrossborderPaymentResponseRecordConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "confirmCorporatePayment")
    public Observable<Payment> confirmCorporatePayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToConfirmPaymentsRequest, confirmPaymentsResponseRecordConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "changeCorporateCrossBorderPayment")
    public Observable<Payment> changeCorporateCrossBorderPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToChangeUnconfirmedCrossBorderPaymentRequest, changeUnconfirmedCrossBorderPaymentResponseConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "changeCorporateDomesticPayment")
    public Observable<Payment> changeCorporateDomesticPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToChangeUnconfirmedPaymentRequest, changeUnconfirmedPaymentResponseConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "deleteCorporatePayment")
    public Observable<Payment> deleteCorporatePayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToDeletePaymentRequest, deletePaymentResponseConverter);
    }
}
