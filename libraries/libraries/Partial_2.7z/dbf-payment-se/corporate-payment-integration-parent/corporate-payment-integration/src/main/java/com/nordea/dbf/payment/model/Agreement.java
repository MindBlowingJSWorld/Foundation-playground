package com.nordea.dbf.payment.model;

import org.apache.commons.lang.Validate;

import static com.nordea.dbf.logging.Logging.mask;

/**
 * TODO: Temporary model of a corporate agreement until the AA-team have a proper implementation we can integrate towards
 *
 */
public class Agreement {

    private String name;
    private String customer;
    private String agreement;

    public Agreement(String name, String customer, String agreement) {
        Validate.notEmpty(name, "name can't be null or empty");
        Validate.notEmpty(customer, "customer can't be null or empty");
        Validate.notEmpty(agreement, "agreement can't be null or empty");

        this.name = name;
        this.customer = customer;
        this.agreement = agreement;
    }

    public String getName() {
        return name;
    }

    public String getCustomer() {
        return customer;
    }

    public String getAgreement() {
        return agreement;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Agreement agreement1 = (Agreement) o;

        if (!name.equals(agreement1.name)) return false;
        if (!customer.equals(agreement1.customer)) return false;
        return agreement.equals(agreement1.agreement);

    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + customer.hashCode();
        result = 31 * result + agreement.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Agreement{" +
                "name='" + name + '\'' +
                ", customer='" + mask(customer) + '\'' +
                ", agreement='" + agreement + '\'' +
                '}';
    }
}
