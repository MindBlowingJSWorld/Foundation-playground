package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.accountkey.*;
import org.apache.commons.validator.routines.checkdigit.IBANCheckDigit;

import java.util.Optional;

public class CorporateAccountKeyCreator {

    private static final IBANCheckDigit IBAN_VALIDATOR = new IBANCheckDigit();

    public static String createFromAccountKey(long accountNumber, String currencyCode) {
        return new NordeaAccountKey(new AccountNumber(String.valueOf(accountNumber)), currencyCode, "SE").toString();
    }

    public static AccountKey createToAccountKey(String legacySubType, String accountNumber, String accountCurrencyCode) {
        return createToAccountKey(legacySubType, accountNumber, accountCurrencyCode, Optional.empty());
    }

    public static AccountKey createToAccountKey(String legacySubType, String accountNumber, String accountCurrencyCode, Optional<String> bicCode) {
        final LegacyPaymentType legacyPaymentType = LegacyPaymentType.fromCode(legacySubType);
        switch (legacyPaymentType) {
            case PG:
                return new PgAccountKey(getAccountNumberWithoutNonNumericCharacters(accountNumber));
            case BG:
                return new BgAccountKey(getAccountNumberWithoutNonNumericCharacters(accountNumber));
            case NORDEA_ACCOUNT:
                return new NordeaAccountKey(getAccountNumberWithoutNonNumericCharacters(accountNumber), accountCurrencyCode, "SE");
            case EXTERNAL_TRANSFER:
            case SALARY:
            case PENSION:
                return new ExternalAccountKey("SE", getAccountNumberWithoutNonNumericCharacters(accountNumber));
            case CROSS_BORDER:
                if (IBAN_VALIDATOR.isValid(accountNumber.replaceAll("\\s", "").replaceAll("-", "")) && bicCode.isPresent() && !bicCode.get().isEmpty()) {
                    return new SepaAccountKey(bicCode.get(), new AccountNumber(accountNumber));
                } else {
                    return new CrossBorderAccountKey(new AccountNumber(accountNumber));
                }
            default:
                throw new UnsupportedOperationException("Payment type not supported");
        }
    }

    protected static AccountNumber getAccountNumberWithoutNonNumericCharacters(String rawString) {
        return new AccountNumber(rawString.replaceAll("\\s|-|\\.", ""));
    }
}
