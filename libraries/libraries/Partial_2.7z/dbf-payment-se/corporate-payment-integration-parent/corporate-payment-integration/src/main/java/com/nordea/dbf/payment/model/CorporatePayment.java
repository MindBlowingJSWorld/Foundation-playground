package com.nordea.dbf.payment.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * Created by K306010 on 2016-03-17.
 *
 * A set of shared constants.
 */
public class CorporatePayment {

    private static DateTimeFormatter YYYY_MM_DD = DateTimeFormatter.ISO_LOCAL_DATE;
    private static DateTimeFormatter YYYYMMDD = DateTimeFormatter.BASIC_ISO_DATE;
    private static DateTimeFormatter YY_MM_DD = DateTimeFormatter.ofPattern("yy-MM-dd");
    private static DateTimeFormatter YYMMDD = DateTimeFormatter.ofPattern("yyMMdd");

    public static String formatAsDate(LocalDate localDate) {
        return localDate != null ? YYYY_MM_DD.format(localDate) : "";
    }

    public static String formatAsDateWithoutDelimters(LocalDate localDate) {
        return localDate != null ? YYYYMMDD.format(localDate) : "";
    }

    public static String formatAsDateWithoutCentury(LocalDate localDate) {
        return localDate != null ? YY_MM_DD.format(localDate) : "";
    }

    public static String formatAsDateWithoutCenturyAndNoDelimiters(LocalDate localDate) {
        return localDate != null ? YYMMDD.format(localDate) : "";
    }
}
