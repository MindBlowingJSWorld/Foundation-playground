package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountPrefixType;

import java.util.Optional;

/**
 * Representation of the legacy backend's different corporate payment types
 */
public enum CorporatePaymentType {

    ACCOUNT("EB", Optional.of(AccountPrefixType.LBAN), Optional.of(Payment.TypeEnum.lban)),
    // FIXME: Verify that the account is infact NB. Compare with LegacyPaymentType
    ACCOUNT_NORDEA("NA", Optional.of(AccountPrefixType.NAID), Optional.of(Payment.TypeEnum.lban)),
    BANKGIRO("BG", Optional.of(AccountPrefixType.BG), Optional.of(Payment.TypeEnum.bankgiro)),
    CROSSBORDER_SEPA("CB", Optional.of(AccountPrefixType.IBAN), Optional.of(Payment.TypeEnum.crossborder)),
    CROSSBORDER_NON_SEPA("CB", Optional.of(AccountPrefixType.CROSSBORDER), Optional.of(Payment.TypeEnum.crossborder)),
    MONEYORDER("UK", Optional.empty(), Optional.empty()),
    PENSION("PE", Optional.of(AccountPrefixType.LBAN), Optional.of(Payment.TypeEnum.pension)),
    PLUSGIRO("PG", Optional.of(AccountPrefixType.PG), Optional.of(Payment.TypeEnum.plusgiro)),
    SALARY("LO", Optional.of(AccountPrefixType.LBAN), Optional.of(Payment.TypeEnum.salary)),
    CROSSBORDERMONEYORDER("CK", Optional.empty(), Optional.of(Payment.TypeEnum.crossborder));

    private final String legacyCode;
    private final Optional<AccountPrefixType> accountPrefixType;
    private final Optional<Payment.TypeEnum> paymentType;

    CorporatePaymentType(String legacyCode, Optional<AccountPrefixType> accountPrefixType, Optional<Payment.TypeEnum> paymentType) {
        this.legacyCode = legacyCode;
        this.accountPrefixType = accountPrefixType;
        this.paymentType = paymentType;
    }

    public String getLegacyCode() {
        return legacyCode;
    }

    public Optional<AccountPrefixType> getAccountPrefixType() {
        return accountPrefixType;
    }

    public Optional<Payment.TypeEnum> getPaymentType() {
        return paymentType;
    }

    public static Optional<CorporatePaymentType> convertToPaymentType(AccountPrefixType accountPrefixType) {
        for (CorporatePaymentType paymentType : CorporatePaymentType.values()) {
            if (paymentType.getAccountPrefixType().isPresent() && paymentType.getAccountPrefixType().get().equals(accountPrefixType)) {
                return Optional.of(paymentType);
            }
        }
        return Optional.empty();
    }

    public static Payment.TypeEnum fromLegacyCode(String legacyCode, AccountPrefixType accountPrefixType) {
        for (CorporatePaymentType paymentType : CorporatePaymentType.values()) {
            final Optional<AccountPrefixType> paymentTypeAccountPrefixType = paymentType.getAccountPrefixType();
            if (paymentType.getLegacyCode().equals(legacyCode) && paymentTypeAccountPrefixType.isPresent() && paymentTypeAccountPrefixType.get().equals(accountPrefixType)) {
                return paymentType.getPaymentType().get();
            }
        }
        throw new IllegalArgumentException("Legacy payment type code " + legacyCode + " is not supported.");
    }

}
