package com.nordea.dbf.payment.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CorporateTimeConverter {

    public static final DateTimeFormatter CORPORATE_PAYMENT_TIME_STAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");

    public static LocalDateTime convertTimestamp(String corporateTimeStamp) {
        return LocalDateTime.parse(corporateTimeStamp, CORPORATE_PAYMENT_TIME_STAMP_FORMATTER);
    }


}
