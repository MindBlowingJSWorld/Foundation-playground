package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.CrossBorder;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum CrossBorderChargePaidBy {

    B(CrossBorder.ChargePaidByEnum.shared, CrossBorder.ChargePaidByEnum.shared),
    O(CrossBorder.ChargePaidByEnum.payer, CrossBorder.ChargePaidByEnum.payer);

    private static final Map<CrossBorder.ChargePaidByEnum, CrossBorderChargePaidBy> LOOKUP = new HashMap<>();
    private final CrossBorder.ChargePaidByEnum chargePaidByPaymentRequest;
    private final CrossBorder.ChargePaidByEnum chargePaidByPayment;

    static {
        for (CrossBorderChargePaidBy crossBorderChargePaidBy : EnumSet.allOf(CrossBorderChargePaidBy.class)) {
            LOOKUP.put(crossBorderChargePaidBy.getChargePaidByPaymentRequest(), crossBorderChargePaidBy);
        }
    }

    CrossBorderChargePaidBy(CrossBorder.ChargePaidByEnum chargePaidByPaymentRequest, CrossBorder.ChargePaidByEnum chargePaidByPayment) {
        this.chargePaidByPayment = chargePaidByPayment;
        this.chargePaidByPaymentRequest = chargePaidByPaymentRequest;
    }

    public CrossBorder.ChargePaidByEnum getChargePaidByPaymentRequest() {
        return chargePaidByPaymentRequest;
    }

    public CrossBorder.ChargePaidByEnum getChargePaidByPayment() {
        return chargePaidByPayment;
    }


    public static CrossBorderChargePaidBy get(CrossBorder.ChargePaidByEnum chargePaidByEnum) {
        final CrossBorderChargePaidBy crossBorderChargePaidBy = LOOKUP.get(chargePaidByEnum);
        if (crossBorderChargePaidBy != null) {
            return crossBorderChargePaidBy;
        } else {
            throw new IllegalArgumentException("shared and payer are the only supported charge paid by types for corporate cross border payments.");
        }
    }
}
