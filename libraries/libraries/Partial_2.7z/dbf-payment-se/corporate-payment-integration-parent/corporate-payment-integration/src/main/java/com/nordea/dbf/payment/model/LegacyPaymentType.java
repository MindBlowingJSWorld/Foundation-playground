package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.Payment;
import org.apache.commons.lang.Validate;

public enum LegacyPaymentType {

    PG("PG", Payment.TypeEnum.plusgiro),
    BG("BG", Payment.TypeEnum.bankgiro),
    NORDEA_ACCOUNT("NA", Payment.TypeEnum.lban),
    EXTERNAL_TRANSFER("EB", Payment.TypeEnum.lban),
    CROSS_BORDER("CB", Payment.TypeEnum.crossborder),
    SALARY("LO", Payment.TypeEnum.salary),
    PENSION("PE", Payment.TypeEnum.pension);

    private final String code;
    private final Payment.TypeEnum paymentType;

    LegacyPaymentType(String code, Payment.TypeEnum plusgiro) {
        this.code = code;
        paymentType = plusgiro;
    }

    public String code() {
        return code;
    }

    public Payment.TypeEnum toPaymentType() {
        return paymentType;
    }

    public static LegacyPaymentType fromCode(String code) {
        Validate.notNull(code, "code can't be null");

        for (final LegacyPaymentType type : values()) {
            if (type.code().equals(code)) {
                return type;
            }
        }
        return null;
    }

    public static String codeFromPaymentType(Payment.TypeEnum type) {

        for (LegacyPaymentType legacyPaymentType : values()) {
            if (legacyPaymentType.paymentType.equals(type)) {
                return legacyPaymentType.code();
            }
        }
        throw new IllegalArgumentException("Invalid Corporate payment type  '" + type + "'");
    }
}
