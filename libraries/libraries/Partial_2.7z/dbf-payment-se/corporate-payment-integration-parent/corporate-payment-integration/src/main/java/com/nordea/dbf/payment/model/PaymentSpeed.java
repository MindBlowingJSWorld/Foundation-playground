package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.Payment;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum PaymentSpeed {

    N(Payment.SpeedEnum.normal),
    E(Payment.SpeedEnum.express);

    private static final Map<Payment.SpeedEnum, PaymentSpeed> LOOKUP = new HashMap<>();

    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentSpeed.class);
    private final Payment.SpeedEnum paymentSpeed;

    static {
        for (PaymentSpeed crossBorderPaymentSpeed : EnumSet.allOf(PaymentSpeed.class)) {
            LOOKUP.put(crossBorderPaymentSpeed.getPaymentSpeed(), crossBorderPaymentSpeed);
        }
    }

    PaymentSpeed(Payment.SpeedEnum PaymentSpeed) {
        this.paymentSpeed = PaymentSpeed;
    }

    public Payment.SpeedEnum getPaymentSpeed() {
        return paymentSpeed;
    }

    public static PaymentSpeed get(Payment.SpeedEnum PaymentSpeed) {
        return LOOKUP.get(PaymentSpeed);
    }

    public static Payment.SpeedEnum fromCode(String code) {
        if (code.isEmpty()){
            return Payment.SpeedEnum.normal;
        }
        for (PaymentSpeed paymentSpeed : PaymentSpeed.values()) {
            if (paymentSpeed.name().equals(code)) {
                return paymentSpeed.paymentSpeed;
            }
        }
        LOGGER.error("Could not map speed code " + code);
        return null;
    }

}
