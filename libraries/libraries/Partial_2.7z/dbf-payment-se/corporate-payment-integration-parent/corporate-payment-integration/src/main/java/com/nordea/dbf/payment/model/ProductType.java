package com.nordea.dbf.payment.model;

/**
 * The main categories of corporate products
 *
 */
public enum ProductType {
  Account, Loan, Card
}
