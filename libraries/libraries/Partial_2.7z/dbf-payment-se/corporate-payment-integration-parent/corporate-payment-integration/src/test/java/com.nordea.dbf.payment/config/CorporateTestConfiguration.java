package com.nordea.dbf.payment.config;

import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.payment.CorporatePaymentFacade;
import com.nordea.dbf.payment.common.PaymentFacade;
import com.nordea.dbf.payment.common.converters.BackendErrorCode;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.integrationtests.CorporateTestDataManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.*;

import java.util.Optional;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Configuration
@ComponentScan(basePackages = "com.nordea.dbf.payment", excludeFilters = @ComponentScan.Filter(type = FilterType.ANNOTATION, value = Configuration.class))
public class CorporateTestConfiguration {

    @Bean
    @Primary
    @Qualifier("corporateErrorHandler")
    public BackendErrorHandler corporateErrorHandler() {
        return new BackendErrorHandler() {
            @Override
            public <T extends ErrorResponse> Optional<T> exceptionOf(int kbearb, int krc) {
                if (kbearb < 1 && krc < 1) {
                    return Optional.empty();
                }
                return Optional.of(((T) BackendErrorCode.getException(kbearb, krc)));
            }
        };
    }

    @Bean
    @Autowired
    @Primary
    public M8ImsConnector m8ImsConnector(M8ImsConnection m8ImsConnection) {
        M8ImsConnector m8ImsConnector = mock(M8ImsConnector.class);
        when(m8ImsConnector.connect()).thenReturn(m8ImsConnection);
        return m8ImsConnector;
    }

    @Bean
    @Primary
    public M8ImsConnection m8ImsConnection() {
        return mock(M8ImsConnection.class);
    }

    @Bean
    @Primary
    @Qualifier("corporatePaymentFacade")
    public PaymentFacade corporatePaymentFacade() {
        return new CorporatePaymentFacade();
    }

    @Bean
    public CorporateTestDataManager corporateTestDataManager() {
        return new CorporateTestDataManager();
    }

    @Bean
    public NilRequestMsgHeaders nilRequestMsgHeaders() {
        return new NilRequestMsgHeaders();
    }
}
