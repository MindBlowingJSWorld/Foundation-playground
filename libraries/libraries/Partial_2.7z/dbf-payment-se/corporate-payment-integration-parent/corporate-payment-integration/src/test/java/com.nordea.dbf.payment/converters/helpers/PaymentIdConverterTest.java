package com.nordea.dbf.payment.converters.helpers;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.unWrapId;
import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.wrapId;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class PaymentIdConverterTest {

    @Test
    public void shouldWrapId() {
        // Given
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setId("2015-09-20-15.39.53.563933");

        // When
        payment = wrapId(payment);

        // Then
        assertEquals("2015-09-20-15.39.53.563933:SEK:1940080100", payment.getId());
    }

    @Test
    public void shouldUnwrapId() {
        // Given
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setId("2015-09-20-15.39.53.563933:SEK:1940080100");
        payment.setFrom(null);

        // When
        payment = unWrapId(payment);

        // Then
        assertEquals("NAID-SE-SEK-1940080100", payment.getFrom());
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowIllegalArgumentException() {
        // Given
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.BG_ACCOUNT);

        // When
        unWrapId(payment);

        fail("IllegalArgumentException should have been thrown");
    }
}
