package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.GetConfirmedPaymentsRequestAccountsSegment;
import com.nordea.dbf.payment.record.corporate.payment.GetConfirmedPaymentsRequestRecord;
import com.nordea.dbf.payment.testdata.TestData;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.LinkedList;
import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentFilterToGetConfirmedPaymentsRequestTest {

    private static final long AVS_KTO_FORTS = 0L;
    private static final long INDEX_FORTS = 0L;
    private static final String FILTER_TO_GET_CONFIRMED_PAYMENTS_REQUEST_TRANSACTION_CODE = "ESC006";
    private PaymentFilterToGetConfirmedPaymentsRequest paymentsRequest;
    private String userId;

    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private ServiceData serviceData;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        String agreementOwner = "AO1234567890";
        paymentsRequest = new PaymentFilterToGetConfirmedPaymentsRequest(nilRequestMsgHeadersMock);
        userId = "1234567890";

        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new GetConfirmedPaymentsRequestRecord());

        serviceData = new ServiceData(serviceRequestContextMock, agreementOwner, "123", "corporate");
    }

    @Test
    public void shouldMapFullRequest() {
        PaymentFilter paymentFilter = new PaymentFilter();
        LinkedList<AccountKey> accountKeys = new LinkedList<>();
        accountKeys.add(TestData.BG_ACCOUNT);
        accountKeys.add(TestData.BG_ACCOUNT);
        accountKeys.add(TestData.BG_ACCOUNT);
        paymentFilter.setFromAccounts(new ListFilter<>(accountKeys));

        GetConfirmedPaymentsRequestRecord returnValue =
                paymentsRequest.convert(serviceData, paymentFilter);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(FILTER_TO_GET_CONFIRMED_PAYMENTS_REQUEST_TRANSACTION_CODE));
        assertThat("AvsKtoForts is not correct", returnValue.getAvsKtoForts(),
                is(AVS_KTO_FORTS));
        assertThat("IndexForts is not correct", returnValue.getIndexForts(),
                is(INDEX_FORTS));
        assertThat("Tid is not correct", returnValue.getTid(),
                is(StringUtils.EMPTY));
        assertThat("UserId is not correct", returnValue.getUserId(),
                is(userId));
        assertThat("AnvId is not correct", returnValue.getAnvId(),
                is(Long.parseLong(userId)));
        assertThat("AgreementHolderId is not correct", returnValue.getAgreementHolderId(),
                is(Long.parseLong(serviceData.getAgreementOwner().substring(2, 12))));
        assertThat("TechId is not correct", returnValue.getTechId(),
                is("123"));

        returnValue.getAccounts().forEachRemaining(obj -> {
            GetConfirmedPaymentsRequestAccountsSegment returnSegment =
                    (GetConfirmedPaymentsRequestAccountsSegment) obj;
            assertThat("AvsKonto is not correct", returnSegment.getAvsKonto(),
                    is(Long.parseLong(TestData.BG_ACCOUNT.getAccountNumber().getAccountNumber())));
            assertThat("ValKodAvsKto is not correct", returnSegment.getValKodAvsKto(),
                    is(""));
        });
    }

    @Test
    public void shouldGetEmptyObservable() {
        PaymentFilter paymentFilter = new PaymentFilter();
        LinkedList<String> statuses = new LinkedList<>();
        statuses.add(Payment.StatusEnum.unconfirmed.toString());
        paymentFilter.setStatuses(statuses);

        GetConfirmedPaymentsRequestRecord req =
                paymentsRequest.convert(serviceData, paymentFilter);

        assertNull("Converted request returned should be null", req);
    }

    @Test
    public void shouldGetRealCurrencyCode() {
        PaymentFilter paymentFilter = new PaymentFilter();
        LinkedList<AccountKey> accountKeys = new LinkedList<>();
        accountKeys.add(TestData.NORDEA_ACCOUNT_KEY);
        paymentFilter.setFromAccounts(new ListFilter<>(accountKeys));

        GetConfirmedPaymentsRequestRecord returnValue =
                paymentsRequest.convert(serviceData, paymentFilter);

        GetConfirmedPaymentsRequestAccountsSegment returnSegment =
                (GetConfirmedPaymentsRequestAccountsSegment) returnValue.getAccounts().next();
        assertThat("ValKodAvsKto is not correct", returnSegment.getValKodAvsKto(),
                is(TestData.NORDEA_ACCOUNT_KEY.getCurrencyCode().get()));
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowNullPointerException() {
        PaymentFilter paymentFilter = new PaymentFilter();

        GetConfirmedPaymentsRequestRecord returnValue =
                paymentsRequest.convert(serviceData, paymentFilter);

        returnValue.getAccounts();
        fail("NullPointerException should have been thrown");
    }
}
