package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.GetRejectedPaymentsRequestAccountsSegment;
import com.nordea.dbf.payment.record.corporate.payment.GetRejectedPaymentsRequestRecord;
import com.nordea.dbf.payment.testdata.TestData;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;

import java.util.LinkedList;
import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentFilterToGetRejectedPaymentsRequestTest {

    private static final String GET_REJECTED_PAYMENTS_REQUEST_TRANSACTION_CODE = "ESC016";
    private PaymentFilterToGetRejectedPaymentsRequest paymentsRequest;
    private String userId;

    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private ServiceData serviceData;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        String agreementOwner = "AO1234567890";
        paymentsRequest = new PaymentFilterToGetRejectedPaymentsRequest(nilRequestMsgHeadersMock);
        userId = "1234567890";

        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new GetRejectedPaymentsRequestRecord());

        serviceData = new ServiceData(serviceRequestContextMock, agreementOwner, "123", "corporate");
    }

    @Test
    public void shouldMapFullRequest() {
        PaymentFilter paymentFilter = new PaymentFilter();
        LinkedList<AccountKey> accountKeys = new LinkedList<>();
        accountKeys.add(TestData.BG_ACCOUNT);
        accountKeys.add(TestData.BG_ACCOUNT);
        accountKeys.add(TestData.BG_ACCOUNT);
        paymentFilter.setFromAccounts(new ListFilter<>(accountKeys));

        GetRejectedPaymentsRequestRecord returnValue =
                paymentsRequest.convert(serviceData, paymentFilter);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(GET_REJECTED_PAYMENTS_REQUEST_TRANSACTION_CODE));
        assertThat("Tid is not correct", returnValue.getTid(),
                is(StringUtils.EMPTY));
        assertThat("UserId is not correct", returnValue.getUserId(),
                is(userId));
        assertThat("AgreementHolderId is not correct", returnValue.getAgreementHolderId(),
                is(Long.parseLong(serviceData.getAgreementOwner().substring(2, 12))));
        assertThat("TechId is not correct", returnValue.getTechId(),
                is("123"));

        returnValue.getAccounts().forEachRemaining(obj -> {
            GetRejectedPaymentsRequestAccountsSegment returnSegment =
                    (GetRejectedPaymentsRequestAccountsSegment) obj;
            assertThat("PgKtoNr is not correct", returnSegment.getPgKtoNr(),
                    is(Long.parseLong(TestData.BG_ACCOUNT.getAccountNumber().getAccountNumber())));
        });
    }

    @Test
    public void shouldGetEmptyObservable() {
        PaymentFilter paymentFilter = new PaymentFilter();
        LinkedList<String> statuses = new LinkedList<>();
        statuses.add(Payment.StatusEnum.confirmed.toString());
        paymentFilter.setStatuses(statuses);

        GetRejectedPaymentsRequestRecord req =
                paymentsRequest.convert(serviceData, paymentFilter);

        assertNull("Request returned should be null", req);
    }

    @Test(expected = NullPointerException.class)
    public void shouldThrowNullPointerException() {
        PaymentFilter paymentFilter = new PaymentFilter();

        GetRejectedPaymentsRequestRecord returnValue =
                paymentsRequest.convert(serviceData, paymentFilter);

        returnValue.getAccounts();
        fail("NullPointerException should have been thrown");
    }
}
