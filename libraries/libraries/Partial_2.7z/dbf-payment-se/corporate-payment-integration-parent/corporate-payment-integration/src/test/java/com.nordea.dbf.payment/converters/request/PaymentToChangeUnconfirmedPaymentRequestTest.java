package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.model.CorporatePayment;
import com.nordea.dbf.payment.model.LegacyPaymentType;
import com.nordea.dbf.payment.record.corporate.payment.ChangeUnconfirmedPaymentRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;

import java.text.DecimalFormat;
import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToChangeUnconfirmedPaymentRequestTest {

    private static final String CHANGE_UNCONFIRMED_PAYMENT_REQUEST_TRANSACTION_CODE = "ESC020";
    private static final String IN_ADD_RECIP = "N";
    private static final String IN_MOTT_NAMN = "";
    private static final String EMPTY_STRING = "";
    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.##");
    private String agreementOwner = "AO1234567890";
    String userId = "UI1234567890";
    private PaymentToChangeUnconfirmedPaymentRequest paymentToChangeUnconfirmedPaymentRequest;

    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
    private ServiceData serviceData;

    @Before
    public void init() {
        PaymentValidator paymentValidatorMock = mock(PaymentValidator.class);
        paymentToChangeUnconfirmedPaymentRequest =
                new PaymentToChangeUnconfirmedPaymentRequest(nilRequestMsgHeadersMock);

        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(ServiceRequestContext.class),
                any(ChangeUnconfirmedPaymentRequestRecord.class)))
                .thenReturn(new ChangeUnconfirmedPaymentRequestRecord());
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));

        serviceData = new ServiceData(serviceRequestContextMock, agreementOwner, "123", "corporate");
    }

    @Test
    public void shouldMapFullRequest() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.PG_ACCOUNT_KEY, TestData.PG_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.bankgiro);

        ChangeUnconfirmedPaymentRequestRecord returnValue =
                paymentToChangeUnconfirmedPaymentRequest
                        .convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(CHANGE_UNCONFIRMED_PAYMENT_REQUEST_TRANSACTION_CODE));
        assertThat("InAgreementHolderId is not correct", returnValue.getInAgreementHolderId(),
                is(Long.parseLong(agreementOwner.substring(2, 12))));
        assertThat("TechId is not correct", returnValue.getInTechId(),
                is("123"));
        assertThat("InTidChangePay is not correct", returnValue.getInTidChangePay(),
                is(payment.getId()));
        assertThat("InAnvId is not correct", returnValue.getInAnvId(),
                is(userId.substring(2, 12)));
        assertThat("InAvsKto is not correct", returnValue.getInAvsKto(),
                is(Long.parseLong(TestData.PG_ACCOUNT_KEY.getAccountNumber().getAccountNumber())));
        assertThat("InFicka is not correct", returnValue.getInFicka(),
                is(EMPTY_STRING));
        assertThat("InMottKto is not correct", returnValue.getInMottKto(),
                is(TestData.PG_ACCOUNT_KEY.getAccountNumber().getAccountNumber()));
        assertThat("InBel is not correct", returnValue.getInBel(),
                is(DECIMAL_FORMAT.format(payment.getAmount().doubleValue()).replace(".", ",")));
        assertThat("InValKod is not correct", returnValue.getInValKod(),
                is(payment.getCurrency()));
        assertThat("InBegartBokfDat is not correct", returnValue.getInBegartBokfDat(),
                is(CorporatePayment.formatAsDateWithoutCentury(payment.getDue())));
        assertThat("InMottMed is not correct", returnValue.getInMottMed(),
                is(payment.getMessage()));
        assertThat("InRefVs is not correct", returnValue.getInRefVs(),
                is(payment.getOwnMessage()));
        assertThat("InTidChangePay is not correct", returnValue.getInTidChangePay(),
                is(payment.getId()));
        assertThat("InAddRecip is not correct", returnValue.getInAddRecip(),
                is(IN_ADD_RECIP));
        assertThat("InMottNamn is not correct", returnValue.getInMottNamn(),
                is(IN_MOTT_NAMN));
        assertThat("InPaySubtypeExt is not correct", returnValue.getInPaySubTypeExt(),
                is(LegacyPaymentType.codeFromPaymentType(payment.getType())));
    }

    @Test
    public void shouldMapEmptyCurrency() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.PG_ACCOUNT_KEY, TestData.PG_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.plusgiro);
        payment.setCurrency(null);

        ChangeUnconfirmedPaymentRequestRecord returnValue =
                paymentToChangeUnconfirmedPaymentRequest
                        .convert(serviceData, payment);

        assertThat("InValKod is not correct", returnValue.getInValKod(),
                is(""));
    }
}
