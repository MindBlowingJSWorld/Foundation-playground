package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.record.corporate.payment.ConfirmPaymentsRequestPaymentsSegment;
import com.nordea.dbf.payment.record.corporate.payment.ConfirmPaymentsRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToConfirmPaymentsRequestTest {

    private static final String CONFIRM_PAYMENTS_REQUEST_TRANSACTION_CODE = "ESC005";
    private static final String BET_KOD_CROSSBORDER = "U";
    private static final String BET_KOD_DOMESTIC = "I";
    private static final String CONFIRM_PAYMENTS_REQUEST_FILKLUMP_N = "N";
    private NilRequestMsgHeaders nilRequestMsgHeadersMock;
    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private String userId;
    private String agreementOwner;
    private ServiceData serviceData;

    @Before
    public void init() {
        nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        serviceRequestContextMock = mock(ServiceRequestContext.class);
        userId = "UI1234567890";
        agreementOwner = "1234567890";

        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new ConfirmPaymentsRequestRecord());
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));

        serviceData = new ServiceData(serviceRequestContextMock, agreementOwner, "123", "corporate");
    }

    @Test
    public void shouldMapFullRequest() {
        PaymentToConfirmPaymentsRequest paymentToConfirmPaymentsRequest = new PaymentToConfirmPaymentsRequest(nilRequestMsgHeadersMock);
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.NORDEA_ACCOUNT_KEY, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.normal);

        ConfirmPaymentsRequestRecord returnValue =
                paymentToConfirmPaymentsRequest.convert(serviceData, payment);


        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(CONFIRM_PAYMENTS_REQUEST_TRANSACTION_CODE));
        assertThat("AgreementHolderId is not correct", returnValue.getAgreementHolderId(),
                is(Long.parseLong(agreementOwner)));
        assertThat("TechId is not correct", returnValue.getInTechId(),
                is("123"));
        assertThat("InAnvandare is not correct", returnValue.getInAnvandare(),
                is(serviceRequestContextMock.getUserId().get()));
        assertThat("InAvsKto is not correct", returnValue.getInAvsKto(),
                is(TestData.NORDEA_ACCOUNT_KEY.getAccountNumber().getAccountNumber()));
        assertThat("InFicka is not correct", returnValue.getInFicka(),
                is(payment.getCurrency()));
        assertThat("InBetKod is not correct", returnValue.getInBetKod(),
                is(BET_KOD_DOMESTIC));
        ConfirmPaymentsRequestPaymentsSegment paymentSegment = (ConfirmPaymentsRequestPaymentsSegment) returnValue.getPayments().next();
        assertThat("PaymentSegment InTidSign is not correct", paymentSegment.getInTidSign(),
                is(payment.getId()));
        assertThat("PaymentSegment InYOmDetEEnFilKlump is not correct", paymentSegment.getInYOmDetEEnFilKlump(),
                is(CONFIRM_PAYMENTS_REQUEST_FILKLUMP_N));
    }

    @Test
    public void shouldMapInBetKodToCrossborder() {
        PaymentToConfirmPaymentsRequest paymentToConfirmPaymentsRequest = new PaymentToConfirmPaymentsRequest(nilRequestMsgHeadersMock);
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.NORDEA_ACCOUNT_KEY, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.crossborder);

        ConfirmPaymentsRequestRecord returnValue =
                paymentToConfirmPaymentsRequest.convert(serviceData, payment);

        assertThat("InBetKod is not correct", returnValue.getInBetKod(),
                is(BET_KOD_CROSSBORDER));
    }

    @Test
    public void shouldMapEmptyCurrency() {
        PaymentToConfirmPaymentsRequest paymentToConfirmPaymentsRequest = new PaymentToConfirmPaymentsRequest(nilRequestMsgHeadersMock);
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.NORDEA_ACCOUNT_NAID, TestData.PG_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.plusgiro);
        payment.setCurrency(null);

        ConfirmPaymentsRequestRecord returnValue =
                paymentToConfirmPaymentsRequest
                        .convert(serviceData, payment);

        assertThat("InValKod is not correct", returnValue.getInFicka(),
                is(TestData.NORDEA_ACCOUNT_NAID.getCurrencyCode().get()));
    }
}
