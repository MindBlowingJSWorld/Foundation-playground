package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.model.CorporatePayment;
import com.nordea.dbf.payment.model.CorporatePaymentType;
import com.nordea.dbf.payment.model.CrossBorderChargePaidBy;
import com.nordea.dbf.payment.model.PaymentSpeed;
import com.nordea.dbf.payment.record.corporate.payment.CreateCrossborderPaymentRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToCreateCrossBorderPaymentRequestTest {

    private static final String CREATE_CROSS_BORDER_PAYMENT_REQUEST_TRANSACTION_CODE = "ESC001";
    private static final String EMPTY_STRING = StringUtils.EMPTY;
    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.##");

    private PaymentToCreateCrossborderPaymentRequest paymentToCreateCrossborderPaymentRequest;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        paymentToCreateCrossborderPaymentRequest = new PaymentToCreateCrossborderPaymentRequest(nilRequestMsgHeadersMock);
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(ServiceRequestContext.class),
                any(CreateCrossborderPaymentRequestRecord.class)))
                .thenReturn(new CreateCrossborderPaymentRequestRecord());
    }

    @Test
    public void shouldMapFull() {
        ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
        AccountKey fromAccountKey = TestData.NORDEA_ACCOUNT_KEY;
        AccountKey toAccountKey = TestData.CROSS_BORDER_ACCOUNT_KEY;
        Payment payment = PaymentTestData.getUnconfirmedPayment(fromAccountKey, toAccountKey);

        CrossBorder crossBorderMock = mock(CrossBorder.class);
        payment.setCrossBorder(crossBorderMock);

        String agreementOwner = "AO1234567890";

        String userId = "UI1234567890";
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));

        ServiceData serviceData = new ServiceData(serviceRequestContextMock, agreementOwner, "123", "corporate");

        String bic = "Bic";
        when(crossBorderMock.getBic()).thenReturn(bic);
        String bankCountry = "SE";
        when(crossBorderMock.getBankCountry()).thenReturn(bankCountry);
        String branchCode = "BranchCode";
        when(crossBorderMock.getBranchCode()).thenReturn(branchCode);

        String bankName = "BankName";
        when(crossBorderMock.getBankName()).thenReturn(bankName);

        String firstRow = "First row";
        String secondRow = "Second row";
        String thirdRow = "Third row";
        List<String> adressList = Arrays.asList(firstRow, secondRow, thirdRow);
        when(crossBorderMock.getAddress()).thenReturn(adressList);

        payment.setSpeed(Payment.SpeedEnum.express);

        CrossBorder.ChargePaidByEnum chargePaidBy = CrossBorder.ChargePaidByEnum.payer;
        when(crossBorderMock.getChargePaidBy()).thenReturn(chargePaidBy);
        String centralBankReportingCode = "CBR";
        when(crossBorderMock.getCentralBankReportingCode()).thenReturn(centralBankReportingCode);

        String sepaReference = "SepaReference";
        when(crossBorderMock.getSepaReference()).thenReturn(sepaReference);

        CreateCrossborderPaymentRequestRecord returnValue =
                paymentToCreateCrossborderPaymentRequest
                        .convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(CREATE_CROSS_BORDER_PAYMENT_REQUEST_TRANSACTION_CODE));
        assertThat("InAgreementHolderId is not correct", returnValue.getInAgreementHolderId(),
                is(Long.parseLong(agreementOwner.substring(2, 12))));
        assertThat("TechId is not correct", returnValue.getInTechId(),
                is("123"));
        assertThat("InAnvId is not correct", returnValue.getInAnvId(),
                is(Long.parseLong(userId.substring(2, 12))));
        assertThat("InAvsKto is not correct", returnValue.getInAvsKto(),
                is(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber())));
        assertThat("InFicka is not correct", returnValue.getInFicka(),
                is(TestData.NORDEA_ACCOUNT_KEY.getCurrencyCode().get()));
        assertThat("InMottKto is not correct", returnValue.getInMottKto(),
                is(toAccountKey.getAccountNumber().getAccountNumber()));
        assertThat("InSwiftKod is not correct", returnValue.getInSwiftKod(),
                is(bic));
        assertThat("InLandKod is not correct", returnValue.getInLandKod(),
                is(bankCountry));
        assertThat("InSortCode is not correct", returnValue.getInSortCode(),
                is(branchCode));
        assertThat("InUadr is not correct", returnValue.getInUadr(),
                is(EMPTY_STRING));
        assertThat("InUadr2 is not correct", returnValue.getInUadr2(),
                is(EMPTY_STRING));
        assertThat("InBankNamn is not correct", returnValue.getInBankNamn(),
                is(bankName));
        assertThat("InAdrBgxh1 is not correct", returnValue.getInAdrBgxh1(),
                is(firstRow));
        assertThat("InAdrBgxh2 is not correct", returnValue.getInAdrBgxh2(),
                is(secondRow));
        assertThat("InAdrBgxh3 is not correct", returnValue.getInAdrBgxh3(),
                is(thirdRow));
        assertThat("InBel is not correct", returnValue.getInBel(),
                is(DECIMAL_FORMAT.format(payment.getAmount().doubleValue()).replace(".", ",")));
        assertThat("InValKod is not correct", returnValue.getInValKod(),
                is(payment.getCurrency()));
        assertThat("InBegartBokfDat is not correct", returnValue.getInBegartBokfDat(),
                is(CorporatePayment.formatAsDateWithoutCentury(payment.getDue())));
        assertThat("InMottMed is not correct", returnValue.getInMottMed(),
                is(payment.getMessage()));
        assertThat("InEffTyp is not correct", returnValue.getInEffTyp(),
                is(PaymentSpeed.get(payment.getSpeed()).toString()));
        assertThat("InBetalare is not correct", returnValue.getInBetalare(),
                is(CrossBorderChargePaidBy.get(chargePaidBy).toString()));
        assertThat("InRbKod is not correct", returnValue.getInRbkod(),
                is(centralBankReportingCode));
        assertThat("InSepa is not correct", returnValue.getInSepa(),
                is(sepaReference));
        assertThat("InPaySubTpeExt is not correct", returnValue.getPaySubTypeExt(),
                is(CorporatePaymentType.CROSSBORDER_SEPA.getLegacyCode()));
    }

    @Test
    public void shouldMapNulls() {
        ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
        AccountKey fromAccountKey = TestData.NORDEA_ACCOUNT_KEY;
        AccountKey toAccountKey = TestData.CROSS_BORDER_ACCOUNT_KEY;
        Payment payment = PaymentTestData.getUnconfirmedPayment(fromAccountKey, toAccountKey);

        String agreementOwner = "AO1234567890";

        String userId = "UI1234567890";
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));

        ServiceData serviceData = new ServiceData(serviceRequestContextMock, agreementOwner, "123", "corporate");

        CrossBorder crossBorderMock = mock(CrossBorder.class);
        payment.setCrossBorder(crossBorderMock);

        CrossBorder.ChargePaidByEnum chargePaidBy = CrossBorder.ChargePaidByEnum.payer;
        when(crossBorderMock.getChargePaidBy()).thenReturn(chargePaidBy);

        CreateCrossborderPaymentRequestRecord resultValue = paymentToCreateCrossborderPaymentRequest.convert(serviceData, payment);

        assertThat("InSwiftKod is not correct", resultValue.getInSwiftKod(), is(EMPTY_STRING));
        assertThat("InLandKod is not correct", resultValue.getInLandKod(), is(EMPTY_STRING));
        assertThat("InSortCode is not correct", resultValue.getInSortCode(), is(EMPTY_STRING));
        assertThat("InBankNamn is not correct", resultValue.getInBankNamn(), is(EMPTY_STRING));

        assertThat("InEffTyp is not correct", resultValue.getInEffTyp(), is(PaymentSpeed.get(Payment.SpeedEnum.normal).toString()));
        assertThat("InSepa is not correct", resultValue.getInSepa(), is(EMPTY_STRING));
    }
}
