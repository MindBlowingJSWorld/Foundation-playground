package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.model.CorporatePayment;
import com.nordea.dbf.payment.model.LegacyPaymentType;
import com.nordea.dbf.payment.record.corporate.payment.CreatePaymentRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;

import java.text.DecimalFormat;
import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToCreatePaymentRequestTest {

    private static final String CREATE_PAYMENT_REQUEST_TRANSACTION_CODE = "ESC002";
    private static final String IN_ADD_RECIP_FLAG = "N";
    private static final String IN_MOTT_NAMN = "";
    private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#.##");
    private String userId = "12345678912345";
    private String agreementOwner = "123456789102";
    private Payment testPayment;

    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private PaymentToCreatePaymentRequest paymentToCreatePaymentRequest;
    private NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
    private ServiceData serviceData;

    @Before
    public void init() {
        testPayment = PaymentTestData.getUnconfirmedPayment(TestData.NORDEA_ACCOUNT_KEY, TestData.THIRD_PARTY_ACCOUNT);
        testPayment.setType(Payment.TypeEnum.lban);
        paymentToCreatePaymentRequest = new PaymentToCreatePaymentRequest(nilRequestMsgHeadersMock);

        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new CreatePaymentRequestRecord());
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));

        serviceData = new ServiceData(serviceRequestContextMock, agreementOwner, "123", "corporate");
    }

    @Test
    public void shouldMapFullRequest() {
        CreatePaymentRequestRecord requestRecord =
                paymentToCreatePaymentRequest.convert(serviceData, testPayment);

        final AccountKey fromAccountKey = AccountKey.fromString(testPayment.getFrom());
        final AccountKey toAccountKey = AccountKey.fromString(testPayment.getTo());

        assertThat("TransactionCode is not correct", requestRecord.getTransactionCode(),
                is(CREATE_PAYMENT_REQUEST_TRANSACTION_CODE));
        assertThat("InAgreementHolderId is not correct", requestRecord.getInAgreementHolderId(),
                is(Long.valueOf(agreementOwner.substring(2, 12))));
        assertThat("TechId is not correct", requestRecord.getInTechId(),
                is("123"));
        assertThat("InAnvId is not correct", requestRecord.getInAnvId(),
                is(userId.substring(2, 12)));
        assertThat("InAvsKto is not correct", requestRecord.getInAvsKto(),
                is(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber())));
        assertThat("InFicka is not correct", requestRecord.getInFicka(),
                is(TestData.NORDEA_ACCOUNT_KEY.getCurrencyCode().get()));
        assertThat("InMottKto is not correct", requestRecord.getInMottKto(),
                is(toAccountKey.getAccountNumber().getAccountNumber()));
        assertThat("InBel is not correct", requestRecord.getInBel(),
                is((DECIMAL_FORMAT.format(testPayment.getAmount().doubleValue()).replace(".", ","))));
        assertThat("InValKod is not correct", requestRecord.getInValKod(),
                is(testPayment.getCurrency()));
        assertThat("InBegartBokfDat is not correct", requestRecord.getInBegartBokfDat(),
                is(CorporatePayment.formatAsDateWithoutCentury(testPayment.getDue())));
        assertThat("InMottMed is not correct", requestRecord.getInMottMed(),
                is(testPayment.getMessage()));
        assertThat("InRefVs is not correct", requestRecord.getInRefVs(),
                is(testPayment.getOwnMessage()));
        assertThat("InAddRecipFlag is not correct", requestRecord.getInAddRecipFlag(),
                is(IN_ADD_RECIP_FLAG));
        assertThat("InMottNamn is not correct", requestRecord.getInMottNamn(),
                is(IN_MOTT_NAMN));
        assertThat("InPaySubTypeExt is not correct", requestRecord.getInPaySubTypeExt(),
                is(LegacyPaymentType.codeFromPaymentType(testPayment.getType())));
    }

    @Test
    public void shouldRemoveMottMedForSalaryAndPension() {
        Payment.TypeEnum[] types = {Payment.TypeEnum.salary, Payment.TypeEnum.pension};
        for (Payment.TypeEnum type : types) {
            testPayment.setType(type);
            testPayment.setMessage("message");
            CreatePaymentRequestRecord requestRecord =
                    paymentToCreatePaymentRequest.convert(serviceData, testPayment);

            assertThat("InMottMed is not correct", requestRecord.getInMottMed(),
                    is(""));
        }
    }
}
