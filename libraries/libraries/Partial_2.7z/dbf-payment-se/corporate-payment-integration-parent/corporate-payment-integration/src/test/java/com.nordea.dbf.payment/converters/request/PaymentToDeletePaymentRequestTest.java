package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.DeletePaymentRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToDeletePaymentRequestTest {

    private static final String DELETE_PAYMENT_REQUEST_TRANSACTION_CODE = "ESC017";
    private static final String PAYMENT_STATUS_SIGNED = "Y";
    private static final String PAYMENT_STATUS_UNSIGNED = "N";
    private static final String PAYMENT_TYPE_CROSSBORDER = "U";
    private static final String PAYMENT_TYPE_DOMESTIC = "I";

    private PaymentToDeletePaymentRequest paymentToDeletePaymentRequest;
    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private String userId = "UI1234567890";
    private ServiceData serviceData;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        paymentToDeletePaymentRequest = new PaymentToDeletePaymentRequest(nilRequestMsgHeadersMock);
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new DeletePaymentRequestRecord());
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));

        serviceData = new ServiceData(serviceRequestContextMock, "123", "123", "corporate");
    }

    @Test
    public void shouldMapFullRequest() {
        final AccountKey fromAccountKey = TestData.NORDEA_ACCOUNT_KEY;
        final AccountKey toAccountKey = TestData.NORDEA_ACCOUNT_KEY;
        Payment payment = PaymentTestData.getUnconfirmedPayment(fromAccountKey, toAccountKey);
        payment.setType(Payment.TypeEnum.normal);

        DeletePaymentRequestRecord returnValue =
                paymentToDeletePaymentRequest.convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(DELETE_PAYMENT_REQUEST_TRANSACTION_CODE));
        assertThat("TechId is not correct", returnValue.getInTechId(),
            is("123"));

        assertThat("InUserId is not correct", returnValue.getInUserId(),
                is(userId.substring(0, 10)));
        assertThat("InTid is not correct", returnValue.getInTid(),
                is(payment.getId()));
        assertThat("InAvsKto is not correct", returnValue.getInAvsKto(),
                is(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber())));
        assertThat("InFicka is not correct", returnValue.getInFicka(),
                is(payment.getCurrency()));
        assertThat("InBetTyp is not correct", returnValue.getInBetTyp(),
                is(PAYMENT_TYPE_DOMESTIC));
        assertThat("InSign is not correct", returnValue.getInSign(),
                is(PAYMENT_STATUS_UNSIGNED));
    }

    @Test
    public void shouldMapCrossborderAndSigned() {
        final AccountKey fromAccountKey = TestData.NORDEA_ACCOUNT_KEY;
        final AccountKey toAccountKey = TestData.NORDEA_ACCOUNT_KEY;
        Payment payment = PaymentTestData.getConfirmedPayment(fromAccountKey, toAccountKey);
        payment.setType(Payment.TypeEnum.crossborder);

        DeletePaymentRequestRecord returnValue =
                paymentToDeletePaymentRequest.convert(serviceData, payment);

        assertThat("InBetTyp is not correct", returnValue.getInBetTyp(),
                is(PAYMENT_TYPE_CROSSBORDER));
        assertThat("InSign is not correct", returnValue.getInSign(),
                is(PAYMENT_STATUS_SIGNED));
    }
}
