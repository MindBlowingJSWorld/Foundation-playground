package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.corporate.payment.GetUnconfirmedPaymentDetailsRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToGetUnconfirmedPaymentDetailsRequestTest {

    private static final String UNCONFIRMED_PAYMENT_DETAILS_REQUEST_TRANSACTION_CODE = "ESC019";
    private String userId = "UI1234567890";
    private PaymentToGetUnconfirmedPaymentDetailsRequest paymentToGetUnconfirmedPaymentDetailsRequest;

    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private ServiceData serviceData;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        paymentToGetUnconfirmedPaymentDetailsRequest = new PaymentToGetUnconfirmedPaymentDetailsRequest(nilRequestMsgHeadersMock);

        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new GetUnconfirmedPaymentDetailsRequestRecord());
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));

        serviceData = new ServiceData(serviceRequestContextMock, "123", "123", "corporate");
    }

    @Test
    public void shouldMapFullRequest() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.NORDEA_ACCOUNT_KEY, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.normal);

        GetUnconfirmedPaymentDetailsRequestRecord returnValue =
                paymentToGetUnconfirmedPaymentDetailsRequest.convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(UNCONFIRMED_PAYMENT_DETAILS_REQUEST_TRANSACTION_CODE));
        assertThat("InUserId is not correct", returnValue.getInUserid(),
                is(userId.substring(2, 12)));
        assertThat("TechId is not correct", returnValue.getInTechId(),
                is("123"));

        assertThat("InTid is not correct", returnValue.getInTid(),
                is(payment.getId()));
        assertThat("InAvsKto is not correct", returnValue.getInAvsKto(),
                is(Long.parseLong(TestData.NORDEA_ACCOUNT_KEY.getAccountNumber().getAccountNumber())));
        assertThat("InFicka is not correct", returnValue.getInFicka(),
                is(payment.getCurrency()));
    }

    @Test
    public void shouldMapEmptyCurrency() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.PG_ACCOUNT_KEY, TestData.PG_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.plusgiro);
        payment.setCurrency(null);

        GetUnconfirmedPaymentDetailsRequestRecord returnValue =
                paymentToGetUnconfirmedPaymentDetailsRequest
                        .convert(serviceData, payment);

        assertThat("InValKod is not correct", returnValue.getInFicka(),
                is(""));
    }
}
