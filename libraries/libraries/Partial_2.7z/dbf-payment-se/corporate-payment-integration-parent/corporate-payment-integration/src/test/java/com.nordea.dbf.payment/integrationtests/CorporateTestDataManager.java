package com.nordea.dbf.payment.integrationtests;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.payment.model.CorporatePaymentType;
import com.nordea.dbf.payment.model.CorporateTimeConverter;
import com.nordea.dbf.payment.record.corporate.payment.*;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

public class CorporateTestDataManager {
    @Autowired
    private M8ImsConnection m8ImsConnection;

    public void mockDeletionOfCorporatePayment(Payment payment) {
        when(m8ImsConnection.execute(isA(DeletePaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            DeletePaymentResponseRecord deletePaymentResponseRecord = new DeletePaymentResponseRecord();
            deletePaymentResponseRecord.setKrc(0);
            deletePaymentResponseRecord.setKbearb(0);
            return Observable.just(deletePaymentResponseRecord);
        });
    }

    public void mockListingOfNoConfirmedCorporatePayments() {
        when(m8ImsConnection.execute(isA(GetConfirmedPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetConfirmedPaymentsResponseRecord getConfirmedPaymentsResponseRecord = new GetConfirmedPaymentsResponseRecord();
            return Observable.just(getConfirmedPaymentsResponseRecord);
        });
    }

    public void mockListingOfNoUnconfirmedCorporatePayments() {
        when(m8ImsConnection.execute(isA(GetUnconfirmedPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetUnconfirmedPaymentsResponseRecord getUnconfirmedPaymentsResponseRecord = new GetUnconfirmedPaymentsResponseRecord();
            return Observable.just(getUnconfirmedPaymentsResponseRecord);
        });
    }


    public void mockListingOfNoRejectedCorporatePayments() {
        when(m8ImsConnection.execute(isA(GetRejectedPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetRejectedPaymentsResponseRecord getRejectedPaymentsResponseRecord = new GetRejectedPaymentsResponseRecord();
            return Observable.just(getRejectedPaymentsResponseRecord);
        });
    }

    public void mockListingOfOneUnconfirmedCorporatePayment(Payment payment) {
        when(m8ImsConnection.execute(isA(GetUnconfirmedPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetUnconfirmedPaymentsResponseRecord getUnconfirmedPaymentsResponseRecord = new GetUnconfirmedPaymentsResponseRecord();
            final GetUnconfirmedPaymentsResponsePaymentsSegment segment = getUnconfirmedPaymentsResponseRecord.addPayments();
            segment.setEsc003uRegistrTidp(LocalDateTime.now().format(CorporateTimeConverter.CORPORATE_PAYMENT_TIME_STAMP_FORMATTER));
            segment.setEsc003uBegartBokfDat(payment.getDue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            segment.setEsc003uAvsKto(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
            segment.setEsc003uValKodAvsKto(payment.getCurrency());
            segment.setEsc003uSubType(CorporatePaymentType.convertToPaymentType(AccountKey.fromString(payment.getTo()).getPrefix()).orElse(CorporatePaymentType.ACCOUNT).getLegacyCode());
            segment.setEsc003uMottKto(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber());
            segment.setEsc003uValKod(payment.getCurrency());
            segment.setEsc003uMottMed(payment.getMessage());
            segment.setEsc003uBel(payment.getAmount().doubleValue());
            segment.setEsc003uFlDelete("Y");
            segment.setEsc003uFlChange("Y");
            if (payment.getCrossBorder() != null) {
//                        segment.setEsc003uMottNamn(payment.getCrossBorder().getRecipientName());
                segment.setEsc003uSubType("CB");
                segment.setEsc003uBetalare("B");
            }
            segment.setEsc003uTid(payment.getId());

            return Observable.just(getUnconfirmedPaymentsResponseRecord);
        });
    }

    public void mockListingOfOneConfirmedCorporatePayment(Payment payment) {
        when(m8ImsConnection.execute(isA(GetConfirmedPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetConfirmedPaymentsResponseRecord getConfirmedPaymentsResponseRecord = new GetConfirmedPaymentsResponseRecord();
            final GetConfirmedPaymentsResponsePaymentsSegment paymentsSegment = getConfirmedPaymentsResponseRecord.addPayments();
            paymentsSegment.setEsc006uRegistrTidp(LocalDateTime.now().format(CorporateTimeConverter.CORPORATE_PAYMENT_TIME_STAMP_FORMATTER));
            paymentsSegment.setEsc006uBegartBokfDat((payment.getDue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))));
            paymentsSegment.setEsc006uAvsKto(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
            paymentsSegment.setEsc006uValKodAvsKto(payment.getCurrency());
            paymentsSegment.setEsc006uSubType(CorporatePaymentType.convertToPaymentType(AccountKey.fromString(payment.getTo()).getPrefix()).orElse(CorporatePaymentType.ACCOUNT).getLegacyCode());
            paymentsSegment.setEsc006uMottKto(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber());
            paymentsSegment.setEsc006uValKod(payment.getCurrency());
            paymentsSegment.setEsc006uBel(payment.getAmount().doubleValue());
            paymentsSegment.setEsc006uFlDelete("Y");
            paymentsSegment.setEsc006uFlChange("Y");
            paymentsSegment.setEsc006uMottNamn("Handelsbolaget AB");
            paymentsSegment.setEsc006uTid(payment.getId());
            return Observable.just(getConfirmedPaymentsResponseRecord);
        });
    }

    public void mockListingOfOneRejectedOrStoppedCorporatePayment(Payment payment) {
        when(m8ImsConnection.execute(isA(GetRejectedPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetRejectedPaymentsResponseRecord getRejectedPaymentsResponseRecord = new GetRejectedPaymentsResponseRecord();
            final GetRejectedPaymentsResponsePaymentsSegment paymentsSegment = getRejectedPaymentsResponseRecord.addPayments();
            paymentsSegment.setEsc016uBel(payment.getAmount().doubleValue());
            paymentsSegment.setEsc016uTid(LocalDateTime.now().format(CorporateTimeConverter.CORPORATE_PAYMENT_TIME_STAMP_FORMATTER));
            paymentsSegment.setEsc016uKtoMott(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber());
            paymentsSegment.setEsc016uPgKtoNr(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
            paymentsSegment.setEsc016uSubType(CorporatePaymentType.convertToPaymentType(AccountKey.fromString(payment.getTo()).getPrefix()).orElse(CorporatePaymentType.ACCOUNT).getLegacyCode());
            paymentsSegment.setEsc016uKodVltaOrig(payment.getCurrency());
            paymentsSegment.setEsc016uStatuskod(payment.getStatus() == Payment.StatusEnum.rejected ? "M" : "H");
            return Observable.just(getRejectedPaymentsResponseRecord);
        });
    }

    public void mockListingOfSeveralRejectedOrStoppedCorporatePayment(Payment... payments) {
        when(m8ImsConnection.execute(isA(GetRejectedPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetRejectedPaymentsResponseRecord getRejectedPaymentsResponseRecord = new GetRejectedPaymentsResponseRecord();
            for (Payment payment : payments) {
                final GetRejectedPaymentsResponsePaymentsSegment paymentsSegment = getRejectedPaymentsResponseRecord.addPayments();
                paymentsSegment.setEsc016uBel(payment.getAmount().doubleValue());
                paymentsSegment.setEsc016uTid(LocalDateTime.now().format(CorporateTimeConverter.CORPORATE_PAYMENT_TIME_STAMP_FORMATTER));
                paymentsSegment.setEsc016uKtoMott(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber());
                paymentsSegment.setEsc016uPgKtoNr(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
                paymentsSegment.setEsc016uSubType(CorporatePaymentType.convertToPaymentType(AccountKey.fromString(payment.getTo()).getPrefix()).orElse(CorporatePaymentType.ACCOUNT).getLegacyCode());
                paymentsSegment.setEsc016uKodVltaOrig(payment.getCurrency());
                paymentsSegment.setEsc016uStatuskod(payment.getStatus() == Payment.StatusEnum.rejected ? "M" : "H");
            }
            return Observable.just(getRejectedPaymentsResponseRecord);
        });
    }

    public void mockRetrieveOfNoConfirmedCorporatePayment() {
        when(m8ImsConnection.execute(isA(GetConfirmedPaymentDetailsRequestRecord.class), any(Class.class))).thenAnswer(s -> Observable.empty());
    }

    public void mockRetrieveOfNoUnconfirmedCorporatePayment() {
        when(m8ImsConnection.execute(isA(GetUnconfirmedPaymentDetailsRequestRecord.class), any(Class.class))).thenAnswer(s -> Observable.empty());
    }


    public void mockRetrieveOneConfirmedCorporatePayment(Payment payment) {
        when(m8ImsConnection.execute(isA(GetConfirmedPaymentDetailsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetConfirmedPaymentDetailsResponseRecord responseRecord = new GetConfirmedPaymentDetailsResponseRecord();
            responseRecord.setBegartBokfDat(payment.getDue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            responseRecord.setSubType(CorporatePaymentType.convertToPaymentType(AccountKey.fromString(payment.getTo()).getPrefix()).orElse(CorporatePaymentType.ACCOUNT).getLegacyCode());
            responseRecord.setTid(payment.getId());
            responseRecord.setBel(payment.getAmount().doubleValue());
            responseRecord.setAvsKto(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
            responseRecord.setValKodAvsKto(payment.getCurrency());
            responseRecord.setMottKto(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber());
            responseRecord.setMottMed(payment.getMessage());
            responseRecord.setValKod(payment.getCurrency());
            return Observable.just(responseRecord);
        });
    }

    public void mockRetrieveOneUnconfirmedCorporatePayment(Payment payment) {
        when(m8ImsConnection.execute(isA(GetUnconfirmedPaymentDetailsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetUnconfirmedPaymentDetailsResponseRecord responseRecord = new GetUnconfirmedPaymentDetailsResponseRecord();
            responseRecord.setBegartBokfDat(payment.getDue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            responseRecord.setSubType(CorporatePaymentType.convertToPaymentType(AccountKey.fromString(payment.getTo()).getPrefix()).orElse(CorporatePaymentType.ACCOUNT).getLegacyCode());
            responseRecord.setTid(payment.getId());
            responseRecord.setBel(payment.getAmount().doubleValue());
            responseRecord.setAvsKto(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
            responseRecord.setValKodAvsKto(payment.getCurrency());
            responseRecord.setMottKto(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber());
            responseRecord.setMottMed(payment.getMessage());
            responseRecord.setValKod(payment.getCurrency());
            return Observable.just(responseRecord);
        });
    }

    public void mockCreateCorporateCrossborderPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(CreateCrossborderPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            CreateCrossborderPaymentResponseRecord createCrossborderPaymentResponseRecord = new CreateCrossborderPaymentResponseRecord();
            createCrossborderPaymentResponseRecord.setPayKey(payment.getId());
            return Observable.just(createCrossborderPaymentResponseRecord);
        });
    }


    public void mockCreateCorporatePayment(Payment payment) {
        when(m8ImsConnection.execute(isA(CreatePaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            CreatePaymentResponseRecord createPaymentResponseRecord = new CreatePaymentResponseRecord();
            createPaymentResponseRecord.setPayKey(payment.getId());
            return Observable.just(createPaymentResponseRecord);
        });
    }

    public void mockConfirmOneCorporatePayment(Payment payment) {
        when(m8ImsConnection.execute(isA(ConfirmPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            ConfirmPaymentsResponseRecord confirmPaymentsResponseRecord = new ConfirmPaymentsResponseRecord();
            confirmPaymentsResponseRecord.setKrc(0);
            confirmPaymentsResponseRecord.setKbearb(0);
            confirmPaymentsResponseRecord.setUtAntFel(0);
            confirmPaymentsResponseRecord.setUtAntRatt(1);
            confirmPaymentsResponseRecord.setUtAntRad(1);

            ConfirmPaymentsResponsePaymentsSegment payments = confirmPaymentsResponseRecord.addPayments();
            payments.setUtTidSign(payment.getId());

            return Observable.just(confirmPaymentsResponseRecord);
        });
    }

    public void mockConfirmNoCorporatePayment() {
        when(m8ImsConnection.execute(isA(ConfirmPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            ConfirmPaymentsResponseRecord confirmPaymentsResponseRecord = new ConfirmPaymentsResponseRecord();
            confirmPaymentsResponseRecord.setKrc(0);
            confirmPaymentsResponseRecord.setKbearb(0);
            confirmPaymentsResponseRecord.setUtAntFel(0);
            confirmPaymentsResponseRecord.setUtAntRatt(0);
            return Observable.just(confirmPaymentsResponseRecord);
        });
    }

    public void mockConfirmFailureCorporatePayment() {
        when(m8ImsConnection.execute(isA(ConfirmPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            ConfirmPaymentsResponseRecord confirmPaymentsResponseRecord = new ConfirmPaymentsResponseRecord();
            confirmPaymentsResponseRecord.setKrc(0);
            confirmPaymentsResponseRecord.setKbearb(0);
            confirmPaymentsResponseRecord.setUtAntFel(1);
            confirmPaymentsResponseRecord.setUtAntRatt(0);
            return Observable.just(confirmPaymentsResponseRecord);
        });
    }

    public void mockCorporatePaymentChange(Payment payment) {
        when(m8ImsConnection.execute(isA(ChangeUnconfirmedPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            ChangeUnconfirmedPaymentResponseRecord changeUnconfirmedPaymentResponseRecord = new ChangeUnconfirmedPaymentResponseRecord();
            changeUnconfirmedPaymentResponseRecord.setPayKey(payment.getId());
            return Observable.just(changeUnconfirmedPaymentResponseRecord);
        });
    }

    public void mockCorporateCrossborderPaymentChange(Payment payment) {
        when(m8ImsConnection.execute(isA(ChangeUnconfirmedCrossBorderPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            ChangeUnconfirmedCrossBorderPaymentResponseRecord changeUnconfirmedCrossBorderPaymentResponseRecord = new ChangeUnconfirmedCrossBorderPaymentResponseRecord();
            changeUnconfirmedCrossBorderPaymentResponseRecord.setPayKey(payment.getId());
            return Observable.just(changeUnconfirmedCrossBorderPaymentResponseRecord);
        });
    }

    public void mockListingOfConfirmedPaymentsBackendError(int kbearb, int krc) {
        when(m8ImsConnection.execute(isA(GetConfirmedPaymentsRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetConfirmedPaymentsResponseRecord getConfirmedPaymentsResponseRecord = new GetConfirmedPaymentsResponseRecord();
            getConfirmedPaymentsResponseRecord.setKbearb(kbearb);
            getConfirmedPaymentsResponseRecord.setKrc(krc);
            return Observable.just(getConfirmedPaymentsResponseRecord);
        });
    }
}
