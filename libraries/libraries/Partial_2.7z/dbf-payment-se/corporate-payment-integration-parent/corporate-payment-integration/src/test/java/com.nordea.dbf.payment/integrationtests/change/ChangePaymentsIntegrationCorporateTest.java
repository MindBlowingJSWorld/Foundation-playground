package com.nordea.dbf.payment.integrationtests.change;

import com.nordea.dbf.agreement.customer.se.model.*;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.CorporateAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;


public class ChangePaymentsIntegrationCorporateTest extends CorporateAbstractIntegrationTestBase {
    @Test
    public void shouldChangeCrossBorderPayment() {
        // given
        Payment originalPayment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.CROSS_BORDER_ACCOUNT_KEY);
        originalPayment.setType(CommonPaymentType.fromPayment(originalPayment, false));
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.CROSS_BORDER_ACCOUNT_KEY);
        payment.setType(CommonPaymentType.fromPayment(payment, false));
        payment.setMessage("A new message");

        corporateTestDataManager.mockListingOfNoConfirmedCorporatePayments();
        corporateTestDataManager.mockRetrieveOfNoConfirmedCorporatePayment();
        corporateTestDataManager.mockListingOfOneUnconfirmedCorporatePayment(payment);
        corporateTestDataManager.mockRetrieveOneUnconfirmedCorporatePayment(payment);
        corporateTestDataManager.mockCorporateCrossborderPaymentChange(payment);
        corporateTestDataManager.mockListingOfNoRejectedCorporatePayments();

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        // given
        Payment changedPayment = corporatePaymentFacade.changePayment(serviceData, payment, originalPayment).toBlocking().single();
        // then
        assertNotEquals(originalPayment.getId(), changedPayment.getId());
        assertEquals(payment.getMessage(), changedPayment.getMessage());
        assertNotEquals(originalPayment.getMessage(), changedPayment.getMessage());
    }
}
