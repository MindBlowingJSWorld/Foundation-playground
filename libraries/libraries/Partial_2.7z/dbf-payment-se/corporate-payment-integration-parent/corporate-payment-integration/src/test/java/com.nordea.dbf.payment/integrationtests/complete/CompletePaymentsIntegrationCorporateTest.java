package com.nordea.dbf.payment.integrationtests.complete;

import com.nordea.dbf.agreement.customer.se.model.*;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.BackendException;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.CorporateAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class CompletePaymentsIntegrationCorporateTest extends CorporateAbstractIntegrationTestBase {
    @Test
    public void shouldConfirmOneCorporatePayment() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT_KEY);
        Payment confirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT_KEY);
        confirmedPayment.setId(payment.getId());
        payment.setType(CommonPaymentType.fromPayment(payment,false));
        confirmedPayment.setType(CommonPaymentType.fromPayment(confirmedPayment,false));

        this.corporateTestDataManager.mockRetrieveOfNoUnconfirmedCorporatePayment();
        this.corporateTestDataManager.mockRetrieveOneConfirmedCorporatePayment(confirmedPayment);
        this.corporateTestDataManager.mockConfirmOneCorporatePayment(confirmedPayment);
        this.corporateTestDataManager.mockListingOfNoRejectedCorporatePayments();

        Payment paymentRequest = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT_KEY);
        paymentRequest.setType(CommonPaymentType.fromPayment(payment,false));
        paymentRequest.setId(payment.getId());
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        // when
        Payment paymentResult = this.corporatePaymentFacade.completePayment(serviceData, paymentRequest).toBlocking().single();

        // then
        assertThat(paymentResult.getId()).isEqualTo(payment.getId() + ":" + TestData.CORPORATE_OWN_ACCOUNT.getCurrencyCode().get() + ":" + TestData.CORPORATE_OWN_ACCOUNT.getAccountNumber().getAccountNumber());
        assertThat(paymentResult.getStatus()).isEqualTo(Payment.StatusEnum.confirmed);
    }

    @Test
    public void shouldThrowNotFoundExceptionWhenMissingPayment() {
        // given
        this.corporateTestDataManager.mockConfirmNoCorporatePayment();

        Payment paymentRequest = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT_KEY);
        paymentRequest.setType(CommonPaymentType.fromPayment(paymentRequest,false));
        paymentRequest.setId(paymentRequest.getId());
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        // when

        assertThatThrownBy(() -> this.corporatePaymentFacade.completePayment(serviceData, paymentRequest).toBlocking().single()).isInstanceOf(NotFoundException.class);
    }

    @Test
    public void shouldThrowBackendExceptionUponNoConfirmation() {
        // given
        this.corporateTestDataManager.mockConfirmFailureCorporatePayment();

        Payment paymentRequest = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT_KEY);
        paymentRequest.setType(CommonPaymentType.fromPayment(paymentRequest,false));
        paymentRequest.setId(paymentRequest.getId());
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        // when

        assertThatThrownBy(() -> this.corporatePaymentFacade.completePayment(serviceData, paymentRequest).toBlocking().single()).isInstanceOf(BackendException.class);

    }
}
