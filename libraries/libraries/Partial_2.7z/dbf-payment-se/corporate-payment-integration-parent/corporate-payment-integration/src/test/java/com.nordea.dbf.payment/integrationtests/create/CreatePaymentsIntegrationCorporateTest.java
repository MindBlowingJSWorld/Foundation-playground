package com.nordea.dbf.payment.integrationtests.create;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.CorporateAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class CreatePaymentsIntegrationCorporateTest extends CorporateAbstractIntegrationTestBase {

    @Test
    public void shouldCreateCrossBorderPayment() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.CROSS_BORDER_ACCOUNT_KEY);
        payment.setType(CommonPaymentType.fromPayment(payment,false));
        this.corporateTestDataManager.mockCreateCorporateCrossborderPayment(payment);
        this.corporateTestDataManager.mockRetrieveOfNoConfirmedCorporatePayment();
        this.corporateTestDataManager.mockRetrieveOneUnconfirmedCorporatePayment(payment);
        this.corporateTestDataManager.mockListingOfNoRejectedCorporatePayments();

        // when
        Payment paymentRequest = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.CROSS_BORDER_ACCOUNT_KEY);
        paymentRequest.setId(null);
        paymentRequest.setType(CommonPaymentType.fromPayment(paymentRequest,false));
        paymentRequest.setRecipientName("recipient");
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");
        Payment paymentResult = this.corporatePaymentFacade.createPayment(serviceData, paymentRequest).toBlocking().single();

        // then
        assertThat(paymentResult.getId()).isEqualTo(payment.getId() + ":" + TestData.CORPORATE_OWN_ACCOUNT.getCurrencyCode().get() + ":" + TestData.CORPORATE_OWN_ACCOUNT.getAccountNumber().getAccountNumber());
    }

    @Test
    public void corporatePgPaymentCanBeCreated() throws Exception {
        testCorporateCreation(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT_KEY);
    }

    @Test
    public void corporateBgPaymentCanBeCreated() throws Exception {
        testCorporateCreation(TestData.CORPORATE_OWN_ACCOUNT, TestData.BG_ACCOUNT_KEY);
    }

    @Test
    public void corporateThirdPartyPaymentCanBeCreated() throws Exception {
        testCorporateCreation(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
    }

    private void testCorporateCreation(AccountKey fromAccount, AccountKey toAccount) {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(fromAccount, toAccount);
        payment.setType(CommonPaymentType.fromPayment(payment,false));
        this.corporateTestDataManager.mockCreateCorporatePayment(payment);
        this.corporateTestDataManager.mockRetrieveOfNoConfirmedCorporatePayment();
        this.corporateTestDataManager.mockRetrieveOneUnconfirmedCorporatePayment(payment);
        this.corporateTestDataManager.mockListingOfNoRejectedCorporatePayments();

        // when
        Payment paymentRequest = PaymentTestData.getUnconfirmedPayment(fromAccount, toAccount);
        paymentRequest.setId(null);
        paymentRequest.setType(CommonPaymentType.fromPayment(paymentRequest,false));

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        Payment paymentResult = this.corporatePaymentFacade.createPayment(serviceData, paymentRequest).toBlocking().single();

        // then
        assertThat(paymentResult.getId()).isEqualTo(payment.getId() + ":" + fromAccount.getCurrencyCode().get() + ":" + fromAccount.getAccountNumber().getAccountNumber());
    }
}
