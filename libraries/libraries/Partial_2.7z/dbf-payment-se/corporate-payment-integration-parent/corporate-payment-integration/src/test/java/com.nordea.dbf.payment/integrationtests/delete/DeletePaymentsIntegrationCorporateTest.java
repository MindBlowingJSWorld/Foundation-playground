package com.nordea.dbf.payment.integrationtests.delete;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.CorporateAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;


/**
 * Created by K306010 on 2016-02-08.
 */

public class DeletePaymentsIntegrationCorporateTest extends CorporateAbstractIntegrationTestBase {
    // TODO: What different types of failures / validations are provided by the backend and should be verified here?

    @Test
    public void shouldDeleteUnconfirmedCorporatePayment() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(CommonPaymentType.fromPayment(payment, false));
        this.corporateTestDataManager.mockDeletionOfCorporatePayment(payment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        // when
        final Payment deletedPayment = corporatePaymentFacade.deletePayment(serviceData, payment).toBlocking().single();
        // then
        assertThat(deletedPayment.getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(deletedPayment.getDue()).isEqualTo(payment.getDue());
        assertThat(deletedPayment.getAmount()).isEqualTo(payment.getAmount());
        assertThat(deletedPayment.getTo()).isEqualTo(payment.getTo());
        assertThat(deletedPayment.getFrom()).isEqualTo(payment.getFrom());
    }

    @Test
    public void shouldDeleteUnconfirmedCorporateCrossborderPayment() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.CROSS_BORDER_ACCOUNT_KEY);
        payment.setType(CommonPaymentType.fromPayment(payment, false));
        this.corporateTestDataManager.mockDeletionOfCorporatePayment(payment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");


        // when
        final Payment deletedPayment = corporatePaymentFacade.deletePayment(serviceData, payment).toBlocking().single();
        // then
        assertThat(deletedPayment.getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(deletedPayment.getDue()).isEqualTo(payment.getDue());
        assertThat(deletedPayment.getAmount()).isEqualTo(payment.getAmount());
        assertThat(deletedPayment.getTo()).isEqualTo(payment.getTo());
        assertThat(deletedPayment.getFrom()).isEqualTo(payment.getFrom());
    }
}
