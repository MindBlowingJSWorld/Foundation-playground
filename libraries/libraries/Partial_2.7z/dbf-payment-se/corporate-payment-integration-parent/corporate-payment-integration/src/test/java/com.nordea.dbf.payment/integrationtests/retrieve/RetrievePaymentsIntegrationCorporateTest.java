package com.nordea.dbf.payment.integrationtests.retrieve;

import com.nordea.dbf.agreement.customer.se.model.Agreement;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.CorporateAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class RetrievePaymentsIntegrationCorporateTest extends CorporateAbstractIntegrationTestBase {

    private Agreement agreementMock = mock(Agreement.class);

    @Test
    public void shouldReturnUnconfirmedPayment() {
        // given
        // TODO: Add more payments
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        this.corporateTestDataManager.mockListingOfNoConfirmedCorporatePayments();
        this.corporateTestDataManager.mockListingOfOneUnconfirmedCorporatePayment(payment);
        this.corporateTestDataManager.mockListingOfNoRejectedCorporatePayments();

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter<>(Collections.singletonList(TestData.CORPORATE_OWN_ACCOUNT)));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");
        List<Payment> payments = corporatePaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertThat(payments.size()).isEqualTo(1);
        assertThat(payments.get(0).getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(payments.get(0).getDue()).isEqualTo(payment.getDue());
        assertThat(payments.get(0).getAmount()).isEqualTo(payment.getAmount());
        assertThat(payments.get(0).getTo()).isEqualTo(payment.getTo());
        assertThat(payments.get(0).getFrom()).isEqualTo(payment.getFrom());
    }


    @Test
    public void shouldReturnConfirmedPayment() {
        // given
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        // TODO: Add more payments
        this.corporateTestDataManager.mockListingOfOneConfirmedCorporatePayment(payment);
        this.corporateTestDataManager.mockListingOfNoUnconfirmedCorporatePayments();
        this.corporateTestDataManager.mockListingOfNoRejectedCorporatePayments();

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter<>(Collections.singletonList(TestData.CORPORATE_OWN_ACCOUNT)));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        List<Payment> payments = corporatePaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();
        // then
        assertThat(payments.size()).isEqualTo(1);
        assertThat(payments.get(0).getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(payments.get(0).getDue()).isEqualTo(payment.getDue());
        assertThat(payments.get(0).getAmount()).isEqualTo(payment.getAmount());
        assertThat(payments.get(0).getTo()).isEqualTo(payment.getTo());
        assertThat(payments.get(0).getFrom()).isEqualTo(payment.getFrom());
    }

    @Test
    public void shouldReturnRejectedPayment() {
        // given
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setStatus(Payment.StatusEnum.rejected);

        this.corporateTestDataManager.mockListingOfNoUnconfirmedCorporatePayments();
        this.corporateTestDataManager.mockListingOfNoConfirmedCorporatePayments();
        this.corporateTestDataManager.mockListingOfOneRejectedOrStoppedCorporatePayment(payment);

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter<>(Collections.singletonList(TestData.CORPORATE_OWN_ACCOUNT)));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        List<Payment> payments = corporatePaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertThat(payments.size()).isEqualTo(1);
        assertThat(payments.get(0).getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(payments.get(0).getAmount()).isEqualTo(payment.getAmount());
        assertThat(payments.get(0).getTo()).isEqualTo(payment.getTo());
        assertThat(payments.get(0).getFrom()).isEqualTo(payment.getFrom());
        assertThat(payments.get(0).getPermissions().getDelete()).isEqualTo(true);
        assertThat(payments.get(0).getPermissions().getCopy()).isEqualTo(false);
    }

    @Test
    public void shouldReturnStoppedPayment() {
        // given
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setStatus(Payment.StatusEnum.stopped);

        this.corporateTestDataManager.mockListingOfNoUnconfirmedCorporatePayments();
        this.corporateTestDataManager.mockListingOfNoConfirmedCorporatePayments();
        this.corporateTestDataManager.mockListingOfOneRejectedOrStoppedCorporatePayment(payment);

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter<>(Collections.singletonList(TestData.CORPORATE_OWN_ACCOUNT)));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        List<Payment> payments = corporatePaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertThat(payments.size()).isEqualTo(1);
        assertThat(payments.get(0).getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(payments.get(0).getAmount()).isEqualTo(payment.getAmount());
        assertThat(payments.get(0).getTo()).isEqualTo(payment.getTo());
        assertThat(payments.get(0).getFrom()).isEqualTo(payment.getFrom());
        assertThat(payments.get(0).getPermissions().getDelete()).isEqualTo(false);
        assertThat(payments.get(0).getPermissions().getCopy()).isEqualTo(false);
    }

    @Test
    public void shouldReturnPaymentsOfAllKinds() {
        // given
        this.corporateTestDataManager.mockListingOfOneConfirmedCorporatePayment(PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY));
        this.corporateTestDataManager.mockListingOfOneUnconfirmedCorporatePayment(PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY));
        this.corporateTestDataManager.mockListingOfSeveralRejectedOrStoppedCorporatePayment(
                PaymentTestData.getRejectedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY),
                PaymentTestData.getStoppedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY)
        );

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter<>(Collections.singletonList(TestData.CORPORATE_OWN_ACCOUNT)));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        List<Payment> payments = corporatePaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertThat(payments.size()).isEqualTo(4);
    }

    @Test(expected = BadRequestException.class)
    public void shouldReturnGenericError() {
        // Given
        this.corporateTestDataManager.mockListingOfConfirmedPaymentsBackendError(999, 999);
        PaymentFilter paymentFilter = new PaymentFilter();
        String agreementOwner = "AO1234567890";
        LinkedList<AccountKey> accountKeys = new LinkedList<>();
        accountKeys.add(TestData.CORPORATE_OWN_ACCOUNT);
        paymentFilter.setFromAccounts(new ListFilter<>(accountKeys));
        when(agreementMock.getAgreementOwner()).thenReturn(agreementOwner);
        paymentFilter.setStatuses(Arrays.asList("confirmed"));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        // When
        List<Payment> payments = corporatePaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // Then
        assertEquals(0, payments.size());
    }
}
