package com.nordea.dbf.payment.integrationtests.retrieve.details;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.CorporateAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class RetrievePaymentDetailsIntegrationCorporateTest extends CorporateAbstractIntegrationTestBase {

    @Test
    public void shouldReturnPaymentDetailsForUnconfirmedPayments() {
        // given
        this.corporateTestDataManager.mockListingOfOneConfirmedCorporatePayment(PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY));

        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        this.corporateTestDataManager.mockListingOfOneUnconfirmedCorporatePayment(payment);
        this.corporateTestDataManager.mockRetrieveOneUnconfirmedCorporatePayment(payment);
        this.corporateTestDataManager.mockRetrieveOfNoConfirmedCorporatePayment();
        this.corporateTestDataManager.mockListingOfNoRejectedCorporatePayments();
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        // when
        final Payment createdPayment = corporatePaymentFacade.getPayment(serviceData, payment).toBlocking().single();
        // then
        assertThat(createdPayment.getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(createdPayment.getDue()).isEqualTo(payment.getDue());
        assertThat(createdPayment.getAmount()).isEqualTo(payment.getAmount());
        assertThat(createdPayment.getTo()).isEqualTo(payment.getTo());
        assertThat(createdPayment.getFrom()).isEqualTo(payment.getFrom());
    }

    @Test
    public void shouldReturnPaymentDetailsForConfirmedPayments() {
        // given
        Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        this.corporateTestDataManager.mockListingOfOneUnconfirmedCorporatePayment(PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY));
        this.corporateTestDataManager.mockListingOfOneConfirmedCorporatePayment(confirmedPayment);
        // TODO due date not included in the ESC016 out area
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setStatus(Payment.StatusEnum.rejected);
        this.corporateTestDataManager.mockListingOfNoRejectedCorporatePayments();
        this.corporateTestDataManager.mockRetrieveOneConfirmedCorporatePayment(confirmedPayment);
        this.corporateTestDataManager.mockRetrieveOfNoUnconfirmedCorporatePayment();
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.CORPORATE_USER_ID, TestData.CORPORATE_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.CORPORATE_USER_ID, "123", "corporate");

        // when
        final Payment createdPayment = corporatePaymentFacade.getPayment(serviceData, confirmedPayment).toBlocking().single();

        // then
        assertThat(createdPayment.getAmount()).isEqualTo(confirmedPayment.getAmount());
        assertThat(createdPayment.getFrom()).isEqualTo(confirmedPayment.getFrom());
        assertThat(createdPayment.getTo()).isEqualTo(confirmedPayment.getTo());
    }
}
