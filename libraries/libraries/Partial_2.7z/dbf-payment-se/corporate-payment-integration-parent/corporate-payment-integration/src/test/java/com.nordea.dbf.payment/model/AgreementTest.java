package com.nordea.dbf.payment.model;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 * Created by K306010 on 2016-02-03.
 */
public class AgreementTest {

    @Test
    public void agreementShouldRequireName() {
        assertThatThrownBy(() -> new Agreement("", "customer", "agreement")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new Agreement(null, "customer", "agreement")).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void agreementShouldRequireCustomer() {
        assertThatThrownBy(() -> new Agreement("name", "", "agreement")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new Agreement("name", null, "agreement")).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void agreementShouldRequireAgreement() {
        assertThatThrownBy(() -> new Agreement("name", "customer", "")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new Agreement("name", "customer", null)).isInstanceOf(IllegalArgumentException.class);
    }
}
