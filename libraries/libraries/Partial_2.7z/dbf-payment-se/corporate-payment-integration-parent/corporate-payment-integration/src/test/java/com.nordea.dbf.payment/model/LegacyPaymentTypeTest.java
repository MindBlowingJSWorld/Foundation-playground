package com.nordea.dbf.payment.model;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class LegacyPaymentTypeTest {

    @Test
    public void fromLegacyCodeShouldReturnNullOnUnknownType() {
        LegacyPaymentType result = LegacyPaymentType.fromCode("");
        assertThat(result).isEqualTo(null);
    }

    @Test
    public void fromlegacyCodeShouldMatchBankgiro() {
        LegacyPaymentType bg = LegacyPaymentType.fromCode("BG");
        assertThat(bg).isEqualTo(LegacyPaymentType.BG);
    }
}
