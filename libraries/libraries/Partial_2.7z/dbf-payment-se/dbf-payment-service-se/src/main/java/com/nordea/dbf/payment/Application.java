package com.nordea.dbf.payment;

import com.nordea.dbf.annotation.EnableServiceConfiguration;
import com.nordea.dbf.audit.annotation.EnableAuditing;
import com.nordea.dbf.security.annotation.EnableServiceSecurity;
import com.nordea.dbf.spring.EnableServiceAuthorisation;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableServiceConfiguration
@EnableServiceSecurity
@EnableAuditing
@EnableHystrix
@EnableSwagger2
@EnableServiceAuthorisation
public class Application extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(Application.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
