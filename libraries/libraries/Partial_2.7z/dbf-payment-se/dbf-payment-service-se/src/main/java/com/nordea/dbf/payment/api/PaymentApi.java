package com.nordea.dbf.payment.api;

import com.nordea.dbf.api.model.*;
import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.annotation.Audit;
import com.nordea.dbf.authz.PaymentsAuthZ;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.AcceptedException;
import com.nordea.dbf.payment.model.SignatureItemId;
import com.nordea.dbf.security.Claims;
import io.swagger.annotations.*;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.List;

@Api
@RestController
public interface PaymentApi {

    String BASE_PATH = "/payments";
    String PAYMENT_ID_REGEX = "\\d+|\\d{4}-\\d{2}-\\d{2}-\\d{2}\\.\\d{2}\\.\\d{2}\\.\\d{6}:[A-Za-z]{3}:\\d{3,34}";

    @ApiOperation(
            value = "creates a new payment",
            tags = "payments",
            response = Payment.class)
    @RequestMapping(
            value = BASE_PATH,
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    DeferredResult<Payment> createPayment(
            @RequestBody @ApiParam(name = "paymentRequest",
                    value = "The payload",
                    required = true) PaymentRequest paymentRequest,
            @ApiParam(name = "serviceRequestContext", value = "serviceRequestContext", hidden = true) ServiceRequestContext serviceRequestContext,
            @ApiParam(hidden = true) Claims claims,
            @ApiParam(hidden = true) PaymentsAuthZ paymentsAuthZ);


    @ApiOperation(
            value = "updates an existing payment",
            tags = "payments",
            response = Payment.class)
    @RequestMapping(
            value = BASE_PATH + "/{paymentId:" + PAYMENT_ID_REGEX + "}",
            method = RequestMethod.PATCH,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    DeferredResult<Payment> updatePayment(
            @ApiParam(name = "paymentId",
                    value = "The id of the payment",
                    required = true,
                    examples = @Example({
                            @ExampleProperty(mediaType = "paymentId", value = "2010-01-02-03.04.05.06.123456"),
                            @ExampleProperty(mediaType = "paymentId", value = "12345"),
                            @ExampleProperty(mediaType = "paymentId", value = "123456789012")}))
            @PathVariable("paymentId") String paymentId,
            @RequestBody @ApiParam(value = "The payload", required = true) PaymentRequest paymentRequest,
            @ApiParam(name = "serviceRequestContext", value = "serviceRequestContext", hidden = true) ServiceRequestContext serviceRequestContext,
            @ApiParam(hidden = true) Claims claims,
            @ApiParam(hidden = true) PaymentsAuthZ paymentsAuthZ);


    @ApiOperation(
            value = "changes an existing payment",
            tags = "payments",
            response = Payment.class)
    @RequestMapping(
            value = BASE_PATH + "/{paymentId:" + PAYMENT_ID_REGEX + "}",
            method = RequestMethod.PUT,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    DeferredResult<Payment> changePayment(
            @ApiParam(name = "paymentId",
                    value = "The id of the payment",
                    required = true,
                    examples = @Example({
                            @ExampleProperty(mediaType = "paymentId", value = "2010-01-02-03.04.05.06.123456:SEK:123"),
                            @ExampleProperty(mediaType = "paymentId", value = "12345"),
                            @ExampleProperty(mediaType = "paymentId", value = "123456789012")}))
            @PathVariable("paymentId") String paymentId,
            @RequestBody @ApiParam(value = "The payload", required = true) PaymentRequest paymentRequest,
            @ApiParam(name = "serviceRequestContext", value = "serviceRequestContext", hidden = true) ServiceRequestContext serviceRequestContext,
            @ApiParam(hidden = true) Claims claims,
            @ApiParam(hidden = true) PaymentsAuthZ paymentsAuthZ);


    @ApiOperation(
            value = "confirms one or several payments",
            tags = "payments",
            response = MultipleIdsResponse.class)
    @RequestMapping(
            value = BASE_PATH + "/confirm",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    DeferredResult<ResponseEntity<MultipleIdsResponse>> confirmPayments(
            @RequestBody PaymentConfirmationRequest paymentConfirmationRequest,
            @ApiParam(name = "serviceRequestContext", value = "serviceRequestContext", hidden = true) ServiceRequestContext serviceRequestContext,
            @ApiParam(hidden = true) Claims claims,
            @ApiParam(hidden = true) PaymentsAuthZ paymentsAuthZ);

    @ApiOperation(
            value = "confirms/completes an unconfirmed payment",
            tags = "payments",
            response = MultiplePaymentsResponse.class)
    @RequestMapping(
            value = BASE_PATH + "/complete/{orderId}",
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    DeferredResult<ResponseEntity<MultiplePaymentsResponse>> completePayment(
            @ApiParam(name = "orderId",
                    value = "The id of the order to be completed")
            @PathVariable("orderId") String orderId,
            @ApiParam(name = "serviceRequestContext", value = "serviceRequestContext", hidden = true) ServiceRequestContext serviceRequestContext,
            @ApiParam(hidden = true) Claims claims,
            @ApiParam(hidden = true) PaymentsAuthZ paymentsAuthZ);

    @ApiOperation(
            value = "gets all payments that satisfies the provided conditions",
            tags = "payments",
            response = Payment.class)
    @Audit(description = "Gets a list of payments as per specification {0}, {1}, {2}, {3}, {4}, {5}", category = AuditCategory.BOOKKEEP)
    @RequestMapping(
            value = BASE_PATH,
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    DeferredResult<List<Payment>> getPayments(
            @ApiParam(name = "status",
                    value = "a comma separated list of statuses",
                    allowableValues = "unconfirmed, confirmed, rejected, stopped, inprogress",
                    allowMultiple = true,
                    example = "unconfirmed")
            @RequestParam(value = "status", required = false) List<String> statuses,
            @ApiParam(name = "risks",
                    value = "a comma separated list of risks",
                    allowMultiple = true)
            @RequestParam(value = "risk", required = false) List<String> risks,
            @ApiParam(name = "due",
                    value = "the due date, must match either of the following regex: " +
                            "(?:before\\()(\\d{4}(-\\d{2}(-\\d{2})?)?)(?:\\)), " +
                            "(?:after\\()(\\d{4}(-\\d{2}(-\\d{2})?)?)(?:\\)) or " +
                            "(?:between\\()(\\d{4}(?:-\\d{2}(?:-\\d{2})?)?)(?:,\\s*)(\\d{4}(?:-\\d{2}(?:-\\d{2})?)?)(?:\\))",
                    examples = @Example(value = {
                            @ExampleProperty(mediaType = "before", value = "before(2014-05-23)"),
                            @ExampleProperty(mediaType = "after", value = "after(2015-09-12)"),
                            @ExampleProperty(mediaType = "between", value = "between(2015-02-03, 2016-03-16)")}))
            @RequestParam(value = "due", required = false) String dateFilterExpression,
            @ApiParam(name = "from",
                    value = "a comma separated list of account numbers",
                    allowMultiple = true,
                    example = "NAID-SE-SEK-32580077936")
            @RequestParam(value = "from", required = false) List<String> accountKeysAsStrings,
            @ApiParam(name = "id",
                    value = "the id of a payment, similar to GET /banking/payments/{paymentId} but will not fetch " +
                            "additional data. Must match the following regex: " + PAYMENT_ID_REGEX,
                    examples = @Example({
                            @ExampleProperty(mediaType = "paymentId", value = "2010-01-02-03.04.05.06.123456"),
                            @ExampleProperty(mediaType = "paymentId", value = "12345"),
                            @ExampleProperty(mediaType = "paymentId", value = "123456789012")}))
            @RequestParam(value = "id", required = false) String paymentId,
            @ApiParam(name = "type",
                    value = "a comma separated list of the type of payment",
                    allowableValues = "plusgiro, bankgiro, owntransfer, lban, einvoice, crossborder, normal, partner, sepa_direct_depit, salary, pension",
                    allowMultiple = true)
            @RequestParam(value = "type", required = false) List<String> paymentTypes,
            @ApiParam(name = "serviceRequestContext", value = "serviceRequestContext", hidden = true) ServiceRequestContext serviceRequestContext,
            @ApiParam(hidden = true) Claims claims,
            @ApiParam(hidden = true) PaymentsAuthZ paymentsAuthZ);


    @ApiOperation(
            value = "gets a detailed description of an existing payment",
            tags = "payments",
            response = Payment.class)
    @RequestMapping(
            value = BASE_PATH + "/{paymentId:" + PAYMENT_ID_REGEX + "}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    DeferredResult<Payment> getPaymentById(
            @ApiParam(name = "paymentId",
                    value = "paymentId",
                    required = true,
                    examples = @Example({
                            @ExampleProperty(mediaType = "paymentId", value = "2010-01-02-03.04.05.06.123456"),
                            @ExampleProperty(mediaType = "paymentId", value = "12345"),
                            @ExampleProperty(mediaType = "paymentId", value = "123456789012")}))
            @PathVariable("paymentId") String paymentId,
            @ApiParam(name = "serviceRequestContext", value = "serviceRequestContext", hidden = true) ServiceRequestContext serviceRequestContext,
            @ApiParam(hidden = true) Claims claims,
            @ApiParam(hidden = true) PaymentsAuthZ paymentsAuthZ);


    @ApiOperation(
            value = "deletes a payment",
            tags = "payments",
            response = Payment.class)
    @RequestMapping(
            value = BASE_PATH + "/{paymentId:" + PAYMENT_ID_REGEX + "}",
            method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    DeferredResult<Payment> deletePayment(
            @ApiParam(name = "paymentId",
                    value = "paymentId",
                    required = true,
                    examples = @Example({
                            @ExampleProperty(mediaType = "paymentId", value = "2010-01-02-03.04.05.06.123456"),
                            @ExampleProperty(mediaType = "paymentId", value = "12345"),
                            @ExampleProperty(mediaType = "paymentId", value = "123456789012")}))
            @PathVariable("paymentId") String paymentId,
            @ApiParam(name = "serviceRequestContext", value = "serviceRequestContext", hidden = true) ServiceRequestContext serviceRequestContext,
            @ApiParam(hidden = true) Claims claims,
            @ApiParam(hidden = true) PaymentsAuthZ paymentsAuthZ);
}
