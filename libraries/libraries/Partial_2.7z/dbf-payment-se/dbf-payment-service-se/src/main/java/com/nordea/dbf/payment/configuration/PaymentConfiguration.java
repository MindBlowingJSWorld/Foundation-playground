package com.nordea.dbf.payment.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.agreement.AgreementDomainFacade;
import com.nordea.dbf.agreement.customer.se.AgreementTypeConverter;
import com.nordea.dbf.agreement.customer.se.CustomerAgreementIntegrator;
import com.nordea.dbf.agreement.customer.se.CustomerAgreementRequestFactory;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.customer.accounts.se.CustomerAccountFacade;
import com.nordea.dbf.customer.accounts.se.integration.CustomerAccountAgreeementsTypeConverter;
import com.nordea.dbf.customer.accounts.se.integration.CustomerAccountAgreementRequestFactory;
import com.nordea.dbf.customer.accounts.se.integration.CustomerAccountIntegrator;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.integration.connect.ims.Configurations;
import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.dbf.integration.connect.ims.f9.F9ImsConnector;
import com.nordea.dbf.integration.connect.ims.f9.F9ImsConnectorImpl;
import com.nordea.dbf.integration.connect.ims.jca.JCAConnectionSupplier;
import com.nordea.dbf.integration.connect.lx.BackendWrapper;
import com.nordea.dbf.integration.connect.lx.DefaultBackendWrapper;
import com.nordea.dbf.integration.connect.lx.LxConnector;
import com.nordea.dbf.integration.connect.lx.LxConnectorImpl;
import com.nordea.dbf.integration.http.HttpClientObservableWrapper;
import com.nordea.dbf.payment.CorporatePaymentFacade;
import com.nordea.dbf.payment.HouseholdPaymentFacade;
import com.nordea.dbf.payment.OwnTransferFacade;
import com.nordea.dbf.payment.common.validators.CorporatePaymentValidator;
import com.nordea.dbf.payment.common.validators.HouseholdPaymentValidator;
import com.nordea.dbf.payment.common.validators.OwntransferPaymentValidator;
import com.nordea.dbf.payment.integration.customer.CustomerAuthorizedAccountsAdapter;
import com.nordea.dbf.payment.service.PaymentService;
import com.nordea.dbf.signing.integration.SigningFacade;
import com.nordea.dbf.signing.integration.SigningFacadeImpl;
import com.nordea.dbf.signing.integration.signing.SigningIntegration;
import com.nordea.sc.jca.BackendInteractionSpec;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import com.nordea.serviceconsumer.providers.JCAConnectionProvider;
import com.nordea.serviceconsumer.providers.defaults.JCAConnectionProviderImpl;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import java.net.URI;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;

import static com.google.common.base.Predicates.or;
import static springfox.documentation.builders.PathSelectors.regex;

@Configuration
@PropertySource(value = {"classpath:payment.properties", "classpath:common.properties"}, ignoreResourceNotFound = true)
public class PaymentConfiguration {

    @Autowired
    private Environment environment;

    @Value("${ndf.signing.url}")
    private String signingUrl;

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2).apiInfo(
                new ApiInfoBuilder()
                        .description("Swagger specification of the API")
                        .title("Payments service")
                        .contact(new Contact("Foundation Team SE", "https://confluence.oneadr.net:8443/display/DBNS/07.+Foundation+SE", "dlcomNSFoundationSE@nordea.com"))
                        .build()
        )
                .directModelSubstitute(LocalDate.class, String.class)
                .directModelSubstitute(LocalDateTime.class, String.class)
                .useDefaultResponseMessages(false)
                .forCodeGeneration(true)
                .ignoredParameterTypes(ServiceRequestContext.class)
                .select()
                .paths(or(regex("/payments.*")))
                .build();
    }

    @Bean
    HttpClientObservableWrapper httpClientObservableWrapper() {
        CloseableHttpAsyncClient httpAsyncClient = HttpAsyncClients.custom().build();
        httpAsyncClient.start();
        return new HttpClientObservableWrapper(httpAsyncClient);
    }

    @Bean
    public SigningIntegration signingIntegration(HttpClientObservableWrapper httpClientObservableWrapper, ObjectMapper objectMapper) {
        return new SigningIntegration(httpClientObservableWrapper, objectMapper, URI.create(signingUrl));
    }

    @Bean
    public SigningFacade signingFacade(SigningIntegration signingIntegration) {
        return new SigningFacadeImpl(signingIntegration);
    }

    @Bean
    public JCAConnectionProvider jcaConnectionProvider() {
        return new JCAConnectionProviderImpl();
    }

    @Bean
    @Autowired
    public JCAConnectionSupplier jcaConnectionSupplier(JCAConnectionProvider jcaConnectionProvider) {
        return () -> jcaConnectionProvider.getConnection(configurationProvider());
    }

    @Bean
    public CustomerAuthorizedAccountsAdapter authorizedAccountsAdapter() {
        return new CustomerAuthorizedAccountsAdapter();
    }

    @Bean
    public LxConnector lxJcaConnector() {
        return new LxConnectorImpl(configurationProvider(), "jca", backendWrapper());
    }

    @Bean
    public CustomerAccountIntegrator customerAccountIntegrator(LxConnector lxJcaConnector) {
        return new CustomerAccountIntegrator(lxJcaConnector);
    }

    @Bean
    public CustomerAccountAgreementRequestFactory customerAccountAgreementRequestFactory() {
        return new CustomerAccountAgreementRequestFactory();
    }

    @Bean
    public CustomerAccountAgreeementsTypeConverter customerAccountAgreeementsTypeConverter() {
        return new CustomerAccountAgreeementsTypeConverter();
    }

    @Bean
    public CustomerAccountFacade customerAccountFacade(CustomerAccountIntegrator customerAccountIntegrator,
                                                       CustomerAccountAgreementRequestFactory customerAccountAgreementRequestFactory,
                                                       CustomerAccountAgreeementsTypeConverter customerAccountAgreeementsTypeConverter) {
        return new CustomerAccountFacade(customerAccountIntegrator, customerAccountAgreementRequestFactory, customerAccountAgreeementsTypeConverter);
    }

    @Bean
    public BackendWrapper backendWrapper() {
        return new DefaultBackendWrapper();
    }

    //FIXME: If this is required, use to retrieve bank information as early as possible.
    @Bean
    @Autowired
    public F9ImsConnector f9ImsConnectBackendConnector(JCAConnectionSupplier jcaConnectionSupplier, ImsConfigurationSupplier imsConfigurationSupplier) {
        return new F9ImsConnectorImpl(jcaConnectionSupplier, imsConfigurationSupplier);
    }

    @Bean
    public ImsConfigurationSupplier imsConfigurationSupplier() {
        final boolean debug = Arrays.asList(environment.getActiveProfiles()).contains("debug");

        final ImsConfiguration.Builder baseConfiguration = ImsConfiguration.builder()
                .serverIdentifier("seims")
                .debugLog(Boolean.valueOf(configurationProvider().getProperty("jca.debug", String.valueOf(debug))));

        return Configurations.builder()
                .when((req, res) -> Configurations.transactionCodeOf(req).startsWith("ESM")).then(baseConfiguration
                        .backendType(BackendInteractionSpec.BackendType.TYPE_IMS_SE)
                        .build())
                .when((req, res) -> Configurations.transactionCodeOf(req).startsWith("ESC")).then(baseConfiguration
                        .backendType(BackendInteractionSpec.BackendType.TYPE_IMS_SE)
                        .build())
                .when((req, res) -> true).then(baseConfiguration
                        .backendType(BackendInteractionSpec.BackendType.TYPE_GENERIC)
                        .build())
                .build();
    }

    @Bean
    @Autowired
    public LegacyBankInfoFacade legacyBankInfoProvider(F9ImsConnector connector) {
        return new LegacyBankInfoFacade(connector);
    }

    @Bean
    public ConfigurationProvider configurationProvider() {
        return new ConfigurationProvider() {
            @Override
            public String getProperty(String key, String defaultValue) {
                return environment.getProperty(key, defaultValue);
            }

            @Override
            public String getProperty(String key) {
                return environment.getProperty(key);
            }
        };
    }

    @Bean
    @Autowired
    public CustomerAgreementIntegrator customerAgreementIntegrator(LxConnector lxConnector) {
        return new CustomerAgreementIntegrator(lxConnector);
    }

    @Bean
    public CustomerAgreementRequestFactory customerAgreementRequestFactory() {
        return new CustomerAgreementRequestFactory();
    }

    @Bean
    public AgreementTypeConverter agreementTypeConverter() {
        return new AgreementTypeConverter();
    }

    @Bean
    @Autowired
    public AgreementDomainFacade agreementDomainFacade(CustomerAgreementIntegrator customerAgreementIntegrator,
                                                       CustomerAgreementRequestFactory customerAgreementRequestFactory,
                                                       AgreementTypeConverter agreementTypeConverter) {
        return new AgreementDomainFacade(customerAgreementIntegrator, customerAgreementRequestFactory, agreementTypeConverter);
    }

    @Bean
    public PaymentService paymentService() {
        return new PaymentService();
    }

    @Bean
    public HouseholdPaymentFacade householdPaymentFacade() {
        return new HouseholdPaymentFacade();
    }

    @Bean
    public CorporatePaymentFacade corporatePaymentsFacade() {
        return new CorporatePaymentFacade();
    }

    @Bean
    public OwnTransferFacade ownTransferFacade() {
        return new OwnTransferFacade();
    }

    @Bean
    @Autowired
    public LegacyBankInfoFacade legacyBankInfoFacade(F9ImsConnector connector) {
        return new LegacyBankInfoFacade(connector);
    }

    @Bean
    public CorporatePaymentValidator corporatePaymentValidator() {
        return new CorporatePaymentValidator();
    }

    @Bean
    public HouseholdPaymentValidator householdPaymentValidator() {
        return new HouseholdPaymentValidator();
    }

    @Bean
    public OwntransferPaymentValidator owntransferPaymentValidator() {
        return new OwntransferPaymentValidator();
    }
}
