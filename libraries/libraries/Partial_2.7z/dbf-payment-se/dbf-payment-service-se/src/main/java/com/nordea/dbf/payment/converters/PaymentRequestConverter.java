package com.nordea.dbf.payment.converters;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRequest;

import java.math.BigDecimal;

/**
 * Converts Payment objects into PaymentRequests and vice versa.
 */
public class PaymentRequestConverter {

    private static Payment.StatusEnum toPaymentStatus(PaymentRequest.StatusEnum paymentStatus) {
        if (paymentStatus != null) {
            return Payment.StatusEnum.valueOf(paymentStatus.toString());
        } else {
            return null;
        }
    }

    public static Payment toPayment(PaymentRequest paymentRequest) {
        final Payment payment = new Payment()
                .setAmount(BigDecimal.valueOf(paymentRequest.getAmount()))
                .setId(paymentRequest.getId())
                .setStatus(toPaymentStatus(paymentRequest.getStatus()))
                .setCurrency(paymentRequest.getCurrency())
                .setDue(paymentRequest.getDue())
                .setFrom(paymentRequest.getFrom())
                .setMessage(paymentRequest.getMessage())
                .setOwnMessage(paymentRequest.getOwnMessage())
                .setRecurring(paymentRequest.getRecurring())
                .setRecipientName(paymentRequest.getRecipientName())
                .setTo(paymentRequest.getTo());

        if (paymentRequest.getCrossBorder() != null) {
            payment.setCrossBorder(paymentRequest.getCrossBorder());
        }

        if (paymentRequest.getSpeed() != null) {
            payment.setSpeed(Payment.SpeedEnum.valueOf(paymentRequest.getSpeed().name()));
        }

        if (paymentRequest.getType() != null) {
            payment.setType(Payment.TypeEnum.valueOf(paymentRequest.getType().name()));
        }
        return payment;
    }
}
