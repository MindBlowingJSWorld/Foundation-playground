package com.nordea.dbf.payment.integration.bankinfo;

import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseBanksSegment;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.util.Iterator;
import java.util.Optional;

/**
 * Adapter that uses the LegacyBankinfoFacade to retrieve a bank name for a certain account number
 *
 */
@Component
public class BankinfoAdapter {

  @Autowired
  private LegacyBankInfoFacade legacyBankInfoFacade;

  public Optional<String> getBankNameFromBranchId(AccountNumber accountNumber, ServiceRequestContext serviceRequestContext) {
    final Observable<BankInfoResponseRecord> banks = legacyBankInfoFacade.getBanks(serviceRequestContext);
    final BankInfoResponseRecord bankInfoResponseRecord = banks.toBlocking().single();
    final Iterator bankinfos = bankInfoResponseRecord.getBanks();
    final int clearingNo = Integer.parseInt(accountNumber.getAccountNumber().substring(0, 4));
    while (bankinfos.hasNext()) {
      final BankInfoResponseBanksSegment next = (BankInfoResponseBanksSegment)bankinfos.next();
      final int fromClNo = next.getFromClNo();
      final int toClNo = next.getToClNo();
      if (clearingNo >= fromClNo && clearingNo <= toClNo) {
        return Optional.of(next.getBankShortName());
      }
    }
    return Optional.empty();
  }
}
