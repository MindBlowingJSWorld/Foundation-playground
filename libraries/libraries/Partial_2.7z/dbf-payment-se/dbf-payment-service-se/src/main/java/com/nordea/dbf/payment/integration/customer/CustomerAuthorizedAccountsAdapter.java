package com.nordea.dbf.payment.integration.customer;

import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.customer.accounts.se.CustomerAccountFacade;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Implementation of the customer agreement adapter
 */
@Component
public class CustomerAuthorizedAccountsAdapter {

    @Autowired
    private CustomerAccountFacade customerAccountFacade;

    public List<AccountKey> findAuthorizedAccounts(String identifierNumber, ServiceRequestContext serviceRequestContext) {
        try {
            // FIXME: Should this really be blocking?
            return serviceRequestContext.getRequestCache().get("authorizedAccounts", () ->
                    customerAccountFacade.findAuthorizedAccounts(identifierNumber, serviceRequestContext).toBlocking().single());
        } catch (InterruptedException e) {
            throw ErrorResponses.backendErrorException(ErrorResponses.Codes.CANCELLED, "findAuthorizedAccounts",
                    "Interrupted while retrieving authorized customer accounts");
        }
    }

}
