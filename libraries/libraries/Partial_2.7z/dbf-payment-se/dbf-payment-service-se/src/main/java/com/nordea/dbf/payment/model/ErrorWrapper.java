package com.nordea.dbf.payment.model;


import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;

/**
 TODO: Consider moving into core?
 A wrapper to handle returning a single object in the observable flow where errors might occur
 Behaviour:
   -> Will capture all exceptions that is an instance of ErrorResponse without rethrowing
   -> Will rethrow all other exceptions
   -> If using validate to get the object, will throw error if exists
 */
public class ErrorWrapper<T> {
    private final T object;
    private final ErrorResponse error;

    public ErrorWrapper(Throwable error) {
        if (! (error instanceof ErrorResponse)) {
            this.rethrow(error);
        }
        this.error = (ErrorResponse) error;
        this.object = null;
        // If this is a non-mapped exception, treat it as fatal.
    }

    public ErrorWrapper(T obj) {
        this.object = obj;
        this.error = null;
    }

    public boolean hasError() {
        return this.error != null;
    }

    public T getObject() {
        return object;
    }

    public Error getError() {
        return error.getErrorResponse();
    }

    public T validate() {
        if (hasError()) {
            rethrow(error);
        }
        return object;
    }
    // Unchecked rethrow
    @SuppressWarnings("unchecked")
    private <T extends Throwable> RuntimeException rethrow(Throwable error) throws T {
        throw (T) error; // rely on vacuous cast
    }

}
