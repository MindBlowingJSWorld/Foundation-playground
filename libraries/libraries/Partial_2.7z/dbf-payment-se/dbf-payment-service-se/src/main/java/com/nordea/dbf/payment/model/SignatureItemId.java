package com.nordea.dbf.payment.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.nordea.dbf.api.model.ModelEntity;
import com.nordea.dbf.api.model.ModelEntitySerializer;

import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@JsonSerialize(
        using = ModelEntitySerializer.class
)

//FIXME: Replace this class with a dependency to dbf-signing-model once it has been released and can be pulled in on its own (without all of dbf-api-model)
public class SignatureItemId implements ModelEntity {
    @JsonIgnore
    private Set<String> presentFields = new HashSet();
    private String id = null;

    public SignatureItemId() {
    }

    @NotNull
    @JsonProperty("id")
    public String getId() {
        return this.id;
    }

    @JsonProperty("id")
    public SignatureItemId setId(String id) {
        this.id = id;
        this.presentFields.add("id");
        return this;
    }

    public Set<String> getPresentFields() {
        return Collections.unmodifiableSet(this.presentFields);
    }

    public SignatureItemId retainFields(Set<String> fields) {
        if(fields != null) {
            this.presentFields.retainAll(fields);
        }

        return this;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("class SignatureItemId {\n");
        sb.append("  id: ").append(this.id).append("\n");
        sb.append("}\n");
        return sb.toString();
    }

    public int hashCode() {
        byte result = 0;
        int result1 = result + (this.id == null?0:this.id.hashCode());
        return result1;
    }

    public boolean equals(Object obj) {
        if(this == obj) {
            return true;
        } else if(obj == null) {
            return false;
        } else if(!(obj instanceof SignatureItemId)) {
            return false;
        } else {
            SignatureItemId other = (SignatureItemId)obj;
            if(this.id == null) {
                if(other.id != null) {
                    return false;
                }
            } else if(!this.id.equals(other.id)) {
                return false;
            }

            return true;
        }
    }
}
