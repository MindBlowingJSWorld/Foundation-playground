package com.nordea.dbf.payment.resource;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.exception.CommandActionExecutionException;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.nordea.dbf.api.model.*;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.annotation.Audit;
import com.nordea.dbf.authz.PaymentsAuthZ;
import com.nordea.dbf.enums.AAPermission;
import com.nordea.dbf.filter.Filters;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.api.PaymentApi;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.converters.PaymentRequestConverter;
import com.nordea.dbf.payment.service.PaymentService;
import com.nordea.dbf.security.Claims;
import com.nordea.dbf.security.annotation.Cid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.async.DeferredResult;
import rx.Observable;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.nordea.dbf.messaging.Observables.deferredResultOf;

/**
 * Resource that exposes the payment REST end point
 */
@RestController
public class PaymentResource implements PaymentApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentResource.class);

    @Value("${aa.agreements.url}")
    private String aaAgreementsUrl;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private RestTemplate restTemplate;

    @HystrixCommand(groupKey = "HTTP", commandKey = "getAaAgreementsuser")
    public ServiceData createServiceData(ServiceRequestContext serviceRequestContext, Claims claims) {
        String racfId = "";
        if (claims.isSegmentCorporate()) {
            ResponseEntity response = restTemplate.exchange(
                    aaAgreementsUrl + "/agreements/" + serviceRequestContext.getAgreementNumber().get() + "/agreementusers/self",
                    HttpMethod.GET,
                    createHttpEntityWithAuthHeader(serviceRequestContext.getAuthenticationToken().get(), Optional.empty()),
                    Agreementuser.class);
            Agreementuser agreementuser = (Agreementuser) response.getBody();
            racfId = agreementuser.getLegacyUserId();
        }

        return new ServiceData(serviceRequestContext, (String) claims.getAdditionalClaims().get(Cid.ATRRIBUTE_NAME), racfId, claims.getSegment());
    }

    @Override
    @Audit(description = "Create payment as per specification {0}", category = AuditCategory.BOOKKEEP)
    public DeferredResult<Payment> createPayment(@Valid @RequestBody PaymentRequest paymentRequest,
                                                 ServiceRequestContext serviceRequestContext,
                                                 Claims claims,
                                                 PaymentsAuthZ paymentsAuthZ) {
        paymentsAuthZ.checkUseVerifyOrFail(AAPermission.ALLOW);

        Payment payment = PaymentRequestConverter.toPayment(paymentRequest);

        return deferredResultOf(paymentService.createPayment(createServiceData(serviceRequestContext, claims), payment), unwrapHystrixException());
    }

    @Override
    @Audit(description = "Update payment {0} with partial specification {1}", category = AuditCategory.BOOKKEEP)
    public DeferredResult<Payment> updatePayment(@PathVariable("paymentId") String paymentId,
                                                 @RequestBody @NotNull PaymentRequest paymentRequest,
                                                 ServiceRequestContext serviceRequestContext,
                                                 Claims claims,
                                                 PaymentsAuthZ paymentsAuthZ) {
        paymentsAuthZ.checkUseVerifyOrFail(AAPermission.ALLOW);

        Payment payment = PaymentRequestConverter.toPayment(paymentRequest);
        payment.setId(paymentId);

        return deferredResultOf(paymentService.patchPayment(createServiceData(serviceRequestContext, claims), payment), unwrapHystrixException());
    }

    @Override
    @Audit(description = "Change payment as per specification {1}", category = AuditCategory.BOOKKEEP)
    public DeferredResult<Payment> changePayment(@PathVariable("paymentId") String paymentId,
                                                 @Valid @RequestBody PaymentRequest paymentRequest,
                                                 ServiceRequestContext serviceRequestContext,
                                                 Claims claims,
                                                 PaymentsAuthZ paymentsAuthZ) {
        paymentsAuthZ.checkUseVerifyOrFail(AAPermission.ALLOW);

        Payment payment = PaymentRequestConverter.toPayment(paymentRequest);
        payment.setId(paymentId);

        return deferredResultOf(paymentService.changePayment(createServiceData(serviceRequestContext, claims), payment), unwrapHystrixException());
    }

    @Override
    @Audit(description = "Confirm payment as per specification {0}", category = AuditCategory.BOOKKEEP)
    public DeferredResult<ResponseEntity<MultipleIdsResponse>> confirmPayments(@RequestBody PaymentConfirmationRequest paymentConfirmationRequest,
                                                                               ServiceRequestContext serviceRequestContext,
                                                                               Claims claims,
                                                                               PaymentsAuthZ paymentsAuthZ) {
        paymentsAuthZ.checkUseVerifyOrFail(AAPermission.ALLOW);

        return deferredResultOf(paymentService.initiateSigning(createServiceData(serviceRequestContext, claims), paymentConfirmationRequest.getPayments())
                .map(response -> {
                    if (response.getErrors().size() > 0) {
                        // FIXME: Core need to be updated to support this response model as well for different statusCodes. Generic object failure with status code.
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
                    } else {
                        return ResponseEntity.status(HttpStatus.OK).body(response);
                    }
                }), unwrapHystrixException());
    }

    @Override
    @Audit(description = "Complete payment as per specification {0}", category = AuditCategory.BOOKKEEP)
    public DeferredResult<ResponseEntity<MultiplePaymentsResponse>> completePayment(@PathVariable("orderId") String orderId,
                                                                                    ServiceRequestContext serviceRequestContext,
                                                                                    Claims claims,
                                                                                    PaymentsAuthZ paymentsAuthZ) {
        paymentsAuthZ.checkUseVerifyOrFail(AAPermission.ALLOW);

        return deferredResultOf(paymentService.completePayment(createServiceData(serviceRequestContext, claims), orderId)
                .map(p -> {
                    if (p.getErrors().size() > 0) {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(p);
                    } else {
                        return ResponseEntity.status(HttpStatus.CREATED).body(p);
                    }
                }), unwrapHystrixException());
    }

    @Override
    public DeferredResult<List<Payment>> getPayments(@RequestParam(value = "status", required = false) List<String> statuses,
                                                     @RequestParam(value = "risk", required = false) List<String> risks,
                                                     @RequestParam(value = "due", required = false) String dateFilterExpression,
                                                     @RequestParam(value = "from", required = false) List<String> accountKeysAsStrings,
                                                     @RequestParam(value = "id", required = false) String paymentId,
                                                     @RequestParam(value = "type", required = false) List<String> paymentTypes,
                                                     ServiceRequestContext serviceRequestContext,
                                                     Claims claims,
                                                     PaymentsAuthZ paymentsAuthZ) {
        paymentsAuthZ.checkUseVerifyOrFail(AAPermission.ALLOW);

        PaymentFilter paymentFilter = new PaymentFilter();

        if (!StringUtils.isEmpty(paymentId)) {
            paymentFilter.setPaymentId(paymentId);
        }

        if (statuses != null) {
            paymentFilter.setStatuses(statuses);
        }

        if (dateFilterExpression != null) {
            paymentFilter.setDueDate(Filters.dateFilterFrom(dateFilterExpression));
        }

        if (accountKeysAsStrings != null) {
            final List<AccountKey> accountKeys = accountKeysAsStrings.stream()
                    .map(AccountKey::fromString)
                    .collect(Collectors.toList());

            paymentFilter.setFromAccounts(Filters.listFilterOf(accountKeys));
        }

        if (paymentTypes != null) {
            paymentFilter.setPaymentTypes(paymentTypes);
        }

        Observable<List<Payment>> paymentsList;

        try {
            paymentsList = paymentService.getPayments(createServiceData(serviceRequestContext, claims), paymentFilter).single();
        } catch (RuntimeException e) {
            LOGGER.info("Payments could not be retrieved for status={}, risk={}, due={}", statuses, risks, dateFilterExpression, e);
            if (e instanceof HystrixRuntimeException && e.getCause() != null) {
                throw new RuntimeException(e.getCause());
            } else {
                throw e;
            }
        }

        return deferredResultOf(paymentsList, unwrapHystrixException());
    }

    @Override
    public DeferredResult<Payment> getPaymentById(@PathVariable("paymentId") String paymentId,
                                                  ServiceRequestContext serviceRequestContext,
                                                  Claims claims,
                                                  PaymentsAuthZ paymentsAuthZ) {
        paymentsAuthZ.checkUseVerifyOrFail(AAPermission.ALLOW);

        return deferredResultOf(paymentService.getPayment(createServiceData(serviceRequestContext, claims), paymentId).map(pw -> pw.validate()), unwrapHystrixException());
    }

    @Override
    @Audit(description = "Delete payment as per specification {0}", category = AuditCategory.BOOKKEEP)
    public DeferredResult<Payment> deletePayment(@PathVariable("paymentId") String paymentId,
                                                 ServiceRequestContext serviceRequestContext,
                                                 Claims claims,
                                                 PaymentsAuthZ paymentsAuthZ) {
        paymentsAuthZ.checkUseVerifyOrFail(AAPermission.ALLOW);

        return deferredResultOf(paymentService.deletePayment(createServiceData(serviceRequestContext, claims), paymentId), unwrapHystrixException());
    }

    private HttpEntity createHttpEntityWithAuthHeader(String token, Optional<Object> body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.put("Authorization", Collections.singletonList(token));

        if (body.isPresent()) {
            return new HttpEntity(body.get(), headers);
        } else {
            return new HttpEntity(headers);
        }
    }

    private Function<Throwable, Throwable> unwrapHystrixException() {
        return error -> {
            if ((error instanceof HystrixRuntimeException || error instanceof CommandActionExecutionException) && Objects.nonNull(error.getCause())) {
                return error.getCause();
            }
            return error;
        };
    }
}
