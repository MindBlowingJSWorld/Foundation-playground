package com.nordea.dbf.payment.service;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.*;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.AuditLogger;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.filter.Filters;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.InternalServerErrorException;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.http.errorhandling.exception.UnauthorizedException;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseBanksSegment;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseRecord;
import com.nordea.dbf.payment.CorporatePaymentFacade;
import com.nordea.dbf.payment.HouseholdPaymentFacade;
import com.nordea.dbf.payment.OwnTransferFacade;
import com.nordea.dbf.payment.common.PaymentFacade;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.PaymentFilterType;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.validators.CorporatePaymentValidator;
import com.nordea.dbf.payment.common.validators.HouseholdPaymentValidator;
import com.nordea.dbf.payment.common.validators.OwntransferPaymentValidator;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.integration.customer.CustomerAuthorizedAccountsAdapter;
import com.nordea.dbf.payment.model.ErrorWrapper;
import com.nordea.dbf.signing.integration.SigningFacade;
import com.nordea.dbf.signing.integration.signing.impl.PaymentSigningTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.nordea.dbf.payment.converters.helpers.PaymentIdConverter.unWrapId;

public class PaymentService {

    @Autowired
    private AuditLogger auditLogger;

    private static final Logger LOGGER = LoggerFactory.getLogger(PaymentService.class);

    @Autowired
    private SigningFacade signingFacade;

    @Autowired
    private LegacyBankInfoFacade legacyBankInfoFacade;

    @Autowired
    private CustomerAuthorizedAccountsAdapter authorizedAccountsAdapter;

    @Autowired
    private HouseholdPaymentFacade householdPaymentFacade;

    @Autowired
    private CorporatePaymentFacade corporatePaymentFacade;

    @Autowired
    private OwnTransferFacade ownTransferFacade;

    @Autowired
    private CorporatePaymentValidator corporatePaymentValidator;

    @Autowired
    private HouseholdPaymentValidator householdPaymentValidator;

    @Autowired
    private OwntransferPaymentValidator owntransferPaymentValidator;

    private PaymentFacade getPaymentFacade(ServiceData serviceData) {
        return getPaymentFacade(serviceData, null);
    }

    private PaymentFacade getPaymentFacade(ServiceData serviceData, Payment.TypeEnum typeEnum) {
        if (typeEnum != null && typeEnum.equals(Payment.TypeEnum.owntransfer)) {
            return ownTransferFacade;
        }

        if (serviceData.isSegmentHousehold()) {
            return householdPaymentFacade;
        } else if (serviceData.isSegmentCorporate()) {
            return corporatePaymentFacade;
        }
        throw new IllegalArgumentException("The segment : " + serviceData.getSegment() + " is not valid");
    }

    public PaymentValidator getValidator(ServiceData serviceData, Payment payment) {
        if (Payment.TypeEnum.owntransfer.equals(payment.getType())) {
            return owntransferPaymentValidator.clearValidators();
        }
        if (serviceData.isSegmentCorporate()) {
            return corporatePaymentValidator.clearValidators();
        } else {
            return householdPaymentValidator.clearValidators();
        }
    }

    Optional<String> getBankNameFromBranchId(AccountNumber accountNumber, ServiceRequestContext serviceRequestContext) {
        final BankInfoResponseRecord bankInfoResponseRecord = legacyBankInfoFacade.getBanks(serviceRequestContext).toBlocking().single();
        final Iterator bankinfos = bankInfoResponseRecord.getBanks();
        final int clearingNo = Integer.parseInt(accountNumber.getAccountNumber().substring(0, 4));
        while (bankinfos.hasNext()) {
            final BankInfoResponseBanksSegment next = (BankInfoResponseBanksSegment) bankinfos.next();
            final int fromClNo = next.getFromClNo();
            final int toClNo = next.getToClNo();
            if (clearingNo >= fromClNo && clearingNo <= toClNo) {
                return Optional.of(next.getBankShortName());
            }
        }
        return Optional.empty();
    }

    public Observable<Payment> createPayment(ServiceData serviceData, Payment payment) {
        List<AccountKey> authorizedAccounts = authorizedAccountsAdapter.findAuthorizedAccounts(serviceData.getAgreementOwner(), serviceData.getServiceRequestContext());
        authorizedForFromAccount(payment, authorizedAccounts);

        enrichPayment(payment, serviceData.getServiceRequestContext(), authorizedAccounts);

        PaymentValidator paymentValidator = getValidator(serviceData, payment)
                .paymentCreationValidator(payment);
        paymentValidator.addIdEmptyValidator();
        paymentValidator.validate(payment);

        return getPaymentFacade(serviceData, payment.getType()).createPayment(serviceData, payment)
                .single();
    }

    /**
     * Enriches the payment with data that is required for subsequent processing.
     *
     * @param payment               the payment that possibly require enrichment
     * @param serviceRequestContext the serviceRequestContext
     * @param authorizedAccounts    the users authorized own transfer accounts
     */
    void enrichPayment(Payment payment, ServiceRequestContext serviceRequestContext, List<AccountKey> authorizedAccounts) {
        Payment.TypeEnum paymentType = determinePaymentType(payment, authorizedAccounts);
        switch (paymentType) {
            case plusgiro:
            case bankgiro:
            case owntransfer:
            case einvoice:
            case pension:
            case salary:
                payment.setType(paymentType);
                break;
            case lban:
                payment.setType(paymentType);
                Optional<String> lbanBankName = getBankNameFromBranchId(AccountKey.fromString(payment.getTo()).getAccountNumber(), serviceRequestContext);
                payment.setRecipientName(lbanBankName.orElse(""));

                AccountKey toAccount = AccountKey.fromString(payment.getTo());
                if (lbanBankName.isPresent()
                        && "NB".equals(lbanBankName.get())
                        && toAccount.getCountry().isPresent()
                        && "SE".equals(toAccount.getCountry().get())) {
                    transformPaymentIfToAuthorizedAccounts(payment, authorizedAccounts);
                    payment.setTo("NAID-SE-SEK-" + toAccount.getAccountNumber().getAccountNumber()); // Unsure if we are allowed to make this assumption
                }
                break;
            case crossborder:
                payment.setType(paymentType);
                // Check if to account can be mapped to an authorized account. If so we will do own transfer instead.
                toAccount = AccountKey.fromString(payment.getTo());
                toAccount.getBIC().ifPresent(
                        bic -> transformCrossborderPaymentWithinNordea(bic, payment, authorizedAccounts));
                break;
        }
    }

    void transformCrossborderPaymentWithinNordea(String bic, Payment payment, List<AccountKey> authorizedAccounts) {
        if ("NDEASESS".equals(bic)) {
            transformPaymentIfToAuthorizedAccounts(payment, authorizedAccounts);
            Pattern pattern = Pattern.compile("(?<=IBAN-NDEASESS-SE[0-9]{2}3[0-9]{2})[0-9]*");
            Matcher matcher = pattern.matcher(payment.getTo());
            if (matcher.find()) {
                String accountNumber = matcher.group().replaceAll("^0*", ""); // replaceAll could have been avoided had Java supported variable length positive lookbehind
                payment.setTo("NAID-SE-XXX-" + accountNumber);
                if (payment.getType() != Payment.TypeEnum.owntransfer) {
                    payment.setType(Payment.TypeEnum.lban);
                }
            }
        }
    }

    void transformPaymentIfToAuthorizedAccounts(Payment payment, List<AccountKey> authorizedAccounts) {
        for (AccountKey authorizedAccount : authorizedAccounts) {
            String authorizedAccountNumber = authorizedAccount.getAccountNumber().getAccountNumber();
            String toAccountNumber = AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber();

            if (toAccountNumber.endsWith(authorizedAccountNumber) && (null == payment.getDue() || LocalDate.now().equals(payment.getDue()))) {
                payment.setType(Payment.TypeEnum.owntransfer);
                payment.setDue(LocalDate.now());
            }
        }
    }

    private AccountKey authorizedForFromAccount(Payment payment, List<AccountKey> authorizedAccounts) {
        AccountKey from = AccountKey.fromString(payment.getFrom());
        // Match by currency and accountNumber to handle subaccounts
        List<AccountKey> matches = authorizedAccounts.stream().filter(a -> a.getCurrencyCode().equals(from.getCurrencyCode()) &&
                a.getAccountNumber().equals(from.getAccountNumber())).collect(Collectors.toList());
        if (matches.size() != 1) {
            auditLogger.log(AuditCategory.SECURITY, "Attempted to modify payment with non-authorized account \"" + payment.getFrom() + "\" as source account");
            throw new UnauthorizedException(new Error().setError(ErrorResponses.Codes.UNAUTHORIZED).setErrorDescription("payment with non-authorized account"));
        }
        return matches.get(0);
    }

    public Observable<Payment> patchPayment(ServiceData serviceData, Payment partialPayment) {
        return getPayment(serviceData, partialPayment.getId()).map(pw -> {
            Payment payment = pw.validate();
            if (partialPayment.getAmount() != null) {
                payment.setAmount(partialPayment.getAmount());
            }

            if (partialPayment.getDue() != null) {
                payment.setDue(partialPayment.getDue());
            }

            if (partialPayment.getOwnMessage() != null) {
                payment.setOwnMessage(partialPayment.getOwnMessage());
            }

            if (partialPayment.getType() != null) {
                payment.setType(partialPayment.getType());
            }

            PaymentValidator paymentValidator = getValidator(serviceData, payment)
                    .paymentConfirmationValidator(payment)
                    .addDueValidator();
            paymentValidator.validate(payment);

            return payment;
        }).flatMap(payment ->
                // We send payment twice since the same converter also supports changing the from account, which requires the original payment as second parameter
                getPaymentFacade(serviceData).changePayment(serviceData, payment, payment)
        );
    }

    public Observable<Payment> changePayment(ServiceData serviceData, Payment payment) {
        /*
         * TODO: Verify what changes that are valid.
         * Currently the implementation only allows for the following changes on E-invoices
         *    - Due, Message, Own Reference, Amount, From Account.
         */
        List<AccountKey> authorizedAccounts = authorizedAccountsAdapter.findAuthorizedAccounts(serviceData.getAgreementOwner(), serviceData.getServiceRequestContext());
        authorizedForFromAccount(payment, authorizedAccounts);
        Payment.TypeEnum paymentType = determinePaymentType(payment, authorizedAccounts);
        payment.setType(paymentType);

        enrichPayment(payment, serviceData.getServiceRequestContext(), authorizedAccounts);

        PaymentValidator paymentValidator = getValidator(serviceData, payment)
                .paymentConfirmationValidator(payment)
                .addDueValidator();
        paymentValidator.validate(payment);

        /*
           1. Retrieve the existing payment (or 404 if not existing)
           2. Determine if the change is valid based on input
           3. Merge the payments into one, mastered by the input with subsequent fields added by the retrieved one.
           4. Call the subsequent backend service
        */

        // FIXME: Should the service really verify the payment, or leave this to the backend?
        return this.getPayment(serviceData, payment.getId()).flatMap(pw -> {
                    Payment origPayment = pw.validate();
                    return getPaymentFacade(serviceData).changePayment(serviceData, payment, origPayment);
                }
        ).single();
    }

    private Payment.TypeEnum determinePaymentType(Payment payment, List<AccountKey> authorizedAccounts) {
        AccountKey to = AccountKey.fromString(payment.getTo());

        boolean ownBothAccounts = authorizedAccounts.stream().filter(a -> a.getCurrencyCode().equals(to.getCurrencyCode()) &&
                a.getAccountNumber().equals(to.getAccountNumber())).findAny().isPresent();
        return CommonPaymentType.fromPayment(payment, ownBothAccounts);
    }

    public Observable<List<Payment>> getPayments(ServiceData serviceData, PaymentFilter paymentFilter) {
        // GetPayments is complicated by the following factors:
        /*
            1. Different solutions for corporate / household
            2. Backends have different support for filtering
            3. Filtering is always applied based on authorized accounts, and is handled differently.
            4. Some bugs exist in the backend implementations.
            5. Continuation keys are spread across multiple backends. . .

            To supply a consistent filtering experience the filtering is applied when applicable for the backend,
            but the Payment list is always filtered before returning it to end users.
         */
        List<AccountKey> authorizedAccounts = authorizedAccountsAdapter.findAuthorizedAccounts(serviceData.getAgreementOwner(), serviceData.getServiceRequestContext());
        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.FROM_ACCOUNT)) {
            ListFilter<AccountKey> fromAccounts = paymentFilter.getFromAccounts();
            // Ensure that the filters supplied are valid ones.
            List<AccountKey> filteredAccounts = new ArrayList<>();
            for (AccountKey accountKey : fromAccounts.getValues()) {
                filteredAccounts.addAll(authorizedAccounts.stream().filter(a -> a.getCurrencyCode().equals(accountKey.getCurrencyCode()) &&
                        a.getAccountNumber().equals(accountKey.getAccountNumber())).collect(Collectors.toList()));
            }

            authorizedAccounts = filteredAccounts;
        }
        // TODO: This won't give errors when trying to filter on unauthorized accounts, only skip them as input for the filtering. Possibly the right solution, otherwise users can "fish" account numbers.
        if (authorizedAccounts.isEmpty()) {
            return Observable.just(Collections.emptyList());
        }
        paymentFilter.setFromAccounts(Filters.listFilterOf(authorizedAccounts));

        // FIXME: This is not the ideal solution as we might still send down for example private pg accounts. The solution in the if-block below is to regarded as temporary to fix ABENDs in the backend when we send down too long account numbers belonging to private accounts
        if (serviceData.isSegmentCorporate()) {
            List<AccountKey> accounts = paymentFilter.getFromAccounts().getValues();
            List<AccountKey> corporateAccounts = accounts.stream().filter(accountKey -> accountKey.getAccountNumber().getAccountNumber().length() >= 2
                    && accountKey.getAccountNumber().getAccountNumber().length() <= 8).collect(Collectors.toList());
            paymentFilter.setFromAccounts(Filters.listFilterOf(corporateAccounts));
        }
        return getPaymentFacade(serviceData).getPayments(serviceData, paymentFilter)
                // Sort result by due date. Business rule.
                .map(this::sortByDueDate);

    }

    private List<Payment> sortByDueDate(List<Payment> list) {
        list.sort((a, b) -> {
            if (a.getDue() == null) {
                return -1;
            }
            if (b.getDue() == null) {
                return 1;
            }
            return a.getDue().compareTo(b.getDue());
        });
        return list;
    }


    public Observable<ErrorWrapper<Payment>> getPayment(ServiceData serviceData, String paymentId) {
        // FIXME: This is to have a consistent way of filtering accounts, should this be changed ?
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setPaymentId(paymentId);
        if (serviceData.isSegmentCorporate()) {
            isCorporateUserAuthorizedForPayment(serviceData, paymentId);
            Payment payment = new Payment();
            payment.setId(paymentId);
            return corporatePaymentFacade.getPayment(serviceData, payment).map(ErrorWrapper::new).onErrorReturn(ErrorWrapper::new);
        } else {
            // FIXME: For HH we can also go directly towards the detail transactions. However the HH implementation currently relies on type, perhaps refactor and go to all types transactions?
            return getPayments(serviceData, paymentFilter).map(paymentList -> {
                if (paymentList.isEmpty()) {
                    LOGGER.error("Payment '{}' not found. Responding with a 404/Not found.", paymentId);
                    throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(paymentId))));
                } else if (paymentList.size() > 1) {
                    LOGGER.warn("Request for payment '{}' resulted in more than one (1) result. Responding with a 500/Internal server error.", paymentId);
                    throw new InternalServerErrorException(new Error().setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR).setErrorDescription("Payment data inconsistency"));
                }
                return paymentList.get(0);
            }).map(ErrorWrapper::new).onErrorReturn(ErrorWrapper::new);
        }
    }

    private void isCorporateUserAuthorizedForPayment(ServiceData serviceData, String paymentId) {
        Payment unWrappedPayment = new Payment();
        unWrappedPayment.setId(paymentId);
        unWrapId(unWrappedPayment);
        List<AccountKey> authorizedAccounts = authorizedAccountsAdapter.findAuthorizedAccounts(serviceData.getAgreementOwner(), serviceData.getServiceRequestContext());
        authorizedForFromAccount(unWrappedPayment, authorizedAccounts);
    }

    public Observable<Payment> deletePayment(ServiceData serviceData, String paymentId) {
        return getPayment(serviceData, paymentId)
                .flatMap(pw ->
                        getPaymentFacade(serviceData).deletePayment(serviceData, pw.validate())
                );
    }

    public Observable<MultiplePaymentsResponse> completePayment(ServiceData serviceData, String orderId) {
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setStatuses(Collections.singletonList(Payment.StatusEnum.unconfirmed.name()));
        MultiplePaymentsResponse multiplePaymentsResponse = new MultiplePaymentsResponse();

        return signingFacade.getSigningItem(orderId, serviceData.getServiceRequestContext())
                .map(paymentId -> {
                    if (serviceData.isSegmentCorporate()) {
                        isCorporateUserAuthorizedForPayment(serviceData, paymentId);
                    }
                    return paymentId;
                })
                .flatMap(paymentId -> getPayment(serviceData, paymentId))
                .flatMap(pw -> {
                    PaymentValidator paymentValidator = getValidator(serviceData, pw.getObject())
                            .paymentConfirmationValidator(pw.getObject());
                    paymentValidator.validate(pw.getObject());
                    if (!pw.hasError()) {
                        return getPaymentFacade(serviceData).completePayment(serviceData, pw.getObject()).map(ErrorWrapper::new).onErrorReturn(ErrorWrapper::new);
                    }
                    return Observable.just(pw);
                })
                .map(pw -> {
                    if (pw.hasError()) {
                        multiplePaymentsResponse.getErrors().add(pw.getError());
                    } else {
                        multiplePaymentsResponse.getResults().add(pw.getObject());
                    }
                    return pw;
                })
                .toList()
                .map(completedPayments -> {
                    // TODO: Should the signing be completed if it fails?
                    signingFacade.completeSigning(orderId, serviceData.getServiceRequestContext());
                    return multiplePaymentsResponse;
                })
                ;
    }

    public Observable<MultipleIdsResponse> initiateSigning(ServiceData serviceData, List<String> paymentIds) {
        // TODO: add handling for 4-eye confirmation.
        final Predicate<Payment> paymentHasValidState = p -> p.getStatus().equals(Payment.StatusEnum.unconfirmed);
        final MultipleIdsResponse multipleIdsResponse = new MultipleIdsResponse();

        return Observable.from(paymentIds).flatMap(id ->
                getPayment(serviceData, id)
        ).toList().map(paymentWrappers -> {
            List<ErrorWrapper<PaymentSigningTemplate>> resultList = new ArrayList<>();
            for (ErrorWrapper<Payment> paymentWrapper : paymentWrappers) {
                ErrorWrapper<PaymentSigningTemplate> rtr = null;


                if (paymentWrapper.hasError()) {
                    multipleIdsResponse.getErrors().add(paymentWrapper.getError());
                } else {
                    if (paymentHasValidState.test(paymentWrapper.getObject())) {
                        Payment p = paymentWrapper.getObject();
                        PaymentValidator paymentValidator = getValidator(serviceData, p)
                                .paymentConfirmationValidator(p);
                        paymentValidator.validate(p);
                        PaymentSigningTemplate paymentSigningTemplate = new PaymentSigningTemplate();
                        paymentSigningTemplate.addPayment(p.getId(), p.getType().toString(), p.getAmount().toString(), p.getCurrency(), p.getRecipientName(), p.getTo(), p.getDue().toString(), p.getFrom(), "{  }");
                        rtr = new ErrorWrapper<>(paymentSigningTemplate);
                    } else {
                        multipleIdsResponse.getErrors().add(new Error().setError(ErrorResponses.Types.BAD_REQUEST).setErrorDescription("Payment in invalid state").setDetails(Arrays.asList(new ErrorDetails().setParam(paymentWrapper.getObject().getId()))));
                    }
                }
                resultList.add(rtr);
            }
            return resultList;
        }).flatMap(sigs -> {
            if (multipleIdsResponse.getErrors().size() == 0) {
                return Observable.from(sigs);
            }
            return Observable.empty();
        }).flatMap(sig -> signingFacade.initiateSigning(sig.getObject(), serviceData.getServiceRequestContext()).map(ErrorWrapper::new).onErrorReturn(ErrorWrapper::new))
                .toList().map(signingOrders -> {
                    for (ErrorWrapper<String> signingOrder : signingOrders) {
                        if (signingOrder.hasError()) {
                            multipleIdsResponse.getErrors().add(signingOrder.getError());
                        } else {
                            multipleIdsResponse.getResults().add(signingOrder.getObject());
                        }
                    }
                    return multipleIdsResponse;
                }).defaultIfEmpty(multipleIdsResponse);
    }
}
