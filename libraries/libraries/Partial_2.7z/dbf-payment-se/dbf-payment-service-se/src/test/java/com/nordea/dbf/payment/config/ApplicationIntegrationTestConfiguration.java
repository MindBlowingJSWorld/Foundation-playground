package com.nordea.dbf.payment.config;

import com.nordea.dbf.AAClient;
import com.nordea.dbf.agreement.AgreementDomainFacade;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.payment.CorporatePaymentFacade;
import com.nordea.dbf.payment.HouseholdPaymentFacade;
import com.nordea.dbf.payment.OwnTransferFacade;
import com.nordea.dbf.payment.converters.response.einvoice.EInvoiceToPaymentConverter;
import com.nordea.dbf.payment.integration.bankinfo.BankinfoAdapter;
import com.nordea.dbf.payment.integration.customer.CustomerAuthorizedAccountsAdapter;
import com.nordea.dbf.payment.integrationtest.TestDataManager;
import com.nordea.dbf.payment.signingMock.MockSigningFacade;
import com.nordea.dbf.signing.integration.SigningFacade;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

import static org.mockito.Mockito.mock;

/**
 * Custom application test configuration
 *
 */
@Configuration
public class ApplicationIntegrationTestConfiguration {

    @Bean
    @Primary
    public AAClient aaClient() {
        return mock(AAClient.class);
    }

    @Bean
    @Primary
    public SigningFacade signingFacade() {
        return new MockSigningFacade();
    }

    @Bean
    @Primary
    public AgreementDomainFacade agreementDomainFacade() {
        return mock(AgreementDomainFacade.class);
    }

    @Bean
    @Primary
    public BankinfoAdapter bankinfoAdapter() {
        return mock(BankinfoAdapter.class);
    }

    @Bean
    @Primary
    public LegacyBankInfoFacade legacyBankInfoFacade() {
        return mock(LegacyBankInfoFacade.class);
    }

    @Bean
    @Primary
    public CustomerAuthorizedAccountsAdapter getAuthorizedAccountsAdapter() {
        return mock(CustomerAuthorizedAccountsAdapter.class);
    }

    @Bean
    @Primary
    public EInvoiceToPaymentConverter eInvoiceToPaymentConverter() {
        return new EInvoiceToPaymentConverter();
    }

    @Bean
    public TestDataManager testDataManager() {
        return new TestDataManager();
    }

    @Bean
    @Primary
    public HouseholdPaymentFacade householdPaymentFacade() {
        return mock(HouseholdPaymentFacade.class);
    }

    @Bean
    @Primary
    public CorporatePaymentFacade corporatePaymentsFacade() {
        return mock(CorporatePaymentFacade.class);
    }

    @Bean
    @Primary
    public OwnTransferFacade ownTransferFacade() {
        return mock(OwnTransferFacade.class);
    }

    @Bean
    @Primary
    public RestTemplate restTemplate() {
        return mock(RestTemplate.class);
    }
}
