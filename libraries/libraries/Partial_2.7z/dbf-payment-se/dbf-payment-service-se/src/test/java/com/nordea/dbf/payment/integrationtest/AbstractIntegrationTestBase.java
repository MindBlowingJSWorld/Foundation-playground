package com.nordea.dbf.payment.integrationtest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.AAClient;
import com.nordea.dbf.Permissions;
import com.nordea.dbf.agreement.AgreementDomainFacade;
import com.nordea.dbf.agreement.customer.se.model.*;
import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.authz.PaymentsAuthZ;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.domains.PaymentPermissions;
import com.nordea.dbf.enums.AAPermission;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseBanksSegment;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseRecord;
import com.nordea.dbf.payment.Application;
import com.nordea.dbf.payment.config.ApplicationIntegrationTestConfiguration;
import com.nordea.dbf.payment.converters.response.einvoice.EInvoiceToPaymentConverter;
import com.nordea.dbf.payment.integration.bankinfo.BankinfoAdapter;
import com.nordea.dbf.payment.integration.customer.CustomerAuthorizedAccountsAdapter;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.Resetable;
import com.nordea.dbf.test.annotation.ServiceIntegrationTest;
import com.nordea.dbf.test.http.Path;
import com.nordea.dbf.test.jca.config.JCATestConfiguration;
import com.nordea.dbf.test.rest.Requests;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;
import rx.Observable;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutionException;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = {Application.class, JCATestConfiguration.class, ApplicationIntegrationTestConfiguration.class}) //, AutoMapperTestConfiguration.class})
@WebAppConfiguration
@ServiceIntegrationTest
public abstract class AbstractIntegrationTestBase {
    private static final int TIMEOUT_30s = 30000;

    @Value("${local.server.port}")
    protected int port;

    private String baseUrl;

    protected RestTemplate rest;

    protected Path basePath;

    protected Permissions permissions = mock(Permissions.class);

    @Autowired(required = false)
    private List<Resetable> resetableResources;

    @Autowired
    protected TestDataManager testDataManager;

    @Autowired
    protected AAClient aaClient;

    @Autowired
    protected ObjectMapper objectMapper;

    // Required to support the lookup of the payment (implicit retrieve)
    @Autowired
    protected CustomerAuthorizedAccountsAdapter authorizedAccountsAdapter;

    // This ensures the bankname of the third party transfer can be retrieved.
    @Autowired
    protected BankinfoAdapter bankinfoAdapter;

    @Autowired
    protected EInvoiceToPaymentConverter eInvoiceToPaymentConverter;

    @Autowired
    protected AgreementDomainFacade agreementDomainFacade;

    @Autowired
    private LegacyBankInfoFacade legacyBankInfoFacade;

    @BeforeClass
    public static void configureEnvironment() throws Exception {
        System.setProperty("dbf.domain", "nd.dev");
    }

    @Before
    public void configureRest() {
        if (resetableResources != null) {
            resetableResources.forEach(Resetable::reset);
        }

        RestTemplate restTemplate = new RestTemplate();

        //find and replace Jackson message converter with our own
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter){
                MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter = new MappingJackson2HttpMessageConverter();
                mappingJackson2HttpMessageConverter.setObjectMapper(objectMapper);
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter);
            }
        }

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setConnectTimeout(TIMEOUT_30s);
        requestFactory.setReadTimeout(TIMEOUT_30s);

        restTemplate.setRequestFactory(requestFactory);
        this.rest = restTemplate;

        this.baseUrl = "http://localhost:" + port;
        this.basePath = new Path(baseUrl);

        rest.setErrorHandler(new DefaultResponseErrorHandler());


        Requests.configure(rest);
    }

    @Before
    public void setupTestData() throws InterruptedException, ExecutionException, IOException {
        Agreement corporateAgreement = new Agreement(new UserIdentifierNumber(TestData.CORPORATE_USER_ID), TestData.CORPORATE_USER_ID,
                new AgreementNumber(TestData.CORPORATE_AGREEMENT_ID), AgreementType.CORPORATE, AgreementRole.A);
        Agreement householdAgreement = new Agreement(new UserIdentifierNumber(TestData.HOUSEHOLD_USER_ID), TestData.HOUSEHOLD_USER_ID,
                new AgreementNumber(TestData.HOUSEHOLD_AGREEMENT_ID), AgreementType.PRIVATE, AgreementRole.A);

        when(authorizedAccountsAdapter.findAuthorizedAccounts(eq(TestData.CORPORATE_USER_ID), any(ServiceRequestContext.class)))
                .thenReturn(Collections.singletonList(TestData.CORPORATE_OWN_ACCOUNT));
        when(authorizedAccountsAdapter.findAuthorizedAccounts(eq(TestData.HOUSEHOLD_USER_ID), any(ServiceRequestContext.class)))
                .thenReturn(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.CORPORATE_OWN_ACCOUNT));

        // All can use
        HashMap<String, AAPermission> permissionMap = new HashMap<>();
        permissionMap.put(PaymentPermissions.USE.toString(), AAPermission.ALLOW);
        when(permissions.getRules()).thenReturn(permissionMap);
        PaymentsAuthZ paymentsAuthZ = new PaymentsAuthZ(permissions);
        when(aaClient.getPaymentsAuthZ(any(), any())).thenReturn(paymentsAuthZ);


        when(bankinfoAdapter.getBankNameFromBranchId(any(AccountNumber.class), any(ServiceRequestContext.class)))
                .thenReturn(Optional.empty());

        when(legacyBankInfoFacade.getBanks(any(ServiceRequestContext.class))).thenAnswer(i -> {
            BankInfoResponseRecord bankInfoResponseRecord = new BankInfoResponseRecord();
            BankInfoResponseBanksSegment bankInfoResponseBanksSegment = bankInfoResponseRecord.addBanks();
            bankInfoResponseBanksSegment.setBankName("A Test Bank");
            bankInfoResponseBanksSegment.setBankShortName("ATB");
            bankInfoResponseBanksSegment.setFromClNo(0000);
            bankInfoResponseBanksSegment.setToClNo(9999);
            return Observable.just(bankInfoResponseRecord);
        });

    }
}
