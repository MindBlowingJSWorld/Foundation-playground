package com.nordea.dbf.payment.integrationtest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.api.model.Agreementuser;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.payment.CorporatePaymentFacade;
import com.nordea.dbf.payment.HouseholdPaymentFacade;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.PaymentFilterType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integration.customer.CustomerAuthorizedAccountsAdapter;
import com.nordea.dbf.payment.signingMock.MockSigningFacade;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.signing.integration.signing.impl.PaymentSigningTemplate;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import rx.Observable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

public class TestDataManager {

    @Autowired
    private HouseholdPaymentFacade householdPaymentFacade;

    @Autowired
    private CorporatePaymentFacade corporatePaymentsFacade;

    @Autowired
    private MockSigningFacade signingFacade;

    @Autowired
    private CustomerAuthorizedAccountsAdapter authorizedAccountsAdapter;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private RestTemplate restTemplate;

    public void mockAuthorizedAccounts(AccountKey ... accountKeys) {
        when(authorizedAccountsAdapter.findAuthorizedAccounts(isA(String.class), isA(ServiceRequestContext.class)))
                .thenReturn(Arrays.asList(accountKeys));
    }

    /*public void mockAuthorizedAccounts(AccountKey... accountKeys) {
        when(authorizedAccountsAdapter.findAuthorizedAccounts(any(String.class), any(ServiceRequestContext.class)))
                .thenReturn(Arrays.asList(accountKeys));
    }*/

    public void mockListingOfCorporatePayments(Payment... payments) {
        when(corporatePaymentsFacade.getPayments(isA(ServiceData.class), isA(PaymentFilter.class)))
                .thenAnswer(i -> {
                    PaymentFilter paymentFilter = (PaymentFilter) i.getArguments()[1];
                    if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.PAYMENT_ID)) {
                        return Observable.just(Arrays.asList(payments).stream().filter(p -> p.getId().equals(paymentFilter.getPaymentId())).collect(Collectors.toList()));
                    } else {
                        return Observable.just(Arrays.asList(payments));
                    }
                });
    }

    public void mockListingOfHouseholdPayments(Payment... payments) {
        when(householdPaymentFacade.getPayments(isA(ServiceData.class), isA(PaymentFilter.class)))
                .thenAnswer(i -> {
                    PaymentFilter paymentFilter = (PaymentFilter) i.getArguments()[1];
                    if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.PAYMENT_ID)) {
                        return Observable.just(Arrays.asList(payments).stream().filter(p -> p.getId().equals(paymentFilter.getPaymentId())).collect(Collectors.toList()));
                    } else {
                        return Observable.just(Arrays.asList(payments));
                    }
                });
    }

    public void mockListingWithExceptionCorporate() {
        when(corporatePaymentsFacade.getPayments(isA(ServiceData.class), isA(PaymentFilter.class)))
                .thenThrow(new RuntimeException("Something went wrong!"));
    }

    public void mockListingWithExceptionHousehold() {
        when(householdPaymentFacade.getPayments(any(ServiceData.class), any(PaymentFilter.class)))
                .thenThrow(new RuntimeException("Something went wrong!"));
    }

    // This is primarily to ensure that the thenThrows are cleared since they take precedence over thenAnswer.
    public void reset() {
        Mockito.reset(householdPaymentFacade);
        Mockito.reset(corporatePaymentsFacade);
    }

    public void mockChangeOfHouseholdPayment(Payment payment) {
        when(householdPaymentFacade.changePayment(isA(ServiceData.class), isA(Payment.class), isA(Payment.class)))
                .thenAnswer(i -> {
                    payment.setId(PaymentTestData.getId(AccountKey.fromString(payment.getFrom()), AccountKey.fromString(payment.getTo())));
                    if (payment.getType() != null && payment.getType().equals(Payment.TypeEnum.einvoice)) {
                        payment.setType(Payment.TypeEnum.bankgiro);
                    }
                    return Observable.just(payment);
                });
    }

    public void mockChangeOfCorporatePayment(Payment payment) {
        when(corporatePaymentsFacade.changePayment(isA(ServiceData.class), isA(Payment.class), isA(Payment.class)))
                .thenAnswer(i -> {
                    payment.setId(PaymentTestData.getId(AccountKey.fromString(payment.getFrom()), AccountKey.fromString(payment.getTo())));
                    return Observable.just(payment);
                });
    }

    public void mockListingOfNoCorporatePayments() {
        when(corporatePaymentsFacade.getPayments(isA(ServiceData.class), isA(PaymentFilter.class)))
                .thenAnswer(i -> Observable.just(new ArrayList()));
    }

    public void mockListingOfNoHouseholdPayments() {
        when(householdPaymentFacade.getPayments(isA(ServiceData.class), isA(PaymentFilter.class)))
                .thenAnswer(i -> Observable.just(new ArrayList()));
    }

    public void mockRetrieveOfNoCorporatePayments() {
        when(corporatePaymentsFacade.getPayment(isA(ServiceData.class), isA(Payment.class)))
                .thenThrow(new NotFoundException(new Error()));
    }

    public void mockRetrieveOfCorporatePayment(Payment payment) {
        when(corporatePaymentsFacade.getPayment(isA(ServiceData.class), isA(Payment.class)))
                .thenAnswer(i -> {
                    Payment p = (Payment) i.getArguments()[1];
                    if (p.getId().equals(payment.getId())) {
                        return Observable.just(payment);
                    } else {
                        throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(p.getId()))));
                    }
                });
    }

    public void mockDeletionOfCorporatePayment(Payment payment) {
        when(corporatePaymentsFacade.deletePayment(isA(ServiceData.class), isA(Payment.class)))
                .thenAnswer(i -> Observable.just(payment));
    }

    public void mockDeletionOfHouseholdPayment(Payment payment) {
        when(householdPaymentFacade.deletePayment(isA(ServiceData.class), isA(Payment.class)))
                .thenAnswer(i -> Observable.just(payment));
    }

    public void mockHouseholdPaymentComplete(Payment payment) {
        when(householdPaymentFacade.completePayment(isA(ServiceData.class), isA(Payment.class)))
                .thenAnswer(i -> {
                    payment.setId(PaymentTestData.getId(AccountKey.fromString(payment.getFrom()), AccountKey.fromString(payment.getTo())));
                    payment.setStatus(Payment.StatusEnum.confirmed);
                    return Observable.just(payment);
                });
    }

    public void mockCorporatePaymentComplete(Payment payment) {
        when(corporatePaymentsFacade.completePayment(isA(ServiceData.class), isA(Payment.class)))
                .thenAnswer(i -> {
                    payment.setId(PaymentTestData.getId(AccountKey.fromString(payment.getFrom()), AccountKey.fromString(payment.getTo())));
                    payment.setStatus(Payment.StatusEnum.confirmed);
                    return Observable.just(payment);
                });
    }

    public String mockSignedOrder(Payment p) {
        PaymentSigningTemplate paymentSigningTemplate = new PaymentSigningTemplate();
        paymentSigningTemplate.addPayment(p.getId(), p.getType().toString(), p.getAmount().toString(), p.getCurrency(), "BENEFICIARY NAME", p.getTo(), p.getDue().toString(), p.getFrom(), null);

        return signingFacade.initiateSigning(paymentSigningTemplate, null).toBlocking().single();
    }

    public String mockSignedOrderPending(Payment payment) {
        return signingFacade.createPendingOrder(payment);
    }

    public String mockSignInitiation(Payment p) {
        PaymentSigningTemplate paymentSigningTemplate = new PaymentSigningTemplate();
        paymentSigningTemplate
                .addPayment(p.getId(),
                        p.getType() == null ? "" : p.getType().toString(),
                        p.getAmount().toString(),
                        p.getCurrency(),
                        "BENEFICIARY NAME",
                        p.getTo(),
                        p.getDue().toString(),
                        p.getFrom(),
                        null);

        return signingFacade.createOrderIdForPayment(p);
    }

    public void mockSuccessfulAaAgreementsResponse(String racfId) {
        Agreementuser agreementuser = new Agreementuser();
        agreementuser.setLegacyUserId(racfId);
        mockSuccessfulAaAgreementsResponse(agreementuser);
    }

    public void mockSuccessfulAaAgreementsResponse(Agreementuser agreementuser) {
        ResponseEntity<Agreementuser> responseEntity = new ResponseEntity<>(agreementuser, HttpStatus.OK);
        when(restTemplate.exchange(any(String.class), any(HttpMethod.class), (org.springframework.http.HttpEntity<?>) any(HttpEntity.class), eq(Agreementuser.class)))
                .thenReturn(responseEntity);
    }
}
