package com.nordea.dbf.payment.integrationtest.builder;


import com.nordea.soa.agreementdomain.customeragreementservice.service._1.AgreementType;

public class AgreementTypeBuilder {

    private final AgreementType agreementType = new AgreementType();

    public AgreementTypeBuilder agreementNumber(Integer value) {
        agreementType.setAgreementNumber(value);
        return this;
    }

    public AgreementTypeBuilder agreementOwner(Long value) {
        agreementType.setAgreementOwner(value);
        return this;
    }

    public AgreementTypeBuilder agreementName(String value) {
        agreementType.setAgreementName(value);
        return this;
    }

    public AgreementTypeBuilder agreementKey(String value) {
        agreementType.setAgreementKey(value);
        return this;
    }

    public AgreementTypeBuilder customerRole(String value) {
        agreementType.setCustomerRole(value);
        return this;
    }

    public AgreementType build() {
        return agreementType;
    }

}
