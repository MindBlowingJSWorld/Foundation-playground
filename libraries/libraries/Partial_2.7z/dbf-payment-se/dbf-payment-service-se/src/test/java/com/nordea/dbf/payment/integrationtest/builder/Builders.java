package com.nordea.dbf.payment.integrationtest.builder;

public class Builders {

    public static AgreementTypeBuilder newAgreementType() {
        return new AgreementTypeBuilder();
    }

}
