package com.nordea.dbf.payment.integrationtest.change;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.api.model.PaymentRequest;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.converters.helpers.PaymentIdConverter;
import com.nordea.dbf.payment.integrationtest.AbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.spec.auth.CorporateUser;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;

import java.net.URI;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class ChangePaymentsIntegrationTest extends AbstractIntegrationTestBase {

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testChangeNonExistingPayment() throws Exception {
        testDataManager.mockListingOfHouseholdPayments();
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // given
        final URI uri = basePath.subPath("payments/" + "1234").toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(new PaymentRequest(), HttpMethod.PATCH, uri), Payment.class))
                .isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationChangePgPayment() throws Exception {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        payment.setType(Payment.TypeEnum.plusgiro);
        integrationChange(payment);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationChangeBgPayment() throws Exception {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setType(Payment.TypeEnum.bankgiro);
        integrationChange(payment);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationChange3rdPartyTransfer() throws Exception {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.lban);
        integrationChange(payment);
    }

    private void integrationChange(final Payment payment) throws Exception {
        // when
        String paymentId = payment.getId();
        testDataManager.mockListingOfHouseholdPayments(payment);
        testDataManager.mockChangeOfHouseholdPayment(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");
        // given
        final URI uri = basePath.subPath("payments/" + payment.getId()).toURI();
        final ResponseEntity<Payment> response = rest.exchange(new RequestEntity<>(payment, HttpMethod.PATCH, uri), Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isNotEqualTo(paymentId);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationChangeRecurringPgPayment() throws Exception {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        payment.setRecurring(TestData.PAYMENT_RECURRING);
        payment.setType(Payment.TypeEnum.plusgiro);
        integrationChangeRecurring(payment);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationChangeRecurringBgPayment() throws Exception {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setRecurring(TestData.PAYMENT_RECURRING);
        payment.setType(Payment.TypeEnum.bankgiro);
        integrationChangeRecurring(payment);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationChangeRecurring3rdPartyTransfer() throws Exception {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setRecurring(TestData.PAYMENT_RECURRING);
        payment.setType(Payment.TypeEnum.lban);
        integrationChangeRecurring(payment);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldChangeEInvoiceToBG() {
        //when
        Payment originalPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        originalPayment.setType(Payment.TypeEnum.einvoice);
        String id = originalPayment.getId();
        testDataManager.mockListingOfHouseholdPayments(originalPayment);
        testDataManager.mockChangeOfHouseholdPayment(originalPayment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        //given
        final URI uri = basePath.subPath("payments/" + originalPayment.getId()).toURI();
        final ResponseEntity<Payment> response = rest.exchange(new RequestEntity<>(originalPayment, HttpMethod.PATCH, uri), Payment.class);

        //then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isNotEqualTo(id);
        assertThat(response.getBody().getId()).isNotEqualTo(id);
    }

    private void integrationChangeRecurring(final Payment payment) throws Exception {
        // when
        String id = payment.getId();
        testDataManager.mockListingOfHouseholdPayments(payment);
        testDataManager.mockChangeOfHouseholdPayment(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");
        // given
        final URI uri = basePath.subPath("payments/" + payment.getId()).toURI();
        final ResponseEntity<Payment> response = rest.exchange(new RequestEntity<>(payment, HttpMethod.PATCH, uri), Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isNotEqualTo(id);
        assertThat(response.getBody().getRecurring()).isEqualTo(payment.getRecurring());
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void shouldChangeCrossBorderPayment() {
        // given
        Payment originalPayment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.CROSS_BORDER_ACCOUNT_KEY);
        originalPayment.setType(Payment.TypeEnum.crossborder);
        PaymentIdConverter.wrapId(originalPayment);
        String id = originalPayment.getId();

        testDataManager.mockRetrieveOfCorporatePayment(originalPayment);
        testDataManager.mockChangeOfCorporatePayment(originalPayment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // when
        final URI uri = basePath.subPath("payments/" + originalPayment.getId()).toURI();
        final ResponseEntity<Payment> response = rest.exchange(new RequestEntity<>(originalPayment, HttpMethod.PATCH, uri), Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isNotEqualTo(id);
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void corporateThirdPartyPaymentCanBeChanged() {
        // given
        Payment originalPayment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.THIRD_PARTY_ACCOUNT);
        PaymentIdConverter.wrapId(originalPayment);
        String id = originalPayment.getId();
        originalPayment.setType(Payment.TypeEnum.lban);

        testDataManager.mockRetrieveOfCorporatePayment(originalPayment);
        testDataManager.mockChangeOfCorporatePayment(originalPayment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // when
        final URI uri = basePath.subPath("payments/" + originalPayment.getId()).toURI();
        final ResponseEntity<Payment> response = rest.exchange(new RequestEntity<>(originalPayment, HttpMethod.PATCH, uri), Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isNotEqualTo(id);
    }
}
