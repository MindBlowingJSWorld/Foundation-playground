package com.nordea.dbf.payment.integrationtest.complete;

import com.nordea.dbf.api.model.MultiplePaymentsResponse;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.converters.helpers.PaymentIdConverter;
import com.nordea.dbf.payment.integrationtest.AbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.spec.auth.CorporateUser;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;

import java.net.URI;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.fail;

public class CompletePaymentsIntegrationTest extends AbstractIntegrationTestBase {

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testCompleteHouseholdPgPayment() throws Exception {
        integrationCompleteHousehold(TestData.PG_ACCOUNT);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testCompleteHouseholdBgPayment() throws Exception {
        integrationCompleteHousehold(TestData.BG_ACCOUNT);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testCompleteHousehold3rdPartyTransfer() throws Exception {
        integrationCompleteHousehold(TestData.NORDEA_ACCOUNT_KEY);
    }

    private void integrationCompleteHousehold(final AccountKey accountKey) throws Exception {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey);
        payment.setType(Payment.TypeEnum.lban);
        String id = payment.getId();

        testDataManager.mockListingOfHouseholdPayments(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");
        String orderId = testDataManager.mockSignedOrder(payment);
        testDataManager.mockHouseholdPaymentComplete(payment);

        // when
        final URI uri = basePath.subPath("payments/complete/" + orderId).toURI();

        ResponseEntity<MultiplePaymentsResponse> exchange = rest.exchange(new RequestEntity<>(HttpMethod.POST, uri), MultiplePaymentsResponse.class);

        assertThat(exchange.getStatusCode()).isEqualTo(HttpStatus.CREATED);

        MultiplePaymentsResponse multiplePaymentsResponse = exchange.getBody();
        assertThat(multiplePaymentsResponse.getResults()).hasSize(1);
        assertThat(multiplePaymentsResponse.getErrors()).hasSize(0);
        assertThat(multiplePaymentsResponse.getResults().get(0).getStatus()).isEqualTo(Payment.StatusEnum.confirmed);
        assertThat(multiplePaymentsResponse.getResults().get(0).getId()).isNotEqualTo(id);
    }


    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void testCompleteCorporatePayment() throws Exception {
        integrationCompleteCorporate(TestData.PG_ACCOUNT);
    }

    private void integrationCompleteCorporate(final AccountKey accountKey) throws Exception {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, accountKey);
        PaymentIdConverter.wrapId(payment);
        payment.setType(Payment.TypeEnum.lban);
        String id = payment.getId();

        String orderid = testDataManager.mockSignedOrder(payment);
        testDataManager.mockRetrieveOfCorporatePayment(payment);
        testDataManager.mockCorporatePaymentComplete(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // when
        final URI uri = basePath.subPath("payments/complete/" + orderid).toURI();

        ResponseEntity<MultiplePaymentsResponse> exchange = rest.exchange(new RequestEntity<>(HttpMethod.POST, uri), MultiplePaymentsResponse.class);

        assertThat(exchange.getStatusCode()).isEqualTo(HttpStatus.CREATED);

        MultiplePaymentsResponse multiplePaymentsResponse = exchange.getBody();
        assertThat(multiplePaymentsResponse.getResults()).hasSize(1);
        assertThat(multiplePaymentsResponse.getErrors()).hasSize(0);
        assertThat(multiplePaymentsResponse.getResults().get(0).getStatus()).isEqualTo(Payment.StatusEnum.confirmed);
        assertThat(multiplePaymentsResponse.getResults().get(0).getId()).isNotEqualTo(id);
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void shouldFailOnPendingSignature() throws Exception {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT);

        String orderId = testDataManager.mockSignedOrderPending(payment);

        // when
        final URI uri = basePath.subPath("payments/complete/" + orderId).toURI();

        try {
            rest.exchange(new RequestEntity<>(HttpMethod.POST, uri), MultiplePaymentsResponse.class);
            fail("Expected to fail");
        } catch(HttpServerErrorException e) {
            e.printStackTrace();
        }
    }
}
