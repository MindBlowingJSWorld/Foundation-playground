package com.nordea.dbf.payment.integrationtest.confirm;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.MultipleIdsResponse;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentConfirmationRequest;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.payment.integrationtest.AbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.net.URI;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.fail;

public class ConfirmPaymentsIntegrationTest extends AbstractIntegrationTestBase {

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirmWithFailingBackend() {
        Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);

        testDataManager.mockListingWithExceptionHousehold();
        PaymentConfirmationRequest paymentConfirmationRequest = new PaymentConfirmationRequest();
        paymentConfirmationRequest.getPayments().add(confirmedPayment.getId());

        // when
        final URI uri = basePath.subPath("payments/confirm").toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(paymentConfirmationRequest, HttpMethod.POST, uri), String.class))
                .isInstanceOf(HttpServerErrorException.class).hasMessageContaining("500");

        testDataManager.reset();
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirmNonExistingPayment() {
        Payment secondRequest = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);

        testDataManager.mockListingOfNoHouseholdPayments();
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        PaymentConfirmationRequest paymentConfirmationRequest = new PaymentConfirmationRequest();
        paymentConfirmationRequest.getPayments().add(secondRequest.getId());
        // when
        final URI uri = basePath.subPath("payments/confirm" ).toURI();
        try {
            rest.exchange(new RequestEntity<>(paymentConfirmationRequest, HttpMethod.POST, uri), String.class);
            fail("Should throw a 400 Bad request");
        } catch(HttpClientErrorException e) {
            try {
                MultipleIdsResponse multipleIdsResponse = objectMapper.readValue(e.getResponseBodyAsString(), MultipleIdsResponse.class);
                assertThat(multipleIdsResponse.getResults()).isEmpty();
                assertThat(multipleIdsResponse.getErrors()).hasSize(1);
                Error error = multipleIdsResponse.getErrors().get(0);
                assertThat(error.getError()).isEqualTo(ErrorResponses.Types.NOT_FOUND);
                assertThat(error.getDetails()).hasSize(1);
                assertThat(error.getDetails().get(0).getParam()).isEqualTo(secondRequest.getId());
            } catch (Exception ex) {
                fail("Could not deserialize error response " + e.getResponseBodyAsString());
            }
        }
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirmPayment() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        payment.setType(Payment.TypeEnum.lban);
        testDataManager.mockListingOfHouseholdPayments(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        PaymentConfirmationRequest paymentConfirmationRequest = new PaymentConfirmationRequest();
        paymentConfirmationRequest.getPayments().add(payment.getId());

        // when
        final URI uri = basePath.subPath("payments/confirm").toURI();
        ResponseEntity<String> exchange = rest.exchange(new RequestEntity<>(paymentConfirmationRequest, HttpMethod.POST, uri), String.class);

        assertThat(exchange.getStatusCode()).isEqualTo(HttpStatus.OK);

    }
/*
    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirmWithFailingBackendByPut() {
        Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);

        testDataManager.mockListingWithExceptionHousehold();

        // when
        final URI uri = basePath.subPath("payments/" + confirmedPayment.getId()).toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(confirmedPayment, HttpMethod.PUT, uri), ConfirmationRequired.class))
                .isInstanceOf(HttpServerErrorException.class).hasMessageContaining("500");

        testDataManager.reset();
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirmNonExistingPaymentByPut() {
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        Payment secondRequest = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);

        testDataManager.mockListingOfNoHouseholdPayments();

        // when
        final URI uri = basePath.subPath("payments/" + secondRequest.getId()).toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(secondRequest, HttpMethod.PUT, uri), ConfirmationRequired.class))
        .isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirmPaymentWithChanges() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        Payment secondRequest = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        payment.setId(secondRequest.getId());
        payment.setMessage("This is a difference besides status");

        testDataManager.mockListingOfHouseholdPayments(payment);
        testDataManager.mockChangeOfHouseholdPayment(payment);

        // when
        final URI uri = basePath.subPath("payments/" + secondRequest.getId()).toURI();
        ResponseEntity<Payment> exchange = rest.exchange(new RequestEntity<>(secondRequest, HttpMethod.PUT, uri), Payment.class);

        // This should go to the change flow instead of the confirmation flow
        assertThat(exchange.getStatusCode()).isEqualTo(HttpStatus.OK);

    }


    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirmPgPaymentByPut() throws Exception {
        integrationHouseholdConfirmByPut(TestData.PG_ACCOUNT);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirmBgPaymentByPut() throws Exception {
        integrationHouseholdConfirmByPut(TestData.BG_ACCOUNT);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testHouseholdConfirm3rdPartyTransferByPut() throws Exception {
        integrationHouseholdConfirmByPut(TestData.NORDEA_ACCOUNT_KEY);
    }

    private void integrationHouseholdConfirmByPut(final AccountKey accountKey) throws Exception {
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey);
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey);
        unconfirmedPayment.setId(payment.getId());

        String orderid = testDataManager.mockSignInitiation(payment);
        testDataManager.mockListingOfHouseholdPayments(unconfirmedPayment);

        // when
        final URI uri = basePath.subPath("payments/" + payment.getId()).toURI();

        // Ensure that the confirmation process is initiated.
        ResponseEntity<ConfirmationRequired> exchange = rest.exchange(new RequestEntity<>(payment, HttpMethod.PUT, uri), ConfirmationRequired.class);

        assertThat(exchange.getStatusCode()).isEqualTo(HttpStatus.ACCEPTED);
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void testCorporateConfirmWithFailingBackendByPut() {
        Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);

        testDataManager.mockListingWithExceptionCorporate();

        // when
        final URI uri = basePath.subPath("payments/" + confirmedPayment.getId()).toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(confirmedPayment, HttpMethod.PUT, uri), ConfirmationRequired.class))
            .isInstanceOf(HttpServerErrorException.class).hasMessageContaining("500");

        testDataManager.reset();
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void testCorporateConfirmNonExistingPaymentByPut() {
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        Payment secondRequest = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT);

        testDataManager.mockListingOfNoCorporatePayments();

        // when
        final URI uri = basePath.subPath("payments/" + secondRequest.getId()).toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(secondRequest, HttpMethod.PUT, uri), ConfirmationRequired.class))
            .isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void testCorporateConfirmPaymentWithChanges() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        Payment secondRequest = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        payment.setId(secondRequest.getId());
        payment.setMessage("This is a difference besides status");

        testDataManager.mockListingOfCorporatePayments(payment);
        testDataManager.mockChangeOfCorporatePayment(payment);

        // when
        final URI uri = basePath.subPath("payments/" + secondRequest.getId()).toURI();
        ResponseEntity<Payment> exchange = rest.exchange(new RequestEntity<>(secondRequest, HttpMethod.PUT, uri), Payment.class);

        // This should go to the change flow instead of the confirmation flow
        assertThat(exchange.getStatusCode()).isEqualTo(HttpStatus.OK);

    }


    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void testCorporateConfirmPgPaymentByPut() throws Exception {
        integrationCorporateConfirmByPut(TestData.PG_ACCOUNT);
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void testCorporateConfirmBgPaymentByPut() throws Exception {
        integrationCorporateConfirmByPut(TestData.BG_ACCOUNT);
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void testCorporateConfirm3rdPartyTransferByPut() throws Exception {
        integrationCorporateConfirmByPut(TestData.NORDEA_ACCOUNT_KEY);
    }

    private void integrationCorporateConfirmByPut(final AccountKey accountKey) throws Exception {
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, accountKey);
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, accountKey);
        unconfirmedPayment.setId(payment.getId());

        String orderid = testDataManager.mockSignInitiation(payment);
        testDataManager.mockListingOfCorporatePayments(unconfirmedPayment);

        // when
        final URI uri = basePath.subPath("payments/" + payment.getId()).toURI();

        // Ensure that the confirmation process is initiated.
        ResponseEntity<ConfirmationRequired> exchange = rest.exchange(new RequestEntity<>(payment, HttpMethod.PUT, uri), ConfirmationRequired.class);

        assertThat(exchange.getStatusCode()).isEqualTo(HttpStatus.ACCEPTED);
    }
*/
}
