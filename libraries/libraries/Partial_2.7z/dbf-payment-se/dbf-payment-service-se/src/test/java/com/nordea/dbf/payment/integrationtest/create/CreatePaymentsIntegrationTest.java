package com.nordea.dbf.payment.integrationtest.create;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.HouseholdPaymentFacade;
import com.nordea.dbf.payment.OwnTransferFacade;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integration.customer.CustomerAuthorizedAccountsAdapter;
import com.nordea.dbf.payment.integrationtest.AbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.http.Path;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import rx.Observable;

import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

public class CreatePaymentsIntegrationTest extends AbstractIntegrationTestBase {

    // Required to support the lookup of the payment (implicit retrieve)
    @Autowired
    protected CustomerAuthorizedAccountsAdapter authorizedAccountsAdapter;

    @Autowired
    protected OwnTransferFacade ownTransferFacade;

    @Autowired
    protected HouseholdPaymentFacade householdPaymentFacade;

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldReMapIbanToAuthorizedAccountToOwnTransfer() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.HOUSEHOLD_OWN_ACCOUNT_IBAN_FORMAT);
        payment.setId(null);

        // when
        testDataManager.mockSuccessfulAaAgreementsResponse("123");
        when(authorizedAccountsAdapter.findAuthorizedAccounts(eq(TestData.HOUSEHOLD_USER_ID), any(ServiceRequestContext.class)))
                .thenReturn(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.CORPORATE_OWN_ACCOUNT));
        final String paymentId = "123";
        when(ownTransferFacade.createPayment(any(ServiceData.class), any(Payment.class))).thenAnswer(i -> Observable.just(payment.setId(paymentId)));
        Path path = basePath.subPath("payments");
        final ResponseEntity<Payment> response = rest.exchange(new RequestEntity<>(payment, HttpMethod.POST, path.toURI()), new ParameterizedTypeReference<Payment>() {
        });

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(paymentId);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldReMapIbanToDomestic() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORWEGIAN_ACCOUNT_SEPA);
        payment.setId(null);

        // when
        testDataManager.mockSuccessfulAaAgreementsResponse("123");
        when(authorizedAccountsAdapter.findAuthorizedAccounts(eq(TestData.HOUSEHOLD_USER_ID), any(ServiceRequestContext.class)))
                .thenReturn(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.CORPORATE_OWN_ACCOUNT));
        String paymentId = "123";
        when(householdPaymentFacade.createPayment(any(ServiceData.class), any(Payment.class))).thenAnswer(i -> Observable.just(payment.setId(paymentId)));
        Path path = basePath.subPath("payments");
        final ResponseEntity<Payment> response = rest.exchange(new RequestEntity<>(payment, HttpMethod.POST, path.toURI()), new ParameterizedTypeReference<Payment>() {
        });

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(paymentId);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldNotReMapCrossborderIban() {
        //given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.CROSSBORDER_ACCOUNT_IBAN);
        payment.setId(null);

        //when
        when(authorizedAccountsAdapter.findAuthorizedAccounts(eq(TestData.HOUSEHOLD_USER_ID), any(ServiceRequestContext.class)))
                .thenReturn(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.CORPORATE_OWN_ACCOUNT));
        //when()
    }

    /*
    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void basicCrossBorderPaymentShouldFailWithID() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(HOUSEHOLD_OWN_ACCOUNT, CROSS_BORDER_ACCOUNT_KEY);
        TestDataManager.mockCreateHouseholdCrossborderPayment(jca, payment);
        // The details are retrieved upon success
        TestDataManager.mockRetrieveHouseholdCrossborderPayment(jca, payment);

        // when
        assertThatThrownBy(() -> rest.postForEntity(basePath.subPath("payments").toURI(), payment, Payment.class))
                .isInstanceOf(HttpClientErrorException.class).hasMessageContaining("400");
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void basicCrossBorderPaymentCanBeCreated() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(HOUSEHOLD_OWN_ACCOUNT, NORWEGIAN_ACCOUNT_SEPA);
        TestDataManager.mockCreateHouseholdCrossborderPayment(jca, payment);
        // The details are retrieved upon success
        TestDataManager.mockRetrieveHouseholdCrossborderPayment(jca, payment);

        // ID is not allowed in the request
        Payment paymentCreateRequest = PaymentTestData.getUnconfirmedCrossborderPayment(HOUSEHOLD_OWN_ACCOUNT, NORWEGIAN_ACCOUNT_SEPA);
        paymentCreateRequest.setId(null);

        // when
        final ResponseEntity<Payment> response = rest.postForEntity(basePath.subPath("payments").toURI(), paymentCreateRequest, Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(payment.getId());
        assertThat(response.getBody().getCrossBorder().getCentralBankReportingCode()).isEqualTo("461");
        assertThat(response.getBody().getCurrency()).isEqualTo(payment.getCurrency());
        assertThat(response.getBody().getFrom()).isEqualTo(HOUSEHOLD_OWN_ACCOUNT.toString());
        assertThat(response.getBody().getTo()).isEqualTo(NORWEGIAN_ACCOUNT_SEPA.toString());

        assertThat(response.getBody().getAmount()).isEqualTo(payment.getAmount());
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void ownTransferCanBeCreatedBetweenUserAccounts() throws Exception {
        Payment payment = PaymentTestData.getConfirmedPayment(HOUSEHOLD_OWN_ACCOUNT, CORPORATE_OWN_ACCOUNT);
        TestDataManager.mockCreateOwnTransferPayment(jca, payment);

        final ResponseEntity<Payment> response = rest.postForEntity(basePath.subPath("payments").toURI(),
                payment,
                Payment.class);

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getStatus()).isEqualTo(Payment.StatusEnum.confirmed);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreatePgPayment() throws Exception {
        integrationCreate(PG_ACCOUNT);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreateBgPayment() throws Exception {
        integrationCreate(BG_ACCOUNT);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreate3rdPartyTransfer() throws Exception {
        integrationCreate(NORDEA_ACCOUNT_KEY);
    }

    private void integrationCreate(final AccountKey accountKey) throws Exception {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(HOUSEHOLD_OWN_ACCOUNT, accountKey);
        TestDataManager.mockRetrieveHouseholdPayment(jca, payment);

        final ResponseEntity<Payment> response = rest.postForEntity(basePath.subPath("payments").toString(), payment, Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(payment.getId());
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreateRecurringPgPayment() throws Exception {
        integrationCreateRecurring(PG_ACCOUNT, "PG", PAYMENT_RECURRING);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreateRecurringBgPayment() throws Exception {
        integrationCreateRecurring(BG_ACCOUNT, "BG", PAYMENT_RECURRING);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreateRecurring3rdPartyTransfer() throws Exception {
        integrationCreateRecurring(NORDEA_ACCOUNT_KEY, "NA", PAYMENT_RECURRING);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreateForEverRecurringPgPayment() throws Exception {
        integrationCreateRecurring(PG_ACCOUNT, "PG", PAYMENT_RECURRING_FOR_EVER);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreateForEverRecurringBgPayment() throws Exception {
        integrationCreateRecurring(BG_ACCOUNT, "BG", PAYMENT_RECURRING_FOR_EVER);
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void testIntegrationCreateForEverRecurring3rdPartyTransfer() throws Exception {
        integrationCreateRecurring(NORDEA_ACCOUNT_KEY, "NA", PAYMENT_RECURRING_FOR_EVER);
    }

    private void integrationCreateRecurring(final AccountKey accountKey, final String giroType, final PaymentRecurring recurring) throws Exception {

        // given
        Payment payment = PaymentTestData.getUnconfirmedRecurringPayment(HOUSEHOLD_OWN_ACCOUNT, accountKey, recurring);
        TestDataManager.mockCreateHouseholdPayment(jca, payment);
        // when
        final ResponseEntity<Payment> response = rest.postForEntity(basePath.subPath("payments").toURI(), payment, Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(payment.getId());
        assertThat(response.getBody().getRecurring()).isEqualTo(recurring);
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void shouldCreateCrossBorderPayment() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(CORPORATE_OWN_ACCOUNT, CROSS_BORDER_ACCOUNT_KEY);
        TestDataManager.mockCreateCorporateCrossborderPayment(jca, payment);
        // when
        final ResponseEntity<Payment> response = rest.postForEntity(basePath.subPath("payments").toURI(), payment, Payment.class);
        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(payment.getId());
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void corporatePgPaymentCanBeCreated() throws Exception {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(CORPORATE_OWN_ACCOUNT, PG_ACCOUNT_KEY);
        TestDataManager.mockCreateCorporatePayment(jca, payment);
        // when
        final ResponseEntity<Payment> response = rest.postForEntity(basePath.subPath("payments").toURI(), payment, Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(payment.getId());
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void corporateBgPaymentCanBeCreated() throws Exception {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(CORPORATE_OWN_ACCOUNT, BG_ACCOUNT_KEY);
        TestDataManager.mockCreateCorporatePayment(jca, payment);
        // when
        final ResponseEntity<Payment> response = rest.postForEntity(basePath.subPath("payments").toURI(), payment, Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(payment.getId());
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void corporateThirdPartyPaymentCanBeCreated() throws Exception {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(CORPORATE_OWN_ACCOUNT, NORDEA_ACCOUNT_KEY);
        TestDataManager.mockCreateCorporatePayment(jca, payment);
        // when
        final ResponseEntity<Payment> response = rest.postForEntity(basePath.subPath("payments").toURI(), payment, Payment.class);

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody().getId()).isEqualTo(payment.getId());
    }
*/
}
