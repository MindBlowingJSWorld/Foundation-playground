package com.nordea.dbf.payment.integrationtest.delete;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.converters.helpers.PaymentIdConverter;
import com.nordea.dbf.payment.integrationtest.AbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.spec.auth.CorporateUser;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Test;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;

import java.net.URI;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class DeletePaymentsIntegrationTest extends AbstractIntegrationTestBase {

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void shouldFailOnNonExistingCorporatePayment() {
        // Given
        testDataManager.mockRetrieveOfNoCorporatePayments();
        testDataManager.mockAuthorizedAccounts(AccountKey.fromString("NAID-SE-SEK-179176"));
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // When
        final URI uri = basePath.subPath("payments/{paymentId}").withPathParameter("paymentId", "2016-09-20-13.09.21.781917:SEK:179176").toURI();

        // Then
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(HttpMethod.DELETE, uri), new ParameterizedTypeReference<String>() {
        })).isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void shouldDeleteCorporateThirdPartyPayment() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.THIRD_PARTY_ACCOUNT);
        PaymentIdConverter.wrapId(payment);
        testDataManager.mockRetrieveOfCorporatePayment(payment);
        testDataManager.mockDeletionOfCorporatePayment(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // When
        final URI uri = basePath.subPath("payments/{paymentId}").withPathParameter("paymentId", payment.getId()).toURI();
        final ResponseEntity<Payment> response = rest.exchange(new RequestEntity<>(HttpMethod.DELETE, uri), new ParameterizedTypeReference<Payment>() {
        });

        // Then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        Payment deletedPayment = response.getBody();
        assertThat(deletedPayment.getId()).isEqualTo(payment.getId());
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldFailOnNonExistingHouseholdPayment() {
        // Given
        testDataManager.mockListingOfNoHouseholdPayments();
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // When
        final URI uri = basePath.subPath("payments/{paymentId}").withPathParameter("paymentId", "123123").toURI();

        // Then
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(HttpMethod.DELETE, uri), new ParameterizedTypeReference<String>() {
        }))
                .isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldDeleteHouseholdPayment() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        testDataManager.mockListingOfHouseholdPayments(payment);
        testDataManager.mockDeletionOfHouseholdPayment(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // When
        final URI uri = basePath.subPath("payments/{paymentId}").withPathParameter("paymentId", payment.getId()).toURI();
        ResponseEntity<String> responseEntity = rest.exchange(new RequestEntity<>(HttpMethod.DELETE, uri), new ParameterizedTypeReference<String>() {
        });

        // Then
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
    }
}
