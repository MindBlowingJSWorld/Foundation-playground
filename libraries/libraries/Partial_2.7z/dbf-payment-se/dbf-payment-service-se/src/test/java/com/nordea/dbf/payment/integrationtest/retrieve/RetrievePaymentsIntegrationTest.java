package com.nordea.dbf.payment.integrationtest.retrieve;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.converters.response.einvoice.EInvoiceToPaymentConverter;
import com.nordea.dbf.payment.integrationtest.AbstractIntegrationTestBase;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.testdata.EInvoices;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.http.Path;
import com.nordea.dbf.test.spec.auth.CorporateUser;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Test;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpServerErrorException;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.junit.Assert.assertEquals;

public class RetrievePaymentsIntegrationTest extends AbstractIntegrationTestBase {

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void shouldReturnUnconfirmedPayment() {
        // given
        // TODO: Add more payments
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        testDataManager.mockListingOfCorporatePayments(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");
        // when
        Path path = basePath.subPath("payments").withQueryParameter("status", Payment.StatusEnum.unconfirmed);
        final ResponseEntity<List<Payment>> response = rest.exchange(new RequestEntity<>(HttpMethod.GET, path.toURI()), new ParameterizedTypeReference<List<Payment>>() {
        });
        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);

        final List<Payment> payments = response.getBody();
        assertThat(payments.size()).isEqualTo(1);
        assertThat(payments.get(0).getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(payments.get(0).getDue()).isEqualTo(payment.getDue());
        assertThat(payments.get(0).getAmount()).isEqualTo(payment.getAmount());
        assertThat(payments.get(0).getTo()).isEqualTo(payment.getTo());
        assertThat(payments.get(0).getFrom()).isEqualTo(payment.getFrom());
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void shouldReturnConfirmedPayment() {
        // given
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        // TODO: Add more payments
        testDataManager.mockListingOfCorporatePayments(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // when
        Path path = basePath.subPath("payments").withQueryParameter("status", Payment.StatusEnum.confirmed);
        final ResponseEntity<List<Payment>> response = rest.exchange(new RequestEntity<>(HttpMethod.GET, path.toURI()), new ParameterizedTypeReference<List<Payment>>() {
        });

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);

        final List<Payment> payments = response.getBody();
        assertThat(payments.size()).isEqualTo(1);
        assertThat(payments.get(0).getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(payments.get(0).getDue()).isEqualTo(payment.getDue());
        assertThat(payments.get(0).getAmount()).isEqualTo(payment.getAmount());
        assertThat(payments.get(0).getTo()).isEqualTo(payment.getTo());
        assertThat(payments.get(0).getFrom()).isEqualTo(payment.getFrom());
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void shouldReturnRejectedPayment() {
        // given
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setStatus(Payment.StatusEnum.rejected);
        // TODO: Add more paymentsPaymentRequestTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY)
        testDataManager.mockListingOfCorporatePayments(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");
        // when
        Path path = basePath.subPath("payments").withQueryParameter("status", Payment.StatusEnum.rejected);
        final ResponseEntity<List<Payment>> response = rest.exchange(new RequestEntity<>(HttpMethod.GET, path.toURI()), new ParameterizedTypeReference<List<Payment>>() {
        });
        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);

        final List<Payment> payments = response.getBody();
        assertThat(payments.size()).isEqualTo(1);
        assertThat(payments.get(0).getStatus().toString()).isEqualTo(payment.getStatus().toString());
        // TODO due date not included in the ESC016 out area
        //assertThat(payments[0].getDue()).isEqualTo(payment.getDue());
        assertThat(payments.get(0).getAmount()).isEqualTo(payment.getAmount());
        assertThat(payments.get(0).getTo()).isEqualTo(payment.getTo());
        assertThat(payments.get(0).getFrom()).isEqualTo(payment.getFrom());
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID, agreementOwner = TestData.CORPORATE_USER_ID)
    public void shouldReturnPaymentsOfAllKinds() {
        for (Payment.TypeEnum type : Payment.TypeEnum.values()) {

            // given
            Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY)
                    .setType(type);
            Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY)
                    .setType(type);
            // TODO due date not included in the ESC016 out area
            Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY)
                    .setType(type);
            payment.setStatus(Payment.StatusEnum.rejected);

            testDataManager.mockListingOfCorporatePayments(payment, unconfirmedPayment, confirmedPayment);
            testDataManager.mockSuccessfulAaAgreementsResponse("123");
            // when
            Path path = basePath.subPath("payments");
            final ResponseEntity<List<Payment>> response = rest.exchange(new RequestEntity<>(HttpMethod.GET, path.toURI()), new ParameterizedTypeReference<List<Payment>>() {
            });

            // then
            assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);

            final List<Payment> payments = response.getBody();
            assertThat(payments).hasSize(3);
            payments.forEach(payment1 -> assertEquals(type, payment1.getType()));
        }
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void unconfirmedPaymentsCanBeRetrieved() {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);

        // given
        testDataManager.mockListingOfHouseholdPayments(unconfirmedPayment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // when
        Path path = basePath.subPath("payments").withQueryParameter("status", Payment.StatusEnum.unconfirmed);
        final ResponseEntity<List<Payment>> response = rest.exchange(new RequestEntity<>(HttpMethod.GET, path.toURI()), new ParameterizedTypeReference<List<Payment>>() {
        });

        // then
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);

        final List<Payment> payments = response.getBody();
        assertThat(payments).hasSize(1);

        final Payment payment = payments.get(0);
        assertThat(payment.getId()).isEqualTo(unconfirmedPayment.getId());
        assertThat(payment.getStatus()).isEqualTo(unconfirmedPayment.getStatus());
        assertThat(payment.getDue()).isEqualTo(unconfirmedPayment.getDue());
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void backendErrorShouldCauseInternalServerErrorStatus() {
        // given
        testDataManager.mockListingWithExceptionHousehold();

        try {
            // when
            Path path = basePath.subPath("payments").withQueryParameter("status", Payment.StatusEnum.unconfirmed);
            final ResponseEntity<List<Payment>> response = rest.exchange(new RequestEntity<>(HttpMethod.GET, path.toURI()), new ParameterizedTypeReference<List<Payment>>() {
            });
            fail("backend error should not result in success");
        } catch (HttpServerErrorException e) {

            // then
            assertThat(e.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        testDataManager.reset();
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void allEInvoicesCanBeRetrieved() {
        //FIXME: The jackson serialization of the RestTemplate fails on arrival/entry date due to LocalDateTime
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().setArrivalDate(null).build();
        EInvoiceToPaymentConverter eInvoiceToPaymentConverter = new EInvoiceToPaymentConverter();

        testDataManager.mockListingOfHouseholdPayments(eInvoiceToPaymentConverter.convert(null, eInvoice));
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // When
        Path path = basePath.subPath("payments");
        ResponseEntity<List<Payment>> responseEntity = rest.exchange(new RequestEntity<>(HttpMethod.GET, path.toURI()), new ParameterizedTypeReference<List<Payment>>() {
        });

        // then
        List<Payment> paymentList = responseEntity.getBody();
        assertThat(paymentList).hasSize(1);

        final Payment payment = paymentList.get(0);

        assertThat(payment.getId()).isEqualTo(eInvoice.getInvoiceId());
    }
}
