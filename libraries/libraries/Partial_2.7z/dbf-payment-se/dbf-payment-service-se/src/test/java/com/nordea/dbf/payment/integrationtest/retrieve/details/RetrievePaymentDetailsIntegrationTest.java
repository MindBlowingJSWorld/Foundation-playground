package com.nordea.dbf.payment.integrationtest.retrieve.details;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.converters.response.einvoice.EInvoiceToPaymentConverter;
import com.nordea.dbf.payment.integrationtest.AbstractIntegrationTestBase;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.testdata.EInvoices;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.http.Path;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Test;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;

import static org.assertj.core.api.Assertions.assertThat;

public class RetrievePaymentDetailsIntegrationTest extends AbstractIntegrationTestBase {

    /*
    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldReturn404ForHouseholdPaymentByIdWhenMissing() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);

        TestDataManager.mockListingOfNoEInvoicePayments(jca);
        TestDataManager.mockListingOfNoCrossborderPayments(jca);
        TestDataManager.mockRetrieveNoCrossborderHouseholdPayment(jca);
        TestDataManager.mockListingOfOneHouseholdPayment(jca, payment);
        TestDataManager.mockRetrieveHouseholdPayment(jca, payment);

        // then
        final URI uri = basePath.subPath("banking/payments/" + "123").toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(HttpMethod.GET, uri), new ParameterizedTypeReference<Payment>() {
        })).isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldReturn404ForHouseholdCrossborderPaymentByIdWhenMissing() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORWEGIAN_ACCOUNT_SEPA);

        TestDataManager.mockListingOfNoEInvoicePayments(jca);
        TestDataManager.mockListingOfNoCrossborderPayments(jca);
        TestDataManager.mockRetrieveHouseholdCrossborderPayment(jca, payment);

        // then
        final URI uri = basePath.subPath("banking/payments/" + "123").toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(HttpMethod.GET, uri), new ParameterizedTypeReference<Payment>() {
        })).isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldReturn404ForHouseholdEInvoicePaymentByIdWhenMissing() {
        // given
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().setFromAccount(Long.parseLong(TestData.HOUSEHOLD_OWN_ACCOUNT.getAccountNumber().getAccountNumber())).build();

        TestDataManager.mockListingOfNoCrossborderPayments(jca);
        TestDataManager.mockRetrieveNoCrossborderHouseholdPayment(jca);
        TestDataManager.mockRetrieveOneEInvoicePayment(jca, eInvoice);

        // then
        final URI uri = basePath.subPath("banking/payments/" + "123").toURI();
        assertThatThrownBy(() -> rest.exchange(new RequestEntity<>(HttpMethod.GET, uri), new ParameterizedTypeReference<Payment>() {
        })).isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void clientShouldGetNotFoundIfCrossBorderPaymentDoesNotExist() {
        // given
        TestDataManager.mockCrossborderPaymentNotFound(jca);
        TestDataManager.mockListingOfNoHouseholdPayments(jca);
        TestDataManager.mockListingOfNoEInvoicePayments(jca);

        // when
        try {
            rest.getForEntity(basePath.subPath("banking/payment/32580077936150702130740").toURI(), Payment.class);
            fail("expected 404");
        } catch (HttpClientErrorException e) {
            // then
            assertThat(e.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        }
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void crossBorderPaymentDetailsCanBeRetrievedForHouseholdUser() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORWEGIAN_ACCOUNT_SEPA);

        TestDataManager.mockListingOfNoHouseholdPayments(jca);
        TestDataManager.mockListingOfNoEInvoicePayments(jca);
        TestDataManager.mockRetrieveHouseholdCrossborderPayment(jca, payment);

        // when
        final ResponseEntity<Payment> responseEntity = rest.getForEntity(basePath.subPath("banking/payments/" + payment.getId()).toURI(), Payment.class);

        // then
        assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void shouldReturnPaymentDetailsForUnconfirmedPayments() {
        // given
        TestDataManager.mockListingOfOneConfirmedCorporatePayment(jca, PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY));

        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        TestDataManager.mockListingOfOneUnconfirmedCorporatePayment(jca, payment);
        TestDataManager.mockRetrieveOneUnconfirmedCorporatePayment(jca, payment);
        // when
        final URI targetUrl = UriComponentsBuilder.fromUriString("http://localhost:" + port).path("/banking/payments/" + payment.getId()).build().toUri();
        final Payment createdPayment = rest.getForObject(targetUrl, Payment.class);
        // then
        assertThat(createdPayment.getStatus().toString()).isEqualTo(payment.getStatus().toString());
        assertThat(createdPayment.getDue()).isEqualTo(payment.getDue());
        assertThat(createdPayment.getAmount()).isEqualTo(payment.getAmount());
        assertThat(createdPayment.getTo()).isEqualTo(payment.getTo());
        assertThat(createdPayment.getFrom()).isEqualTo(payment.getFrom());
    }

    @Test
    @CorporateUser(userName = TestData.CORPORATE_USER_ID, agreement = TestData.CORPORATE_AGREEMENT_ID)
    public void shouldReturnPaymentDetailsForConfirmedPayments() {
        // given
        Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        TestDataManager.mockListingOfOneUnconfirmedCorporatePayment(jca, PaymentTestData.getUnconfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY));
        TestDataManager.mockListingOfOneConfirmedCorporatePayment(jca, confirmedPayment);
        // TODO due date not included in the ESC016 out area
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.CORPORATE_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setStatus(Payment.StatusEnum.rejected);
        TestDataManager.mockListingOfOneRejectedCorporatePayment(jca, payment);
        TestDataManager.mockRetrieveOneConfirmedCorporatePayment(jca, confirmedPayment);

        // when
        final URI targetUrl = UriComponentsBuilder.fromUriString("http://localhost:" + port).path("/banking/payments/" + confirmedPayment.getId()).build().toUri();
        final Payment createdPayment = rest.getForObject(targetUrl, Payment.class);
        // then
        assertThat(createdPayment.getAmount()).isEqualTo(confirmedPayment.getAmount());
        assertThat(createdPayment.getFrom()).isEqualTo(confirmedPayment.getFrom());
        assertThat(createdPayment.getTo()).isEqualTo(confirmedPayment.getTo());
    }
*/
    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void invoiceDetailsCanBeRetrieved() {
        // FIXME: The entry date deserialization does not work in the test
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().setArrivalDate(null).build();
        EInvoiceToPaymentConverter eInvoiceToPaymentConverter = new EInvoiceToPaymentConverter();
        Payment einvoicePayment = eInvoiceToPaymentConverter.convert(null, eInvoice);

        testDataManager.mockListingOfHouseholdPayments(einvoicePayment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");

        // When
        Path path = basePath.subPath("/payments/" + einvoicePayment.getId());
        ResponseEntity<Payment> responseEntity = rest.exchange(new RequestEntity<>(HttpMethod.GET, path.toURI()), new ParameterizedTypeReference<Payment>() {
        });

        // then
        final Payment payment = responseEntity.getBody();
        assertThat(payment.getId()).isEqualTo(eInvoice.getInvoiceId());
    }
}
