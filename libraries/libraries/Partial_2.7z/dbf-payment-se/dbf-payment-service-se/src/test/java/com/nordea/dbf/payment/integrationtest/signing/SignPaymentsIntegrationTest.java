package com.nordea.dbf.payment.integrationtest.signing;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.MultipleIdsResponse;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentConfirmationRequest;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.payment.integrationtest.AbstractIntegrationTestBase;
import com.nordea.dbf.payment.model.SignatureItemId;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;

import java.net.URI;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

public class SignPaymentsIntegrationTest extends AbstractIntegrationTestBase {

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldGetOrderIdWhenConfirmingHousehold() {
        final Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.lban);

        testDataManager.mockListingOfHouseholdPayments(payment);
        testDataManager.mockSuccessfulAaAgreementsResponse("123");
        final String orderId = testDataManager.mockSignInitiation(payment);
        PaymentConfirmationRequest paymentConfirmationRequest = new PaymentConfirmationRequest();
        paymentConfirmationRequest.getPayments().add(payment.getId());

        final URI uri = basePath.subPath("/payments/confirm").toURI();

        ResponseEntity<MultipleIdsResponse> multipleIdsResponse =
                rest.exchange(new RequestEntity<>(paymentConfirmationRequest, HttpMethod.POST, uri), MultipleIdsResponse.class);

        assertThat("Should return status 200", multipleIdsResponse.getStatusCode(), is(HttpStatus.OK));
        assertThat("Should have one result", multipleIdsResponse.getBody().getResults().size(), is(1));
        assertThat("Should have no errors", multipleIdsResponse.getBody().getErrors().size(), is(0));
        assertThat("Should return the orderId", multipleIdsResponse.getBody().getResults().get(0), is(orderId));
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldErrorWhenConfirmingNonExistingHousehold() {
        final Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.lban);

        testDataManager.mockListingOfNoHouseholdPayments();
        final String orderId = testDataManager.mockSignInitiation(payment);
        PaymentConfirmationRequest paymentConfirmationRequest = new PaymentConfirmationRequest();
        paymentConfirmationRequest.getPayments().add(payment.getId());

        final URI uri = basePath.subPath("/payments/confirm").toURI();

        try {
            rest.exchange(new RequestEntity<>(paymentConfirmationRequest, HttpMethod.POST, uri), MultipleIdsResponse.class);
            fail("Should throw a 400 Bad request");
        } catch(HttpClientErrorException e) {
            try {
                MultipleIdsResponse multipleIdsResponse = objectMapper.readValue(e.getResponseBodyAsString(), MultipleIdsResponse.class);
                Assertions.assertThat(multipleIdsResponse.getResults()).isEmpty();
                Assertions.assertThat(multipleIdsResponse.getErrors()).hasSize(1);
                Error error = multipleIdsResponse.getErrors().get(0);
                Assertions.assertThat(error.getError()).isEqualTo(ErrorResponses.Types.NOT_FOUND);
                Assertions.assertThat(error.getDetails()).hasSize(1);
                Assertions.assertThat(error.getDetails().get(0).getParam()).isEqualTo(payment.getId());
            } catch (Exception ex) {
                fail("Could not deserialize error response " + e.getResponseBodyAsString());
            }
        }
    }

    @Test
    @HouseholdUser(userName = TestData.HOUSEHOLD_USER_ID, agreement = TestData.HOUSEHOLD_AGREEMENT_ID)
    public void shouldErrorWhenConfirmingNonExistingAndExistingHousehold() {
        final Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        final Payment secondPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.lban);

        testDataManager.mockListingOfHouseholdPayments(payment);

        final String orderId = testDataManager.mockSignInitiation(payment);
        PaymentConfirmationRequest paymentConfirmationRequest = new PaymentConfirmationRequest();
        paymentConfirmationRequest.getPayments().add(payment.getId());
        paymentConfirmationRequest.getPayments().add(secondPayment.getId());

        final URI uri = basePath.subPath("/payments/confirm").toURI();

        try {
            rest.exchange(new RequestEntity<>(paymentConfirmationRequest, HttpMethod.POST, uri), MultipleIdsResponse.class);
            fail("Should throw a 400 Bad request");
        } catch(HttpClientErrorException e) {
            try {
                MultipleIdsResponse multipleIdsResponse = objectMapper.readValue(e.getResponseBodyAsString(), MultipleIdsResponse.class);
                Assertions.assertThat(multipleIdsResponse.getResults()).isEmpty();
                Assertions.assertThat(multipleIdsResponse.getErrors()).hasSize(1);
                Error error = multipleIdsResponse.getErrors().get(0);
                Assertions.assertThat(error.getError()).isEqualTo(ErrorResponses.Types.NOT_FOUND);
                Assertions.assertThat(error.getDetails()).hasSize(1);
                Assertions.assertThat(error.getDetails().get(0).getParam()).isEqualTo(secondPayment.getId());
            } catch (Exception ex) {
                fail("Could not deserialize error response " + e.getResponseBodyAsString());
            }
        }
    }
}
