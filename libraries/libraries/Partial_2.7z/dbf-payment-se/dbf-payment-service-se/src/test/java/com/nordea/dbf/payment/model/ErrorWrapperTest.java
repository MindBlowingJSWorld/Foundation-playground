package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.*;

public class ErrorWrapperTest {
    @Test
    public void testErrorWrapper() {
        String str = "123";
        ErrorWrapper<String> errorWrapper = new ErrorWrapper<>(str);
        assertEquals(str, errorWrapper.validate());
        assertFalse(errorWrapper.hasError());
    }

    @Test
    public void testErrorWrapperRethrow() {
        NullPointerException nullPointerException = new NullPointerException();
        assertThatThrownBy(() ->new ErrorWrapper<>(nullPointerException)).isInstanceOf(NullPointerException.class);
    }

    @Test
    public void testErrorWrapperCapture() {
        NotFoundException notFoundException = new NotFoundException(new Error());
        ErrorWrapper<Object> objectErrorWrapper = new ErrorWrapper<>(notFoundException);
        assertTrue(objectErrorWrapper.hasError());
    }

    @Test
    public void testErrorWrapperCaptureAndRethrow() {
        NotFoundException notFoundException = new NotFoundException(new Error());
        ErrorWrapper<Object> objectErrorWrapper = new ErrorWrapper<>(notFoundException);
        assertTrue(objectErrorWrapper.hasError());
        assertThatThrownBy(() -> objectErrorWrapper.validate()).isInstanceOf(NotFoundException.class);
    }
}
