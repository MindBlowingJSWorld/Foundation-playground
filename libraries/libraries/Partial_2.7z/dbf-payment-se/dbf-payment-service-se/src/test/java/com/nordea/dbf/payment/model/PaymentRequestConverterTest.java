package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRequest;
import org.junit.Before;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentRequestConverterTest {
    final PaymentRequest paymentRequest1 = mock(PaymentRequest.class);
    final PaymentRequest paymentRequest2 = mock(PaymentRequest.class);
    final Payment payment = mock(Payment.class);
    final CrossBorder crossBorder = mock(CrossBorder.class);

    @Before
    public void setup() {
        when(paymentRequest1.getId()).thenReturn("anid");
        when(paymentRequest1.isFieldPresent("id")).thenReturn(true);

        when(paymentRequest2.getAmount()).thenReturn(2d);
        when(paymentRequest2.isFieldPresent("amount")).thenReturn(true);

        when(payment.getAmount()).thenReturn(BigDecimal.ONE);
        when(payment.getId()).thenReturn("apaymentid");
        when(payment.getStatus()).thenReturn(Payment.StatusEnum.inprogress);
        when(payment.getCurrency()).thenReturn("SEK");
        when(payment.getDue()).thenReturn(LocalDate.now());
        when(payment.getFrom()).thenReturn("NAID-SE01-SEK-1234");
        when(payment.getMessage()).thenReturn("Message");
        when(payment.getOwnMessage()).thenReturn("Own message");
        when(payment.getRecurring()).thenReturn(null);
        when(payment.getTo()).thenReturn("NAID-SE01-SEK-2345");
        when(payment.getCrossBorder()).thenReturn(crossBorder);
        when(payment.getSpeed()).thenReturn(Payment.SpeedEnum.normal);
    }

}
