package com.nordea.dbf.payment.resource;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * Created by K306010 on 2016-02-01.
 *
 * Does not test the full resource, but rather the logic that is present in the payment Resource endpoints.
 */

@RunWith(MockitoJUnitRunner.class)
public class PaymentResourceTest {

    @Test
    @Ignore("Reimplement me")
    public void dummyTestToEnsureResourceUnitTestsAreDone() {

    }

}
