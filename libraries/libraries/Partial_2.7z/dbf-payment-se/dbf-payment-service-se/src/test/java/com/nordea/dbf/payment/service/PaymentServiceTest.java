package com.nordea.dbf.payment.service;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

public class PaymentServiceTest {

    private PaymentService paymentService;
    private ServiceRequestContext requestContext;

    @Before
    public void setUp() {
        requestContext = mock(ServiceRequestContext.class);
        paymentService = mock(PaymentService.class);
        doCallRealMethod().when(paymentService).enrichPayment(any(), any(), any());
        doCallRealMethod().when(paymentService).transformCrossborderPaymentWithinNordea(anyString(), any(), any());
    }

    @Test
    public void enrichPaymentShouldNotEnrichPgPayment() {
        //Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);

        // When
        paymentService.enrichPayment(payment, requestContext, new LinkedList<>());

        // Then
        assertEquals(Payment.TypeEnum.plusgiro, payment.getType());
    }

    @Test
    public void enrichPaymentShouldNotEnrichBgPayment() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);

        // When
        paymentService.enrichPayment(payment, requestContext, new LinkedList<>());

        // Then
        assertEquals(Payment.TypeEnum.bankgiro, payment.getType());
    }

    // ------------------------- enrichPayment IBAN
    @Test
    public void enrichPaymentShouldNotEnrichIbanToForeignAccount() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT,
                TestData.CROSSBORDER_ACCOUNT_IBAN);

        // When
        paymentService.enrichPayment(payment, requestContext, new LinkedList<>());

        // Then
        assertEquals(Payment.TypeEnum.crossborder, payment.getType());
        assertEquals(TestData.CROSSBORDER_ACCOUNT_IBAN.toString(), payment.getTo());
    }

    @Test
    public void enrichPaymentShouldEnrichIbanToAuthorizedAccountWithDueDateToday() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT_OTHER,
                TestData.HOUSEHOLD_OWN_ACCOUNT_IBAN_FORMAT);
        payment.setDue(LocalDate.now());
        List<AccountKey> authorizedAccounts = new LinkedList<>();
        authorizedAccounts.add(TestData.HOUSEHOLD_OWN_ACCOUNT);
        authorizedAccounts.add(TestData.HOUSEHOLD_OWN_ACCOUNT_OTHER);

        // When
        paymentService.enrichPayment(payment, requestContext, authorizedAccounts);

        // Then
        assertEquals("NAID-SE-XXX-" + TestData.HOUSEHOLD_OWN_ACCOUNT.getAccountNumber().getAccountNumber(), payment.getTo());
    }

    @Test
    public void enrichPaymentShouldEnrichIbanToAuthorizedAccount() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT_OTHER,
                TestData.HOUSEHOLD_OWN_ACCOUNT_IBAN_FORMAT);
        List<AccountKey> authorizedAccounts = new LinkedList<>();
        authorizedAccounts.add(TestData.HOUSEHOLD_OWN_ACCOUNT);
        authorizedAccounts.add(TestData.HOUSEHOLD_OWN_ACCOUNT_OTHER);
        doCallRealMethod().when(paymentService).transformPaymentIfToAuthorizedAccounts(any(), any());

        // When
        paymentService.enrichPayment(payment, requestContext, authorizedAccounts);

        // Then
        assertEquals("NAID-SE-XXX-" + TestData.HOUSEHOLD_OWN_ACCOUNT.getAccountNumber().getAccountNumber(), payment.getTo());
    }

    @Test
    public void enrichPaymentShouldEnrichIbanToUnAuthorizedNordeaAccount() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT,
                TestData.NORDEA_ACCOUNT_IBAN);
        List<AccountKey> authorizedAccounts = new LinkedList<>();

        // When
        paymentService.enrichPayment(payment, requestContext, authorizedAccounts);

        // Then
        assertEquals(Payment.TypeEnum.lban, payment.getType());
        assertEquals(TestData.NORDEA_ACCOUNT_NAID.toString().replaceFirst("SEK", "XXX"), payment.getTo());
    }

    @Test
    public void enrichPaymentShouldNotEnrichIbanToOtherSwedishBank() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT,
                TestData.CROSSBORDER_ACCOUNT_IBAN);

        // When
        when(paymentService.getBankNameFromBranchId(any(AccountNumber.class), any(ServiceRequestContext.class))).thenReturn(Optional.of("XX"));
        paymentService.enrichPayment(payment, requestContext, new LinkedList<>());

        // Then
        assertEquals(Payment.TypeEnum.crossborder, payment.getType());
        assertEquals(TestData.CROSSBORDER_ACCOUNT_IBAN.toString(), payment.getTo());
    }

    // ------------------------- enrichPayment LBAN
    @Test
    public void enrichPaymentShouldEnrichLbanToAuthorizedAccountWithDueDateToday() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT,
                TestData.NORDEA_ACCOUNT_LBAN);
        payment.setDue(LocalDate.now());
        when(paymentService.getBankNameFromBranchId(any(AccountNumber.class), any(ServiceRequestContext.class))).thenReturn(Optional.of("NB"));
        doCallRealMethod().when(paymentService).transformPaymentIfToAuthorizedAccounts(any(), any());
        List<AccountKey> authorizedAccounts = new LinkedList<>();
        authorizedAccounts.add(TestData.NORDEA_ACCOUNT_NAID);
        authorizedAccounts.add(TestData.HOUSEHOLD_OWN_ACCOUNT);

        // When
        paymentService.enrichPayment(payment, requestContext, authorizedAccounts);

        // Then
        assertEquals(Payment.TypeEnum.owntransfer, payment.getType());
        assertEquals(TestData.NORDEA_ACCOUNT_NAID.toString(), payment.getTo());
    }

    @Test
    public void enrichPaymentShouldPartlyEnrichLbanToAuthorizedAccountWithDueDateInFuture() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT,
                TestData.NORDEA_ACCOUNT_LBAN);
        payment.setDue(LocalDate.MAX);
        when(paymentService.getBankNameFromBranchId(any(AccountNumber.class), any(ServiceRequestContext.class))).thenReturn(Optional.of("NB"));
        doCallRealMethod().when(paymentService).transformPaymentIfToAuthorizedAccounts(any(), any());
        List<AccountKey> authorizedAccounts = new LinkedList<>();
        authorizedAccounts.add(TestData.NORDEA_ACCOUNT_NAID);
        authorizedAccounts.add(TestData.HOUSEHOLD_OWN_ACCOUNT);

        // When
        paymentService.enrichPayment(payment, requestContext, authorizedAccounts);

        // Then
        assertEquals(Payment.TypeEnum.lban, payment.getType());
        assertEquals(TestData.NORDEA_ACCOUNT_NAID.toString(), payment.getTo());
    }

    @Test
    public void enrichPaymentShouldEnrichLbanToUnAuthorizedNordeaAccount() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT,
                TestData.NORDEA_ACCOUNT_LBAN);
        when(paymentService.getBankNameFromBranchId(any(AccountNumber.class), any(ServiceRequestContext.class))).thenReturn(Optional.of("NB"));
        List<AccountKey> authorizedAccounts = new LinkedList<>();

        // When
        paymentService.enrichPayment(payment, requestContext, authorizedAccounts);

        // Then
        assertEquals(Payment.TypeEnum.lban, payment.getType());
        assertEquals(TestData.NORDEA_ACCOUNT_NAID.toString(), payment.getTo());
    }

    @Test
    public void enrichPaymentShouldNotEnrichLbanToOtherSwedishBank() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(
                TestData.HOUSEHOLD_OWN_ACCOUNT,
                TestData.THIRD_PARTY_ACCOUNT);
        when(paymentService.getBankNameFromBranchId(any(AccountNumber.class), any(ServiceRequestContext.class))).thenReturn(Optional.of("SEB"));

        // When
        paymentService.enrichPayment(payment, requestContext, new LinkedList<>());

        // Then
        assertEquals(Payment.TypeEnum.lban, payment.getType());
        assertEquals(TestData.THIRD_PARTY_ACCOUNT.toString(), payment.getTo());
    }

    // ------------------------- transformCrossborderPaymentWithinNordea
    @Test
    public void transformCrossborderPaymentShouldPerformTransformation() {
        // Given
        String bic = "NDEASESS";
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_IBAN);
        doCallRealMethod().when(paymentService).transformPaymentIfToAuthorizedAccounts(any(), any());

        // When
        paymentService.transformCrossborderPaymentWithinNordea(bic, payment, new LinkedList<>());

        // Then
        assertEquals(TestData.NORDEA_ACCOUNT_NAID.toString().replaceAll("SEK", "XXX"), payment.getTo());
        assertEquals(Payment.TypeEnum.lban, payment.getType());
    }

    @Test
    public void transformCrossborderPaymentShouldPerformTransformationWhenToAccountIsOwn() {
        // Given
        String bic = "NDEASESS";
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_IBAN);
        payment.setDue(LocalDate.now());
        doCallRealMethod().when(paymentService).transformPaymentIfToAuthorizedAccounts(any(), any());
        List<AccountKey> authorizedAccounts = new LinkedList<>();
        authorizedAccounts.add(TestData.HOUSEHOLD_OWN_ACCOUNT);
        authorizedAccounts.add(TestData.NORDEA_ACCOUNT_NAID);

        // When
        paymentService.transformCrossborderPaymentWithinNordea(bic, payment, authorizedAccounts);

        // Then
        assertEquals(TestData.NORDEA_ACCOUNT_NAID.toString().replaceAll("SEK", "XXX"), payment.getTo());
        assertEquals(Payment.TypeEnum.owntransfer, payment.getType());
    }

    @Test
    public void transformCrossborderPaymentShouldNotAttemptTransformation() {
        // Given
        String bic = "SWEDSESS";

        // When
        paymentService.transformCrossborderPaymentWithinNordea(bic, null, null);

        // Then
        verify(paymentService, never()).transformPaymentIfToAuthorizedAccounts(any(), any());
    }

    // ------------------------- transformPaymentIfToAuthorizedAccounts
    @Test
    public void transformPaymentBasedOnAuthorizedAccountsShouldTransformPayment() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT_OTHER, TestData.HOUSEHOLD_OWN_ACCOUNT_IBAN_FORMAT);
        payment.setDue(LocalDate.now());
        List<AccountKey> authorizedAccounts = new LinkedList<>();
        authorizedAccounts.add(TestData.NORDEA_ACCOUNT_NAID);
        authorizedAccounts.add(TestData.HOUSEHOLD_OWN_ACCOUNT);
        doCallRealMethod().when(paymentService).transformPaymentIfToAuthorizedAccounts(any(), any());

        // When
        paymentService.transformPaymentIfToAuthorizedAccounts(payment, authorizedAccounts);

        // Then
        assertEquals(Payment.TypeEnum.owntransfer, payment.getType());
    }

    @Test
    public void transformPaymentBasedOnAuthorizedAccountsShouldNotTransformPayment() {
        // Given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT_OTHER, TestData.HOUSEHOLD_OWN_ACCOUNT_IBAN_FORMAT);
        List<AccountKey> authorizedAccounts = new LinkedList<>();
        authorizedAccounts.add(TestData.NORDEA_ACCOUNT_NAID);
        doCallRealMethod().when(paymentService).transformPaymentIfToAuthorizedAccounts(any(), any());

        // When
        paymentService.transformPaymentIfToAuthorizedAccounts(payment, authorizedAccounts);

        // Then
        assertEquals(null, payment.getType());
        assertEquals(TestData.HOUSEHOLD_OWN_ACCOUNT_IBAN_FORMAT.toString(), payment.getTo());
    }
}
