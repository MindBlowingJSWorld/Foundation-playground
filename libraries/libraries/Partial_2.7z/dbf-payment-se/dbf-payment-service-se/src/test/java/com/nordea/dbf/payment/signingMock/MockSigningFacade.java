package com.nordea.dbf.payment.signingMock;

import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BackendException;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.signing.integration.SigningFacade;
import com.nordea.dbf.signing.integration.model.ItemModel;
import com.nordea.dbf.signing.integration.signing.SigningTemplate;
import rx.Observable;

import com.nordea.dbf.api.model.Error;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class MockSigningFacade implements SigningFacade {
    private final static Map<String, ItemModel> mockedSigning = new HashMap<>();
    private final static Map<String, ItemModel> pendingSigning = new HashMap<>();
    private final static Map<String, String> initiateSigning = new HashMap<>();

    @Override
    public Observable<String> initiateSigning(SigningTemplate signingTemplate, ServiceRequestContext serviceRequestContext) {
        ItemModel signingItem = signingTemplate.getSigningItem();
        String uuidString;
        if (initiateSigning.containsKey(signingItem.getItemId())) {
            uuidString = initiateSigning.get(signingItem.getItemId());
        } else {
            uuidString = UUID.randomUUID().toString();
        }
        mockedSigning.put(uuidString, signingItem);

        return Observable.just(uuidString);
    }

    @Override
    public Observable<String> getSigningItem(String signatureId, ServiceRequestContext serviceRequestContext) {
        if (pendingSigning.containsKey(signatureId)) {
            throw new BackendException(new Error().setError(ErrorResponses.Types.BACKEND_ERROR).setErrorDescription("The signing order is not completed ").setDetails(Arrays.asList(new ErrorDetails().setParam(signatureId))));
        }
        return Observable.just(mockedSigning.get(signatureId).getItemId());
    }

    @Override
    public Observable<String> completeSigning(String signatureId, ServiceRequestContext serviceRequestContext) {
        String itemId = "";
        if (! mockedSigning.containsKey(signatureId) && ! pendingSigning.containsKey(signatureId)) {
            throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("The signing request was not found").setDetails(Arrays.asList(new ErrorDetails().setParam(signatureId))));
        }

        if (mockedSigning.containsKey(signatureId)) {
            itemId = mockedSigning.remove(signatureId).getItemId();
        }
        if (pendingSigning.containsKey(signatureId)) {
            throw new BackendException(new Error().setError(ErrorResponses.Types.BACKEND_ERROR).setErrorDescription("The signing order is not completed ").setDetails(Arrays.asList(new ErrorDetails().setParam(signatureId))));
        }

        return Observable.just(itemId);
    }

    public String createPendingOrder(Payment payment) {
        UUID uuid = UUID.randomUUID();
        ItemModel itemModel = new ItemModel();
        itemModel.setItemId(payment.getId());
        pendingSigning.put(uuid.toString(), itemModel);
        return uuid.toString();
    }

    public String createOrderIdForPayment(Payment payment) {
        if (initiateSigning.containsKey(payment.getId())) {
            return initiateSigning.get(payment.getId());
        } else {
            UUID uuid = UUID.randomUUID();
            initiateSigning.put(payment.getId(), uuid.toString());
            return uuid.toString();
        }
    }
}
