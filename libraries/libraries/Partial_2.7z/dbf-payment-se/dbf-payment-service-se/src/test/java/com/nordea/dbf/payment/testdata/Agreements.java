package com.nordea.dbf.payment.testdata;

import com.nordea.dbf.agreement.customer.se.model.*;

public class Agreements {

    private static final long HOUSEHOLD_AGREEMENT1 = 1800191;

    public static Agreement householdAgreement1(String customerId) {
        return new Agreement(new UserIdentifierNumber(customerId), customerId, new AgreementNumber(HOUSEHOLD_AGREEMENT1),
                AgreementType.PRIVATE, AgreementRole.A);
    }

}
