package com.nordea.dbf.payment.testdata;

import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.record.domestic.EInvoiceResponseEInvoicesSegment;
import com.nordea.dbf.payment.record.domestic.EInvoiceResponseRecord;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Currency;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by K306010 on 2016-03-14.
 */
public class EInvoices {
    public static Builder plusgiroInvoice1() {
        return new Builder()
                .setInvoiceId("1234")
                .setInvoicerName("PlusgiroInvoicer1")
                .setMessage("PlusgiroMessage1")
                .setFromAccount(1234)
                .setToAccount(1000)
                .setGiroType("PG")
                .setPaymentId(0)
                .setPaymentStatusCode("NCF")
                .setArrivalDate(LocalDate.parse("2015-06-01"))
                .setUrlHotel("http://localhost")
                .setIsOcr(true)
                .setCurrency(Currency.getInstance("SEK"))
                .setInvoicerId("PG1")
                .setAmount(BigDecimal.valueOf(100d))
                .setOwnReference("PgOwnReference1")
                .setDueDate(LocalDate.parse("2015-06-30"));
    }

    public static class Builder {

        private final EInvoice eInvoice = mock(EInvoice.class);

        public Builder setInvoiceId(String eInvoiceId) {
            when(eInvoice.getInvoiceId()).thenReturn(eInvoiceId);
            return this;
        }

        public Builder setInvoicerName(String name) {
            when(eInvoice.getInvoicerName()).thenReturn(name);
            return this;
        }

        public Builder setMessage(String message) {
            when(eInvoice.getMessage()).thenReturn(message);
            return this;
        }

        public Builder setToAccount(long toAccount) {
            when(eInvoice.getToAccount()).thenReturn(toAccount);
            return this;
        }

        public Builder setTicketType(String ticketType) {
            when(eInvoice.getTicketType()).thenReturn(ticketType);
            return this;
        }

        public Builder setFromAccount(long fromAccount) {
            when(eInvoice.getFromAccount()).thenReturn(fromAccount);
            return this;
        }

        public Builder setPaymentId(long paymentId) {
            when(eInvoice.getPaymentId()).thenReturn(paymentId);
            return this;
        }

        public Builder setOwnCategory(String ownCategory) {
            when(eInvoice.getOwnCategory()).thenReturn(ownCategory);
            return this;
        }

        public Builder setPaymentErrorType(String paymentErrorType) {
            when(eInvoice.getPaymentErrorType()).thenReturn(paymentErrorType);
            return this;
        }

        public Builder setPaymentStatusCode(String code) {
            when(eInvoice.getPaymentStatusCode()).thenReturn(code);
            return this;
        }

        public Builder setDueDate(LocalDate dueDate) {
            when(eInvoice.getDueDate()).thenReturn(dueDate);
            return this;
        }

        public Builder setGiroType(String giroType) {
            when(eInvoice.getGiroType()).thenReturn(giroType);
            return this;
        }

        public Builder setUrlHotel(String urlHotel) {
            when(eInvoice.getUrlHotel()).thenReturn(urlHotel);
            return this;
        }

        public Builder setIsOcr(Boolean isOcr) {
            when(eInvoice.getIsOcr()).thenReturn(isOcr);
            return this;
        }

        public Builder setArrivalDate(LocalDate arrivalDate) {
            when(eInvoice.getArrivalDate()).thenReturn(arrivalDate);
            return this;
        }

        public Builder setCurrency(Currency currency) {
            when(eInvoice.getCurrency()).thenReturn(currency);
            return this;
        }

        public Builder setInvoicerId(String invoicerId) {
            when(eInvoice.getInvoicerId()).thenReturn(invoicerId);
            return this;
        }

        public Builder setOwnReference(String ownReference) {
            when(eInvoice.getOwnReference()).thenReturn(ownReference);
            return this;
        }

        public Builder setAmount(BigDecimal amount) {
            when(eInvoice.getAmount()).thenReturn(amount);
            return this;
        }

        public Builder addTo(EInvoiceResponseRecord responseRecord) {
            final EInvoiceResponseEInvoicesSegment segment = responseRecord.addEInvoices();

            segment.setInvoiceId(eInvoice.getInvoiceId());
            segment.setInvoicerName(eInvoice.getInvoicerName());
            segment.setMessage(eInvoice.getMessage());
            segment.setToAccount(eInvoice.getToAccount());
            segment.setTicketType(eInvoice.getTicketType());
            segment.setFromAccount(eInvoice.getFromAccount());
            segment.setPaymentId(eInvoice.getPaymentId());
            segment.setOwnCategory(eInvoice.getOwnCategory());
            segment.setPaymentErrorType(eInvoice.getPaymentErrorType());
            segment.setPaymentStatusCode(eInvoice.getPaymentStatusCode());
            segment.setDueDate(eInvoice.getDueDate().format(DateTimeFormatter.ISO_LOCAL_DATE));
            segment.setGiroType(eInvoice.getGiroType());
            segment.setUrlHotel(eInvoice.getUrlHotel());
            segment.setIsOcr(eInvoice.getIsOcr());
            segment.setArrivalDate(eInvoice.getArrivalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
            segment.setCurrency(eInvoice.getCurrency().getCurrencyCode());
            segment.setInvoicerId(eInvoice.getInvoicerId());
            segment.setOwnReference(eInvoice.getOwnReference());
            segment.setAmount(eInvoice.getAmount().doubleValue());
            segment.setNewDate(eInvoice.getNewDate() ? "Y" : "N");

            return this;
        }

        public EInvoice build() {
            return eInvoice;
        }
    }
}
