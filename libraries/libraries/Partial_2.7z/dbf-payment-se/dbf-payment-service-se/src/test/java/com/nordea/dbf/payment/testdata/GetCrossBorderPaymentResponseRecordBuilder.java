package com.nordea.dbf.payment.testdata;

import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentResponseMessageRowCollectionSegment;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentResponseRecord;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentResponseUrgencyTypeCollectionSegment;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.List;

public class GetCrossBorderPaymentResponseRecordBuilder {

    private final GetCrossBorderPaymentResponseRecord record;

    private GetCrossBorderPaymentResponseRecordBuilder(GetCrossBorderPaymentResponseRecord record) {
        this.record = record;
    }

    @SuppressWarnings("unchecked")
    public GetCrossBorderPaymentResponseRecordBuilder addUrgencyTypeCollection(GetCrossBorderPaymentResponseUrgencyTypeCollectionSegment segment) {
        try {
            final Field field = GetCrossBorderPaymentResponseRecord.class.getDeclaredField("mUrgencyTypeCollection");
            field.setAccessible(true);

            ((List) field.get(record)).add(segment);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new UnsupportedOperationException("Failed to add segment to record", e);
        }

        return this;
    }

    @SuppressWarnings("unchecked")
    public GetCrossBorderPaymentResponseRecordBuilder addMessageRowCollection(GetCrossBorderPaymentResponseMessageRowCollectionSegment segment) {
        try {
            final Field field = GetCrossBorderPaymentResponseRecord.class.getDeclaredField("mMessageRowCollection");
            field.setAccessible(true);

            ((List) field.get(record)).add(segment);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new UnsupportedOperationException("Failed to add segment to record", e);
        }

        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setBeneficiaryCountry(String newBeneficiaryCountry) {
        record.setBeneficiaryCountry(newBeneficiaryCountry);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setUserId(String newUserId) {
        record.setUserId(newUserId);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setRepeatingRule(String newRepeatingRule) {
        record.setRepeatingRule(newRepeatingRule);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setCustomerType(String newCustomerType) {
        record.setCustomerType(newCustomerType);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setTimeStamp(String newTimeStamp) {
        record.setTimeStamp(newTimeStamp);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setPaymentStatusCode(String newPaymentStatusCode) {
        record.setPaymentStatusCode(newPaymentStatusCode);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setStatusExtensionCode(String newStatusExtensionCode) {
        record.setStatusExtensionCode(newStatusExtensionCode);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setPaymentSubType(int newPaymentSubType) {
        record.setPaymentSubType(newPaymentSubType);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setDebitAmount(BigDecimal newDebitAmount) {
        record.setDebitAmount(newDebitAmount);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setChargesCurrencyAmount(BigDecimal newChargesCurrencyAmount) {
        record.setChargesCurrencyAmount(newChargesCurrencyAmount);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setBankChargesDebitAmount(BigDecimal newBankChargesDebitAmount) {
        record.setBankChargesDebitAmount(newBankChargesDebitAmount);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setBankChargesCurrencyCode(String newBankChargesCurrencyCode) {
        record.setBankChargesCurrencyCode(newBankChargesCurrencyCode);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setMyCategory(String newMyCategory) {
        record.setMyCategory(newMyCategory);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setRecepitCode(String newRecepitCode) {
        record.setRecepitCode(newRecepitCode);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setRate(BigDecimal newRate) {
        record.setRate(newRate);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setFromAccountId(String newFromAccountId) {
        record.setFromAccountId(newFromAccountId);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setInputDate(String newInputDate) {
        record.setInputDate(newInputDate);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setLegacyKey(String newLegacyKey) {
        record.setLegacyKey(newLegacyKey);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setOwnReference(String newOwnReference) {
        record.setOwnReference(newOwnReference);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setFromAccountIdAndCurrency(String newFromAccountIdAndCurrency) {
        record.setFromAccountIdAndCurrency(newFromAccountIdAndCurrency);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setRemitterName(String newRemitterName) {
        record.setRemitterName(newRemitterName);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setRemitterAdress1(String newRemitterAdress1) {
        record.setRemitterAdress1(newRemitterAdress1);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setRemitterAdress2(String newRemitterAdress2) {
        record.setRemitterAdress2(newRemitterAdress2);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setRemitterAdress3(String newRemitterAdress3) {
        record.setRemitterAdress3(newRemitterAdress3);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setExecutionDate(String newExecutionDate) {
        record.setExecutionDate(newExecutionDate);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setReferenceTextF(String newReferenceTextF) {
        record.setReferenceTextF(newReferenceTextF);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setAmount(BigDecimal newAmount) {
        record.setAmount(newAmount);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setCurrency(String newCurrency) {
        record.setCurrency(newCurrency);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setIntermediaryBankAccount(String newIntermediaryBankAccount) {
        record.setIntermediaryBankAccount(newIntermediaryBankAccount);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setIntermediaryBankBIC(String newIntermediaryBankBIC) {
        record.setIntermediaryBankBIC(newIntermediaryBankBIC);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setReceivingBankCountry(String newReceivingBankCountry) {
        record.setReceivingBankCountry(newReceivingBankCountry);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setReceivingBankBIC(String newReceivingBankBIC) {
        record.setReceivingBankBIC(newReceivingBankBIC);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setReceivingBankCode(String newReceivingBankCode) {
        record.setReceivingBankCode(newReceivingBankCode);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setReceivingBankName(String newReceivingBankName) {
        record.setReceivingBankName(newReceivingBankName);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setReceivingBankAddress1(String newReceivingBankAddress1) {
        record.setReceivingBankAddress1(newReceivingBankAddress1);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setReceivingBankAddress2(String newReceivingBankAddress2) {
        record.setReceivingBankAddress2(newReceivingBankAddress2);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setReceivingBankAddress3(String newReceivingBankAddress3) {
        record.setReceivingBankAddress3(newReceivingBankAddress3);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setToAccountId(String newToAccountId) {
        record.setToAccountId(newToAccountId);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setBeneficiaryName(String newBeneficiaryName) {
        record.setBeneficiaryName(newBeneficiaryName);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setBeneficiaryAddress1(String newBeneficiaryAddress1) {
        record.setBeneficiaryAddress1(newBeneficiaryAddress1);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setBeneficiaryAddress2(String newBeneficiaryAddress2) {
        record.setBeneficiaryAddress2(newBeneficiaryAddress2);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setBeneficiaryAddress3(String newBeneficiaryAddress3) {
        record.setBeneficiaryAddress3(newBeneficiaryAddress3);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setChargePaidBy(String newChargePaidBy) {
        record.setChargePaidBy(newChargePaidBy);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setCbrCode(String newCbrCode) {
        record.setCbrCode(newCbrCode);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setUrgencyTypeCount(int newUrgencyTypeCount) {
        record.setUrgencyTypeCount(newUrgencyTypeCount);
        return this;
    }

    public GetCrossBorderPaymentResponseRecordBuilder setMessageRowCount(int newMessageRowCount) {
        record.setMessageRowCount(newMessageRowCount);
        return this;
    }

    public static GetCrossBorderPaymentResponseRecordBuilder instance() {
        final GetCrossBorderPaymentResponseRecord record = new GetCrossBorderPaymentResponseRecord();
        record.initialize();
        return new GetCrossBorderPaymentResponseRecordBuilder(record);
    }

    public static GetCrossBorderPaymentResponseRecordBuilder from(GetCrossBorderPaymentResponseRecord record) {
        return new GetCrossBorderPaymentResponseRecordBuilder(record);
    }

    public GetCrossBorderPaymentResponseRecord build() {
        return record;
    }

}
