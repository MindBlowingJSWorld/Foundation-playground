# Integration

## Purpose

This integration project is used to connect to the backend for a specific service using the automapper and either the osb or jca extension adapters


## Getting started

```sh
$ mvn clean install
```


