package com.nordea.dbf.payment;

import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.InternalServerErrorException;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.messaging.Observables;
import com.nordea.dbf.payment.common.PaymentFacade;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integration.HouseholdPaymentIntegration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import com.nordea.dbf.api.model.Error;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class HouseholdPaymentFacade implements PaymentFacade {
    private static final Logger LOGGER = LoggerFactory.getLogger(HouseholdPaymentFacade.class);

    @Autowired
    private HouseholdPaymentIntegration householdHouseholdPaymentIntegration;

    @Autowired
    private M8ImsConnector m8ImsConnector;

    //DONE
    @Override
    public Observable<Payment> createPayment(ServiceData serviceData, Payment payment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(createPaymentBasedOnType(connection, serviceData, payment)
                // Since only the ID is returned, perform a lookup to get the actual payment.
                .flatMap(createdPayment -> getPayment(serviceData, createdPayment)));
    }

    private Observable<Payment> createPaymentBasedOnType(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        switch (payment.getType()) {
            case plusgiro:
            case bankgiro:
                return householdHouseholdPaymentIntegration.createHouseholdDomesticPayment(connection, serviceData, payment);
            case lban:
                return householdHouseholdPaymentIntegration.createHouseholdThirdPartyPayment(connection, serviceData, payment);
            case crossborder:
                return householdHouseholdPaymentIntegration.createHouseholdCrossBorderPayment(connection, serviceData, payment);
            default:
                throw new IllegalArgumentException("Invalid payment type " + payment.getType());
        }
    }

    @Override
    public Observable<Payment> changePayment(ServiceData serviceData, Payment payment, Payment originalPayment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(changePaymentBasedOnType(connection, serviceData, payment, originalPayment)
                .flatMap(changedPayment -> getPaymentByType(connection, serviceData, changedPayment)));
    }

    private Observable<Payment> changePaymentBasedOnType(M8ImsConnection connection, ServiceData serviceData, Payment payment, Payment originalPayment) {
        switch (originalPayment.getType()) {
            case plusgiro:
            case bankgiro:
                return householdHouseholdPaymentIntegration.changeHouseholdDomesticPayment(connection, serviceData, payment, originalPayment);
            case lban:
                return householdHouseholdPaymentIntegration.changeHouseholdThirdPartyPayment(connection, serviceData, payment, originalPayment);
            case crossborder:
                return householdHouseholdPaymentIntegration.changeHouseholdCrossBorderPayment(connection, serviceData, payment);
            case einvoice:
                return householdHouseholdPaymentIntegration.changeHouseholdEInvoicePayment(connection, serviceData, payment);
            default:
                throw new IllegalArgumentException("Invalid payment type " + payment.getType());
        }
    }

    @Override
    public Observable<Payment> deletePayment(ServiceData serviceData, Payment payment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(deletePaymentBasedOnType(connection, serviceData, payment));
    }

    private Observable<Payment> deletePaymentBasedOnType(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        switch (payment.getType()) {
            case plusgiro:
            case bankgiro:
            case lban:
                return householdHouseholdPaymentIntegration.deleteHouseholdDomesticPayment(connection, serviceData, payment);
            case crossborder:
                return householdHouseholdPaymentIntegration.deleteHouseholdCrossBorderPayment(connection, serviceData, payment);
            case einvoice:
                return householdHouseholdPaymentIntegration.deleteHouseholdEInvoicePayment(connection, serviceData, payment);
            default:
                throw new IllegalArgumentException("Invalid payment type " + payment.getType());
        }
    }

    @Override
    public Observable<Payment> completePayment(ServiceData serviceData, Payment payment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(completePaymentBasedOnType(connection, serviceData, payment)
                // Return the originalPayment with confirmed status
                .flatMap(p -> getPaymentByType(connection, serviceData, payment.setStatus(Payment.StatusEnum.confirmed))));
    }

    private Observable<Payment> completePaymentBasedOnType(M8ImsConnection connection, ServiceData serviceData, Payment originalPayment) {
        switch (originalPayment.getType()) {
            case lban:
            case plusgiro:
            case bankgiro:
                return householdHouseholdPaymentIntegration.confirmHouseholdDomesticPayment(connection, serviceData, originalPayment);
            case crossborder:
                return householdHouseholdPaymentIntegration.confirmHouseholdCrossBorderPayment(connection, serviceData, originalPayment);
            case einvoice:
                return householdHouseholdPaymentIntegration.confirmHouseholdEInvoicePayment(connection, serviceData, originalPayment);
            default:
                throw new IllegalArgumentException("Invalid payment type " + originalPayment.getType());
        }
    }

    @Override
    public Observable<List<Payment>> getPayments(ServiceData serviceData, PaymentFilter paymentFilter) {
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(householdHouseholdPaymentIntegration.getHouseholdCrossBorderPayments(connection, serviceData, paymentFilter)
                .concatWith(householdHouseholdPaymentIntegration.getHouseholdDomesticPayments(connection, serviceData, paymentFilter))
                .concatWith(householdHouseholdPaymentIntegration.getHouseholdEInvoicePayments(connection, serviceData, paymentFilter))
                .filter(paymentFilter.applyFilter())
                // FIXME: This is a relatively temporary fix as without buffering backpressure we often get the error "more items arrived than were requested". Oversee use of observables?
                .onBackpressureBuffer()
                // Ensure that all details are fetched.
                .flatMap(p -> getPaymentByType(connection, serviceData, p))
                .toList()
                .defaultIfEmpty(Collections.emptyList()));
    }

    @Override
    public Observable<Payment> getPayment(ServiceData serviceData, Payment payment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(getPaymentByType(connection, serviceData, payment)
                .toList()
                .map(paymentList -> validateSinglePaymentList(payment, paymentList)));
    }

    private Observable<Payment> getPaymentByType(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        switch (payment.getType()) {
            case plusgiro:
            case bankgiro:
            case owntransfer:
            case lban:
                return householdHouseholdPaymentIntegration.getHouseholdDomesticPayment(connection, serviceData, payment);
            case crossborder:
                return householdHouseholdPaymentIntegration.getHouseholdCrossBorderPayment(connection, serviceData, payment);
            case einvoice:
                return householdHouseholdPaymentIntegration.getHouseholdEInvoicePayment(connection, serviceData, payment);
            default:
                throw new IllegalArgumentException("Unknown type: " + payment.getType());
        }
    }

    private Payment validateSinglePaymentList(Payment queriedPayment, List<Payment> paymentList) {
        if (paymentList.isEmpty()) {
            LOGGER.error("Payment '{}' not found. Responding with a 404/Not found.", queriedPayment.getId());
            throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(queriedPayment.getId()))));
        } else if (paymentList.size() > 1) {
            LOGGER.warn("Request for payment '{}' resulted in more than one (1) result. Responding with a 500/Internal server error.", queriedPayment.getId());
            throw new InternalServerErrorException(new Error().setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR).setErrorDescription("Payment data inconsistency"));
        }
        return paymentList.get(0);
    }
}
