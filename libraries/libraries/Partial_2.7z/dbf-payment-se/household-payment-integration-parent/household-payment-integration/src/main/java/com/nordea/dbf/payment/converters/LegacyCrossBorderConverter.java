package com.nordea.dbf.payment.converters;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.api.model.accountkey.SepaAccountKey;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import org.apache.commons.lang.Validate;

import java.util.Optional;

public interface LegacyCrossBorderConverter {

    String URGENT_LEGACY_CODE = "URGP";

    static String accountNumberFromCrossBorderLegacyKey(String legacyKey) {
        // Legacy key = account number + payment id. Use the whole id as payment id to avoid overlapping identifiers with
        // other payment types (e.g. we don't want NNNMMM === MMM).
        return legacyKey.substring(0, 11);
    }

    static String convertToAccountKey(String toAccountId, String bicCode) {
        SepaAccountKey sepaAccountKey = new SepaAccountKey(bicCode, new AccountNumber(toAccountId));
        return sepaAccountKey.toString();
    }

    // TODO Verify the mappings
    static Payment.StatusEnum convertCrossBorderLegacyStatus(String paymentStatusCode) {
        switch (paymentStatusCode) {
            case "01":
                return Payment.StatusEnum.confirmed;
            case "11":
                return Payment.StatusEnum.unconfirmed;
            case "05":
                return Payment.StatusEnum.paid;
            case "20":
                return Payment.StatusEnum.inprogress;
            case "08":
            case "10":
                return Payment.StatusEnum.cancelled;
            case "02":
                return Payment.StatusEnum.inprogress;
            case "99":
                return Payment.StatusEnum.unconfirmed;
            default:
                throw new BadRequestException(ErrorResponses.requestNotUnderstood("Invalid crossborder legacy value '" + paymentStatusCode + "'", Optional.of("paymentStatus")));
        }
    }
    // TODO Confirm values and mappings.
    // 1 Unconfirmed
    // 2 DuePayment
    // 3 HistPayments
    // 4 Rejected
    // 5 Bundled
    static Integer fromPaymentStatus(Payment.StatusEnum paymentStatusCode) {
        switch(paymentStatusCode) {
            case unconfirmed:
                return 1;
            case confirmed:
                return 2;
            case paid:
                return 3;
            case rejected:
                return 4;
            // TODO: Can the below ones be mapped?
            case onhold:
            case cancelled:
            case inprogress:
            default:
                return null;
        }
    }

    static String convertChargePaidByToLegacy(CrossBorder.ChargePaidByEnum chargePaidBy) {
        switch (chargePaidBy) {
            case payer:
                return "OUR";
            case shared:
                return "SHA";
            case payee:
                return "BEN";
            default:
                throw new BadRequestException(ErrorResponses.requestNotUnderstood("Invalid charge payer '" + chargePaidBy + "'", Optional.of("chargePaidBy")));
        }
    }

    static CrossBorder.ChargePaidByEnum convertLegacyChargePaidByToModel(String string) {
        Validate.notEmpty(string, "string can't be null or empty");

        switch (string) {
            case "OUR":
                return CrossBorder.ChargePaidByEnum.payee;
            case "SHA":
                return CrossBorder.ChargePaidByEnum.shared;
            case "BEN":
                return CrossBorder.ChargePaidByEnum.payee;
            default:
                throw new BadRequestException(ErrorResponses.requestNotUnderstood("Invalid charge legacy value '" + string + "'", Optional.of("chargePaidBy")));
        }
    }

}
