package com.nordea.dbf.payment.converters;

import com.nordea.dbf.api.model.PaymentModifyFields;
import com.nordea.dbf.api.model.PaymentPermissions;

public interface LegacyPaymentPermissionsConverter {

    static PaymentPermissions paymentPermissionsOf(String allowedToModifyString, String allowedToCopyString, String allowedToDeleteString) {
        boolean allowedToModify = allowedToModifyString.equalsIgnoreCase("Y");
        boolean allowedToCopy = allowedToCopyString.equalsIgnoreCase("Y");
        boolean allowedToDelete = allowedToDeleteString.equalsIgnoreCase("Y");
        return new PaymentPermissions()
                .setCopy(allowedToCopy)
                .setDelete(allowedToDelete)
                .setModify(new PaymentModifyFields()
                        .setAmount(allowedToModify)
                        .setDue(allowedToModify)
                        .setFrom(allowedToModify)
                        .setMessage(allowedToModify)
                        .setRecurringCount(allowedToModify)
                        .setRecurringInterval(allowedToModify)
                        .setRecurringLastday(allowedToModify)
                        .setRecurringRepeats(allowedToModify)
                        .setTo(allowedToModify)
                        .setType(allowedToModify));
    }

}
