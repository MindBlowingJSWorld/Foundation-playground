package com.nordea.dbf.payment.converters.request.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.filter.DateFilter;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.PaymentFilterType;
import com.nordea.dbf.payment.common.converters.FilterRequestConverter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.converters.LegacyCrossBorderConverter;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListRequestFromAccountsSegment;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListRequestRecord;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListRequestStatusCollectionSegment;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
public class PaymentFilterToCrossborderPaymentListRequestRecord implements FilterRequestConverter<GetCrossBorderPaymentListRequestRecord> {
    // FIXME: Manage these properly.
    private static final String ALL_PAYMENTS = "0";
    private static final String WHITESPACE = " ";
    private static final String EMPTY_DATE_STR = "000000";
    private static final String GET_CROSSBORDER_PAYMENT_LIST_TRANSACTION_CODE = "LHP61P57";

    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentFilterToCrossborderPaymentListRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public GetCrossBorderPaymentListRequestRecord convert(ServiceData serviceData, PaymentFilter paymentFilter) {
        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.PAYMENT_TYPE) &&
                !paymentFilter.getPaymentTypes().contains(Payment.TypeEnum.crossborder)) {
            return null;
        }

        final GetCrossBorderPaymentListRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new GetCrossBorderPaymentListRequestRecord());
        requestRecord.setTransactionCode(GET_CROSSBORDER_PAYMENT_LIST_TRANSACTION_CODE);

        requestRecord.setBeneficiaryName(StringUtils.repeat(WHITESPACE, 34));
        requestRecord.setCurrency(StringUtils.repeat(WHITESPACE, 3));
        requestRecord.setToAccountId(StringUtils.repeat(WHITESPACE, 34));
        requestRecord.setMyCategory(StringUtils.repeat(WHITESPACE, 20));
        requestRecord.setAmountFrom(BigDecimal.ZERO);
        requestRecord.setAmountTo(BigDecimal.ZERO);

        requestRecord.setContinueKey(StringUtils.EMPTY);

        // TODO: What paymentSubTypes are valid for CrossBorder? (only crossborder? )
        requestRecord.setPaymentSubType(ALL_PAYMENTS);

        // TODO Verify the assumption that this is filtering based on DUE date and the expected Format.
        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.DUE_DATE)) {
            final DateFilter dateFilter = paymentFilter.getDueDate();

            if (dateFilter.getStartDate().isPresent()) {
                requestRecord.setFromDate(dateFilter.getStartDate().get().format(DateTimeFormatter.ofPattern("yyMMdd")));
            }

            if (dateFilter.getEndDate().isPresent()) {
                requestRecord.setToDate(dateFilter.getEndDate().get().format(DateTimeFormatter.ofPattern("yyMMdd")));
            }
        } else {
            requestRecord.setFromDate(EMPTY_DATE_STR);
            requestRecord.setToDate(EMPTY_DATE_STR);

        }
        // TODO hardcoded 1, 2, 3, 4 & 5 are valid values
        // 1 Unconfirmed
        // 2 DuePayment
        // 3 HistPayments
        // 4 Rejected
        // 5 Bundled

        List<Integer> legacyStatus = new ArrayList<>();

        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.STATUS)) {
            // use status:es supplied by users
            List<Integer> intStatuses = paymentFilter.getStatuses().stream()
                    .map(LegacyCrossBorderConverter::fromPaymentStatus)
                    .filter(Objects::nonNull)
                    .sorted()
                    .collect(Collectors.toList());

            if (intStatuses.size() == 0) {
                // The filters would result in no matches.
                return null;
            } else {
                legacyStatus = intStatuses;
            }
        } else {
            // TODO: Default is to fetch only unconfirmed, verify this assumption.
            legacyStatus.add(LegacyCrossBorderConverter.fromPaymentStatus(Payment.StatusEnum.unconfirmed));
        }

        for (Integer intStatus : legacyStatus) {
            GetCrossBorderPaymentListRequestStatusCollectionSegment statusSegment = requestRecord.addStatusCollection();
            statusSegment.setPaymentStatusCode(intStatus);
        }
        // FIXME: The legacy implementation added another entry which seems redundant, verify that it is in fact not used.
        // requestRecord.addStatusCollection();

        // Retrieve will always be filtered by accounts.
        ListFilter<AccountKey> fromAccounts = paymentFilter.getFromAccounts();

        if (fromAccounts.getValues().size() == 0) {
            return null;
        }

        for (final AccountKey accountKey : fromAccounts.getValues()) {
            final GetCrossBorderPaymentListRequestFromAccountsSegment accountSegment = requestRecord.addFromAccounts();
            accountSegment.setFromAccountCurrency(accountKey.getCurrencyCode().orElse(StringUtils.EMPTY));
            accountSegment.setFromAccountId(Long.parseLong(accountKey.getAccountNumber().getAccountNumber()));
        }

        return requestRecord;
    }
}
