package com.nordea.dbf.payment.converters.request.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.crossborder.household.ConfirmCrossBorderPaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToConfirmCrossBorderPaymentRequestRecord implements Converter<Payment, ConfirmCrossBorderPaymentRequestRecord> {

    private static final String CONFIRM_CROSSBORDER_PAYMENT_TRANSACTION_CODE = "LHP61P54";
    private static final String WHITESPACE = " ";

    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToConfirmCrossBorderPaymentRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public ConfirmCrossBorderPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        // TODO: This only confirms one payment?
        final ConfirmCrossBorderPaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new ConfirmCrossBorderPaymentRequestRecord());
        requestRecord.setTransactionCode(CONFIRM_CROSSBORDER_PAYMENT_TRANSACTION_CODE);

        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());
        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());

        // Generic data
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(WHITESPACE); //OK?

        requestRecord.setLegacyKey(payment.getId());

        // Seems to be copied from the IN area to the OUT area...
        // requestRecord.setPaymentType(" ");
        // requestRecord.setPaymentSubType(" ");
        return requestRecord;
    }
}
