package com.nordea.dbf.payment.converters.request.crossborder;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.converters.LegacyCrossBorderConverter;
import com.nordea.dbf.payment.model.HouseholdPayment;
import com.nordea.dbf.payment.record.crossborder.household.CreateCrossBorderPaymentRequestMessageRowCollectionSegment;
import com.nordea.dbf.payment.record.crossborder.household.CreateCrossBorderPaymentRequestRecord;
import com.nordea.dbf.payment.record.crossborder.household.CreateCrossBorderPaymentRequestUrgencyTypeCollectionSegment;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;

@Component
public class PaymentToCreateCrossborderPaymentRequestRecord implements Converter<Payment, CreateCrossBorderPaymentRequestRecord> {

    private static final String WHITESPACE = " ";
    private static final String CREATE_CROSSBORDER_PAYMENT_TRANSACTION_CODE = "LHP61P53";
    private static final String REPEATING_RULE_DEFAULT = "O";
    private static final String AGREEMENT_TYPE_DEFAULT = "O";
    private static final String RECEIPT_CODE_DEFAULT = "N";
    private static final String VALIDATE_FRAUD_DEFAULT = "N";
    private static final int MESSAGE_ROW_COUNT_DEFAULT = 0;
    private static final int URGENCY_TYPE_COUNT_DEFAULT = 0;
    private static final DateTimeFormatter PAYMENT_DUE_PATTERN = DateTimeFormatter.ofPattern(HouseholdPayment.PAYMENT_NONDELIMITED_DATE_FORMAT.toPattern());

    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToCreateCrossborderPaymentRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public CreateCrossBorderPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        final CreateCrossBorderPaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new CreateCrossBorderPaymentRequestRecord());
        requestRecord.setTransactionCode(CREATE_CROSSBORDER_PAYMENT_TRANSACTION_CODE);

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());
        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());

        // Generic data
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(StringUtils.EMPTY);

        // Legacy key components, not used for create
        requestRecord.setFromAccountId(StringUtils.EMPTY);
        requestRecord.setInputDate(StringUtils.EMPTY);
        requestRecord.setLegacyKey(StringUtils.EMPTY);

        requestRecord.setRepeatingRule(REPEATING_RULE_DEFAULT); // TODO As of now hardcoded to O which means once
        requestRecord.setAgreementType(AGREEMENT_TYPE_DEFAULT); // 02 means household
        requestRecord.setRecepitCode(RECEIPT_CODE_DEFAULT); // Hardcoded as N in PN
        requestRecord.setAgreementNumber(serviceData.getAgreement());
        requestRecord.setAgreementOwner(serviceData.getAgreementOwner());
        requestRecord.setCustomerNumber(serviceData.getUserId());
        requestRecord.setFromAccountNumber(fromAccountKey.getAccountNumber().getAccountNumber() + fromAccountKey.getCurrencyCode().orElse(StringUtils.EMPTY));
        requestRecord.setFiller(StringUtils.repeat(WHITESPACE, 48));
        requestRecord.setOwnReference(payment.getOwnMessage());
        requestRecord.setRemitterName(StringUtils.EMPTY);
        requestRecord.setRemitterNameCO(StringUtils.EMPTY);
        requestRecord.setRemitterStreetAddress(StringUtils.EMPTY);
        requestRecord.setRemitterPostCode(StringUtils.EMPTY);
        requestRecord.setIntermediaryBankAccount(StringUtils.repeat(WHITESPACE, 34));
        requestRecord.setIntermediaryBankBIC(StringUtils.repeat(WHITESPACE, 11));
        requestRecord.setReferenceTextF(StringUtils.repeat(WHITESPACE, 16));
        requestRecord.setExecutionDate(PAYMENT_DUE_PATTERN.format(payment.getDue()));
        requestRecord.setReferenceTextF(payment.getMessage());
        requestRecord.setCurrency(payment.getCurrency());
        requestRecord.setAmount(payment.getAmount());
        requestRecord.setReceivingBankCountry(toAccountKey.getCountry().orElse(StringUtils.EMPTY));
        requestRecord.setReceivingBankBIC(toAccountKey.getBIC().orElse(StringUtils.EMPTY));
        requestRecord.setReceivingBankCode(StringUtils.EMPTY);
        requestRecord.setReceivingBankAddress1(StringUtils.repeat(WHITESPACE, 35));
        requestRecord.setReceivingBankAddress2(StringUtils.repeat(WHITESPACE, 35));
        requestRecord.setReceivingBankAddress3(StringUtils.repeat(WHITESPACE, 35));
        requestRecord.setBeneficiaryAddress1(StringUtils.repeat(WHITESPACE, 35));
        requestRecord.setBeneficiaryAddress2(StringUtils.repeat(WHITESPACE, 35));
        requestRecord.setBeneficiaryAddress3(StringUtils.repeat(WHITESPACE, 35));
        requestRecord.setToAccountId(toAccountKey.getAccountNumber().getAccountNumber());

        CrossBorder crossBorderRequest = payment.getCrossBorder();
        // FIXME: Verify if this is validated in the backend.
        if (crossBorderRequest == null) {
            crossBorderRequest = new CrossBorder();
        }
        requestRecord.setCbrCode(crossBorderRequest.getCentralBankReportingCode());
        requestRecord.setChargePaidBy(LegacyCrossBorderConverter.convertChargePaidByToLegacy(crossBorderRequest.getChargePaidBy()));
        requestRecord.setMessageRowCount(0);

        // Y/N indicates whether signing is needed or must be performed.
        // Since we always mandate signing in confirmations, we always set this to N.
        requestRecord.setValidateForFraud(VALIDATE_FRAUD_DEFAULT);
        requestRecord.setFiller1(WHITESPACE);
        requestRecord.setMessageRowCount(MESSAGE_ROW_COUNT_DEFAULT);
        requestRecord.setUrgencyTypeCount(URGENCY_TYPE_COUNT_DEFAULT);
        if (payment.getSpeed() == Payment.SpeedEnum.express) {
            final CreateCrossBorderPaymentRequestUrgencyTypeCollectionSegment urgencyType = requestRecord.addUrgencyTypeCollection();
            urgencyType.setUrgencyType(LegacyCrossBorderConverter.URGENT_LEGACY_CODE);
        } else {
            final CreateCrossBorderPaymentRequestUrgencyTypeCollectionSegment urgencyType = requestRecord.addUrgencyTypeCollection();
            urgencyType.setUrgencyType(WHITESPACE);
        }
        final CreateCrossBorderPaymentRequestMessageRowCollectionSegment messageSegment = requestRecord.addMessageRowCollection();
        messageSegment.setMessageRow(payment.getMessage());

        return requestRecord;
    }
}
