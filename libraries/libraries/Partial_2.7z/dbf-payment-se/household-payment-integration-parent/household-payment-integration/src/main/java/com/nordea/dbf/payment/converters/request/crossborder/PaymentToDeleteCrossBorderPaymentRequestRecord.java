package com.nordea.dbf.payment.converters.request.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.crossborder.household.DeleteCrossBorderPaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToDeleteCrossBorderPaymentRequestRecord implements Converter<Payment, DeleteCrossBorderPaymentRequestRecord> {

    private static final String DELETE_CROSSBORDER_PAYMENT_TRANSACTION_CODE = "LHP61P56";
    private static final String WHITESPACE = " ";

    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToDeleteCrossBorderPaymentRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public DeleteCrossBorderPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        final DeleteCrossBorderPaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new DeleteCrossBorderPaymentRequestRecord());
        requestRecord.setTransactionCode(DELETE_CROSSBORDER_PAYMENT_TRANSACTION_CODE);

        // Common
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(WHITESPACE);

        requestRecord.setLegacyKey(payment.getId());

        return requestRecord;
    }
}
