package com.nordea.dbf.payment.converters.request.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentRequestRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToGetCrossBorderPaymentRecord implements Converter<Payment, GetCrossBorderPaymentRequestRecord> {

    private static final String GET_CROSSBORDER_PAYMENT_TRANSACTION_CODE = "LHP61P58";

    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToGetCrossBorderPaymentRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public GetCrossBorderPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        final GetCrossBorderPaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new GetCrossBorderPaymentRequestRecord());
        requestRecord.setTransactionCode(GET_CROSSBORDER_PAYMENT_TRANSACTION_CODE);

        // Generic data
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(StringUtils.EMPTY);

        requestRecord.setLegacyKey(payment.getId());

        return requestRecord;
    }
}
