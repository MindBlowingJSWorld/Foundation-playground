package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.filter.DateFilter;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.PaymentFilterType;
import com.nordea.dbf.payment.common.converters.FilterRequestConverter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.PaymentStatusToMessageId;
import com.nordea.dbf.payment.record.domestic.PaymentListRequestFromAccountsSegment;
import com.nordea.dbf.payment.record.domestic.PaymentListRequestRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class PaymentFilterToPaymentListRequestRecord implements FilterRequestConverter<List<PaymentListRequestRecord>> {

    private static final String FILTER_PAYMENT_LITE_REQUEST_RECORD_TRANSACTION_CODE = "FQQ852";
    private static final long CONTINUE_KEY_ACCT = 0L;
    private static final long CONTINUE_KEY_PAY_ID = 0L;
    private static final String SEARCH_WITH_DATE = "Y";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentFilterToPaymentListRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public List<PaymentListRequestRecord> convert(ServiceData serviceData, PaymentFilter paymentFilter) {
        // To enable filtering on payment types, the request need to be run multiple times.
        List<PaymentListRequestRecord> paymentListRequestRecords = new ArrayList<>();

        // If a filter is applied on payment types, ensure that any types are valid for this.
        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.PAYMENT_TYPE) &&
                (paymentFilter.getPaymentTypes().stream()
                        .map(this::getLegacyPaymentType)
                        .filter(s -> s != null)
                        .count() == 0)
                ) {
            return paymentListRequestRecords;
        }

        // One set of requests each should be performed per status
        // This has to be done since the backend does not support retrieving all payments of all types at the same time, that results in kbearb 12, krc 12
        // We regard this as a bug but they will not fix it as it will hardly ever occur in production
        List<String> statusFilters;
        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.STATUS)) {
            statusFilters = paymentFilter.getStatuses().stream()
                    .map(PaymentStatusToMessageId::getSubMessageIdByStatus).filter(s -> s != null)
                    .sorted()
                    .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
        } else {
            statusFilters = Stream.of(Payment.StatusEnum.values())
                    .map(PaymentStatusToMessageId::getSubMessageIdByStatus)
                    .filter(s -> s != null)
                    .sorted()
                    .collect(Collectors.toList());
        }

        for (String status : statusFilters) {
            // If we have payment type, clone the request.
            if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.PAYMENT_TYPE)) {
                ArrayList<String> giroTypes = paymentFilter.getPaymentTypes().stream()
                        .map(this::getLegacyPaymentType)
                        .filter(s -> s != null)
                        .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);

                for (String giroType : giroTypes) {
                    paymentListRequestRecords.add(createRequestRecord(serviceData, paymentFilter, giroType, status));
                }
            } else {
                paymentListRequestRecords.add(createRequestRecord(serviceData, paymentFilter, StringUtils.EMPTY, status));
            }
        }

        return paymentListRequestRecords;
    }

    // TODO: Move into a more suitable converter / ENUM.
    private String getLegacyPaymentType(Payment.TypeEnum typeFilter) {
        switch (typeFilter) {
            case plusgiro:
                return LegacyGiroType.PG.code();
            case bankgiro:
                return LegacyGiroType.BG.code();
            case owntransfer:
                return LegacyGiroType.OWN_ACCOUNTS.code();
            case lban:
                return LegacyGiroType.EXTERNAL_TRANSFER.code();
            case salary:
                return LegacyGiroType.SALARY.code();
            case pension:
                return LegacyGiroType.PENSION.code();
            default:
                return null;
        }
    }

    private PaymentListRequestRecord createRequestRecord(ServiceData serviceData, PaymentFilter paymentFilter, String giroType, String status) {
        PaymentListRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new PaymentListRequestRecord());
        requestRecord.setTransactionCode(FILTER_PAYMENT_LITE_REQUEST_RECORD_TRANSACTION_CODE);

        // Generic data
        requestRecord.setCustomerId(Long.parseLong(serviceData.getUserId()));
        requestRecord.setAgreementNumber(serviceData.getAgreement().intValue());

        // Set the Girotype if any
        requestRecord.setGiroType(giroType);

        // If the request is filtered by status, setup the subMessages accordingly.
        requestRecord.setSubMessageId1(StringUtils.EMPTY);
        requestRecord.setSubMessageId2(StringUtils.EMPTY);
        requestRecord.setSubMessageId3(StringUtils.EMPTY);
        requestRecord.setSubMessageId4(StringUtils.EMPTY);
        requestRecord.setMessageId(status);

        // If a due date has been supplied
        requestRecord.setStartDate(StringUtils.EMPTY);
        requestRecord.setEndDate(StringUtils.EMPTY);
        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.DUE_DATE)) {
            requestRecord.setSearchWithDate(SEARCH_WITH_DATE);
            final DateFilter dateFilter = paymentFilter.getDueDate();

            if (dateFilter.getStartDate().isPresent()) {
                requestRecord.setStartDate(dateFilter.getStartDate().get().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            }

            if (dateFilter.getEndDate().isPresent()) {
                requestRecord.setEndDate(dateFilter.getEndDate().get().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            }
        }

        // Retrieve will always be filtered by accounts.
        ListFilter<AccountKey> fromAccounts = paymentFilter.getFromAccounts();

        for (final AccountKey accountKey : fromAccounts.getValues()) {
            final PaymentListRequestFromAccountsSegment segment = requestRecord.addFromAccounts();

            segment.setFromAccount(Long.parseLong(accountKey.getAccountNumber().getAccountNumber()));
            segment.setFromAccountCurrency(accountKey.getCurrencyCode().orElse(null));
        }

        requestRecord.setContinueKeyAcct(CONTINUE_KEY_ACCT);
        requestRecord.setContinueKeyPayId(CONTINUE_KEY_PAY_ID);

        return requestRecord;
    }
}
