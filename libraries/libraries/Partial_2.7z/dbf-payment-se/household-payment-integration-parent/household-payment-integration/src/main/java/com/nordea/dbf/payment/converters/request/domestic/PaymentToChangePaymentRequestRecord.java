package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.ExtendedRequestConverter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.HouseholdPayment;
import com.nordea.dbf.payment.record.domestic.ChangePaymentRequestRecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.ZoneId;
import java.util.Date;

@Component
public class PaymentToChangePaymentRequestRecord extends ExtendedRequestConverter<ChangePaymentRequestRecord, Payment> {

    private static final String CHANGE_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP809";
    private static final String IP_FLAG = " ";
    private static final String SAVE_RECEIVER = "N";
    private static final String VALIDATE_FOR_FRAUD = "E";
    private static final String EINVOICE_ID = StringUtils.EMPTY;
    private static final String NICKNAME = StringUtils.EMPTY;
    private static final String OWN_CATEGORY = StringUtils.EMPTY;
    private static final String STATUS_CODE = LegacyPaymentStatus.UNCONFIRMED.code();
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToChangePaymentRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public ChangePaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        checkRecurring(payment);

        Payment originalPayment = this.getExtension();

        final ChangePaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new ChangePaymentRequestRecord());

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());
        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());
        requestRecord.setTransactionCode(CHANGE_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE);

        // Generic data
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(IP_FLAG);

        // Payment payload
        requestRecord.setPaymentId(Long.valueOf(payment.getId()));

        // If we change the from account we also need to send down the old from account. This is the single reason originalPayment exists.
        requestRecord.setOldFromAccount(Long.parseLong(AccountKey.fromString(originalPayment.getFrom()).getAccountNumber().getAccountNumber()));
        requestRecord.setFromAccount(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));

        requestRecord.setAgreementNumber(serviceData.getAgreement().intValue());
        requestRecord.setAmount(payment.getAmount().doubleValue());
        requestRecord.setCustomerId(Long.parseLong(serviceData.getUserId()));
        requestRecord.setDueDate(HouseholdPayment.PAYMENT_DATE_FORMAT.format(Date.from(payment.getDue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
        requestRecord.setEinvoiceId(EINVOICE_ID);
        requestRecord.setFromAccountCurrency(fromAccountKey.getCurrencyCode().orElse(null));
        requestRecord.setGiroType(LegacyGiroType.fromPaymentType(payment.getType()).code());
        requestRecord.setMessage(payment.getMessage());
        requestRecord.setNickname(NICKNAME);
        requestRecord.setOwnCategory(OWN_CATEGORY);
        requestRecord.setOwnReference(payment.getOwnMessage());
        requestRecord.setSaveReceiver(SAVE_RECEIVER);
        requestRecord.setStatusCode(STATUS_CODE);
        requestRecord.setToAccount(Long.parseLong(toAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setTransactionCurrency(payment.getCurrency());
        requestRecord.setUserId(serviceData.getUserId());
        requestRecord.setValidateForFraud(VALIDATE_FOR_FRAUD); // FIXME: Check how this should be configured

        handleRecurring(requestRecord, payment);

        return requestRecord;
    }

    /**
     * Handling recurring part of payment.
     *
     * @param requestRecord to decorate
     * @param payment       as source for decoration
     */
    private void handleRecurring(ChangePaymentRequestRecord requestRecord, Payment payment) {
        if (payment.getRecurring() != null) {
            switch (payment.getRecurring().getInterval()) {
                case monthly:
                    requestRecord.setProlong(HouseholdPayment.RECURR_MONTHLY); // Recurring = monthly
                    break;
                default:
                    throw new IllegalArgumentException("Recurring interval '" + payment.getRecurring().getInterval() + "' is not allowed");
            }
            if (payment.getRecurring().getCount() != null) {
                requestRecord.setRecurringNumber(payment.getRecurring().getCount());
            } else {
                // 999 is for ever...
                requestRecord.setRecurringNumber(HouseholdPayment.RECURR_FOR_EVER);
            }
        } else {
            requestRecord.setProlong(HouseholdPayment.RECURR_ONCE); // Recurring = once
            requestRecord.setRecurringNumber(0);
        }
    }

    // TODO: Code duplication
    private void checkRecurring(Payment payment) {
        if (payment.getRecurring() != null) {
            Validate.notNull(payment.getRecurring().getInterval());
            if (!payment.getRecurring().getInterval().equals(PaymentRecurring.IntervalEnum.monthly)) {
                throw new IllegalArgumentException("Recurring interval '" + payment.getRecurring().getInterval() + "' is not allowed");
            }
            Validate.notNull(payment.getRecurring().getFrequency());
            if (payment.getRecurring().getFrequency() != 1) {
                throw new IllegalArgumentException("Recurring frequency '" + payment.getRecurring().getFrequency() + "' is not allowed");
            }
        }
    }
}
