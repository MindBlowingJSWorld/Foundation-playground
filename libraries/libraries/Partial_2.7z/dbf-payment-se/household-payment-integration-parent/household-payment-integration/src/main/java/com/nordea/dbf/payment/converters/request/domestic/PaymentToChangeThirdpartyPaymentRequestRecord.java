package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.ExtendedRequestConverter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.ChangePaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToChangeThirdpartyPaymentRequestRecord extends ExtendedRequestConverter<ChangePaymentRequestRecord, Payment> {

    private static final String CHANGE_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP810";
    private static final String MESSAGE_ID = "FQP8101";
    private final PaymentToChangePaymentRequestRecord paymentToChangePaymentRequestRecord;

    @Autowired
    public PaymentToChangeThirdpartyPaymentRequestRecord(PaymentToChangePaymentRequestRecord paymentToChangePaymentRequestRecord) {
        this.paymentToChangePaymentRequestRecord = paymentToChangePaymentRequestRecord;
    }

    @Override
    public ChangePaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        // Thirdparty and domestic share the same copybook, reuse and swap the transaction / message id.
        Payment originalPayment = this.getExtension();
        ChangePaymentRequestRecord req = paymentToChangePaymentRequestRecord.with(originalPayment).convert(serviceData, payment);
        req.setTransactionCode(CHANGE_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE);
        req.setMessageId(MESSAGE_ID);
        req.setOldFromAccount(Long.parseLong(AccountKey.fromString(originalPayment.getFrom()).getAccountNumber().getAccountNumber()));

        return req;
    }
}
