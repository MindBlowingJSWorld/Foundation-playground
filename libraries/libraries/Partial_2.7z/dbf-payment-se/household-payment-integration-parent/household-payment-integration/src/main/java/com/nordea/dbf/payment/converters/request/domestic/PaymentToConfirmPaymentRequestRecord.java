package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentRequestPaymentsSegment;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToConfirmPaymentRequestRecord implements Converter<Payment, ConfirmPaymentRequestRecord> {

    private static final String CONFIRM_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP801";
    private static final String IP_FLAG = " ";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToConfirmPaymentRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public ConfirmPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        // TODO: This only confirms one payment?
        final ConfirmPaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new ConfirmPaymentRequestRecord());
        requestRecord.setTransactionCode(CONFIRM_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE);

        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());
        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());

        // Generic data
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(IP_FLAG); //OK?

        final ConfirmPaymentRequestPaymentsSegment segment = requestRecord.addPayments();
        segment.setUserId(serviceData.getUserId());
        segment.setCustomerId(Long.parseLong(serviceData.getUserId()));
        segment.setGiroType(LegacyGiroType.fromPaymentType(payment.getType()).code());
        segment.setPaymentId(Long.parseLong(payment.getId()));
        segment.setAgreementNumber(serviceData.getAgreement().intValue());
        segment.setFromAccount(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));

        return requestRecord;
    }
}
