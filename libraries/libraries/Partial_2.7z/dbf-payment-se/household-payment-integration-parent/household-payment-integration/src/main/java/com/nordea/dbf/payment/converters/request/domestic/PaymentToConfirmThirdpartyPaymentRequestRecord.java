package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToConfirmThirdpartyPaymentRequestRecord implements Converter<Payment, ConfirmPaymentRequestRecord> {

    private static final String CONFIRM_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP807";
    private static final String MESSAGE_ID = "FQP8071";
    private final PaymentToConfirmPaymentRequestRecord paymentToConfirmPaymentRequestRecord;

    @Autowired
    public PaymentToConfirmThirdpartyPaymentRequestRecord(PaymentToConfirmPaymentRequestRecord paymentToConfirmPaymentRequestRecord) {
        this.paymentToConfirmPaymentRequestRecord = paymentToConfirmPaymentRequestRecord;
    }

    @Override
    public ConfirmPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        // Thirdparty and domestic share the same copybook, reuse and swap the transaction / message id.
        ConfirmPaymentRequestRecord req = paymentToConfirmPaymentRequestRecord.convert(serviceData, payment);
        req.setTransactionCode(CONFIRM_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE);
        req.setMessageId(MESSAGE_ID);
        return req;
    }
}
