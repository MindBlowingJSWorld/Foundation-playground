package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.HouseholdPayment;
import com.nordea.dbf.payment.record.domestic.CreatePaymentRequestRecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.ZoneId;
import java.util.Date;

@Component
public class PaymentToCreatePaymentRequestRecord implements Converter<Payment, CreatePaymentRequestRecord> {

    private static final String CREATE_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP800";
    private static final long PAYMENT_ID = 0L;
    private static final String SAVE_RECEIVER = "N";
    private static final String VALIDATE_FOR_FRAUD = "E";
    private static final String EINVOICE_ID = StringUtils.EMPTY;
    private static final String NICKNAME = StringUtils.EMPTY;
    private static final String STATUS_CODE = LegacyPaymentStatus.UNCONFIRMED.code();
    private static final String OWN_CATEGORY = StringUtils.EMPTY;
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToCreatePaymentRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public CreatePaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        checkRecurring(payment);

        final CreatePaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new CreatePaymentRequestRecord());
        requestRecord.setTransactionCode(CREATE_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE);

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());
        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());

        // Generic data
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(" ");

        // Payment payload
        requestRecord.setPaymentId(PAYMENT_ID);
        requestRecord.setAgreementNumber(serviceData.getAgreement().intValue());
        requestRecord.setAmount(payment.getAmount().doubleValue());
        requestRecord.setCustomerId(Long.parseLong(serviceData.getUserId()));
        requestRecord.setDueDate(HouseholdPayment.PAYMENT_DATE_FORMAT.format(Date.from(payment.getDue().atStartOfDay(ZoneId.systemDefault()).toInstant())));
        requestRecord.setEinvoiceId(EINVOICE_ID);
        requestRecord.setFromAccount(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setFromAccountCurrency(fromAccountKey.getCurrencyCode().orElse(null));
        requestRecord.setGiroType(LegacyGiroType.fromPaymentType(payment.getType()).code());
        requestRecord.setMessage(payment.getMessage());
        requestRecord.setNickname(NICKNAME);
        requestRecord.setOwnCategory(OWN_CATEGORY);
        requestRecord.setOwnReference(payment.getOwnMessage());
        requestRecord.setSaveReceiver(SAVE_RECEIVER);
        requestRecord.setStatusCode(STATUS_CODE);
        requestRecord.setToAccount(Long.parseLong(toAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setTransactionCurrency(payment.getCurrency());
        requestRecord.setUserId(serviceData.getUserId());
        requestRecord.setValidateForFraud(VALIDATE_FOR_FRAUD); // FIXME: Check how this should be configured

        handleRecurring(requestRecord, payment);

        return requestRecord;
    }

    /**
     * Handling recurring part of payment.
     *
     * @param requestRecord to decorate
     * @param payment       as source for decoration
     */
    private void handleRecurring(CreatePaymentRequestRecord requestRecord, Payment payment) {
        if (payment.getRecurring() != null) {
            switch (payment.getRecurring().getInterval()) {
                case monthly:
                    requestRecord.setProlong(HouseholdPayment.RECURR_MONTHLY); // Recurring = monthly
                    break;
                default:
                    throw new IllegalArgumentException("Recurring interval '" + payment.getRecurring().getInterval() + "' is not allowed");
            }
            if (payment.getRecurring().getCount() != null) {
                requestRecord.setRecurringNumber(payment.getRecurring().getCount());
            } else {
                // 999 is for ever...
                requestRecord.setRecurringNumber(HouseholdPayment.RECURR_FOR_EVER);
            }
        } else {
            requestRecord.setProlong(HouseholdPayment.RECURR_ONCE); // Recurring = once
            requestRecord.setRecurringNumber(0);
        }
    }

    // TODO: Code duplication
    private void checkRecurring(Payment payment) {
        if (payment.getRecurring() != null) {
            Validate.notNull(payment.getRecurring().getInterval());
            if (!payment.getRecurring().getInterval().equals(PaymentRecurring.IntervalEnum.monthly)) {
                throw new IllegalArgumentException("Recurring interval '" + payment.getRecurring().getInterval() + "' is not allowed");
            }
            Validate.notNull(payment.getRecurring().getFrequency());
            if (payment.getRecurring().getFrequency() != 1) {
                throw new IllegalArgumentException("Recurring frequency '" + payment.getRecurring().getFrequency() + "' is not allowed");
            }
        }
    }
}
