package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.CreatePaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToCreateThirdpartyPaymentRequestRecord implements Converter<Payment, CreatePaymentRequestRecord> {

    private static final String CREATE_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP806";
    private static final String MESSAGE_ID = "FQP8061";
    private final PaymentToCreatePaymentRequestRecord paymentToCreatePaymentRequestRecord;

    @Autowired
    public PaymentToCreateThirdpartyPaymentRequestRecord(PaymentToCreatePaymentRequestRecord paymentToCreatePaymentRequestRecord) {
        this.paymentToCreatePaymentRequestRecord = paymentToCreatePaymentRequestRecord;
    }

    @Override
    public CreatePaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        // Thirdparty and domestic share the same copybook, reuse and swap the transaction / message id.

        CreatePaymentRequestRecord req = paymentToCreatePaymentRequestRecord.convert(serviceData, payment);
        req.setTransactionCode(CREATE_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE);
        req.setMessageId(MESSAGE_ID);

        return req;
    }
}
