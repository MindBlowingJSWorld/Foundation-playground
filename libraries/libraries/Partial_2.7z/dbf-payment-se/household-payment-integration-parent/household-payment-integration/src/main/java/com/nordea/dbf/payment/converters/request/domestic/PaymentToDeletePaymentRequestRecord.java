package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.LegacyPaymentSubType;
import com.nordea.dbf.payment.record.domestic.DeletePaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToDeletePaymentRequestRecord implements Converter<Payment, DeletePaymentRequestRecord> {

    private static final String DELETE_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP802";
    private static final String IP_FLAG = " ";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToDeletePaymentRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public DeletePaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        final DeletePaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new DeletePaymentRequestRecord());
        requestRecord.setTransactionCode(DELETE_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE);

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());
        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());

        // Common
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(IP_FLAG);

        requestRecord.setPaymentId(Long.parseLong(payment.getId()));

        requestRecord.setCustomerId(Long.parseLong(serviceData.getUserId()));
        requestRecord.setAgreementNumber(serviceData.getAgreement().intValue());

        requestRecord.setFromAccount(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setSubType(LegacyPaymentSubType.fromAccountKey(toAccountKey).code());
        requestRecord.setGiroType(LegacyGiroType.fromPaymentType(payment.getType()).code());
        requestRecord.setPaymentStatus(LegacyPaymentStatus.fromPaymentStatusEnum(payment.getStatus()).code());

        return requestRecord;
    }
}
