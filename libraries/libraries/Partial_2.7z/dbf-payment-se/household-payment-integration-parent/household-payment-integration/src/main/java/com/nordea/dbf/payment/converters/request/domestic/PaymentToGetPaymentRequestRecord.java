package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.LegacyPaymentSubType;
import com.nordea.dbf.payment.record.domestic.GetPaymentRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToGetPaymentRequestRecord implements Converter<Payment, GetPaymentRequestRecord> {

    private static final String GET_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQQ850";
    private static final String IP_FLAG = " ";
    public final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToGetPaymentRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public GetPaymentRequestRecord convert(ServiceData serviceData, Payment payment) {
        final GetPaymentRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new GetPaymentRequestRecord());
        requestRecord.setTransactionCode(GET_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE);

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());

        // Generic data
        requestRecord.setIpAddress(serviceData.getRemoteAddress());
        requestRecord.setIpFlag(IP_FLAG);

        // Payment payload
        requestRecord.setAgreementNumber(serviceData.getAgreement().intValue());
        requestRecord.setCustomerId(Long.parseLong(serviceData.getUserId()));
        requestRecord.setFromAccount(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setPaymentId(Long.parseLong(payment.getId()));
        requestRecord.setPaymentStatus(LegacyPaymentStatus.fromPaymentStatusEnum(payment.getStatus()).code());
        requestRecord.setSubType(LegacyPaymentSubType.fromPaymentType(payment.getType()).code());
        requestRecord.setGiroType(LegacyGiroType.fromPaymentType(payment.getType()).code());

        return requestRecord;
    }
}
