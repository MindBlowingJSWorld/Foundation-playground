package com.nordea.dbf.payment.converters.request.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.ExtendedRequestConverter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.model.LegacyEInvoice;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestEInvoicesSegment;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EInvoiceToChangeEInvoiceRequestRecord extends ExtendedRequestConverter<EInvoiceRequestRecord, EInvoice> {

    private static final String CHANGE_EINVOICE_MESSAGE_ID = "M8047P4";
    private static final String EINVOICE_REQUEST_RECORD_TRANSACTION_CODE = "M8047P";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public EInvoiceToChangeEInvoiceRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    public EInvoiceRequestRecord convert(ServiceData serviceData, Payment payment) {
        EInvoice eInvoice = this.getExtension();

        eInvoice.setDueDate(payment.getDue()); // If payment.getDue() is null an exception is thrown
        eInvoice.setMessage(payment.getMessage());
        eInvoice.setOwnReference(payment.getOwnMessage());
        eInvoice.setAmount(payment.getAmount());
        eInvoice.setFromAccount(Long.valueOf(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));

        final EInvoiceRequestRecord requestRecord = nilRequestMsgHeaders.eInvoiceRequestFrom(serviceData.getServiceRequestContext());
        requestRecord.setTransactionCode(EINVOICE_REQUEST_RECORD_TRANSACTION_CODE);
        requestRecord.setMessageId(CHANGE_EINVOICE_MESSAGE_ID);

        final EInvoiceRequestEInvoicesSegment segment = requestRecord.addEInvoices();
        segment.initialize();
        segment.setArrivalDate(eInvoice.getArrivalDate().format(LegacyEInvoice.ARRIVAL_DATE_FORMAT));
        segment.setInvoiceId(eInvoice.getInvoiceId());
        segment.setMessage(eInvoice.getMessage());
        segment.setOwnReference(eInvoice.getOwnReference());
        segment.setCurrency(eInvoice.getCurrency().getCurrencyCode());
        segment.setAmount(eInvoice.getAmount().doubleValue());
        segment.setDueDate(eInvoice.getDueDate().format(LegacyEInvoice.DUE_DATE_FORMAT));
        segment.setFromAccount(eInvoice.getFromAccount());
        segment.setGiroType(eInvoice.getGiroType());
        segment.setInvoicerId(eInvoice.getInvoicerId());
        segment.setInvoicerName(eInvoice.getInvoicerName());
        segment.setIsOcr(eInvoice.getIsOcr());
        segment.setOwnCategory(eInvoice.getOwnCategory());
        segment.setToAccount(eInvoice.getToAccount());

        return requestRecord;
    }
}
