package com.nordea.dbf.payment.converters.request.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.PaymentFilterType;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestEInvoicesSegment;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import rx.Observable;

@Component
public class PaymentFilterToGetEInvoicesRequestRecord implements Converter<PaymentFilter, EInvoiceRequestRecord> {

    private static final String GET_EINVOICES_MESSAGE_ID = "M8047P6";
    private static final String EINVOICE_REQUEST_RECORD_TRANSACTION_CODE = "M8047P";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentFilterToGetEInvoicesRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    public EInvoiceRequestRecord convert(ServiceData serviceData, PaymentFilter paymentFilter) {
        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.PAYMENT_TYPE) &&
                !paymentFilter.getPaymentTypes().contains(Payment.TypeEnum.einvoice)) {
            return null;
        }

        final EInvoiceRequestRecord requestRecord = nilRequestMsgHeaders.eInvoiceRequestFrom(serviceData.getServiceRequestContext());
        requestRecord.setTransactionCode(EINVOICE_REQUEST_RECORD_TRANSACTION_CODE);
        requestRecord.setMessageId(GET_EINVOICES_MESSAGE_ID);

        if (paymentFilter.getPaymentFilterTypes().contains(PaymentFilterType.PAYMENT_ID)) {
            final EInvoiceRequestEInvoicesSegment eInvoice = requestRecord.addEInvoices();
            eInvoice.setInvoiceId(paymentFilter.getPaymentId());
        }

        return requestRecord;
    }
}
