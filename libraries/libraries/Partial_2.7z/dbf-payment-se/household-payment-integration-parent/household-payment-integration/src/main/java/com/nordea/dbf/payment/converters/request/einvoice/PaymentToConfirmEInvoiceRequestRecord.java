package com.nordea.dbf.payment.converters.request.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestEInvoicesSegment;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import rx.Observable;

@Component
public class PaymentToConfirmEInvoiceRequestRecord implements Converter<Payment, EInvoiceRequestRecord> {

    private static final String CONFIRM_EINVOICE_MESSAGE_ID = "M8047P2";
    private static final String EINVOICE_REQUEST_RECORD_TRANSACTION_CODE = "M8047P";
    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToConfirmEInvoiceRequestRecord(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public EInvoiceRequestRecord convert(ServiceData serviceData, Payment payment) {
        final EInvoiceRequestRecord requestRecord = nilRequestMsgHeaders.eInvoiceRequestFrom(serviceData.getServiceRequestContext());
        requestRecord.setTransactionCode(EINVOICE_REQUEST_RECORD_TRANSACTION_CODE);
        requestRecord.setMessageId(CONFIRM_EINVOICE_MESSAGE_ID);

        final EInvoiceRequestEInvoicesSegment eInvoice = requestRecord.addEInvoices();
        eInvoice.setInvoiceId(payment.getId());

        return requestRecord;
    }
}
