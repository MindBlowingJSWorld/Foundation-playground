package com.nordea.dbf.payment.converters.response.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.record.crossborder.household.ConfirmCrossBorderPaymentResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

@Component
public class ConfirmCrossBorderPaymentResponseToPaymentConverter implements ResponseConverter<ConfirmCrossBorderPaymentResponseRecord, Payment> {

    @Autowired
    @Qualifier("householdErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public Payment responseConvert(ServiceData serviceData, ConfirmCrossBorderPaymentResponseRecord response) {
        Payment payment = new Payment();
        payment.setId(response.getLegacyKey());
        return payment;
    }
}
