package com.nordea.dbf.payment.converters.response.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.converters.LegacyCrossBorderConverter;
import com.nordea.dbf.payment.record.crossborder.household.CrossBorderPaymentIdResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

@Component
public class CrossBorderPaymentIdResponseToPaymentConverter implements ResponseConverter<CrossBorderPaymentIdResponseRecord, Payment> {

    @Autowired
    @Qualifier("householdErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public Payment responseConvert(ServiceData serviceData, CrossBorderPaymentIdResponseRecord response) {
        Payment payment = new Payment();
        payment.setFrom(LegacyCrossBorderConverter.accountNumberFromCrossBorderLegacyKey(response.getLegacyKey()));
        payment.setId(response.getLegacyKey());
        payment.setType(Payment.TypeEnum.crossborder);
        return payment;
    }
}
