package com.nordea.dbf.payment.converters.response.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.converters.LegacyAccountKeyConverter;
import com.nordea.dbf.payment.converters.LegacyCrossBorderConverter;
import com.nordea.dbf.payment.converters.LegacyPaymentPermissionsConverter;
import com.nordea.dbf.payment.model.HouseholdPayment;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListResponsePaymentCollectionSegment;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

@Component
public class CrossBorderPaymentListResponsePaymentSegmentToPaymentConverter implements Converter<GetCrossBorderPaymentListResponsePaymentCollectionSegment, Payment> {
    @Override
    public Payment convert(ServiceData serviceData, GetCrossBorderPaymentListResponsePaymentCollectionSegment segment) {
        final String accountNumber = LegacyCrossBorderConverter.accountNumberFromCrossBorderLegacyKey(segment.getLegacyKey());
        Payment payment = new Payment();

        // TODO: verify that the ID is formatted correctly.
        payment.setId(segment.getLegacyKey());

        payment.setAmount(segment.getAmount());
        payment.setCurrency(segment.getCurrency());
        LocalDate dueDate = null;
        LocalDateTime entryDate = null;
        try {

            dueDate = HouseholdPayment.PAYMENT_SIMPLE_DATE_FORMAT.parse(segment.getExecutionDate()).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            entryDate = HouseholdPayment.PAYMENT_SIMPLE_DATE_FORMAT.parse(segment.getPaymentDate()).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        payment.setDue(dueDate);
        payment.setEntryDate(entryDate);
        payment.setStatus(LegacyCrossBorderConverter.convertCrossBorderLegacyStatus(segment.getPaymentStatusCode()));
        payment.setType(Payment.TypeEnum.crossborder);
        payment.setFrom(LegacyAccountKeyConverter.accountKeyOf(StringUtils.EMPTY, Long.parseLong(accountNumber), segment.getFromAccountCurrency()));
        payment.setType(Payment.TypeEnum.crossborder);
        payment.setPermissions(LegacyPaymentPermissionsConverter.paymentPermissionsOf(
                        segment.getAllowedToModify(),
                        segment.getAllowedToCopy(),
                        segment.getAllowedToDelete()));

        // TODO: Verify that we receive bic code from the GET that we do after Create
        payment.setTo(LegacyCrossBorderConverter.convertToAccountKey(segment.getToAccountId(), "DUMMYB"));
        return payment;
    }
}
