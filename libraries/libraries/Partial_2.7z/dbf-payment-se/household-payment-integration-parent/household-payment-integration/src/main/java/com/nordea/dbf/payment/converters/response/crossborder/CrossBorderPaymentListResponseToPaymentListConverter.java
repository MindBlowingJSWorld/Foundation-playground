package com.nordea.dbf.payment.converters.response.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListResponsePaymentCollectionSegment;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class CrossBorderPaymentListResponseToPaymentListConverter implements ResponseConverter<GetCrossBorderPaymentListResponseRecord,  List<Payment>> {
    @Autowired
    @Qualifier("householdErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public List<Payment> responseConvert(ServiceData serviceData, GetCrossBorderPaymentListResponseRecord response) {
        CrossBorderPaymentListResponsePaymentSegmentToPaymentConverter segmentToPaymentConverter = new CrossBorderPaymentListResponsePaymentSegmentToPaymentConverter();
        List<Payment> paymentList = new ArrayList<>();
        response.getPaymentCollection().forEachRemaining(s -> {
            Payment payment = segmentToPaymentConverter.convert(serviceData, (GetCrossBorderPaymentListResponsePaymentCollectionSegment) s);

            // TODO: Recurring is currently not provided in the Segment section, either lookup or discuss with domain to correct if all data should be equal for listing.
            //handleRecurring(source, payment);
            paymentList.add(payment);
        });
        return paymentList;
    }
}
