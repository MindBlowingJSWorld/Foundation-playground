package com.nordea.dbf.payment.converters.response.crossborder;

import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.common.model.AccountKeyFormat;
import com.nordea.dbf.payment.converters.LegacyCrossBorderConverter;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentResponseRecord;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentResponseUrgencyTypeCollectionSegment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.nordea.dbf.util.StringTemplate.usingMap;

@Component
public class GetCrossBorderPaymentResponseToPaymentConverter implements ResponseConverter<GetCrossBorderPaymentResponseRecord, Payment> {

    // FIXME ..
    private static final DateTimeFormatter RESPONSE_DATE_FORMAT = DateTimeFormatter.ofPattern("yyMMdd");
    // FIXME ..
    private static final Pattern ID_AND_CURRENCY_PATTERN = Pattern.compile("(?<accountNumber>\\d+)(?<currencyCode>[A-Z]{3})");

    @Autowired
    @Qualifier("householdErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public Payment responseConvert(ServiceData serviceData, GetCrossBorderPaymentResponseRecord responseRecord) {
        // Special handling of a result meaning payment not found.
        if (responseRecord.getKbearb() == 8 && responseRecord.getKrc() == 200) {
            return null;
        }

        final Payment payment = new Payment();
        final Matcher matcher = ID_AND_CURRENCY_PATTERN.matcher(responseRecord.getFromAccountIdAndCurrency());

        if (!matcher.matches()) {
            throw ErrorResponses.backendErrorException(ErrorResponses.Codes.INVALID_FIELD, "GetCrossBorderPaymentResponse", "Invalid fromAccountIdAndCurrency format");
        }

        payment.setId(responseRecord.getFromAccountId() + responseRecord.getInputDate() + responseRecord.getLegacyKey());
        payment.setStatus(LegacyCrossBorderConverter.convertCrossBorderLegacyStatus(responseRecord.getPaymentStatusCode()));
        payment.setAmount(responseRecord.getAmount());
        payment.setCurrency(responseRecord.getCurrency());
        payment.setEntryDate(LocalDate.parse(responseRecord.getInputDate(), RESPONSE_DATE_FORMAT).atStartOfDay());
        payment.setDue(LocalDate.parse(responseRecord.getExecutionDate(), RESPONSE_DATE_FORMAT));
        payment.setOwnMessage(responseRecord.getOwnReference());
        payment.setMessage(responseRecord.getReferenceTextF());
        payment.setType(Payment.TypeEnum.crossborder);
        payment.setRecipientName(responseRecord.getReceivingBankName());
        payment.setCrossBorder(new CrossBorder()
                .setAddress(Arrays.asList(responseRecord.getReceivingBankAddress1(), responseRecord.getReceivingBankAddress2(), responseRecord.getReceivingBankAddress3()))
                .setBankCountry(responseRecord.getReceivingBankCountry())
                .setBic(responseRecord.getReceivingBankBIC())
                .setBranchCode(responseRecord.getReceivingBankCode())
                .setCentralBankReportingCode(responseRecord.getCbrCode())
                .setChargePaidBy(LegacyCrossBorderConverter.convertLegacyChargePaidByToModel(responseRecord.getChargePaidBy()))
                .setSepaReference(null)); // TODO SEPA reference not available

        payment.setFrom(AccountKeyFormat.NAID_ACCOUNT_FORMAT.expand(usingMap(ImmutableMap.of(
                "currency", matcher.group("currencyCode"),
                "accountNumber", matcher.group("accountNumber")))));

        payment.setTo(AccountKeyFormat.CROSS_BORDER_TRANSFERS.expand(usingMap(ImmutableMap.of(
                "bicCode", responseRecord.getReceivingBankBIC(),
                "iban", responseRecord.getToAccountId()))));

        final Iterator urgency = responseRecord.getUrgencyTypeCollection();

        if (!urgency.hasNext()) {
            payment.setSpeed(Payment.SpeedEnum.normal);
        } else {
            final GetCrossBorderPaymentResponseUrgencyTypeCollectionSegment urgencySegment
                    = (GetCrossBorderPaymentResponseUrgencyTypeCollectionSegment) urgency.next();

            if (Objects.equals(urgencySegment.getUrgencyType(), LegacyCrossBorderConverter.URGENT_LEGACY_CODE)) {
                payment.setSpeed(Payment.SpeedEnum.express);
            } else {
                throw ErrorResponses.backendErrorException(ErrorResponses.Codes.NOT_UNDERSTOOD, "speed",
                        "Urgency type '" + urgencySegment.getUrgencyType() + "' not understood");
            }

            if (urgency.hasNext()) {
                throw ErrorResponses.backendErrorException(ErrorResponses.Codes.NOT_UNDERSTOOD, "speed",
                        "Multiple urgency types available in backend response");
            }
        }

        return payment;
    }
}
