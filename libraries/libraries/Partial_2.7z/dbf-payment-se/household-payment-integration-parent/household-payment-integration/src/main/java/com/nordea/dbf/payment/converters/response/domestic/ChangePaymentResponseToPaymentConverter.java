package com.nordea.dbf.payment.converters.response.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.LegacyAccountKeyConverter;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.converters.LegacyPaymentPermissionsConverter;
import com.nordea.dbf.payment.model.HouseholdPayment;
import com.nordea.dbf.payment.record.domestic.ChangePaymentResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class ChangePaymentResponseToPaymentConverter implements ResponseConverter<ChangePaymentResponseRecord, Payment> {
    @Autowired
    @Qualifier("householdErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public Payment responseConvert(ServiceData serviceData, ChangePaymentResponseRecord responseRecord) {
        final LegacyGiroType legacyGiroType = LegacyGiroType.fromCode(responseRecord.getGiroType());
        final Payment payment = new Payment();

        payment.setAmount(BigDecimal.valueOf(responseRecord.getAmount()));
        payment.setCurrency(responseRecord.getTransactionCurrency());
        payment.setDue(LocalDate.parse(responseRecord.getDueDate(), DateTimeFormatter.ISO_LOCAL_DATE));
        payment.setFrom(LegacyAccountKeyConverter.accountKeyOf(StringUtils.EMPTY, responseRecord.getFromAccount(), responseRecord.getFromAccountCurrencyCode()));
        payment.setId(String.valueOf(responseRecord.getPaymentId()));
        payment.setMessage(responseRecord.getMessage());
        payment.setOwnMessage(responseRecord.getOwnReference());
        payment.setStatus(LegacyPaymentStatus.fromCode(responseRecord.getPaymentStatus()).asPaymentStatus());
        payment.setTo(LegacyAccountKeyConverter.accountKeyOf(responseRecord.getGiroType(), responseRecord.getToAccount(), responseRecord.getToAccountCurrencyCode()));
        payment.setType(legacyGiroType.toPaymentType());
        payment.setRecipientName(responseRecord.getReceiverName());
        payment.setReference(responseRecord.getEinvoiceId());

        handleRecurring(responseRecord, payment);
        handlePermissions(responseRecord, payment);

        return payment;
    }

    // TODO: Move these out from the converters.
    private void handlePermissions(final ChangePaymentResponseRecord record, final Payment payment) {
        payment.setPermissions(LegacyPaymentPermissionsConverter.paymentPermissionsOf(record.getAllowedToModify(), record.getAllowedToCopy(), record.getAllowedToDelete()));
    }

    private void handleRecurring(final ChangePaymentResponseRecord paymentResponseRecord, final Payment payment) {
        int recurringNumber = paymentResponseRecord.getRecurringNumber();
        // The recurring continuously isn't set properly in the backend service so it can't be trusted on, so we need to complement with checking the recurring number being 999...
        boolean recurringContinuously = "Y".equals(paymentResponseRecord.getRecurringContinously()) || HouseholdPayment.RECURR_FOR_EVER == recurringNumber;

        if (recurringContinuously || recurringNumber > 1) {
            PaymentRecurring recurring = new PaymentRecurring()
                    .setCount(recurringContinuously ? null : recurringNumber)
                    //Frequency and interval given by business rules...
                    .setFrequency(1)
                    .setInterval(PaymentRecurring.IntervalEnum.monthly)
                    .setLastday(false);
            payment.setRecurring(recurring);
        }
    }
}
