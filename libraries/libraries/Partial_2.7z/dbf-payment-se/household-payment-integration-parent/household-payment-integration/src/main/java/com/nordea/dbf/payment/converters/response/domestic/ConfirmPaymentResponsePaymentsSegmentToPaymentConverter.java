package com.nordea.dbf.payment.converters.response.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentResponsePaymentsSegment;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class ConfirmPaymentResponsePaymentsSegmentToPaymentConverter implements Converter<ConfirmPaymentResponsePaymentsSegment, Payment> {
    @Override
    public Payment convert(ServiceData serviceData, ConfirmPaymentResponsePaymentsSegment segment) {
        final Payment payment = new Payment();

        if (!StringUtils.isEmpty(segment.getDueDate())) {
            payment.setDue(LocalDate.parse(segment.getDueDate(), DateTimeFormatter.ISO_LOCAL_DATE));
        }

        payment.setId(String.valueOf(segment.getPaymentId()));
        payment.setStatus(LegacyPaymentStatus.fromCode(segment.getPaymentStatus()).asPaymentStatus());

        return payment;
    }
}
