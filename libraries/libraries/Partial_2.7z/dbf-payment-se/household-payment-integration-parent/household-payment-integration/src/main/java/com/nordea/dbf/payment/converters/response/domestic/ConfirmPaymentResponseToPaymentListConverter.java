package com.nordea.dbf.payment.converters.response.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentResponsePaymentsSegment;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.util.ArrayList;
import java.util.List;

@Component
public class ConfirmPaymentResponseToPaymentListConverter implements ResponseConverter<ConfirmPaymentResponseRecord, Payment> {
    @Autowired
    @Qualifier("householdErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }


    @Override
    public Payment responseConvert(ServiceData serviceData, ConfirmPaymentResponseRecord response) {
        ConfirmPaymentResponsePaymentsSegmentToPaymentConverter segmentConverter = new ConfirmPaymentResponsePaymentsSegmentToPaymentConverter();
        List<Payment> paymentList = new ArrayList<>();

        response.getPayments().forEachRemaining(s -> paymentList.add(segmentConverter.convert(serviceData, (ConfirmPaymentResponsePaymentsSegment) s)));

        // We only send one payment down for confirmation.
        return paymentList.get(0);
    }
}
