package com.nordea.dbf.payment.converters.response.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.converters.LegacyAccountKeyConverter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.converters.LegacyPaymentPermissionsConverter;
import com.nordea.dbf.payment.record.domestic.PaymentListResponsePaymentsSegment;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class PaymentListResponsePaymentsSegmentToPaymentConverter implements Converter<PaymentListResponsePaymentsSegment, Payment> {

    @Override
    public Payment convert(ServiceData serviceData, PaymentListResponsePaymentsSegment source) {
        if(null == source.getGiroType() || null == LegacyGiroType.fromCode(source.getGiroType())) {
            return null;
        }

        final LegacyGiroType legacyGiroType = LegacyGiroType.fromCode(source.getGiroType());

        final Payment payment = new Payment();
        payment.setAmount(BigDecimal.valueOf(source.getAmount()));
        payment.setCurrency(source.getTransactionCurrency());
        payment.setDue(LocalDate.parse(source.getDueDate(), DateTimeFormatter.ISO_LOCAL_DATE));
        payment.setFrom(LegacyAccountKeyConverter.accountKeyOf(StringUtils.EMPTY, source.getFromAccount(), source.getFromAccountCurrency()));
        payment.setId(String.valueOf(source.getPaymentId()));
        payment.setStatus(LegacyPaymentStatus.fromCode(source.getPaymentStatus()).asPaymentStatus());
        payment.setTo(LegacyAccountKeyConverter.accountKeyOf(source.getGiroType(), source.getToAccount(), source.getToAccountCurrency()));
        payment.setType(legacyGiroType.toPaymentType());
        payment.setRecipientName(source.getReceiverName());
        payment.setReference(source.getEinvoiceId());

        payment.setPermissions(LegacyPaymentPermissionsConverter.paymentPermissionsOf(
                source.getAllowedToModify(),
                source.getAllowedToCopy(),
                source.getAllowedToDelete()));

        return payment;
    }
}
