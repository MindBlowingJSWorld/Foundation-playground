package com.nordea.dbf.payment.converters.response.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.record.domestic.PaymentListResponsePaymentsSegment;
import com.nordea.dbf.payment.record.domestic.PaymentListResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.util.ArrayList;
import java.util.List;

@Component
public class PaymentListResponseRecordToPaymentListConverter implements ResponseConverter<PaymentListResponseRecord, List<Payment>> {
    @Autowired
    @Qualifier("householdErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public List<Payment> responseConvert(ServiceData serviceData, PaymentListResponseRecord paymentListResponseRecord) {
        PaymentListResponsePaymentsSegmentToPaymentConverter converter = new PaymentListResponsePaymentsSegmentToPaymentConverter();

        // Iterate over all payment segments and convert them into Payments.
        List<Payment> paymentList = new ArrayList<>();
        paymentListResponseRecord.getPayments().forEachRemaining(s -> {
            Payment payment = converter.convert(serviceData, (PaymentListResponsePaymentsSegment) s);

            // TODO: Recurring is currently not provided in the Segment section, either lookup or discuss with domain to correct if all data should be equal for listing.
            //handleRecurring(source, payment);
            paymentList.add(payment);
        });

        return paymentList;
    }
}
