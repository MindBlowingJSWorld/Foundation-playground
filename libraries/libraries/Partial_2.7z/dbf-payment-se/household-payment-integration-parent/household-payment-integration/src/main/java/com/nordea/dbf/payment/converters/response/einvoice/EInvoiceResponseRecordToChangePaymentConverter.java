package com.nordea.dbf.payment.converters.response.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.model.LegacyEInvoice;
import com.nordea.dbf.payment.record.domestic.EInvoiceResponseEInvoicesSegment;
import com.nordea.dbf.payment.record.domestic.EInvoiceResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.util.ArrayList;
import java.util.List;

import static com.nordea.dbf.http.errorhandling.ErrorResponses.unauthorizedAccessException;

@Component
public class EInvoiceResponseRecordToChangePaymentConverter implements ResponseConverter<EInvoiceResponseRecord, List<Payment>> {

    @Autowired
    EInvoiceToPaymentConverter eInvoiceToPaymentConverter;

    @Autowired
    @Qualifier("eInvoiceErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        if (kbearb == 4 && krc == 5) {
            throw unauthorizedAccessException("Only read access to fee-account", StringUtils.EMPTY);
        }
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public List<Payment> responseConvert(ServiceData serviceData, EInvoiceResponseRecord responseRecord) {
        List<Payment> paymentList = new ArrayList<>(responseRecord.getNoOfEInvoices());

        responseRecord.getEInvoices().forEachRemaining(s -> {
            Payment payment = eInvoiceToPaymentConverter.convert(serviceData, new LegacyEInvoice((EInvoiceResponseEInvoicesSegment) s));
            payment.setType(CommonPaymentType.fromPayment(payment, false));
            paymentList.add(payment);
        });
        return paymentList;
    }
}
