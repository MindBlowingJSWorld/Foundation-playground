package com.nordea.dbf.payment.converters.response.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.model.LegacyEInvoice;
import com.nordea.dbf.payment.record.domestic.EInvoiceResponseEInvoicesSegment;
import com.nordea.dbf.payment.record.domestic.EInvoiceResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.util.ArrayList;
import java.util.List;

@Component
public class EInvoiceResponseRecordToEInvoiceConverter implements ResponseConverter<EInvoiceResponseRecord, List<EInvoice>> {

    @Autowired
    @Qualifier("eInvoiceErrorHandler")
    BackendErrorHandler backendErrorHandler;

    @Override
    public List<EInvoice> convert(ServiceData serviceData, EInvoiceResponseRecord responseRecord) {
        if (responseRecord.getKbearb() == 4 && responseRecord.getKrc() == 5) {
            return new ArrayList<>();
        }
        this.errorHandler(responseRecord.getKbearb(), responseRecord.getKrc());
        return this.responseConvert(serviceData, responseRecord);
    }

    @Override
    public void errorHandler(int kbearb, int krc) {
        backendErrorHandler.check(kbearb, krc);
    }

    @Override
    public List<EInvoice> responseConvert(ServiceData serviceData, EInvoiceResponseRecord responseRecord) {
        List<EInvoice> eInvoiceList = new ArrayList<>(responseRecord.getNoOfEInvoices());

        responseRecord.getEInvoices().forEachRemaining(s ->
            eInvoiceList.add(new LegacyEInvoice((EInvoiceResponseEInvoicesSegment) s))
        );
        return eInvoiceList;
    }
}
