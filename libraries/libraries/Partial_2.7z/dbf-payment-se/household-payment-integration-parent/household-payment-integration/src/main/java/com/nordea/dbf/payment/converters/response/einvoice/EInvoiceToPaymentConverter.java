package com.nordea.dbf.payment.converters.response.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.converters.LegacyAccountKeyConverter;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.model.EInvoices;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.time.LocalDateTime;
import java.time.ZoneId;

@Component
public class EInvoiceToPaymentConverter implements Converter<EInvoice, Payment> {

    @Override
    public Payment convert(ServiceData serviceData, EInvoice source) {
        // FIXME: It doesn't make sense that this many fields are nullable.

        final Payment payment = new Payment();

        if (!StringUtils.isEmpty(source.getPaymentStatusCode())) {
            payment.setStatus(LegacyPaymentStatus.fromCode(source.getPaymentStatusCode()).asPaymentStatus());
        }

        if (source.getCurrency() != null) {
            payment.setCurrency(source.getCurrency().getCurrencyCode());

            if (source.getFromAccount() != 0) {
                payment.setFrom(LegacyAccountKeyConverter.accountKeyOf(StringUtils.EMPTY, source.getFromAccount(), source.getCurrency().getCurrencyCode()));
            }

            if (source.getToAccount() != 0) {
                payment.setTo(LegacyAccountKeyConverter.accountKeyOf(source.getGiroType(), source.getToAccount(), source.getCurrency().getCurrencyCode()));
            }
        }

        if (source.getAmount() != null) {
            payment.setAmount(source.getAmount());
        }

        if (source.getDueDate() != null) {
            payment.setDue(source.getDueDate());
        }

        if (source.getArrivalDate() != null) {
            payment.setEntryDate(LocalDateTime.from(source.getArrivalDate().atStartOfDay(ZoneId.systemDefault())));
        }

        if (!StringUtils.isEmpty(source.getUrlHotel())) {
            payment.setUrl("einvoice:" + source.getUrlHotel() + "?invoicer_id=" + source.getInvoicerId() + "&ticket_type=" + source.getTicketType());
        }

        if (!StringUtils.isEmpty(source.getOwnReference())) {
            payment.setOwnMessage(source.getOwnReference());
        }

        if (!StringUtils.isEmpty(source.getInvoiceId())) {
            payment.setReference(source.getInvoiceId());
        }
        if (!StringUtils.isEmpty(source.getInvoicerName())) {
            payment.setRecipientName(source.getInvoicerName());
        }

        payment.setType(Payment.TypeEnum.einvoice);
        payment.setPermissions(EInvoices.defaultEInvoicePermissions());

        payment.setMessage(source.getMessage());

        if (source.getPaymentId() != 0) {
            payment.setId(String.valueOf(source.getPaymentId()));
        } else {
            payment.setId(source.getInvoiceId());
        }

        return payment;
    }
}
