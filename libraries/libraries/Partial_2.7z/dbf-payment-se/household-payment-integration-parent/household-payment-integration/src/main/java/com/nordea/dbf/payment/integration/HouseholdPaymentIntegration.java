package com.nordea.dbf.payment.integration;

import com.google.common.collect.Iterators;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.nordea.dbf.agreement.customer.se.model.Agreement;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.InternalServerErrorException;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.util.M8RequestResponseWrapper;
import com.nordea.dbf.payment.converters.request.crossborder.*;
import com.nordea.dbf.payment.converters.request.domestic.*;
import com.nordea.dbf.payment.converters.request.einvoice.*;
import com.nordea.dbf.payment.converters.response.crossborder.ConfirmCrossBorderPaymentResponseToPaymentConverter;
import com.nordea.dbf.payment.converters.response.crossborder.CrossBorderPaymentIdResponseToPaymentConverter;
import com.nordea.dbf.payment.converters.response.crossborder.CrossBorderPaymentListResponseToPaymentListConverter;
import com.nordea.dbf.payment.converters.response.crossborder.GetCrossBorderPaymentResponseToPaymentConverter;
import com.nordea.dbf.payment.converters.response.domestic.*;
import com.nordea.dbf.payment.converters.response.einvoice.EInvoiceResponseRecordToChangePaymentConverter;
import com.nordea.dbf.payment.converters.response.einvoice.EInvoiceResponseRecordToEInvoiceConverter;
import com.nordea.dbf.payment.converters.response.einvoice.EInvoiceToPaymentConverter;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.record.crossborder.household.*;
import com.nordea.dbf.payment.record.domestic.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This is primarily a wrapper class to encapsulate the logic required to distinguish between E-invoice / CrossBorder / Domestic / Own-Transfer from the facade.
 */
public class HouseholdPaymentIntegration {
    private static final Logger LOGGER = LoggerFactory.getLogger(HouseholdPaymentIntegration.class);

    @Autowired
    private M8RequestResponseWrapper m8RequestResponseWrapper;

    /*
       Converters autowired below
     */
    @Autowired
    private PaymentFilterToCrossborderPaymentListRequestRecord paymentFilterToCrossborderPaymentListRequestRecord;
    @Autowired
    private PaymentFilterToPaymentListRequestRecord paymentFilterToPaymentListRequestRecord;
    @Autowired
    private CrossBorderPaymentListResponseToPaymentListConverter crossBorderPaymentListResponseToPaymentListConverter;
    @Autowired
    private PaymentListResponseRecordToPaymentListConverter paymentListResponseRecordToPaymentListConverter;

    @Autowired
    private PaymentToGetPaymentRequestRecord paymentToGetPaymentRequestRecord;
    @Autowired
    private PaymentToGetCrossBorderPaymentRecord paymentToGetCrossBorderPaymentRecord;
    @Autowired
    private GetPaymentResponseToPaymentConverter getPaymentResponseToPaymentConverter;
    @Autowired
    private GetCrossBorderPaymentResponseToPaymentConverter getCrossBorderPaymentResponseToPaymentConverter;
    @Autowired
    private EInvoiceToChangeEInvoiceRequestRecord eInvoiceToChangeEInvoiceRequestRecord;
    @Autowired
    private PaymentToGetEInvoiceRequestRecord paymentToGetEInvoiceRequestRecord;
    @Autowired
    private EInvoiceToPaymentConverter eInvoiceToPaymentConverter;
    @Autowired
    private EInvoiceResponseRecordToEInvoiceConverter eInvoiceResponseRecordToEInvoiceConverter;
    @Autowired
    private PaymentToConfirmEInvoiceRequestRecord paymentToConfirmEInvoiceRequestRecord;
    @Autowired
    private PaymentToDeleteEInvoiceRequestRecord paymentToDeleteEInvoiceRequestRecord;
    @Autowired
    private PaymentFilterToGetEInvoicesRequestRecord paymentFilterToGetEInvoicesRequestRecord;
    @Autowired
    private EInvoiceResponseRecordToChangePaymentConverter eInvoiceResponseRecordToChangePaymentConverter;

    @Autowired
    private PaymentToDeletePaymentRequestRecord paymentToDeletePaymentRequestRecord;
    @Autowired
    private PaymentToDeleteCrossBorderPaymentRequestRecord paymentToDeleteCrossBorderPaymentRequestRecord;
    @Autowired
    private DeletePaymentResponseToPaymentConverter deletePaymentResponseToPaymentConverter;
    @Autowired
    private CrossBorderPaymentIdResponseToPaymentConverter crossBorderPaymentIdResponseToPaymentConverter;

    @Autowired
    private PaymentToConfirmCrossBorderPaymentRequestRecord paymentToConfirmCrossBorderPaymentRequestRecord;
    @Autowired
    private PaymentToConfirmPaymentRequestRecord paymentToConfirmPaymentRequestRecord;
    @Autowired
    private ConfirmCrossBorderPaymentResponseToPaymentConverter confirmCrossBorderPaymentResponseToPaymentConverter;
    @Autowired
    private ConfirmPaymentResponseToPaymentListConverter confirmPaymentResponseToPaymentListConverter;

    @Autowired
    private PaymentToCreatePaymentRequestRecord paymentToCreatePaymentRequestRecord;
    @Autowired
    private PaymentToCreateCrossborderPaymentRequestRecord paymentToCreateCrossborderPaymentRequestRecord;
    @Autowired
    private PaymentToCreateThirdpartyPaymentRequestRecord paymentToCreateThirdpartyPaymentRequestRecord;
    @Autowired
    private CreatePaymentResponseToPaymentConverter createPaymentResponseToPaymentConverter;

    @Autowired
    private PaymentToChangeCrossborderPaymentRequestRecord paymentToChangeCrossborderPaymentRequestRecord;
    @Autowired
    private PaymentToChangePaymentRequestRecord paymentToChangePaymentRequestRecord;
    @Autowired
    private PaymentToChangeThirdpartyPaymentRequestRecord paymentToChangeThirdpartyPaymentRequestRecord;
    @Autowired
    private ChangePaymentResponseToPaymentConverter changePaymentResponseToPaymentConverter;


    //########################################
    //######            Create          ######
    //########################################

    @HystrixCommand(groupKey = "JCA", commandKey = "createHouseholdDomesticPayment")
    public Observable<Payment> createHouseholdDomesticPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToCreatePaymentRequestRecord, createPaymentResponseToPaymentConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "createHouseholdThirdPartyPayment")
    public Observable<Payment> createHouseholdThirdPartyPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToCreateThirdpartyPaymentRequestRecord, createPaymentResponseToPaymentConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "createHouseholdCrossBorderPayment")
    public Observable<Payment> createHouseholdCrossBorderPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToCreateCrossborderPaymentRequestRecord, crossBorderPaymentIdResponseToPaymentConverter);
    }

    //########################################
    //######            Change          ######
    //########################################

    @HystrixCommand(groupKey = "JCA", commandKey = "changeHouseholdDomesticPayment")
    public Observable<Payment> changeHouseholdDomesticPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment, Payment originalPayment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToChangePaymentRequestRecord.with(originalPayment), changePaymentResponseToPaymentConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "changeHouseholdThirdPartyPayment")
    public Observable<Payment> changeHouseholdThirdPartyPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment, Payment originalPayment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToChangeThirdpartyPaymentRequestRecord.with(originalPayment), changePaymentResponseToPaymentConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "changeHouseholdCrossBorderPayment")
    public Observable<Payment> changeHouseholdCrossBorderPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToChangeCrossborderPaymentRequestRecord, crossBorderPaymentIdResponseToPaymentConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "changeHouseholdEInvoicePayment")
    public Observable<Payment> changeHouseholdEInvoicePayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        EInvoiceRequestRecord req = paymentToGetEInvoiceRequestRecord.convert(serviceData, payment);
        return connection.execute(req, EInvoiceResponseRecord.class)
                .map(res -> {
                    List<EInvoice> eInvoices = eInvoiceResponseRecordToEInvoiceConverter.convert(serviceData, res);
                    if (eInvoices.isEmpty()) {
                        LOGGER.error("Payment '{}' not found. Responding with a 404/Not found.", payment.getId());
                        throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(payment.getId()))));
                    } else if (eInvoices.size() > 1) {
                        LOGGER.warn("Request for payment '{}' resulted in more than one (1) result. Responding with a 500/Internal server error.", payment.getId());
                        throw new InternalServerErrorException(new Error().setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR).setErrorDescription("Payment data inconsistency"));
                    }

                    return eInvoices.get(0);
                })
                .map(eInvoice -> eInvoiceToChangeEInvoiceRequestRecord.with(eInvoice).convert(serviceData, payment))
                .flatMap(req2 -> connection.execute(req, EInvoiceResponseRecord.class).map(res2 -> {
                    List<Payment> paymentList = eInvoiceResponseRecordToChangePaymentConverter.convert(serviceData, res2);
                    if (paymentList.isEmpty()) {
                        LOGGER.error("Payment '{}' not found. Responding with a 404/Not found.", payment.getId());
                        throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(payment.getId()))));
                    } else if (paymentList.size() > 1) {
                        LOGGER.warn("Request for payment '{}' resulted in more than one (1) result. Responding with a 500/Internal server error.", payment.getId());
                        throw new InternalServerErrorException(new Error().setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR).setErrorDescription("Payment data inconsistency"));
                    }

                    return paymentList.get(0);
                }));
    }

    //########################################
    //######            Delete          ######
    //########################################

    @HystrixCommand(groupKey = "JCA", commandKey = "deleteHouseholdDomesticPayment")
    public Observable<Payment> deleteHouseholdDomesticPayment(M8ImsConnection connection, ServiceData serviceData, Payment originalPayment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, originalPayment, serviceData, paymentToDeletePaymentRequestRecord, deletePaymentResponseToPaymentConverter, p -> originalPayment);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "deleteHouseholdCrossBorderPayment")
    public Observable<Payment> deleteHouseholdCrossBorderPayment(M8ImsConnection connection, ServiceData serviceData, Payment originalPayment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, originalPayment, serviceData, paymentToDeleteCrossBorderPaymentRequestRecord, crossBorderPaymentIdResponseToPaymentConverter, p -> originalPayment);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "deleteHouseholdEInvoicePayment")
    public Observable<Payment> deleteHouseholdEInvoicePayment(M8ImsConnection connection, ServiceData serviceData, Payment originalPayment) {
        EInvoiceRequestRecord req = paymentToDeleteEInvoiceRequestRecord.convert(serviceData, originalPayment);
        return connection.execute(req, EInvoiceResponseRecord.class)
                // Validate errors codes
                .map(res -> {
                    List<EInvoice> eInvoices = eInvoiceResponseRecordToEInvoiceConverter.convert(serviceData, res);
                    if (eInvoices.isEmpty()) {
                        LOGGER.error("Payment '{}' not found. Responding with a 404/Not found.", originalPayment.getId());
                        throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(originalPayment.getId()))));
                    } else if (eInvoices.size() > 1) {
                        LOGGER.warn("Request for payment '{}' resulted in more than one (1) result. Responding with a 500/Internal server error.", originalPayment.getId());
                        throw new InternalServerErrorException(new Error().setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR).setErrorDescription("Payment data inconsistency"));
                    }
                    return eInvoices.get(0);
                })
                // Return the originalPayment
                .map(eInvoice -> originalPayment);
    }

    //########################################
    //######            Confirm         ######
    //########################################


    @HystrixCommand(groupKey = "JCA", commandKey = "confirmHouseholdDomesticPayment")
    public Observable<Payment> confirmHouseholdDomesticPayment(M8ImsConnection connection, ServiceData serviceData, Payment originalPayment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, originalPayment, serviceData, paymentToConfirmPaymentRequestRecord, confirmPaymentResponseToPaymentListConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "confirmHouseholdCrossBorderPayment")
    public Observable<Payment> confirmHouseholdCrossBorderPayment(M8ImsConnection connection, ServiceData serviceData, Payment originalPayment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, originalPayment, serviceData, paymentToConfirmCrossBorderPaymentRequestRecord, confirmCrossBorderPaymentResponseToPaymentConverter);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "confirmHouseholdEInvoicePayment")
    public Observable<Payment> confirmHouseholdEInvoicePayment(M8ImsConnection connection, ServiceData serviceData, Payment originalPayment) {
        EInvoiceRequestRecord req = paymentToConfirmEInvoiceRequestRecord.convert(serviceData, originalPayment);
        return connection.execute(req, EInvoiceResponseRecord.class)
                .map(res -> {
                    List<EInvoice> eInvoices = eInvoiceResponseRecordToEInvoiceConverter.convert(serviceData, res);
                    if (eInvoices.isEmpty()) {
                        LOGGER.error("Payment '{}' not found. Responding with a 404/Not found.", originalPayment.getId());
                        throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(originalPayment.getId()))));
                    } else if (eInvoices.size() > 1) {
                        LOGGER.warn("Request for payment '{}' resulted in more than one (1) result. Responding with a 500/Internal server error.", originalPayment.getId());
                        throw new InternalServerErrorException(new Error().setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR).setErrorDescription("Payment data inconsistency"));
                    }
                    return eInvoices.get(0);
                })
                .map(eInvoice -> eInvoiceToPaymentConverter.convert(serviceData, eInvoice));
    }

    //########################################
    //######         getPayments        ######
    //########################################

    @HystrixCommand(groupKey = "JCA", commandKey = "getHouseholdDomesticPayments")
    public Observable<Payment> getHouseholdDomesticPayments(M8ImsConnection connection, ServiceData serviceData, PaymentFilter paymentFilter) {
        List<PaymentListRequestRecord> paymentListRequestRecords = paymentFilterToPaymentListRequestRecord.convert(serviceData, paymentFilter);
        Observable<Payment> householdPaymentContinuation = Observable.empty();
        if (paymentListRequestRecords.size() > 0) {
            for (PaymentListRequestRecord req : paymentListRequestRecords) {
                householdPaymentContinuation = householdPaymentContinuation.mergeWith(getHouseholdPaymentContinuation(connection, serviceData, req));
            }

        }
        return householdPaymentContinuation;
    }

    private Observable<Payment> getHouseholdPaymentContinuation(M8ImsConnection connection, ServiceData serviceData, PaymentListRequestRecord req) {
        return connection.execute(req, PaymentListResponseRecord.class).concatMap(res -> {
            List<Payment> paymentList = paymentListResponseRecordToPaymentListConverter.convert(serviceData, res);
            if ("Y".equals(res.getMoreRecords())) {
                final PaymentListResponsePaymentsSegment last = (PaymentListResponsePaymentsSegment) Iterators.getLast(res.getPayments());
                req.setContinueKeyAcct(last.getFromAccount());
                req.setContinueKeyPayId(last.getPaymentId());
                return Observable.from(paymentList).concatWith(getHouseholdPaymentContinuation(connection, serviceData, req));
            } else {
                return Observable.from(paymentList);
            }
        });
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getHouseholdCrossBorderPayments")
    public Observable<Payment> getHouseholdCrossBorderPayments(M8ImsConnection connection, ServiceData serviceData, PaymentFilter paymentFilter) {
        Observable<Payment> paymentObservable;

        //TODO: This is an optimization that can be used if the error response from the backend is correctly captured.
/*        if (paymentFilter.getPaymentFilterTypes().size() == 2 &&
                paymentFilter.getPaymentFilterTypes().containsAll(Arrays.asList(PaymentFilterType.PAYMENT_ID, PaymentFilterType.FROM_ACCOUNT))) {
            // Crossborder support filtering by ID, use it explicitly if only filtering on ID (from account is always given).
            Payment p = new Payment();
            p.setId(paymentFilter.getPaymentId());
            paymentObservable = getHouseholdCrossborderPayment(serviceData, p);
        } else {
*/
        GetCrossBorderPaymentListRequestRecord req = paymentFilterToCrossborderPaymentListRequestRecord.convert(serviceData, paymentFilter);
        paymentObservable = getHouseholdCrossBorderContinuation(connection, serviceData, req);
//        }
        return paymentObservable;
    }

    private Observable<Payment> getHouseholdCrossBorderContinuation(M8ImsConnection connection, ServiceData serviceData, GetCrossBorderPaymentListRequestRecord req) {
        if (req == null) {
            return Observable.empty();
        }
        return connection.execute(req, GetCrossBorderPaymentListResponseRecord.class).concatMap(res -> {
            List<Payment> paymentList = crossBorderPaymentListResponseToPaymentListConverter.convert(serviceData, res);
            if (res.getContinueKey() != null &&
                    res.getContinueKey().length() > 0 &&
                    StringUtils.isNumeric(res.getContinueKey()) &&
                    Integer.valueOf(res.getContinueKey()) > 0) {
                req.setContinueKey(res.getContinueKey());
                return Observable.from(paymentList).concatWith(getHouseholdCrossBorderContinuation(connection, serviceData, req));
            } else {
                return Observable.from(paymentList);
            }
        });
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getHouseholdEInvoicePayments")
    public Observable<Payment> getHouseholdEInvoicePayments(M8ImsConnection connection, ServiceData serviceData, PaymentFilter paymentFilter) {
        EInvoiceRequestRecord req = paymentFilterToGetEInvoicesRequestRecord.convert(serviceData, paymentFilter);
        return getEInvoiceResponseRecordContinuation(connection, serviceData, req);
    }

    private Observable<Payment> getEInvoiceResponseRecordContinuation(M8ImsConnection connection, ServiceData serviceData, EInvoiceRequestRecord req) {
        if (req == null) {
            return Observable.empty();
        }
        return connection.execute(req, EInvoiceResponseRecord.class).concatMap(res -> {
            List<EInvoice> convert = eInvoiceResponseRecordToEInvoiceConverter.convert(serviceData, res);
            List<Payment> paymentList = convert.stream().map(e -> eInvoiceToPaymentConverter.convert(serviceData, e)).collect(Collectors.toList());
            if (res.getKbearb() == 0 && res.getKrc() == 4) {
                final Iterator<EInvoiceResponseEInvoicesSegment> iterator = res.getEInvoices();
                final EInvoiceResponseEInvoicesSegment lastSegment = Iterators.getLast(iterator);

                req.setContinuationKey(lastSegment.getInvoiceId());

                return Observable.from(paymentList).concatWith(getEInvoiceResponseRecordContinuation(connection, serviceData, req));
            } else {
                return Observable.from(paymentList);
            }
        });
    }

    //########################################
    //######         getPayment         ######
    //########################################

    @HystrixCommand(groupKey = "JCA", commandKey = "getHouseholdDomesticPayment")
    public Observable<Payment> getHouseholdDomesticPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToGetPaymentRequestRecord, getPaymentResponseToPaymentConverter)
            // This will filter householdPayments against ID.
            .filter(p -> p != null && p.getId().equals(payment.getId()));
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getHouseholdCrossBorderPayment")
    public Observable<Payment> getHouseholdCrossBorderPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToGetCrossBorderPaymentRecord, getCrossBorderPaymentResponseToPaymentConverter)
            .filter(p -> p != null);
    }

    @HystrixCommand(groupKey = "JCA", commandKey = "getHouseholdEInvoicePayment")
    public Observable<Payment> getHouseholdEInvoicePayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        EInvoiceRequestRecord req = paymentToGetEInvoiceRequestRecord.convert(serviceData, payment);
        return connection.execute(req, EInvoiceResponseRecord.class)
                .map(res ->{
                    List<EInvoice> eInvoices = eInvoiceResponseRecordToEInvoiceConverter.convert(serviceData, res);
                    if (eInvoices.isEmpty()) {
                        LOGGER.error("Payment '{}' not found. Responding with a 404/Not found.", payment.getId());
                        throw new NotFoundException(new Error().setError(ErrorResponses.Types.NOT_FOUND).setErrorDescription("Payment not found").setDetails(Arrays.asList(new ErrorDetails().setParam(payment.getId()))));
                    } else if (eInvoices.size() > 1) {
                        LOGGER.warn("Request for payment '{}' resulted in more than one (1) result. Responding with a 500/Internal server error.", payment.getId());
                        throw new InternalServerErrorException(new Error().setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR).setErrorDescription("Payment data inconsistency"));
                    }
                    return eInvoices.get(0);
                })
                .map(eInvoice -> eInvoiceToPaymentConverter.convert(serviceData, eInvoice));
    }
}
