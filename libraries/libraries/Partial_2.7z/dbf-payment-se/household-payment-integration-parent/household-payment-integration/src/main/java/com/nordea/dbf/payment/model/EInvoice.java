package com.nordea.dbf.payment.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Currency;

public interface EInvoice {

    String getInvoiceId();

    long getToAccount();

    LegacyEInvoice setToAccount(long toAccount);

    long getFromAccount();

    LegacyEInvoice setFromAccount(long fromAccount);

    String getGiroType();

    LegacyEInvoice setGiroType(String giroType);

    String getInvoicerName();

    BigDecimal getAmount();

    LegacyEInvoice setAmount(BigDecimal amount);

    Currency getCurrency();

    LegacyEInvoice setCurrency(Currency currency);

    LocalDate getDueDate();

    EInvoice setDueDate(LocalDate dueDate);

    LocalDate getArrivalDate();

    Boolean getIsOcr();

    String getTicketType();

    String getUrlHotel();

    String getInvoicerId();

    String getPaymentStatusCode();

    String getPaymentErrorType();

    boolean getNewDate();

    long getPaymentId();

    String getOwnCategory();

    LegacyEInvoice setOwnCategory(String ownCategory);

    String getOwnReference();

    LegacyEInvoice setOwnReference(String ownReference);

    String getMessage();

    LegacyEInvoice setMessage(String message);

}
