package com.nordea.dbf.payment.model;

import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import org.apache.commons.lang.StringUtils;

import java.util.Optional;

import static com.nordea.dbf.http.errorhandling.ErrorResponses.*;

public class EInvoiceErrorHandler implements BackendErrorHandler {

    @Override
    public <T extends ErrorResponse> Optional<T> exceptionOf(int kbearb, int krc) {
        /*if (kbearb == 4 && krc == 5) {
            return Optional.of((T) unauthorizedAccessException("Only read access to fee-account", StringUtils.EMPTY));
        } else */if (kbearb == 4 && krc == 8) {
            return Optional.of((T) unauthorizedAccessException("No access to fee-account", StringUtils.EMPTY));
        } else if (kbearb == 2 && krc == 1) {
            return Optional.of((T) internalErrorException("Invalid message id", StringUtils.EMPTY));
        } else if (kbearb == 2 && krc == 2) {
            return Optional.of((T) invalidRequestParameterException("userId", "Invalid user"));
        } else if (kbearb == 2 && krc == 3) {
            return Optional.of((T) invalidRequestParameterException("agreementNumber", "Invalid agreement"));
        } else if (kbearb == 2 && krc == 4) {
            return Optional.of((T) invalidRequestParameterException("eInvoiceId", "Invalid e-invoice id"));
        } else if (kbearb == 2 && krc == 5) {
            return Optional.of((T) internalErrorException("Bad count", StringUtils.EMPTY));
        } else if (kbearb == 8) {
            return Optional.of((T) backendErrorException(String.format("kbearb_%d_krc_%d", kbearb, krc), StringUtils.EMPTY, StringUtils.EMPTY));
        } else if (kbearb != 0 && krc != 0) {
            return Optional.of((T) backendErrorException(String.format("kbearb_%d_krc_%d", kbearb, krc), StringUtils.EMPTY, StringUtils.EMPTY));
        }
        return Optional.empty();
    }
}
