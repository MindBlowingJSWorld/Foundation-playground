package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.PaymentModifyFields;
import com.nordea.dbf.api.model.PaymentPermissions;

public class EInvoices {

    public static PaymentPermissions defaultEInvoicePermissions() {
        return new PaymentPermissions()
                .setCopy(false)
                .setDelete(true)
                .setModify(new PaymentModifyFields()
                        .setAmount(true)
                        .setDue(true)
                        .setFrom(true)
                        .setRecurringCount(false)
                        .setRecurringInterval(false)
                        .setRecurringLastday(false)
                        .setRecurringRepeats(false)
                        .setTo(true)
                        .setType(false));
    }
}
