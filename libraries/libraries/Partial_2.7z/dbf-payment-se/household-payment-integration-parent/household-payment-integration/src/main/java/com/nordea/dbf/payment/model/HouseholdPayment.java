package com.nordea.dbf.payment.model;

import java.text.SimpleDateFormat;

/**
 * Created by k306010 on 2016-02-22.
 *
 * A set of shared constants.
 */
public class HouseholdPayment {

    public static final String RECURR_ONCE = "001";

    public static final String RECURR_MONTHLY = "030";

    public static final int RECURR_FOR_EVER = 999;

    public static final SimpleDateFormat PAYMENT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd-HH.mm.ss.SSS000");

    public static final SimpleDateFormat PAYMENT_NONDELIMITED_DATE_FORMAT = new SimpleDateFormat("yyyyMMdd");

    public static final SimpleDateFormat PAYMENT_SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyMMdd");
}
