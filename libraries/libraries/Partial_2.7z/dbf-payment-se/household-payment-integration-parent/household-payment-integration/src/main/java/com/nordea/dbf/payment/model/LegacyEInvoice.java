package com.nordea.dbf.payment.model;

import com.nordea.dbf.payment.record.domestic.EInvoiceResponseEInvoicesSegment;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Currency;
import java.util.Objects;

public class LegacyEInvoice implements EInvoice {

    public static final DateTimeFormatter ARRIVAL_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    public static final DateTimeFormatter DUE_DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final EInvoiceResponseEInvoicesSegment segment;

    public LegacyEInvoice(EInvoiceResponseEInvoicesSegment segment) {
        Validate.notNull(segment, "segment can't be null");
        this.segment = segment;
    }

    public String getInvoiceId() {
        return segment.getInvoiceId();
    }

    public long getToAccount() {
        return segment.getToAccount();
    }

    @Override
    public LegacyEInvoice setToAccount(long toAccount) {
        segment.setToAccount(toAccount);
        return this;
    }

    public long getFromAccount() {
        return segment.getFromAccount();
    }

    @Override
    public LegacyEInvoice setFromAccount(long fromAccount) {
        segment.setFromAccount(fromAccount);
        return this;
    }

    @Override
    public String getGiroType() {
        return segment.getGiroType();
    }

    @Override
    public LegacyEInvoice setGiroType(String giroType) {
        segment.setGiroType(giroType);
        return this;
    }

    public String getInvoicerName() {
        return segment.getInvoicerName();
    }

    public BigDecimal getAmount() {
        return BigDecimal.valueOf(segment.getAmount());
    }

    @Override
    public LegacyEInvoice setAmount(BigDecimal amount) {
        segment.setAmount(amount.doubleValue());
        return this;
    }

    public Currency getCurrency() {
        if (StringUtils.isEmpty(segment.getCurrency())) {
            return null;
        }

        return Currency.getInstance(segment.getCurrency());
    }

    @Override
    public LegacyEInvoice setCurrency(Currency currency) {
        segment.setCurrency(currency.getCurrencyCode());
        return this;
    }

    public LocalDate getDueDate() {
        if (StringUtils.isEmpty(segment.getDueDate())) {
            return null;
        }

        return LocalDate.parse(segment.getDueDate(), DUE_DATE_FORMAT);
    }

    @Override
    public EInvoice setDueDate(LocalDate dueDate) {
        segment.setDueDate(DUE_DATE_FORMAT.format(dueDate));
        return this;
    }

    public LocalDate getArrivalDate() {
        if (StringUtils.isEmpty(segment.getArrivalDate())) {
            return null;
        }

        return LocalDate.parse(segment.getArrivalDate(), ARRIVAL_DATE_FORMAT);
    }

    public Boolean getIsOcr() {
        return segment.getIsOcr();
    }

    public String getTicketType() {
        return segment.getTicketType();
    }

    public String getUrlHotel() {
        return segment.getUrlHotel();
    }

    public String getInvoicerId() {
        return segment.getInvoicerId();
    }

    public String getPaymentStatusCode() {
        return segment.getPaymentStatusCode();
    }

    public String getPaymentErrorType() {
        return segment.getPaymentErrorType();
    }

    public boolean getNewDate() {
        return Objects.equals(segment.getNewDate(), "Y");
    }

    public long getPaymentId() {
        return segment.getPaymentId();
    }

    public String getOwnCategory() {
        return segment.getOwnCategory();
    }

    @Override
    public LegacyEInvoice setOwnCategory(String ownCategory) {
        segment.setOwnCategory(ownCategory);
        return this;
    }

    public String getOwnReference() {
        return segment.getOwnReference();
    }

    @Override
    public LegacyEInvoice setOwnReference(String ownReference) {
        segment.setOwnReference(ownReference);
        return this;
    }

    public String getMessage() {
        return segment.getMessage();
    }

    @Override
    public LegacyEInvoice setMessage(String message) {
        segment.setMessage(message);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LegacyEInvoice that = (LegacyEInvoice) o;

        return segment.equals(that.segment);

    }

    @Override
    public int hashCode() {
        return segment.hashCode();
    }

    @Override
    public String toString() {
        return "LegacyEInvoice{" +
                "invoiceId='" + getInvoiceId() + '\'' +
                ", toAccount=" + getToAccount() +
                ", fromAccount=" + getFromAccount() +
                ", invoicerName='" + getInvoicerName() + '\'' +
                ", amount=" + getAmount() +
                ", currency=" + getCurrency() +
                ", dueDate=" + getDueDate() +
                ", arrivalDate=" + getArrivalDate() +
                ", isOcr=" + getIsOcr() +
                ", ticketType='" + getTicketType() + '\'' +
                ", urlHotel='" + getUrlHotel() + '\'' +
                ", invoicerId='" + getInvoicerId() + '\'' +
                ", paymentStatusCode='" + getPaymentStatusCode() + '\'' +
                ", paymentErrorType='" + getPaymentErrorType() + '\'' +
                ", newDate=" + getNewDate() +
                ", paymentId=" + getPaymentId() +
                ", ownCategory='" + getOwnCategory() + '\'' +
                ", ownReference='" + getOwnReference() + '\'' +
                ", message='" + getMessage() + '\'' +
                '}';
    }
}
