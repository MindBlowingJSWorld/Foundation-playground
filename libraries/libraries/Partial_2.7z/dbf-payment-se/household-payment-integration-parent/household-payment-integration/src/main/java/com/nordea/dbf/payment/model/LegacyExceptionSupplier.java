package com.nordea.dbf.payment.model;

@FunctionalInterface
public interface LegacyExceptionSupplier {

    RuntimeException get(int kbearb, int krc);

}
