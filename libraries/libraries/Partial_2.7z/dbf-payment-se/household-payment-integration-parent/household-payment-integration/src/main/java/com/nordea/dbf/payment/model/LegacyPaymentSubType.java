package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;

public enum LegacyPaymentSubType {

    NORMAL("NO"),
    OWNTRANSFER("OT"),
    EINVOICE("EI"),
    DIRECTDEBIT("DD"),
    ELOAN("EL"),
    THIRDPARTY("TH"),
    NOTIFIEDPAYMENT("NP"),
    EUPAYMENT ("EU");

    private final String code;

    LegacyPaymentSubType(String code) {
        this.code = code;
    }

    public String code() {
        return code;
    }

    public static LegacyPaymentSubType fromAccountKey(AccountKey accountKey) {
        switch (accountKey.getPrefix()) {
            case PG:
            case BG:
                return LegacyPaymentSubType.NORMAL;
            case NAID:
            case LBAN:
                return LegacyPaymentSubType.THIRDPARTY;
        }

        throw new UnsupportedOperationException("Unknown account key: " + accountKey);
    }

    public static LegacyPaymentSubType fromPaymentType(Payment.TypeEnum paymentType) {
        switch (paymentType) {
            case plusgiro:
            case bankgiro:
                return LegacyPaymentSubType.NORMAL;
            case owntransfer:
                return LegacyPaymentSubType.OWNTRANSFER;
            case lban:
                return LegacyPaymentSubType.THIRDPARTY;
            case einvoice:
            case crossborder:
            default:
                throw new UnsupportedOperationException("Unknown payment type for domestic payment sub type: " + paymentType);
        }
    }
}
