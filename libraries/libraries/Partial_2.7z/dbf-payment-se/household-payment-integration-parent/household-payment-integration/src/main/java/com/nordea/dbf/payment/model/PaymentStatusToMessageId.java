package com.nordea.dbf.payment.model;

import com.nordea.dbf.api.model.Payment;

public class PaymentStatusToMessageId {

    private static final String MESSAGE_ID_UNCONFIRMED = "FQ85201";
    private static final String MESSAGE_ID_CONFIRMED = "FQ85211";
    private static final String MESSAGE_ID_REJECTED = "FQ85221";

    public static String getSubMessageIdByStatus(Payment.StatusEnum status) {
        switch (status) {
            case unconfirmed:
                return MESSAGE_ID_UNCONFIRMED;
            case confirmed:
                return MESSAGE_ID_CONFIRMED;
            case rejected:
                return MESSAGE_ID_REJECTED;
            default:
                return null;
        }
    }
}