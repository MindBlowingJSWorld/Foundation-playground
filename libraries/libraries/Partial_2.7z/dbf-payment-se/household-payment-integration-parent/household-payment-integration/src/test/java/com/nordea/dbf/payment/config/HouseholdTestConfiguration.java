package com.nordea.dbf.payment.config;

import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.payment.HouseholdPaymentFacade;
import com.nordea.dbf.payment.common.PaymentFacade;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.converters.request.einvoice.EInvoiceToChangeEInvoiceRequestRecord;
import com.nordea.dbf.payment.integrationtests.HouseholdTestDataManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Configuration
@ComponentScan(basePackages = "com.nordea.dbf.payment", excludeFilters = @ComponentScan.Filter(type = FilterType.ANNOTATION, value = Configuration.class))
public class HouseholdTestConfiguration {

    @Bean
    @Primary
    @Qualifier("householdErrorHandler")
    public BackendErrorHandler householdErrorHandler() {
        return mock(BackendErrorHandler.class);
    }

    @Bean
    @Autowired
    @Primary
    public M8ImsConnector m8ImsConnector(M8ImsConnection m8ImsConnection) {
        M8ImsConnector m8ImsConnector = mock(M8ImsConnector.class);
        when(m8ImsConnector.connect()).thenReturn(m8ImsConnection);
        return m8ImsConnector;
    }

    @Bean
    @Primary
    public M8ImsConnection m8ImsConnection() {
        return mock(M8ImsConnection.class);
    }

    @Bean
    @Primary
    @Qualifier("householdPaymentFacade")
    public PaymentFacade householdPaymentFacade() {
        return new HouseholdPaymentFacade();
    }

    @Bean
    public HouseholdTestDataManager householdTestDataManager() {
        return new HouseholdTestDataManager();
    }

    @Bean
    @Autowired
    public EInvoiceToChangeEInvoiceRequestRecord eInvoiceToChangeEInvoiceRequestRecord(final NilRequestMsgHeaders nilRequestMsgHeaders) {
        return new EInvoiceToChangeEInvoiceRequestRecord(nilRequestMsgHeaders);
    }
}
