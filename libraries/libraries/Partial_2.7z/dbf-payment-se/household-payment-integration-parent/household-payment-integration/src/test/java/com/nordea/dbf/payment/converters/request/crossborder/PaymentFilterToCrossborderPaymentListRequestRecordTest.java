package com.nordea.dbf.payment.converters.request.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.api.model.accountkey.ExternalAccountKey;
import com.nordea.dbf.filter.DateFilter;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.PaymentFilterType;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.converters.LegacyCrossBorderConverter;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListRequestFromAccountsSegment;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListRequestRecord;
import com.nordea.dbf.payment.record.crossborder.household.GetCrossBorderPaymentListRequestStatusCollectionSegment;
import com.nordea.dbf.payment.testdata.TestData;
import com.nordea.infra.record.nilheader.NilRequestMsgHeaderRecord;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentFilterToCrossborderPaymentListRequestRecordTest {

    private static final String ALL_PAYMENTS = "0";
    private static final String WHITESPACE = " ";
    private static final String EMPTY_DATE_STR = "000000";
    private static final String GET_CROSSBORDER_PAYMENT_LIST_TRANSACTION_CODE = "LHP61P57";
    private static final String EMPTY_STRING = "";


    private final NilRequestMsgHeaders nilRequestMsgHeadersMock;


    public PaymentFilterToCrossborderPaymentListRequestRecordTest() {
        nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
    }

    @Before
    public void init() {
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(ServiceRequestContext.class), any(NilRequestMsgHeaderRecord.class)))
                .thenReturn(new GetCrossBorderPaymentListRequestRecord());
    }

    @Test
    public void shouldMapFull() {
        PaymentFilterToCrossborderPaymentListRequestRecord paymentFilterToCrossborderPaymentListRequestRecord =
                new PaymentFilterToCrossborderPaymentListRequestRecord(nilRequestMsgHeadersMock);

        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        //Given
        PaymentFilter paymentFilter = mock(PaymentFilter.class);
        ListFilter<AccountKey> accountKeyListFilter = new ListFilter<>(Collections.singletonList(fromHouseHoldAccount));
        when(paymentFilter.getFromAccounts()).thenReturn(accountKeyListFilter);
        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");


        //When
        GetCrossBorderPaymentListRequestRecord resultValue =
                paymentFilterToCrossborderPaymentListRequestRecord.convert(serviceData, paymentFilter);

        assertThat("TransactionCode was not correct", resultValue.getTransactionCode(), is(GET_CROSSBORDER_PAYMENT_LIST_TRANSACTION_CODE));
        assertThat("BeneficiaryName was not correct", resultValue.getBeneficiaryName(), is(EMPTY_STRING));
        assertThat("Currency was not correct", resultValue.getCurrency(), is(EMPTY_STRING));
        assertThat("ToAccountId was not correct", resultValue.getToAccountId(), is(EMPTY_STRING));
        assertThat("MyCategory was not correct", resultValue.getMyCategory(), is(EMPTY_STRING));
        assertThat("AmountFrom was not correct", resultValue.getAmountFrom(), is(BigDecimal.ZERO.setScale(2)));
        assertThat("AmountTo was not correct", resultValue.getAmountTo(), is(BigDecimal.ZERO.setScale(2)));

        assertThat("ContinueKey was not correct", resultValue.getContinueKey(), is(EMPTY_STRING));

        assertThat("PaymentSubType was not set correct", resultValue.getPaymentSubType(), is(ALL_PAYMENTS));

        assertThat("FromDate was not set correctly", resultValue.getFromDate(), is(EMPTY_DATE_STR));
        assertThat("ToDate was not set correctly", resultValue.getToDate(), is(EMPTY_DATE_STR));

        GetCrossBorderPaymentListRequestStatusCollectionSegment statusCollectionSegment =
                (GetCrossBorderPaymentListRequestStatusCollectionSegment)
                        resultValue.getStatusCollection().next();
        assertThat("StatusSegment was not set correctly", statusCollectionSegment.getPaymentStatusCode(),
                is(LegacyCrossBorderConverter.fromPaymentStatus(Payment.StatusEnum.unconfirmed)));
    }

    @Test
    public void shouldReturnNoResultIfNoAccountKeysFilter() {
        PaymentFilterToCrossborderPaymentListRequestRecord paymentFilterToCrossborderPaymentListRequestRecord =
                new PaymentFilterToCrossborderPaymentListRequestRecord(nilRequestMsgHeadersMock);

        //Given
        PaymentFilter paymentFilter = mock(PaymentFilter.class);
        ListFilter<AccountKey> accountKeyListFilter = new ListFilter<>(Collections.emptyList());
        when(paymentFilter.getFromAccounts()).thenReturn(accountKeyListFilter);
        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

        //When
        GetCrossBorderPaymentListRequestRecord result =
                paymentFilterToCrossborderPaymentListRequestRecord.convert(serviceData, paymentFilter);

        assertNull("Received a result", result);

    }

    @Test
    public void shouldMapAccountSegments() {
        PaymentFilterToCrossborderPaymentListRequestRecord paymentFilterToCrossborderPaymentListRequestRecord =
                new PaymentFilterToCrossborderPaymentListRequestRecord(nilRequestMsgHeadersMock);

        AccountKey fromHouseHoldAccount1 = TestData.HOUSEHOLD_OWN_ACCOUNT;
        AccountKey fromHouseHoldAccount2 = new ExternalAccountKey("SE", new AccountNumber("59300046883"));
        //Given
        PaymentFilter paymentFilter = mock(PaymentFilter.class);
        ListFilter<AccountKey> accountKeyListFilter = new ListFilter<>(Arrays.asList(fromHouseHoldAccount1, fromHouseHoldAccount2));
        when(paymentFilter.getFromAccounts()).thenReturn(accountKeyListFilter);
        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");


        //When
        GetCrossBorderPaymentListRequestRecord resultValue =
                paymentFilterToCrossborderPaymentListRequestRecord.convert(serviceData, paymentFilter);

        Iterator<GetCrossBorderPaymentListRequestFromAccountsSegment> i = resultValue.getFromAccounts();
        GetCrossBorderPaymentListRequestFromAccountsSegment hhSegment = i.next();
        GetCrossBorderPaymentListRequestFromAccountsSegment corpSegment = i.next();

        assertThat("HHCurrency wasn't mapped correctly", hhSegment.getFromAccountCurrency(), is(fromHouseHoldAccount1.getCurrencyCode().get()));
        assertThat("HHAccountId wasn't mapped correctly", hhSegment.getFromAccountId(), is(Long.parseLong(fromHouseHoldAccount1.getAccountNumber().getAccountNumber())));

        assertThat("CorpCurrency wasn't mapped correctly", corpSegment.getFromAccountCurrency(), is(EMPTY_STRING));
        assertThat("CorpAccountId wasn't mapped correctly", corpSegment.getFromAccountId(), is(Long.parseLong(fromHouseHoldAccount2.getAccountNumber().getAccountNumber())));
    }

    @Test
    public void shouldUseUserStatusesInsteadOfDefault() {
        PaymentFilterToCrossborderPaymentListRequestRecord paymentFilterToCrossborderPaymentListRequestRecord =
                new PaymentFilterToCrossborderPaymentListRequestRecord(nilRequestMsgHeadersMock);

        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        //Given
        PaymentFilter paymentFilter = mock(PaymentFilter.class);
        ListFilter<AccountKey> accountKeyListFilter = new ListFilter<>(Collections.singletonList(fromHouseHoldAccount));
        when(paymentFilter.getFromAccounts()).thenReturn(accountKeyListFilter);
        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

        when(paymentFilter.getPaymentFilterTypes())
                .thenReturn(Collections.singleton(PaymentFilterType.STATUS));

        Payment.StatusEnum status = Payment.StatusEnum.rejected;
        when(paymentFilter.getStatuses()).thenReturn(Collections.singletonList(status));


        //When
        GetCrossBorderPaymentListRequestRecord resultValue =
                paymentFilterToCrossborderPaymentListRequestRecord.convert(serviceData, paymentFilter);

        Iterator<GetCrossBorderPaymentListRequestStatusCollectionSegment> statusCollection =
                resultValue.getStatusCollection();
        GetCrossBorderPaymentListRequestStatusCollectionSegment statusSegment = statusCollection.next();
        assertThat("PaymentStatusCode was not correct", statusSegment.getPaymentStatusCode(),
                is(LegacyCrossBorderConverter.fromPaymentStatus(status)));
    }

    @Test
    public void shouldReturnNoResultIfMissingUserStatuses() {
        PaymentFilterToCrossborderPaymentListRequestRecord paymentFilterToCrossborderPaymentListRequestRecord =
                new PaymentFilterToCrossborderPaymentListRequestRecord(nilRequestMsgHeadersMock);

        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        //Given
        PaymentFilter paymentFilter = mock(PaymentFilter.class);
        ListFilter<AccountKey> accountKeyListFilter = new ListFilter<>(Collections.singletonList(fromHouseHoldAccount));
        when(paymentFilter.getFromAccounts()).thenReturn(accountKeyListFilter);
        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

        when(paymentFilter.getPaymentFilterTypes())
                .thenReturn(Collections.singleton(PaymentFilterType.STATUS));

        //When

        GetCrossBorderPaymentListRequestRecord result = paymentFilterToCrossborderPaymentListRequestRecord.convert(serviceData, paymentFilter);

        assertNull("Got a result back", result);
    }

    @Test
    public void shouldNotSetDatesIfNotPresent() {
        PaymentFilterToCrossborderPaymentListRequestRecord paymentFilterToCrossborderPaymentListRequestRecord =
                new PaymentFilterToCrossborderPaymentListRequestRecord(nilRequestMsgHeadersMock);

        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        //Given
        PaymentFilter paymentFilter = mock(PaymentFilter.class);
        ListFilter<AccountKey> accountKeyListFilter = new ListFilter<>(Collections.singletonList(fromHouseHoldAccount));
        when(paymentFilter.getFromAccounts()).thenReturn(accountKeyListFilter);
        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        when(paymentFilter.getPaymentFilterTypes()).thenReturn(Collections.singleton(PaymentFilterType.DUE_DATE));
        DateFilter dateFilter = mock(DateFilter.class);
        when(dateFilter.getStartDate()).thenReturn(Optional.empty());
        when(dateFilter.getEndDate()).thenReturn(Optional.empty());
        when(paymentFilter.getDueDate()).thenReturn(dateFilter);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

        GetCrossBorderPaymentListRequestRecord resultValue =
                paymentFilterToCrossborderPaymentListRequestRecord.convert(serviceData, paymentFilter);

        assertThat("FromDate was not set correctly", resultValue.getFromDate(), is(EMPTY_STRING));
        assertThat("ToDate was not set correctly", resultValue.getToDate(), is(EMPTY_STRING));
    }

    @Test
    public void shouldSetDatesIfPresent() {
        PaymentFilterToCrossborderPaymentListRequestRecord paymentFilterToCrossborderPaymentListRequestRecord =
                new PaymentFilterToCrossborderPaymentListRequestRecord(nilRequestMsgHeadersMock);

        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        //Given
        PaymentFilter paymentFilter = mock(PaymentFilter.class);
        ListFilter<AccountKey> accountKeyListFilter = new ListFilter<>(Collections.singletonList(fromHouseHoldAccount));
        when(paymentFilter.getFromAccounts()).thenReturn(accountKeyListFilter);
        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);

        LocalDate fromDate = LocalDate.now().minusMonths(3);
        LocalDate toDate = LocalDate.now().minusMonths(2);
        DateFilter dateFilter = DateFilter.between(fromDate, toDate);

        when(paymentFilter.getDueDate()).thenReturn(dateFilter);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

        when(paymentFilter.getPaymentFilterTypes())
                .thenReturn(Collections.singleton(PaymentFilterType.DUE_DATE));

        GetCrossBorderPaymentListRequestRecord resultValue =
                paymentFilterToCrossborderPaymentListRequestRecord.convert(serviceData, paymentFilter);

        assertThat("FromDate was not set correctly", resultValue.getFromDate(), is(DateTimeFormatter.ofPattern("yyMMdd").format(fromDate)));
        assertThat("ToDate was not set correctly", resultValue.getToDate(), is(is(DateTimeFormatter.ofPattern("yyMMdd").format(toDate))));
    }
}
