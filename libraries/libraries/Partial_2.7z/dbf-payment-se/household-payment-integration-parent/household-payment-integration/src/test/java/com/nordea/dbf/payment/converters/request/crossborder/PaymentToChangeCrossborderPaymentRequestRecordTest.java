package com.nordea.dbf.payment.converters.request.crossborder;

import com.nordea.dbf.agreement.customer.se.model.Agreement;
import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.converters.LegacyCrossBorderConverter;
import com.nordea.dbf.payment.model.HouseholdPayment;
import com.nordea.dbf.payment.record.crossborder.household.ChangeCrossBorderPaymentRequestMessageRowCollectionSegment;
import com.nordea.dbf.payment.record.crossborder.household.ChangeCrossBorderPaymentRequestRecord;
import com.nordea.dbf.payment.record.crossborder.household.ChangeCrossBorderPaymentRequestUrgencyTypeCollectionSegment;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToChangeCrossborderPaymentRequestRecordTest {

    private static final String CHANGE_CROSSBORDER_PAYMENT_TRANSACTION_CODE = "LHP61P53";
    private static final String EMPTY_STRING = StringUtils.EMPTY;
    private static final String REPEATING_RULE_DEFAULT = "O";
    private static final String AGREEMENT_TYPE_DEFAULT = "O";
    private static final String RECEIPT_CODE_DEFAULT = "N";
    private static final int MESSAGE_ROW_COUNT_DEFAULT = 0;
    private static final int URGENCY_TYPE_COUNT_DEFAULT = 0;
    private static final String VALIDATE_FRAUD_DEFAULT = "N";
    private static final DateTimeFormatter PAYMENT_DUE_PATTERN = DateTimeFormatter.ofPattern(HouseholdPayment.PAYMENT_NONDELIMITED_DATE_FORMAT.toPattern());


    private final NilRequestMsgHeaders nilRequestMsgHeadersMock;

    public PaymentToChangeCrossborderPaymentRequestRecordTest() {
        nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
    }

    @Before
    public void init() {
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(ServiceRequestContext.class), any(ChangeCrossBorderPaymentRequestRecord.class)))
                .thenReturn(new ChangeCrossBorderPaymentRequestRecord());
    }

    @Test
    public void shouldMapFull() {
        PaymentToChangeCrossborderPaymentRequestRecord paymentToChangeCrossborderPaymentRequestRecord
                = new PaymentToChangeCrossborderPaymentRequestRecord(nilRequestMsgHeadersMock);

        //Given
        Long agreementNumber = 22L;
        String userId = "UI1234567890";
        String remoteAddress = "255.127.127.127";

        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        when(serviceRequestContext.getAgreementNumber()).thenReturn(Optional.of(agreementNumber));
        when(serviceRequestContext.getUserId()).thenReturn(Optional.of(userId));
        when(serviceRequestContext.getRemoteAddress()).thenReturn(remoteAddress);

        String agreementOwner = "AO1234567890";

        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        AccountKey toCrossBorderAccount = TestData.CROSS_BORDER_ACCOUNT_KEY;

        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(fromHouseHoldAccount, toCrossBorderAccount);
        CrossBorder crossBorder = new CrossBorder();
        String centralBankReportingCode = "COD";
        CrossBorder.ChargePaidByEnum chargePaidBy = CrossBorder.ChargePaidByEnum.payee;
        crossBorder.setChargePaidBy(chargePaidBy);
        crossBorder.setCentralBankReportingCode(centralBankReportingCode);
        payment.setCrossBorder(crossBorder);

        ServiceData serviceData = new ServiceData(serviceRequestContext, agreementOwner, "123", "household");

        //When
        ChangeCrossBorderPaymentRequestRecord resultValue =  paymentToChangeCrossborderPaymentRequestRecord
                .convert(serviceData, payment);

        //Then
        assertThat("Transaction Code is not correct", resultValue.getTransactionCode(), is(CHANGE_CROSSBORDER_PAYMENT_TRANSACTION_CODE));
        assertThat("IpAddress is not correct", resultValue.getIpAddress(), is(remoteAddress));
        assertThat("IpFlag is not correct", resultValue.getIpFlag(), is(StringUtils.EMPTY));
        assertThat("FromAccountId is not correct", resultValue.getFromAccountId(), is(payment.getId().substring(0,11)));
        assertThat("InputDate is not correct", resultValue.getInputDate(), is(payment.getId().substring(11, 17)));
        assertThat("LegacyKey is not correct", resultValue.getLegacyKey(), is(payment.getId().substring(17)));
        assertThat("RepeatingRule is not correct", resultValue.getRepeatingRule(), is(REPEATING_RULE_DEFAULT));
        assertThat("AgreementType is not correct", resultValue.getAgreementType(), is(AGREEMENT_TYPE_DEFAULT));
        assertThat("ReceiptCode is not correct", resultValue.getRecepitCode(), is(RECEIPT_CODE_DEFAULT));
        assertThat("AgreementNumber is not correct", resultValue.getAgreementNumber(), is(agreementNumber));
        assertThat("AgreementOwner is not correct", resultValue.getAgreementOwner(), is(agreementOwner));
        assertThat("CustomerNumber is not correct", resultValue.getCustomerNumber(), is(userId));
        String fromAccountNumber = fromHouseHoldAccount.getAccountNumber().getAccountNumber() + fromHouseHoldAccount.getCurrencyCode().get();
        assertThat("FromAccountNumber is not correct", resultValue.getFromAccountNumber(), is(fromAccountNumber));
        assertThat("Filler is not correct", resultValue.getFiller(), is(StringUtils.EMPTY));
        assertThat("OwnReference is not correct", resultValue.getOwnReference(), is(payment.getOwnMessage()));

        assertThat("RemitterName is not correct", resultValue.getRemitterName(), is(EMPTY_STRING));
        assertThat("RemitterCO is not correct", resultValue.getRemitterNameCO(), is(EMPTY_STRING));
        assertThat("RemitterStreetAddress is not correct", resultValue.getRemitterStreetAddress(), is(EMPTY_STRING));
        assertThat("RemitterPostCode is not correct", resultValue.getRemitterPostCode(), is(EMPTY_STRING));
        assertThat("IntermediaryBankAccount is not correct", resultValue.getIntermediaryBankAccount(), is(EMPTY_STRING));
        assertThat("IntermediaryBankBIC is not correct", resultValue.getIntermediaryBankBIC(), is(EMPTY_STRING));
        assertThat("ExecutionDate is not Correct", resultValue.getExecutionDate(), is(PAYMENT_DUE_PATTERN.format(payment.getDue())));
        assertThat("ReferenceTextF is not correct", resultValue.getReferenceTextF(), is(payment.getMessage()));
        assertThat("Currency is not correct", resultValue.getCurrency(), is(payment.getCurrency()));
        assertThat("Amount is not correct", resultValue.getAmount(), is(payment.getAmount().setScale(2)));

        assertThat("ReceivingBankCountry is not correct", resultValue.getReceivingBankCountry(), is(EMPTY_STRING));
        assertThat("ReveivingBankBIC is not correct", resultValue.getReceivingBankBIC(), is(EMPTY_STRING));
        assertThat("ReveivingBankCode is not correct", resultValue.getReceivingBankCode(), is(EMPTY_STRING));
        assertThat("ReceivingBankAddress1 is not correct", resultValue.getReceivingBankAddress1(), is(EMPTY_STRING));
        assertThat("ReceivingBankAddress2 is not correct", resultValue.getReceivingBankAddress2(), is(EMPTY_STRING));
        assertThat("ReceivingBankAddress3 is not correct", resultValue.getReceivingBankAddress3(), is(EMPTY_STRING));
        assertThat("BeneficiaryAddress1 is not correct", resultValue.getBeneficiaryAddress1(), is(EMPTY_STRING));
        assertThat("BeneficiaryAddress2 is not correct", resultValue.getBeneficiaryAddress2(), is(EMPTY_STRING));
        assertThat("BeneficiaryAddress3 is not correct", resultValue.getBeneficiaryAddress3(), is(EMPTY_STRING));
        assertThat("ToAccountId is not correct", resultValue.getToAccountId(), is(toCrossBorderAccount.getAccountNumber().getAccountNumber()));

        assertThat("CbrCode is not correct", resultValue.getCbrCode(), is(centralBankReportingCode));
        assertThat("ChargePaidBy is not correct", resultValue.getChargePaidBy(), is(LegacyCrossBorderConverter.convertChargePaidByToLegacy(chargePaidBy)));
        assertThat("MessageRowCount is not correct", resultValue.getMessageRowCount(), is(MESSAGE_ROW_COUNT_DEFAULT+1));

        assertThat("ValidateForFraud is not correct", resultValue.getValidateForFraud(), is(VALIDATE_FRAUD_DEFAULT));
        assertThat("Filler1 is not correct", resultValue.getFiller1(), is(EMPTY_STRING));
        assertThat("UrgencyTypeCount is not correct", resultValue.getUrgencyTypeCount(), is(URGENCY_TYPE_COUNT_DEFAULT+1));
        ChangeCrossBorderPaymentRequestMessageRowCollectionSegment resultSegment = (ChangeCrossBorderPaymentRequestMessageRowCollectionSegment) resultValue.getMessageRowCollection().next();
        assertThat("MessageRow is not correct", resultSegment.getMessageRow(), is(payment.getMessage()));

    }

    @Test
    public void shouldSetUrgentCodeForExpressSpeed() {
        PaymentToChangeCrossborderPaymentRequestRecord paymentToChangeCrossborderPaymentRequestRecord
                = new PaymentToChangeCrossborderPaymentRequestRecord(nilRequestMsgHeadersMock);

        //Given
        Long agreementNumber = 22L;
        String userId = "UI1234567890";
        String remoteAddress = "255.127.127.127";

        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        when(serviceRequestContext.getAgreementNumber()).thenReturn(Optional.of(agreementNumber));
        when(serviceRequestContext.getUserId()).thenReturn(Optional.of(userId));
        when(serviceRequestContext.getRemoteAddress()).thenReturn(remoteAddress);

        String agreementOwner = "AO1234567890";


        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        AccountKey toCrossBorderAccount = TestData.CROSS_BORDER_ACCOUNT_KEY;

        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(fromHouseHoldAccount, toCrossBorderAccount);
        CrossBorder crossBorder = new CrossBorder();
        String centralBankReportingCode = "COD";
        CrossBorder.ChargePaidByEnum chargePaidBy = CrossBorder.ChargePaidByEnum.payee;
        crossBorder.setChargePaidBy(chargePaidBy);
        crossBorder.setCentralBankReportingCode(centralBankReportingCode);
        payment.setCrossBorder(crossBorder);

        payment.setSpeed(Payment.SpeedEnum.express);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, agreementOwner, "household");

        ChangeCrossBorderPaymentRequestRecord resultValue =
                paymentToChangeCrossborderPaymentRequestRecord
                        .convert(serviceData, payment);

        ChangeCrossBorderPaymentRequestUrgencyTypeCollectionSegment urgencySegment =
                (ChangeCrossBorderPaymentRequestUrgencyTypeCollectionSegment)
                        resultValue.getUrgencyTypeCollection().next();
        assertThat("UrgencyType was not set correctly", urgencySegment.getUrgencyType(), is(LegacyCrossBorderConverter.URGENT_LEGACY_CODE));
    }

    @Test
    public void shouldSetNoUrgentCodeForNormalSpeed() {
        PaymentToChangeCrossborderPaymentRequestRecord paymentToChangeCrossborderPaymentRequestRecord
                = new PaymentToChangeCrossborderPaymentRequestRecord(nilRequestMsgHeadersMock);

        //Given
        Long agreementNumber = 22L;
        String userId = "UI1234567890";
        String remoteAddress = "255.127.127.127";

        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        when(serviceRequestContext.getAgreementNumber()).thenReturn(Optional.of(agreementNumber));
        when(serviceRequestContext.getUserId()).thenReturn(Optional.of(userId));
        when(serviceRequestContext.getRemoteAddress()).thenReturn(remoteAddress);

        String agreementOwner = "AO1234567890";

        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        AccountKey toCrossBorderAccount = TestData.CROSS_BORDER_ACCOUNT_KEY;

        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(fromHouseHoldAccount, toCrossBorderAccount);
        CrossBorder crossBorder = new CrossBorder();
        String centralBankReportingCode = "COD";
        CrossBorder.ChargePaidByEnum chargePaidBy = CrossBorder.ChargePaidByEnum.payee;
        crossBorder.setChargePaidBy(chargePaidBy);
        crossBorder.setCentralBankReportingCode(centralBankReportingCode);
        payment.setCrossBorder(crossBorder);

        payment.setSpeed(Payment.SpeedEnum.normal);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, agreementOwner, "household");

        ChangeCrossBorderPaymentRequestRecord resultValue =
                paymentToChangeCrossborderPaymentRequestRecord
                        .convert(serviceData, payment);

        ChangeCrossBorderPaymentRequestUrgencyTypeCollectionSegment urgencySegment =
                (ChangeCrossBorderPaymentRequestUrgencyTypeCollectionSegment)
                        resultValue.getUrgencyTypeCollection().next();
        assertThat("UrgencyType was not set correctly", urgencySegment.getUrgencyType(), is(EMPTY_STRING));
    }
}
