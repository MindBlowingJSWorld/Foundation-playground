package com.nordea.dbf.payment.converters.request.crossborder;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.crossborder.household.DeleteCrossBorderPaymentRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToDeleteCrossBorderPaymentRequestRecordTest {

    private static final String DELETE_CROSSBORDER_PAYMENT_TRANSACTION_CODE = "LHP61P56";

    private final NilRequestMsgHeaders nilRequestMsgHeadersMock;

    public PaymentToDeleteCrossBorderPaymentRequestRecordTest() {
        nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
    }

    @Before
    public void init() {
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(ServiceRequestContext.class), any(DeleteCrossBorderPaymentRequestRecord.class)))
                .thenReturn(new DeleteCrossBorderPaymentRequestRecord());
    }

    @Test
    public void shouldMapFull() {
        PaymentToDeleteCrossBorderPaymentRequestRecord paymentToDeleteCrossBorderPaymentRequestRecord =
                new PaymentToDeleteCrossBorderPaymentRequestRecord(nilRequestMsgHeadersMock);
        //Given

        ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
        String remoteAddress = "255.127.127.127";
        when(serviceRequestContext.getRemoteAddress()).thenReturn(remoteAddress);

        AccountKey fromHouseHoldAccount = TestData.HOUSEHOLD_OWN_ACCOUNT;
        AccountKey toCrossBorderAccount = TestData.CROSS_BORDER_ACCOUNT_KEY;
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(fromHouseHoldAccount, toCrossBorderAccount);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

        //When
        DeleteCrossBorderPaymentRequestRecord resultValue = paymentToDeleteCrossBorderPaymentRequestRecord.convert(serviceData, payment);

        assertThat("Transaction Code is not correct", resultValue.getTransactionCode(), is(DELETE_CROSSBORDER_PAYMENT_TRANSACTION_CODE));
        assertThat("IpAddress is not correct", resultValue.getIpAddress(), is(remoteAddress));
        assertThat("IpFlag is not correct", resultValue.getIpFlag(), is(StringUtils.EMPTY));
        assertThat("LegacyKey is not correct", resultValue.getLegacyKey(), is(payment.getId()));

    }
}
