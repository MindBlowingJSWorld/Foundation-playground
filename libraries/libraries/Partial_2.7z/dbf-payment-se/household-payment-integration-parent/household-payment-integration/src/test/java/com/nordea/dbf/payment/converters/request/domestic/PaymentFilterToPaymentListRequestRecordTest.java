package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.filter.DateFilter;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.PaymentListRequestFromAccountsSegment;
import com.nordea.dbf.payment.record.domestic.PaymentListRequestRecord;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static com.nordea.dbf.payment.model.PaymentStatusToMessageId.getSubMessageIdByStatus;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentFilterToPaymentListRequestRecordTest {

    private static final String FILTER_PAYMENT_LITE_REQUEST_RECORD_TRANSACTION_CODE = "FQQ852";
    private static final long CONTINUE_KEY_ACCT = 0L;
    private static final long CONTINUE_KEY_PAY_ID = 0L;
    private static final String SEARCH_WITH_DATE = "Y";
    private static final String SEARCH_WITH_DATE_DEFAULT = "N";

    private PaymentFilterToPaymentListRequestRecord paymentRequest;
    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private String userId = "1234567890";
    private Long agreementOwner = 123456789L;

    private int counter = 0;
    private ServiceData serviceData;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        paymentRequest = new PaymentFilterToPaymentListRequestRecord(nilRequestMsgHeadersMock);
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any())).thenAnswer(i -> trulyNewObject(counter, 0));
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));
        when(serviceRequestContextMock.getAgreementNumber()).thenReturn(Optional.of(agreementOwner));
        serviceData = new ServiceData(serviceRequestContextMock, TestData.HOUSEHOLD_USER_ID, agreementOwner.toString(), "household");
    }

    private PaymentListRequestRecord trulyNewObject(int max, int current) {
        if (current < max) {
            return trulyNewObject(max, ++current);
        }
        this.counter++;
        return new PaymentListRequestRecord();
    }

    @Test
    public void shouldThrowExceptionDueToNullFilter() {
        assertThatThrownBy(() -> paymentRequest.convert(serviceData, null))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    public void shouldThrowExceptionDueToEmptyFilter() {
        assertThatThrownBy(() -> paymentRequest.convert(serviceData, new PaymentFilter()))
                .isInstanceOf(NullPointerException.class);
    }

    @Test
    public void shouldReturnEmptyObservable() {
        PaymentFilter paymentFilter = new PaymentFilter();

        LinkedList<String> statuses = new LinkedList<>();
        statuses.add(Payment.StatusEnum.confirmed.toString());
        paymentFilter.setStatuses(statuses);

        LinkedList<String> paymentTypes = new LinkedList<>();
        paymentFilter.setPaymentTypes(paymentTypes);

        assertTrue("Should have returned empty Observable",
                paymentRequest.convert(serviceData, paymentFilter).isEmpty());
    }

    private List<PaymentListRequestRecord> prepareForMessageIdAssertions(LinkedList<String> statuses) {
        PaymentFilter paymentFilter = new PaymentFilter();

        paymentFilter.setStatuses(statuses);

        LinkedList<String> paymentTypes = new LinkedList<>();
        paymentTypes.add(Payment.TypeEnum.bankgiro.toString());
        paymentFilter.setPaymentTypes(paymentTypes);

        LinkedList<AccountKey> accounts = new LinkedList<>();
        accounts.add(TestData.BG_ACCOUNT);
        ListFilter<AccountKey> listFilter = new ListFilter<>(accounts);
        paymentFilter.setFromAccounts(listFilter);

        return paymentRequest.convert(serviceData, paymentFilter);

    }

    @Test
    public void shouldMapMessageId() {
        LinkedList<String> statuses = new LinkedList<>();
        statuses.add(Payment.StatusEnum.confirmed.toString());

        List<PaymentListRequestRecord> requestRecords = prepareForMessageIdAssertions(statuses);

        assertThat("Incorrect amount of requestRecords returned", requestRecords.size(),
                is(1));

        PaymentListRequestRecord requestRecord = requestRecords.get(0);
        assertThat("MessageId is not correct", requestRecord.getMessageId(),
                is(getSubMessageIdByStatus(Payment.StatusEnum.confirmed)));
        assertThat("SubMessageId1 is not correct", requestRecord.getSubMessageId1(),
                is(""));
        assertThat("SubMessageId2 is not correct", requestRecord.getSubMessageId2(),
                is(""));
        assertThat("SubMessageId3 is not correct", requestRecord.getSubMessageId3(),
                is(""));
        assertThat("SubMessageId4 is not correct", requestRecord.getSubMessageId4(),
                is(""));
    }

    @Test
    public void shouldMapTwoSubMessages() {
        LinkedList<String> statuses = new LinkedList<>();
        statuses.add(Payment.StatusEnum.confirmed.toString());
        statuses.add(Payment.StatusEnum.confirmed.toString());

        List<PaymentListRequestRecord> requestRecords = prepareForMessageIdAssertions(statuses);

        assertThat("Incorrect amount of requestRecords returned", requestRecords.size(),
                is(2));

        requestRecords.forEach(requestRecord -> {
            assertThat("MessageId is not correct", requestRecord.getMessageId(),
                    is(getSubMessageIdByStatus(Payment.StatusEnum.confirmed)));
            assertThat("SubMessageId1 is not correct", requestRecord.getSubMessageId1(),
                    is(""));
            assertThat("SubMessageId2 is not correct", requestRecord.getSubMessageId2(),
                    is(""));
            assertThat("SubMessageId3 is not correct", requestRecord.getSubMessageId3(),
                    is(""));
            assertThat("SubMessageId4 is not correct", requestRecord.getSubMessageId4(),
                    is(""));
        });
    }

    @Test
    public void shouldMapAllSubMessages() {
        LinkedList<String> statuses = new LinkedList<>();
        statuses.add(Payment.StatusEnum.unconfirmed.name());
        statuses.add(Payment.StatusEnum.confirmed.name());
        statuses.add(Payment.StatusEnum.rejected.name());
        statuses.add(Payment.StatusEnum.rejected.name());

        List<PaymentListRequestRecord> requestRecords = prepareForMessageIdAssertions(statuses);

        assertThat("Incorrect amount of requestRecords returned", requestRecords.size(),
                is(4));

        requestRecords.forEach(requestRecord -> {
            assertThat("MessageId is not correct", requestRecord.getMessageId(),
                    is(getSubMessageIdByStatus(Payment.StatusEnum.valueOf(statuses.removeFirst()))));
            assertThat("SubMessageId1 is not correct", requestRecord.getSubMessageId1(),
                    is(""));
            assertThat("SubMessageId2 is not correct", requestRecord.getSubMessageId2(),
                    is(""));
            assertThat("SubMessageId3 is not correct", requestRecord.getSubMessageId3(),
                    is(""));
            assertThat("SubMessageId4 is not correct", requestRecord.getSubMessageId4(),
                    is(""));
        });
    }

    @Test
    public void shouldMapDueDate() {
        PaymentFilter paymentFilter = new PaymentFilter();

        LinkedList<AccountKey> accounts = new LinkedList<>();
        accounts.add(TestData.BG_ACCOUNT);
        ListFilter<AccountKey> listFilter = new ListFilter<>(accounts);
        paymentFilter.setFromAccounts(listFilter);

        PaymentListRequestRecord returnValue =
                paymentRequest.convert(serviceData, paymentFilter).get(0);

        assertThat("SearchWithDate is not correct", returnValue.getSearchWithDate(),
                is(SEARCH_WITH_DATE_DEFAULT));
        assertThat("StartDate is not correct", returnValue.getStartDate(),
                is(""));
        assertThat("EndDate is not correct", returnValue.getEndDate(),
                is(""));

        paymentFilter.setDueDate(DateFilter.after(LocalDate.MIN));
        returnValue =
                paymentRequest.convert(serviceData, paymentFilter).get(0);

        assertThat("SearchWithDate is not correct", returnValue.getSearchWithDate(),
                is(SEARCH_WITH_DATE));
        assertThat("StartDate is not correct", returnValue.getStartDate(),
                is(LocalDate.MIN.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")).substring(0, 10)));
        assertThat("EndDate is not correct", returnValue.getEndDate(),
                is(""));

        paymentFilter.setDueDate(DateFilter.between(LocalDate.MIN, LocalDate.MAX));
        returnValue =
                paymentRequest.convert(serviceData, paymentFilter).get(0);

        assertThat("StartDate is not correct", returnValue.getStartDate(),
                is(LocalDate.MIN.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")).substring(0, 10)));
        assertThat("EndDate is not correct", returnValue.getEndDate(),
                is(LocalDate.MAX.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")).substring(0, 10)));

    }

    @Test
    public void shouldMapAllGiroTypes() {
        PaymentFilter paymentFilter = new PaymentFilter();

        LinkedList<AccountKey> accounts = new LinkedList<>();
        accounts.add(TestData.BG_ACCOUNT);
        ListFilter<AccountKey> listFilter = new ListFilter<>(accounts);
        paymentFilter.setFromAccounts(listFilter);

        LinkedList<String> paymentTypes = new LinkedList<>();
        paymentTypes.add(Payment.TypeEnum.plusgiro.toString());
        paymentTypes.add(Payment.TypeEnum.bankgiro.toString());
        paymentTypes.add(Payment.TypeEnum.owntransfer.toString());
        paymentTypes.add(Payment.TypeEnum.lban.toString());
        paymentFilter.setPaymentTypes(paymentTypes);

        List<PaymentListRequestRecord> paymentListRequestRecords = paymentRequest.convert(serviceData, paymentFilter);
        assertThat("GiroType is not correct", paymentListRequestRecords.get(0).getGiroType(),
                is(LegacyGiroType.PG.code()));
        assertThat("GiroType is not correct", paymentListRequestRecords.get(1).getGiroType(),
                is(LegacyGiroType.BG.code()));
        assertThat("GiroType is not correct", paymentListRequestRecords.get(2).getGiroType(),
                is(LegacyGiroType.OWN_ACCOUNTS.code()));
        assertThat("GiroType is not correct", paymentListRequestRecords.get(3).getGiroType(),
                is(LegacyGiroType.EXTERNAL_TRANSFER.code()));
    }

    @Test
    public void shouldMapFullRequestWithEmptyFilters() {
        PaymentFilter paymentFilter = new PaymentFilter();

        LinkedList<AccountKey> accounts = new LinkedList<>();
        accounts.add(TestData.BG_ACCOUNT);
        ListFilter<AccountKey> listFilter = new ListFilter<>(accounts);
        paymentFilter.setFromAccounts(listFilter);

        LinkedList<String> statuses = new LinkedList<>();
        statuses.add(Payment.StatusEnum.unconfirmed.name());
        statuses.add(Payment.StatusEnum.confirmed.name());
        statuses.add(Payment.StatusEnum.rejected.name());

        List<PaymentListRequestRecord> requestRecords = paymentRequest.convert(serviceData, paymentFilter);

        assertThat("Incorrect amount of requestRecords returned", requestRecords.size(),
                is(3));

        requestRecords.forEach(requestRecord -> {
            assertThat("TransactionCode is not correct", requestRecord.getTransactionCode(),
                    is(FILTER_PAYMENT_LITE_REQUEST_RECORD_TRANSACTION_CODE));
            assertThat("CustomerId is not correct", requestRecord.getCustomerId(),
                    is(Long.parseLong(userId)));
            assertThat("AgreementNumber is not correct", requestRecord.getAgreementNumber(),
                    is(agreementOwner.intValue()));
            assertThat("GiroType is not correct", requestRecord.getGiroType(),
                    is(""));
            assertThat("MessageId is not correct", requestRecord.getMessageId(),
                    is(getSubMessageIdByStatus(Payment.StatusEnum.valueOf(statuses.removeFirst()))));
            assertThat("SubMessageId1 is not correct", requestRecord.getSubMessageId1(),
                    is(""));
            assertThat("SubMessageId2 is not correct", requestRecord.getSubMessageId2(),
                    is(""));
            assertThat("SubMessageId3 is not correct", requestRecord.getSubMessageId3(),
                    is(""));
            assertThat("SubMessageId4 is not correct", requestRecord.getSubMessageId4(),
                    is(""));
            assertThat("SearchWithDate is not correct", requestRecord.getSearchWithDate(),
                    is(SEARCH_WITH_DATE_DEFAULT));
            assertThat("StartDate is not correct", requestRecord.getStartDate(),
                    is(""));
            assertThat("EndDate is not correct", requestRecord.getEndDate(),
                    is(""));
            assertThat("ContinueKeyAcct is not correct", requestRecord.getContinueKeyAcct(),
                    is(CONTINUE_KEY_ACCT));
            assertThat("ContinueKeyPayId is not correct", requestRecord.getContinueKeyPayId(),
                    is(CONTINUE_KEY_PAY_ID));
        });
    }

    @Test
    public void shouldMapMultipleAccounts() {
        PaymentFilter paymentFilter = new PaymentFilter();

        LinkedList<AccountKey> accounts = new LinkedList<>();
        accounts.add(TestData.BG_ACCOUNT);
        accounts.add(TestData.BG_ACCOUNT);
        accounts.add(TestData.BG_ACCOUNT);
        ListFilter<AccountKey> listFilter = new ListFilter<>(accounts);
        paymentFilter.setFromAccounts(listFilter);

        PaymentListRequestRecord returnValue =
                paymentRequest.convert(serviceData, paymentFilter).get(0);

        returnValue.getFromAccounts().forEachRemaining(obj -> {
            PaymentListRequestFromAccountsSegment segment = (PaymentListRequestFromAccountsSegment) obj;
            assertThat("FromAccount is not correct", segment.getFromAccount(),
                    is(Long.parseLong(TestData.BG_ACCOUNT.getAccountNumber().getAccountNumber())));
        });
    }
}
