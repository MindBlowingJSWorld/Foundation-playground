package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.ChangePaymentRequestRecord;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToChangeThirdpartyPaymentRequestRecordTest {

    private static final String CHANGE_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP810";
    private static final String MESSAGE_ID = "FQP8101";

    private Payment payment = mock(Payment.class);
    private Payment originalPayment = mock(Payment.class);
    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private PaymentToChangePaymentRequestRecord requestRecordMock = mock(PaymentToChangePaymentRequestRecord.class);
    private PaymentToChangeThirdpartyPaymentRequestRecord thirdpartyPaymentRequest;
    private ServiceData serviceData;

    @Before
    public void init() {
        ChangePaymentRequestRecord changePaymentRequestRecord = new ChangePaymentRequestRecord();
        when(originalPayment.getFrom()).thenReturn(TestData.BG_ACCOUNT.toString());
        when(requestRecordMock.with(any())).thenReturn(requestRecordMock);
        when(requestRecordMock.convert(any(), any())).thenReturn(changePaymentRequestRecord);
        thirdpartyPaymentRequest = new PaymentToChangeThirdpartyPaymentRequestRecord(requestRecordMock);
        serviceData = new ServiceData(serviceRequestContextMock, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
    }

    @Test
    public void shouldMapThirdpartySpecifics() {
        ChangePaymentRequestRecord returnValue =
                thirdpartyPaymentRequest.with(originalPayment).convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(CHANGE_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE));
        assertThat("MessageId is not correct", returnValue.getMessageId(),
                is(MESSAGE_ID));
        assertThat("OldFromAccount is not correct", returnValue.getOldFromAccount(),
                is(Long.parseLong(AccountKey.fromString(originalPayment.getFrom()).getAccountNumber().getAccountNumber())));
    }
}
