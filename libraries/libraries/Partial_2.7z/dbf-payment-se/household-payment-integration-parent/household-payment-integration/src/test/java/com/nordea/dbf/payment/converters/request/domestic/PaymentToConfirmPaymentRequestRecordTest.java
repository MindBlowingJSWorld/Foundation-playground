package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentRequestPaymentsSegment;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToConfirmPaymentRequestRecordTest {

    private static final String CONFIRM_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP801";
    private static final String IP_FLAG = " ";

    private PaymentToConfirmPaymentRequestRecord paymentRequest;
    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private String userId = "1234567890";
    private String remoteAddress = "address";
    private Long agreementOwner = 123456789L;
    private ServiceData serviceData;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        paymentRequest = new PaymentToConfirmPaymentRequestRecord(nilRequestMsgHeadersMock);
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new ConfirmPaymentRequestRecord());
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));
        when(serviceRequestContextMock.getAgreementNumber()).thenReturn(Optional.of(agreementOwner));
        when(serviceRequestContextMock.getRemoteAddress()).thenReturn(remoteAddress);
        serviceData = new ServiceData(serviceRequestContextMock, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
    }

    @Test
    public void shouldMapFullRequest() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.BG_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setType(Payment.TypeEnum.bankgiro);

        ConfirmPaymentRequestRecord returnValue =
                paymentRequest.convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(CONFIRM_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE));
        assertThat("IpAddress is not correct", returnValue.getIpAddress(),
                is(serviceRequestContextMock.getRemoteAddress()));
        assertThat("IpFlag is not correct", returnValue.getIpFlag(),
                is(""));

        ConfirmPaymentRequestPaymentsSegment segment =
                (ConfirmPaymentRequestPaymentsSegment) returnValue.getPayments().next();
        assertThat("UserId is not correct", segment.getUserId(),
                is(userId));
        assertThat("CustomerId is not correct", segment.getCustomerId(),
                is(Long.parseLong(userId)));
        assertThat("GiroType is not correct", segment.getGiroType(),
                is(TestData.BG_ACCOUNT.getPrefix().toString()));
        assertThat("PaymentId is not correct", segment.getPaymentId(),
                is(Long.parseLong(payment.getId())));
        assertThat("AgreementNumber is nor correct", segment.getAgreementNumber(),
                is(agreementOwner.intValue()));
        assertThat("FromAccount is not correct", segment.getFromAccount(),
                is(Long.parseLong(TestData.BG_ACCOUNT.getAccountNumber().getAccountNumber())));
    }
}
