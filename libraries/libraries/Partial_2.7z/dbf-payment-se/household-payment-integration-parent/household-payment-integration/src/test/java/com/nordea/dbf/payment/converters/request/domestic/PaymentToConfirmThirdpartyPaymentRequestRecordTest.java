package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.ConfirmPaymentRequestRecord;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToConfirmThirdpartyPaymentRequestRecordTest {

    private static final String CONFIRM_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP807";
    private static final String MESSAGE_ID = "FQP8071";

    private Payment payment = mock(Payment.class);
    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private PaymentToConfirmPaymentRequestRecord requestRecordMock = mock(PaymentToConfirmPaymentRequestRecord.class);
    private PaymentToConfirmThirdpartyPaymentRequestRecord thirdpartyPaymentRequest;
    private ServiceData serviceData;

    @Before
    public void init() {
        ConfirmPaymentRequestRecord confirmPaymentRequestRecord = new ConfirmPaymentRequestRecord();
        when(requestRecordMock.convert(any(), any())).thenReturn(confirmPaymentRequestRecord);
        thirdpartyPaymentRequest = new PaymentToConfirmThirdpartyPaymentRequestRecord(requestRecordMock);
        serviceData = new ServiceData(serviceRequestContextMock, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
    }

    @Test
    public void shouldMapThirdpartySpecifics() {
        ConfirmPaymentRequestRecord returnValue =
                thirdpartyPaymentRequest.convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(CONFIRM_THIRD_PARTY_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE));
        assertThat("MessageId is not correct", returnValue.getMessageId(),
                is(MESSAGE_ID));
    }
}
