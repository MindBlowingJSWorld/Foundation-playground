package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.HouseholdPayment;
import com.nordea.dbf.payment.record.domestic.CreatePaymentRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import java.time.ZoneId;
import java.util.Date;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToCreatePaymentRequestRecordTest {
    private static final String CREATE_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQP800";
    private static final long PAYMENT_ID = 0L;
    private static final String SAVE_RECEIVER = "N";
    private static final String VALIDATE_FOR_FRAUD = "E";
    private static final String EINVOICE_ID = StringUtils.EMPTY;
    private static final String NICKNAME = StringUtils.EMPTY;
    private static final String STATUS_CODE = LegacyPaymentStatus.UNCONFIRMED.code();
    private static final String OWN_CATEGORY = StringUtils.EMPTY;

    private PaymentToCreatePaymentRequestRecord paymentRequest;
    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private String userId = "1234567890";
    private String remoteAddress = "address";
    private Long agreementOwner = 123456789L;
    private ServiceData serviceData;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        paymentRequest = new PaymentToCreatePaymentRequestRecord(nilRequestMsgHeadersMock);
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new CreatePaymentRequestRecord());
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));
        when(serviceRequestContextMock.getAgreementNumber()).thenReturn(Optional.of(agreementOwner));
        when(serviceRequestContextMock.getRemoteAddress()).thenReturn(remoteAddress);
        serviceData = new ServiceData(serviceRequestContextMock, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
    }

    @Test
    public void shouldMapFullRequest() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.BG_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setType(Payment.TypeEnum.bankgiro);

        CreatePaymentRequestRecord returnValue =
                paymentRequest.convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(CREATE_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE));
        assertThat("IpAddress is not correct", returnValue.getIpAddress(),
                is(remoteAddress));
        assertThat("IpFlag is not correct", returnValue.getIpFlag(),
                is(""));
        assertThat("PaymentId is not correct", returnValue.getPaymentId(),
                is(PAYMENT_ID));
        assertThat("AgreementNumber is not correct", returnValue.getAgreementNumber(),
                is(agreementOwner.intValue()));
        assertThat("Amount is not correct", returnValue.getAmount(),
                is(payment.getAmount().doubleValue()));
        assertThat("CustomerId is not correct", returnValue.getCustomerId(),
                is(Long.parseLong(userId)));
        assertThat("DueDate is not correct", returnValue.getDueDate(),
                is(HouseholdPayment.PAYMENT_DATE_FORMAT.format(Date.from(payment.getDue().atStartOfDay(ZoneId.systemDefault()).toInstant())).substring(0, 10)));
        assertThat("EInvoiceId is not correct", returnValue.getEinvoiceId(),
                is(EINVOICE_ID));
        assertThat("FromAccount is not correct", returnValue.getFromAccount(),
                is(Long.parseLong(TestData.BG_ACCOUNT.getAccountNumber().getAccountNumber())));
        assertThat("FromAccountCurrency is not correct", returnValue.getFromAccountCurrency(),
                is(""));
        assertThat("GiroType is not correct", returnValue.getGiroType(),
                is(LegacyGiroType.convertToGiroType(TestData.BG_ACCOUNT.getPrefix())));
        assertThat("Message is not correct", returnValue.getMessage(),
                is(payment.getMessage()));
        assertThat("Nickname is not correct", returnValue.getNickname(),
                is(NICKNAME));
        assertThat("OwnCategory is not correct", returnValue.getOwnCategory(),
                is(OWN_CATEGORY));
        assertThat("OwnReference is not correct", returnValue.getOwnReference(),
                is(payment.getOwnMessage()));
        assertThat("SaveReceiver is not correct", returnValue.getSaveReceiver(),
                is(SAVE_RECEIVER));
        assertThat("StatusCode is not correct", returnValue.getStatusCode(),
                is(STATUS_CODE));
        assertThat("ToAccount is not correct", returnValue.getToAccount(),
                is(Long.parseLong(TestData.BG_ACCOUNT.getAccountNumber().getAccountNumber())));
        assertThat("TransactionCurrency is not correct", returnValue.getTransactionCurrency(),
                is(payment.getCurrency()));
        assertThat("UserId is not correct", returnValue.getUserId(),
                is(userId));
        assertThat("ValidateForFraud is not correct", returnValue.getValidateForFraud(),
                is(VALIDATE_FOR_FRAUD));
        assertThat("BankName is not correct", returnValue.getReceiverName(),
                is(StringUtils.EMPTY));
        assertThat("Prolong is not correct", returnValue.getProlong(),
                is(HouseholdPayment.RECURR_ONCE));
        assertThat("RecurringNumber is not correct", returnValue.getRecurringNumber(),
                is(0));
    }

    @Test
    public void shouldMapAllExtraMessageCases() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.BG_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setType(Payment.TypeEnum.bankgiro);

        CreatePaymentRequestRecord returnValue =
                paymentRequest.convert(serviceData, payment);

        assertThat("BankName is not correct", returnValue.getReceiverName(),
                is(StringUtils.EMPTY));
    }

    @Test
    public void shouldThrowExceptionDueToNullRecurring() {
        Payment payment = generatePayment();
        PaymentRecurring paymentRecurring = new PaymentRecurring();
        payment.setRecurring(paymentRecurring);
        assertThatThrownBy(() -> paymentRequest.convert(serviceData, payment))
                .isInstanceOf(IllegalArgumentException.class);
    }


    @Test
    public void shouldThrowExceptionDueToDailyInterval() {
        Payment payment = generatePayment();
        PaymentRecurring paymentRecurring = new PaymentRecurring();
        paymentRecurring.setInterval(PaymentRecurring.IntervalEnum.daily);
        payment.setRecurring(paymentRecurring);
        assertThatThrownBy(() -> paymentRequest.convert(serviceData, payment))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void shouldThrowExceptionDueToNullFrequency() {
        Payment payment = generatePayment();
        PaymentRecurring paymentRecurring = new PaymentRecurring();
        paymentRecurring.setInterval(PaymentRecurring.IntervalEnum.monthly);
        paymentRecurring.setFrequency(null);
        payment.setRecurring(paymentRecurring);
        assertThatThrownBy(() -> paymentRequest.convert(serviceData, payment))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void shouldThrowExceptionDueToInvalidFrequency() {
        Payment payment = generatePayment();
        PaymentRecurring paymentRecurring = new PaymentRecurring();
        paymentRecurring.setInterval(PaymentRecurring.IntervalEnum.monthly);
        paymentRecurring.setFrequency(2);
        payment.setRecurring(paymentRecurring);
        assertThatThrownBy(() -> paymentRequest.convert(serviceData, payment))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void shouldMapRecurringCountFromArg() {
        Payment payment = generatePayment();
        PaymentRecurring paymentRecurring = new PaymentRecurring();

        int paymentRecurringCount = 1;
        paymentRecurring.setInterval(PaymentRecurring.IntervalEnum.monthly);
        paymentRecurring.setFrequency(1);
        paymentRecurring.setCount(paymentRecurringCount);
        payment.setRecurring(paymentRecurring);
        CreatePaymentRequestRecord returnValue =
            paymentRequest.convert(serviceData, payment);

        assertThat("RecurringNumber is not correct", returnValue.getRecurringNumber(),
                is(paymentRecurringCount));
    }

    @Test
    public void shouldMapRecurringCountFromNull() {
        Payment payment = generatePayment();
        PaymentRecurring paymentRecurring = new PaymentRecurring();

        paymentRecurring.setInterval(PaymentRecurring.IntervalEnum.monthly);
        paymentRecurring.setFrequency(1);
        paymentRecurring.setCount(null);
        payment.setRecurring(paymentRecurring);
        CreatePaymentRequestRecord returnValue =
            paymentRequest.convert(serviceData, payment);
        assertThat("RecurringNumber is not correct", returnValue.getRecurringNumber(),
                is(HouseholdPayment.RECURR_FOR_EVER));
    }

    private Payment generatePayment() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.BG_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setType(Payment.TypeEnum.bankgiro);
        return payment;
    }
}
