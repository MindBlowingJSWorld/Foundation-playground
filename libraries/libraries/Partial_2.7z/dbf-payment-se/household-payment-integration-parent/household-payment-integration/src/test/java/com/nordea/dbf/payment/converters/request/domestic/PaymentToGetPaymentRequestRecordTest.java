package com.nordea.dbf.payment.converters.request.domestic;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.LegacyPaymentSubType;
import com.nordea.dbf.payment.record.domestic.GetPaymentRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToGetPaymentRequestRecordTest {

    private static final String GET_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE = "FQQ850";
    private static final String IP_FLAG = " ";
    private PaymentToGetPaymentRequestRecord paymentRequest;
    private ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);
    private String userId = "1234567890";
    private String remoteAddress = "address";
    private Long agreementOwner = 123456789L;
    private ServiceData serviceData;

    @Before
    public void init() {
        NilRequestMsgHeaders nilRequestMsgHeadersMock = mock(NilRequestMsgHeaders.class);
        paymentRequest = new PaymentToGetPaymentRequestRecord(nilRequestMsgHeadersMock);
        when(nilRequestMsgHeadersMock.withHeaderConfiguration(any(), any()))
                .thenReturn(new GetPaymentRequestRecord());
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));
        when(serviceRequestContextMock.getAgreementNumber()).thenReturn(Optional.of(agreementOwner));
        when(serviceRequestContextMock.getRemoteAddress()).thenReturn(remoteAddress);
        serviceData = new ServiceData(serviceRequestContextMock, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
    }

    @Test
    public void shouldMapFullRequest() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.BG_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setType(Payment.TypeEnum.bankgiro);

        GetPaymentRequestRecord returnValue =
                paymentRequest.convert(serviceData, payment);

        assertThat("TransactionCode is not correct", returnValue.getTransactionCode(),
                is(GET_PAYMENT_REQUEST_RECORD_TRANSACTION_CODE));
        assertThat("IpAddress is not correct", returnValue.getIpAddress(),
                is(serviceRequestContextMock.getRemoteAddress()));
        assertThat("PaymentId is not correct", returnValue.getPaymentId(),
                is(Long.parseLong(payment.getId())));
        assertThat("CustomerId is not correct", returnValue.getCustomerId(),
                is(Long.parseLong(userId)));
        assertThat("AgreementNumber is not correct", returnValue.getAgreementNumber(),
                is(agreementOwner.intValue()));
        assertThat("FromAccount is not correct", returnValue.getFromAccount(),
                is(Long.parseLong(TestData.BG_ACCOUNT.getAccountNumber().getAccountNumber())));
        assertThat("SubType is not correct", returnValue.getSubType(),
                is(LegacyPaymentSubType.fromAccountKey(TestData.BG_ACCOUNT_KEY).code()));
        assertThat("GiroType is not correct", returnValue.getGiroType(),
                is(LegacyGiroType.convertToGiroType(TestData.BG_ACCOUNT.getPrefix())));
        assertThat("PaymentStatus is not correct", returnValue.getPaymentStatus(),
                is(LegacyPaymentStatus.fromPaymentStatusEnum(payment.getStatus()).code()));
    }
}
