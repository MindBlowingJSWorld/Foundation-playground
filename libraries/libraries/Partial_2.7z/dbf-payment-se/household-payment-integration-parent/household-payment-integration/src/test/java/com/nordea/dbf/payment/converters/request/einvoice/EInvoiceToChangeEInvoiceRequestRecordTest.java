package com.nordea.dbf.payment.converters.request.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.validators.PaymentValidator;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.model.LegacyEInvoice;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestEInvoicesSegment;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestRecord;
import com.nordea.dbf.payment.testdata.EInvoices;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class EInvoiceToChangeEInvoiceRequestRecordTest {

    private static final String EINVOICE_REQUEST_RECORD_TRANSACTION_CODE = "M8047P";
    private static final String CHANGE_EINVOICE_MESSAGE_ID = "M8047P4";
    private NilRequestMsgHeaders nilRequestMsgHeaders = mock(NilRequestMsgHeaders.class);
    private ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
    private EInvoiceToChangeEInvoiceRequestRecord eInvoiceToChangeEInvoiceRequestRecord;
    private EInvoice testEInvoice;
    private Payment testPayment;
    private ServiceData serviceData;

    @Before
    public void init() {
        when(nilRequestMsgHeaders.eInvoiceRequestFrom(any())).thenReturn(new EInvoiceRequestRecord());
        when(serviceRequestContext.getUserId()).thenReturn(Optional.of("12345678912345"));
        when(serviceRequestContext.getAgreementNumber()).thenReturn(Optional.of(123456789101112L));

        eInvoiceToChangeEInvoiceRequestRecord =
                new EInvoiceToChangeEInvoiceRequestRecord(nilRequestMsgHeaders);
        testEInvoice = EInvoices.plusgiroInvoice1().build();
        testPayment = PaymentTestData.getUnconfirmedPayment(TestData.BG_ACCOUNT, TestData.BG_ACCOUNT);
        serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

    }

    @Test
    public void shouldMapFullRequest() {
        EInvoiceRequestRecord requestRecord =
                eInvoiceToChangeEInvoiceRequestRecord.with(testEInvoice).convert(serviceData, testPayment);

        assertTrue("EInvoices is not correct", requestRecord.getEInvoices().hasNext());
        assertThat("TransactionCode is not correct", requestRecord.getTransactionCode(),
                is(EINVOICE_REQUEST_RECORD_TRANSACTION_CODE));
        assertThat("MessageId is not correct", requestRecord.getMessageId(),
                is(CHANGE_EINVOICE_MESSAGE_ID));

        EInvoiceRequestEInvoicesSegment segment = (EInvoiceRequestEInvoicesSegment) requestRecord.getEInvoices().next();
        assertThat("ArrivalDate is not correct", segment.getArrivalDate(),
                is(testEInvoice.getArrivalDate().format(LegacyEInvoice.ARRIVAL_DATE_FORMAT)));
        assertThat("InvoiceId is not correct", segment.getInvoiceId(),
                is(testEInvoice.getInvoiceId()));
        assertThat("Message is not correct", segment.getMessage(),
                is(testEInvoice.getMessage()));
        assertThat("OwnReference is not correct", segment.getOwnReference(),
                is(testEInvoice.getOwnReference()));
        assertThat("Currency is not correct", segment.getCurrency(),
                is(testEInvoice.getCurrency().getCurrencyCode()));
        assertThat("Amount is not correct", segment.getAmount(),
                is(testEInvoice.getAmount().doubleValue()));
        assertThat("DueDate is not correct", segment.getDueDate(),
                is(testEInvoice.getDueDate().format(LegacyEInvoice.DUE_DATE_FORMAT)));
        assertThat("FromAccount is not correct", segment.getFromAccount(),
                is(testEInvoice.getFromAccount()));
        assertThat("GiroType is not correct", segment.getGiroType(),
                is(testEInvoice.getGiroType()));
        assertThat("InvoicerId is not correct", segment.getInvoicerId(),
                is(testEInvoice.getInvoicerId()));
        assertThat("InvoicerName is not correct", segment.getInvoicerName(),
                is(testEInvoice.getInvoicerName()));
        assertThat("IsOcr is not correct", segment.getIsOcr(),
                is(testEInvoice.getIsOcr()));
        assertThat("OwnCategory is not correct", segment.getOwnCategory(),
                is(""));
        assertThat("ToAccount is not correct", segment.getToAccount(),
                is(testEInvoice.getToAccount()));
    }
}
