package com.nordea.dbf.payment.converters.request.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestRecord;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentFilterToGetEInvoiceListRequestRecordTest {

    private static final String EINVOICE_REQUEST_RECORD_TRANSACTION_CODE = "M8047P";
    private static final String GET_EINVOICE_LIST_MESSAGE_ID = "M8047P6";
    private NilRequestMsgHeaders nilRequestMsgHeaders = mock(NilRequestMsgHeaders.class);
    private ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
    private PaymentFilterToGetEInvoicesRequestRecord paymentFilterToGetEInvoicesRequestRecord;
    private ServiceData serviceData;

    @Before
    public void init() {
        when(nilRequestMsgHeaders.eInvoiceRequestFrom(any())).thenReturn(new EInvoiceRequestRecord());
        paymentFilterToGetEInvoicesRequestRecord = new PaymentFilterToGetEInvoicesRequestRecord(nilRequestMsgHeaders);
        serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
    }

    @Test
    public void shouldMapFullRequest() {
        EInvoiceRequestRecord requestRecord =
                paymentFilterToGetEInvoicesRequestRecord.convert(serviceData, new PaymentFilter());

        assertThat("TransactionCode is not correct", requestRecord.getTransactionCode(),
                is(EINVOICE_REQUEST_RECORD_TRANSACTION_CODE));
        assertThat("MessageId is not correct", requestRecord.getMessageId(),
                is(GET_EINVOICE_LIST_MESSAGE_ID));
    }

    @Test
    public void shouldReturnNull() {
        PaymentFilter paymentFilter = new PaymentFilter();
        List<String> ll = new ArrayList<>();
        Arrays.stream(Payment.TypeEnum.values())
                .filter(typeEnum -> !typeEnum.equals(Payment.TypeEnum.einvoice))
                .forEach(typeEnum -> ll.add(typeEnum.toString()));
        paymentFilter.setPaymentTypes(ll);

        assertNull(paymentFilterToGetEInvoicesRequestRecord.convert(serviceData, paymentFilter));

    }
}
