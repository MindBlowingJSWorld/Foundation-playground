package com.nordea.dbf.payment.converters.request.einvoice;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestEInvoicesSegment;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestRecord;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Before;
import org.junit.Test;
import rx.Observable;

import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class PaymentToGetEInvoiceRequestRecordTest {

    private static final String EINVOICE_REQUEST_RECORD_TRANSACTION_CODE = "M8047P";
    private static final String GET_EINVOICE_MESSAGE_ID = "M8047P5";
    private NilRequestMsgHeaders nilRequestMsgHeaders = mock(NilRequestMsgHeaders.class);
    private ServiceRequestContext serviceRequestContext = mock(ServiceRequestContext.class);
    private PaymentToGetEInvoiceRequestRecord paymentToGetEInvoiceRequestRecord;
    private Payment testPayment;
    private ServiceData serviceData;

    @Before
    public void init() {
        when(nilRequestMsgHeaders.eInvoiceRequestFrom(any())).thenReturn(new EInvoiceRequestRecord());
        when(serviceRequestContext.getUserId()).thenReturn(Optional.of("12345678912345"));
        when(serviceRequestContext.getAgreementNumber()).thenReturn(Optional.of(123456789101112L));

        paymentToGetEInvoiceRequestRecord = new PaymentToGetEInvoiceRequestRecord(nilRequestMsgHeaders);
        testPayment = PaymentTestData.getConfirmedPayment(TestData.BG_ACCOUNT, TestData.BG_ACCOUNT);
        serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
    }

    @Test
    public void shouldMapFullRequest() {

        EInvoiceRequestRecord requestRecord =
                paymentToGetEInvoiceRequestRecord.convert(serviceData, testPayment);


        assertTrue("EInvoices is not correct", requestRecord.getEInvoices().hasNext());
        assertThat("InvoiceId is not correct", ((EInvoiceRequestEInvoicesSegment) requestRecord.getEInvoices().next()).getInvoiceId(),
                is(testPayment.getId()));
        assertThat("TransactionCode is not correct", requestRecord.getTransactionCode(),
                is(EINVOICE_REQUEST_RECORD_TRANSACTION_CODE));
        assertThat("MessageId is not correct", requestRecord.getMessageId(),
                is(GET_EINVOICE_MESSAGE_ID));
    }

    @Test
    public void shouldMapNulls() {
        EInvoiceRequestRecord requestRecord =
            paymentToGetEInvoiceRequestRecord.convert(serviceData, new Payment());

        assertThat("InvoiceId is not correct", ((EInvoiceRequestEInvoicesSegment) requestRecord.getEInvoices().next()).getInvoiceId(),
                is(""));
    }
}
