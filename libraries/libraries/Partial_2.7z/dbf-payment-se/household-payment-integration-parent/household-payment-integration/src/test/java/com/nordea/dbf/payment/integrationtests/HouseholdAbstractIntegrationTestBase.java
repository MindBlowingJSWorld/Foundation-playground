package com.nordea.dbf.payment.integrationtests;

import com.nordea.dbf.agreement.customer.se.model.Agreement;
import com.nordea.dbf.http.RequestCache;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.PaymentFacade;
import com.nordea.dbf.payment.config.HouseholdConfiguration;
import com.nordea.dbf.payment.config.HouseholdTestConfiguration;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.security.SecureRandom;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {HouseholdConfiguration.class, HouseholdTestConfiguration.class})
public abstract class HouseholdAbstractIntegrationTestBase {
    @Autowired
    protected HouseholdTestDataManager householdTestDataManager;

    @Autowired
    @Qualifier("householdPaymentFacade")
    protected PaymentFacade householdPaymentFacade;

    protected Agreement agreement = mock(Agreement.class);

    protected ServiceRequestContext getServiceRequestContext(String householdUserId, long householdAgreementId) {
        SecureRandom random = new SecureRandom();
        String requestId = IntStream.range(0, 10).mapToObj((value) -> {
            switch(random.nextInt(3)) {
                case 0:
                    return String.valueOf((char)(97 + random.nextInt(25)));
                case 1:
                    return String.valueOf((char)(65 + random.nextInt(25)));
                case 2:
                    return String.valueOf((char)(48 + random.nextInt(9)));
                default:
                    throw new RuntimeException();
            }
        }).collect(Collectors.joining());
        return new ServiceRequestContext() {
            @Override
            public Optional<String> getApplicationId() {
                return Optional.of("ROSME");
            }

            @Override
            public Optional<String> getRequestId() {
                return Optional.of(requestId);
            }

            @Override
            public Optional<String> getSessionId() {
                return Optional.of(UUID.randomUUID().toString());
            }

            @Override
            public Optional<String> getUserId() {
                return Optional.of(householdUserId);
            }

            @Override
            public Optional<String> getAuthenticationMethod() {
                return Optional.of("BANKID");
            }

            @Override
            public Optional<String> getAuthenticationLevel() {
                return Optional.of("HIGH");
            }

            @Override
            public Optional<String> getAuthenticationToken() {
                return null;
            }

            @Override
            public Optional<String> getChannelId() {
                return Optional.of("RBO");
            }

            @Override
            public Optional<String> getCountry() {
                return Optional.of("SE");
            }

            @Override
            public Optional<Locale> getLanguage() {
                return Optional.empty();
            }

            @Override
            public Optional<Long> getAgreementNumber() {
                return Optional.of(householdAgreementId);
            }

            @Override
            public String getRemoteAddress() {
                return "127.0.0.1";
            }

            @Override
            public long getTimeStamp() {
                return 0;
            }

            @Override
            public List<String> getRequestRoute() {
                return null;
            }

            @Override
            public RequestCache getRequestCache() {
                return null;
            }
        };
    }

    @BeforeClass
    public static void configureEnvironment() throws Exception {
        System.setProperty("com.nordea.environmenttype", "UNIT_TEST");
    }

    @Before
    public void setupTestData() {
        // Add if necessary.
        when(agreement.getAgreementOwner()).thenReturn("194008010011");

    }
}
