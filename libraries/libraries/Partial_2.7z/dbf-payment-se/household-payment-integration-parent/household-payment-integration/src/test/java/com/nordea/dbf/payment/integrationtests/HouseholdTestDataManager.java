package com.nordea.dbf.payment.integrationtests;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.payment.common.model.LegacyGiroType;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.converters.LegacyCrossBorderConverter;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.model.LegacyEInvoice;
import com.nordea.dbf.payment.record.crossborder.household.*;
import com.nordea.dbf.payment.record.domestic.*;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static com.nordea.dbf.payment.model.PaymentStatusToMessageId.getSubMessageIdByStatus;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

public class HouseholdTestDataManager {

    @Autowired
    private M8ImsConnection m8ImsConnection;

    public void mockDeletionOfHouseholdPaymentTransaction(String paymentId) {
        when(m8ImsConnection.execute(isA(DeletePaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            DeletePaymentResponseRecord deletePaymentResponseRecord = new DeletePaymentResponseRecord();
            deletePaymentResponseRecord.setPaymentId(Long.parseLong(paymentId));
            return Observable.just(deletePaymentResponseRecord);
        });
    }

    public void mockListingOfNoCrossborderPayments() {
        when(m8ImsConnection.execute(isA(GetCrossBorderPaymentListRequestRecord.class), any(Class.class))).thenAnswer(s -> Observable.empty());
    }

    public void mockListingOfNoHouseholdPayments() {
        when(m8ImsConnection.execute(isA(PaymentListRequestRecord.class), any(Class.class))).thenAnswer(s -> Observable.empty());
    }

    public void mockCrossborderPaymentNotFound() {
        when(m8ImsConnection.execute(isA(GetCrossBorderPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetCrossBorderPaymentResponseRecord getCrossBorderPaymentResponseRecord = new GetCrossBorderPaymentResponseRecord();
            getCrossBorderPaymentResponseRecord.setKbearb(8);
            getCrossBorderPaymentResponseRecord.setKrc(200);
            return Observable.just(getCrossBorderPaymentResponseRecord);
        });
    }

    public void mockListingOfHouseholdPaymentThrowsException() {
        when(m8ImsConnection.execute(isA(PaymentListRequestRecord.class), any(Class.class))).thenThrow(new NullPointerException(""));
    }

    public void mockListingOfOneHouseholdPayment(Payment payment) {
        mockListingOfOneHouseholdPaymentWithStatus(payment, payment.getStatus());
    }

    public void mockListingOfOneHouseholdPaymentWithStatus(Payment payment, Payment.StatusEnum status) {
        when(m8ImsConnection.execute(isA(PaymentListRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            PaymentListRequestRecord paymentListRequestRecord = (PaymentListRequestRecord) s.getArguments()[0];
            if (paymentListRequestRecord.getMessageId().equals(getSubMessageIdByStatus(status))) {
                PaymentListResponseRecord paymentListResponseRecord = new PaymentListResponseRecord();
                final com.nordea.dbf.payment.record.domestic.PaymentListResponsePaymentsSegment segment = paymentListResponseRecord.addPayments();

                configurePaymentListResponseSegment(payment, status, segment);
                return Observable.just(paymentListResponseRecord);
            } else {
                return Observable.empty();
            }
        });
    }

    public void mockListingOfHouseholdPayments(Payment... payments) {
        when(m8ImsConnection.execute(isA(PaymentListRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            PaymentListRequestRecord paymentListRequestRecord = (PaymentListRequestRecord) s.getArguments()[0];
            PaymentListResponseRecord paymentListResponseRecord = new PaymentListResponseRecord();
            for (Payment payment : payments) {
                if (paymentListRequestRecord.getMessageId().equals(getSubMessageIdByStatus(payment.getStatus()))) {
                    final com.nordea.dbf.payment.record.domestic.PaymentListResponsePaymentsSegment segment = paymentListResponseRecord.addPayments();

                    configurePaymentListResponseSegment(payment, payment.getStatus(), segment);
                }
            }
            return Observable.just(paymentListResponseRecord);
        });
    }

    private void configurePaymentListResponseSegment(Payment payment, Payment.StatusEnum status, PaymentListResponsePaymentsSegment segment) {
        segment.setPaymentId(Long.parseLong(payment.getId()));
        segment.setFromAccount(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
        segment.setFromAccountCurrency(AccountKey.fromString(payment.getFrom()).getCurrencyCode().orElse(""));
        segment.setGiroType(LegacyGiroType.convertToGiroType(AccountKey.fromString(payment.getTo()).getPrefix()));
        segment.setToAccount(Long.parseLong(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber()));
        segment.setToAccountCurrency(AccountKey.fromString(payment.getTo()).getCurrencyCode().orElse(""));
        segment.setDueDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        segment.setAmount(payment.getAmount().doubleValue());
        segment.setTransactionCurrency(payment.getCurrency());
        segment.setPaymentStatus(LegacyPaymentStatus.fromPaymentStatusEnum(status).code());
    }

    public void mockRetrieveHouseholdPayment(Payment payment) {
        mockRetrieveHouseholdPaymentWithStatus(payment, payment.getStatus());
    }

    public void mockRetrieveHouseholdPaymentWithStatus(Payment payment, Payment.StatusEnum status) {
        when(m8ImsConnection.execute(isA(GetPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetPaymentResponseRecord getPaymentResponseRecord = configureGetPaymentResponseRecord(payment, status);

            return Observable.just(getPaymentResponseRecord);
        });
    }

    public void mockRetrieveHouseholdPayments(Payment... payments) {
        when(m8ImsConnection.execute(isA(GetPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            GetPaymentRequestRecord req = (GetPaymentRequestRecord) s.getArguments()[0];
            for (Payment payment : payments) {
                if (payment.getId().equals(Long.toString(req.getPaymentId()))) {
                    return Observable.just(configureGetPaymentResponseRecord(payment, payment.getStatus()));
                }
            }

            return Observable.empty();
        });
    }

    private GetPaymentResponseRecord configureGetPaymentResponseRecord(Payment payment, Payment.StatusEnum status) {
        GetPaymentResponseRecord getPaymentResponseRecord = new GetPaymentResponseRecord();
        getPaymentResponseRecord.setAllowedToCopy("Y");
        getPaymentResponseRecord.setAllowedToDelete("Y");
        getPaymentResponseRecord.setAllowedToModify("Y");
        getPaymentResponseRecord.setAmount(payment.getAmount().doubleValue());
        getPaymentResponseRecord.setBeneficiaryDbResponse("");
        getPaymentResponseRecord.setCounterValue(0);
        getPaymentResponseRecord.setDateDeposit("");
        getPaymentResponseRecord.setDateWithdrawal("");
        //FIXME: User java.time.Clock to not have constants rely on each other in different places
        getPaymentResponseRecord.setDueDate(LocalDateTime.now().plusDays(5).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        getPaymentResponseRecord.setEinvoiceId("");
        getPaymentResponseRecord.setExchangeRate(0);
        getPaymentResponseRecord.setFromAccount(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
        getPaymentResponseRecord.setFromAccountCurrencyCode(payment.getCurrency());
        getPaymentResponseRecord.setGiroType(LegacyGiroType.convertToGiroType(AccountKey.fromString(payment.getTo()).getPrefix()));
        getPaymentResponseRecord.setMessage(payment.getMessage());
        getPaymentResponseRecord.setNickname("");
        getPaymentResponseRecord.setOcrType("");
        getPaymentResponseRecord.setOwnCategory("");
        getPaymentResponseRecord.setOwnReference(payment.getOwnMessage());
        getPaymentResponseRecord.setPaymentId(Long.parseLong(payment.getId()));
        getPaymentResponseRecord.setPaymentStatus(LegacyPaymentStatus.fromPaymentStatusEnum(status).code());
        getPaymentResponseRecord.setProlong("001");
        getPaymentResponseRecord.setReasonCode("");
        getPaymentResponseRecord.setReceiverName("");

        PaymentRecurring recurring = payment.getRecurring();
        if (recurring != null) {
            if (recurring.getCount() == null &&
                    recurring.getFrequency() == 1 &&
                    recurring.getInterval().equals(PaymentRecurring.IntervalEnum.monthly) &&
                    recurring.getLastday().equals(false)) {
                // This is recurring forever.
                getPaymentResponseRecord.setRecurringContinously("Y");
                getPaymentResponseRecord.setRecurringNumber(999);
            } else {
                getPaymentResponseRecord.setRecurringContinously("N");
                getPaymentResponseRecord.setRecurringNumber(recurring.getCount());
            }
        }
        getPaymentResponseRecord.setToAccount(Long.parseLong(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber()));
        getPaymentResponseRecord.setToAccountCurrencyCode(payment.getCurrency());
        getPaymentResponseRecord.setTransactionCurrency(payment.getCurrency());
        return getPaymentResponseRecord;
    }

    public void mockRetrieveNoCrossborderHouseholdPayment() {
        when(m8ImsConnection.execute(isA(GetCrossBorderPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
                    GetCrossBorderPaymentResponseRecord getCrossBorderPaymentResponseRecord = new GetCrossBorderPaymentResponseRecord();
                    getCrossBorderPaymentResponseRecord.setKbearb(8);
                    getCrossBorderPaymentResponseRecord.setKrc(200);
                    return Observable.just(getCrossBorderPaymentResponseRecord);
                }
        );
    }

    public void mockRetrieveHouseholdCrossborderPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(GetCrossBorderPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
                    GetCrossBorderPaymentResponseRecord getCrossBorderPaymentResponseRecord = new GetCrossBorderPaymentResponseRecord();
                    if (payment.getStatus().equals(Payment.StatusEnum.unconfirmed)) {
                        getCrossBorderPaymentResponseRecord.setPaymentStatusCode("11");
                    } else if (payment.getStatus().equals(Payment.StatusEnum.confirmed)) {
                        getCrossBorderPaymentResponseRecord.setPaymentStatusCode("01");
                    } else {
                        throw new IllegalArgumentException("Add status as required for mockRetrieveHouseholdCrossborderPayment: " + payment.getStatus());
                    }
                    getCrossBorderPaymentResponseRecord.setCbrCode("461");

                    getCrossBorderPaymentResponseRecord.setLegacyKey(payment.getId().substring(17));
                    getCrossBorderPaymentResponseRecord.setInputDate(payment.getId().substring(11, 17));

                    getCrossBorderPaymentResponseRecord.setFromAccountId(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber());
                    getCrossBorderPaymentResponseRecord.setFromAccountIdAndCurrency(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber() + payment.getCurrency());
                    getCrossBorderPaymentResponseRecord.setExecutionDate(payment.getDue().format(DateTimeFormatter.ofPattern("yyMMdd")));
                    getCrossBorderPaymentResponseRecord.setAmount(payment.getAmount());
                    getCrossBorderPaymentResponseRecord.setCurrency(payment.getCurrency());
                    getCrossBorderPaymentResponseRecord.setToAccountId(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber());
                    getCrossBorderPaymentResponseRecord.setChargePaidBy(LegacyCrossBorderConverter.convertChargePaidByToLegacy(payment.getCrossBorder().getChargePaidBy()));
                    getCrossBorderPaymentResponseRecord.setReceivingBankBIC(AccountKey.fromString(payment.getTo()).getBIC().get());
                    return Observable.just(getCrossBorderPaymentResponseRecord);
                }
        );
    }

    public void mockCreateHouseholdCrossborderPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(CreateCrossBorderPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            CrossBorderPaymentIdResponseRecord crossBorderPaymentIdResponseRecord = new CrossBorderPaymentIdResponseRecord();
            crossBorderPaymentIdResponseRecord.setLegacyKey(payment.getId());
            crossBorderPaymentIdResponseRecord.setTransactionCode(payment.getId());
            return Observable.just(crossBorderPaymentIdResponseRecord);
        });
    }

    public void mockCreateHouseholdPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(CreatePaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            CreatePaymentResponseRecord createPaymentResponseRecord = new CreatePaymentResponseRecord();
            createPaymentResponseRecord.setAllowedToCopy("Y");
            createPaymentResponseRecord.setAllowedToDelete("Y");
            createPaymentResponseRecord.setAllowedToModify("Y");
            createPaymentResponseRecord.setAmount(payment.getAmount().doubleValue());
            createPaymentResponseRecord.setBeneficiaryDbResponse("");
            createPaymentResponseRecord.setCounterValue(0);
            createPaymentResponseRecord.setDateDeposit("");
            createPaymentResponseRecord.setDateWithdrawal("");
            createPaymentResponseRecord.setDueDate(payment.getDue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            createPaymentResponseRecord.setEinvoiceId("");
            createPaymentResponseRecord.setExchangeRate(0);
            createPaymentResponseRecord.setFromAccount(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
            createPaymentResponseRecord.setFromAccountCurrencyCode(payment.getCurrency());
            createPaymentResponseRecord.setGiroType(LegacyGiroType.convertToGiroType(AccountKey.fromString(payment.getTo()).getPrefix()));
            createPaymentResponseRecord.setMessage(payment.getMessage());
            createPaymentResponseRecord.setNickname("");
            createPaymentResponseRecord.setOcrType("");
            createPaymentResponseRecord.setOwnCategory("");
            createPaymentResponseRecord.setOwnReference(payment.getOwnMessage());
            createPaymentResponseRecord.setPaymentId(Long.parseLong(payment.getId()));
            createPaymentResponseRecord.setPaymentStatus(LegacyPaymentStatus.fromPaymentStatusEnum(payment.getStatus()).code());
            createPaymentResponseRecord.setProlong("001");
            createPaymentResponseRecord.setReasonCode("");
            createPaymentResponseRecord.setReceiverName("");

            PaymentRecurring recurring = payment.getRecurring();
            if (recurring != null) {
                if (recurring.getCount() == null &&
                        recurring.getFrequency() == 1 &&
                        recurring.getInterval().equals(PaymentRecurring.IntervalEnum.monthly) &&
                        recurring.getLastday().equals(false)) {
                    // This is recurring forever.
                    createPaymentResponseRecord.setRecurringContinously("Y");
                    createPaymentResponseRecord.setRecurringNumber(999);
                } else {
                    createPaymentResponseRecord.setRecurringContinously("N");
                    createPaymentResponseRecord.setRecurringNumber(recurring.getCount());
                }
            }
            createPaymentResponseRecord.setToAccount(Long.parseLong(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber()));
            createPaymentResponseRecord.setToAccountCurrencyCode(payment.getCurrency());
            createPaymentResponseRecord.setTransactionCurrency(payment.getCurrency());
            return Observable.just(createPaymentResponseRecord);
        });
    }

    public void mockDeleteHouseholdPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(DeletePaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            DeletePaymentResponseRecord deletePaymentResponseRecord = new DeletePaymentResponseRecord();
            deletePaymentResponseRecord.setPaymentId(Long.valueOf(payment.getId()));
            return Observable.just(deletePaymentResponseRecord);
        });
    }

    public void mockDeleteHouseholdCrossborderPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(DeleteCrossBorderPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            CrossBorderPaymentIdResponseRecord crossborderPaymentIdResponseRecord = new CrossBorderPaymentIdResponseRecord();
            crossborderPaymentIdResponseRecord.setLegacyKey(payment.getId());
            return Observable.just(crossborderPaymentIdResponseRecord);
        });
    }

    public void mockChangeOfOneHouseholdPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(ChangePaymentRequestRecord.class), any(Class.class))).thenAnswer(i -> {
            ChangePaymentResponseRecord changePaymentResponseRecord = new ChangePaymentResponseRecord();
            changePaymentResponseRecord.setAllowedToCopy("Y");
            changePaymentResponseRecord.setAllowedToDelete("Y");
            changePaymentResponseRecord.setAllowedToModify("Y");
            changePaymentResponseRecord.setAmount(payment.getAmount().doubleValue());
            changePaymentResponseRecord.setBeneficiaryDbResponse("");
            changePaymentResponseRecord.setCounterValue(0);
            changePaymentResponseRecord.setDateDeposit("");
            changePaymentResponseRecord.setDateWithdrawal("");
            changePaymentResponseRecord.setDueDate(payment.getDue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            changePaymentResponseRecord.setEinvoiceId("");
            changePaymentResponseRecord.setExchangeRate(0);
            changePaymentResponseRecord.setFromAccount(Long.parseLong(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));
            changePaymentResponseRecord.setFromAccountCurrencyCode(payment.getCurrency());
            changePaymentResponseRecord.setGiroType(LegacyGiroType.convertToGiroType(AccountKey.fromString(payment.getTo()).getPrefix()));
            changePaymentResponseRecord.setMessage(payment.getMessage());
            changePaymentResponseRecord.setNickname("");
            changePaymentResponseRecord.setOcrType("");
            changePaymentResponseRecord.setOwnCategory("");
            changePaymentResponseRecord.setOwnReference(payment.getOwnMessage());
            changePaymentResponseRecord.setPaymentId(Long.parseLong(payment.getId()));
            changePaymentResponseRecord.setPaymentStatus(LegacyPaymentStatus.fromPaymentStatusEnum(payment.getStatus()).code());
            changePaymentResponseRecord.setProlong("001");
            changePaymentResponseRecord.setReasonCode("");
            changePaymentResponseRecord.setReceiverName("");

            PaymentRecurring recurring = payment.getRecurring();
            if (recurring != null) {
                if (recurring.getCount() == null &&
                        recurring.getFrequency() == 1 &&
                        recurring.getInterval().equals(PaymentRecurring.IntervalEnum.monthly) &&
                        recurring.getLastday().equals(false)) {
                    // This is recurring forever.
                    changePaymentResponseRecord.setRecurringContinously("Y");
                    changePaymentResponseRecord.setRecurringNumber(999);
                } else {
                    changePaymentResponseRecord.setRecurringContinously("N");
                    changePaymentResponseRecord.setRecurringNumber(recurring.getCount());
                }
            }
            changePaymentResponseRecord.setToAccount(Long.parseLong(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber()));
            changePaymentResponseRecord.setToAccountCurrencyCode(payment.getCurrency());
            changePaymentResponseRecord.setTransactionCurrency(payment.getCurrency());
            return Observable.just(changePaymentResponseRecord);
        });
    }

    public void mockConfirmOneHouseholdPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(ConfirmPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            ConfirmPaymentResponseRecord confirmPaymentResponseRecord = new ConfirmPaymentResponseRecord();
            final com.nordea.dbf.payment.record.domestic.ConfirmPaymentResponsePaymentsSegment segment = confirmPaymentResponseRecord.addPayments();

            segment.setCounterValue(payment.getAmount().doubleValue());
            segment.setDateDeposit("");
            segment.setDateWithdrawal("");
            segment.setDueDate(payment.getDue().format(DateTimeFormatter.ISO_LOCAL_DATE));
            segment.setExchangeRate(1);
            segment.setGiroType(LegacyGiroType.convertToGiroType(AccountKey.fromString(payment.getTo()).getPrefix()));
            segment.setNewDate("");
            segment.setPaymentErrorType("");
            segment.setPaymentId(Long.parseLong(payment.getId()));
            segment.setPaymentStatus(LegacyPaymentStatus.fromPaymentStatusEnum(payment.getStatus()).code());

            return Observable.just(confirmPaymentResponseRecord);
        });
    }

    public void mockConfirmOneHouseholdCrossborderPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(ConfirmCrossBorderPaymentRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            ConfirmCrossBorderPaymentResponseRecord confirmPaymentResponseRecord = new ConfirmCrossBorderPaymentResponseRecord();
            confirmPaymentResponseRecord.setLegacyKey(payment.getId());
            return Observable.just(confirmPaymentResponseRecord);
        });
    }


    /**
     * E-invoices
     */

    public void mockListingOfNoEInvoicePayments() {
        when(m8ImsConnection.execute(isA(EInvoiceRequestRecord.class), any(Class.class))).thenAnswer(s ->
                Observable.empty());
    }

    public void mockRetrieveNoEInvoicePayment() {
        when(m8ImsConnection.execute(isA(EInvoiceRequestRecord.class), any(Class.class))).thenAnswer(s ->
                Observable.empty());
    }

    private EInvoiceResponseRecord configureGetEinvoiceResponseRecord(EInvoice eInvoice) {
        EInvoiceResponseRecord eInvoiceResponseRecord = new EInvoiceResponseRecord();
        EInvoiceResponseEInvoicesSegment segment = eInvoiceResponseRecord.addEInvoices();

        segment.setPaymentStatusCode(eInvoice.getPaymentStatusCode());
        segment.setPaymentId(eInvoice.getPaymentId());
        segment.setArrivalDate(eInvoice.getArrivalDate().format(LegacyEInvoice.ARRIVAL_DATE_FORMAT));
        segment.setInvoiceId(eInvoice.getInvoiceId());
        segment.setMessage(eInvoice.getMessage());
        segment.setOwnReference(eInvoice.getOwnReference());
        segment.setCurrency(eInvoice.getCurrency().getCurrencyCode());
        segment.setAmount(eInvoice.getAmount().doubleValue());
        segment.setDueDate(eInvoice.getDueDate().format(LegacyEInvoice.DUE_DATE_FORMAT));
        segment.setFromAccount(eInvoice.getFromAccount());
        segment.setGiroType(eInvoice.getGiroType());
        segment.setInvoicerId(eInvoice.getInvoicerId());
        segment.setInvoicerName(eInvoice.getInvoicerName());
        segment.setIsOcr(eInvoice.getIsOcr());
        segment.setMessage(eInvoice.getMessage());
        segment.setOwnCategory(eInvoice.getOwnCategory());
        segment.setToAccount(eInvoice.getToAccount());

        return eInvoiceResponseRecord;
    }

    public void mockRetrieveOneEInvoicePayment(EInvoice eInvoice) {
        when(m8ImsConnection.execute(isA(EInvoiceRequestRecord.class), any(Class.class))).thenAnswer(s ->
                Observable.just(configureGetEinvoiceResponseRecord(eInvoice)));
    }

    public void mockRetrieveNoEInvoiceWithKbearbKrc(int kbearb, int krc) {
        when(m8ImsConnection.execute(isA(EInvoiceRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            EInvoiceResponseRecord responseRecord = new EInvoiceResponseRecord();
            responseRecord.setKbearb(kbearb);
            responseRecord.setKrc(krc);
            return Observable.just(responseRecord);
        });
    }
}
