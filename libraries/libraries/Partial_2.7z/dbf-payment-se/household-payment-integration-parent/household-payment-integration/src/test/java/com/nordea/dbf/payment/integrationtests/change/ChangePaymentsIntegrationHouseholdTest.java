package com.nordea.dbf.payment.integrationtests.change;

import com.nordea.dbf.agreement.customer.se.model.*;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.HouseholdAbstractIntegrationTestBase;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.testdata.EInvoices;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class ChangePaymentsIntegrationHouseholdTest extends HouseholdAbstractIntegrationTestBase {

    @Test
    public void testIntegrationChangePgPayment() throws Exception {
        integrationChange(TestData.PG_ACCOUNT);
    }

    @Test
    public void testIntegrationChangeBgPayment() throws Exception {
        integrationChange(TestData.BG_ACCOUNT);
    }

    @Test
    public void testIntegrationChange3rdPartyTransfer() throws Exception {
        integrationChange(TestData.NORDEA_ACCOUNT_KEY);
    }

    private void integrationChange(final AccountKey accountKey) throws Exception {
        // when
        Payment originalPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey);
        originalPayment.setType(CommonPaymentType.fromPayment(originalPayment, false));
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey);
        payment.setId(originalPayment.getId());
        payment.setMessage("A new message");
        payment.setType(CommonPaymentType.fromPayment(payment, false));

        householdTestDataManager.mockListingOfNoEInvoicePayments();
        householdTestDataManager.mockCrossborderPaymentNotFound();
        householdTestDataManager.mockChangeOfOneHouseholdPayment(payment);
        householdTestDataManager.mockListingOfOneHouseholdPayment(payment);
        householdTestDataManager.mockRetrieveHouseholdPayment(payment);

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
        // given
        Payment changedPayment = householdPaymentFacade.changePayment(serviceData, payment, originalPayment).toBlocking().single();
        // then
        assertEquals(payment.getId(), changedPayment.getId());
        assertEquals(payment.getMessage(), changedPayment.getMessage());
        assertNotEquals(originalPayment.getMessage(), changedPayment.getMessage());
    }

    @Test
    public void testIntegrationChangeRecurringPgPayment() throws Exception {
        integrationChangeRecurring(TestData.PG_ACCOUNT, TestData.PAYMENT_RECURRING);
    }

    @Test
    public void testIntegrationChangeRecurringBgPayment() throws Exception {
        integrationChangeRecurring(TestData.BG_ACCOUNT, TestData.PAYMENT_RECURRING);
    }

    @Test
    public void testIntegrationChangeRecurring3rdPartyTransfer() throws Exception {
        integrationChangeRecurring(TestData.NORDEA_ACCOUNT_KEY, TestData.PAYMENT_RECURRING);
    }

    private void integrationChangeRecurring(final AccountKey accountKey, final PaymentRecurring recurring) throws Exception {
        // given
        Payment originalPayment = PaymentTestData.getUnconfirmedRecurringPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey, recurring);
        originalPayment.setType(CommonPaymentType.fromPayment(originalPayment, false));
        Payment payment = PaymentTestData.getUnconfirmedRecurringPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey, recurring);
        payment.setId(originalPayment.getId());
        payment.setMessage("A new changed message");
        payment.setType(CommonPaymentType.fromPayment(payment, false));

        householdTestDataManager.mockListingOfNoEInvoicePayments();
        householdTestDataManager.mockCrossborderPaymentNotFound();
        householdTestDataManager.mockChangeOfOneHouseholdPayment(payment);
        householdTestDataManager.mockListingOfOneHouseholdPayment(payment);
        householdTestDataManager.mockRetrieveHouseholdPayment(payment);

        // when
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        // given
        Payment changedPayment = householdPaymentFacade.changePayment(serviceData, payment, originalPayment).toBlocking().single();

        // then
        assertEquals(payment.getId(), changedPayment.getId());
        assertEquals(payment.getMessage(), changedPayment.getMessage());
        assertNotEquals(originalPayment.getMessage(), changedPayment.getMessage());
    }

    @Test
    public void eInvoiceCanBeChanged() {
        // given
        Payment originalEInvoicePayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.PG_ACCOUNT);
        originalEInvoicePayment.setType(Payment.TypeEnum.einvoice);

        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        payment.setType(Payment.TypeEnum.einvoice);

        EInvoice eInvoice = EInvoices.plusgiroInvoice1()
                .setInvoiceId(payment.getId())
                .setFromAccount(Long.parseLong(TestData.HOUSEHOLD_OWN_ACCOUNT.getAccountNumber().getAccountNumber()))
                .build();

        householdTestDataManager.mockRetrieveOneEInvoicePayment(eInvoice);
        householdTestDataManager.mockRetrieveHouseholdPayment(payment);

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
        // given

        // when
        Payment changedPayment = householdPaymentFacade.changePayment(serviceData, payment, originalEInvoicePayment).toBlocking().single();

        // then
        assertEquals(Payment.TypeEnum.bankgiro, changedPayment.getType());
        assertEquals(payment.getId(), changedPayment.getId());
    }
}
