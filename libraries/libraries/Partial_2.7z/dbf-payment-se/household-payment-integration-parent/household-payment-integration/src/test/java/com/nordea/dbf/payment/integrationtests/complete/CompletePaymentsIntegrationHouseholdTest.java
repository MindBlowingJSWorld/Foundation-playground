package com.nordea.dbf.payment.integrationtests.complete;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.converters.response.einvoice.EInvoiceToPaymentConverter;
import com.nordea.dbf.payment.integrationtests.HouseholdAbstractIntegrationTestBase;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.testdata.EInvoices;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by K306010 on 2016-02-09.
 */
public class CompletePaymentsIntegrationHouseholdTest extends HouseholdAbstractIntegrationTestBase {
    @Test
    public void shouldConfirmHouseholdPayment() {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        confirmedPayment.setId(unconfirmedPayment.getId());
        unconfirmedPayment.setType(CommonPaymentType.fromPayment(unconfirmedPayment, false));
        confirmedPayment.setType(CommonPaymentType.fromPayment(confirmedPayment, false));
        // given
        this.householdTestDataManager.mockRetrieveHouseholdPayment(confirmedPayment);
        this.householdTestDataManager.mockConfirmOneHouseholdPayment(unconfirmedPayment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        Payment paymentResult = this.householdPaymentFacade.completePayment(serviceData, unconfirmedPayment).toBlocking().single();

        // then
        assertEquals(paymentResult.getId(), unconfirmedPayment.getId());
        assertEquals(paymentResult.getStatus(), Payment.StatusEnum.confirmed);
    }

    @Test
    public void shouldConfirmHouseholdCrossBorderPayment() {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORWEGIAN_ACCOUNT_SEPA);
        Payment confirmedPayment = PaymentTestData.getConfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORWEGIAN_ACCOUNT_SEPA);
        confirmedPayment.setId(unconfirmedPayment.getId());
        unconfirmedPayment.setType(CommonPaymentType.fromPayment(unconfirmedPayment, false));
        confirmedPayment.setType(CommonPaymentType.fromPayment(confirmedPayment, false));
        // given
        this.householdTestDataManager.mockRetrieveHouseholdCrossborderPayment(confirmedPayment);
        this.householdTestDataManager.mockConfirmOneHouseholdCrossborderPayment(unconfirmedPayment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        Payment paymentResult = this.householdPaymentFacade.completePayment(serviceData, unconfirmedPayment).toBlocking().single();

        // then
        assertEquals(paymentResult.getId(), unconfirmedPayment.getId());
        assertEquals(paymentResult.getStatus(), Payment.StatusEnum.confirmed);
    }

    @Test
    public void shouldConfirmEInvoicePayment() {
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().setPaymentId(12345L).setPaymentStatusCode("BEV").build();
        EInvoiceToPaymentConverter eInvoiceToPaymentConverter = new EInvoiceToPaymentConverter();
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
        Payment eInvoicePayment = eInvoiceToPaymentConverter.convert(serviceData, eInvoice);
        eInvoicePayment.setType(Payment.TypeEnum.einvoice);

        // given
        this.householdTestDataManager.mockRetrieveOneEInvoicePayment(eInvoice);

        // when
        Payment paymentResult = this.householdPaymentFacade.completePayment(serviceData, eInvoicePayment).toBlocking().single();

        // then
        assertEquals(eInvoicePayment.getId(), paymentResult.getId());
        assertEquals(Payment.StatusEnum.confirmed, paymentResult.getStatus());
    }
}
