package com.nordea.dbf.payment.integrationtests.create;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.HouseholdAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class CreatePaymentsIntegrationHouseholdTest extends HouseholdAbstractIntegrationTestBase {

    @Test
    public void basicCrossBorderPaymentCanBeCreated() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORWEGIAN_ACCOUNT_SEPA);
        payment.setType(CommonPaymentType.fromPayment(payment, false));
        this.householdTestDataManager.mockCreateHouseholdCrossborderPayment(payment);
        // The details are retrieved upon success
        this.householdTestDataManager.mockRetrieveHouseholdCrossborderPayment(payment);

        // ID is not allowed in the request
        Payment paymentCreateRequest = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORWEGIAN_ACCOUNT_SEPA);
        paymentCreateRequest.setId(null);
        paymentCreateRequest.setType(CommonPaymentType.fromPayment(payment, false));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");
        // when
        Payment paymentResult = this.householdPaymentFacade.createPayment(serviceData, paymentCreateRequest).toBlocking().single();


        // then
        assertThat(paymentResult.getId()).isEqualTo(payment.getId());
        assertThat(paymentResult.getCrossBorder().getCentralBankReportingCode()).isEqualTo("461");
        assertThat(paymentResult.getCurrency()).isEqualTo(payment.getCurrency());
        assertThat(paymentResult.getFrom()).isEqualTo(TestData.HOUSEHOLD_OWN_ACCOUNT.toString());
        assertThat(paymentResult.getTo()).isEqualTo(TestData.NORWEGIAN_ACCOUNT_SEPA.toString());
        assertThat(paymentResult.getAmount()).isEqualByComparingTo(payment.getAmount());
    }

    @Test
    public void testIntegrationCreatePgPayment() throws Exception {
        integrationCreate(TestData.PG_ACCOUNT);
    }

    @Test
    public void testIntegrationCreateBgPayment() throws Exception {
        integrationCreate(TestData.BG_ACCOUNT);
    }

    @Test
    public void testIntegrationCreate3rdPartyTransfer() throws Exception {
        integrationCreate(TestData.NORDEA_ACCOUNT_KEY);
    }

    private void integrationCreate(final AccountKey accountKey) throws Exception {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey);
        payment.setType(CommonPaymentType.fromPayment(payment, false));
        this.householdTestDataManager.mockCreateHouseholdPayment(payment);
        // The details are retrieved upon success
        this.householdTestDataManager.mockRetrieveHouseholdPayment(payment);

        // ID is not allowed in the request
        Payment paymentCreateRequest = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey);
        paymentCreateRequest.setId(null);
        paymentCreateRequest.setType(CommonPaymentType.fromPayment(payment, false));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

        Payment paymentResult = this.householdPaymentFacade.createPayment(serviceData, paymentCreateRequest).toBlocking().single();

        // then
        assertThat(paymentResult.getId()).isEqualTo(payment.getId());
    }

    @Test
    public void testIntegrationCreateRecurringPgPayment() throws Exception {
        integrationCreateRecurring(TestData.PG_ACCOUNT, TestData.PAYMENT_RECURRING);
    }

    @Test
    public void testIntegrationCreateRecurringBgPayment() throws Exception {
        integrationCreateRecurring(TestData.BG_ACCOUNT, TestData.PAYMENT_RECURRING);
    }

    @Test
    public void testIntegrationCreateRecurring3rdPartyTransfer() throws Exception {
        integrationCreateRecurring(TestData.NORDEA_ACCOUNT_KEY, TestData.PAYMENT_RECURRING);
    }

    @Test
    public void testIntegrationCreateForEverRecurringPgPayment() throws Exception {
        integrationCreateRecurring(TestData.PG_ACCOUNT, TestData.PAYMENT_RECURRING_FOR_EVER);
    }

    @Test
    public void testIntegrationCreateForEverRecurringBgPayment() throws Exception {
        integrationCreateRecurring(TestData.BG_ACCOUNT, TestData.PAYMENT_RECURRING_FOR_EVER);
    }

    @Test
    public void testIntegrationCreateForEverRecurring3rdPartyTransfer() throws Exception {
        integrationCreateRecurring(TestData.NORDEA_ACCOUNT_KEY, TestData.PAYMENT_RECURRING_FOR_EVER);
    }

    private void integrationCreateRecurring(final AccountKey accountKey, final PaymentRecurring recurring) throws Exception {

        // given
        Payment payment = PaymentTestData.getUnconfirmedRecurringPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey, recurring);
        payment.setType(CommonPaymentType.fromPayment(payment, false));
        this.householdTestDataManager.mockCreateHouseholdPayment(payment);
        // The details are retrieved upon success
        this.householdTestDataManager.mockRetrieveHouseholdPayment(payment);

        // ID is not allowed in the request
        Payment paymentCreateRequest = PaymentTestData.getUnconfirmedRecurringPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, accountKey, recurring);
        paymentCreateRequest.setId(null);
        paymentCreateRequest.setType(CommonPaymentType.fromPayment(payment, false));
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");

        // when
        Payment paymentResult = this.householdPaymentFacade.createPayment(serviceData, paymentCreateRequest).toBlocking().single();

        // then
        assertThat(paymentResult.getId()).isEqualTo(payment.getId());
    }
    

}
