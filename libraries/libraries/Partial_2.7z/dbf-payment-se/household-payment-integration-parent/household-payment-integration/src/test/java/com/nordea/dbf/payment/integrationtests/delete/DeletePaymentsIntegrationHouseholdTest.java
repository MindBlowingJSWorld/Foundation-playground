package com.nordea.dbf.payment.integrationtests.delete;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.common.model.CommonPaymentType;
import com.nordea.dbf.payment.integrationtests.HouseholdAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.EInvoices;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by K306010 on 2016-02-08.
 */

public class DeletePaymentsIntegrationHouseholdTest extends HouseholdAbstractIntegrationTestBase {
    // TODO: What different types of failures / validations are provided by the backend and should be verified here?

    @Test
    public void unconfirmedHouseholdCrossborderPaymentCanBeDeleted() {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.CROSS_BORDER_ACCOUNT_KEY);
        unconfirmedPayment.setType(CommonPaymentType.fromPayment(unconfirmedPayment, false));
        // given
        this.householdTestDataManager.mockDeleteHouseholdCrossborderPayment(unconfirmedPayment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        final Payment payment = this.householdPaymentFacade.deletePayment(serviceData, unconfirmedPayment).toBlocking().single();

        assertEquals(payment.getId(), unconfirmedPayment.getId());
        assertEquals(payment.getStatus(), unconfirmedPayment.getStatus());
        assertEquals(payment.getDue(), unconfirmedPayment.getDue());
    }

    @Test
    public void unconfirmedHouseholdPaymentCanBeDeleted() {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        unconfirmedPayment.setType(CommonPaymentType.fromPayment(unconfirmedPayment, false));
        // given
        this.householdTestDataManager.mockDeleteHouseholdPayment(unconfirmedPayment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");


        final Payment payment = this.householdPaymentFacade.deletePayment(serviceData, unconfirmedPayment).toBlocking().single();

        // then
        assertEquals(payment.getId(), unconfirmedPayment.getId());
        assertEquals(payment.getStatus(), unconfirmedPayment.getStatus());
        assertEquals(payment.getDue(), unconfirmedPayment.getDue());
    }

    @Test
    public void unconfirmedEInvoicePaymentCanBeDeleted() {
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().build();
        // given
        this.householdTestDataManager.mockRetrieveOneEInvoicePayment(eInvoice);
        Payment paymentId = new Payment();
        paymentId.setType(Payment.TypeEnum.einvoice);
        paymentId.setId(String.valueOf(eInvoice.getPaymentId()));

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");


        final Payment payment = this.householdPaymentFacade.deletePayment(serviceData, paymentId).toBlocking().single();

        // then
        assertEquals(payment.getId(), paymentId.getId());
    }
}
