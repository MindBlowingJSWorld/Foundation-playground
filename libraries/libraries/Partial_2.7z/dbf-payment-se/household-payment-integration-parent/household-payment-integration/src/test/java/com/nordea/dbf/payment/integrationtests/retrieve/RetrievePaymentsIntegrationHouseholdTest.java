package com.nordea.dbf.payment.integrationtests.retrieve;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.filter.DateFilter;
import com.nordea.dbf.filter.ListFilter;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.http.errorhandling.exception.UnauthorizedException;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.HouseholdAbstractIntegrationTestBase;
import com.nordea.dbf.payment.model.EInvoice;
import com.nordea.dbf.payment.testdata.EInvoices;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;
import rx.Observable;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertEquals;

public class RetrievePaymentsIntegrationHouseholdTest extends HouseholdAbstractIntegrationTestBase {

    @Test
    public void unconfirmedPaymentsCanBeRetrieved() {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        // given
        this.householdTestDataManager.mockListingOfNoEInvoicePayments();
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockListingOfOneHouseholdPayment(unconfirmedPayment);
        this.householdTestDataManager.mockRetrieveHouseholdPayment(unconfirmedPayment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertEquals(1, payments.size());

        final Payment payment = payments.get(0);
        assertEquals(payment.getId(), unconfirmedPayment.getId());
        assertEquals(payment.getStatus(), unconfirmedPayment.getStatus());
        assertEquals(payment.getDue(), unconfirmedPayment.getDue());
    }

    @Test
    public void unconfirmedPaymentsInDateRangeCanBeRetrieved() {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);

        // given
        this.householdTestDataManager.mockListingOfNoEInvoicePayments();
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockListingOfOneHouseholdPayment(unconfirmedPayment);
        this.householdTestDataManager.mockRetrieveHouseholdPayment(unconfirmedPayment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        //FIXME: User java.time.Clock to not have constants rely on each other in different places
        paymentFilter.setDueDate(DateFilter.between(unconfirmedPayment.getDue().minusDays(6), unconfirmedPayment.getDue().plusDays(1)));
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();
        // then

        assertEquals(payments.size(), 1);

        final Payment payment = payments.get(0);
        assertEquals(payment.getId(), unconfirmedPayment.getId());
        assertEquals(payment.getStatus(), unconfirmedPayment.getStatus());
        assertEquals(payment.getDue(), unconfirmedPayment.getDue());
    }

    @Test
    public void unconfirmedPaymentsOutsideDateRangeWontBeRetrieved() {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);

        // given
        this.householdTestDataManager.mockListingOfNoEInvoicePayments();
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockListingOfOneHouseholdPayment(unconfirmedPayment);
        this.householdTestDataManager.mockRetrieveHouseholdPayment(unconfirmedPayment);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        paymentFilter.setDueDate(DateFilter.between(unconfirmedPayment.getDue().plusDays(1), unconfirmedPayment.getDue().plusDays(2)));
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();
        // then

        assertEquals(payments.size(), 0);
    }

    @Test
    public void paymentsForMultipleStatusesCanBeRetrieved() throws Exception {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        this.householdTestDataManager.mockListingOfNoEInvoicePayments();
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockListingOfHouseholdPayments(unconfirmedPayment, confirmedPayment);
        this.householdTestDataManager.mockRetrieveHouseholdPayments(unconfirmedPayment, confirmedPayment);

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertEquals(2, payments.size());
    }

    @Test
    public void paymentsForMultipleStatusesCanBeRetrievedAndFiltered() throws Exception {
        Payment unconfirmedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        Payment confirmedPayment = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        Payment rejectedPayment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.BG_ACCOUNT);
        rejectedPayment.setStatus(Payment.StatusEnum.rejected);

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        this.householdTestDataManager.mockListingOfNoEInvoicePayments();
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockListingOfHouseholdPayments(unconfirmedPayment, confirmedPayment, rejectedPayment);
        this.householdTestDataManager.mockRetrieveHouseholdPayments(unconfirmedPayment, confirmedPayment, rejectedPayment);

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        paymentFilter.setStatuses(Arrays.asList("unconfirmed", "confirmed"));
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertEquals(2, payments.size());
    }

    @Test
    public void allEInvoicesCanBeRetrieved() {
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockListingOfNoHouseholdPayments();
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().setFromAccount(Long.valueOf(TestData.HOUSEHOLD_OWN_ACCOUNT.getAccountNumber().getAccountNumber())).build();

        this.householdTestDataManager.mockRetrieveOneEInvoicePayment(eInvoice);

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        // When
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertEquals(payments.size(), 1);

        final Payment payment = payments.get(0);

        assertEquals(payment.getId(), eInvoice.getInvoiceId());
    }

    @Test
    public void eInvoicesCanBeListedAsUnconfirmedPayment() {
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().setFromAccount(Long.valueOf(TestData.HOUSEHOLD_OWN_ACCOUNT.getAccountNumber().getAccountNumber())).build();
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        // given
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockListingOfNoHouseholdPayments();

        this.householdTestDataManager.mockRetrieveOneEInvoicePayment(eInvoice);

        // When
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        paymentFilter.setStatuses(Arrays.asList("unconfirmed"));
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertEquals(payments.size(), 1);

        final Payment payment = payments.get(0);

        assertEquals(payment.getId(), eInvoice.getInvoiceId());
    }

    @Test
    public void eInvoicesWillBeFilteredAsUnconfirmedPayment() {
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().setFromAccount(Long.valueOf(TestData.HOUSEHOLD_OWN_ACCOUNT.getAccountNumber().getAccountNumber())).build();

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        // given
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockListingOfNoHouseholdPayments();

        this.householdTestDataManager.mockRetrieveOneEInvoicePayment(eInvoice);

        // When
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        paymentFilter.setStatuses(Arrays.asList("confirmed"));
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertEquals(payments.size(), 0);
    }

    @Test
    public void paymentCanBeQueriedByIdWhenNotMatchingEInvoice() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        this.householdTestDataManager.mockRetrieveNoEInvoicePayment();
        // When the ID is specified, the payment details is queried directly for crossborder.
        this.householdTestDataManager.mockRetrieveNoCrossborderHouseholdPayment();
        this.householdTestDataManager.mockListingOfOneHouseholdPayment(payment);
        this.householdTestDataManager.mockRetrieveHouseholdPayment(payment);

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        paymentFilter.setPaymentId(payment.getId());
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertEquals(payments.size(), 1);

        Payment resultPayment = payments.get(0);
        assertEquals(resultPayment.getId(), payment.getId());
    }

    @Test
    public void paymentsWillBeEmptyWhenNoMatchOnId() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        EInvoice eInvoice = EInvoices.plusgiroInvoice1().setFromAccount(Long.valueOf(TestData.HOUSEHOLD_OWN_ACCOUNT.getAccountNumber().getAccountNumber())).build();

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");


        this.householdTestDataManager.mockRetrieveOneEInvoicePayment(eInvoice);
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockRetrieveNoCrossborderHouseholdPayment();
        this.householdTestDataManager.mockListingOfOneHouseholdPayment(payment);
        this.householdTestDataManager.mockRetrieveHouseholdPayment(payment);

        // when
        PaymentFilter paymentFilter = new PaymentFilter();
        paymentFilter.setFromAccounts(new ListFilter(Arrays.asList(TestData.HOUSEHOLD_OWN_ACCOUNT)));
        paymentFilter.setPaymentId("123");
        List<Payment> payments = this.householdPaymentFacade.getPayments(serviceData, paymentFilter).toBlocking().single();

        // then
        assertEquals(payments.size(), 0);
    }

    @Test
    public void getEInvoiceShouldReturnEmptyObservableIfNoEInvoiceExists() {
        //given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.einvoice);
        this.householdTestDataManager.mockRetrieveNoEInvoiceWithKbearbKrc(4, 5);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        Observable<Payment> paymentObservable = this.householdPaymentFacade.getPayment(serviceData,
                payment
        );

        assertThatThrownBy(() -> paymentObservable.isEmpty().toBlocking().single()).isInstanceOf(NotFoundException.class);
    }

    @Test
    public void getEInvoicesShouldFailIfErrorIsReturned() {
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);
        payment.setType(Payment.TypeEnum.einvoice);
        this.householdTestDataManager.mockRetrieveNoEInvoiceWithKbearbKrc(4, 8);

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");

        Observable<Payment> paymentObservable = this.householdPaymentFacade.getPayment(serviceData,
                payment
        );

        assertThatThrownBy(() -> paymentObservable.toBlocking().single()).isInstanceOf(UnauthorizedException.class);
    }
}
