package com.nordea.dbf.payment.integrationtests.retrieve.details;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.HouseholdAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertEquals;


/**
 * Created by K306010 on 2016-02-09.
 */
public class RetrievePaymentDetailsIntegrationHouseholdTest extends HouseholdAbstractIntegrationTestBase {

    @Test
    public void shouldThrownNotFoundExceptionWhenPaymentNotFound() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORDEA_ACCOUNT_KEY);

        this.householdTestDataManager.mockListingOfNoEInvoicePayments();
        this.householdTestDataManager.mockRetrieveNoEInvoicePayment();
        this.householdTestDataManager.mockListingOfNoCrossborderPayments();
        this.householdTestDataManager.mockRetrieveNoCrossborderHouseholdPayment();
        this.householdTestDataManager.mockListingOfOneHouseholdPayment(payment);
        this.householdTestDataManager.mockRetrieveHouseholdPayment(payment);

        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
        Payment paymentId = new Payment();
        paymentId.setId("132");

        // when
        paymentId.setType(Payment.TypeEnum.einvoice);
        // then
        assertThatThrownBy(() -> this.householdPaymentFacade.getPayment(serviceData, paymentId).toBlocking().single()).isInstanceOf(NotFoundException.class);

        // when
        paymentId.setType(Payment.TypeEnum.crossborder);
        // then
        assertThatThrownBy(() -> this.householdPaymentFacade.getPayment(serviceData, paymentId).toBlocking().single()).isInstanceOf(NotFoundException.class);

        // when
        paymentId.setType(Payment.TypeEnum.plusgiro);
        // Domestic require further details for a lookup
        paymentId.setFrom(TestData.HOUSEHOLD_OWN_ACCOUNT.toString());
        paymentId.setStatus(Payment.StatusEnum.unconfirmed);
        // then
        assertThatThrownBy(() -> this.householdPaymentFacade.getPayment(serviceData, paymentId).toBlocking().single()).isInstanceOf(NotFoundException.class);

    }

    @Test
    public void crossBorderPaymentDetailsCanBeRetrievedForHouseholdUser() {
        // given
        Payment payment = PaymentTestData.getUnconfirmedCrossborderPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.NORWEGIAN_ACCOUNT_SEPA);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_USER_ID, "household");
        payment.setType(Payment.TypeEnum.crossborder);
        // Domestic require further details for a lookup
        payment.setFrom(TestData.HOUSEHOLD_OWN_ACCOUNT.toString());
        payment.setStatus(Payment.StatusEnum.unconfirmed);

        this.householdTestDataManager.mockListingOfNoHouseholdPayments();
        this.householdTestDataManager.mockListingOfNoEInvoicePayments();
        this.householdTestDataManager.mockRetrieveHouseholdCrossborderPayment(payment);

        // when
        Payment paymentResult = this.householdPaymentFacade.getPayment(serviceData, payment).toBlocking().single();

        // then
        assertEquals(paymentResult.getId(), payment.getId());
    }
}
