package com.nordea.dbf.payment;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.messaging.Observables;
import com.nordea.dbf.payment.common.PaymentFacade;
import com.nordea.dbf.payment.common.PaymentFilter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integration.OwnTransferIntegration;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.util.List;

public class OwnTransferFacade implements PaymentFacade {
    @Autowired
    private OwnTransferIntegration ownTransferIntegration;

    @Autowired
    private M8ImsConnector m8ImsConnector;

    @Override
    public Observable<Payment> createPayment(ServiceData serviceData, Payment payment) {
        M8ImsConnection connection = m8ImsConnector.connect();
        return Observables.manage(connection).on(ownTransferIntegration.createPayment(connection, serviceData, payment));
    }

    @Override
    public Observable<Payment> changePayment(ServiceData serviceData, Payment payment, Payment originalPayment) {
        return Observable.error(new RuntimeException("Change payment not supported for own transfers."));
    }

    @Override
    public Observable<Payment> deletePayment(ServiceData serviceData, Payment payment) {
        return Observable.error(new RuntimeException("Delete payment not supported for own transfers."));
    }

    @Override
    public Observable<Payment> completePayment(ServiceData serviceData, Payment payment) {
        return Observable.error(new RuntimeException("Confirm payment not supported for own transfers."));
    }

    @Override
    public Observable<List<Payment>> getPayments(ServiceData serviceData, PaymentFilter paymentFilter) {
        return Observable.error(new RuntimeException("Get payments not supported for own transfers."));
    }

    @Override
    public Observable<Payment> getPayment(ServiceData serviceData, Payment payment) {
        return Observable.error(new RuntimeException("Get payment not supported for own transfers."));
    }
}
