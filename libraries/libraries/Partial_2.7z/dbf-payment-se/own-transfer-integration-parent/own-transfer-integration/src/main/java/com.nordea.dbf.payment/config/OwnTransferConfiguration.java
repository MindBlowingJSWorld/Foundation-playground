package com.nordea.dbf.payment.config;

import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.integration.connect.ims.Configurations;
import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.dbf.integration.connect.ims.jca.JCAConnectionSupplier;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnectorImpl;
import com.nordea.dbf.payment.common.converters.BackendErrorCode;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.util.M8RequestResponseWrapper;
import com.nordea.dbf.payment.integration.OwnTransferIntegration;
import com.nordea.sc.jca.BackendInteractionSpec;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import com.nordea.serviceconsumer.providers.JCAConnectionProvider;
import com.nordea.serviceconsumer.providers.defaults.JCAConnectionProviderImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.Arrays;
import java.util.Optional;

@Configuration
public class OwnTransferConfiguration {

    @Autowired
    private Environment environment;

    @Bean
    @Qualifier("ownTransferErrorHandler")
    public BackendErrorHandler ownTransferErrorHandler() {
        return new BackendErrorHandler() {
            @Override
            public <T extends ErrorResponse> Optional<T> exceptionOf(int kbearb, int krc) {
                if (kbearb < 1 && krc < 1) {
                    return Optional.empty();
                }
                return Optional.of(((T) BackendErrorCode.getException(kbearb, krc)));
            }
        };
    }

    @Bean
    public M8RequestResponseWrapper m8RequestResponseWrapper() {
        return new M8RequestResponseWrapper();
    }

    @Bean
    public JCAConnectionProvider jcaConnectionProvider() {
        return new JCAConnectionProviderImpl();
    }

    @Bean
    @Autowired
    public JCAConnectionSupplier jcaConnectionSupplier(JCAConnectionProvider jcaConnectionProvider) {
        return () -> jcaConnectionProvider.getConnection(configurationProvider());
    }

    @Bean
    @Autowired
    public M8ImsConnector m8BackendConnection(JCAConnectionSupplier jcaConnectionSupplier, ImsConfigurationSupplier imsConfigurationSupplier) {
        return new M8ImsConnectorImpl(jcaConnectionSupplier, imsConfigurationSupplier);
    }

    @Bean
    public ImsConfigurationSupplier imsConfigurationSupplier() {
        final boolean debug = Arrays.asList(environment.getActiveProfiles()).contains("debug");

        final ImsConfiguration.Builder baseConfiguration = ImsConfiguration.builder()
                .serverIdentifier("seims")
                .debugLog(Boolean.valueOf(configurationProvider().getProperty("jca.debug", String.valueOf(debug))));

        return Configurations.builder()
                .when((req, res) -> Configurations.transactionCodeOf(req).startsWith("ESM")).then(baseConfiguration
                        .backendType(BackendInteractionSpec.BackendType.TYPE_IMS_SE)
                        .build())
                .when((req, res) -> Configurations.transactionCodeOf(req).startsWith("ESC")).then(baseConfiguration
                        .backendType(BackendInteractionSpec.BackendType.TYPE_IMS_SE)
                        .build())
                .when((req, res) -> true).then(baseConfiguration
                        .backendType(BackendInteractionSpec.BackendType.TYPE_GENERIC)
                        .build())
                .build();
    }

    @Bean
    public ConfigurationProvider configurationProvider() {
        return new ConfigurationProvider() {
            @Override
            public String getProperty(String key, String defaultValue) {
                return environment.getProperty(key, defaultValue);
            }

            @Override
            public String getProperty(String key) {
                return environment.getProperty(key);
            }
        };
    }

    @Bean
    public OwnTransferIntegration ownTransferIntegration() {
        return new OwnTransferIntegration();
    }

    @Bean
    public NilRequestMsgHeaders nilRequestMsgHeaders() {
        return new NilRequestMsgHeaders();
    }
}

