package com.nordea.dbf.payment.converters.request;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.model.NilRequestMsgHeaders;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.model.OwnTransfer;
import com.nordea.dbf.payment.record.owntransfer.CreateTransferRequestRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PaymentToCreateTransferRequest implements Converter<Payment, CreateTransferRequestRecord> {

    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    @Autowired
    public PaymentToCreateTransferRequest(NilRequestMsgHeaders nilRequestMsgHeaders) {
        this.nilRequestMsgHeaders = nilRequestMsgHeaders;
    }

    @Override
    public CreateTransferRequestRecord convert(ServiceData serviceData, Payment payment) {
        final CreateTransferRequestRecord requestRecord = nilRequestMsgHeaders.withHeaderConfiguration(serviceData.getServiceRequestContext(), new CreateTransferRequestRecord());
        requestRecord.setTransactionCode("INLP062");

        final AccountKey fromAccountKey = AccountKey.fromString(payment.getFrom());
        final AccountKey toAccountKey = AccountKey.fromString(payment.getTo());

        requestRecord.setAgreementNumber(serviceData.getAgreement());
        requestRecord.setCustomerId(Long.parseLong(serviceData.getUserId()));

        // TODO: Where did "E" come from?
        requestRecord.setFuncCode("E");
        requestRecord.setAmount(payment.getAmount().doubleValue());
        if (payment.getDue() != null) {
            requestRecord.setDueDate(OwnTransfer.DATE_FORMAT.format(payment.getDue()));
        } else {
            // FIXME: Should this be defaulted to today's date?
        }
        requestRecord.setOwnMessage(payment.getMessage());
        requestRecord.setFromAccount(Long.parseLong(fromAccountKey.getAccountNumber().getAccountNumber()));
        requestRecord.setFromAccountCurrencyCode(fromAccountKey.getCurrencyCode().orElse(null));
        requestRecord.setToAccount(Long.parseLong(toAccountKey.getAccountNumber().toString()));
        requestRecord.setToAccountCurrencyCode(toAccountKey.getCurrencyCode().orElse(null));
        requestRecord.setTransactionCurrency(payment.getCurrency());

        return requestRecord;
    }
}
