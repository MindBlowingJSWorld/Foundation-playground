package com.nordea.dbf.payment.converters.response;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.common.converters.LegacyAccountKeyConverter;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.record.owntransfer.TransferResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
public class TransferResponseToPayment implements ResponseConverter<TransferResponseRecord, Payment> {

    @Autowired
    @Qualifier("ownTransferErrorHandler")
    private BackendErrorHandler errorHandler;

    @Override
    public void errorHandler(int kbearb, int krc) {
        errorHandler.check(kbearb, krc);
    }

    @Override
    public Payment responseConvert(ServiceData serviceData, TransferResponseRecord response) {
        Payment payment = new Payment();
        
        payment.setAmount(BigDecimal.valueOf(response.getAmount()));
        payment.setCurrency(response.getTransactionCurrency());
        payment.setDue(LocalDate.parse(response.getDueDate(), DateTimeFormatter.ISO_LOCAL_DATE));
        payment.setFrom(LegacyAccountKeyConverter.accountKeyOf("NA", response.getFromAccount(), response.getTransactionCurrency()));
        payment.setId(String.valueOf(response.getPaymentId()));
        payment.setMessage(response.getOwnMessage());
        payment.setStatus(LegacyPaymentStatus.fromCode(response.getPaymentStatus()).asPaymentStatus());
        payment.setTo(LegacyAccountKeyConverter.accountKeyOf("NA", response.getToAccount(), response.getTransactionCurrency()));
        payment.setType(Payment.TypeEnum.owntransfer);

        return payment;
    }
}
