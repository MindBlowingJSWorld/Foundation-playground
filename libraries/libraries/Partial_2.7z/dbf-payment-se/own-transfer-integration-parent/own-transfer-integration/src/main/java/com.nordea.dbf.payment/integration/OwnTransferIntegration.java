package com.nordea.dbf.payment.integration;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.common.util.M8RequestResponseWrapper;
import com.nordea.dbf.payment.converters.request.PaymentToCreateTransferRequest;
import com.nordea.dbf.payment.converters.response.TransferResponseToPayment;
import com.nordea.dbf.payment.record.owntransfer.CreateTransferRequestRecord;
import com.nordea.dbf.payment.record.owntransfer.TransferResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

/**
 * This class is not really required, but added to have a consistent layout for all integrations.
 */
public class OwnTransferIntegration {
    @Autowired
    private M8RequestResponseWrapper m8RequestResponseWrapper;

    // Converters below
    @Autowired
    private PaymentToCreateTransferRequest paymentToCreateTransferRequest;
    @Autowired
    private TransferResponseToPayment transferResponseToPayment;

    @HystrixCommand(groupKey = "JCA", commandKey = "createOwnTransferPayment")
    public Observable<Payment> createPayment(M8ImsConnection connection, ServiceData serviceData, Payment payment) {
        return m8RequestResponseWrapper.requestResponseWrapper(connection, payment, serviceData, paymentToCreateTransferRequest, transferResponseToPayment);
    }
}
