package com.nordea.dbf.payment.model;

import java.time.format.DateTimeFormatter;

public class OwnTransfer {

    public static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;
}
