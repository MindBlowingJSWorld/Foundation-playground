package com.nordea.dbf.payment.config;

import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.payment.OwnTransferFacade;
import com.nordea.dbf.payment.common.PaymentFacade;
import com.nordea.dbf.payment.integrationtests.OwnTransferTestDataManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by K306010 on 2016-03-18.
 */
@Configuration
@ComponentScan(basePackages = "com.nordea.dbf.payment", excludeFilters = @ComponentScan.Filter(type = FilterType.ANNOTATION, value = Configuration.class))
public class OwnTransferTestConfiguration {
    @Bean
    @Qualifier("ownTransferErrorHandler")
    public BackendErrorHandler ownTransferErrorHandler() {
        return mock(BackendErrorHandler.class);
    }

    @Bean
    @Primary
    @Qualifier("ownTransferPaymentFacade")
    public PaymentFacade ownTransferPaymentFacade() {
        return new OwnTransferFacade();
    }


    @Bean
    @Autowired
    @Primary
    public M8ImsConnector m8ImsConnector(M8ImsConnection m8ImsConnection) {
        M8ImsConnector m8ImsConnector = mock(M8ImsConnector.class);
        when(m8ImsConnector.connect()).thenReturn(m8ImsConnection);
        return m8ImsConnector;
    }

    @Bean
    @Primary
    public M8ImsConnection m8ImsConnection() {
        return mock(M8ImsConnection.class);
    }

    @Bean
    public OwnTransferTestDataManager ownTransferTestDataManager() {
        return new OwnTransferTestDataManager();
    }
}
