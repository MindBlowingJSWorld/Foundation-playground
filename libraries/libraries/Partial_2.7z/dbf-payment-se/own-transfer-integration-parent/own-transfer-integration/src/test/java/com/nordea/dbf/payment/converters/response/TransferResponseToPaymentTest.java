package com.nordea.dbf.payment.converters.response;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.integration.config.BackendErrorHandler;
import com.nordea.dbf.payment.record.owntransfer.TransferResponseRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;


@RunWith(MockitoJUnitRunner.class)
public class TransferResponseToPaymentTest {

    @Mock
    public BackendErrorHandler errorHandler = mock(BackendErrorHandler.class);

    @InjectMocks
    private TransferResponseToPayment transferResponseToPayment = new TransferResponseToPayment();


    @Test
    public void fromTransferResponseRecord() {
        // given
        TransferResponseRecord given = new TransferResponseRecord();
        given.initialize();
        given.setAmount(1);
        given.setCounterValue(2);
        given.setCustomerId(3);
        given.setDateDeposit("newDateDeposit");
        given.setDateWithdrawal("newDateWithdrawal");
        given.setDueDate("2015-01-01");
        given.setDuplicateExist("newDuplicateExist");
        given.setExchangeRate(4);
        given.setFromAccount(5);
        given.setNewDate("newNewDate");
        given.setOwnMessage("newOwnMessage");
        given.setPaymentId(6);
        given.setPaymentStatus("NCF");
        given.setToAccount(7);
        given.setTransactionCurrency("SEK");

        Payment expected = new Payment();
        expected.setAmount(new BigDecimal("1.0"));
        expected.setCurrency("SEK");
        expected.setDue(LocalDate.parse("2015-01-01", DateTimeFormatter.ISO_LOCAL_DATE));
        expected.setFrom("NAID-SE-SEK-5");
        expected.setId(String.valueOf(6));
        expected.setMessage("newOwnMessage");
        expected.setStatus(Payment.StatusEnum.unconfirmed);
        expected.setTo("NAID-SE-SEK-7");
        expected.setType(Payment.TypeEnum.owntransfer);

        // when
        Payment payment = transferResponseToPayment.convert(null, given);

        // then
        assertThat(payment).isEqualTo(expected);
    }

    @Test
    public void exampleTransferResponseCanBeConvertedToPayment() {
        final TransferResponseRecord responseRecord = new TransferResponseRecord();

        responseRecord.initialize();
        responseRecord.setCustomerId(194008010011L);
        responseRecord.setPaymentId(1460958717242L);
        responseRecord.setToAccount(32580077936L);
        responseRecord.setFromAccount(32581014679L);
        responseRecord.setAmount(1.0);
        responseRecord.setDueDate("2015-05-26");
        responseRecord.setTransactionCurrency("SEK");
        responseRecord.setPaymentStatus("UTF");
        responseRecord.setExchangeRate(0.0);
        responseRecord.setDateDeposit("20150526");
        responseRecord.setDateWithdrawal("20150526");

        final Payment payment = transferResponseToPayment.convert(null, responseRecord);

        assertThat(payment.getId()).isEqualTo("1460958717242");
        assertThat(payment.getTo()).isEqualTo("NAID-SE-SEK-32580077936");
        assertThat(payment.getFrom()).isEqualTo("NAID-SE-SEK-32581014679");
        assertThat(payment.getAmount()).isEqualTo(new BigDecimal("1.0"));
        assertThat(payment.getDue()).isEqualTo(LocalDate.parse("2015-05-26"));
        assertThat(payment.getCurrency()).isEqualTo("SEK");
        assertThat(payment.getStatus()).isEqualTo(Payment.StatusEnum.paid);
        assertThat(payment.getType()).isEqualTo(Payment.TypeEnum.owntransfer);
    }

}
