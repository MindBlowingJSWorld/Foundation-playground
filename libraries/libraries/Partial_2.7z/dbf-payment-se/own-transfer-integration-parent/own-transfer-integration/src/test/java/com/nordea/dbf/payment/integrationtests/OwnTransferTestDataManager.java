package com.nordea.dbf.payment.integrationtests;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.payment.common.model.LegacyPaymentStatus;
import com.nordea.dbf.payment.record.owntransfer.CreateTransferRequestRecord;
import com.nordea.dbf.payment.record.owntransfer.TransferResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.time.format.DateTimeFormatter;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

/**
 * Created by K306010 on 2016-03-18.
 */
public class OwnTransferTestDataManager {
    @Autowired
    private M8ImsConnection m8ImsConnection;

    public void mockCreateOwnTransferPayment(Payment payment) {
        when(m8ImsConnection.execute(isA(CreateTransferRequestRecord.class), any(Class.class))).thenAnswer(s -> {
            TransferResponseRecord transferResponseRecord = new TransferResponseRecord();
            transferResponseRecord.setPaymentId(Long.valueOf(payment.getId()));
            transferResponseRecord.setAmount(payment.getAmount().doubleValue());
            transferResponseRecord.setTransactionCurrency(payment.getCurrency());
            transferResponseRecord.setDueDate(payment.getDue().format(DateTimeFormatter.ISO_LOCAL_DATE));
            transferResponseRecord.setMessageId(payment.getMessage());
            transferResponseRecord.setPaymentStatus(LegacyPaymentStatus.UNCONFIRMED.code());
            transferResponseRecord.setToAccount(Long.valueOf(AccountKey.fromString(payment.getTo()).getAccountNumber().getAccountNumber()));
            transferResponseRecord.setFromAccount(Long.valueOf(AccountKey.fromString(payment.getFrom()).getAccountNumber().getAccountNumber()));

            return Observable.just(transferResponseRecord);
        });
    }
}
