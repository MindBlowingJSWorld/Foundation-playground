package com.nordea.dbf.payment.integrationtests.create;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.dbf.payment.integrationtests.OwnTransferAbstractIntegrationTestBase;
import com.nordea.dbf.payment.testdata.PaymentTestData;
import com.nordea.dbf.payment.testdata.TestData;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CreatePaymentsIntegrationOwnTransferTest extends OwnTransferAbstractIntegrationTestBase {
    @Test
    public void ownTransferCanBeCreatedBetweenUserAccounts() throws Exception {
        Payment payment = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.CORPORATE_OWN_ACCOUNT);
        this.ownTransferTestDataManager.mockCreateOwnTransferPayment(payment);


        Payment paymentRequest = PaymentTestData.getConfirmedPayment(TestData.HOUSEHOLD_OWN_ACCOUNT, TestData.CORPORATE_OWN_ACCOUNT);
        paymentRequest.setId(null);
        ServiceRequestContext serviceRequestContext = getServiceRequestContext(TestData.HOUSEHOLD_USER_ID, TestData.HOUSEHOLD_AGREEMENT_ID);
        ServiceData serviceData = new ServiceData(serviceRequestContext, TestData.HOUSEHOLD_USER_ID, "123", "household");
        Payment paymentResult = this.ownTransferPaymentFacade.createPayment(serviceData, paymentRequest).toBlocking().single();

        assertEquals(paymentResult.getId(), payment.getId());

    }
}
