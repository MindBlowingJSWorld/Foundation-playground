package com.nordea.dbf.payment.common;

import com.nordea.dbf.agreement.customer.se.model.Agreement;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.InternalServerErrorException;
import com.nordea.dbf.payment.common.model.ServiceData;
import rx.Observable;

import java.util.List;

public interface PaymentFacade {
    /**
     * Creates the payment according to the user input.
     *
     */
    Observable<Payment> createPayment(ServiceData serviceData, Payment payment);

    /**
     * Changes the payment according to the user input.
     * If the change only affects the status, this can initiate the confirmation/signing process.
     *
     */
    Observable<Payment> changePayment(ServiceData serviceData, Payment payment, Payment originalPayment);

    /**
     * Deletes the payment if it exists.
     *
     */
    Observable<Payment> deletePayment(ServiceData serviceData, Payment payment);

    /**
     * Finalize the confirmation flow based upon a successful signature from the user
     *
     */
    Observable<Payment> completePayment(ServiceData serviceData, Payment payment);

    /**
     * Lists the payments based on the supplied PaymentFilter and user.
     * The payment filter is expected to contain the relevant authorized accounts as a minimum.
     *
     */
    Observable<List<Payment>> getPayments(ServiceData serviceData, PaymentFilter paymentFilter);

    /**
     * Request for a specific payment based on ID.
     *
     */
    Observable<Payment> getPayment(ServiceData serviceData, Payment payment);
}
