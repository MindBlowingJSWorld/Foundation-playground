package com.nordea.dbf.payment.common;

import com.nordea.dbf.agreement.customer.se.model.Agreement;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.filter.DateFilter;
import com.nordea.dbf.filter.EqualityFilter;
import com.nordea.dbf.filter.Filter;
import com.nordea.dbf.filter.ListFilter;
import rx.functions.Func1;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * A shared class for payment filtering
 *
 * TODO: Make more generic, utilizing the PaymentFilterType better.
 *
 */
public class PaymentFilter {
    private Map<PaymentFilterType, Filter> paymentFiltersMap;

    private ListFilter<Payment.StatusEnum> statuses;
    private ListFilter<String> risks;
    private DateFilter dueDate;
    private ListFilter<AccountKey> fromAccounts;
    private EqualityFilter<String> paymentId;
    private ListFilter<Payment.TypeEnum> paymentTypes;

    public PaymentFilter() {
        paymentFiltersMap = new HashMap<>();
    }

    public Set<PaymentFilterType> getPaymentFilterTypes() {
        return paymentFiltersMap.keySet();
    }

    public List<Payment.StatusEnum> getStatuses() {
        return statuses.getValues();
    }

    public void setStatuses(List<String> statusStrings) {
        List<Payment.StatusEnum> statusList = new ArrayList<>();
        if (statusStrings != null) {
            statusStrings.forEach(s -> {
                Payment.StatusEnum status = Payment.StatusEnum.valueOf(s);
                switch (status) {
                    case unconfirmed:
                    case confirmed:
                    case rejected:
                    case stopped:
                    case inprogress:
                        statusList.add(status);
                        break;
                    default:
                        throw new IllegalArgumentException("Payment status not supported: " + s);
                }
            });
            this.statuses = new ListFilter<>(statusList);

            paymentFiltersMap.put(PaymentFilterType.STATUS, this.statuses);
        }
    }

    public List<String> getRisks() {
        return risks.getValues();
    }

    public void setRisks(List<String> risks) {
        if (risks != null && !risks.isEmpty()) {
            this.risks = new ListFilter<>(risks);
            paymentFiltersMap.put(PaymentFilterType.RISK, this.risks);
        }
    }

    public DateFilter getDueDate() {
        return dueDate;
    }

    public void setDueDate(DateFilter dueDate) {
        if(dueDate.getEndDate().isPresent() || dueDate.getStartDate().isPresent()) {
            this.dueDate = dueDate;
            paymentFiltersMap.put(PaymentFilterType.DUE_DATE, this.dueDate);
        }
    }

    public ListFilter<AccountKey> getFromAccounts() {
        return fromAccounts;
    }

    public void setFromAccounts(ListFilter<AccountKey> fromAccounts) {
        if (fromAccounts != null && !fromAccounts.getValues().isEmpty()) {
            this.fromAccounts = fromAccounts;
            paymentFiltersMap.put(PaymentFilterType.FROM_ACCOUNT, fromAccounts);
        }
    }

    public String getPaymentId() {
        return paymentId.getExpectedValue();
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = new EqualityFilter<>(paymentId);
        paymentFiltersMap.put(PaymentFilterType.PAYMENT_ID, this.paymentId);
    }

    public List<Payment.TypeEnum> getPaymentTypes() {
        return paymentTypes.getValues();
    }

    public void setPaymentTypes(List<String> paymentTypeStrings) {
        List<Payment.TypeEnum> paymentTypeList = paymentTypeStrings.stream().map(Payment.TypeEnum::valueOf).collect(Collectors.toList());

        this.paymentTypes = new ListFilter<>(paymentTypeList);

        paymentFiltersMap.put(PaymentFilterType.PAYMENT_TYPE, this.paymentTypes);
    }


    public Func1<? super Payment, Boolean> applyFilter() {
        return payment ->
            // TODO: Should this be replaced with a Payment specific filter implementation ?
            this.getPaymentFilterTypes()
                    .stream()
                    .map(this::getPredicateForType)
                    .reduce(p -> true, Predicate::and)
                    .test(payment);
    }

    private Predicate<Payment> getPredicateForType(PaymentFilterType paymentFilterType) {
        // FIXME: The filtering does not throw an error when filtering on incompatible types.
        switch (paymentFilterType) {
            case STATUS:
                return p -> statuses.accept(p.getStatus());
            case PAYMENT_ID:
                return p -> paymentId.accept(p.getId());
            case FROM_ACCOUNT:
                return p -> fromAccounts.accept(AccountKey.fromString(p.getFrom()));
            case PAYMENT_TYPE:
                return p -> paymentTypes.accept(p.getType());
            case DUE_DATE:
                return p -> dueDate.accept(p.getDue());
            case RISK:
            default:
                throw new RuntimeException(paymentFilterType.toString() + " filtering not implemented.");
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("PaymentFilter{ ");

        for (PaymentFilterType paymentFilterType : this.getPaymentFilterTypes()) {
            sb = sb.append(paymentFilterType)
                    .append(this.paymentFiltersMap.get(paymentFilterType).toString());
        }
        sb.append(" }");
        return sb.toString();
    }
}
