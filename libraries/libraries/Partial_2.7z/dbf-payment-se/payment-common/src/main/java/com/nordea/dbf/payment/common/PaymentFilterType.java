package com.nordea.dbf.payment.common;

/**
 * Created by k306010 on 2016-02-23.
 */
public enum PaymentFilterType {
    STATUS,
    PAYMENT_ID,
    RISK,
    FROM_ACCOUNT,
    PAYMENT_TYPE,
    DUE_DATE
    // AGREEMENT


}
