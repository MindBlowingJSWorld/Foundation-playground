package com.nordea.dbf.payment.common.converters;

import com.nordea.dbf.payment.common.model.ServiceData;

public interface Converter<S, T> {
    T convert(ServiceData var1, S var2);
}
