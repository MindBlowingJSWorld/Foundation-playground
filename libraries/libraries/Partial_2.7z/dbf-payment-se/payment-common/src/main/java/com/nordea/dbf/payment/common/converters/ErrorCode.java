package com.nordea.dbf.payment.common.converters;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BackendException;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;

public enum ErrorCode {

    BESE0001backend(ErrorResponses.Types.BACKEND_ERROR, "Unmapped code"),
    BESE0001(ErrorResponses.Types.BAD_REQUEST, "Unmapped code"),
    BESE1001(ErrorResponses.Types.BAD_REQUEST, "This account can't be used as From-account"),
    BESE1002(ErrorResponses.Types.BAD_REQUEST, "This account can't be used as To-account"),
    BESE1003(ErrorResponses.Types.BAD_REQUEST, "Salary and Pension must be registrered minimum 2 days in advance"),
    BESE1004(ErrorResponses.Types.BAD_REQUEST, "Payment note (reference) not allowed with OCR payment"),
    BESE1005(ErrorResponses.Types.BAD_REQUEST, "Error in IBAN account number"),
    BESE1006(ErrorResponses.Types.BAD_REQUEST, "Beneficiary already in beneficiaries list"),
    BESE1007(ErrorResponses.Types.BAD_REQUEST, "Invalid PG account"),
    BESE1008(ErrorResponses.Types.BAD_REQUEST, "Invalid bankgiro account"),
    BESE1009(ErrorResponses.Types.BAD_REQUEST, "Error in reference number (OCR)"),
    BESE1010(ErrorResponses.Types.BAD_REQUEST, "Error in reference number (OCR)"),
    BESE1011(ErrorResponses.Types.BAD_REQUEST, "The currency of the payment is not allowed"),
    BESE1012(ErrorResponses.Types.BAD_REQUEST, "Not allowed to type in amount with decimals for some currencies"),
    BESE1013(ErrorResponses.Types.BAD_REQUEST, "Not allowed to use choosen currency for payments to this specific country"),
    BESE1014(ErrorResponses.Types.BAD_REQUEST, "Invalid OCR, soft control"),
    BESE1015(ErrorResponses.Types.BAD_REQUEST, "Bank information is required for this payment"),
    BESE1016(ErrorResponses.Types.BAD_REQUEST, "BIC correct but country code doesn't match"),
    BESE1017(ErrorResponses.Types.BAD_REQUEST, "Currency and account currency pocket must match"),
    BESE1018(ErrorResponses.Types.BAD_REQUEST, "Bank code is not required for this payment"),
    BESE1019(ErrorResponses.Types.BAD_REQUEST, "Payment to this bank is not possible"),
    BESE1020(ErrorResponses.Types.BAD_REQUEST, "BG payment only in account currency"),
    BESE1021(ErrorResponses.Types.BAD_REQUEST, "Cannot use this To-account for the payment"),
    BESE1022(ErrorResponses.Types.BAD_REQUEST, "Please enter correct OCR number"),
    BESE1023(ErrorResponses.Types.BAD_REQUEST, "Currency cannot be EUR or SEK"),
    BESE1024(ErrorResponses.Types.BAD_REQUEST, "You cannot use EUR/SEK for this payment"),
    BESE1025(ErrorResponses.Types.BAD_REQUEST, "You cannot use EUR/SEK for this payment"),
    BESE1026(ErrorResponses.Types.BAD_REQUEST, "Exchange amount greater than maximum value."),
    BESE1027(ErrorResponses.Types.BAD_REQUEST, "Amount too low"),
    BESE1028(ErrorResponses.Types.BAD_REQUEST, "Duplicate payment. Technical code. Please try again."),
    BESE1029(ErrorResponses.Types.BAD_REQUEST, "From account is blocked"),
    BESE1030(ErrorResponses.Types.BAD_REQUEST, "To account is blocked"),
    BESE1031(ErrorResponses.Types.BAD_REQUEST, "Enter correct OCR number"),
    BESE1032(ErrorResponses.Types.BAD_REQUEST, "IBAN account number invalid"),
    BESE1033(ErrorResponses.Types.BAD_REQUEST, "Not possible to use recurring with OCR"),
    BESE1034(ErrorResponses.Types.BAD_REQUEST, "Not enough funds"),
    BESE1035(ErrorResponses.Types.BAD_REQUEST, "We don't support this country and currency"),
    BESE1036(ErrorResponses.Types.BAD_REQUEST, "Amount is too low"),
    BESE1037(ErrorResponses.Types.BAD_REQUEST, "To and From account must not be the same"),
    BESE1038(ErrorResponses.Types.BAD_REQUEST, "Too large or too small amount for transfer"),
    BESE1039(ErrorResponses.Types.BAD_REQUEST, "Selected bank does not correspond with the specified beneficiary"),
    BESE1040(ErrorResponses.Types.BAD_REQUEST, "Insufficient funds"),
    BESE1041(ErrorResponses.Types.BAD_REQUEST, "Exchange amount greater than maximum value."),
    BESE1042(ErrorResponses.Types.BAD_REQUEST, "Exchange amount and currency problems. Please try again."),
    BESE1043(ErrorResponses.Types.BAD_REQUEST, "Invalid country code"),
    BESE1044(ErrorResponses.Types.BAD_REQUEST, "Country code and SWIFT don't match"),
    BESE1045(ErrorResponses.Types.BAD_REQUEST, "Missing bank information"),
    BESE1046(ErrorResponses.Types.BAD_REQUEST, "BIC is mandatory"),
    BESE1047(ErrorResponses.Types.BAD_REQUEST, "Account is closed"),
    BESE1048(ErrorResponses.Types.BAD_REQUEST, "Mandatory field IBAN missing OR wrong country"),
    BESE1049(ErrorResponses.Types.BAD_REQUEST, "Cut off for execution passed"),
    BESE1050(ErrorResponses.Types.BAD_REQUEST, "Currency is not allowed for check"),
    BESE1051(ErrorResponses.Types.BAD_REQUEST, "Amount exceeds limit for check"),
    BESE1052(ErrorResponses.Types.BAD_REQUEST, "Too much recipient information for check"),
    BESE1053(ErrorResponses.Types.BAD_REQUEST, "Duplicate payment. Technical code. Please try again."),
    BESE1054(ErrorResponses.Types.BAD_REQUEST, "Date changed to next banking day"),
    BESE1055(ErrorResponses.Types.BAD_REQUEST, "Maximum amount exceeded"),
    BESE1056(ErrorResponses.Types.BAD_REQUEST, "Recipient name is missing"),
    BESE1057(ErrorResponses.Types.BAD_REQUEST, "Please enter correct BIC"),
    BESE1058(ErrorResponses.Types.BAD_REQUEST, "Please enter correct OCR number"),;

    private final String code;
    private final String description;
    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorCode.class);

    ErrorCode(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public static Exception getException(String error) {
        try {
            ErrorCode errorCode = ErrorCode.valueOf(error);
            LOGGER.error("Mapped code occurred, returning code: " + errorCode.code + "to user. Description of code: " + errorCode.description);
            return getException(errorCode);
        } catch (IllegalArgumentException e) {
            LOGGER.error("Unmapped code occurred, returning general code:" + BESE0001.code + "to user.");
            return getException(BESE0001);
        }
    }

    public static Exception getException(ErrorCode errorCode) {
        if (ErrorResponses.Types.BACKEND_ERROR.equals(errorCode.code)) {
            return new BackendException(getError(errorCode));
        } else {
            return new BadRequestException(getError(errorCode));
        }
    }

    public static Error getError(ErrorCode errorCode) {
        ErrorDetails errorDetails = new ErrorDetails();
        errorDetails.setReason(errorCode.name());
        errorDetails.setMoreInfo(errorCode.code + ": " + errorCode.description);
        return new Error().setDetails(Collections.singletonList(errorDetails));
    }

    public static Error getErrorWithParam(ErrorCode errorCode, String param) {
        ErrorDetails errorDetails = new ErrorDetails();
        errorDetails.setReason(errorCode.name());
        errorDetails.setMoreInfo(errorCode.code + ": " + errorCode.description);
        errorDetails.setParam(param);
        return new Error().setDetails(Collections.singletonList(errorDetails));
    }
}
