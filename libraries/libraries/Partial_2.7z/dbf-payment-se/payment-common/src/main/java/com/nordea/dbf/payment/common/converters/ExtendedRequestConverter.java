package com.nordea.dbf.payment.common.converters;

import com.nordea.dbf.api.model.Payment;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;

public abstract class ExtendedRequestConverter<T extends M8MessageHeaderRequestRecord, E> implements Converter<Payment, T> {

    E e;

    private E extension;

    public Converter<Payment, T> with(E e) {
        this.setExtension(e);
        return this;
    }

    public void setExtension(E extension) {
        this.extension = extension;
    }

    public E getExtension() {
        return this.extension;
    }
}
