package com.nordea.dbf.payment.common.converters;

import com.nordea.dbf.payment.common.PaymentFilter;

public interface FilterRequestConverter<T> extends Converter<PaymentFilter, T> {

}
