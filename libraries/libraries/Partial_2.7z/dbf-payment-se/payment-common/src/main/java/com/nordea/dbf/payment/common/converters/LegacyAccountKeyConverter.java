package com.nordea.dbf.payment.common.converters;

import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.payment.common.model.AccountKeyFormat;
import com.nordea.dbf.util.StringTemplate;
import org.apache.commons.lang.StringUtils;

import static com.nordea.dbf.payment.common.model.LegacyGiroType.fromCode;
import static com.nordea.dbf.util.StringTemplate.usingMap;

public interface LegacyAccountKeyConverter {

    /**
     * Returns the internal account key from the provided payment type, account number and currency.
     *
     * @param paymentType   The giro type of the payment, or null/empty if transfer.
     * @param accountNumber The accountNumber of the target account.
     * @param currency      The currency of the target account.
     * @return An account key
     */
    static String accountKeyOf(String paymentType, long accountNumber, String currency) {
        final StringTemplate accountKeyFormat;

        if (StringUtils.isEmpty(paymentType)) {
            accountKeyFormat = AccountKeyFormat.NAID_ACCOUNT_FORMAT;
        } else {
            switch (fromCode(paymentType)) {
                case PG:
                    accountKeyFormat = AccountKeyFormat.PG_ACCOUNT_FORMAT;
                    break;
                case BG:
                    accountKeyFormat = AccountKeyFormat.BG_ACCOUNT_FORMAT;
                    break;
                case NORDEA_ACCOUNT:
                case OWN_ACCOUNTS:
                    accountKeyFormat = AccountKeyFormat.NAID_ACCOUNT_FORMAT;
                    break;
                case EXTERNAL_TRANSFER:
                    accountKeyFormat = AccountKeyFormat.EXTERNAL_TRANSFER;
                    break;
                default:
                    throw new IllegalArgumentException("Invalid payment type '" + paymentType + "'");
            }
        }

        return accountKeyFormat.expand(usingMap(ImmutableMap.of(
                "accountNumber", accountNumber,
                "currency", currency
        )));
    }
}
