package com.nordea.dbf.payment.common.converters;

import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.infra.record.nilheader.NilResponseMsgHeaderRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.ParameterizedType;

public interface ResponseConverter<S extends NilResponseMsgHeaderRecord, T> extends Converter<S, T> {
    static final Logger LOGGER = LoggerFactory.getLogger(ResponseConverter.class);
    @Override
    default T convert(ServiceData serviceData, S responseRecord) {
        // ResponseConverters are always error checked first.
        try {
            this.errorHandler(responseRecord.getKbearb(), responseRecord.getKrc());
        } catch (RuntimeException e) {
            LOGGER.error("Response resulted in exception. Response data: " + responseRecord.toString() + System.lineSeparator());
            throw e;
        }
        return this.responseConvert(serviceData, responseRecord);
    }

    void errorHandler(int kbearb, int krc);

    T responseConvert(ServiceData serviceData, S responseRecord);

    default Class<T> getResponseClass() {
        // Assuming only this interface is implemented.
        return (Class<T>) ((ParameterizedType) this.getClass().getGenericInterfaces()[0]).getActualTypeArguments()[0];
    }
}
