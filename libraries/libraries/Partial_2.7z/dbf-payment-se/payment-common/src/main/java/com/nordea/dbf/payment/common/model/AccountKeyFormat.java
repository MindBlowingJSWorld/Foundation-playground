package com.nordea.dbf.payment.common.model;

import com.nordea.dbf.util.StringTemplate;

/**
 * Constants file taken from {@code com.nordea.nil.lsb.se.payment.util.LASEPaymentConstants}.
 * TODO This should be done away with and the properties herein should be configured in a proper fashion
 */
public interface AccountKeyFormat {

    StringTemplate PG_ACCOUNT_FORMAT = new StringTemplate("PG-{accountNumber}");

    StringTemplate BG_ACCOUNT_FORMAT = new StringTemplate("BG-{accountNumber}");

    StringTemplate NAID_ACCOUNT_FORMAT = new StringTemplate("NAID-SE-{currency}-{accountNumber}");

    StringTemplate EXTERNAL_TRANSFER = new StringTemplate("LBAN-SE-{accountNumber}");

    StringTemplate CROSS_BORDER_TRANSFERS = new StringTemplate("IBAN-{bicCode}-{iban}");


}
