package com.nordea.dbf.payment.common.model;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.api.model.accountkey.AccountPrefixType;

import java.time.LocalDate;

import static com.nordea.dbf.api.model.Payment.*;

public class CommonPaymentType {

    public static TypeEnum fromPayment(Payment payment, boolean ownBothAccounts) {
        final AccountKey fromAccount = AccountKey.fromString(payment.getFrom());
        final AccountKey toAccount = AccountKey.fromString(payment.getTo());

        // TODO: Is this a valid assumption ?
        if (!fromAccount.getPrefix().equals(AccountPrefixType.NAID)) {
            throw new IllegalArgumentException("Invalid from account type, only NAID-accounts allowed.");
        }

        if (payment.getType() != null) {
            if (payment.getType() == TypeEnum.pension) {
                return TypeEnum.pension;
            } else if (payment.getType() == TypeEnum.salary) {
                return TypeEnum.salary;
            }
        }

        switch (toAccount.getPrefix()) {
            case NAID:
                if (ownBothAccounts && (null == payment.getDue() || LocalDate.now().equals(payment.getDue()))) {
                    payment.setDue(LocalDate.now());
                    return TypeEnum.owntransfer;
                } else {
                    return TypeEnum.lban;
                }
            case PG:
                return TypeEnum.plusgiro;
            case BG:
                return TypeEnum.bankgiro;
            case LBAN:
                return TypeEnum.lban;
            case IBAN:
            case CROSSBORDER:
                return TypeEnum.crossborder;
            default:
                throw new IllegalArgumentException("Invalid to account type: " + toAccount.getPrefix());
        }
    }
}
