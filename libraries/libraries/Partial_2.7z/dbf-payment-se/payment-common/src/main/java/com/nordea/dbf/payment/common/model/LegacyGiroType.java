package com.nordea.dbf.payment.common.model;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.accountkey.AccountPrefixType;
import org.apache.commons.lang.Validate;

public enum LegacyGiroType {
    // TODO: Verify these mappings.
    PG("PG", Payment.TypeEnum.plusgiro),
    BG("BG", Payment.TypeEnum.bankgiro),
    OWN_ACCOUNTS("EK", Payment.TypeEnum.owntransfer),
    NORDEA_ACCOUNT("NA", Payment.TypeEnum.lban),
    EXTERNAL_TRANSFER("EB", Payment.TypeEnum.lban),
    SALARY("LO", Payment.TypeEnum.salary),
    PENSION("PE", Payment.TypeEnum.pension);

    private final String code;

    private final Payment.TypeEnum paymentType;

    LegacyGiroType(String code, Payment.TypeEnum plusgiro) {
        this.code = code;
        paymentType = plusgiro;
    }

    public String code() {
         return code;
    }

    public Payment.TypeEnum toPaymentType() {
        return paymentType;
    }

    public static LegacyGiroType fromCode(String code) {
        Validate.notNull(code, "code can't be null");

        for (final LegacyGiroType type : values()) {
            if (type.code().equals(code)) {
                return type;
            }
        }

        return null;
    }

    public static String convertToGiroType(AccountPrefixType prefix) {
        switch (prefix) {
            case PG:
                return LegacyGiroType.PG.code();
            case BG:
                return LegacyGiroType.BG.code();
            case LBAN:
                return LegacyGiroType.EXTERNAL_TRANSFER.code();
            default:
                return LegacyGiroType.NORDEA_ACCOUNT.code();
        }
    }

    public static LegacyGiroType fromPaymentType(Payment.TypeEnum paymentType) {
        switch (paymentType) {
            case plusgiro:
                return LegacyGiroType.PG;
            case bankgiro:
                return LegacyGiroType.BG;
            case owntransfer:
                return LegacyGiroType.OWN_ACCOUNTS;
            case lban:
                return LegacyGiroType.EXTERNAL_TRANSFER;
            case einvoice:
            case crossborder:
            default:
                throw new UnsupportedOperationException("Unknown payment type for legacy giro types: " + paymentType);
        }
    }
}
