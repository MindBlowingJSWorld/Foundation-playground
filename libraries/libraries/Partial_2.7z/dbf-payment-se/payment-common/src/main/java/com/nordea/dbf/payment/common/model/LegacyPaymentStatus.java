package com.nordea.dbf.payment.common.model;

import com.nordea.dbf.api.model.Payment;

public enum LegacyPaymentStatus {

    CONFIRMED("BEV", Payment.StatusEnum.confirmed),
    UNCONFIRMED("NCF", Payment.StatusEnum.unconfirmed),
    REJECTED("UND", Payment.StatusEnum.rejected),
    DELETED("DEL", Payment.StatusEnum.cancelled),
    CANCELLED("MAK", Payment.StatusEnum.cancelled),
    PAID("UTF", Payment.StatusEnum.paid),
    INPROGRESS("SND", Payment.StatusEnum.inprogress);

    private final String code;
    private final Payment.StatusEnum paymentStatus;

    LegacyPaymentStatus(String code, Payment.StatusEnum paymentStatus) {
        this.code = code;
        this.paymentStatus = paymentStatus;
    }

    public String code() {
        return code;
    }

    public Payment.StatusEnum asPaymentStatus() {
      return paymentStatus;
    }

    public static LegacyPaymentStatus fromCode(final String code) {
        for (final LegacyPaymentStatus status : values()) {
            if (status.code().equals(code)) {
                return status;
            }
        }

        throw new IllegalArgumentException("Invalid status code: " + code);
    }

    public static LegacyPaymentStatus fromPaymentStatusEnum(final Payment.StatusEnum status) {
        for (final LegacyPaymentStatus legacyStatus : values()) {
            if (legacyStatus.paymentStatus == status) {
                return legacyStatus;
            }
        }

        throw new IllegalArgumentException("Invalid status: " + status);
    }
}
