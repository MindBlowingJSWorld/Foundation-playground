package com.nordea.dbf.payment.common.model;

import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payment.record.domestic.EInvoiceRequestRecord;
import com.nordea.infra.record.nilheader.NilRequestMsgHeaderRecord;
import org.apache.commons.lang.StringUtils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Created by k306010 on 2016-02-23.
 * <p>
 * Generalize the setup of headers for all NilRequestMsgHeaders based on the requestContext.
 */
public class NilRequestMsgHeaders {

    static final int TIME_TO_LIVE = 30;

    public <T extends NilRequestMsgHeaderRecord> T withHeaderConfiguration(ServiceRequestContext requestContext, T instance) {
        requestContext.getLanguage()
                .map(Locale::getLanguage)
                .ifPresent(instance::setLanguage);

        instance.setUserId(requestContext.getUserId().get());
        instance.setTimeToLive(TIME_TO_LIVE);
        instance.setApplicationId(requestContext.getApplicationId().get());
        instance.setCountry(requestContext.getCountry().get());
        instance.setRequestId(requestContext.getRequestId().get());
        // FIXME: The sesssion is incorrectly overwritten in the core
        instance.setSessionId(requestContext.getSessionId().orElse("TEST-" + requestContext.getUserId().get()));
        instance.setUtcTime(LocalDateTime.ofInstant(Instant.ofEpochMilli(requestContext.getTimeStamp()), ZoneOffset.UTC).format(DateTimeFormatter.ISO_DATE_TIME));

        return instance;
    }

    /**
     * Create an <code>EInvoiceRequestRecord</code> from the provided service context and message id. The request
     * will be populated from the service request context and can be extended by the requesting method.
     *
     * @param requestContext The request context that contains the user information.
     * @return A <code>EInvoiceRequestRecord</code> that can be used to execute some operation against the
     * e-invoice backend.
     */
    public EInvoiceRequestRecord eInvoiceRequestFrom(ServiceRequestContext requestContext) {
        EInvoiceRequestRecord eInvoiceRequestRecord = new EInvoiceRequestRecord();
        eInvoiceRequestRecord.initialize();
        final EInvoiceRequestRecord requestRecord = withHeaderConfiguration(requestContext, eInvoiceRequestRecord);

        requestRecord.setAgreement(requestContext.getAgreementNumber().get());
        requestRecord.setUserId("SE000" + requestContext.getUserId().get());
        //requestRecord.setTransactionCode("M8047P");
        //requestRecord.setMessageId(message.getMessageId());
        requestRecord.setContinuationKey(StringUtils.repeat("0", 18));
        requestRecord.setAgreementHolderId(Long.parseLong(requestContext.getUserId().get()));

        return requestRecord;
    }
}
