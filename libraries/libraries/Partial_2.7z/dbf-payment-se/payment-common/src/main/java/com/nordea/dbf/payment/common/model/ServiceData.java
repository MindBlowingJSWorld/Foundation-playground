package com.nordea.dbf.payment.common.model;

import com.nordea.dbf.http.ServiceRequestContext;

/**
 * A wrapper of data required to work with payment services
 */
public class ServiceData {

    private final ServiceRequestContext serviceRequestContext;
    private final String agreementOwner;
    private final String racfId;
    private final String segment;

    public ServiceData(ServiceRequestContext serviceRequestContext, String agreementOwner, String racfId, String segment) {
        this.serviceRequestContext = serviceRequestContext;
        this.agreementOwner = agreementOwner;
        this.racfId = racfId;
        this.segment = segment;
    }

    public ServiceRequestContext getServiceRequestContext() {
        return serviceRequestContext;
    }

    public String getAgreementOwner() {
        return agreementOwner;
    }

    public String getRacfId() {
        return racfId;
    }

    public boolean isSegmentCorporate() {
        return "corporate".equals(this.segment);
    }

    public boolean isSegmentHousehold() {
        return "household".equals(this.segment);
    }

    public String getSegment() {
        return segment;
    }

    public Long getAgreement() {
        return this.serviceRequestContext.getAgreementNumber().get();
    }

    public String getUserId() {
        return this.serviceRequestContext.getUserId().get();
    }

    public String getRemoteAddress() {
        return this.serviceRequestContext.getRemoteAddress();
    }
}
