package com.nordea.dbf.payment.common.util;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnection;
import com.nordea.dbf.payment.common.converters.Converter;
import com.nordea.dbf.payment.common.converters.ResponseConverter;
import com.nordea.dbf.payment.common.model.ServiceData;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;
import rx.functions.Func1;

public class M8RequestResponseWrapper {
    private static final Logger LOGGER = LoggerFactory.getLogger(M8RequestResponseWrapper.class);

    public Observable<Payment> requestResponseWrapper(M8ImsConnection connection, Payment payment, ServiceData serviceData, Converter requestConverter, ResponseConverter responseConverter) {
        return requestResponseWrapper(connection, payment, serviceData, requestConverter, responseConverter, p -> p);
    }

    public Observable<Payment> requestResponseWrapper(M8ImsConnection connection, Payment payment, ServiceData serviceData, Converter requestConverter, ResponseConverter responseConverter, Func1<Payment, Payment> converter) {
        M8MessageHeaderRequestRecord req = (M8MessageHeaderRequestRecord) requestConverter.convert(serviceData, payment);
        return connection.execute(
                req,
                (Class<M8MessageHeaderResponseRecord>) responseConverter.getResponseClass())
                .map(res -> converter.call((Payment) responseConverter.convert(serviceData, res)))
                .doOnError(e -> {
                    LOGGER.error("Request resulted in exception. Request data: " + req.toString() + System.lineSeparator());
                })
                ;
    }
}
