package com.nordea.dbf.payment.common.util;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.util.Difference;

import java.util.Objects;

/**
 *
 * A utiltiy class used to compare two payments (or a partial payment with the original payment)
 *
 */
public class PaymentDifference {

    /**
     * A comparison of data between two payments. The comparison is solely based on the information available in the payment as opposed to the originalPayment,
     * a such the originalPayment can contain more data then the payment without causing any differences.
     *
     * @param payment the payment to be compared (partial or complete)
     * @param originalPayment the original payment
     * @return
     */
    public static Difference compareWithOriginal(Payment payment, Payment originalPayment) {
        return Difference.between(payment, originalPayment)
                .filter(property -> !Objects.equals(property.getName(), "presentFields"))
                .filter(property -> property.getLeftValue() != null && property.getRightValue() != null);

    }
}
