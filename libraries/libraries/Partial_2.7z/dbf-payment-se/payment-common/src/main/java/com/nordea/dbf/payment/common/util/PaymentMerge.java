package com.nordea.dbf.payment.common.util;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;

/**
  * A utility class used to merge Payments, primarily used for changing payments.
 */
public class PaymentMerge {
    /**
     * Merges the input payment into the source based on the following ruleset:
     * - If a value exists in input, but not in source, add to source
     * - If a value exists in source but not in input, leave it
     * - If a value exists in both then,
     * keep source if equal
     * override source with input if different
     *
     * @param input  the input payment, can be a complete payment or partial.
     * @param source the source payment
     * @return a Payment with the details merged from input and source
     */
    public static Payment merge(Payment input, Payment source) {
        Payment result = new Payment();

        /*
            Not mapped:

        if (input.getEntryDate() != null) {
            result.setEntryDate(input.getEntryDate());
        } else if (source.getEntryDate() != null) {
            result.setEntryDate(source.getEntryDate());
        }

         */

        /*
            Based on source:

         */
        result.setId(source.getId());
        result.setStatus(source.getStatus());
        result.setPermissions(source.getPermissions());


        /*
            Mapped:

         */
        if (input.getAmount() != null) {
            result.setAmount(input.getAmount());
        } else if (source.getAmount() != null) {
            result.setAmount(source.getAmount());
        }
        if (input.getCurrency() != null) {
            result.setCurrency(input.getCurrency());
        } else if (source.getCurrency() != null) {
            result.setCurrency(source.getCurrency());
        }
        if (input.getDue() != null) {
            result.setDue(input.getDue());
        } else if (source.getDue() != null) {
            result.setDue(source.getDue());
        }
        if (input.getFrom() != null) {
            result.setFrom(input.getFrom());
        } else if (source.getFrom() != null) {
            result.setFrom(source.getFrom());
        }
        if (input.getMessage() != null) {
            result.setMessage(input.getMessage());
        } else if (source.getMessage() != null) {
            result.setMessage(source.getMessage());
        }
        if (input.getOwnMessage() != null) {
            result.setOwnMessage(input.getOwnMessage());
        } else if (source.getOwnMessage() != null) {
            result.setOwnMessage(source.getOwnMessage());
        }
        if (input.getReceipt() != null) {
            result.setReceipt(input.getReceipt());
        } else if (source.getReceipt() != null) {
            result.setReceipt(source.getReceipt());
        }
        if (input.getSpeed() != null) {
            result.setSpeed(input.getSpeed());
        } else if (source.getSpeed() != null) {
            result.setSpeed(source.getSpeed());
        }
        if (input.getStatusMessage() != null) {
            result.setStatusMessage(input.getStatusMessage());
        } else if (source.getStatusMessage() != null) {
            result.setStatusMessage(source.getStatusMessage());
        }
        if (input.getTo() != null) {
            result.setTo(input.getTo());
        } else if (source.getTo() != null) {
            result.setTo(source.getTo());
        }
        if (input.getType() != null) {
            result.setType(input.getType());
        } else if (source.getType() != null) {
            result.setType(source.getType());
        }
        if (input.getUrl() != null) {
            result.setUrl(input.getUrl());
        } else if (source.getUrl() != null) {
            result.setUrl(source.getUrl());
        }

        mergeCrossBorder(input, source, result);

        mergeRecurring(input, source, result);

        return result;
    }

    private static void mergeCrossBorder(Payment input, Payment source, Payment result) {
        if (input.getCrossBorder() != null && source.getCrossBorder() != null) {
            CrossBorder inputCrossBorder = input.getCrossBorder();
            CrossBorder sourceCrossBorder = source.getCrossBorder();
            CrossBorder mergedCrossborder = new CrossBorder();
            
            // FIXME: This is a list, map values?
            if (inputCrossBorder.getAddress() != null) {
                mergedCrossborder.setAddress(inputCrossBorder.getAddress());
            } else if (sourceCrossBorder.getAddress() != null) {
                mergedCrossborder.setAddress(sourceCrossBorder.getAddress());
            }
            // TODO: is the below mapping correct?
            if (inputCrossBorder.getSepaReference() != null) {
                mergedCrossborder.setSepaReference(inputCrossBorder.getSepaReference());
            } else if (sourceCrossBorder.getSepaReference() != null) {
                mergedCrossborder.setSepaReference(sourceCrossBorder.getSepaReference());                
            }

            if (inputCrossBorder.getBankCountry() != null) {
                mergedCrossborder.setBankCountry(inputCrossBorder.getBankCountry());
            } else if (sourceCrossBorder.getBankCountry() != null) {
                mergedCrossborder.setBankCountry(sourceCrossBorder.getBankCountry());
            }
            if (inputCrossBorder.getBankName() != null) {
                mergedCrossborder.setBankName(inputCrossBorder.getBankName());
            } else if (sourceCrossBorder.getBankName() != null) {
                mergedCrossborder.setBankName(sourceCrossBorder.getBankName());
            }
            if (inputCrossBorder.getBic() != null) {
                mergedCrossborder.setBic(inputCrossBorder.getBic());
            } else if (sourceCrossBorder.getBic() != null) {
                mergedCrossborder.setBic(sourceCrossBorder.getBic());
            }
            if (inputCrossBorder.getBranchCode() != null) {
                mergedCrossborder.setBranchCode(inputCrossBorder.getBranchCode());
            } else if (sourceCrossBorder.getBranchCode() != null) {
                mergedCrossborder.setBranchCode(sourceCrossBorder.getBranchCode());
            }
            if (inputCrossBorder.getCentralBankReportingCode() != null) {
                mergedCrossborder.setCentralBankReportingCode(inputCrossBorder.getCentralBankReportingCode());
            } else if (sourceCrossBorder.getCentralBankReportingCode() != null) {
                mergedCrossborder.setCentralBankReportingCode(sourceCrossBorder.getCentralBankReportingCode());
            }
            if (inputCrossBorder.getChargePaidBy() != null) {
                mergedCrossborder.setChargePaidBy(inputCrossBorder.getChargePaidBy());
            } else if (sourceCrossBorder.getChargePaidBy() != null) {
                mergedCrossborder.setChargePaidBy(sourceCrossBorder.getChargePaidBy());
            }
/*            if (inputCrossBorder.getRecipientName() != null) {
                mergedCrossborder.setRecipientName(inputCrossBorder.getRecipientName());
            } else if (sourceCrossBorder.getRecipientName() != null) {
                mergedCrossborder.setRecipientName(sourceCrossBorder.getRecipientName());
            }
*/
            result.setCrossBorder(mergedCrossborder);
        } else if (input.getCrossBorder() != null) {
            result.setCrossBorder(input.getCrossBorder());
        } else if (source.getCrossBorder() != null) {
            result.setCrossBorder(source.getCrossBorder());
        }
    }

    private static void mergeRecurring(Payment input, Payment source, Payment result) {
        if (input.getRecurring() != null && source.getRecurring() != null) {
            PaymentRecurring mergedRecurring = new PaymentRecurring();

        } else if (input.getRecurring() != null) {
            result.setRecurring(input.getRecurring());
        } else if (source.getRecurring() != null) {
            result.setRecurring(source.getRecurring());
        }
    }
}
