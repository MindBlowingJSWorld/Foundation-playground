package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Payment;

public class CorporatePaymentValidator extends PaymentValidator {

    private static final int SHORT_MESSAGE_MAX_LENGTH = 12;
    private static final int MEDIUM_MESSAGE_MAX_LENGTH = 140;
    private static final int LONG_MESSAGE_MAX_LENGTH = 220;
    private static final int OWNTRANSFER_OWN_MESSAGE_MAX_LENGTH = 20;
    private static final int OWN_MESSAGE_MIN_LENGTH = 0;
    private static final int OWN_MESSAGE_MAX_LENGTH = 35;
    private static final int BANK_NAME_MAX_LENGTH = 35;
    private static final int SEPA_REFERENCE_MAX_LENGTH = 35;
    private static final int ADDRESS_MAX_LENGTH = 105;
    private static final int CENTRAL_BANK_REPORTING_CODE_LENGTH = 3;
    private static final int BANK_COUNTRY_LENGTH = 2;

    public CorporatePaymentValidator() {
        this.addFromValidator();
        this.addToValidator();
    }

    public CorporatePaymentValidator paymentCreationValidator(Payment payment) {
        addIdEmptyValidator();
        switch (payment.getType()) {
            case plusgiro:
            case bankgiro:
            case lban:
            case pension:
            case salary:
            case crossborder:
                addDueValidator();
                break;
            case owntransfer:
            case einvoice:
                break;
            default:
                throw new IllegalArgumentException(String.format("Unsupported payment type: %s", payment.getType()));
        }
        return paymentConfirmationValidator(payment);
    }

    public CorporatePaymentValidator paymentConfirmationValidator(Payment payment) {
        switch (payment.getType()) {
            case plusgiro:
                return paymentPgValidator();
            case bankgiro:
                return paymentBgValidator();
            case lban:
                return paymentLbanValidator();
            case pension:
                return paymentPensionValidator();
            case salary:
                return paymentSalaryValidator();
            case crossborder:
                return paymentCrossborderValidator();
            case owntransfer:
                this.addAmountValidator();
                this.addOwnMessageValidator(0, OWNTRANSFER_OWN_MESSAGE_MAX_LENGTH);
                return this;
            default:
                throw new IllegalArgumentException(String.format("Unsupported payment type: %s", payment.getType()));
        }
    }

    public CorporatePaymentValidator paymentPgValidator() {
        return paymentDomesticValidator(LONG_MESSAGE_MAX_LENGTH);
    }

    public CorporatePaymentValidator paymentBgValidator() {
        return paymentDomesticValidator(LONG_MESSAGE_MAX_LENGTH);
    }

    public CorporatePaymentValidator paymentLbanValidator() {
        return paymentDomesticValidator(SHORT_MESSAGE_MAX_LENGTH);
    }

    public CorporatePaymentValidator paymentPensionValidator() {
        return paymentDomesticValidator(SHORT_MESSAGE_MAX_LENGTH);
    }

    public CorporatePaymentValidator paymentSalaryValidator() {
        return paymentDomesticValidator(SHORT_MESSAGE_MAX_LENGTH);
    }

    private CorporatePaymentValidator paymentDomesticValidator(int messageMaxLength) {
        this.addMessageValidator(0, messageMaxLength);
        this.addOwnMessageValidator(OWN_MESSAGE_MIN_LENGTH, OWN_MESSAGE_MAX_LENGTH);
        this.addAmountValidator();
        return this;
    }

    public CorporatePaymentValidator paymentCrossborderValidator() {
        this.addMessageValidator(0, MEDIUM_MESSAGE_MAX_LENGTH);
        this.addCrossborderExistenceValidator();
        this.addSepaReferenceValidator();
        this.addBankNameValidator();
        this.addAddressValidator();
        this.addBankCountryValidator();
        this.addCentralBankReportingCodeValidator();
        this.addAmountValidator();
        this.addRecipientNameValidator();
        return this;
    }

    public CorporatePaymentValidator addAddressValidator() {
        addValidator(new PaymentAddressValidator(ADDRESS_MAX_LENGTH));
        return this;
    }

    public CorporatePaymentValidator addBankCountryValidator() {
        addValidator(new PaymentBankCountryValidator(BANK_COUNTRY_LENGTH));
        return this;
    }

    public CorporatePaymentValidator addBankNameValidator() {
        addValidator(new PaymentBankNameValidator(BANK_NAME_MAX_LENGTH));
        return this;
    }

    public CorporatePaymentValidator addCentralBankReportingCodeValidator() {
        addValidator(new PaymentCentralBankReportingCodeValidator(CENTRAL_BANK_REPORTING_CODE_LENGTH));
        return this;
    }

    public CorporatePaymentValidator addRecipientNameValidator() {
        addValidator(new PaymentRecipientNameValidator());
        return this;
    }

    public CorporatePaymentValidator addSepaReferenceValidator() {
        addValidator(new PaymentSepaReferenceValidator(SEPA_REFERENCE_MAX_LENGTH));
        return this;
    }
}
