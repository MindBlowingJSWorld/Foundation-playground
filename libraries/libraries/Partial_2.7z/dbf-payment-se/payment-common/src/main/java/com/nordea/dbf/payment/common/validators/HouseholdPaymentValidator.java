package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Payment;

public class HouseholdPaymentValidator extends PaymentValidator {

    public HouseholdPaymentValidator() {
        this.addFromValidator();
        this.addToValidator();
    }

    @Override
    public PaymentValidator paymentCreationValidator(Payment payment) {
        addIdEmptyValidator();
        return this;
    }

    @Override
    public PaymentValidator paymentConfirmationValidator(Payment payment) {
        return this;
    }

    @Override
    public PaymentValidator addBankCountryValidator() {
        return this;
    }

    @Override
    public PaymentValidator addBankNameValidator() {
        return this;
    }

    @Override
    public PaymentValidator addCentralBankReportingCodeValidator() {
        return this;
    }

    @Override
    public PaymentValidator addSepaReferenceValidator() {
        return this;
    }

    @Override
    public PaymentValidator addAddressValidator() {
        return this;
    }
}
