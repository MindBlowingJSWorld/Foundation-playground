package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentAddressValidator implements Validator {

    private final int maxLength;

    public PaymentAddressValidator(int maxLength) {
        this.maxLength = maxLength;
    }

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (payment.getCrossBorder() == null || payment.getCrossBorder().getAddress() == null || payment.getCrossBorder().getAddress().isEmpty()) {
            return Optional.empty();
        }

        List<Error> collect = payment.getCrossBorder().getAddress().stream()
                .filter(s -> s.length() > maxLength)
                .map(s -> ErrorCode.getErrorWithParam(BESE0001, "address"))
                .collect(Collectors.toList());

        if (collect.size() > 0) {
            Error error = new Error();
            collect.forEach(e -> error.getDetails().add(e.getDetails().get(0)));
            return Optional.of(error);
        }

        return Optional.empty();
    }
}
