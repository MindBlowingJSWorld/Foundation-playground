package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;
import org.apache.commons.lang.StringUtils;

import java.util.Optional;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentBankCountryValidator implements Validator {

    private final int length;

    public PaymentBankCountryValidator(int length) {
        this.length = length;
    }

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (payment.getCrossBorder() != null
                && payment.getCrossBorder().getBankCountry() != null
                && payment.getCrossBorder().getBankCountry().length() != length) {
            return Optional.of(ErrorCode.getErrorWithParam(BESE0001, "bank_country"));
        }
        return Optional.empty();
    }
}
