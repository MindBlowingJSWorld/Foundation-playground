package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;

import java.util.Optional;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentCentralBankReportingCodeValidator implements Validator {

    private final int length;

    public PaymentCentralBankReportingCodeValidator(int length) {
        this.length = length;
    }

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (payment.getCrossBorder() != null
                && payment.getCrossBorder().getCentralBankReportingCode() != null
                && payment.getCrossBorder().getCentralBankReportingCode().length() != length) {
            return Optional.of(ErrorCode.getErrorWithParam(BESE0001, "central_bank_reporting_code"));
        }
        return Optional.empty();
    }
}
