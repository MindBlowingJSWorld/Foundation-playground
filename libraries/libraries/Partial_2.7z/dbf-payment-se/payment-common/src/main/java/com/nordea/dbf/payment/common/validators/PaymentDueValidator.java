package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;

import java.time.LocalDate;
import java.util.Optional;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentDueValidator implements Validator {

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (payment.getDue().isAfter(LocalDate.now().minusDays(1))
                && payment.getDue().isBefore(LocalDate.now().plusYears(1))) {
            return Optional.empty();
        }
        return Optional.of(ErrorCode.getErrorWithParam(BESE0001, "due"));
    }
}
