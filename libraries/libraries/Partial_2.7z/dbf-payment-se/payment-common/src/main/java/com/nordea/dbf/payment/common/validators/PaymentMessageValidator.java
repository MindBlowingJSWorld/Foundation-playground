package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;
import org.apache.commons.lang.StringUtils;

import java.util.Optional;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentMessageValidator implements Validator {

    private final int min;
    private final int max;

    public PaymentMessageValidator(int min, int max) {
        this.min = min;
        this.max = max;
    }

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (payment.getMessage() != null
                && !payment.getMessage().equals(StringUtils.EMPTY)
                && checkLength(payment.getMessage())) {
            return Optional.of(ErrorCode.getErrorWithParam(BESE0001, "message"));
        }
        return Optional.empty();
    }

    private boolean checkLength(String string) {
        return string.length() < min || string.length() > max;
    }
}
