package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;

import java.util.Optional;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentOwnMessageValidator implements Validator {

    private final int min;
    private final int max;

    public PaymentOwnMessageValidator(int min, int max) {
        this.min = min;
        this.max = max;
    }

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (payment.getOwnMessage() == null || checkLength(payment.getOwnMessage())) {
            return Optional.of(ErrorCode.getErrorWithParam(BESE0001, "own_message"));
        }
        return Optional.empty();
    }

    private boolean checkLength(String string) {
        return string.length() < min || string.length() > max;
    }
}
