package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;
import org.apache.commons.lang.StringUtils;

import java.util.Optional;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentSepaReferenceValidator implements Validator {

    private final int maxLength;

    public PaymentSepaReferenceValidator(int maxLength) {
        this.maxLength = maxLength;
    }

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (payment.getCrossBorder() != null
                && payment.getCrossBorder().getSepaReference() != null
                && payment.getCrossBorder().getSepaReference().length() > maxLength) {
            return Optional.of(ErrorCode.getErrorWithParam(BESE0001, "sepa_reference"));
        }
        return Optional.empty();
    }
}
