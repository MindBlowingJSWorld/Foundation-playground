package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;

import java.util.List;
import java.util.Optional;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentStatusValidator implements Validator {

    private List<Payment.StatusEnum> statuses;

    public PaymentStatusValidator(List<Payment.StatusEnum> statuses) {
        this.statuses = statuses;
    }

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (statuses.contains(payment.getStatus())) {
            return Optional.empty();
        }
        return Optional.of(ErrorCode.getErrorWithParam(BESE0001, "status"));
    }
}
