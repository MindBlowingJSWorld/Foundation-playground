package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.converters.ErrorCode;

import java.util.Optional;

import static com.nordea.dbf.payment.common.converters.ErrorCode.BESE0001;

public class PaymentToValidator implements Validator {

    @Override
    public Optional<Error> validate(final Payment payment) {
        if (payment.getTo() == null || payment.getTo().length() == 0) {
            return Optional.of(ErrorCode.getErrorWithParam(BESE0001, "to"));
        }
        return Optional.empty();
    }
}
