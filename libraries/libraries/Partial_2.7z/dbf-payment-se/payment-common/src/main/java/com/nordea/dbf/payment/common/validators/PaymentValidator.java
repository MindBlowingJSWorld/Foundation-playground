package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.payment.common.model.ServiceData;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public abstract class PaymentValidator {

    protected List<Validator> validators = new ArrayList<>();

    public Payment validate(Payment payment) {
        Error error = new Error().setError("error_core_invalid_fields")
                .setErrorDescription("Invalid parameter(s) for payment")
                .setDetails(new ArrayList<>());

        List<Error> collect = validators.stream()
                .map(validator -> validator.validate(payment))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toList());

        if (collect.size() > 0) {
            collect.forEach(e -> error.getDetails().add(e.getDetails().get(0)));
            throw new BadRequestException(error);
        }

        return payment;
    }

    public PaymentValidator clearValidators() {
        validators.clear();
        return this;
    }

    public abstract PaymentValidator paymentCreationValidator(Payment payment);

    public abstract PaymentValidator paymentConfirmationValidator(Payment payment);

    protected PaymentValidator addValidator(Validator validator) {
        this.validators.add(validator);
        return this;
    }

    public PaymentValidator addIdEmptyValidator() {
        addValidator(new PaymentIdEmptyValidator());
        return this;
    }

    public PaymentValidator addToValidator() {
        addValidator(new PaymentToValidator());
        return this;
    }

    public PaymentValidator addFromValidator() {
        addValidator(new PaymentFromValidator());
        return this;
    }

    public PaymentValidator addAmountValidator() {
        addValidator(new PaymentAmountValidator());
        return this;
    }

    public PaymentValidator addCrossborderExistenceValidator() {
        addValidator(new PaymentCrossborderExistenceValidator());
        return this;
    }

    public PaymentValidator addDueValidator() {
        addValidator(new PaymentDueValidator());
        return this;
    }

    public PaymentValidator addMessageValidator(int min, int max) {
        addValidator(new PaymentMessageValidator(min, max));
        return this;
    }

    public PaymentValidator addOwnMessageValidator(int min, int max) {
        addValidator(new PaymentOwnMessageValidator(min, max));
        return this;
    }

    public PaymentValidator addRecipientNameValidator() {
        addValidator(new PaymentRecipientNameValidator());
        return this;
    }

    public PaymentValidator addStatusValidator(List<Payment.StatusEnum> statuses) {
        addValidator(new PaymentStatusValidator(statuses));
        return this;
    }

    public abstract PaymentValidator addBankCountryValidator();

    public abstract PaymentValidator addBankNameValidator();

    public abstract PaymentValidator addCentralBankReportingCodeValidator();

    public abstract PaymentValidator addSepaReferenceValidator();

    public abstract PaymentValidator addAddressValidator();

}
