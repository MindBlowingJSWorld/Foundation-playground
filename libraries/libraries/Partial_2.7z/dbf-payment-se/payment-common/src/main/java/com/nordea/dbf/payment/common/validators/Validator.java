package com.nordea.dbf.payment.common.validators;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;

import java.util.Optional;

public interface Validator {
    Optional<Error> validate(Payment payment);
}
