package com.nordea.dbf.payment.common.model;

import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.infra.record.nilheader.NilRequestMsgHeaderRecord;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import org.junit.Test;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Optional;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Component
public class NilRequestMsgHeadersTest {

    private final NilRequestMsgHeaders nilRequestMsgHeaders;

    public NilRequestMsgHeadersTest() {

        this.nilRequestMsgHeaders = new NilRequestMsgHeaders();
    }

    @Test
    public void shouldCreateDefaultHeader() {
        //Given
        ServiceRequestContext serviceRequestContextMock = mock(ServiceRequestContext.class);

        Locale locale = Locale.forLanguageTag("sv");
        String userId = "UserId";
        String applicationId = "ApId";
        String country = "SE";
        String requestId = "RequestId";
        String sessionId = "SessionId";
        LocalDateTime now = LocalDateTime.now();
        long timestamp = now.toInstant(ZoneOffset.UTC).toEpochMilli();

        when(serviceRequestContextMock.getLanguage()).thenReturn(Optional.of(locale));
        when(serviceRequestContextMock.getUserId()).thenReturn(Optional.of(userId));
        when(serviceRequestContextMock.getApplicationId()).thenReturn(Optional.of(applicationId));
        when(serviceRequestContextMock.getCountry()).thenReturn(Optional.of(country));
        when(serviceRequestContextMock.getRequestId()).thenReturn(Optional.of(requestId));
        when(serviceRequestContextMock.getSessionId()).thenReturn(Optional.of(sessionId));
        when(serviceRequestContextMock.getTimeStamp()).thenReturn(timestamp);


        NilRequestMsgHeaderRecord nilRequestMsgHeaderRecord = new PaymentToRecord();

        //When
        nilRequestMsgHeaders.withHeaderConfiguration(serviceRequestContextMock, nilRequestMsgHeaderRecord);

        //Then
        assertThat("TimeToLive was not initialized correctly", nilRequestMsgHeaderRecord.getTimeToLive(), is(NilRequestMsgHeaders.TIME_TO_LIVE));
        assertThat("UserId was not initialized correctly", nilRequestMsgHeaderRecord.getUserId(), is(userId));
        assertThat("ApplicationId was not initialized correctly", nilRequestMsgHeaderRecord.getApplicationId(), is(applicationId));
        assertThat("Country was not initialized correctly", nilRequestMsgHeaderRecord.getCountry(), is(country));
        assertThat("RequestId was not initialized correctly", nilRequestMsgHeaderRecord.getRequestId(), is(requestId));
        assertThat("SessionId was not initialized correctly", nilRequestMsgHeaderRecord.getSessionId(), is(sessionId));
        assertThat("Timestamp was not initialized correctly", nilRequestMsgHeaderRecord.getUtcTime(), is(now.format(DateTimeFormatter.ISO_DATE_TIME)));

    }

    private static class PaymentToRecord extends M8MessageHeaderRequestRecord {
        private PaymentToRecord() {
            super("Cp278");
            setBytes(new byte[M8MessageHeaderRequestRecord.SIZE]);
            initialize();
        }
    }
}
