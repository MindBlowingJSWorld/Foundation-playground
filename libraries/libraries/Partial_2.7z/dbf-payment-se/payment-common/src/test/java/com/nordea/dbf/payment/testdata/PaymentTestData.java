package com.nordea.dbf.payment.testdata;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.api.model.accountkey.AccountPrefixType;
import org.apache.commons.lang.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;

public class PaymentTestData {

    private static LocalDateTime localDateTime = LocalDateTime.now().minusYears(1);

    // A simple wrapper class to create on unique ID based on from account and date for each payment.
    public static String getId(AccountKey from, AccountKey to) {
        localDateTime = localDateTime.plusDays(1);

        // Household and corporate ID's are different, adopt according to the annotated user OR if it is a crossborder domestic.
        // FIXME: This should be solved in a better way..
        if (from.equals(TestData.CORPORATE_OWN_ACCOUNT)) {
            // "id": "2015-09-14-15.15.31.586099",
            return localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH.mm.ss.A")).substring(0, 26);
        } else if (from.getPrefix() == AccountPrefixType.NAID
                && (to.getPrefix() == AccountPrefixType.IBAN || to.getPrefix() == AccountPrefixType.CROSSBORDER)) {
            return from.getAccountNumber().getAccountNumber().substring(0, 11) + localDateTime.format(DateTimeFormatter.ofPattern("yyMMddHHmmss"));
        } else {
            return localDateTime.format(DateTimeFormatter.ofPattern("yyMMddHHmmssSSS")).substring(0, 13);
        }
    }

    public static Payment getUnconfirmedPayment(AccountKey from, AccountKey to) {
        Payment payment = new Payment();
        payment.setId(getId(from, to));
        payment.setFrom(from.toString());
        payment.setTo(to.toString());
        payment.setStatus(Payment.StatusEnum.unconfirmed);
        payment.setAmount(BigDecimal.valueOf(100d));
        //FIXME: User java.time.Clock to not have constants rely on each other in different places
        payment.setDue(LocalDate.now().plusDays(5));
        payment.setCurrency("SEK");
        payment.setMessage("A suitable m");
        payment.setOwnMessage("A suitable own m");
        return payment;
    }

    public static Payment getUnconfirmedRecurringPayment(AccountKey from, AccountKey to, PaymentRecurring paymentRecurring) {
        Payment payment = getUnconfirmedPayment(from, to);
        payment.setRecurring(paymentRecurring);
        return payment;
    }

    public static Payment getUnconfirmedCrossborderPayment(AccountKey from, AccountKey to) {
        Payment payment = getUnconfirmedPayment(from, to);
        payment.setCrossBorder(new CrossBorder()
                .setChargePaidBy(CrossBorder.ChargePaidByEnum.payer)
                .setBranchCode("")
                .setAddress(Collections.emptyList())
                .setCentralBankReportingCode("ABC")
                .setSepaReference(StringUtils.repeat("A", 35))
                .setBic("")
                .setBankCountry("SE"))
                .setRecipientName("Danskabolaget AS");
        return payment;
    }

    public static Payment getConfirmedCrossborderPayment(AccountKey from, AccountKey to) {
        Payment payment = getConfirmedPayment(from, to);
        payment.setCrossBorder(new CrossBorder()
                .setChargePaidBy(CrossBorder.ChargePaidByEnum.payer)
                .setBranchCode("")
                .setAddress(Collections.emptyList())
                .setCentralBankReportingCode("")
                .setSepaReference("")
                .setBic("")
                .setBankCountry(""))
                .setRecipientName("Danskabolaget AS");
        return payment;
    }

    public static Payment getConfirmedPayment(AccountKey from, AccountKey to) {
        Payment payment = new Payment();

        payment.setId(getId(from, to));
        payment.setFrom(from.toString());
        payment.setTo(to.toString());
        payment.setStatus(Payment.StatusEnum.confirmed);
        payment.setAmount(BigDecimal.valueOf(100d));
        //FIXME: User java.time.Clock to not have constants rely on each other in different places
        payment.setDue(LocalDate.now().plusDays(5));
        payment.setCurrency("SEK");
        payment.setMessage("A suitable m");
        payment.setOwnMessage("A suitable own m");
        payment.setSpeed(Payment.SpeedEnum.normal);

        return payment;
    }

    public static Payment getRejectedPayment(AccountKey from, AccountKey to) {
        Payment payment = new Payment();

        payment.setId(getId(from, to));
        payment.setFrom(from.toString());
        payment.setTo(to.toString());
        payment.setStatus(Payment.StatusEnum.rejected);
        payment.setAmount(BigDecimal.valueOf(100d));
        //FIXME: User java.time.Clock to not have constants rely on each other in different places
        payment.setDue(LocalDate.now().plusDays(5));
        payment.setCurrency("SEK");
        payment.setMessage("A suitable m");
        payment.setOwnMessage("A suitable own m");
        payment.setSpeed(Payment.SpeedEnum.normal);

        return payment;
    }

    public static Payment getStoppedPayment(AccountKey from, AccountKey to) {
        Payment payment = new Payment();

        payment.setId(getId(from, to));
        payment.setFrom(from.toString());
        payment.setTo(to.toString());
        payment.setStatus(Payment.StatusEnum.stopped);
        payment.setAmount(BigDecimal.valueOf(100d));
        //FIXME: User java.time.Clock to not have constants rely on each other in different places
        payment.setDue(LocalDate.now().plusDays(5));
        payment.setCurrency("SEK");
        payment.setMessage("A suitable m");
        payment.setOwnMessage("A suitable own m");
        payment.setSpeed(Payment.SpeedEnum.normal);

        return payment;
    }
}
