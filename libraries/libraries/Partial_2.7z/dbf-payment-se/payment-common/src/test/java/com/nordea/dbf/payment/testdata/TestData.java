package com.nordea.dbf.payment.testdata;

import com.nordea.dbf.api.model.PaymentRecurring;
import com.nordea.dbf.api.model.accountkey.*;

public class TestData {

    /*
    Section for shared test data.
    */

    // Common
    public static final String TRANSACTION_CURRENCY_CODE = "SEK";

    public static final AccountKey NORDEA_ACCOUNT_KEY =
            new NordeaAccountKey(new AccountNumber("32580077943"), "SEK", "SE");
    public static final AccountKey PG_ACCOUNT = new PgAccountKey(new AccountNumber("3"));
    public static final AccountKey BG_ACCOUNT = new BgAccountKey(new AccountNumber("4"));
    public static final AccountKey CROSSBORDER_ACCOUNT_IBAN =
            AccountKey.fromString("IBAN-DEUTDEFF-DE7430000000032580077945");
    public static final AccountKey NORDEA_ACCOUNT_IBAN =
            AccountKey.fromString("IBAN-NDEASESS-SE7430000000032580077940");
    public static final AccountKey NORDEA_ACCOUNT_NAID =
            AccountKey.fromString("NAID-SE-SEK-32580077940");
    public static final AccountKey NORDEA_ACCOUNT_LBAN =
            AccountKey.fromString("LBAN-SE-32580077940");

    public static final String PROLONG_MONTHLY = "030";
    public static final int RECURRING_NUMBER = 2;
    public static final int RECURRING_FOR_EVER = 999;

    public static final PaymentRecurring PAYMENT_RECURRING = new PaymentRecurring().setCount(RECURRING_NUMBER).setFrequency(1).setInterval(PaymentRecurring.IntervalEnum.monthly).setLastday(false);
    public static final PaymentRecurring PAYMENT_RECURRING_FOR_EVER = new PaymentRecurring().setCount(null).setFrequency(1).setInterval(PaymentRecurring.IntervalEnum.monthly).setLastday(false);


    // Corporate
    public static final long CORPORATE_AGREEMENT_ID = 3257412L;
    public static final AccountKey CORPORATE_OWN_ACCOUNT =
            new NordeaAccountKey(new AccountNumber("1940080100"), "SEK", "SE");
    public static final String CORPORATE_USER_ID = "194008010011";
    public static final AccountKey CROSS_BORDER_ACCOUNT_KEY =
            new CrossBorderAccountKey(new AccountNumber("DK5930004688370736"));
    public static final AccountKey PG_ACCOUNT_KEY =
            new PgAccountKey(new AccountNumber("542675"));
    public static final AccountKey BG_ACCOUNT_KEY =
            new BgAccountKey(new AccountNumber("542675"));

    // Household
    public static final AccountKey HOUSEHOLD_OWN_ACCOUNT = AccountKey.fromString("NAID-SE-SEK-32580077944");
    public static final AccountKey HOUSEHOLD_OWN_ACCOUNT_OTHER = AccountKey.fromString("NAID-SE-SEK-32580077945");
    public static final String HOUSEHOLD_USER_ID = "193008010011";
    public static final long HOUSEHOLD_AGREEMENT_ID = 2172332;
    public static final AccountKey NORWEGIAN_ACCOUNT_SEPA =
            new SepaAccountKey("NDEASESS", new AccountNumber("SE6560870520711"));
    public static final AccountKey THIRD_PARTY_ACCOUNT =
            new ExternalAccountKey("SE", new AccountNumber("5930004688370736"));
    public static final AccountKey HOUSEHOLD_OWN_ACCOUNT_IBAN_FORMAT =
            AccountKey.fromString("IBAN-NDEASESS-SE7430000000032580077944");
}
