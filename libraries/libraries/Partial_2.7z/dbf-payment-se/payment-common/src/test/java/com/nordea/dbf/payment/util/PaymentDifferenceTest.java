package com.nordea.dbf.payment.util;

import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.util.PaymentDifference;
import com.nordea.dbf.util.Difference;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

/**
 * Created by K306010 on 2016-03-21.
 */
public class PaymentDifferenceTest {
    @Test
    public void shouldNotFindAnyDifferences() {
        Payment input = new Payment();
        input.setId("132");
        input.setFrom("NAID-SE-231");
        input.setTo("NAID-SE-132");
        input.setAmount(BigDecimal.valueOf(3.0));

        Payment source = new Payment();
        source.setId("132");
        source.setFrom("NAID-SE-231");
        source.setTo("NAID-SE-132");
        source.setAmount(BigDecimal.valueOf(3.0));

        assertTrue(PaymentDifference.compareWithOriginal(input, source).equals(Difference.none()));
    }

    @Test
    public void shouldFindOneDifferenceBasedOnInput() {
        Payment input = new Payment();
        input.setId("132");
        input.setFrom("NAID-SE-231");
        input.setTo("NAID-SE-132");
        input.setAmount(BigDecimal.valueOf(2.0));

        Payment source = new Payment();
        source.setId("132");
        source.setFrom("NAID-SE-231");
        source.setTo("NAID-SE-132");
        source.setAmount(BigDecimal.valueOf(3.0));

        assertFalse(PaymentDifference.compareWithOriginal(input, source).equals(Difference.none()));
        for (Difference.Property property : PaymentDifference.compareWithOriginal(input, source).properties()) {
            assertEquals(property.getName().toString(), "amount");
        }

    }


    @Test
    public void shouldNotFindOneDifferenceWhenOnlyPresentInSource() {
        Payment input = new Payment();
        input.setId("132");
        input.setFrom("NAID-SE-231");
        input.setTo("NAID-SE-132");
        input.setAmount(BigDecimal.valueOf(3.0));

        Payment source = new Payment();
        source.setId("132");
        source.setFrom("NAID-SE-231");
        source.setTo("NAID-SE-132");
        source.setAmount(BigDecimal.valueOf(3.0));
        source.setCurrency("SEK");

        assertTrue(PaymentDifference.compareWithOriginal(input, source).equals(Difference.none()));
    }
}
