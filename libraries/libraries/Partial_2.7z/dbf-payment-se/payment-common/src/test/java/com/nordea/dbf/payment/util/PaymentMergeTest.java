package com.nordea.dbf.payment.util;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.util.PaymentDifference;
import com.nordea.dbf.payment.common.util.PaymentMerge;
import com.nordea.dbf.util.Difference;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

/**
 * Created by K306010 on 2016-03-21.
 */
public class PaymentMergeTest {
    @Test
    public void shouldMergePaymentCompletely() {
        Payment input = new Payment();
        input.setId("132");
        input.setFrom("NAID-SE-231");
        input.setTo("NAID-SE-132");
        input.setAmount(BigDecimal.valueOf(3.0));

        Payment source = new Payment();
        source.setId("132");
        source.setFrom("NAID-SE-111");
        source.setTo("NAID-SE-222");
        source.setAmount(BigDecimal.valueOf(2.0));

        Payment result = PaymentMerge.merge(input, source);

        assertTrue(PaymentDifference.compareWithOriginal(input, result).equals(Difference.none()));
    }

    @Test
    public void shouldMergeAndAmendBasedOnInput() {
        Payment input = new Payment();
        input.setId("132");
        input.setFrom("NAID-SE-231");
        input.setTo("NAID-SE-132");
        input.setAmount(BigDecimal.valueOf(3.0));
        input.setCurrency("SEK");

        Payment source = new Payment();
        source.setId("132");
        source.setFrom("NAID-SE-231");
        source.setTo("NAID-SE-132");
        source.setAmount(BigDecimal.valueOf(3.0));

        Payment result = PaymentMerge.merge(input, source);
        assertEquals(result.getId(), input.getId());
        assertEquals(result.getFrom(), input.getFrom());
        assertEquals(result.getTo(), input.getTo());
        assertEquals(result.getAmount(), input.getAmount());
        assertEquals(result.getCurrency(), input.getCurrency());       
    }

    @Test
    public void shouldMergeInnerObjectsAsWell() {
        Payment input = new Payment();
        input.setId("132");
        input.setFrom("NAID-SE-231");
        input.setTo("NAID-SE-132");
        input.setAmount(BigDecimal.valueOf(3.0));
        input.setCurrency("SEK");
        CrossBorder crossBorder = new CrossBorder();
        crossBorder.setBankCountry("SE");
        crossBorder.setBankName("Test bank");
        crossBorder.setBic("SEEESS");
        input.setCrossBorder(crossBorder);

        Payment source = new Payment();
        source.setId("132");
        source.setFrom("NAID-SE-231");
        source.setTo("NAID-SE-132");
        source.setAmount(BigDecimal.valueOf(3.0));
        CrossBorder crossBorder2 = new CrossBorder();
        crossBorder2.setBankCountry("SE");
        crossBorder2.setBic("SEEESS");
        crossBorder2.setBranchCode("DK");
        source.setCrossBorder(crossBorder2);


        Payment result = PaymentMerge.merge(input, source);

        assertFalse(PaymentDifference.compareWithOriginal(input, source).equals(Difference.none()));

        CrossBorder resultCrossBorder = result.getCrossBorder();
        assertEquals(resultCrossBorder.getBankCountry(), crossBorder.getBankCountry());
        assertEquals(resultCrossBorder.getBankName(), crossBorder.getBankName());
        assertEquals(resultCrossBorder.getBic(), crossBorder.getBic());
        assertEquals(resultCrossBorder.getBranchCode(), crossBorder2.getBranchCode());
    }
}
