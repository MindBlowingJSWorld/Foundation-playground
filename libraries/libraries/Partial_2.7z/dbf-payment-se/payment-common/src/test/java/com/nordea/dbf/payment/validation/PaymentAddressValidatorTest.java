package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentAddressValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Arrays;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentAddressValidatorTest {

    private int maxLength = 10;
    private Validator validator = new PaymentAddressValidator(maxLength);

    @Test
    public void shouldSucceed() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder().setAddress(Arrays.asList("123", "123", "", "345")));
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldAcceptNullCrossborder() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldAcceptEmptyAddress() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder());
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFail() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder().setAddress(Arrays.asList("123", "123456789123", "", "345")));
        Optional<Error> error = validator.validate(payment);
        assertEquals(1, error.get().getDetails().size());
    }

    @Test
    public void shouldFailTwice() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder().setAddress(Arrays.asList("123", "123456789123", "123123123123123", "345")));
        Optional<Error> error = validator.validate(payment);
        assertEquals(2, error.get().getDetails().size());
    }
}
