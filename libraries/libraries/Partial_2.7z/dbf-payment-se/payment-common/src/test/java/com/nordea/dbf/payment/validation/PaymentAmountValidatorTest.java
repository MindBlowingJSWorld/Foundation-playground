package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentAmountValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentAmountValidatorTest {

    private Validator validator = new PaymentAmountValidator();

    @Test
    public void shouldSucceed() {
        Payment payment = new Payment();
        payment.setAmount(new BigDecimal(12));
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFail() {
        for (BigDecimal bigDecimal : Arrays.asList(new BigDecimal(0), new BigDecimal(-1))) {
            Payment payment = new Payment();
            payment.setAmount(bigDecimal);
            Optional<Error> error = validator.validate(payment);
            assertEquals(1, error.get().getDetails().size());
        }
    }
}
