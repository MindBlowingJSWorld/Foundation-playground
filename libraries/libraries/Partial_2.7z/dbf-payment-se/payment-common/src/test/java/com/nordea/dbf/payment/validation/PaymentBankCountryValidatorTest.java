package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentAddressValidator;
import com.nordea.dbf.payment.common.validators.PaymentBankCountryValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Arrays;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentBankCountryValidatorTest {

    private int maxLength = 2;
    private Validator validator = new PaymentBankCountryValidator(maxLength);

    @Test
    public void shouldSucceed() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder().setBankCountry("SE"));
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFail() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder().setBankCountry("SWEDEN"));
        Optional<Error> error = validator.validate(payment);
        assertEquals(1, error.get().getDetails().size());
    }

    @Test
    public void shouldAcceptNullCrossborder() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldAcceptEmpty() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder());
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }
}
