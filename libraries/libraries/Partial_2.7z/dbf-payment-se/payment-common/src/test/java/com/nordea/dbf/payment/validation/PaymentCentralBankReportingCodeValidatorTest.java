package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.CrossBorder;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentCentralBankReportingCodeValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentCentralBankReportingCodeValidatorTest {

    private int maxLength = 3;
    private Validator validator = new PaymentCentralBankReportingCodeValidator(maxLength);

    @Test
    public void shouldSucceed() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder().setCentralBankReportingCode("123"));
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFail() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder().setCentralBankReportingCode("123546789123"));
        Optional<Error> error = validator.validate(payment);
        assertEquals(1, error.get().getDetails().size());
    }

    @Test
    public void shouldAcceptNullCrossborder() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldAcceptEmpty() {
        Payment payment = new Payment();
        payment.setCrossBorder(new CrossBorder());
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }
}
