package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentDueValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentDueValidatorTest {

    private Validator validator = new PaymentDueValidator();

    @Test
    public void shouldSucceed() {
        for (LocalDate date : Arrays.asList(LocalDate.now(), LocalDate.now().plusYears(1).minusDays(1))) {
            Payment payment = new Payment();
            payment.setDue(date);
            Optional<Error> error = validator.validate(payment);
            assertEquals(false, error.isPresent());
        }
    }

    @Test
    public void shouldFail() {
        for (LocalDate date : Arrays.asList(LocalDate.now().minusDays(1), LocalDate.now().plusYears(1), LocalDate.MAX, LocalDate.MIN)) {
            Payment payment = new Payment();
            payment.setDue(date);
            Optional<Error> error = validator.validate(payment);
            assertEquals(true, error.isPresent());
        }
    }
}
