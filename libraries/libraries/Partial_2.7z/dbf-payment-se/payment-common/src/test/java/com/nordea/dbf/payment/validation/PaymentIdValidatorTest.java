package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentIdEmptyValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentIdValidatorTest {

    private Validator validator = new PaymentIdEmptyValidator();

    @Test
    public void shouldAllowEmpty() {
        Payment payment = new Payment();
        payment.setId("");
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldAllowNull() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFail() {
        Payment payment = new Payment();
        payment.setId("id");
        Optional<Error> error = validator.validate(payment);
        assertEquals(true, error.isPresent());
    }
}
