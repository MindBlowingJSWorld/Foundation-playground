package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentMessageValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentMessageValidatorTest {

    private int minLength = 5;
    private int maxLength = 10;
    private Validator validator = new PaymentMessageValidator(minLength, maxLength);

    @Test
    public void shouldSucceed() {
        Payment payment = new Payment();
        payment.setMessage("123456");
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFail() {
        Payment payment = new Payment();
        payment.setMessage("123");
        Optional<Error> error = validator.validate(payment);
        assertEquals(1, error.get().getDetails().size());
    }

    @Test
    public void shouldAcceptNull() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldAcceptEmpty() {
        Payment payment = new Payment();
        payment.setMessage("");
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }
}
