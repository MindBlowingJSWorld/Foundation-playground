package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentOwnMessageValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentOwnMessageValidatorTest {

    private int minLength = 5;
    private int maxLength = 10;
    private Validator validator = new PaymentOwnMessageValidator(minLength, maxLength);

    @Test
    public void shouldSucceed() {
        Payment payment = new Payment();
        payment.setOwnMessage("123456");
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFail() {
        Payment payment = new Payment();
        payment.setOwnMessage("123");
        Optional<Error> error = validator.validate(payment);
        assertEquals(1, error.get().getDetails().size());
    }

    @Test
    public void shouldNotAcceptNull() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(1, error.get().getDetails().size());
    }

    @Test
    public void shouldNotAcceptEmpty() {
        Payment payment = new Payment();
        payment.setOwnMessage("");
        Optional<Error> error = validator.validate(payment);
        assertEquals(1, error.get().getDetails().size());
    }
}
