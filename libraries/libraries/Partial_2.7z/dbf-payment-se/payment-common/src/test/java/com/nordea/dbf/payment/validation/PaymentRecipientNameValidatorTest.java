package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentRecipientNameValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentRecipientNameValidatorTest {

    private Validator validator = new PaymentRecipientNameValidator();

    @Test
    public void shouldFailEmpty() {
        Payment payment = new Payment();
        payment.setRecipientName("");
        Optional<Error> error = validator.validate(payment);
        assertEquals(true, error.isPresent());
    }

    @Test
    public void shouldFailNull() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(true, error.isPresent());
    }

    @Test
    public void shouldSucceed() {
        Payment payment = new Payment();
        payment.setRecipientName("id");
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }
}
