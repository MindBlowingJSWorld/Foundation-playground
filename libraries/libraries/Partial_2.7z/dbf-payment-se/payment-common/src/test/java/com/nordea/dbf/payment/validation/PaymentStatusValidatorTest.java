package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentStatusValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentStatusValidatorTest {

    private List<Payment.StatusEnum> statuses = Collections.singletonList(Payment.StatusEnum.unconfirmed);
    private Validator validator = new PaymentStatusValidator(statuses);

    @Test
    public void shouldAllow() {
        Payment payment = new Payment();
        payment.setStatus(statuses.get(0));
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFailNull() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(true, error.isPresent());
    }

    @Test
    public void shouldFail() {
        Payment payment = new Payment();
        payment.setStatus(Payment.StatusEnum.confirmed);
        Optional<Error> error = validator.validate(payment);
        assertEquals(true, error.isPresent());
    }
}
