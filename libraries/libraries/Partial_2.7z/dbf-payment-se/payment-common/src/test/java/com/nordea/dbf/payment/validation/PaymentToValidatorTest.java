package com.nordea.dbf.payment.validation;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.payment.common.validators.PaymentToValidator;
import com.nordea.dbf.payment.common.validators.Validator;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertEquals;

public class PaymentToValidatorTest {

    private Validator validator = new PaymentToValidator();

    @Test
    public void shouldSucceed() {
        Payment payment = new Payment();
        payment.setTo("from");
        Optional<Error> error = validator.validate(payment);
        assertEquals(false, error.isPresent());
    }

    @Test
    public void shouldFailNull() {
        Payment payment = new Payment();
        Optional<Error> error = validator.validate(payment);
        assertEquals(true, error.isPresent());
    }

    @Test
    public void shouldFailEmpty() {
        Payment payment = new Payment();
        payment.setTo("");
        Optional<Error> error = validator.validate(payment);
        assertEquals(true, error.isPresent());
    }
}
