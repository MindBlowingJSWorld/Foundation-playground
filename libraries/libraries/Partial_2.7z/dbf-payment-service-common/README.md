# Service

## Purpose

The DBF microservices are split into two type of components :
 * The integration component - integrates with various backend solutions like LX services, OSB services, REST services, etc.
 * **The microservice component** - exposes the REST API

This is the microservice component and contains a spring boot project which can be run within or outside a web application container.

This microservice is used to expose the following methods -

<<Your methods go here>>


## Getting started

You can run the microservice on the embedded jetty container by running the Application.

Note - Please set the VM argument -Dcom.nordea.environmenttype=LOCAL while running the Application.

You can run the integration test cases provided as is, as the above mentioned argument has already been set in the BeforeClass setting for the integration test.


For authentication you can use the postman scripts getTokenDPPhase1 and getTokenDPPhase2 found here:
https://confluence.oneadr.net:8443/display/DBNS/API+Design+Guide
