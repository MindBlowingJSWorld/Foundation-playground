package com.nordea.dbf.config;

import com.codahale.metrics.JmxReporter;
import com.codahale.metrics.MetricRegistry;
import com.nordea.dbf.concurrent.Handover;
import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.mock.PaymentServiceMock;
import com.nordea.dbf.service.PaymentService;
import com.nordea.mep.core.RxContext;
import com.nordea.mep.core.integration.http.RxRestClient;
import com.nordea.mep.core.metrics.RxMetrics;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;


import java.util.concurrent.TimeUnit;

/**
 * Created by G90073 on 06-04-2016.
 */

@Configuration
@PropertySource(value = {"classpath:payments-nordic.properties", "classpath:xfm_${com.nordea.environmenttype}.properties",
        "file:/${com.nordea.midas.appProperties}/payments-nordic.properties", "classpath:common.properties"}, ignoreResourceNotFound = true)
public class ServiceConfig {

    @Autowired
    private Environment environment;


    @Bean
    public MethodValidationPostProcessor methodValidationPostProcessor() {
        return new MethodValidationPostProcessor();
    }


    @Bean
    MetricRegistry metricRegistry() {
        MetricRegistry metricRegistry = new MetricRegistry();

        JmxReporter.forRegistry(metricRegistry)
                .convertRatesTo(TimeUnit.SECONDS)
                .convertDurationsTo(TimeUnit.MILLISECONDS)
                .build()
                .start();

        return metricRegistry;
    }

    @Bean
    RxMetrics rxMetrics(MetricRegistry metricRegistry) {
        return new RxMetrics(metricRegistry);
    }

    @Bean
    RxContext rxContext() {
        return RxContext.from(() -> {
            Handover handover = ThreadContext.DEFAULT.createHandover();
            return handover::in;
        });
    }

    @Bean
    public AsyncRestTemplate asyncRestTemplate() {

        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        //Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("CCCProxy.root4.net", 8080));
        //requestFactory.setProxy(proxy);

        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(10);
        executor.initialize();

        requestFactory.setTaskExecutor(executor);
        return new AsyncRestTemplate(requestFactory);
    }


    @Bean
    public RxRestClient restClient(AsyncRestTemplate restTemplate, RxContext context, RxMetrics metrics,
                                   // TODO
                                   @Value("${com.nordea.mep.npay.gw.rest.timeout:20000}") int socketTimeout) {
        return new RxRestClient(restTemplate, context, metrics, socketTimeout);
    }


    @Primary
    @ConditionalOnProperty("nordic.payments.mock.integration.enabled")
    @Bean
    public PaymentService mockPaymentService() {
        return new PaymentServiceMock(environment);
    }

}
