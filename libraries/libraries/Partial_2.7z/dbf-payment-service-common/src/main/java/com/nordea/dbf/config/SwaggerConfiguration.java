package com.nordea.dbf.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.async.DeferredResult;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import java.time.LocalDate;

import static java.util.Collections.singletonList;

@Configuration
public class SwaggerConfiguration {

    //Swagger enables hypermedia configuration which tries to inject primaryObjectMapper and fails if there's many with no matching bean name.
    @Bean
    @Autowired
    public ObjectMapper primaryObjectMapper(ObjectMapper _halObjectMapper) {
        return _halObjectMapper;
    }

    @Bean
    public Docket apiInfo() {
        return new Docket(DocumentationType.SWAGGER_2).apiInfo(new ApiInfoBuilder().title("Nordic Payments API Gateway")
                .description("TODO")
                .contact("Corporate Payments Team")
                .build())
                .select()
                .apis(RequestHandlerSelectors.any())
                .build()
                .pathMapping("/")
                .directModelSubstitute(LocalDate.class, String.class)
                .genericModelSubstitutes(DeferredResult.class)
                .useDefaultResponseMessages(false)
                .globalResponseMessage(RequestMethod.GET, singletonList(new ResponseMessageBuilder().code(500)
                        .message("500 message")
                        .responseModel(new ModelRef("Error"))
                        .build()));
    }
}
