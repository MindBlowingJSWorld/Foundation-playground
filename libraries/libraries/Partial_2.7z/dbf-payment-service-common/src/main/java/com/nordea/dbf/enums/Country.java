package com.nordea.dbf.enums;

/**
 * Created by g90073 on 07-04-2016.
 */
public enum Country {
  SWEDEN("SE"),FINLAND("FI"),DENMARK("DK"),NORWAY("NO");
  private final String value;
  Country(String countryCode){
    value = countryCode;
  }
  public String getValue() {
    return value;
  }
}
