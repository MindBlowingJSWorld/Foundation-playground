package com.nordea.dbf.mappers;

import com.nordea.dbf.model.*;


import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Z481804 on 18.3.2016.
 */
public class DataMapper {

    /*private final String decimalNumberFormat = "#.00";

    public Transaction convertTransaction(MenigaTransaction menigaTransaction) {
        Transaction transaction = new Transaction();
        transaction.setId(menigaTransaction.getBankId());
        transaction.setAmount(convertNumber(menigaTransaction.getAmount()));
        transaction.setCurrency("TODO");
        transaction.setDate(menigaTransaction.getDate());
        transaction.setEntryDate(menigaTransaction.getDueDate());
        transaction.setFrom("TODO");
        transaction.setTo("TODO");
        transaction.setMessage("TODO");
        transaction.setTitle(menigaTransaction.getText());
        transaction.setInterestDate(LocalDate.of(9999, 3, 18));
        transaction.setOriginalAmount(convertNumber(menigaTransaction.getAmountInCurrency()));
        transaction.setOriginalCurrency(menigaTransaction.getCurrency());
        transaction.setReference("TODO");
        transaction.setStatus(null);
        transaction.setType(null);

        XFMTransactionData xfmData = new XFMTransactionData();
        xfmData.setAccountId(menigaTransaction.getAccountId());
        xfmData.setCategoryId(menigaTransaction.getCategoryId());
        xfmData.setHasUncertainCategorization(menigaTransaction.isHasUncertainCategorization());
        xfmData.setHasUserClearedCategoryUncertainty(menigaTransaction.isHasUserClearedCategoryUncertainty());
        xfmData.setXfmTransactionId(menigaTransaction.getId());
        xfmData.setDetectedCategories(convertMenigaCategoryScores(menigaTransaction.getDetectedCategories()));

        Merchant merchant = new Merchant();
        merchant.setId(null); // TODO
        merchant.setName("TODO");
        merchant.setAddress("TODO");

        xfmData.setMerchant(merchant);
        transaction.setXfmData(xfmData);
        return transaction;
    }

    public Category convertCategory(MenigaCategory menigaCategory) {
        Category category = new Category();
        category.setId(menigaCategory.getId());
        category.setName(menigaCategory.getName());
        category.setParentCategoryId(menigaCategory.getParentCategoryId());
        category.setOrderId(menigaCategory.getOrderId());
        category.setType(menigaCategory.getCategoryType());
        return category;
    }


    private String convertNumber(Double number) {
        if (number == null) return null;
        DecimalFormat df = new DecimalFormat(decimalNumberFormat);
        return df.format(number);
    }

    private List<CategoryScore> convertMenigaCategoryScores(List<MenigaCategoryScore> menigaCategoryScores) {
        if (menigaCategoryScores == null) return null;
        return menigaCategoryScores.stream().map(menigaCategoryScore -> {
            CategoryScore score = new CategoryScore();
            score.setCategoryId(menigaCategoryScore.getCategoryId());
            score.setScore(menigaCategoryScore.getScore());
            return score;
        }).collect(Collectors.toList());
    }*/
}
