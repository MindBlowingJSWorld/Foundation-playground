package com.nordea.dbf.mappers;

import com.nordea.dbf.model.*;
import com.nordea.dbf.model.foundation.FoundationPayment;


import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by G90048 on 06-04-2016.
 */
public class PaymentDataMapper {
  public Payment convertPayment(FoundationPayment foundationPayment) {
    Payment payment = new Payment();
    PaymentPermissions paymentPermissions = new PaymentPermissions();
    PaymentModifyFields paymentModifyFields = new PaymentModifyFields();

    payment.setId(foundationPayment.getId());
    payment.setAmount(""+foundationPayment.getAmount());
    payment.setFrom(foundationPayment.getFrom());
    payment.setTo(foundationPayment.getTo());
    payment.setRecipientName(foundationPayment.getRecipientName());
    payment.setStatus(foundationPayment.getStatus());
    payment.setType(foundationPayment.getType());
    payment.setDue(foundationPayment.getDue());
    payment.setCurrency(foundationPayment.getCurrency());
    payment.setExtraMessage(foundationPayment.getExtraMessage());

    // // TODO : Mapping work pending for Permissions and Modigy maodels
    paymentPermissions.setDelete(true);
    paymentPermissions.setCopy(true);

    paymentModifyFields.setFrom(true);
    paymentModifyFields.setTo(true);
    paymentModifyFields.setAmount(true);
    paymentModifyFields.setDue(true);
    paymentModifyFields.setMessage(true);
    paymentModifyFields.setRecurringCount(true);
    paymentModifyFields.setRecurringInterval(true);
    paymentModifyFields.setRecurringRepeats(true);
    paymentModifyFields.setRecurringLastday(true);
    paymentModifyFields.setType(true);

    paymentPermissions.setModify(paymentModifyFields);
    payment.setPermissions(paymentPermissions);

    return payment;
  }
}
