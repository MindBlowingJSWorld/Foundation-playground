package com.nordea.dbf.mock;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.nordea.dbf.model.Payment;
import com.nordea.dbf.service.PaymentService;

import org.springframework.core.env.Environment;
import rx.Observable;

import javax.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import static jdk.nashorn.internal.runtime.regexp.joni.Config.log;

/**
 * Created by g90073 on 07-04-2016.
 */
public class PaymentServiceMock implements PaymentService  {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private String mockPath;

    public PaymentServiceMock(Environment environment) {
        this.mockPath = environment.getProperty("mock.path");
    }


    @Override
    public Observable<List<Payment>> getPayments(String authorizationHeader,@Nullable String serviceRequestContext) {
      try {
        InputStream stream = getClass().getClassLoader().getResourceAsStream(mockPath + "Payments.json");
        return Observable.just(objectMapper.readValue(stream,
            objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, Payment.class)));
      } catch (IOException e) {
        e.printStackTrace();
        return Observable.error(new RuntimeException());
      }
    }
}
