package com.nordea.dbf.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Created by G90073 on 06.04.2016.
 */

@Data
@ApiModel(value = "Payment")
public class Payment extends ModelBase {

    @ApiModelProperty(value = "ID of payment", required = false, example = "xxx")
    private String id;

    @ApiModelProperty(value = "Amount of the payment in local currency", required = false, example = "99.99")
    private String amount;

    @ApiModelProperty(value = "Details of 'from where' the payment was done i.e. source", required = false, example = "IBAN-DABADKKK-DK5930004688370736")
    private String from;

    @ApiModelProperty(value = "Details of 'to where' the payment was done i.e. target", required = false, example = "IBAN-DABADKKK-DK5930004688370736")
    private String to;

    @ApiModelProperty(value = "Recipient Name", required = false, example = "Name")
    private String recipientName;

    @ApiModelProperty(value = "Status of the transaction, e.g if it has been billed yet", required = false, example = "billed")
    private String status;

    @ApiModelProperty(value = "Type of the transaction", required = false, example = "self_service")
    private String type;

    @ApiModelProperty(value = "Base ISO currency code", required = false, example = "SEK")
    private String currency;

    @ApiModelProperty(value = "Payment due date", required = false, example = "2016-01-01")
    private String due;

    @ApiModelProperty(value = "Extra message", required = false, example = "xxx")
    private String extraMessage;

    @ApiModelProperty(value = "Permissions", required = false, example = "xxx")
    @JsonProperty("permissions")
    protected PaymentPermissions permissions;  // In case of SE

    public static enum StatusEnum {
      unconfirmed, confirmed, paid, onhold, cancelled, rejected, inprogress, undefined;
      private StatusEnum() {}
    }

    public static enum TypeEnum {
      normal,owntransfer,thirdparty,pgbg;
      private TypeEnum() {}
    }

  // TODO : date Mapping and country specific response mappjng.
}
