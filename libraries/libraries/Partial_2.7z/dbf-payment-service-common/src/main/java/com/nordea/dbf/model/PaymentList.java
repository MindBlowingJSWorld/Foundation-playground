package com.nordea.dbf.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * Created by g90073 on 06.04.2016.
 */
@Data
@ApiModel("PaymentList")
public class PaymentList {

    @ApiModelProperty(value = "List of payments", required = false)
    private List<Payment> payments;
}
