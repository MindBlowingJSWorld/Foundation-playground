package com.nordea.dbf.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Created by G90048 on 08.04.2016.
 */
@Data
@ApiModel(value = "PaymentModifyFields")
public class PaymentModifyFields {

  @ApiModelProperty(value = "from filed modify permission", required = false, example = "true")
  @JsonProperty("from")
  private Boolean from;

  @ApiModelProperty(value = "to field modify permission", required = false, example = "true")
  @JsonProperty("to")
  private Boolean to;

  @ApiModelProperty(value = "amount field modify permission", required = false, example = "true")
  @JsonProperty("amount")
  private Boolean amount;

  @ApiModelProperty(value = "due field modify permission", required = false, example = "true")
  @JsonProperty("due")
  private Boolean due;

  @ApiModelProperty(value = "message field modify permission", required = false, example = "true")
  @JsonProperty("message")
  private Boolean message;

  @ApiModelProperty(value = "recurringCount field modify permission", required = false, example = "true")
  @JsonProperty("recurring_count")
  private Boolean recurringCount;

  @ApiModelProperty(value = "recurringInterval field modify permission", required = false, example = "true")
  @JsonProperty("recurring_interval")
  private Boolean recurringInterval;

  @ApiModelProperty(value = "recurringRepeats field modify permission", required = false, example = "true")
  @JsonProperty("recurring_repeats")
  private Boolean recurringRepeats;

  @ApiModelProperty(value = "recurringLastday field modify permission", required = false, example = "true")
  @JsonProperty("recurring_lastday")
  private Boolean recurringLastday;

  @ApiModelProperty(value = "type field modify permission", required = false, example = "true")
  @JsonProperty("type")
  private Boolean type;
}
