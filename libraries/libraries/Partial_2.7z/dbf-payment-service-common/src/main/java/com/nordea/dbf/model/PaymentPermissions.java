package com.nordea.dbf.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * Created by G90048 on 08.04.2016.
 */
@Data
@ApiModel(value = "PaymentPermissions")
public class PaymentPermissions {

  @ApiModelProperty(value = "delete permission", required = false, example = "true")
  @JsonProperty("delete")
  private Boolean delete;

  @ApiModelProperty(value = "copy permission", required = false, example = "true")
  @JsonProperty("copy")
  private Boolean copy;

  @ApiModelProperty(value = "Fields level modification permissions", required = false, example = "xxx")
  @JsonProperty("modify")
  private PaymentModifyFields modify;
}
