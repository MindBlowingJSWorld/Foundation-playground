package com.nordea.dbf.model;

import lombok.Data;
import lombok.experimental.Builder;

/**
 * Created by G90073 on 06.04.2016.
 */
@Data
@Builder
public class TokenRequest {

    private String grant_type;
    private String username;
    private String client_id;
    private String scope;
    private String auth_method;
    private String country;
    private String personalcode;
    private String payLoad;

}
