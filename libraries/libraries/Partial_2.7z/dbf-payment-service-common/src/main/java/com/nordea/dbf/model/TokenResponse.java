package com.nordea.dbf.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.joda.time.DateTime;

/**
 * Created by G90073 on 06.04.2016.
 */
@Data
public class TokenResponse {

    @JsonProperty("token")
    private String accessTokenSweden;

    @JsonProperty("access_token")
    private String accessTokenFinland;

    public String getAccessTokenSweden() {
      return accessTokenSweden;
    }

    public void setAccessTokenSweden(String accessTokenSweden) {
      this.accessTokenSweden = accessTokenSweden;
    }

    public String getAccessTokenFinland() {
      return accessTokenFinland;
    }

    public void setAccessTokenFinland(String accessTokenFinland) {
      this.accessTokenFinland = accessTokenFinland;
    }
    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public DateTime getCreated() {
        return created;
    }

    public void setCreated(DateTime created) {
        this.created = created;
    }

    private String refreshToken;
    public DateTime created;

}
