package com.nordea.dbf.model.foundation;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nordea.dbf.model.ModelBase;
import lombok.Data;

/**
 * Created by G90048 on 07.04.2016.
 */

@Data
public class FoundationPayment extends ModelBase {
  private String id;
  private String from;
  private String to;
  @JsonProperty("recipient_name")
  private String recipientName;
  private Double amount;
  private String status;
  private String type;
  private String due;
  private String currency;
  @JsonProperty("extra_messages")
  private String extraMessage;
  // TODO : Above properties are as per FI response. Need to handle SE response properties.
}
