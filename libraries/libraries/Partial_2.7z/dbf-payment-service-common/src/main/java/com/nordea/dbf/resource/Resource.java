package com.nordea.dbf.resource;

import com.nordea.dbf.model.*;

import com.nordea.dbf.service.PaymentService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;
import rx.Observable;
import javax.annotation.Nullable;
import javax.annotation.Nullable;
import java.util.List;


@RestController
@RequestMapping("/corporate")
@Api(value = "/corporate", description = "API to get consolidated data for corporate payments.")
@Validated
public class Resource {

    public PaymentService service;

    @Autowired
    public Resource(PaymentService service) {
        this.service = service;
    }

    @RequestMapping(value = "/payments", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Get all payments")
    public DeferredResult<List<Payment>> getPayments(@RequestHeader(value = "Authorization") String authorizationHeader,
        @RequestHeader(value = "X-DBF-ServiceRequestContext") @Nullable String serviceRequestContext)  {

      final DeferredResult<List<Payment>> result = new DeferredResult<>();
      Observable<List<Payment>> paymentList = service.getPayments(authorizationHeader,serviceRequestContext);
      paymentList.subscribe(result::setResult, result::setErrorResult);
      return result;
    }
}
