package com.nordea.dbf.service;

import com.nordea.dbf.model.*;
import rx.Observable;
import javax.annotation.Nullable;

import java.util.List;

/**
 * Created by G90073 on 06.04.2016.
 */
public interface PaymentService {
    Observable<List<Payment>> getPayments(String authorizationHeader,@Nullable String serviceRequestContext);
}
