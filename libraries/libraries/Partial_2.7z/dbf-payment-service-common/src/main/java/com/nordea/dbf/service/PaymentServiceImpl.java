package com.nordea.dbf.service;

import com.nordea.dbf.model.Payment;
import com.nordea.dbf.model.TokenRequest;
import com.nordea.dbf.model.TokenResponse;
import com.nordea.dbf.model.foundation.FoundationPayment;
import com.nordea.dbf.enums.Country;
import com.nordea.mep.core.integration.http.RxRestClient;
import com.nordea.dbf.mappers.PaymentDataMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;
import rx.Observable;
import rx.functions.Action1;
import rx.functions.Func1;
import rx.functions.Func2;

import javax.annotation.Nullable;
import java.net.URI;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

@Slf4j
@Component
public class PaymentServiceImpl implements PaymentService {
  private RxRestClient restClient;
  private RxRestClient restClient1; // TODO : Adding new restClient1 to avoid paging of results.
  private String sePaymentsUrl;
  private String fiPaymentsUrl;

  @Autowired
  public PaymentServiceImpl(Environment environment, RxRestClient restClient,RxRestClient restClient1) {
    this.restClient = restClient;
    this.restClient1 = restClient1;
    this.fiPaymentsUrl = environment.getProperty("payments-fi.url");
    this.sePaymentsUrl = environment.getProperty("payments-se.url");
  }

  private URI createPaymentURI(String country) {
    UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.newInstance().scheme("http");
    if (Country.FINLAND.getValue().equalsIgnoreCase(country)){
      return uriComponentsBuilder.host(fiPaymentsUrl).build().toUri();
    } else {
      return uriComponentsBuilder.host(sePaymentsUrl).build().toUri();
    }
  }

  @Override
  public Observable<List<Payment>> getPayments(String authorizationHeader,@Nullable String serviceRequestContext) {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Authorization", authorizationHeader);
    if(serviceRequestContext != null) {
      headers.add("X-DBF-ServiceRequestContext", serviceRequestContext);
    }
    return  Observable.zip(
        getPaymentsFI(authorizationHeader, serviceRequestContext),getPaymentsSE(),
        new Func2<Payment[], Payment[], List<Payment>>() {
          @Override
          public List<Payment> call(Payment[] paymentsFI, Payment[] paymentsSE) {
            List<Payment> mergedList = new ArrayList<>();
            List<Payment> paymentsListFI = Arrays.asList(paymentsFI);
            List<Payment> paymentsListSE = Arrays.asList(paymentsSE);
            mergedList.addAll(paymentsListFI);
            mergedList.addAll(paymentsListSE);
            // System.out.println(" =========== paymentsListFI.size() >>>>>>>>>>>>>>>>>>> " + (paymentsListFI==null ? 0 : paymentsListFI.size()));
            // System.out.println(" =========== paymentsListSE.size() >>>>>>>>>>>>>>>>>>> " + (paymentsListSE==null ? 0 : paymentsListSE.size()));
            return mergedList;
          }
        });
  }

  private Observable<Payment[]> getPaymentsFI(String authorizationHeader, String serviceRequestContext) {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Authorization", authorizationHeader);
    if(serviceRequestContext != null) {
      headers.add("X-DBF-ServiceRequestContext", serviceRequestContext);
    }
    return restClient.get(createPaymentURI(Country.FINLAND.getValue()), headers, Payment[].class);
  }

  private Observable<Payment[]> getPaymentsSE() {
    return createHeadersSweden().flatMap(httpHeaders -> restClient1.get(createPaymentURI(Country.SWEDEN.getValue()), httpHeaders, Payment[].class));
  }


  /*Start- This code generates the Swedish Token and pass the same  to Swedish foundation service and gets the data*/
  /****************************************************************************************************************************/
  private Observable<HttpHeaders> createHeadersSweden() {
    HttpHeaders headers = new HttpHeaders();
    headers.add("Content-Type", "application/json");
    headers.add("X-DBF-ServiceRequestContext","{\"applicationId\":\"TEST\", \"country\":\"SE\", \"channelId\":\"RBO\",\"sessionId\":\"test-1434367358854\"}");

    TokenRequest tokenRequest = TokenRequest.builder().build();
    HttpEntity<TokenRequest> tokenRequestHttpEntity = new HttpEntity<>(tokenRequest, headers);

    URI uri = URI.create("http://ap-micros1t.oneadr.net/security/oauth2/servicetoken");

    return restClient.post(uri, tokenRequestHttpEntity.getHeaders(), "{\"sessionId\":\"test-1460382312328\",\"personId\":\"194008010011\",\"country\":\"SE\",\"channel\":\"RBO\",\"authenticationMethod\":\"BANKID\",\"grants\":{\"agreement\":2172332}}" ,
        TokenResponse.class).map(tokenResponse -> {
      System.out.println("Inside sweden header");
      headers.add("Authorization", "Bearer " + tokenResponse.getAccessTokenSweden());
      HttpEntity<String> requestEntity = new HttpEntity<>("", headers);
      return headers;
    });
  }

    /*End - This code generates the Swedish Token and pass the same  to Swedish foundation service and gets the data*/
  /****************************************************************************************************************************/
}


