package com.nordea.dbf;

import com.google.common.collect.ImmutableMap;
import com.jayway.restassured.response.Header;
import com.nordea.dbf.security.ClaimEncryptor;
import com.nordea.dbf.test.security.Authorization;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.AsyncRestTemplate;

import java.io.IOException;
import java.net.URL;
import java.util.Collections;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.iterableWithSize;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = MockApplication.class)
@WebAppConfiguration
@IntegrationTest
@Slf4j
public class ApplicationIntegrationTest {

    @Autowired
    private AsyncRestTemplate asyncRestTemplate;

    @Autowired
    private Environment environment;

    @Value("${local.server.port}")
    private int port;

    private URL base;
    private String menigaUrl;
    private MockRestServiceServer mockServer;

    @Autowired
    // TODO This will be removed when encryption fixed to core
    ClaimEncryptor claimEncryptor;

    @BeforeClass
    public static void setupEnvironment() throws Exception {
        System.setProperty("com.nordea.environmenttype", "TEST");
    }

    @Before
    public void setUp() throws Exception {
        this.base = new URL("http://localhost:" + port + "/xfm");
        menigaUrl = "http://" + environment.getProperty("meniga.url");
        mockServer = createMockServerWithAuthentication();
    }

    @Test
    @Ignore("Will be implemented later, only draft for now")
    public void testGetAllTags() throws Exception {
        String tagsResponse = IOUtils.toString(this.getClass().getResourceAsStream("resources/Tags.json"));
        mockServer.expect(requestTo(menigaUrl + "/tags"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withSuccess(tagsResponse, MediaType.APPLICATION_JSON));

        given().accept("application/json")
                .header(defaultBearerAuth())
                .when()
                .get(base + "/tags")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("tags.size()", is(3))
                .body("id[0]", equalTo(2))
                .body("name[0]", equalTo("food"))
                .body("id[1]", equalTo(3))
                .body("name[1]", equalTo("car"))
                .body("id[2]", equalTo(4))
                .body("name[2]", equalTo("bike"));
    }

    @Test
    @Ignore("Will be implemented later, only draft for now")
    public void testGetAllCategories() throws Exception {
        String categoriesResponse = IOUtils.toString(this.getClass().getResourceAsStream("resources/Categories.json"));
        mockServer.expect(requestTo(menigaUrl + "/categories"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withSuccess(categoriesResponse, MediaType.APPLICATION_JSON));

        given().accept("application/json")
                .header(defaultBearerAuth())
                .when()
                .get(base + "/categories")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("categories.size()", is(3))
                .body("id[0]", is(81))
                .body("name[0]", equalTo("Alcohol"))
                .body("otherCategoryName[0]", equalTo("drinks"))
                .body("parentCategoryId[0]", is(118))
                .body("isPublic[0]", equalTo(true))
                .body("isFixedExpenses[0]", equalTo(false))
                .body("categoryType[0]", equalTo("Expenses"))
                .body("categoryRank[0]", equalTo("NotUseful"))
                .body("budgetGenerationType[0]", is(12))
                .body("categoryContextId[0]", equalTo(null))
                .body("orderId[0]", is(0))
                .body("displayData[0]", equalTo("e636"))
                .body("id[1]", is(118))
                .body("name[1]", equalTo("Drinks"))
                .body("id[2]", is(134))
                .body("name[2]", equalTo("Art & Fine Items"));
    }

    @Test
    @Ignore("Will be implemented later, only draft for now")
    public void testGetAllTransactions() throws Exception {
        String transactionsResponse = IOUtils.toString(
                this.getClass().getResourceAsStream("resources/Transactions.json"));
        mockServer.expect(requestTo(menigaUrl + "/transactions?take=30"))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withSuccess(transactionsResponse, MediaType.APPLICATION_JSON));

        given().accept("application/json")
                .header(defaultBearerAuth())
                .when()
                .get(base + "/transactions")
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("transactions.size()", is(2))
                .body("id[0]", is(4960))
                .body("parentIdentifier[0]", equalTo("83df1f9a-1f27-40a3-b44b-34fdb8abf836"))
                .body("amount[0]", equalTo("-9"))
                .body("originalAmount[0]", equalTo("-19"))
                .body("tags[0].size()", is(1))
                .body("tags[0][0]", equalTo("food"))
                .body("commentModel[0]", iterableWithSize(1))
                .body("commentModel[0][0].id", is(0))
                .body("commentModel[0][0].personId", is(0))
                .body("commentModel[0][0].comment", equalTo("string"))
                .body("commentModel[0][0].createdDate", equalTo("2016-03-01T08:28:41.667Z"))
                .body("commentModel[0][0].modifiedDate", equalTo("2016-03-01T08:28:41.667Z"))
                .body("categoryId[0]", equalTo(36))
                .body("date[0]", equalTo("2016-02-24T00:00:00"))
                .body("originalDate[0]", equalTo("2016-02-24T00:00:00"))
                .body("timestamp[0]", equalTo(null))
                .body("text[0]", equalTo("Texaco"))
                .body("originalText[0]", equalTo("Texaco"))
                .body("data[0]", equalTo(""))
                .body("hasUncertainCategorization[0]", equalTo(false))
                .body("accountId[0]", equalTo(28))
                .body("mcc[0]", equalTo(5541))
                .body("detectedCategories[0].size()", is(3))
                .body("detectedCategories[0].score[0]", is(0))
                .body("detectedCategories[0].categoryId[0]", is(36))
                .body("detectedCategories[0].score[1]", is(0))
                .body("detectedCategories[0].categoryId[1]", is(83))
                .body("detectedCategories[0].score[2]", is(0))
                .body("detectedCategories[0].categoryId[2]", is(37))
                .body("currency[0]", equalTo(null))
                .body("amountInCurrency[0]", equalTo(null))
                .body("dataFormat[0]", equalTo(7))
                .body("merchantId[0]", equalTo(null))
                .body("parsedData[0]", equalTo(null))
                .body("bankId[0]", equalTo(1009))
                .body("insertTime[0]", equalTo("2016-02-24T11:47:03.86"))
                .body("balance[0]", equalTo(null))
                .body("categoryChangedTime[0]", equalTo(null))
                .body("changedByRule[0]", equalTo(null))
                .body("changedByRuleTime[0]", equalTo(null))
                .body("counterpartyAccountIdentifier[0]", equalTo(null))
                .body("dueDate[0]", equalTo(null))
                .body("lastModifiedTime[0]", equalTo(null))
                .body("metaDatas[0]", iterableWithSize(0))
                .body("userData[0]", equalTo(null))
                .body("isFlagged[0]", equalTo(true))
                .body("isSplitChild[0]", equalTo(false))
                .body("isUncleared[0]", equalTo(false))
                .body("isRead[0]", equalTo(true))
                .body("isMerchant[0]", equalTo(true))
                .body("id[1]", is(4961));
    }

    @Test
    @Ignore("Will be implemented later")
    public void testGetTransactionsByProductIds() throws IOException {
        String productIds = "30,20";
        String transactionsResponse = IOUtils.toString(
                this.getClass().getResourceAsStream("resources/Transactions.json"));
        mockServer.expect(requestTo(menigaUrl + "/transactions?accountIds=" + productIds))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withSuccess(transactionsResponse, MediaType.APPLICATION_JSON));

        given().accept("application/json")
                .header(defaultBearerAuth())
                .when()
                .get(base + "/transactions?productIds=" + productIds)
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("transactions.size()", is(2));
        mockServer.verify();
    }

    private Header defaultBearerAuth() {
        return new Header("Authorization", "Bearer " + createToken("user"));
    }

    private String createToken(String userId) {
        long iat = System.currentTimeMillis() / 1000;
        long exp = iat + 1000;
        ImmutableMap claims = ImmutableMap.builder()
                .put("sub", "n/a")
                .put("uid", claimEncryptor.encrypt(userId))
                .put("iss", "dbf_authentication")
                .put("client_id", "npay")
                .put("scope", Collections.singleton("ns"))
                .put("exp", exp)
                .put("am", "mta")
                .put("al", "3")
                .put("ch", "dbf")
                .put("nbf", iat)
                .put("iat", iat)
                .put("c", "FI")
                .put("ssn", claimEncryptor.encrypt("1111111111"))
                .put("sid", "unique_session_id")
                .put("grants", Collections.singletonMap("agreement", 12345L))
                .build();
        return Authorization.fromPayload(claims);
    }

    private MockRestServiceServer createMockServerWithAuthentication() throws Exception {
        String tokenResponse = IOUtils.toString(this.getClass().getResourceAsStream("resources/Token.json"));
        MockRestServiceServer mockServer = MockRestServiceServer.createServer(asyncRestTemplate);
        mockServer.expect(requestTo(menigaUrl + "/authentication"))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withSuccess(tokenResponse, MediaType.APPLICATION_JSON));
        return mockServer;
    }
}