package com.nordea.dbf;

import com.nordea.dbf.annotation.EnableServiceConfiguration;
import com.nordea.dbf.audit.annotation.EnableAuditing;
import com.nordea.dbf.security.annotation.EnableServiceSecurity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by Z481804 on 1.3.2016.
 */
@SpringBootApplication
@EnableServiceConfiguration
@EnableServiceSecurity
@EnableAuditing
public class MockApplication {

    public static void main(String[] args) {
        SpringApplication.run(MockApplication.class, args);
    }
}
