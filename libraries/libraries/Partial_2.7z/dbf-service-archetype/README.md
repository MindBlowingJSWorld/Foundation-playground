# DBF Service Archetype

## Purpose

This Archetype is used to generate the microservice component which exposes the services over REST

## Getting Started

Install this archetype into your repository using
```
mvn clean install
```

Alternatively, you can use the installed version of this archetype from nexus, though notice that if you refer to a snapshot version of the archetype 
you need to have the nexus snapshot repository configured in your local maven settings file.

## Usage

This archetype can be used to generate your service component using the command

```
$ mvn archetype:generate -DarchetypeGroupId=com.nordea.dbf -DarchetypeArtifactId=dbf-service-archetype -DarchetypeVersion=1.0-SNAPSHOT -DgroupId=<<your group id>> -DartifactId=<<your artifact id>> -Dversion=<<your artifact version>>
```

Alternatively, you can use just the basic command and interactively provide the other parameters using

```
$ mvn archetype:generate -DarchetypeGroupId=com.nordea.dbf -DarchetypeArtifactId=dbf-service-archetype -DarchetypeVersion=1.0-SNAPSHOT
```