package ${package}.config;

import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * ConfigurationProvider for ServiceConsumer
 *
 */
@Component
public class ServiceConsumerConfigurationProvider implements ConfigurationProvider {

  @Autowired
  private Environment env;

  @Override public String getProperty(String key, String defaultValue) {
    return env.getProperty(key, defaultValue);
  }

  @Override public String getProperty(String key) {
    return env.getProperty(key);
  }
}