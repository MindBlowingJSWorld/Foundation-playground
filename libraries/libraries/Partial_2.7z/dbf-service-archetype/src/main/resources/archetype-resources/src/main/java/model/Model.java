#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Model {
  private Integer modelId;

  @JsonProperty("id")
  public Integer getModelId() {
    return modelId;
  }

  @JsonProperty("id")
  public void setModelId(Integer modelId) {
    this.modelId = modelId;
  }

  //Model properties and methods go here
}
