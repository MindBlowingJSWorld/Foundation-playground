#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.service;

import ${package}.model.Model;
import rx.Observable;
import org.springframework.stereotype.Component;

@Component
public class Service {

  public Observable<Model> getModel() {
    // Replace this call with invocation of facade method which returns an Observable
    Model model = new Model();
    model.setModelId(13);
    return Observable.just(model);
  }

}
