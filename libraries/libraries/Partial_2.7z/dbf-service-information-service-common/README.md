# Service

Provides Service Information - messages about the availability of online services