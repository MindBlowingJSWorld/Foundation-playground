package com.nordea.ndf;

import com.mangofactory.swagger.plugin.EnableSwagger;
import com.nordea.dbf.annotation.EnableServiceConfiguration;
import com.nordea.dbf.security.annotation.EnableServiceSecurity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;

@SpringBootApplication
@EnableSwagger
@EnableServiceConfiguration
@EnableServiceSecurity
public class Application extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(Application.class);
	}

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
}
