package com.nordea.ndf.config;

import com.nordea.dbf.integration.configuration.ServiceContextConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

/**
 * Created by k293170 on 2015-04-07.
 */

@Configuration
@PropertySource(value = {"classpath:model.properties", "classpath:model_${com.nordea.environmenttype}.properties",
        "file:/${com.nordea.midas.appProperties}/model.properties", "classpath:common.properties"}, ignoreResourceNotFound = true)
public class ServiceConfig {

    @Autowired
    private Environment environment;

    @Bean
    public ServiceContextConfiguration contextConfiguration() {
        ServiceContextConfiguration contextConfiguration = new ServiceContextConfiguration();
        contextConfiguration.setTechnicalUserId(environment.getProperty("technicalUserId"));
        contextConfiguration.setClientType(environment.getProperty("clientType"));
        contextConfiguration.setTest(environment.getProperty("test"));
        contextConfiguration.setClientComponent(environment.getProperty("clientComponent"));
        contextConfiguration.setAccountingUnit(environment.getProperty("accountingUnit"));
        contextConfiguration.setOfficeMode(environment.getProperty("officeMode"));
        return contextConfiguration;
    }
}
