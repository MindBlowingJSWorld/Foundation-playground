package com.nordea.ndf.model;

public class InfoLinks {

    private String content;

    public InfoLinks(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }
}