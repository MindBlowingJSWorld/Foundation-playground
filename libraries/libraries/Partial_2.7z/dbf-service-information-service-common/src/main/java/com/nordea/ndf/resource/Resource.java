package com.nordea.ndf.resource;

import com.nordea.ndf.model.InfoLinks;
import com.nordea.ndf.model.SystemStatus;
import com.nordea.ndf.service.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.async.DeferredResult;

import javax.servlet.http.HttpServletResponse;

import static com.nordea.dbf.messaging.Observables.deferredResultOf;

@RestController
public class Resource {

    @Autowired
    public Service service;

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @RequestMapping("/systemstatus")
    public DeferredResult<ResponseEntity<SystemStatus>> getSystemStatus(@RequestParam("country") String country,
                                                                        @RequestParam("language") String language,
                                                                        @RequestParam("platform") String platform,
                                                                        HttpServletResponse response) {
        logger.debug(String.format("Request for system status country %s, language %s, platform %s", country, language, platform));

        return deferredResultOf(service.getSystemStatus(country, language).map(systemStatus -> {
            // service information is public and can be cached up to 30 seconds in Netscaler and browser
            response.setHeader("Cache-Control", "public, max-age=30");
            return new ResponseEntity<>(systemStatus, HttpStatus.OK);
        }));
    }

    @RequestMapping("/infolinks")
    public DeferredResult<ResponseEntity<InfoLinks>> getInfoLinks(@RequestParam("country") String country,
                                                                  @RequestParam("language") String language,
                                                                  HttpServletResponse response) {
        logger.debug(String.format("Request for info links country %s, language %s", country, language));

        return deferredResultOf(service.getInfoLinks(country, language).map(infoLinks -> {
            // info links are public and can be cached up to 30 seconds in Netscaler and browser
            response.setHeader("Cache-Control", "public, max-age=30");
            return new ResponseEntity<>(infoLinks, HttpStatus.OK);
        }));
    }
}
