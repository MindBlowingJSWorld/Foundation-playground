package com.nordea.ndf.service;

import com.nordea.ndf.config.ServiceConsumerConfigurationProvider;
import com.nordea.ndf.model.InfoLinks;
import com.nordea.ndf.model.SystemStatus;
import com.nordea.ndf.tridion.InfoLinksService;
import com.nordea.ndf.wcms.WCMSService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import rx.Observable;

import java.util.HashMap;
import java.util.Map;

@Component
public class Service {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private ServiceConsumerConfigurationProvider config;
    private Map<String, SystemStatus> channelStatusCache = new HashMap<>();
    private Map<String, InfoLinks> infolinksCache = new HashMap<>();
    private final String[] keys = {
            "DK-en", "DK-da",
            "FI-en", "FI-fi", "FI-sv",
            "NO-en", "NO-nb",
            "SE-en", "SE-sv"};

    @Autowired
    WCMSService wcmsService;
    @Autowired
    InfoLinksService infoLinksService;

    public Observable<SystemStatus> getSystemStatus(String country, String language) {

        SystemStatus intenalSystemStatus = getIntenalSystemStatus(country, language);

        if (intenalSystemStatus == null) {
            return Observable.error(new RuntimeException("No status available"));
        }
        return Observable.just(intenalSystemStatus);
    }

    public Observable<InfoLinks> getInfoLinks(String country, String language) {

        InfoLinks internalInfolinks = getInternalInfoLinks(country, language);

        if (internalInfolinks == null) {
            return Observable.error(new RuntimeException("No infolinks available"));
        }
        return Observable.just(internalInfolinks);
    }

    @Scheduled(fixedDelay = 60000)
    public void refreshStatus() {
        logger.debug("Refreshing system status");
        for (String key : keys) {
            String channelId = config.getProperty(key + "-channelid");
            if (channelId == null) continue;
            WCMSService.SystemStatusResponse statusResponse = wcmsService.fetchSystemStatus(channelId);
            SystemStatus systemStatus = new SystemStatus();
            systemStatus.setHeadline(statusResponse.getHeadline());
            systemStatus.setContent(statusResponse.getContent());
            channelStatusCache.put(key, systemStatus);
        }
    }

    @Scheduled(fixedDelay = 60000)
    public void refreshInfolinks() {
        logger.debug("Refreshing infolinks");
        for (String key : keys) {
            String channelId = config.getProperty("login-" + key);
            if (channelId == null) continue;
            infolinksCache.put(key, infoLinksService.getInfoLinks(channelId));
        }
    }

    public SystemStatus getIntenalSystemStatus(String country, String language) {
        String key = makeKey(country, language);
        return channelStatusCache.get(key);
    }

    public InfoLinks getInternalInfoLinks(String country, String language) {
        String key = makeKey(country, language);
        return infolinksCache.get(key);
    }

    private String makeKey(String country, String language) {
        return country.toUpperCase() + "-" + language.toLowerCase();
    }
}
