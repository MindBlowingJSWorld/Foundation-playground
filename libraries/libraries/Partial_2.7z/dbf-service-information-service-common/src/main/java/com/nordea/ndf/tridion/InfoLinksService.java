package com.nordea.ndf.tridion;

import com.nordea.ndf.model.InfoLinks;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;

/**
 * Service fetching content from Tridion
 */
@Component
public class InfoLinksService {

    private static final Logger logger = LoggerFactory.getLogger(InfoLinksService.class);

    @Value("${proxy.port}")
    private int proxyPort;
    @Value("${proxy.host}")
    private String proxyHost;

    @Value("${proxy:false}")
    private boolean proxy;

    public RestTemplate restTemplate() {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        if(proxy) {
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
            requestFactory.setProxy(proxy);
        }
        return new RestTemplate(requestFactory);
    }

    public InfoLinks getInfoLinks(String url) {
        try {
            URI uri = new URI(url);
            ResponseEntity<Object[]> response = restTemplate().getForEntity(uri, Object[].class);
            return new InfoLinks(new TridionContentModel(response.getBody()).getContent().get(0).getText());
        } catch (Exception e) {
            logger.error("getInfoLinks url", e);
        }
        return null;
    }
}

