package com.nordea.ndf.tridion;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Model for Tridion content based on the Application Content Schema
 * <p/>
 * For this service we only use the labels (appLabels)
 */
public class TridionContentModel {

    private final Map<String, Object> applicationContentMap = new LinkedHashMap();

    public TridionContentModel(Object[] objects) {
        for (Object o : objects) {
            if (o instanceof Map) {
                Map h = (Map) o;
                if ("Application Content".equalsIgnoreCase((String) h.get("Schema"))) {
                    applicationContentMap.putAll(h);
                }
            }
        }
        if (applicationContentMap == null) {
            throw new RuntimeException("Can't construct TridionContentModel - no Application Content Schema found");
        }
    }

    public List<Content> getContent() {
        List<Content> contents = new ArrayList<>();
        for (Map<String, List<String>> lm : (List<Map<String, List<String>>>) applicationContentMap.get("appContent")) {
            for (Map.Entry<String, List<String>> e : lm.entrySet())
                contents.add(new Content(e.getValue()));
        }
        return contents;
    }

    public static class Content {
        private String text;

        public Content(List<String> text) {
            this.text = "";
            for (String s : text) {
                this.text += s;
            }
        }

        public String getText() {
            return text;
        }
    }
}