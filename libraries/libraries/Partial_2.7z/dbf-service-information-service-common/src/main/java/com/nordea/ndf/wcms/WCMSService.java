package com.nordea.ndf.wcms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;

/**
 * Service to fetch status content from WCMS
 *
 * Content is fetched every minute and cached here
 * WCMS is accessed using a http proxy
 */

@Component
public class WCMSService {
    private static final Logger logger = LoggerFactory.getLogger(WCMSService.class);
    private static String SYSTEM_STATUS_URL = "http://wcms.nordea.com/Sitemod/nordea_all/modules/systemstatusv2/GetMessage.ashx?IncludeHTMLContext=0&updatecache=1&channelid=";

    @Value("${proxy.port}")
    private int proxyPort;
    @Value("${proxy.host}")
    private String proxyHost;



    public RestTemplate restTemplate() {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();

        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, proxyPort));
        requestFactory.setProxy(proxy);

        return new RestTemplate(requestFactory);
    }

    public SystemStatusResponse fetchSystemStatus(String channelId) {
        try {
            RestTemplate restClient = restTemplate();
            ResponseEntity<String> forEntity = restClient.getForEntity(SYSTEM_STATUS_URL + channelId, String.class);

            String json = forEntity.getBody();
            json = json.substring(1, json.length() - 1);//Trim jsonp () wrapping

            ObjectMapper mapper = new ObjectMapper();

            SystemStatusResponse response = mapper.readValue(json, SystemStatusResponse.class);
            return response;
        } catch (Exception e) {
            logger.error("fetchSystemStatus", e);
            return null;
        }
    }

    /*
    ({"id":"00000000-0000-0000-0000-000000000000",
            "html":"<table cellspacing=\"0\" cellpadding=\"0\" style=\"margin-bottom: 15px;\"><tbody><tr><td style=\"width:20px;\"><img src=\"/sitemod/upload/Root/e_guidelines/icons/info_information_s.gif\" alt=\"\" /></td><td style=\"color:#C93100;font-weight:bold;\">Nordea Digital are down</td></tr><tr><td></td><td style=\"padding-top: 3px;\">nfnwelfnøwekfmøwemfwemfmwfmwe'fw'ef,wef,øwe</td></tr></tbody></table>",
            "headline":"Nordea Digital are down",
            "content":"nfnwelfnøwekfmøwemfwemfmwfmwe'fw'ef,wef,øwe"})
*/
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SystemStatusResponse {
        @JsonProperty("Headline")
        String headline;
        @JsonProperty("Content")
        String content;

        public String getHeadline() {
            return headline;
        }

        public void setHeadline(String headline) {
            this.headline = headline;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }
    }
}

