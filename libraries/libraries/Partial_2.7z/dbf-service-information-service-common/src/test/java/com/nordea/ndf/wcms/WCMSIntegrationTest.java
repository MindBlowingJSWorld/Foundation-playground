package com.nordea.ndf.wcms;

import static org.junit.Assert.assertNotNull;

import com.nordea.ndf.Application;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
@IntegrationTest({"server.port=0"})
public class WCMSIntegrationTest {

	@BeforeClass
	public static void setupEnvironment() throws Exception {
		System.setProperty("com.nordea.environmenttype", "DEV");
	}

	@Autowired
	WCMSService service;


	//Test methods go here
	@Test
	public void testIntegration() throws Exception {
		WCMSService.SystemStatusResponse systemStatus = service.fetchSystemStatus("b723708f-4e77-4c9e-bb54-581b84e0580c");
		assertNotNull(systemStatus);
	}
}

