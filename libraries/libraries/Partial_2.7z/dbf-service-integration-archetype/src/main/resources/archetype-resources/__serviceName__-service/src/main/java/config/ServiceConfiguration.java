#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource(value = {"classpath:${serviceName}.properties", "classpath:${serviceName}_${com.nordea.environmenttype}.properties",
        "file:/${com.nordea.midas.appProperties}/model.properties", "classpath:common.properties"}, ignoreResourceNotFound = true)
public class ServiceConfiguration {

    @Autowired
    private Environment environment;

}
