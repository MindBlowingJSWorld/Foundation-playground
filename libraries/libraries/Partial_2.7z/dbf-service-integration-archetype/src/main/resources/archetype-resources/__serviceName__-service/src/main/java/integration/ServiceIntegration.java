#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.integration;

public class ServiceIntegration {

  public void getIntegration() {
    // Replace this call with invocation of facade method which returns an Observable
  }

}
