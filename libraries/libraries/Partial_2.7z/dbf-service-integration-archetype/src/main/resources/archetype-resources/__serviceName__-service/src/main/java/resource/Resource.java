#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.resource;

import ${package}.model.ServiceModel;
import ${package}.service.Service;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.async.DeferredResult;
import static com.nordea.dbf.messaging.Observables.deferredResultOf;

@RestController
public class Resource {

    @Autowired
    public Service service;

    @RequestMapping("/")
    public DeferredResult<ServiceModel> get() {
        return deferredResultOf(service.getModel());
    }

}
