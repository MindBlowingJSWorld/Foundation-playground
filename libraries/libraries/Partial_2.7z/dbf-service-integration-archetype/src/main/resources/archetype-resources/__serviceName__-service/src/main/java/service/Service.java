#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
package ${package}.service;

import ${package}.model.ServiceModel;
import rx.Observable;
import org.springframework.stereotype.Component;

@Component
public class Service {

  public Observable<ServiceModel> getModel() {
    // Replace this call with invocation of facade method which returns an Observable
    ServiceModel model = new ServiceModel();
    model.setModelId(13);
    return Observable.just(model);
  }

}
