package com.nordea.dbf.account.base.api;

import com.nordea.dbf.api.model.Account;
import com.nordea.dbf.api.model.AccountList;
import com.nordea.dbf.api.model.Transaction;
import com.nordea.dbf.api.model.TransactionList;
import com.nordea.dbf.authz.AccountsAuthZ;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.security.Claims;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.Set;

@Api
@RestController
public interface AccountsApi {

    @ApiOperation(value = "Get all accounts",
            notes = "Returns a list of accounts belonging to a customer.",
            tags = "accounts",
            response = com.nordea.dbf.api.model.AccountList.class
    )
    @RequestMapping(value = "/accounts", method = RequestMethod.GET)
    DeferredResult<AccountList> getAccounts(@ApiParam(hidden = true) ServiceRequestContext serviceRequestContext,
                                            @ApiParam(hidden = true) Claims claims,
                                            @ApiParam(hidden = true) AccountsAuthZ accountsAuthZ,
                                            @RequestParam(value = "fields", required = false)
                                            @ApiParam(value = "Comman seperated list of fiends to limit the result to") Set<String> fields);


    @ApiOperation(value = "Get specific account",
            notes = "Get specific account.",
            tags = "accounts",
            response = com.nordea.dbf.api.model.Account.class
    )
    @RequestMapping(value = "/accounts/{account_id}", method = RequestMethod.GET)
    DeferredResult<Account> getAccount(@ApiParam(value = "The ID of the account the query concerns", required = true)
                                       @PathVariable("account_id") String account_id,
                                       @ApiParam(hidden = true) ServiceRequestContext serviceRequestContext,
                                       @ApiParam(hidden = true) Claims claims,
                                       @ApiParam(hidden = true) AccountsAuthZ accountsAuthZ);

    @ApiOperation(value = "Get account transactions",
            notes = "Returns a list of account transactions on a specific account.",
            tags = "accounts",
            response = com.nordea.dbf.api.model.TransactionList.class
    )
    @RequestMapping(value = "/accounts/{account_id}/transactions", method = RequestMethod.GET)
    DeferredResult<ResponseEntity<TransactionList>> getTransactionList(@PathVariable("account_id")
                                                                       @ApiParam(value = "The ID of the account the query concerns", required = true) String account_id,
                                                                       @RequestParam(value = "start_date", required = false)
                                                                       @ApiParam(value = "The start date of the range of transactions to list. Format as yyyy-mm-dd") String start_date,
                                                                       @RequestParam(value = "end_date", required = false)
                                                                       @ApiParam(value = "The end date of the range of transactions to list. Format as yyyy-mm-dd") String end_date,
                                                                       @RequestParam(value = "page_number", required = false, defaultValue = "0")
                                                                       @ApiParam(value = "The requested page to return.") Integer page_number,
                                                                       @RequestParam(value = "page_size", required = false, defaultValue = "10")
                                                                       @ApiParam(value = "The number of transactions to return per page. Defaults to 10 with a maximum of 20.") Integer page_size,
                                                                       @RequestParam(value = "sort_by", required = false)
                                                                       @ApiParam(value = "Sorts by supported attribute in ascending or descending order. Append sort_by=[attribute_name]-[asc/desc]. Use attribute_name-desc sort to sort in reverse. Note: Sorted by transaction date desc by default. Meaning, newest transactions are listed first.") String sort_by,
                                                                       @ApiParam(hidden = true) ServiceRequestContext serviceRequestContext,
                                                                       @ApiParam(hidden = true) Claims claims,
                                                                       @ApiParam(hidden = true) AccountsAuthZ accountsAuthZ);


    @ApiOperation(value = "Get specific account transaction based on account id",
            notes = "Get specific account transaction based on account id.",
            tags = "accounts",
            response = com.nordea.dbf.api.model.Transaction.class
    )
    @RequestMapping(value = "/accounts/{account_id}/transactions/{transaction_id}", method = RequestMethod.GET)
    DeferredResult<Transaction> getTransactionDetails(@PathVariable("account_id")
                                                      @ApiParam(value = "The ID of the account the query concerns", required = true) String account_id,
                                                      @PathVariable("transaction_id")
                                                      @ApiParam(value = "The ID of the transaction the query concerns", required = true) String transaction_id,
                                                      @ApiParam(hidden = true) ServiceRequestContext serviceRequestContext,
                                                      @ApiParam(hidden = true) Claims claims,
                                                      @ApiParam(hidden = true) AccountsAuthZ accountsAuthZ);
}