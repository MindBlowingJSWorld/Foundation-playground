package com.nordea.dbf.account.base.errors;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.ErrorDetails;

import java.util.ArrayList;

/**
 * This is the shared list of errors for Accounts micro services
 *
 * Examples usage:
 *
 * <code>
 *      Error error = AccountsErrors.BAD_DATE_FORMAT
 *          .detail("from_date", "Not correct format", "is lenght 0")
 *          .detail("to_ldate", "Not correct format", "Contains illegal character");
 *      throw new PreconditionFailedException(error);
 *
 *      throw new BadRequestException(AccountsErrors.BAD_DATE_FORMAT.error());
 *
 *      throw new BadRequestException(AccountsErrors.BAD_DATE_FORMAT.detail("strt_date","Invalid parameter","Unknown parameter name"));
 * </code>
 */
public enum AccountsErrors {
    BAD_DATE_FORMAT("1","Cannot parse date");

    private String error;
    private String errorDescription;

    AccountsErrors(String error, String errorDescription) {
        this.error = error;
        this.errorDescription = errorDescription;
    }

    public DslError error() {
        DslError error = new DslError();
        error.setError(this.error);
        error.setErrorDescription(errorDescription);
        error.setDetails(new ArrayList<>());
        return error;
    }

    public DslError detail(String param, String moreInfo, String reason) {
        return error().detail(param,moreInfo,reason);
    }

    public static class DslError extends Error{
        public DslError detail(String param, String moreInfo, String reason){
            ErrorDetails errorDetail = new ErrorDetails();
            errorDetail.setParam(param);
            errorDetail.setMoreInfo(moreInfo);
            errorDetail.setReason(reason);
            getDetails().add(errorDetail);
            return this;
        }
    }
}
