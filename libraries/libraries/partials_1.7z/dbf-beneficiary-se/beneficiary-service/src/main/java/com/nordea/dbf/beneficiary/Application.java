package com.nordea.dbf.beneficiary;

import com.nordea.dbf.annotation.EnableServiceConfiguration;
import com.nordea.dbf.audit.annotation.EnableAuditing;
import com.nordea.dbf.beneficiary.config.BeneficiaryConfiguration;
import com.nordea.dbf.security.annotation.EnableServiceSecurity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@EnableServiceConfiguration
@EnableServiceSecurity
@EnableAuditing
@Import (BeneficiaryConfiguration.class)
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}
