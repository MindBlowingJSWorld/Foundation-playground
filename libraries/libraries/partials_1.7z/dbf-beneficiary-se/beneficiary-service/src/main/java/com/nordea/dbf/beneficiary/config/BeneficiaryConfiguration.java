package com.nordea.dbf.beneficiary.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationConfig;
import com.nordea.dbf.agreement.facade.CorporateAgreementFacade;
import com.nordea.dbf.beneficiary.CorporateBeneficiaryFacade;
import com.nordea.dbf.beneficiary.CorporateBeneficiaryFacadeImpl;
import com.nordea.dbf.beneficiary.integration.BeneficiaryListProvider;
import com.nordea.dbf.beneficiary.integration.BeneficiaryProvider;
import com.nordea.dbf.beneficiary.integration.corporate.RetrieveCorporateBeneficiaryList;
import com.nordea.dbf.beneficiary.integration.household.crossborder.PerformActionForCrossBorderBeneficiary;
import com.nordea.dbf.beneficiary.integration.household.domestic.CreateDomesticBeneficiary;
import com.nordea.dbf.beneficiary.integration.household.domestic.DeleteDomesticBeneficiary;
import com.nordea.dbf.beneficiary.integration.household.domestic.RetrieveDomesticBeneficiaryList;
import com.nordea.dbf.beneficiary.integration.household.domestic.UpdateDomesticBeneficiary;
import com.nordea.dbf.customer.agreements.se.AgreementDomainFacade;
import com.nordea.dbf.customer.agreements.se.integration.AgreementTypeConverter;
import com.nordea.dbf.customer.agreements.se.integration.CustomerAgreementIntegrator;
import com.nordea.dbf.customer.agreements.se.integration.CustomerAgreementRequestFactory;
import com.nordea.dbf.integration.configuration.ServiceContextConfiguration;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.dbf.integration.connect.ims.Configurations;
import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.dbf.integration.connect.ims.jca.JCAConnectionSupplier;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnector;
import com.nordea.dbf.integration.connect.ims.m8.M8ImsConnectorImpl;
import com.nordea.dbf.integration.connect.lx.DefaultBackendWrapper;
import com.nordea.dbf.integration.connect.lx.LxConnector;
import com.nordea.dbf.integration.connect.lx.LxConnectorImpl;
import com.nordea.dbf.json.CustomObjectMapper;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import com.nordea.sc.jca.BackendInteractionSpec;
import com.nordea.serviceconsumer.Backend;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import com.nordea.serviceconsumer.providers.JCAConnectionProvider;
import com.nordea.serviceconsumer.providers.defaults.JCAConnectionProviderImpl;
import oracle.jdbc.pool.OracleDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import javax.xml.crypto.Data;
import java.sql.SQLException;

/**
 * Spring configuration, wiring and such
 */
@Configuration
@PropertySource(value = {"classpath:beneficiary_${com.nordea.environmenttype}.properties", "classpath:beneficiary.properties",
        "file:/${com.nordea.midas.appProperties}/common.properties"}, ignoreResourceNotFound = true)

public class BeneficiaryConfiguration {

    @Autowired
    private ConfigurationProvider configurationProvider;

    @Autowired
    private Environment environment;

    // TODO Check if this is centralized
    @PostConstruct
    public void setup() {
        Backend.getBackendCaller().setConfigurationProvider(configurationProvider);
    }

    // Simple helper method to ensure variables are set.
    private String getMandatoryEnvironment(String name) {
        String result = environment.getProperty(name);
        if (result == null || result.isEmpty()) {
            throw new IllegalArgumentException("Required property " + name + " is missing.");
        }
        return result;
    }

    @Bean
    public DataSource dataSource() throws SQLException {
        OracleDataSource dataSource = new OracleDataSource();
        dataSource.setURL(getMandatoryEnvironment("db.url"));
        dataSource.setUser(getMandatoryEnvironment("db.user"));
        dataSource.setPassword(getMandatoryEnvironment("db.password"));
        dataSource.setConnectionCachingEnabled(true);
        return dataSource;
    }

    @Bean
    public LxConnector lxJcaConnector() {
        return new LxConnectorImpl(configurationProvider, "jca", new DefaultBackendWrapper());
    }

    @Bean
    @Autowired
    public CorporateAgreementFacade corporateAgreementFacade(BackendConnector<M8MessageHeaderRequestRecord,
            M8MessageHeaderResponseRecord> backendConnector) {
        return new CorporateAgreementFacade(backendConnector);
    }

    @Bean
    @Autowired
    public AgreementDomainFacade agreementDomainFacade(LxConnector lxConnector) {
        return new AgreementDomainFacade(new CustomerAgreementIntegrator(lxConnector),
                new CustomerAgreementRequestFactory(),
                new AgreementTypeConverter());
    }

    @Bean
    public PerformActionForCrossBorderBeneficiary hhCrossBorderBeneficiaryListFacade(BackendConnector<M8MessageHeaderRequestRecord,
            M8MessageHeaderResponseRecord> backendConnector){
        return new PerformActionForCrossBorderBeneficiary(backendConnector);
    }

    @Bean
    public RetrieveDomesticBeneficiaryList hhDomesticBeneficiaryListFacade(BackendConnector<M8MessageHeaderRequestRecord,
            M8MessageHeaderResponseRecord> backendConnector){
        return new RetrieveDomesticBeneficiaryList(backendConnector);
    }

    @Bean
    public RetrieveCorporateBeneficiaryList corporateBeneficiaryListFacade(BackendConnector<M8MessageHeaderRequestRecord,
            M8MessageHeaderResponseRecord> backendConnector){
        return new RetrieveCorporateBeneficiaryList(backendConnector);
    }

    @Bean
    public CreateDomesticBeneficiary createDomesticBeneficiary(BackendConnector<M8MessageHeaderRequestRecord,
            M8MessageHeaderResponseRecord> backendConnector){
        return new CreateDomesticBeneficiary(backendConnector);
    }

    @Bean
    public DeleteDomesticBeneficiary deleteDomesticBeneficiary(BackendConnector<M8MessageHeaderRequestRecord,
            M8MessageHeaderResponseRecord> backendConnector){
        return new DeleteDomesticBeneficiary(backendConnector);
    }

    @Bean
    public UpdateDomesticBeneficiary updateDomesticBeneficiary(BackendConnector<M8MessageHeaderRequestRecord,
            M8MessageHeaderResponseRecord> backendConnector){
        return new UpdateDomesticBeneficiary(backendConnector);
    }

    @Bean
    @Autowired
    public CorporateBeneficiaryFacade corporateBeneficiaryFacade(DataSource dataSource) {
        return new CorporateBeneficiaryFacadeImpl(dataSource);
    }

    @Bean @Autowired
    public BeneficiaryProvider beneficiaryProvider(RetrieveCorporateBeneficiaryList corporateBeneficiaryListFacade,
                                                   PerformActionForCrossBorderBeneficiary retrieveCrossBorderBeneficiaryList,
                                                   RetrieveDomesticBeneficiaryList retrieveDomesticBeneficiaryList,
                                                   CreateDomesticBeneficiary createDomesticBeneficiary,
                                                   DeleteDomesticBeneficiary deleteDomesticBeneficiary,
                                                   UpdateDomesticBeneficiary updateDomesticBeneficiary,
                                                   CorporateBeneficiaryFacade corporateBeneficiaryFacade){
        return new BeneficiaryListProvider(corporateBeneficiaryListFacade, retrieveCrossBorderBeneficiaryList,
                retrieveDomesticBeneficiaryList, createDomesticBeneficiary, deleteDomesticBeneficiary,
                 updateDomesticBeneficiary, corporateBeneficiaryFacade);
    }

    @Bean
    public ServiceContextConfiguration serviceContextConfiguration() {
        final ServiceContextConfiguration contextConfiguration = new ServiceContextConfiguration();

        contextConfiguration.setTechnicalUserId(environment.getProperty("technicalUserId"));
        contextConfiguration.setClientType(environment.getProperty("clientType"));
        contextConfiguration.setTest(environment.getProperty("test"));
        contextConfiguration.setClientComponent(environment.getProperty("clientComponent"));
        contextConfiguration.setAccountingUnit(environment.getProperty("accountingUnit"));
        contextConfiguration.setOfficeMode(environment.getProperty("officeMode"));

        return contextConfiguration;
    }

    @Bean
    @Autowired
    public M8ImsConnector m8BackendConnector(
            JCAConnectionSupplier jcaConnectionSupplier,
            ImsConfigurationSupplier imsConfigurationSupplier) {
        return new M8ImsConnectorImpl(jcaConnectionSupplier, imsConfigurationSupplier);
    }

    @Bean
    public JCAConnectionSupplier jcaConnectionSupplier(JCAConnectionProvider jcaConnectionProvider,
                                                       ConfigurationProvider configurationProvider) {
        return () -> jcaConnectionProvider.getConnection(configurationProvider);
    }

    @Bean @Autowired
    public ImsConfigurationSupplier imsConfigurationSupplier(ConfigurationProvider configurationProvider) {
        return Configurations.singleton(ImsConfiguration.builder()
                .backendType(BackendInteractionSpec.BackendType.TYPE_GENERIC)
                .serverIdentifier(configurationProvider.getProperty("backend.integrationType"))
                .build());
    }

    @Bean public JCAConnectionProvider jcaConnectionProvider() {
        return new JCAConnectionProviderImpl();
    }

    @Bean public ObjectMapper jacksonObjectMapper() {
        return CustomObjectMapper.builder().dateFormat("yyyy-MM-dd").build();
    }

    @Bean public SerializationConfig serializationConfig() {
        return jacksonObjectMapper().getSerializationConfig();
    }

    @Bean public static PropertySourcesPlaceholderConfigurer properties() {
        return new PropertySourcesPlaceholderConfigurer();
    }
}
