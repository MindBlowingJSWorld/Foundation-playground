package com.nordea.dbf.beneficiary.errorhandling;

import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.http.errorhandling.exception.InternalServerErrorException;
import com.nordea.dbf.http.errorhandling.ErrorResponse;

import javax.annotation.PostConstruct;
import java.util.Map;

public abstract class AbstractLegacyErrorHandler implements LegacyErrorHandler {

    private Map<LegacyErrorAttributes, RuntimeException> errorCodeMappings;

    @PostConstruct
    public void setup() {
        this.errorCodeMappings = getErrorCodeMappings();
    }

    protected abstract Map<LegacyErrorAttributes, RuntimeException> getErrorCodeMappings();

    @Override
    public void handleLegacyError(int kbearb, int krc) {
        if (kbearb != 0 && krc != 0) {
            final LegacyErrorAttributes legacyErrorAttributes = new LegacyErrorAttributes(kbearb, krc);
            final RuntimeException runtimeException = errorCodeMappings.get(legacyErrorAttributes);

            if (runtimeException != null) {
                throw runtimeException;
            } else {
                final ErrorResponse errorResponse = new ErrorResponse("legacy_backend_error", String.format("kbearb_%s_krc_%s", kbearb, krc), "", "");

                throw new InternalServerErrorException(errorResponse);
            }
        }
    }

    protected InternalServerErrorException createSystemError(int kbearb, int krc, String message) {
        return new InternalServerErrorException(new BeneficiaryErrorResponse("database_error", kbearb, krc, message));
    }

    protected BadRequestException createBadRequest(int kbearb, int krc, String message) {
        return new BadRequestException(new BeneficiaryErrorResponse("bad_request", kbearb, krc, message));
    }

    protected InternalServerErrorException createDBError(int kbearb, int krc, String message) {
        return new InternalServerErrorException(new BeneficiaryErrorResponse("database_error", kbearb, krc, message));
    }

}
