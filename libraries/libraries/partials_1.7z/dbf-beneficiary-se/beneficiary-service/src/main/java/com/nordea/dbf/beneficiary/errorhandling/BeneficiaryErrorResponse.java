package com.nordea.dbf.beneficiary.errorhandling;

import com.nordea.dbf.http.errorhandling.ErrorResponse;

/**
 * Payment specific error response with that automatically handles kbearb and krc
 *
 */
public class BeneficiaryErrorResponse extends ErrorResponse {

  public BeneficiaryErrorResponse(String type, int kbearb, int krc, String message) {
    super(type, String.format("kbearb_%s_krc_%s", kbearb, krc), message, "");
  }

}
