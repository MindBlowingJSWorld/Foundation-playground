package com.nordea.dbf.beneficiary.errorhandling;

import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.beneficiary.annotation.HouseholdCrossBorder;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Handler for legacy errors. Contains a mapping from kbearb and krc codes to an exception that can be thrown.
 */
@HouseholdCrossBorder
@Component
public class HHCrossBorderLegacyErrorHandler extends AbstractLegacyErrorHandler {

    @Override
    protected Map<LegacyErrorAttributes, RuntimeException> getErrorCodeMappings() {
        return ImmutableMap.<LegacyErrorAttributes, RuntimeException>builder()
                .put(new LegacyErrorAttributes(4, 30), createBadRequest(4, 30, "Wrong status for update"))
                .put(new LegacyErrorAttributes(4, 32), createBadRequest(4, 32, "The due date is too old"))
                .put(new LegacyErrorAttributes(4, 33), createBadRequest(4, 33, "The cut off time has been passed for chosen date with this currency"))
                .put(new LegacyErrorAttributes(4, 90), createBadRequest(4, 90, "Fraud"))
                .put(new LegacyErrorAttributes(4, 91), createBadRequest(4, 91, "ReceiverAccount blocked due to fraud"))
                .put(new LegacyErrorAttributes(4, 200), createBadRequest(4, 200, "Info error"))
                .put(new LegacyErrorAttributes(4, 231), createBadRequest(4, 231, "Its only allowed to do own transfers if BIC/Swift code starts with 'NDEA'"))
                .put(new LegacyErrorAttributes(4, 301), createBadRequest(4, 301, "Due date can't be more than one year ahead (365 days)"))
                .put(new LegacyErrorAttributes(4, 302), createBadRequest(4, 302, "Execution date missing"))
                .put(new LegacyErrorAttributes(4, 303), createBadRequest(4, 303, "The date of payment is not a banking day"))
                .put(new LegacyErrorAttributes(4, 321), createBadRequest(4, 321, "The currency of the payment is not allowed"))
                .put(new LegacyErrorAttributes(4, 322), createBadRequest(4, 322, "Not allowed to type in amount with decimals for some currencies"))
                .put(new LegacyErrorAttributes(4, 323), createBadRequest(4, 323, "Not allowed to use chosen currency for payments to this specific country"))
                .put(new LegacyErrorAttributes(4, 324), createBadRequest(4, 324, "Payments not allowed to chosen country"))
                .put(new LegacyErrorAttributes(4, 325), createBadRequest(4, 325, "Amount too low"))
                .put(new LegacyErrorAttributes(4, 503), createBadRequest(4, 503, "From account must not be blocked or cancelled"))
                .put(new LegacyErrorAttributes(4, 504), createBadRequest(4, 504, "From account must not be blocked or cancelled"))
                .put(new LegacyErrorAttributes(4, 505), createBadRequest(4, 505, "From account must not be blocked or cancelled"))
                .put(new LegacyErrorAttributes(4, 506), createBadRequest(4, 506, "No funds"))
                .put(new LegacyErrorAttributes(4, 510), createBadRequest(4, 510, "From account must not be blocked or cancelled"))
                .put(new LegacyErrorAttributes(4, 571), createBadRequest(4, 571, "BIC is not given correctly according to current rules"))
                .put(new LegacyErrorAttributes(4, 572), createBadRequest(4, 572, "Clearing code is not given correctly according to current rules"))
                .put(new LegacyErrorAttributes(4, 573), createBadRequest(4, 573, "If Bank code is used either - SWIFT/BIC OR - beneficiary bank's name and beneficiary bank's country must be given"))
                .put(new LegacyErrorAttributes(4, 574), createBadRequest(4, 574, "Bank's country code should be the same as BIC/SWIFT's country code if both values are given by the customer"))
                .put(new LegacyErrorAttributes(4, 576), createBadRequest(4, 576, "If Bank code is used either - SWIFT/BIC OR - beneficiary bank's name and beneficiary bank's country must be given"))
                .put(new LegacyErrorAttributes(4, 578), createBadRequest(4, 578, "BIC is mandatory to some countries (EU/EEA)"))
                .put(new LegacyErrorAttributes(4, 579), createBadRequest(4, 579, "Clearing code is mandatory to some countries"))
                .put(new LegacyErrorAttributes(4, 580), createBadRequest(4, 580, "Contradicted input given about receiver's bank"))
                .put(new LegacyErrorAttributes(4, 590), createBadRequest(4, 590, "Beneficiary name is missing"))
                .put(new LegacyErrorAttributes(4, 591), createBadRequest(4, 591, "Beneficiary account missing"))
                .put(new LegacyErrorAttributes(4, 592), createBadRequest(4, 592, "To account is not given correctly according to current rules"))
                .put(new LegacyErrorAttributes(4, 593), createBadRequest(4, 593, "To account is not given correctly according to current rules"))
                .put(new LegacyErrorAttributes(4, 596), createBadRequest(4, 596, "Some problem with the credit account, closed, blocked or something else"))
                .put(new LegacyErrorAttributes(4, 600), createBadRequest(4, 600, "If the payment is to be sent to a country that requires IBAN, check that the account is given in IBAN format"))
                .put(new LegacyErrorAttributes(4, 602), createBadRequest(4, 602, "ReceiverAccount blocked due to fraud"))
                .put(new LegacyErrorAttributes(4, 700), createBadRequest(4, 700, "Message mandatory for some countries"))
                .put(new LegacyErrorAttributes(4, 710), createBadRequest(4, 710, "Payer of charges information missing"))
                .put(new LegacyErrorAttributes(4, 712), createBadRequest(4, 712, "Payment option \"OUR\" not allowed for outgoing payments"))
                .put(new LegacyErrorAttributes(4, 770), createBadRequest(4, 770, "Reporting code must be valid according to current rules"))
                .put(new LegacyErrorAttributes(4, 772), createBadRequest(4, 772, "Purpose mandatory with this size of amount"))
                .put(new LegacyErrorAttributes(4, 909), createBadRequest(4, 909, "Duplicate"))
                .put(new LegacyErrorAttributes(4, 960), createBadRequest(4, 960, "Amount exceeds the remaining limit in agreement system"))
                .put(new LegacyErrorAttributes(4, 961), createBadRequest(4, 961, "User must have authority in agreement system to use the From account"))
                .put(new LegacyErrorAttributes(4, 968), createBadRequest(4, 968, "Maximum numbers of beneficiaries in beneficiary register is 50"))
                .put(new LegacyErrorAttributes(4, 970), createBadRequest(4, 970, "Duplicate beneficiary: beneficiary which customer tried to add was duplicate"))
                .put(new LegacyErrorAttributes(4, 999), createBadRequest(4, 999, "Unknown validation error"))
                .put(new LegacyErrorAttributes(8, 23), createSystemError(8, 23, "Technical error"))
                .put(new LegacyErrorAttributes(8, 200), createSystemError(8, 200, "Technical error"))
                .put(new LegacyErrorAttributes(8, 964), createSystemError(8, 964, "Technical error (post saknas vid limituppdatering)"))
                .put(new LegacyErrorAttributes(8, 962), createSystemError(8, 962, "Technical error"))
                .put(new LegacyErrorAttributes(8, 963), createSystemError(8, 963, "Technical error"))
                .put(new LegacyErrorAttributes(8, 965), createSystemError(8, 965, "Technical error"))
                .put(new LegacyErrorAttributes(8, 966), createSystemError(8, 966, "Technical error"))
                .put(new LegacyErrorAttributes(8, 967), createSystemError(8, 967, "Technical error"))
                .put(new LegacyErrorAttributes(8, 969), createSystemError(8, 969, "Technical error"))
                .put(new LegacyErrorAttributes(12, 12), createBadRequest(12, 12, "No error, payment list bundle call exceeded legacy output limit. Perform single calls instead"))
                .put(new LegacyErrorAttributes(99, 99), createBadRequest(99, 99, "Field must not start with a colon ':' or hyphen '-'"))
                .build();
    }
}
