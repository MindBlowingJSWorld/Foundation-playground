package com.nordea.dbf.beneficiary.errorhandling;

import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.beneficiary.annotation.HouseholdCrossBorder;
import com.nordea.dbf.beneficiary.annotation.HouseholdDomestic;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Handler for legacy errors. Contains a mapping from kbearb and krc codes to an exception that can be thrown.
 */
@HouseholdDomestic
@Component
public class HHDomesticLegacyErrorHandler extends AbstractLegacyErrorHandler {

    @Override
    protected Map<LegacyErrorAttributes, RuntimeException> getErrorCodeMappings() {
        return ImmutableMap.<LegacyErrorAttributes, RuntimeException>builder()
                .put(new LegacyErrorAttributes(4, 2), createBadRequest(4, 2, "Request to a fund account"))
                .put(new LegacyErrorAttributes(4, 4), createBadRequest(4, 4, "Line missing"))
                .put(new LegacyErrorAttributes(4, 5), createBadRequest(4, 5, "Message accepted, but one or more lines were erroneous"))
                .put(new LegacyErrorAttributes(4, 6), createBadRequest(4, 6, "Non allowed exchange at due date"))
                .put(new LegacyErrorAttributes(4, 7), createBadRequest(4, 7, "Only SEK allowed for this payment"))
                .put(new LegacyErrorAttributes(4, 8), createBadRequest(4, 8, "Payment type required"))
                .put(new LegacyErrorAttributes(4, 12), createBadRequest(4, 12, "Duplicate payment"))
                .put(new LegacyErrorAttributes(4, 13), createBadRequest(4, 13, "Duplicate transfer between own accounts"))
                .put(new LegacyErrorAttributes(4, 14), createBadRequest(4, 14, "Source account blocked"))
                .put(new LegacyErrorAttributes(4, 15), createBadRequest(4, 15, "Recipient account blocked"))
                .put(new LegacyErrorAttributes(4, 16), createBadRequest(4, 16, "Beneficiary already in beneficiaries list"))
                .put(new LegacyErrorAttributes(4, 20), createBadRequest(4, 20, "Nordea account specified as external bank account"))
                .put(new LegacyErrorAttributes(4, 21), createBadRequest(4, 21, "NDBGDEST error for recipient account"))
                .put(new LegacyErrorAttributes(4, 22), createBadRequest(4, 22, "Erroneous PlusGiro account number"))
                .put(new LegacyErrorAttributes(4, 23), createBadRequest(4, 23, "Erroneous BankGiro account number"))
                .put(new LegacyErrorAttributes(4, 24), createBadRequest(4, 24, "Erroneous reference number (OCR)"))
                .put(new LegacyErrorAttributes(4, 25), createBadRequest(4, 25, "Sender note with OCR"))
                .put(new LegacyErrorAttributes(4, 26), createBadRequest(4, 26, "Error in the OCR field"))
                .put(new LegacyErrorAttributes(4, 27), createBadRequest(4, 27, "Error in IBAN account number"))
                .put(new LegacyErrorAttributes(4, 28), createBadRequest(4, 28, "Bad recurring requested for OCR"))
                .put(new LegacyErrorAttributes(4, 30), createBadRequest(4, 30, "Not enough funds"))
                .put(new LegacyErrorAttributes(4, 31), createBadRequest(4, 31, "Source account missing in accounts ledger"))
                .put(new LegacyErrorAttributes(4, 32), createBadRequest(4, 32, "Recipient account missing in accounts ledger"))
                .put(new LegacyErrorAttributes(4, 33), createBadRequest(4, 33, "Recipient account not allowed"))
                .put(new LegacyErrorAttributes(4, 34), createBadRequest(4, 34, "Transfer to the same account and currency pocket"))
                .put(new LegacyErrorAttributes(4, 35), createBadRequest(4, 35, "Can't book source account"))
                .put(new LegacyErrorAttributes(4, 36), createBadRequest(4, 36, "Erroneous OCR detected with a soft control"))
                .put(new LegacyErrorAttributes(4, 37), createBadRequest(4, 37, "The customer doesn't own the source account"))
                .put(new LegacyErrorAttributes(4, 38), createBadRequest(4, 38, "The customer is not authorized for this agreement"))
                .put(new LegacyErrorAttributes(4, 39), createBadRequest(4, 39, "Too large or too small amount for transfer"))
                .put(new LegacyErrorAttributes(4, 40), createBadRequest(4, 40, "The selected bank is not compliant with the recipient account number"))
                .put(new LegacyErrorAttributes(4, 53), createBadRequest(4, 53, "Exchange amount is larger than the maximum allowed amount"))
                .put(new LegacyErrorAttributes(4, 54), createBadRequest(4, 54, "Wrong account/currency combination. EUR-SEK-EUR or SEK-EUR-SEK."))
                .put(new LegacyErrorAttributes(4, 62), createBadRequest(4, 62, "Cut off for execution passed"))
                .put(new LegacyErrorAttributes(4, 63), createBadRequest(4, 63, "Status in progress when update requested"))
                .put(new LegacyErrorAttributes(4, 64), createBadRequest(4, 64, "Non recurring when performing exchange"))
                .put(new LegacyErrorAttributes(6, 40), createDBError(6, 40, "Database error towards FQ9PSTAT"))
                .put(new LegacyErrorAttributes(6, 42), createDBError(6, 42, "Database error towards FQ9BETBT"))
                .put(new LegacyErrorAttributes(6, 44), createDBError(6, 44, "Database error towards FQ9PHIST"))
                .put(new LegacyErrorAttributes(6, 43), createDBError(6, 43, "Database error towards FQ9OVEBT"))
                .put(new LegacyErrorAttributes(6, 46), createDBError(6, 46, "Database error towards FQ9MOTTT"))
                .put(new LegacyErrorAttributes(6, 202), createDBError(6, 202, "Database error when calling INLG7410"))
                .put(new LegacyErrorAttributes(6, 200), createDBError(6, 200, "Database error in the PlusGiro catalogue"))
                .put(new LegacyErrorAttributes(6, 201), createDBError(6, 201, "Database error in the BankGiro catalogue"))
                .put(new LegacyErrorAttributes(8, 4), createSystemError(8, 4, "System error"))
                .put(new LegacyErrorAttributes(10, 0), createBadRequest(10, 0, "Accounts ledger not allowed"))
                .put(new LegacyErrorAttributes(12, 0), createBadRequest(12, 0, "Wrong message id"))
                .put(new LegacyErrorAttributes(16, 0), createBadRequest(16, 0, "Missing message id"))
                .put(new LegacyErrorAttributes(200, 24), createBadRequest(200, 24, "Sender note with OCR"))
                .put(new LegacyErrorAttributes(200, 25), createBadRequest(200, 25, "Wrong performer (PG/BG/NA/EB)"))
                .put(new LegacyErrorAttributes(200, 26), createBadRequest(200, 26, "OCR found for transfer"))
                .put(new LegacyErrorAttributes(200, 28), createBadRequest(200, 28, "Error in the OCR field"))
                .put(new LegacyErrorAttributes(200, 30), createBadRequest(200, 30, "Recipient account empty"))
                .put(new LegacyErrorAttributes(200, 31), createBadRequest(200, 31, "Error in the IBAN account number"))
                .put(new LegacyErrorAttributes(200, 49), createBadRequest(200, 49, "The currency code of the amount is not EUR or SEK"))
                .put(new LegacyErrorAttributes(200, 50), createBadRequest(200, 50, "The amount is not numerical and > 0"))
                .put(new LegacyErrorAttributes(200, 51), createBadRequest(200, 51, "Currency code is not EUR or SEK for the source account"))
                .put(new LegacyErrorAttributes(200, 52), createBadRequest(200, 52, "Currency code is not EUR or SEK for the recipient account"))
                .put(new LegacyErrorAttributes(200, 53), createBadRequest(200, 53, "Exchange amount larger than the maximum allowed value"))
                .put(new LegacyErrorAttributes(200, 54), createBadRequest(200, 54, "The source account is not numerical and > 0"))
                .put(new LegacyErrorAttributes(200, 55), createBadRequest(200, 55, "LORG not numerical and < 0"))
                .put(new LegacyErrorAttributes(200, 56), createBadRequest(200, 56, "LBETALID not numerical and < 0"))
                .put(new LegacyErrorAttributes(200, 57), createBadRequest(200, 57, "LMOTKO not numerial and < 0"))
                .put(new LegacyErrorAttributes(200, 60), createBadRequest(200, 60, "Due date before today"))
                .put(new LegacyErrorAttributes(200, 61), createBadRequest(200, 61, "Invalid execution date"))
                .put(new LegacyErrorAttributes(200, 70), createBadRequest(200, 70, "Miscellaneous PlusGiro error"))
                .put(new LegacyErrorAttributes(200, 71), createBadRequest(200, 71, "Miscellaneous BankGiro error"))
                .put(new LegacyErrorAttributes(200, 72), createBadRequest(200, 72, "Miscellaneous INLG7410 error"))
                .put(new LegacyErrorAttributes(200, 73), createBadRequest(200, 73, "Miscellaneous NDBGATE error"))
                .put(new LegacyErrorAttributes(200, 74), createBadRequest(200, 74, "Recipient name empty"))
                .put(new LegacyErrorAttributes(200, 75), createBadRequest(200, 75, "Bad KSTAT used"))
                .put(new LegacyErrorAttributes(200, 76), createBadRequest(200, 76, "Bad NALIAS used"))
                .put(new LegacyErrorAttributes(200, 77), createBadRequest(200, 77, "Bad LUSER used"))
                .put(new LegacyErrorAttributes(200, 78), createBadRequest(200, 78, "Bad LNRAVT used"))
                .put(new LegacyErrorAttributes(200, 79), createBadRequest(200, 79, "LRECNO not numerical"))
                .put(new LegacyErrorAttributes(200, 80), createBadRequest(200, 80, "NRECTYP not '001' or '030'"))
                .put(new LegacyErrorAttributes(200, 81), createBadRequest(200, 81, "Error when performing criteria check"))
                .build();
    }
}
