package com.nordea.dbf.beneficiary.errorhandling;

/**
 *
 */
public class LegacyErrorAttributes {

  private int kbearb;
  private int krc;

  public LegacyErrorAttributes(int kbearb, int krc) {
    this.kbearb = kbearb;
    this.krc = krc;
  }

  public int getKbearb() {
    return kbearb;
  }

  public int getKrc() {
    return krc;
  }

  @Override public boolean equals(Object o) {
    if (this == o)
      return true;
    if (o == null || getClass() != o.getClass())
      return false;

    LegacyErrorAttributes that = (LegacyErrorAttributes) o;

    if (kbearb != that.kbearb)
      return false;
    return krc == that.krc;

  }

  @Override public int hashCode() {
    int result = kbearb;
    result = 31 * result + krc;
    return result;
  }
}
