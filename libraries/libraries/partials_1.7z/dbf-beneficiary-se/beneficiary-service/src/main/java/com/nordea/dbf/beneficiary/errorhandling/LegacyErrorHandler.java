package com.nordea.dbf.beneficiary.errorhandling;

public interface LegacyErrorHandler {
    void handleLegacyError(int kbearb, int krc);
}
