package com.nordea.dbf.beneficiary.integration;

import com.nordea.dbf.beneficiary.model.BeneficiaryCategory;
import com.nordea.dbf.beneficiary.model.Constants;
import com.nordea.dbf.http.errorhandling.ErrorResponse;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;

/**
 * Created by N420910 on 2015-09-10.
 */
public class BeneficiaryKey {

    private String beneficiaryKeyId;

    public BeneficiaryKey(String beneficiaryKeyId) {
        this.beneficiaryKeyId = beneficiaryKeyId;
    }

    public String getBeneficiaryId() {
        return beneficiaryKeyId;
    }

    /**
     * Format beneficiary id : HHDOM-paymentType-accountNumber-nickName
     * @param paymentType
     * @param accountNumber
     * @param nickName
     * @return
     */
    public static String createBeneficiaryId(BeneficiaryCategory paymentType, String accountNumber, String nickName) {
        String id = domesticOrCrossBorder(paymentType) + Constants.HYPHEN + paymentType.subType() + Constants.HYPHEN +
                accountNumber + Constants.HYPHEN + nickName;

        return id;
    }

    public static String createCorporateBeneficiaryId(BeneficiaryCategory paymentType, String accountNumber, String nickname, String id) {
        return domesticOrCrossBorder(paymentType) + Constants.HYPHEN + paymentType.subType() + Constants.HYPHEN +
                accountNumber + Constants.HYPHEN + id + Constants.HYPHEN + nickname;
    }

    private static String domesticOrCrossBorder(BeneficiaryCategory paymentType) {
        if (BeneficiaryCategory.CROSS_BORDER.equals(paymentType)) {
            return Constants.ID_HH_CROSSBORDER;
        } else {
            return Constants.ID_HH_DOMESTIC;
        }
    }

    /**
     * Validate beneficiary ID
     * @throws BadRequestException
     */
    public void validateBeneficiaryId() throws BadRequestException {
        int length = beneficiaryKeyId.split(Constants.HYPHEN).length;
        if(length < 3) {
            throw new BadRequestException(new ErrorResponse(ErrorResponses.Types.BAD_REQUEST, null, "Wrong beneficiaryId format", null));
        }

    }

    /**
     * Extract payment type from beneficiary ID
     * @return
     */
    public String extractPaymentType (){
        String paymentType = beneficiaryKeyId.split(Constants.HYPHEN)[1];

        return paymentType;
    }

    /**
     * Exgtract account number from beneficiary ID
     * @return
     */
    public String extractAccountNumber (){
        String identifier = beneficiaryKeyId.split(Constants.HYPHEN)[0];
        switch (identifier){
            case Constants.ID_HH_DOMESTIC:
            case Constants.ID_HH_CROSSBORDER:
                return beneficiaryKeyId.split(Constants.HYPHEN)[2];
            default:
                return null;
        }
    }

    /**
     * Extract nick name from beneficiary ID
     * @return
     */
    public String extractNickname (){
        String identifier = beneficiaryKeyId.split(Constants.HYPHEN)[0];
        String nickname = null;
        switch (identifier){
            case Constants.ID_HH_DOMESTIC:
            case Constants.ID_HH_CROSSBORDER:
                nickname = findNickName();
        }

        return nickname;
    }

    /**
     * Get nick name from third portion to the end of beneficiary ID.
     * @return
     */
    private String findNickName() {
        String[] keys = beneficiaryKeyId.split(Constants.HYPHEN);
        return beneficiaryKeyId.substring(beneficiaryKeyId.indexOf(keys[3]), beneficiaryKeyId.length());
    }

}
