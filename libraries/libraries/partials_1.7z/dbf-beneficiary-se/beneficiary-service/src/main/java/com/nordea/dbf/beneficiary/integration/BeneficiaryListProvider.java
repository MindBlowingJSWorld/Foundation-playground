package com.nordea.dbf.beneficiary.integration;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.CorporateBeneficiaryFacade;
import com.nordea.dbf.beneficiary.integration.corporate.RetrieveCorporateBeneficiaryList;
import com.nordea.dbf.beneficiary.integration.household.crossborder.PerformActionForCrossBorderBeneficiary;
import com.nordea.dbf.beneficiary.integration.household.domestic.CreateDomesticBeneficiary;
import com.nordea.dbf.beneficiary.integration.household.domestic.DeleteDomesticBeneficiary;
import com.nordea.dbf.beneficiary.integration.household.domestic.RetrieveDomesticBeneficiaryList;
import com.nordea.dbf.beneficiary.integration.household.domestic.UpdateDomesticBeneficiary;
import com.nordea.dbf.beneficiary.model.Constants;
import com.nordea.dbf.customer.agreements.se.AgreementDomainFacade;
import com.nordea.dbf.customer.agreements.se.integration.model.Agreement;
import com.nordea.dbf.customer.agreements.se.integration.model.AgreementNumber;
import com.nordea.dbf.customer.agreements.se.integration.model.AgreementType;
import com.nordea.dbf.customer.agreements.se.integration.model.UserIdentifierNumber;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Notification;
import rx.Observable;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

public class BeneficiaryListProvider implements BeneficiaryProvider {

    @Autowired
    private AgreementDomainFacade agreementDomainFacade;

    private final Logger LOGGER = LoggerFactory.getLogger(BeneficiaryListProvider.class);

    private RetrieveCorporateBeneficiaryList retrieveCorporateBeneficiaryList;
    private PerformActionForCrossBorderBeneficiary performActionForCrossBorderBeneficiary;
    private RetrieveDomesticBeneficiaryList retrieveDomesticBeneficiaryList;
    private DeleteDomesticBeneficiary deleteDomesticBeneficiary;
    private UpdateDomesticBeneficiary updateDomesticBeneficiary;
    private CreateDomesticBeneficiary createDomesticBeneficiary;
    private CorporateBeneficiaryFacade corporateBeneficiaryFacade;

    public BeneficiaryListProvider(RetrieveCorporateBeneficiaryList retrieveCorporateBeneficiaryList,
                                   PerformActionForCrossBorderBeneficiary retrieveCrossBorderBeneficiaryList,
                                   RetrieveDomesticBeneficiaryList retrieveDomesticBeneficiaryList,
                                   CreateDomesticBeneficiary createDomesticBeneficiary,
                                   DeleteDomesticBeneficiary deleteDomesticBeneficiary,
                                   UpdateDomesticBeneficiary updateDomesticBeneficiary,
                                   CorporateBeneficiaryFacade corporateBeneficiaryFacade){
        Validate.notNull(retrieveCorporateBeneficiaryList, "RetrieveCorporateBeneficiaryList can't be null");
        Validate.notNull(retrieveCrossBorderBeneficiaryList, "PerformActionForCrossBorderBeneficiary can't be null");
        Validate.notNull(retrieveDomesticBeneficiaryList, "CreateDomesticBeneficiary can't be null");
        Validate.notNull(createDomesticBeneficiary, "CreateDomesticBeneficiary can't be null");
        Validate.notNull(deleteDomesticBeneficiary, "DeleteDomesticBeneficiary can't be null");
        Validate.notNull(updateDomesticBeneficiary, "UpdateDomesticBeneficiary can't be null");
        Validate.notNull(corporateBeneficiaryFacade, "CorporateBeneficiaryFacade can't be null");


        this.retrieveCorporateBeneficiaryList = retrieveCorporateBeneficiaryList;
        this.performActionForCrossBorderBeneficiary = retrieveCrossBorderBeneficiaryList;
        this.retrieveDomesticBeneficiaryList = retrieveDomesticBeneficiaryList;
        this.createDomesticBeneficiary = createDomesticBeneficiary;
        this.deleteDomesticBeneficiary = deleteDomesticBeneficiary;
        this.updateDomesticBeneficiary = updateDomesticBeneficiary;
        this.corporateBeneficiaryFacade = corporateBeneficiaryFacade;
    }

    @Override
    public Observable<Beneficiary> getBeneficiaries(ServiceRequestContext serviceRequestContext, String range) {
        Validate.notNull(serviceRequestContext, "request context can't be null");

        String userId = serviceRequestContext.getUserId().get();
        long agreementId = serviceRequestContext.getAgreementNumber().get();
        final Agreement agreement = getAgreement(userId, agreementId, serviceRequestContext);

        switch (agreement.getAgreementType()) {
            case PRIVATE:
                LOGGER.debug("Resolved household customer segment for agreement number {}", agreementId);
                return getHouseholdBeneficiaryList(serviceRequestContext, agreement, range);

            case CORPORATE:
                LOGGER.debug("Resolved corporate customer segment for agreement number {}", agreementId);
                /*return retrieveCorporateBeneficiaryList.getCorporateBeneficiaryList(serviceRequestContext,
                        agreementId, range);*/
                return corporateBeneficiaryFacade.getBeneficiariesForCustomer(serviceRequestContext.getUserId().get());
        }

        throw new UnsupportedOperationException("Agreement type '" + agreement.getAgreementType() + "' is not supported");
    }

    @Override
    public Observable<Beneficiary> createBeneficiary(ServiceRequestContext serviceRequestContext, Beneficiary beneficiary) {
        Validate.notNull(serviceRequestContext, "request context can't be null");
        Validate.notNull(beneficiary, "request parameter cannot be null");
        final String userId = serviceRequestContext.getUserId().get();
        final Long agreementId = serviceRequestContext.getAgreementNumber().get();
        final Agreement agreement = getAgreement(userId, agreementId, serviceRequestContext);

        if (AgreementType.CORPORATE.equals(agreement.getAgreementType())) {
            return corporateBeneficiaryFacade.createBeneficiary(serviceRequestContext, beneficiary);
        } else if (AgreementType.PRIVATE.equals(agreement.getAgreementType())) {
            if (Beneficiary.CategoryEnum.cross_border.toString().equals(beneficiary.getCategory().toString())) {
                // Create cross-border
                return performActionForCrossBorderBeneficiary.createBeneficiary(serviceRequestContext,
                        agreement,
                        beneficiary);
            } else {
                // Create domestic
                return createDomesticBeneficiary.hhDomesticAddBeneficiary(serviceRequestContext,
                        agreement, beneficiary);
            }
        } else {
            throw new UnsupportedOperationException("Agreement type '" + agreement.getAgreementType() + "' is not supported");
        }
    }

    @Override
    public Observable<Beneficiary> updateBeneficiary(ServiceRequestContext serviceRequestContext,
                                                     Beneficiary beneficiary,
                                                     BeneficiaryKey beneficiaryKey) {
        Validate.notNull(serviceRequestContext, "request context can't be null");
        Validate.notNull(beneficiary, "request parameter cannot be null");
        Validate.notNull(beneficiaryKey, "beneficiary key cannot be null");
        final String userId = serviceRequestContext.getUserId().get();
        final Long agreementId = serviceRequestContext.getAgreementNumber().get();
        final Agreement agreement = getAgreement(userId, agreementId, serviceRequestContext);

        if (AgreementType.CORPORATE.equals(agreement.getAgreementType())) {
            return corporateBeneficiaryFacade.updateBeneficiary(serviceRequestContext, beneficiary);
        } else if (AgreementType.PRIVATE.equals(agreement.getAgreementType())) {
            if (Beneficiary.CategoryEnum.cross_border.toString().equals(beneficiary.getCategory().toString())) {
                return performActionForCrossBorderBeneficiary.updateBeneficiary(serviceRequestContext, agreement, beneficiary, beneficiaryKey);
            } else {
                return updateDomesticBeneficiary.hhDomesticUpdateBeneficiary(serviceRequestContext,
                        agreement, beneficiary, beneficiaryKey);
            }
        } else {
            throw new UnsupportedOperationException("Agreement type '" + agreement.getAgreementType() + "' is not supported");
        }
    }

    @Override
    public Observable<Beneficiary> deleteBeneficiary(ServiceRequestContext serviceRequestContext,
                                                     String beneficiaryId,
                                                     BeneficiaryKey beneficiaryKey) {
        Validate.notNull(serviceRequestContext, "request context can't be null");
        Validate.notNull(beneficiaryId, "request parameter cannot be null");
        Validate.notNull(beneficiaryKey, "beneficiary key cannot be null");
        final String userId = serviceRequestContext.getUserId().get();
        final Long agreementId = serviceRequestContext.getAgreementNumber().get();
        final Agreement agreement = getAgreement(userId, agreementId, serviceRequestContext);

        if (AgreementType.CORPORATE.equals(agreement.getAgreementType())) {
            return corporateBeneficiaryFacade.deleteBeneficiary(beneficiaryId);
        } else if (AgreementType.PRIVATE.equals(agreement.getAgreementType())) {
            String paymentType = beneficiaryKey.extractPaymentType();
            if (Constants.CATEGORY_CB.equals(paymentType)) {
                return performActionForCrossBorderBeneficiary.deleteBeneficiary(serviceRequestContext, agreement, beneficiaryKey);
            } else {
                return lookUpExistingBeneficiary(serviceRequestContext, agreement, beneficiaryKey)
                        .flatMap(existingBeneficiary -> deleteDomesticBeneficiary.hhDomesticDeleteBeneficiary(serviceRequestContext, agreement, beneficiaryKey, existingBeneficiary));
            }
        } else {
            throw new UnsupportedOperationException("Agreement type '" + agreement.getAgreementType() + "' is not supported");
        }
    }

    private Observable<Beneficiary> lookUpExistingBeneficiary(ServiceRequestContext serviceRequestContext, Agreement agreement, BeneficiaryKey  beneficiaryKey) {
        return retrieveDomesticBeneficiaryList.getHHDomesticBeneficiaryList(serviceRequestContext, agreement)
                .filter(b -> Objects.equals(b.getId(), beneficiaryKey.getBeneficiaryId()))
                .single()
                .materialize()
                .map(n -> {
                    if (n.getThrowable() instanceof NoSuchElementException) {
                        LOGGER.info("Beneficiary {} does not exist", beneficiaryKey.getBeneficiaryId());
                        return Notification.createOnError(ErrorResponses.requestedResourceNotFoundException("beneficiaryId", "beneficiary not found"));
                    }
                    return n;
                })
                .dematerialize();
    }

    protected Observable<Beneficiary> getHouseholdBeneficiaryList(ServiceRequestContext serviceRequestContext,
                                                                  Agreement agreement, String range){
        //Fetch Household Cross Border Beneficiary List
        Observable<Beneficiary> hhCrossBorderBeneficiary =
                performActionForCrossBorderBeneficiary.getAllBeneficiaries(serviceRequestContext, agreement);

        //Fetch Household Domestic Beneficiary List
        Observable<Beneficiary> hhDomesticBeneficiary =
                retrieveDomesticBeneficiaryList.getHHDomesticBeneficiaryList(serviceRequestContext, agreement);

        Observable<Beneficiary> householdBeneficiaryList = hhDomesticBeneficiary.mergeWith(hhCrossBorderBeneficiary);
        List<Beneficiary> beneficiaryList = householdBeneficiaryList.toList().toBlocking().single();
        beneficiaryList = CommonHandler.filterList(beneficiaryList, range);
        return Observable.from(beneficiaryList);
    }

    private Agreement getAgreement(String userId, Long agreementId,
                                   ServiceRequestContext serviceRequestContext){
        final Agreement agreement = agreementDomainFacade.findAgreement(new UserIdentifierNumber(userId),
                new AgreementNumber(agreementId), serviceRequestContext).toBlocking().single();

        if (agreement == null) {
            LOGGER.warn("Request contained an invalid agreement number {}", agreementId);
            throw new BadRequestException(ErrorResponses.invalidAuthentication("agreement", agreement));
        }
        return agreement;
    }
}
