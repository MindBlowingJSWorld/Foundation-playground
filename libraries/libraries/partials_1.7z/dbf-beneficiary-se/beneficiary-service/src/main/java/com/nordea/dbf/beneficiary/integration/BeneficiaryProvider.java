package com.nordea.dbf.beneficiary.integration;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.model.Action;
import com.nordea.dbf.http.ServiceRequestContext;
import rx.Observable;

import javax.xml.ws.Service;

/**
 * Created by G95495 on 26-05-2015.
 */
public interface BeneficiaryProvider {

    Observable<Beneficiary> getBeneficiaries(ServiceRequestContext serviceRequestContext,
                                             String range);
    Observable<Beneficiary> createBeneficiary(ServiceRequestContext serviceRequestContext,
                                              Beneficiary beneficiary);
    Observable<Beneficiary> updateBeneficiary(ServiceRequestContext serviceRequestContext,
                                              Beneficiary beneficiary,
                                              BeneficiaryKey beneficiaryKey);
    Observable<Beneficiary> deleteBeneficiary(ServiceRequestContext serviceRequestContext,
                                              String beneficiaryId,
                                              BeneficiaryKey beneficiaryKey);


}
