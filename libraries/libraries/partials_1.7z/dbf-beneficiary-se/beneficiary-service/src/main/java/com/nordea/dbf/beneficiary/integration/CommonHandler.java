package com.nordea.dbf.beneficiary.integration;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.api.model.accountkey.*;
import com.nordea.dbf.beneficiary.model.Constants;
import com.nordea.dbf.http.errorhandling.ErrorResponse;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import weblogic.utils.classfile.expr.Const;

import java.text.ParseException;
import java.util.List;

/**
 * Created by G95495 on 19-06-2015.
 */
public class CommonHandler {

    /**
     * Set toAccount format
     * @param paymentType
     * @param swiftCode
     * @param acntNumber
     * @return
     */
    public static String setToFormat(String paymentType, String swiftCode, String acntNumber){

        AccountNumber accountNumber = new AccountNumber(acntNumber);
        switch (paymentType){
            case Constants.CATEGORY_PG:
                return new PgAccountKey(accountNumber).toString();
            case Constants.CATEGORY_BG:
                return new BgAccountKey(accountNumber).toString();
            case Constants.CATEGORY_NA:
                return new NordeaAccountKey(accountNumber, Constants.CURRENCY_SE, Constants.COUNTRY_CODE_SE).toString();
            case Constants.CATEGORY_CB:
                return new CrossBorderAccountKey(accountNumber).toString();
            case Constants.CATEGORY_EB:
                return new ExternalAccountKey(Constants.COUNTRY_CODE_SE, accountNumber).toString();
            default:
                return accountNumber.toString();
        }
    }

    /**
     * Filter the benificiary list
     * @param beneficiaryList
     * @param range
     * @return
     */
    public static List<Beneficiary> filterList(List<Beneficiary> beneficiaryList, String range){
        if(range != null){
            int startIndex = Integer.parseInt(range.split(Constants.HYPHEN)[0]);
            int lastIndex = Integer.parseInt(range.split(Constants.HYPHEN)[1]);

            if(lastIndex > beneficiaryList.size()){
                lastIndex = beneficiaryList.size();
            }
            if(startIndex > beneficiaryList.size()){
                startIndex = beneficiaryList.size();
            }

            beneficiaryList = beneficiaryList.subList(startIndex,lastIndex);
        }
        return beneficiaryList;
    }

    /**
     * Check range. This should implemented in CORE
     * @param range
     * @throws ParseException
     */
    public static void checkRange(String range) throws ParseException {
        String[] indices = range.split(Constants.HYPHEN);
        if (indices.length != 2) {
            throw new ParseException("Incorrect Range specified. Range must be in the format start-end",
                    range.length());
        } else {
            int startIndex = Integer.parseInt(indices[0]);
            int endIndex = Integer.parseInt(indices[1]);
            if (startIndex > endIndex || startIndex < 0 || endIndex < 0) {
                throw new ParseException("Incorrect Range specified. Start must be smaller than or equal to end",
                        range.length());
            }
        }
    }

}
