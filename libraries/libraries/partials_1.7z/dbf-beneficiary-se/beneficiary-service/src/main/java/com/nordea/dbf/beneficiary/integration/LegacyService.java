package com.nordea.dbf.beneficiary.integration;

/**
 * Created by G95495 on 11-05-2015.
 */
public interface LegacyService {
    String transactionCode();

    String messageId();

}
