package com.nordea.dbf.beneficiary.integration.corporate;

import com.nordea.dbf.agreement.Agreement;
import com.nordea.dbf.agreement.Engagement;
import com.nordea.dbf.agreement.facade.CorporateAgreementFacade;
import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.api.model.accountkey.ExternalAccountKey;
import com.nordea.dbf.beneficiary.annotation.Corporate;
import com.nordea.dbf.beneficiary.errorhandling.LegacyErrorHandler;
import com.nordea.dbf.beneficiary.integration.CommonHandler;
import com.nordea.dbf.beneficiary.model.BeneficiaryCategory;
import com.nordea.dbf.beneficiary.model.Constants;
import com.nordea.dbf.beneficiary.model.LegacyTransactionDetails;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListResponseBeneficiariesSegment;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListResponseRecord;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static com.nordea.dbf.messaging.Observables.manage;

/**
 * Created by G95495 on 26-05-2015.
 * TODO Use the exception handling that payment uses (JSON files) (create jira)
 */
public class RetrieveCorporateBeneficiaryList {

    private final Logger LOGGER = LoggerFactory.getLogger(RetrieveCorporateBeneficiaryList.class);

    @Autowired
    private CorporateAgreementFacade corporateAgreementFacade;

    @Autowired
    @Corporate
    private LegacyErrorHandler legacyErrorHandler;

    private BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connector;

    public RetrieveCorporateBeneficiaryList(BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connector) {
        Validate.notNull(connector, "connector can't be null");
        this.connector = connector;
    }

    public Observable<Beneficiary> getCorporateBeneficiaryList
            (ServiceRequestContext requestContext, Long agreementId, String range) {
        Validate.notNull(requestContext, "context can't be null");
        Validate.notNull(agreementId, "context can't be null");

        final BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord>
                connection = connector.connect();
        LOGGER.debug("Backend connection established");

        try {
            final Engagement engagement = corporateAgreementFacade.getCustomerEngagement(requestContext).toBlocking().single();

            if (engagement == null) {
                LOGGER.warn("No corporate engagement found for agreementId {}", agreementId);
                throw new BadRequestException(ErrorResponses.invalidAuthentication("agreement", engagement));
            }

            CorporateBeneficiaryListRequestRecord requestRecord = createRequest(requestContext, agreementId, engagement);

            return manage(connection).on(connection
                    .execute(Optional.of(requestContext), requestRecord, CorporateBeneficiaryListResponseRecord.class)
                    .flatMap(corporateBeneficiaryListResponseRecord -> {
                        return Observable.from(fetchResponse(validResponse(corporateBeneficiaryListResponseRecord), range));
                    }));
        } catch (RuntimeException e){
            LOGGER.warn("Corporate engagement could not be resolved for request context {}", requestContext, e);
            throw new RuntimeException("Corporate engagement could not be resolved for:" + requestContext.getUserId() + " and agreement:" + agreementId);
        }
    }

    /**
     * Creates a request record from the input parameters.
     *
     * @param requestContext The response records retrieved from the backend.
     * @param agreementId The input customer agreement number
     * @param engagement The corporate engagement class
     * @return A request record.
     */
    public CorporateBeneficiaryListRequestRecord createRequest(ServiceRequestContext requestContext, Long agreementId
            , Engagement engagement){
        final CorporateBeneficiaryListRequestRecord requestRecord = new CorporateBeneficiaryListRequestRecord();

        requestRecord.initialize();
        requestRecord.setTimeToLive(Constants.TIME_TO_LIVE);
        requestRecord.setSessionId(requestContext.getSessionId().orElse(StringUtils.EMPTY));
        requestRecord.setRequestId(requestContext.getRequestId().orElse(StringUtils.EMPTY));
        requestRecord.setTransactionCode(LegacyTransactionDetails.RETRIEVE_CORPORATE.transactionCode());
        requestRecord.setMessageId(LegacyTransactionDetails.RETRIEVE_CORPORATE.messageId());

        requestRecord.setUserId(requestContext.getUserId().get().substring(Constants.CORPORATE_USERID_SUBSTRING)); //The userid without century digits e.g. 19
        requestRecord.setChannelId(Constants.CORPORATE_CHANNEL);
        requestRecord.setPaymentSubType(Constants.SPACE); //Null to fetch all types
        requestRecord.setRacfId(engagement.getRacfId());

        Agreement agreement = engagement.getAgreementById(String.valueOf(agreementId));
        requestRecord.setAgreementOwner(agreement.getCustomer());
        LOGGER.debug("Request record generated");
        return requestRecord;
    }

    /**
     * Creates a list of beneficiaries from the provided response record.
     *
     * @param responseRecord The response records retrieved from the backend.
     * @return A list of beneficiaries.
     */
    @SuppressWarnings("unchecked")
    public List<Beneficiary> fetchResponse(CorporateBeneficiaryListResponseRecord responseRecord,
                                                            String range) {
        final Iterator<CorporateBeneficiaryListResponseBeneficiariesSegment> iterator = responseRecord.getBeneficiaries();
        final List<Beneficiary> result = new ArrayList<Beneficiary>(responseRecord.getNoOfBeneficiaries());

        LOGGER.debug("Retrieved {} corporate beneficiaries", responseRecord.getNoOfBeneficiaries());
        while (iterator.hasNext()) {
            final CorporateBeneficiaryListResponseBeneficiariesSegment segment = iterator.next();
            final Beneficiary beneficiary = new Beneficiary();

            beneficiary.setId(createId(segment)); // To uniquely identify a beneficiary
            beneficiary.setName(segment.getName());
            beneficiary.setNickname(segment.getNickname());
            //ClearingNumber is prefixed to accountNumber. Will need to extract it back when doing update/delete..
            segment.setAccountNumber(segment.getClearingNumber().concat(segment.getAccountNumber()));

            beneficiary.setTo(new ExternalAccountKey(Constants.COUNTRY_CODE_SE, new AccountNumber(segment.getAccountNumber())).toString());
            beneficiary.setCategory(BeneficiaryCategory.getCategory(segment.getPaymentSubTypeEx()).getBeneficiaryCategory());
            beneficiary.setDisplayNumber(segment.getFormattedAccNo());

            result.add(beneficiary);
        }
        return CommonHandler.filterList(result, range);
    }

    protected CorporateBeneficiaryListResponseRecord validResponse(CorporateBeneficiaryListResponseRecord responseRecord) {
        if (responseRecord.getKbearb() != 0 && responseRecord.getKrc() != 0) {
            legacyErrorHandler.handleLegacyError(responseRecord.getKbearb(), responseRecord.getKrc());
        }
        return responseRecord;
    }

    // TODO The beneficiary id should be created using the BeneficiaryKey class
    private String createId(CorporateBeneficiaryListResponseBeneficiariesSegment segment){
        return Constants.ID_CORPORATE + Constants.HYPHEN + segment.getPaymentSubTypeEx() + Constants.HYPHEN + Constants.CORPORATE_CHANNEL +
                Constants.HYPHEN + segment.getUserId() + Constants.HYPHEN +
                segment.getAgreementOwner();
    }
}
