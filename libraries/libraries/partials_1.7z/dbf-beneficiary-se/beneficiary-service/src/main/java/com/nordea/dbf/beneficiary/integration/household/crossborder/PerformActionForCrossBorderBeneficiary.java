package com.nordea.dbf.beneficiary.integration.household.crossborder;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.api.model.accountkey.AccountNumber;
import com.nordea.dbf.api.model.accountkey.CrossBorderAccountKey;
import com.nordea.dbf.beneficiary.annotation.HouseholdCrossBorder;
import com.nordea.dbf.beneficiary.errorhandling.LegacyErrorHandler;
import com.nordea.dbf.beneficiary.integration.BeneficiaryKey;
import com.nordea.dbf.beneficiary.integration.CommonHandler;
import com.nordea.dbf.beneficiary.model.*;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHCrossBorderBeneficiaryListRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHCrossBorderBeneficiaryListResponseBeneficiariesSegment;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHCrossBorderBeneficiaryListResponseRecord;
import com.nordea.dbf.customer.agreements.se.integration.model.Agreement;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Notification;
import rx.Observable;

import java.util.*;

import static com.nordea.dbf.messaging.Observables.manage;

/**
 * Created by G95495 on 26-05-2015.
 */
public class PerformActionForCrossBorderBeneficiary {

    @Autowired
    @HouseholdCrossBorder
    private LegacyErrorHandler legacyErrorHandler;

    private final Logger LOGGER = LoggerFactory.getLogger(PerformActionForCrossBorderBeneficiary.class);

    private BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connector;

    public PerformActionForCrossBorderBeneficiary(BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connector) {
        Validate.notNull(connector, "connector can't be null");
        this.connector = connector;
    }

    public Observable<Beneficiary> getAllBeneficiaries(ServiceRequestContext requestContext, Agreement agreement) {
        Validate.notNull(requestContext, "Request context cannot be null");
        Validate.notNull(agreement, "Agreement cannot be null");
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        int function = TransactionFunction.RETRIEVE_ALL.getCode();
        String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();
        requestRecord = createRequestRecord(requestRecord,
                requestContext,
                function,
                transactionId,
                messageId);

        requestRecord.setOwnerId(agreement.getAgreementOwner());

        BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connection = connector.connect();
        return manage(connection).on(connection
                .execute(Optional.of(requestContext), requestRecord, HHCrossBorderBeneficiaryListResponseRecord.class)
                .flatMap(hhCrossBorderBeneficiaryListResponseRecord -> {
                    return Observable.from(fetchResponse(validResponse(hhCrossBorderBeneficiaryListResponseRecord)));
                }));
    }

    public Observable<Beneficiary> createBeneficiary(ServiceRequestContext serviceRequestContext,
                                                    Agreement agreement,
                                                    Beneficiary beneficiary) {
        Validate.notNull(serviceRequestContext, "Service request context cannot be null");
        Validate.notNull(agreement, "Agreement cannot be null");
        Validate.notNull(beneficiary, "beneficiary can't be null");

        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        int function = TransactionFunction.ADD.getCode();
        String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();

        requestRecord = createRequestRecord(requestRecord,
                serviceRequestContext,
                function,
                transactionId,
                messageId);

        requestRecord.setOwnerId(agreement.getAgreementOwner());

        AccountKey accountKey = AccountKey.fromString(beneficiary.getTo());

        requestRecord.setAccountNumber(accountKey.getAccountNumber().getAccountNumber());
        requestRecord.setBenefAccountNumber(accountKey.getAccountNumber().getAccountNumber());
        requestRecord.setPaymentType("C");
        requestRecord.setNickname(beneficiary.getNickname());
        requestRecord.setName(beneficiary.getName());
        requestRecord.setBenefNickname(beneficiary.getNickname());
        requestRecord.setPaymentSubType(1);
        if(AccountKey.fromString(beneficiary.getTo()).getBIC().isPresent())
        {
            requestRecord.setSwiftCode(accountKey.getBIC().orElse(""));
            requestRecord.setLocalCodePN(accountKey.getBIC().orElse("").substring(4, 6));
        }

        requestRecord.setBankCode(beneficiary.getMessage());

        BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connection = connector.connect();
        return manage(connection).on(connection
                .execute(Optional.of(serviceRequestContext), requestRecord, HHCrossBorderBeneficiaryListResponseRecord.class)
                .flatMap(hhCrossBorderBeneficiaryListResponseRecord -> {
                    return Observable.from(fetchResponse(validResponse(hhCrossBorderBeneficiaryListResponseRecord)));
                }));

    }

    public Observable<Beneficiary> updateBeneficiary(ServiceRequestContext serviceRequestContext,
                                                     Agreement agreement,
                                                     Beneficiary beneficiary,
                                                     BeneficiaryKey beneficiaryKeyId) {
        Validate.notNull(agreement, "agreement can't be null");
        Validate.notNull(beneficiaryKeyId, "beneficiaryId can't be null");

        BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connection = connector.connect();
        return lookupExistingBeneficiaryRecord(connection, serviceRequestContext, agreement, beneficiaryKeyId)
                .flatMap(existingBeneficiaryRecord -> {
                    if(existingBeneficiaryRecord != null && existingBeneficiaryRecord.getNoOfBeneficiaries() == 0){
                        LOGGER.info("Beneficiary {} does not exist", beneficiaryKeyId.getBeneficiaryId());
                        return Observable.error(ErrorResponses.requestedResourceNotFoundException("beneficiaryId", "beneficiary not found"));
                    }
                    LOGGER.info("Existing beneficiary of paymentType={} loaded for beneficiaryId={}; commencing beneficiary updation",
                            beneficiaryKeyId.extractPaymentType(), beneficiaryKeyId.getBeneficiaryId());


                    HHCrossBorderBeneficiaryListRequestRecord requestRecord = createUpdateRequest(serviceRequestContext, agreement, beneficiary,
                            beneficiaryKeyId, existingBeneficiaryRecord);

                    return manage(connection).on(connection
                            .execute(Optional.of(serviceRequestContext), requestRecord, HHCrossBorderBeneficiaryListResponseRecord.class)
                            .flatMap(hhCrossBorderBeneficiaryListResponseRecord -> {
                                return Observable.from(fetchResponse(validResponse(hhCrossBorderBeneficiaryListResponseRecord)));
                            }));
                })
                .materialize()
                .map(n -> {
                    if (n.getThrowable() instanceof NoSuchElementException) {
                        LOGGER.info("Beneficiary {} does not exist", beneficiaryKeyId.getBeneficiaryId());
                        return Notification.createOnError(ErrorResponses.requestedResourceNotFoundException("beneficiaryId", "beneficiary not found"));
                    }
                    return n;
                })
                .dematerialize();

    }

    public Observable<Beneficiary> deleteBeneficiary(ServiceRequestContext requestContext,
                                                     Agreement agreement,
                                                     BeneficiaryKey beneficiaryKeyId) {
        Validate.notNull(requestContext, "Request context cannot be null");
        Validate.notNull(agreement, "agreement cannot be null");
        Validate.notNull(beneficiaryKeyId, "beneficiaryKeyId can't be null");

        BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connection = connector.connect();

        return lookupExistingBeneficiary(connection, requestContext, agreement, beneficiaryKeyId).flatMap(existingBeneficiary -> {
            LOGGER.info("Existing beneficiary of paymentType={} loaded for beneficiaryId={}; commencing beneficiary deletion",
                    existingBeneficiary.getCategory(), existingBeneficiary.getId());

            HHCrossBorderBeneficiaryListRequestRecord requestRecord =  new HHCrossBorderBeneficiaryListRequestRecord();
            int function = TransactionFunction.DELETE.getCode();
            String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
            String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();

            requestRecord = createRequestRecord(requestRecord,
                    requestContext,
                    function,
                    transactionId,
                    messageId);

            requestRecord.setOwnerId(agreement.getAgreementOwner());



            requestRecord.setBenefAccountNumber(beneficiaryKeyId.extractAccountNumber());
            requestRecord.setPaymentType("C");
            requestRecord.setBenefNickname(beneficiaryKeyId.extractNickname());

            return manage(connection).on(connection
                    .execute(Optional.of(requestContext), requestRecord, HHCrossBorderBeneficiaryListResponseRecord.class)
                    .flatMap(hhCrossBorderBeneficiaryListResponseRecord -> {
                        validResponse(hhCrossBorderBeneficiaryListResponseRecord);
                        return Observable.just(existingBeneficiary);
                    }));
        });

    }

    protected HHCrossBorderBeneficiaryListRequestRecord createRequestRecord(HHCrossBorderBeneficiaryListRequestRecord requestRecord,
                                                                          ServiceRequestContext requestContext,
                                                                          int function,
                                                                          String transactionId,
                                                                          String messageId) {
        requestRecord.initialize();
        requestRecord.setTimeToLive(Constants.TIME_TO_LIVE);
        requestRecord.setSessionId(requestContext.getSessionId().orElse(StringUtils.EMPTY));
        requestRecord.setRequestId(requestContext.getRequestId().orElse(StringUtils.EMPTY));
        requestRecord.setTransactionCode(transactionId);
        requestRecord.setMessageId(messageId);

        requestRecord.setUserId(requestContext.getUserId().get());

        requestRecord.setFunction(function);

        return requestRecord;
    }

    protected Observable<Beneficiary> lookupExistingBeneficiary
            (BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connection,
             ServiceRequestContext requestContext,Agreement agreement, BeneficiaryKey beneficiaryKeyId){

        String beneficiaryId =  beneficiaryKeyId.getBeneficiaryId();
        LOGGER.info("Attempting to resolve beneficiary id {} prior to deletion", beneficiaryId);

        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        int function = TransactionFunction.RETRIEVE_ALL.getCode();
        String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();

        requestRecord = createRequestRecord(requestRecord, requestContext, function, transactionId, messageId);

        requestRecord.setOwnerId(agreement.getAgreementOwner());

        return manage(connection).on(connection
                .execute(Optional.of(requestContext), requestRecord, HHCrossBorderBeneficiaryListResponseRecord.class)
                .flatMap(hhCrossBorderBeneficiaryListResponseRecord -> {
                    return Observable.from(fetchResponse(validResponse(hhCrossBorderBeneficiaryListResponseRecord)));
                })
                .filter(p -> p.getId().equals(beneficiaryId))
                .single()
                .materialize()
                .map(n -> {
                    if (n.getThrowable() instanceof NoSuchElementException) {
                        LOGGER.info("Beneficiary {} does not exist", beneficiaryId);
                        return Notification.createOnError(ErrorResponses.requestedResourceNotFoundException("beneficiaryId", "beneficiary not found"));
                    }
                    return n;
                })
                .dematerialize());

    }


    protected Observable<HHCrossBorderBeneficiaryListResponseRecord> lookupExistingBeneficiaryRecord
            (BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connection,
             ServiceRequestContext requestContext,Agreement agreement, BeneficiaryKey beneficiaryKeyId){
        LOGGER.info("Attempting to resolve beneficiary id {} prior to updation", beneficiaryKeyId.getBeneficiaryId());

        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();

        int function = TransactionFunction.RETRIEVE_SINGLE.getCode();
        String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();

        requestRecord = createRequestRecord(requestRecord, requestContext, function, transactionId, messageId);

        requestRecord.setOwnerId(agreement.getAgreementOwner());

        requestRecord.setBenefAccountNumber(beneficiaryKeyId.extractAccountNumber());
        requestRecord.setPaymentType("C");
        requestRecord.setBenefNickname(beneficiaryKeyId.extractNickname());

        return manage(connection).on(connection
                .execute(Optional.of(requestContext), requestRecord, HHCrossBorderBeneficiaryListResponseRecord.class)
                .flatMap(hhCrossBorderBeneficiaryListResponseRecord -> {
                    return Observable.just(validResponse(hhCrossBorderBeneficiaryListResponseRecord));
                }));
    }

    /**
     * Creates a request record from the input parameters.
     *
     * @param requestContext The request record to be sent to backend for updation.
     * @param existingBeneficiaryRecord The response records retrieved from the backend for the beneficiary to be updated.
     * @return A request record.
     */
    public HHCrossBorderBeneficiaryListRequestRecord createUpdateRequest (ServiceRequestContext requestContext,
                                                                          Agreement agreement, Beneficiary beneficiary,
                                                                          BeneficiaryKey beneficiaryKeyId,
                                                                          HHCrossBorderBeneficiaryListResponseRecord existingBeneficiaryRecord){
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        int function = TransactionFunction.UPDATE.getCode();
        String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();

        requestRecord = createRequestRecord(requestRecord, requestContext, function, transactionId, messageId);

        requestRecord.setOwnerId(agreement.getAgreementOwner());

        final Iterator<HHCrossBorderBeneficiaryListResponseBeneficiariesSegment> iterator =
                existingBeneficiaryRecord.getBeneficiaries();

        //BenefId - existing values
        requestRecord.setAccountNumber(beneficiaryKeyId.extractAccountNumber());
        requestRecord.setNickname(beneficiaryKeyId.extractNickname());
        requestRecord.setPaymentType(beneficiaryKeyId.extractPaymentType());

        //Beneficiary - new values
        AccountKey accountKey = AccountKey.fromString(beneficiary.getTo());
        requestRecord.setBenefAccountNumber(accountKey.getAccountNumber().getAccountNumber());
        requestRecord.setBenefNickname(beneficiary.getNickname());
        requestRecord.setName(beneficiary.getName());

        //retrieved values
        while (iterator.hasNext()) {//There should be only 1 record
            final HHCrossBorderBeneficiaryListResponseBeneficiariesSegment segment = iterator.next();
            requestRecord.setPaymentSubType(segment.getPaymentSubType());
            requestRecord.setLocalCode(segment.getLocalCode());
            if(AccountKey.fromString(beneficiary.getTo()).getBIC().isPresent())
            {
                requestRecord.setSwiftCode(accountKey.getBIC().orElse(""));
                requestRecord.setLocalCodePN(accountKey.getBIC().orElse("").toString().substring(4,6));
            }
            else {
                requestRecord.setSwiftCode(segment.getSwiftCode());
            }
            if(!StringUtils.isEmpty(beneficiary.getMessage()))
            {
                requestRecord.setBankCode(beneficiary.getMessage());
            }
            else {
                requestRecord.setBankCode(segment.getBankCode());
            }
        }
        return requestRecord;
    }

    /**
     * Creates a list of beneficiaries from the provided response record.
     *
     * @param responseRecord The response records retrieved from the backend.
     * @return A list of beneficiaries.
     */
    @SuppressWarnings("unchecked")
    public List<Beneficiary> fetchResponse(HHCrossBorderBeneficiaryListResponseRecord
                                                   responseRecord) {
        final Iterator<HHCrossBorderBeneficiaryListResponseBeneficiariesSegment> iterator =
                responseRecord.getBeneficiaries();
        final List<Beneficiary> result = new ArrayList<Beneficiary>(responseRecord.getNoOfBeneficiaries());

        LOGGER.debug("Retrieved {} household cross border beneficiaries", responseRecord.getNoOfBeneficiaries());

        while (iterator.hasNext()) {
            final HHCrossBorderBeneficiaryListResponseBeneficiariesSegment segment = iterator.next();
            final Beneficiary beneficiary = new Beneficiary();

            beneficiary.setName(segment.getName());
            beneficiary.setNickname(segment.getNickname());
            beneficiary.setDisplayNumber(segment.getAccountNumber());
            beneficiary.setId(createId(segment)); //to uniquely identify a beneficiary
            beneficiary.setCategory(Beneficiary.CategoryEnum.cross_border);

            beneficiary.setTo(new CrossBorderAccountKey(new AccountNumber(segment.getAccountNumber())).toString());
            if(!StringUtils.isEmpty(segment.getBankCode())) {
                beneficiary.setMessage(segment.getBankCode());
            }
            result.add(beneficiary);
        }
        return result;
    }


    protected HHCrossBorderBeneficiaryListResponseRecord validResponse(HHCrossBorderBeneficiaryListResponseRecord responseRecord) {
        if (responseRecord.getKbearb() != 0 && responseRecord.getKrc() != 0) {
            legacyErrorHandler.handleLegacyError(responseRecord.getKbearb(), responseRecord.getKrc());
        }
        return responseRecord;
    }

    private String createId(HHCrossBorderBeneficiaryListResponseBeneficiariesSegment segment){
        return BeneficiaryKey.createBeneficiaryId(BeneficiaryCategory.CROSS_BORDER, segment.getAccountNumber(), segment.getNickname());
    }

}
