package com.nordea.dbf.beneficiary.integration.household.domestic;


import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.annotation.HouseholdDomestic;
import com.nordea.dbf.beneficiary.errorhandling.LegacyErrorHandler;
import com.nordea.dbf.beneficiary.integration.BeneficiaryKey;
import com.nordea.dbf.beneficiary.model.Constants;
import com.nordea.dbf.beneficiary.model.LegacyTransactionDetails;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticDeleteBeneficiaryRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticDeleteBeneficiaryResponseRecord;
import com.nordea.dbf.customer.agreements.se.integration.model.Agreement;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.util.Optional;

import static com.nordea.dbf.messaging.Observables.manage;

/**
 * Created by G95495 on 22-06-2015.
 */
public class DeleteDomesticBeneficiary {

    @Autowired
    @HouseholdDomestic
    private LegacyErrorHandler legacyErrorHandler;

    private final Logger LOGGER = LoggerFactory.getLogger(DeleteDomesticBeneficiary.class);

    private BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connector;

    public DeleteDomesticBeneficiary(BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connector) {
        Validate.notNull(connector, "connector can't be null");
        this.connector = connector;
    }

    public Observable<Beneficiary> hhDomesticDeleteBeneficiary (ServiceRequestContext requestContext, Agreement agreement,
                                                                BeneficiaryKey beneficiaryKeyId, Beneficiary existingBeneficiary){
        Validate.notNull(requestContext, "context can't be null");
        Validate.notNull(agreement, "agreement can't be null");

        final BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord>
                connection = connector.connect();

        LOGGER.debug("Backend connection established");

        final HHDomesticDeleteBeneficiaryRequestRecord requestRecord = createDeleteRequest(requestContext, agreement, beneficiaryKeyId);

        return manage(connection).on(connection
                .execute(Optional.of(requestContext), requestRecord, HHDomesticDeleteBeneficiaryResponseRecord.class)
                .map(responseRecord -> existingBeneficiary));
    }

    /**
     * Creates a request record from the input parameters.
     *
     * @param requestContext The response records retrieved from the backend.
     * @param agreement The input customer agreement
     * @return A request record.
     */
    public HHDomesticDeleteBeneficiaryRequestRecord createDeleteRequest(ServiceRequestContext requestContext,
                                                                           Agreement agreement, BeneficiaryKey beneficiaryKeyId){
        final HHDomesticDeleteBeneficiaryRequestRecord requestRecord = new HHDomesticDeleteBeneficiaryRequestRecord();

        requestRecord.initialize();
        requestRecord.setTimeToLive(Constants.TIME_TO_LIVE);
        requestRecord.setSessionId(requestContext.getSessionId().orElse(StringUtils.EMPTY));
        requestRecord.setRequestId(requestContext.getRequestId().orElse(StringUtils.EMPTY));
        requestRecord.setTransactionCode(LegacyTransactionDetails.DELETE_HOUSEHOLD_DOMESTIC.transactionCode());
        requestRecord.setMessageId(LegacyTransactionDetails.DELETE_HOUSEHOLD_DOMESTIC.messageId());

        requestRecord.setUserId(requestContext.getUserId().get());
        if(agreement != null) {
            String ownerId = agreement.getAgreementOwner() != null ? agreement.getAgreementOwner()
                    : requestContext.getUserId().get();
            requestRecord.setOwnerId(Long.parseLong(ownerId));
            if(agreement.getAgreementNumber() != null) {
                requestRecord.setAgreementNumber(agreement.getAgreementNumber().getAgreementNumber());
            }
        }

        requestRecord.setPaymentType(beneficiaryKeyId.extractPaymentType());
        requestRecord.setAccountNumber(Long.valueOf(beneficiaryKeyId.extractAccountNumber()));
        requestRecord.setNickname(beneficiaryKeyId.extractNickname());

        LOGGER.debug("Request record generated");
        return requestRecord;
    }

    protected HHDomesticDeleteBeneficiaryResponseRecord validResponse(HHDomesticDeleteBeneficiaryResponseRecord responseRecord) {
        if (responseRecord.getKbearb() != 0 && responseRecord.getKrc() != 0) {
            legacyErrorHandler.handleLegacyError(responseRecord.getKbearb(), responseRecord.getKrc());
        }
        return responseRecord;
    }
}
