package com.nordea.dbf.beneficiary.integration.household.domestic;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.annotation.HouseholdDomestic;
import com.nordea.dbf.beneficiary.errorhandling.LegacyErrorHandler;
import com.nordea.dbf.beneficiary.integration.BeneficiaryKey;
import com.nordea.dbf.beneficiary.integration.CommonHandler;
import com.nordea.dbf.beneficiary.model.BeneficiaryCategory;
import com.nordea.dbf.beneficiary.model.Constants;
import com.nordea.dbf.beneficiary.model.LegacyTransactionDetails;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticBeneficiaryListRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticBeneficiaryListResponseBeneficiariesSegment;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticBeneficiaryListResponseRecord;
import com.nordea.dbf.customer.agreements.se.integration.model.Agreement;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import static com.nordea.dbf.messaging.Observables.manage;

/**
 * Created by G95495 on 26-05-2015.
 */
public class RetrieveDomesticBeneficiaryList {

    @Autowired
    @HouseholdDomestic
    private LegacyErrorHandler legacyErrorHandler;

    private final Logger LOGGER = LoggerFactory.getLogger(RetrieveDomesticBeneficiaryList.class);

    private BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connector;

    public RetrieveDomesticBeneficiaryList(BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> connector) {
        Validate.notNull(connector, "connector can't be null");
        this.connector = connector;
    }

    public Observable<Beneficiary> getHHDomesticBeneficiaryList (ServiceRequestContext requestContext, Agreement agreement){
        Validate.notNull(requestContext, "context can't be null");
        Validate.notNull(agreement, "agreement can't be null");

        final BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord>
                connection = connector.connect();

        LOGGER.debug("Backend connection established");

        final HHDomesticBeneficiaryListRequestRecord requestRecord = createRequest(requestContext, agreement);

        return manage(connection).on(connection
                .execute(Optional.of(requestContext), requestRecord, HHDomesticBeneficiaryListResponseRecord.class)
                .flatMap(hhDomesticBeneficiaryListResponseRecord -> {
                    return Observable.from(fetchResponse(validResponse(hhDomesticBeneficiaryListResponseRecord)));
                }));
    }

    /**
     * Creates a request record from the input parameters.
     *
     * @param requestContext The response records retrieved from the backend.
     * @param agreement The input customer agreement
     * @return A request record.
     */
    public HHDomesticBeneficiaryListRequestRecord createRequest(ServiceRequestContext requestContext, Agreement agreement){
        final HHDomesticBeneficiaryListRequestRecord requestRecord = new HHDomesticBeneficiaryListRequestRecord();

        requestRecord.initialize();
        requestRecord.setTimeToLive(Constants.TIME_TO_LIVE);
        requestRecord.setSessionId(requestContext.getSessionId().orElse(StringUtils.EMPTY));
        requestRecord.setRequestId(requestContext.getRequestId().orElse(StringUtils.EMPTY));
        requestRecord.setTransactionCode(LegacyTransactionDetails.RETRIEVE_HOUSEHOLD_DOMESTIC.transactionCode());
        requestRecord.setMessageId(LegacyTransactionDetails.RETRIEVE_HOUSEHOLD_DOMESTIC.messageId());

        requestRecord.setFlag(Constants.DOMESTIC_FLAG_S);
        requestRecord.setUserId(requestContext.getUserId().get());
        requestRecord.setPaymentType(Constants.SPACE); //To fetch all types

        if(agreement != null) {
            String ownerId = agreement.getAgreementOwner() != null ? agreement.getAgreementOwner()
                    : requestContext.getUserId().get();
            requestRecord.setOwnerId(Long.parseLong(ownerId));
            if(agreement.getAgreementNumber() != null) {
                requestRecord.setAgreementNumber(agreement.getAgreementNumber().getAgreementNumber());
            }
        }
        LOGGER.debug("Request record generated");
        return requestRecord;
    }

    /**
     * Creates a list of beneficiaries from the provided response record.
     *
     * @param responseRecord The response records retrieved from the backend.
     * @return A list of beneficiaries.
     */
    @SuppressWarnings("unchecked")
    public List<Beneficiary> fetchResponse(HHDomesticBeneficiaryListResponseRecord responseRecord) {
        final Iterator<HHDomesticBeneficiaryListResponseBeneficiariesSegment> iterator = responseRecord.getBeneficiaries();
        final List<Beneficiary> result = new ArrayList<Beneficiary>(responseRecord.getNoOfBeneficiaries());

        LOGGER.debug("Retrieved {} household domestic beneficiaries", responseRecord.getNoOfBeneficiaries());

        while (iterator.hasNext()) {
            final HHDomesticBeneficiaryListResponseBeneficiariesSegment segment = iterator.next();
            final Beneficiary beneficiary = new Beneficiary();

            beneficiary.setName(segment.getName());
            beneficiary.setNickname(segment.getNickname());
            beneficiary.setTo(CommonHandler.setToFormat(segment.getPaymentType(), null,
                    String.valueOf(segment.getAccountNumber())));
            beneficiary.setDisplayNumber(String.valueOf(segment.getAccountNumber()));
            beneficiary.setId(createId(segment)); //to uniquely identify a beneficiary
            beneficiary.setCategory(BeneficiaryCategory.getCategory(segment.getPaymentType()).getBeneficiaryCategory());
            result.add(beneficiary);
        }
        return result;
    }

    protected HHDomesticBeneficiaryListResponseRecord validResponse(HHDomesticBeneficiaryListResponseRecord responseRecord) {
        if (responseRecord.getKbearb() != 0 && responseRecord.getKrc() != 0) {
            legacyErrorHandler.handleLegacyError(responseRecord.getKbearb(), responseRecord.getKrc());
        }
        return responseRecord;
    }

    private String createId(HHDomesticBeneficiaryListResponseBeneficiariesSegment segment){
        return BeneficiaryKey.createBeneficiaryId(BeneficiaryCategory.getCategory(segment.getPaymentType()), String.valueOf(segment.getAccountNumber()), segment.getNickname());
    }
}
