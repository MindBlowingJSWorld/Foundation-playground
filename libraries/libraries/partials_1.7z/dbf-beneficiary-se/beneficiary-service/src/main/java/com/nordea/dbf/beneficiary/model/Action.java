package com.nordea.dbf.beneficiary.model;

/**
 * Enum describing the different types of actions that are possible towards the backend
 *
 */

public enum Action {
    RETRIEVE_ALL,
    ADD,
    UPDATE,
    DELETE,
    RETRIEVE_SINGLE
}


