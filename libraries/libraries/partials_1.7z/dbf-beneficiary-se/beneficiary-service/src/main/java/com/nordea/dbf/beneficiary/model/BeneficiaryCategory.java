package com.nordea.dbf.beneficiary.model;

import com.nordea.dbf.api.model.Beneficiary;

/**
 * Created by g95495 on 19-05-2015.
 */
public enum BeneficiaryCategory {

    PG("PG", Beneficiary.CategoryEnum.pg),
    BG("BG", Beneficiary.CategoryEnum.bg),
    CROSS_BORDER("CB", Beneficiary.CategoryEnum.cross_border),
    THIRD_PARTY("EB", Beneficiary.CategoryEnum.third_party),
    PENSION("PE", Beneficiary.CategoryEnum.pension),
    SALARY("LO", Beneficiary.CategoryEnum.salary),
    NORDEA("NA", Beneficiary.CategoryEnum.nordea),
    MOBILE("MO", Beneficiary.CategoryEnum.mobile)
    ;

    private final String subType;

    private final Beneficiary.CategoryEnum category;

    BeneficiaryCategory(String subType, Beneficiary.CategoryEnum category) {
        this.subType = subType;
        this.category = category;
    }

    public static BeneficiaryCategory getCategory(final String subType) {
        for (final BeneficiaryCategory category : values()) {
            if (category.subType.equals(subType)) {
                return category;
            }
        }
        throw new IllegalArgumentException("Invalid sub type: " + subType);
    }

    public static String getSubType(final Beneficiary.CategoryEnum category) {
        for (final BeneficiaryCategory categoryList : values()) {
            if (category.equals(categoryList.getBeneficiaryCategory())) {
                return categoryList.subType;
            }
        }
        throw new IllegalArgumentException("Invalid category type: " + category);
    }

    public String subType() {
        return subType;
    }

    public Beneficiary.CategoryEnum getBeneficiaryCategory() {
        return category;
    }
}

