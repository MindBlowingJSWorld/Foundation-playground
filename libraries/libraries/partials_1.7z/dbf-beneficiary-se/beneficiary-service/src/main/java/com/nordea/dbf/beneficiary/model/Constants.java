package com.nordea.dbf.beneficiary.model;

/**
 * Created by G95495 on 01-06-2015.
 *
 * TODO Remove constants like SPACE = " "
 */
public interface Constants {

    int TIME_TO_LIVE = 30;
    int CORPORATE_USERID_SUBSTRING = 2;
    String CORPORATE_CHANNEL = "ePF";
    String SPACE = " ";
    String HYPHEN = "-";
    String DOMESTIC_FLAG_S = "S";
    String DOMESTIC_FLAG_F = "F";
    String COUNTRY_CODE_SE = "SE";
    String CURRENCY_SE = "SEK";
    String ID_CORPORATE = "COR";
    String ID_HH_DOMESTIC = "HHDOM";
    String ID_HH_CROSSBORDER = "HHCB";
    String ID_CORP_DOMESTIC = "CORPDOM";
    String ID_CORP_CROSSBORDER = "CORPCB";
    String CATEGORY_EB = "EB";
    String CATEGORY_PG = "PG";
    String CATEGORY_BG = "BG";
    String CATEGORY_CB = "CB";
    String CATEGORY_PE = "PE";
    String CATEGORY_LO = "LO";
    String CATEGORY_NA = "NA";
    String CATEGORY_MO = "MO";
}
