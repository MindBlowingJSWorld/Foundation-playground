package com.nordea.dbf.beneficiary.model;

import com.nordea.dbf.beneficiary.integration.LegacyService;

/**
 * Created by G95495 on 11-05-2015.
 */
public enum LegacyTransactionDetails implements LegacyService {
    RETRIEVE_HOUSEHOLD_DOMESTIC("FQQ854", "FQQ8541"),
    HOUSEHOLD_CROSS_BORDER("LHP61P52", "LHP52A01"),
    RETRIEVE_CORPORATE("ESM007", "ESM007"),
    ADD_HOUSEHOLD_DOMESTIC("FQP808", "FQP8081"),
    UPDATE_HOUSEHOLD_DOMESTIC("FQP803", "FQP8031"),
    DELETE_HOUSEHOLD_DOMESTIC("FQP804", "FQP8041");

    private final String transactionCode;

    private final String messageId;

    LegacyTransactionDetails(String transactionCode, String messageId) {
        this.transactionCode = transactionCode;
        this.messageId = messageId;
    }

    @Override
    public String transactionCode() {
        return transactionCode;
    }

    @Override
    public String messageId() {
        return messageId;
    }
}
