package com.nordea.dbf.beneficiary.model;

/**
 * Created by G95495 on 18-05-2015.
 */
public enum TransactionFunction {

    RETRIEVE_ALL(01),
    ADD(02),
    UPDATE(03),
    DELETE(04),
    RETRIEVE_SINGLE(06);

    private final int code;

    TransactionFunction(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
