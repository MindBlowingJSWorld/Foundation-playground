package com.nordea.dbf.beneficiary.resources;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.integration.BeneficiaryKey;
import com.nordea.dbf.beneficiary.integration.BeneficiaryProvider;
import com.nordea.dbf.beneficiary.integration.CommonHandler;
import com.nordea.dbf.beneficiary.model.Action;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponse;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.http.errorhandling.exception.RangeUnsatisfiableException;
import com.nordea.dbf.json.JsonUtils;
import com.nordea.dbf.security.annotation.Agreement;
import com.nordea.dbf.security.annotation.Principal;
import com.nordea.nbo.audit.AuditCategory;
import com.nordea.nbo.audit.annotation.Audit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;
import rx.Notification;
import rx.Observable;

import javax.annotation.PreDestroy;
import javax.validation.Valid;
import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import static com.nordea.dbf.messaging.Observables.deferredResultOf;

/**
 * Resource that exposes the com.nordea.dbf.beneficiary REST end-point
 **/
@RestController
@RequestMapping(value = "/banking")
public class BeneficiaryResource {

    private static final Logger LOGGER = LoggerFactory.getLogger(BeneficiaryResource.class);

    @Autowired
    private BeneficiaryProvider beneficiaryProvider;

    @RequestMapping(value = "/beneficiaries", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public DeferredResult<List<Beneficiary>> getBeneficiaryList(ServiceRequestContext serviceRequestContext,
                                                                @RequestHeader(value = "Range",
                                                                        defaultValue = "0-100") String range) {
        final long start = System.nanoTime();
        try {
            CommonHandler.checkRange(range);
        } catch (ParseException pe) {
            throw new RangeUnsatisfiableException(new ErrorResponse("Requested Range Not Satisfied", "416",
                    pe.getMessage(), range));
        }
        return deferredResultOf(beneficiaryProvider.getBeneficiaries(serviceRequestContext, range)
                .toList()
                .doOnCompleted(() -> LOGGER.info("Retrieved beneficiaries in duration = {} ms", TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start))));
    }

    @RequestMapping(value = "/beneficiaries/{beneficiaryId}", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public DeferredResult<Beneficiary> getBeneficiaryById(@PathVariable("beneficiaryId") String beneficiaryId,
                                                          ServiceRequestContext serviceRequestContext) {
        BeneficiaryKey beneficiaryKey = new BeneficiaryKey(beneficiaryId);
        try {
            beneficiaryKey.validateBeneficiaryId();
        } catch (BadRequestException erc) {
            throw  ErrorResponses.invalidRequestParameterException(beneficiaryId, erc.getMessage());
        }
        Observable<Beneficiary> beneficiaryObservable = beneficiaryProvider.getBeneficiaries(serviceRequestContext, null);
        return deferredResultOf(beneficiaryObservable.filter(b -> b.getId().equals(beneficiaryId)).single().materialize()
                .map(n -> {
                    if (n.getThrowable() instanceof NoSuchElementException) {
                        LOGGER.info("Beneficiary {} does not exist", beneficiaryId);
                        return Notification.createOnError(ErrorResponses.requestedResourceNotFoundException("beneficiaryId", "beneficiary not found"));
                    }
                    return n;
                })
                .dematerialize());
    }

    @Audit(description = "Create beneficiary {0}", category = AuditCategory.BOOKKEEP)
    @RequestMapping(value = "/beneficiaries", method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public DeferredResult<Beneficiary> createBeneficiary(@Valid @RequestBody Beneficiary beneficiary, ServiceRequestContext serviceRequestContext) {
        return deferredResultOf(beneficiaryProvider.createBeneficiary(serviceRequestContext, beneficiary), error -> {
            LOGGER.info("Beneficiary could not be created from request: {}", JsonUtils.toPrettyJson(beneficiary), error);
            return error;
        });
    }

    @Audit(description = "Update beneficiary {0}", category = AuditCategory.BOOKKEEP)
    @RequestMapping(value = "/beneficiaries/{beneficiaryId}", method = RequestMethod.PUT,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public DeferredResult<Beneficiary> updateBeneficiary(@PathVariable("beneficiaryId") String beneficiaryId,
                                                         @Valid @RequestBody Beneficiary beneficiary,
                                                         ServiceRequestContext serviceRequestContext) {
        BeneficiaryKey beneficiaryKey = new BeneficiaryKey(beneficiaryId);
        try {
            beneficiaryKey.validateBeneficiaryId();
        } catch (BadRequestException brx) {
            throw ErrorResponses.invalidRequestParameterException(beneficiaryId, brx.getMessage());
        }

        return deferredResultOf(beneficiaryProvider.updateBeneficiary(serviceRequestContext, beneficiary, beneficiaryKey), error -> {
            if (error instanceof NoSuchElementException) {
                LOGGER.info("Beneficiary with id {} could not be updated (not found)", beneficiaryId);
                return ErrorResponses.requestedResourceNotFoundException("beneficiaryId", "beneficiary not found");
            }

            LOGGER.info("Beneficiary with id {} could not be updated with request", beneficiaryId, JsonUtils.toPrettyJson(beneficiary), error);

            return error;
        }, log -> {
            LOGGER.info("Beneficiary with id {} was updated", beneficiaryId);
        });
    }

    @Audit(description = "Delete beneficiary id {0}", category = AuditCategory.BOOKKEEP)
    @RequestMapping(value = "/beneficiaries/{beneficiaryId}", method = RequestMethod.DELETE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public DeferredResult<Beneficiary> deleteBeneficiary(@PathVariable("beneficiaryId") String beneficiaryId,
                                                         ServiceRequestContext serviceRequestContext) {
        BeneficiaryKey beneficiaryKey = new BeneficiaryKey(beneficiaryId);
        try {
            beneficiaryKey.validateBeneficiaryId();
        } catch (BadRequestException bre) {
            throw ErrorResponses.invalidRequestParameterException(beneficiaryId, bre.getMessage());
        }

        return deferredResultOf(beneficiaryProvider.deleteBeneficiary(serviceRequestContext, beneficiaryId, beneficiaryKey), error -> {
            LOGGER.info("Beneficiary with id {} could not be deleted", beneficiaryId, error);

            return error;
        }, log -> {
            LOGGER.info("Beneficiary with id {} was deleted", beneficiaryId);
        });
    }


}
