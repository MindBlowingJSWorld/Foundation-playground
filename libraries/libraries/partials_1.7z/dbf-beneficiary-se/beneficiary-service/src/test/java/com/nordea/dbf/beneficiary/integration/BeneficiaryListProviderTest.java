package com.nordea.dbf.beneficiary.integration;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Created by G95495 on 09-06-2015.
 */
public class BeneficiaryListProviderTest  {

    public static final String ACCOUNT_NUMBER = "12345678";

    @Test
    public void accountFormatPG(){
        String accountNumber = CommonHandler.setToFormat("PG", null, ACCOUNT_NUMBER);

        assertThat(accountNumber).isEqualTo("PG-" + ACCOUNT_NUMBER);
    }

    @Test
    public void accountFormatBG(){
        String accountNumber = CommonHandler.setToFormat("BG", null, ACCOUNT_NUMBER);

        assertThat(accountNumber).isEqualTo("BG-" + ACCOUNT_NUMBER);
    }

    @Test
    public void accountFormatNA(){
        String accountNumber = CommonHandler.setToFormat("NA", null, ACCOUNT_NUMBER);

        assertThat(accountNumber).isEqualTo("NAID-" + "SE-" + "SEK-" + ACCOUNT_NUMBER);
    }

    @Test
    public void accountFormatCB(){
        String accountNumber = CommonHandler.setToFormat("CB", "NDEAKK", ACCOUNT_NUMBER);

//TODO: check implementation - accountFormat "CB" returns accountFormat "CROSSBORDER-1234" - shouldn't format  "IBAN-NDEAKK-1234" be used?
//        assertThat(accountNumber).isEqualTo("IBAN-" + "NDEAKK-" + ACCOUNT_NUMBER);
        assertThat(accountNumber).isEqualTo("CROSSBORDER-" + ACCOUNT_NUMBER);
    }

    @Test
    public void accountFormatEB(){
        String accountNumber = CommonHandler.setToFormat("EB", null, ACCOUNT_NUMBER);

        assertThat(accountNumber).isEqualTo("LBAN-" + "SE-" + ACCOUNT_NUMBER);
    }

    @Test
    public void clearingNumberNotNull(){
        String accountNumber = CommonHandler.setToFormat("EB", null, "1234" + ACCOUNT_NUMBER);

        assertThat(accountNumber).isEqualTo("LBAN-" + "SE-" + "1234" + ACCOUNT_NUMBER);
    }

    @Test
    public void accountFormatMO(){
        String accountNumber = CommonHandler.setToFormat("MO", null, ACCOUNT_NUMBER);

        assertThat(accountNumber).isEqualTo(ACCOUNT_NUMBER);
    }

    @Test
    public void accountFormatDefault(){
        String accountNumber = CommonHandler.setToFormat("LE", null, ACCOUNT_NUMBER);

        assertThat(accountNumber).isEqualTo(ACCOUNT_NUMBER);
    }
}
