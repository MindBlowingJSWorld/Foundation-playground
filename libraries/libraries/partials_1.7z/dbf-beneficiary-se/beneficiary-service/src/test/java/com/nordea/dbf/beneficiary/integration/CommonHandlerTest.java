package com.nordea.dbf.beneficiary.integration;

import com.nordea.dbf.beneficiary.integration.CommonHandler;
import org.junit.BeforeClass;
import org.junit.Test;

import java.text.ParseException;

import static org.assertj.core.api.Assertions.assertThat;
/**
 * Created by G95495 on 10-06-2015.
 */
public class CommonHandlerTest {

    private final CommonHandler commonHandler = new CommonHandler();

    @BeforeClass
    public static void setupEnvironment() throws Exception {
        System.setProperty("com.nordea.environmenttype", "UNIT_TEST");
    }

   @Test
    public void startGreaterThanEndShouldFail(){
        try {
            commonHandler.checkRange("6-3");
        }
        catch (ParseException e){
            assertThat(e.getMessage()).isEqualTo("Incorrect Range specified. Start must be smaller than or equal to end");
            assertThat(e.getErrorOffset()).isEqualTo(3);
        }

        try {
            commonHandler.checkRange("3-0");
        }
        catch (ParseException e){
            assertThat(e.getMessage()).isEqualTo("Incorrect Range specified. Start must be smaller than or equal to end");
            assertThat(e.getErrorOffset()).isEqualTo(3);
        }
    }

    @Test
    public void startNegativeShouldFail(){
        try {
            commonHandler.checkRange("-1-3");
        }
        catch (ParseException e){
            assertThat(e.getMessage()).isEqualTo("Incorrect Range specified. Range must be in the format start-end");
            assertThat(e.getErrorOffset()).isEqualTo(4);
        }
    }

    @Test
    public void incorrectRangeFormatShouldFail(){
        try {
            commonHandler.checkRange("2-4-5");
        }
        catch (ParseException e){
            assertThat(e.getMessage()).isEqualTo("Incorrect Range specified. Range must be in the format start-end");
            assertThat(e.getErrorOffset()).isEqualTo(5);
        }
    }
}
