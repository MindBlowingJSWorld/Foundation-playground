package com.nordea.dbf.beneficiary.integration.corporate;

import com.nordea.dbf.agreement.Agreement;
import com.nordea.dbf.agreement.Engagement;
import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListResponseBeneficiariesSegment;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListResponseRecord;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextBuilder;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by G95495 on 01-06-2015.
 */
public class RetrieveCorporateBeneficiaryListTest {

    public static final String USER_ID = "194408012369";
    public static final long AGREEMENT_NUMBER = 3931251;
    public static final String RACF_ID = "V000743";
    public static final String AGREEMENT_OWNER = "000007130551";
    public static final String NAME = "testName";
    public static final String NICK_NAME = "testNickName";
    public static final String PAYMENT_TYPE = "PG";
    public static final String ACCOUNT_NUMBER = "12345678";

    private final BackendConnector connector = mock(BackendConnector.class);
    private final RetrieveCorporateBeneficiaryList facade = new RetrieveCorporateBeneficiaryList(connector);
    private final BackendConnection connection = mock(BackendConnection.class);
    private final ServiceRequestContext requestContext = new ServiceRequestContextBuilder()
            .requestRoute(Collections.singletonList("127.0.0.1"))
            .sessionId("aSessionId")
            .requestId("aRequestId")
            .userId(USER_ID)
            .build();

    private final Agreement agreement = new Agreement("test", USER_ID, String.valueOf(AGREEMENT_NUMBER));

    @Before
    public void setUp() throws Exception{
        when(connector.connect()).thenReturn(connection);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testInvalidArguments(){
        facade.getCorporateBeneficiaryList(null, AGREEMENT_NUMBER, null);
        fail("null requestContext should be rejected");

        facade.getCorporateBeneficiaryList(requestContext, null, null);
        fail("null agreementNumber should be rejected");

    }

    @Test
    public void createRequest(){
        Engagement engagement = createMockEngagement();
        CorporateBeneficiaryListRequestRecord requestRecord = facade.createRequest(requestContext, AGREEMENT_NUMBER, engagement);

        assertThat(requestRecord.getChannelId()).isEqualTo("ePF");
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID.substring(2));
        assertThat(requestRecord.getRacfId()).isEqualTo(RACF_ID);

        Agreement agreement = engagement.getAgreementById(String.valueOf(AGREEMENT_NUMBER));
        assertThat(requestRecord.getAgreementOwner()).isEqualTo(agreement.getCustomer());
        assertThat(requestRecord.getTransactionCode()).isEqualTo("ESM007");
        assertThat(requestRecord.getMessageId()).isEqualTo("ESM007");
    }

    @Test
    public void sessionIdShouldBeConfiguredInRecord() {
        CorporateBeneficiaryListRequestRecord requestRecord = facade.createRequest(requestContext, AGREEMENT_NUMBER, createMockEngagement());

        assertThat(requestRecord.getSessionId()).isEqualTo("aSessionId");
    }

    @Test
    public void sessionIdShouldBeEmptyIfNotContainedInContext() {
        final ServiceRequestContext context = new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .userId(USER_ID)
                .build();

        CorporateBeneficiaryListRequestRecord requestRecord = facade.createRequest(context, AGREEMENT_NUMBER, createMockEngagement());

        assertThat(requestRecord.getSessionId()).isEmpty();
    }

    @Test
    public void getCorporateBeneficiaryList(){
        final CorporateBeneficiaryListResponseRecord responseRecord = createCorporateResponse();
        List<Beneficiary> beneficiaryList = facade.fetchResponse(responseRecord, null);
        assertThat(beneficiaryList.size()).isEqualTo(1);

        Beneficiary beneficiary = beneficiaryList.get(0);
        assertThat(beneficiary.getName()).isEqualTo("testName");
        assertThat(beneficiary.getNickname()).isEqualTo("testNickName");
        assertThat(beneficiary.getTo()).isEqualTo("LBAN-SE-210512345678");
        assertThat(beneficiary.getCategory().toString()).isEqualTo("pg");
        assertThat(beneficiary.getDisplayNumber()).isEqualTo("2105-12345678");
    }

    private Engagement createMockEngagement(){
        List<Agreement> agreementList = new ArrayList<Agreement>();
        agreementList.add(agreement);

        return new Engagement(agreementList, RACF_ID);
    }

    private CorporateBeneficiaryListResponseRecord createCorporateResponse(){
        CorporateBeneficiaryListResponseRecord responseRecord = new CorporateBeneficiaryListResponseRecord();
        responseRecord.setNoOfBeneficiaries(1);

        CorporateBeneficiaryListResponseBeneficiariesSegment segment = responseRecord.addBeneficiaries();
        segment.setUserId(USER_ID);
        segment.setAgreementOwner(AGREEMENT_OWNER);
        segment.setName(NAME);
        segment.setNickname(NICK_NAME);
        segment.setPaymentSubTypeEx(PAYMENT_TYPE);
        segment.setClearingNumber("2105");
        segment.setFormattedAccNo("2105-12345678");
        segment.setAccountNumber(ACCOUNT_NUMBER);
        return responseRecord;
    }
}
