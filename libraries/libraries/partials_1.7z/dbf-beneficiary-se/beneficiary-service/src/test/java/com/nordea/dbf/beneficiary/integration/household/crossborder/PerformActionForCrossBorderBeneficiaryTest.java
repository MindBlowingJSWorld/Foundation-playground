package com.nordea.dbf.beneficiary.integration.household.crossborder;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.integration.BeneficiaryKey;
import com.nordea.dbf.beneficiary.model.Action;
import com.nordea.dbf.beneficiary.model.LegacyTransactionDetails;
import com.nordea.dbf.beneficiary.model.TransactionFunction;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHCrossBorderBeneficiaryListRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHCrossBorderBeneficiaryListResponseBeneficiariesSegment;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHCrossBorderBeneficiaryListResponseRecord;
import com.nordea.dbf.customer.agreements.se.integration.model.*;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextBuilder;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by G95495 on 01-06-2015.
 */
public class PerformActionForCrossBorderBeneficiaryTest {

    public static final String USER_ID = "196807130551";
    public static final long AGREEMENT_NUMBER = 3932910;
    public static final String PAYMENT_TYPE = "C";
    public static final int PAYMENT_SUB_TYPE = 1;
    public static final String NAME = "testName";
    public static final String NICK_NAME = "testNickName";
    public static final String ACCOUNT_NUMBER = "12345678";

    private final BackendConnector connector = mock(BackendConnector.class);
    private final PerformActionForCrossBorderBeneficiary facade = new PerformActionForCrossBorderBeneficiary(connector);
    private final BackendConnection connection = mock(BackendConnection.class);
    private final ServiceRequestContext requestContext = new ServiceRequestContextBuilder()
            .requestRoute(Collections.singletonList("127.0.0.1"))
            .sessionId("aSessionId")
            .requestId("aRequestId")
            .userId(USER_ID)
            .build();

    private final Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID,
            new AgreementNumber(AGREEMENT_NUMBER), AgreementType.PRIVATE, AgreementRole.A);

    private final Beneficiary beneficiary = new Beneficiary();

    private String beneficiaryId = "HHCB-CB-12345678-testNickName";
    private BeneficiaryKey beneficiaryKeyId = new BeneficiaryKey(beneficiaryId);

    @Before
    public void setUp() throws Exception{
        when(connector.connect()).thenReturn(connection);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testInvalidArguments(){

        facade.getAllBeneficiaries(null, agreement);
        fail("null requestContext should be rejected");

        facade.getAllBeneficiaries(requestContext, null);
        fail("null agreementNumber should be rejected");
    }

    @Test
    public void sessionIdShouldBeEmptyIfNotContainedInContext() {
        final ServiceRequestContext context = new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .userId(USER_ID)
                .build();

        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        requestRecord = facade.createRequestRecord(requestRecord, context, TransactionFunction.UPDATE.getCode(), "transactionId", "messageId");
        assertThat(requestRecord.getSessionId()).isEmpty();
    }

    @Test
    public void createRequestRetrieveAll(){
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        int function = TransactionFunction.RETRIEVE_ALL.getCode();
        String trasactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();
        requestRecord = facade.createRequestRecord(requestRecord, requestContext, function, trasactionId, messageId);

        assertThat(requestRecord.getTransactionCode()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode());
        assertThat(requestRecord.getMessageId()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId());
        assertThat(requestRecord.getFunction()).isEqualTo(TransactionFunction.RETRIEVE_ALL.getCode());
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID);
    }

    @Test
    public void createRequestRetrieveSingle(){
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        int function = TransactionFunction.RETRIEVE_SINGLE.getCode();
        String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();
        requestRecord = facade.createRequestRecord(requestRecord, requestContext, function, transactionId, messageId);
        requestRecord.setUserId(USER_ID);
        requestRecord.setOwnerId(USER_ID);
        requestRecord.setBenefAccountNumber(ACCOUNT_NUMBER);
        requestRecord.setPaymentType(PAYMENT_TYPE);
        requestRecord.setBenefNickname(NICK_NAME);

        assertThat(requestRecord.getTransactionCode()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode());
        assertThat(requestRecord.getMessageId()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId());
        assertThat(requestRecord.getFunction()).isEqualTo(TransactionFunction.RETRIEVE_SINGLE.getCode());
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getOwnerId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getBenefAccountNumber()).isEqualTo(ACCOUNT_NUMBER);
        assertThat(requestRecord.getBenefNickname()).isEqualTo(NICK_NAME);
        assertThat(requestRecord.getPaymentType()).isEqualTo(PAYMENT_TYPE);
    }

    @Test
    public void createRequestAdd(){
        String toAccount = "IBAN-NDEAFIHH-DE74600700700121219000";
        beneficiary.setTo(toAccount);
        beneficiary.setName(NAME);
        beneficiary.setNickname(NICK_NAME);

        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        int function = TransactionFunction.ADD.getCode();
        String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();
        requestRecord = facade.createRequestRecord(requestRecord, requestContext, function, transactionId, messageId);
        requestRecord.setUserId(USER_ID);
        requestRecord.setOwnerId(USER_ID);
        requestRecord.setAccountNumber("DE74600700700121219000");
        requestRecord.setBenefAccountNumber("DE74600700700121219000");
        requestRecord.setPaymentType(PAYMENT_TYPE);
        requestRecord.setBenefNickname(beneficiary.getNickname());
        requestRecord.setNickname(beneficiary.getNickname());
        requestRecord.setName(beneficiary.getName());
        requestRecord.setPaymentSubType(PAYMENT_SUB_TYPE);
        requestRecord.setSwiftCode("NDEAFIHH");
        requestRecord.setLocalCodePN("FI");

        assertThat(requestRecord.getTransactionCode()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode());
        assertThat(requestRecord.getMessageId()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId());
        assertThat(requestRecord.getFunction()).isEqualTo(TransactionFunction.ADD.getCode());
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getOwnerId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getAccountNumber()).isEqualTo("DE74600700700121219000");
        assertThat(requestRecord.getBenefAccountNumber()).isEqualTo("DE74600700700121219000");
        assertThat(requestRecord.getPaymentType()).isEqualTo(PAYMENT_TYPE);
        assertThat(requestRecord.getNickname()).isEqualTo(NICK_NAME);
        assertThat(requestRecord.getBenefNickname()).isEqualTo(NICK_NAME);
        assertThat(requestRecord.getName()).isEqualTo(NAME);
        assertThat(requestRecord.getPaymentSubType()).isEqualTo(PAYMENT_SUB_TYPE);
        assertThat(requestRecord.getSwiftCode()).isEqualTo("NDEAFIHH");
        assertThat(requestRecord.getLocalCodePN()).isEqualTo("FI");
    }

    @Test
    public void createRequestDelete(){
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = new HHCrossBorderBeneficiaryListRequestRecord();
        int function = TransactionFunction.DELETE.getCode();
        String transactionId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode();
        String messageId = LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId();
        requestRecord = facade.createRequestRecord(requestRecord, requestContext, function, transactionId, messageId);
        requestRecord.setUserId(USER_ID);
        requestRecord.setOwnerId(USER_ID);
        requestRecord.setBenefAccountNumber(ACCOUNT_NUMBER);
        requestRecord.setBenefNickname(NICK_NAME);
        requestRecord.setPaymentType(PAYMENT_TYPE);

        assertThat(requestRecord.getTransactionCode()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode());
        assertThat(requestRecord.getMessageId()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId());
        assertThat(requestRecord.getFunction()).isEqualTo(TransactionFunction.DELETE.getCode());
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getOwnerId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getBenefAccountNumber()).isEqualTo(ACCOUNT_NUMBER);
        assertThat(requestRecord.getBenefNickname()).isEqualTo(NICK_NAME);
        assertThat(requestRecord.getPaymentType()).isEqualTo(PAYMENT_TYPE);
    }

    @Test
    public void createRequestUpdate(){
        String toAccount = "IBAN-NDEAFIHH-DE74600700700121219000";
        beneficiary.setTo(toAccount);
        beneficiary.setName(NAME);
        beneficiary.setNickname(NICK_NAME);
        beneficiary.setMessage("FW12345");
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = facade.createUpdateRequest(requestContext, agreement,
                beneficiary, beneficiaryKeyId, createHHCrossBorderResponse());

        assertThat(requestRecord.getTransactionCode()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.transactionCode());
        assertThat(requestRecord.getMessageId()).isEqualTo(LegacyTransactionDetails.HOUSEHOLD_CROSS_BORDER.messageId());
        assertThat(requestRecord.getFunction()).isEqualTo(TransactionFunction.UPDATE.getCode());
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getOwnerId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getAccountNumber()).isEqualTo(ACCOUNT_NUMBER);
        assertThat(requestRecord.getBenefAccountNumber()).isEqualTo("DE74600700700121219000");
        assertThat(requestRecord.getPaymentType()).isEqualTo(PAYMENT_TYPE);
        assertThat(requestRecord.getNickname()).isEqualTo(NICK_NAME);
        assertThat(requestRecord.getBenefNickname()).isEqualTo(NICK_NAME);
        assertThat(requestRecord.getName()).isEqualTo(NAME);
        assertThat(requestRecord.getSwiftCode()).isEqualTo("NDEAFIHH");
        assertThat(requestRecord.getLocalCodePN()).isEqualTo("FI");
        assertThat(requestRecord.getBankCode()).isEqualTo("FW12345");
    }

    @Test
    public void checkSpecialCasesUpdate(){
        String toAccount = "IBAN-NDEAFIHH-DE74600700700121219000";
        beneficiary.setTo(toAccount);
        beneficiary.setMessage("FW12345");
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = facade.createUpdateRequest(requestContext, agreement,
                beneficiary, beneficiaryKeyId, createHHCrossBorderResponse());
        assertThat(requestRecord.getSwiftCode()).isEqualTo("NDEAFIHH");
        assertThat(requestRecord.getLocalCodePN()).isEqualTo("FI");
        assertThat(requestRecord.getBankCode()).isEqualTo("FW12345");

        toAccount = "IBAN-NDEAFIHH-DE74600700700121219000";
        beneficiary.setTo(toAccount);
        beneficiary.setMessage("//FW147 258 369");
        requestRecord = facade.createUpdateRequest(requestContext, agreement,
                beneficiary, beneficiaryKeyId, createHHCrossBorderResponse());
        assertThat(requestRecord.getSwiftCode()).isEqualTo("NDEAFIHH");
        assertThat(requestRecord.getLocalCodePN()).isEqualTo("FI");
        assertThat(requestRecord.getBankCode()).isEqualTo("//FW147 258 369");
    }

    @Test
    public void checkSpecialCasesAdd(){
        String toAccount = "IBAN-NDEAFIHH-DE74600700700121219000";
        beneficiary.setTo(toAccount);
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = facade.createRequestRecord(new HHCrossBorderBeneficiaryListRequestRecord(),
                requestContext, 1, "", "");
        requestRecord.setSwiftCode("NDEAFIHH");
        requestRecord.setLocalCodePN("FI");

        assertThat(requestRecord.getSwiftCode()).isEqualTo("NDEAFIHH");
        assertThat(requestRecord.getLocalCodePN()).isEqualTo("FI");
        assertThat(requestRecord.getBankCode()).isEqualTo("");

        toAccount = "IBAN-NDEAFIHH-DE74600700700121219000";
        beneficiary.setTo(toAccount);
        beneficiary.setMessage("//FW147 258 369");
        requestRecord = facade.createRequestRecord(new HHCrossBorderBeneficiaryListRequestRecord(),
                requestContext, 1, "", "");
        requestRecord.setSwiftCode("NDEAFIHH");
        requestRecord.setLocalCodePN("FI");
        requestRecord.setBankCode(beneficiary.getMessage());
        assertThat(requestRecord.getSwiftCode()).isEqualTo("NDEAFIHH");
        assertThat(requestRecord.getLocalCodePN()).isEqualTo("FI");
        assertThat(requestRecord.getBankCode()).isEqualTo("//FW147 258 369");
    }

    @Test
    public void sessionIdAndRequestIdShouldBeConfiguredInRecord() {
        HHCrossBorderBeneficiaryListRequestRecord requestRecord = facade.createRequestRecord(new HHCrossBorderBeneficiaryListRequestRecord(),
                requestContext, 1, "transactionId", "messageId");

        assertThat(requestRecord.getRequestId()).isEqualTo("aRequestId");
        assertThat(requestRecord.getSessionId()).isEqualTo("aSessionId");
    }



    @Test
    public void getHHCrossBorderBeneficiaryList(){
        final HHCrossBorderBeneficiaryListResponseRecord responseRecord = createHHCrossBorderResponse();
        List<Beneficiary> beneficiaryList = facade.fetchResponse(responseRecord);
        assertThat(beneficiaryList.size()).isEqualTo(1);

        Beneficiary beneficiary = beneficiaryList.get(0);
        assertThat(beneficiary.getId()).isEqualTo("HHCB-CB-" + ACCOUNT_NUMBER + "-" + NICK_NAME);
        assertThat(beneficiary.getName()).isEqualTo("testName");
        assertThat(beneficiary.getNickname()).isEqualTo("testNickName");
//TODO: check implementation - returns accountFormat "CROSSBORDER-12345678" - shouldn't format  "IBAN-NDEASESS-12345678" be used?
//        assertThat(beneficiary.getTo()).isEqualTo("IBAN-NDEASESS-12345678");
        assertThat(beneficiary.getTo()).isEqualTo("CROSSBORDER-12345678");
        assertThat(beneficiary.getCategory().toString()).isEqualTo("cross_border");
        assertThat(beneficiary.getDisplayNumber()).isEqualTo(ACCOUNT_NUMBER);
    }

    private HHCrossBorderBeneficiaryListResponseRecord createHHCrossBorderResponse(){
        HHCrossBorderBeneficiaryListResponseRecord responseRecord = new HHCrossBorderBeneficiaryListResponseRecord();
        responseRecord.setNoOfBeneficiaries(1);

        HHCrossBorderBeneficiaryListResponseBeneficiariesSegment segment = responseRecord.addBeneficiaries();
        segment.setName(NAME);
        segment.setNickname(NICK_NAME);
        segment.setSwiftCode("NDEASESS");
        segment.setLocalCodePN("SE");
        segment.setAccountNumber(ACCOUNT_NUMBER);
        segment.setPaymentSubType(1);
        segment.setLocalCode("SE");
        segment.setBankCode("FW12345");
        return responseRecord;
    }
}
