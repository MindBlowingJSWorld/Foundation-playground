package com.nordea.dbf.beneficiary.integration.household.domestic;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.integration.BeneficiaryKey;
import com.nordea.dbf.beneficiary.model.LegacyTransactionDetails;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticDeleteBeneficiaryRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticDeleteBeneficiaryResponseRecord;
import com.nordea.dbf.customer.agreements.se.integration.model.*;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextBuilder;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Deleted by G95495 on 01-06-2015.
 */

public class DeleteDomesticBeneficiaryTest {

    public static final String USER_ID = "196807130551";
    public static final long AGREEMENT_NUMBER = 3932910;
    public static final String NAME = "testName";
    public static final String NICK_NAME = "testNickName";
    public static final String PAYMENT_TYPE = "PG";
    public static final long ACCOUNT_NUMBER = 12345678;
    public static final Beneficiary EXISTING_BENEFICIARY = new Beneficiary();
    private String beneficiaryId = "HHDOM-PG-12345678-testNickName";
    private BeneficiaryKey beneficiaryKeyId = new BeneficiaryKey(beneficiaryId);

    private final BackendConnector connector = mock(BackendConnector.class);
    private final DeleteDomesticBeneficiary facade = new DeleteDomesticBeneficiary(connector);
    private final BackendConnection connection = mock(BackendConnection.class);
    private final ServiceRequestContext requestContext = new ServiceRequestContextBuilder()
            .requestRoute(Collections.singletonList("127.0.0.1"))
            .sessionId("aSessionId")
            .requestId("aRequestId")
            .userId(USER_ID)
            .build();

    private final Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID,
            new AgreementNumber(AGREEMENT_NUMBER), AgreementType.PRIVATE, AgreementRole.A);

    @Before
    public void setUp() throws Exception{
        when(connector.connect()).thenReturn(connection);
    }


    @Test (expected = IllegalArgumentException.class)
    public void testInvalidArguments(){
        Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID, new AgreementNumber((long) AGREEMENT_NUMBER),
                AgreementType.PRIVATE, AgreementRole.A);

        facade.hhDomesticDeleteBeneficiary(null, agreement, beneficiaryKeyId, EXISTING_BENEFICIARY);
        fail("null requestContext should be rejected");
        facade.hhDomesticDeleteBeneficiary(requestContext, null, beneficiaryKeyId, EXISTING_BENEFICIARY);
        fail("null agreementNumber should be rejected");
        facade.hhDomesticDeleteBeneficiary(requestContext, agreement, null, EXISTING_BENEFICIARY);
        fail("null beneficiaryId should be rejected");
    }

    @Test
    public void createRequest(){
        HHDomesticDeleteBeneficiaryRequestRecord requestRecord = facade.createDeleteRequest(requestContext, agreement, beneficiaryKeyId);

        assertThat(requestRecord.getTransactionCode()).isEqualTo(LegacyTransactionDetails.DELETE_HOUSEHOLD_DOMESTIC.transactionCode());
        assertThat(requestRecord.getMessageId()).isEqualTo(LegacyTransactionDetails.DELETE_HOUSEHOLD_DOMESTIC.messageId());
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getOwnerId()).isEqualTo(Long.parseLong(USER_ID));
        assertThat(requestRecord.getPaymentType()).isEqualTo("PG");
        assertThat(requestRecord.getAgreementNumber()).isEqualTo(AGREEMENT_NUMBER);
        assertThat(requestRecord.getAccountNumber()).isEqualTo(ACCOUNT_NUMBER);
        assertThat(requestRecord.getNickname()).isEqualTo(NICK_NAME);
    }

    @Test
    public void sessionIdShouldBeConfiguredInRecord() {
        HHDomesticDeleteBeneficiaryRequestRecord requestRecord = facade.createDeleteRequest(requestContext, agreement, beneficiaryKeyId);
        assertThat(requestRecord.getSessionId()).isEqualTo("aSessionId");
    }

    @Test
    public void sessionIdShouldBeEmptyIfNotContainedInContext() {
        final ServiceRequestContext context = new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .userId(USER_ID)
                .build();

        HHDomesticDeleteBeneficiaryRequestRecord requestRecord = facade.createDeleteRequest(context, agreement, beneficiaryKeyId);
        assertThat(requestRecord.getSessionId()).isEmpty();
    }

    private HHDomesticDeleteBeneficiaryResponseRecord createHHDomesticResponse(){
        return new HHDomesticDeleteBeneficiaryResponseRecord();
    }

}
