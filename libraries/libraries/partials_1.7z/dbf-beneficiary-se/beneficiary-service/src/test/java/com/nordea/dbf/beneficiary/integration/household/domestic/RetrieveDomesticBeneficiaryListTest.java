package com.nordea.dbf.beneficiary.integration.household.domestic;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.model.LegacyTransactionDetails;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticBeneficiaryListRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticBeneficiaryListResponseBeneficiariesSegment;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticBeneficiaryListResponseRecord;
import com.nordea.dbf.customer.agreements.se.integration.model.*;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextBuilder;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by G95495 on 01-06-2015.
 */
public class RetrieveDomesticBeneficiaryListTest {

    public static final String USER_ID = "196807130551";
    public static final long AGREEMENT_NUMBER = 3932910;
    public static final String NAME = "testName";
    public static final String NICK_NAME = "testNickName";
    public static final String PAYMENT_TYPE = "PG";
    public static final String ACCOUNT_NUMBER = "12345678";

    private final BackendConnector connector = mock(BackendConnector.class);
    private final RetrieveDomesticBeneficiaryList facade = new RetrieveDomesticBeneficiaryList(connector);
    private final BackendConnection connection = mock(BackendConnection.class);
    private final ServiceRequestContext requestContext = new ServiceRequestContextBuilder()
            .requestRoute(Collections.singletonList("127.0.0.1"))
            .sessionId("aSessionId")
            .requestId("aRequestId")
            .userId(USER_ID)
            .build();

    private final Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID,
            new AgreementNumber(AGREEMENT_NUMBER), AgreementType.PRIVATE, AgreementRole.A);

    @Before
    public void setUp() throws Exception{
        when(connector.connect()).thenReturn(connection);
    }

    @Test (expected = IllegalArgumentException.class)
    public void testInvalidArguments(){
        Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID, new AgreementNumber((long) AGREEMENT_NUMBER),
                AgreementType.PRIVATE, AgreementRole.A);

        facade.getHHDomesticBeneficiaryList(null, agreement);
        fail("null requestContext should be rejected");

        facade.getHHDomesticBeneficiaryList(requestContext, null);
        fail("null agreementNumber should be rejected");
    }

    @Test
    public void createRequest(){

        HHDomesticBeneficiaryListRequestRecord requestRecord = facade.createRequest(requestContext, agreement);

        assertThat(requestRecord.getFlag()).isEqualTo("S");
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getOwnerId()).isEqualTo(Long.parseLong(USER_ID));
        assertThat(requestRecord.getPaymentType()).isEqualTo("");
        assertThat(requestRecord.getAgreementNumber()).isEqualTo(AGREEMENT_NUMBER);
        assertThat(requestRecord.getTransactionCode()).isEqualTo(LegacyTransactionDetails.RETRIEVE_HOUSEHOLD_DOMESTIC.transactionCode());
        assertThat(requestRecord.getMessageId()).isEqualTo(LegacyTransactionDetails.RETRIEVE_HOUSEHOLD_DOMESTIC.messageId());
    }

    @Test
    public void sessionIdAndRequestIdShouldBeConfiguredInRecord() {
        HHDomesticBeneficiaryListRequestRecord requestRecord = facade.createRequest(requestContext, agreement);

        assertThat(requestRecord.getRequestId()).isEqualTo("aRequestId");
        assertThat(requestRecord.getSessionId()).isEqualTo("aSessionId");
    }

    @Test
    public void sessionIdShouldBeEmptyIfNotContainedInContext() {
        final ServiceRequestContext context = new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .userId(USER_ID)
                .build();

        HHDomesticBeneficiaryListRequestRecord requestRecord = facade.createRequest(context, agreement);

        assertThat(requestRecord.getSessionId()).isEmpty();
    }

    @Test
    public void getHHDomesticBeneficiaryList(){
        final HHDomesticBeneficiaryListResponseRecord responseRecord = createHHDomesticResponse();
        List<Beneficiary> beneficiaryList = facade.fetchResponse(responseRecord);
        assertThat(beneficiaryList.size()).isEqualTo(1);

        Beneficiary beneficiary = beneficiaryList.get(0);
        assertThat(beneficiary.getId()).isEqualTo("HHDOM-PG-" + ACCOUNT_NUMBER + "-" + "testNickName");
        assertThat(beneficiary.getName()).isEqualTo("testName");
        assertThat(beneficiary.getNickname()).isEqualTo("testNickName");
        assertThat(beneficiary.getTo()).isEqualTo("PG-12345678");
        assertThat(beneficiary.getCategory().toString()).isEqualTo("pg");
        assertThat(beneficiary.getDisplayNumber()).isEqualTo(ACCOUNT_NUMBER);
    }

    private HHDomesticBeneficiaryListResponseRecord createHHDomesticResponse(){
        HHDomesticBeneficiaryListResponseRecord responseRecord = new HHDomesticBeneficiaryListResponseRecord();
        responseRecord.setNoOfBeneficiaries(1);

        HHDomesticBeneficiaryListResponseBeneficiariesSegment segment = responseRecord.addBeneficiaries();
        segment.setName(NAME);
        segment.setNickname(NICK_NAME);
        segment.setPaymentType(PAYMENT_TYPE);
        segment.setAccountNumber(Long.parseLong(ACCOUNT_NUMBER));
        return responseRecord;
    }

}
