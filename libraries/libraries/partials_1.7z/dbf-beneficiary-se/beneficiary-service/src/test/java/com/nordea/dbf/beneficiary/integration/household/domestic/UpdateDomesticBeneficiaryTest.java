package com.nordea.dbf.beneficiary.integration.household.domestic;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.integration.BeneficiaryKey;
import com.nordea.dbf.beneficiary.model.LegacyTransactionDetails;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticUpdateBeneficiaryRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticUpdateBeneficiaryResponseRecord;
import com.nordea.dbf.customer.agreements.se.integration.model.*;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextBuilder;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import org.junit.Before;
import org.junit.Test;

import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Updated by G95495 on 01-06-2015.
 */
public class UpdateDomesticBeneficiaryTest {

    public static final String USER_ID = "196807130551";
    public static final long AGREEMENT_NUMBER = 3932910;
    public static final String NAME = "testName";
    public static final String NICK_NAME = "testNickName";
    public static final String PAYMENT_TYPE = "PG";
    public static final long ACCOUNT_NUMBER = 12345678L;
    private final Beneficiary beneficiary = new Beneficiary();
    private String beneficiaryId = "HHDOM-PG-12345678-testNickName";
    private BeneficiaryKey beneficiaryKeyId = new BeneficiaryKey(beneficiaryId);

    private final BackendConnector connector = mock(BackendConnector.class);
    private final UpdateDomesticBeneficiary facade = new UpdateDomesticBeneficiary(connector);
    private final BackendConnection connection = mock(BackendConnection.class);
    private final ServiceRequestContext requestContext = new ServiceRequestContextBuilder()
            .requestRoute(Collections.singletonList("127.0.0.1"))
            .sessionId("aSessionId")
            .requestId("aRequestId")
            .userId(USER_ID)
            .build();

    private final Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID,
            new AgreementNumber(AGREEMENT_NUMBER), AgreementType.PRIVATE, AgreementRole.A);

    @Before
    public void setUp() throws Exception{
        when(connector.connect()).thenReturn(connection);
        beneficiary.setCategory(Beneficiary.CategoryEnum.pg);
        beneficiary.setNickname(NICK_NAME);
        beneficiary.setName(NAME);
        beneficiary.setTo(PAYMENT_TYPE + "-" + ACCOUNT_NUMBER);
    }


    @Test (expected = IllegalArgumentException.class)
    public void testInvalidArguments(){
        Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID, new AgreementNumber((long) AGREEMENT_NUMBER),
                AgreementType.PRIVATE, AgreementRole.A);

        facade.hhDomesticUpdateBeneficiary(null, agreement, beneficiary, beneficiaryKeyId);
        fail("null requestContext should be rejected");
        facade.hhDomesticUpdateBeneficiary(requestContext, null, beneficiary, beneficiaryKeyId);
        fail("null agreementNumber should be rejected");
        facade.hhDomesticUpdateBeneficiary(requestContext, agreement, null, beneficiaryKeyId);
        fail("null beneficiary should be rejected");
        facade.hhDomesticUpdateBeneficiary(requestContext, agreement, beneficiary, null);
        fail("null beneficiaryId should be rejected");
    }

    @Test
    public void createRequest(){
        HHDomesticUpdateBeneficiaryRequestRecord requestRecord = facade.createUpdateRequest(requestContext, agreement,
                beneficiary, beneficiaryKeyId);

        assertThat(requestRecord.getTransactionCode()).isEqualTo(LegacyTransactionDetails.UPDATE_HOUSEHOLD_DOMESTIC.transactionCode());
        assertThat(requestRecord.getMessageId()).isEqualTo(LegacyTransactionDetails.UPDATE_HOUSEHOLD_DOMESTIC.messageId());
        assertThat(requestRecord.getUserId()).isEqualTo(USER_ID);
        assertThat(requestRecord.getOwnerId()).isEqualTo(Long.parseLong(USER_ID));
        assertThat(requestRecord.getPaymentType()).isEqualTo("PG");
        assertThat(requestRecord.getAgreementNumber()).isEqualTo(AGREEMENT_NUMBER);
        assertThat(requestRecord.getAccountNumber()).isEqualTo(ACCOUNT_NUMBER);
        assertThat(requestRecord.getOcrFlag()).isEqualTo("");
        assertThat(requestRecord.getNickname()).isEqualTo(NICK_NAME);
        assertThat(requestRecord.getName()).isEqualTo(NAME);
    }

    @Test
    public void sessionIdAndRequestIdShouldBeConfiguredInRecord() {
        HHDomesticUpdateBeneficiaryRequestRecord requestRecord = facade.createUpdateRequest(requestContext, agreement,
                beneficiary, beneficiaryKeyId);
        assertThat(requestRecord.getRequestId()).isEqualTo("aRequestId");
        assertThat(requestRecord.getSessionId()).isEqualTo("aSessionId");
    }

    @Test
    public void sessionIdShouldBeEmptyIfNotContainedInContext() {
        final ServiceRequestContext context = new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .userId(USER_ID)
                .build();

        HHDomesticUpdateBeneficiaryRequestRecord requestRecord = facade.createUpdateRequest(context, agreement,
                beneficiary, beneficiaryKeyId);
        assertThat(requestRecord.getSessionId()).isEmpty();
    }

    @Test
    public void createUpdateRequest(){
        final HHDomesticUpdateBeneficiaryResponseRecord responseRecord = createHHDomesticResponse();
        Beneficiary beneficiary = facade.fetchUpdateResponse(responseRecord);

        assertThat(beneficiary.getId()).isEqualTo("HHDOM-PG-" + ACCOUNT_NUMBER + "-" + "testNickName");
        assertThat(beneficiary.getName()).isEqualTo("testName");
        assertThat(beneficiary.getNickname()).isEqualTo("testNickName");
        assertThat(beneficiary.getTo()).isEqualTo("PG-12345678");
        assertThat(beneficiary.getCategory().toString()).isEqualTo("pg");
        assertThat(Long.valueOf(beneficiary.getDisplayNumber())).isEqualTo(ACCOUNT_NUMBER);
    }

    private HHDomesticUpdateBeneficiaryResponseRecord createHHDomesticResponse(){
        HHDomesticUpdateBeneficiaryResponseRecord responseRecord = new HHDomesticUpdateBeneficiaryResponseRecord();

        responseRecord.setName(NAME);
        responseRecord.setNickname(NICK_NAME);
        responseRecord.setPaymentType(PAYMENT_TYPE);
        responseRecord.setAccountNumber(Long.valueOf(ACCOUNT_NUMBER));
        return responseRecord;
    }

}
