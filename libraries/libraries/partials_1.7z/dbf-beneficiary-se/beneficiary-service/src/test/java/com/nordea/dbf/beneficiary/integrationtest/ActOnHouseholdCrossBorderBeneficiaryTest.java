package com.nordea.dbf.beneficiary.integrationtest;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.*;
import com.nordea.dbf.customer.agreements.se.AgreementDomainFacade;
import com.nordea.dbf.customer.agreements.se.integration.model.*;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import rx.Observable;

import java.net.URI;

import static com.nordea.dbf.test.jca.JCARequests.ofType;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by G95495 on 10-06-2015.
 */

@HouseholdUser(userName = "196807130551", agreement = 3932910)
public class ActOnHouseholdCrossBorderBeneficiaryTest extends AbstractIntegrationTestBase {

    private final String USER_ID = "196807130551";
    private final long AGREEMENT_ID = 3932910L;
    private final String BENEFICIARY_ID = "HHCB-CB-4646464646-PERSON-FYRTIOSEC";
    private final String NICKNAME = "Marcus-S";
    private final String NAME = "Marcus Schmidt";
    private final String ACCOUNT_NUMBER = "52004355";
    private final String PAYMENT_TYPE = "PG";

    private final Beneficiary beneficiaryObject = new Beneficiary();

    @Before
    public void setUp() {
        final Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID,
                new AgreementNumber(AGREEMENT_ID), AgreementType.PRIVATE, AgreementRole.A);
        when(agreementDomainFacade.findAgreement(any(), any(), any())).thenReturn(Observable.just(agreement));
        beneficiaryObject.setNickname(NICKNAME);
        beneficiaryObject.setTo("IBAN-NDEASESS-4646464646");
        beneficiaryObject.setName(NAME);
        beneficiaryObject.setCategory(Beneficiary.CategoryEnum.cross_border);
    }

    @Test
    public void createBeneficiary() {
        // given
        setSample();
        // when
        ResponseEntity<Beneficiary> beneficiaryResponseEntity = create(beneficiaryObject);
        // then
        Beneficiary beneficiary = beneficiaryResponseEntity.getBody();
        assertThat(beneficiary.getId().equals("HHCB_CB_" + "4646464646_" + "Marcus"));
        assertThat(beneficiary.getCategory().equals(Beneficiary.CategoryEnum.cross_border));
        assertThat(beneficiary.getTo().equals("IBAN-NDEASESS-4646464646"));
        assertThat(beneficiary.getDisplayNumber().equals("4646464646"));
        assertThat(beneficiary.getName().equals("Marcus Schmidt"));
        assertThat(beneficiary.getNickname().equals("Marcus-S"));
    }

    private void setSample() {
        jca.onRequest(ofType(HHCrossBorderBeneficiaryListRequestRecord.class, HHCrossBorderBeneficiaryListResponseRecord.class))
                .call((interactionSpec, request, response) -> {
                    final HHCrossBorderBeneficiaryListResponseBeneficiariesSegment beneficiary = response.addBeneficiaries();
                    beneficiary.setName("Marcus Schmidt");
                    beneficiary.setNickname("Marcus-S");
                    beneficiary.setPaymentType("PG");
                    beneficiary.setAccountNumber("1234567892");
                });
    }

    private ResponseEntity<Beneficiary> create(Beneficiary beneficiary) {
        final URI uri = basePath.subPath("banking/beneficiaries").toURI();
        return rest.exchange(new RequestEntity<>(beneficiary, HttpMethod.POST, uri), Beneficiary.class);
    }
}
