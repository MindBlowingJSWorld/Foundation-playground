package com.nordea.dbf.beneficiary.integrationtest;

import com.nordea.dbf.beneficiary.record.beneficiary.agreement.*;
import com.nordea.dbf.customer.agreements.se.AgreementDomainFacade;
import com.nordea.dbf.customer.agreements.se.integration.model.*;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import rx.Observable;

import java.net.URI;

import static com.nordea.dbf.test.jca.JCARequests.ofType;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * Created by G95495 on 10-06-2015.
 */

@HouseholdUser(userName = "194008010011", agreement = 2172332)
public class DeleteHouseholdDomesticBeneficiaryTest extends AbstractIntegrationTestBase {

    private final String USER_ID = "194008010011";
    private final long AGREEMENT_ID = 2172332;
    private final long ACCOUNT_NUMBER = 52004355;
    private final String BENEFICIARY_ID = "HHDOM-PG-52004355-AXESS";
    private final String NICKNAME = "AXESS";
    private final String NAME = "testName";
    private final String PAYMENT_TYPE = "PG";

    @Before
    public void setUp() {
        final Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID,
                new AgreementNumber(AGREEMENT_ID), AgreementType.PRIVATE, AgreementRole.A);
        when(agreementDomainFacade.findAgreement(any(), any(), any())).thenReturn(Observable.just(agreement));
    }

    @Test
    public void nonExistingPaymentShouldResultIn404() {
        jca.onRequest(ofType(HHDomesticBeneficiaryListRequestRecord.class, HHDomesticBeneficiaryListResponseRecord.class)).call((spec, req, res) -> { /* Nop */ });

        assertThatThrownBy(() -> delete("HHDOM-PG-520043-AXE")).isInstanceOf(HttpClientErrorException.class).hasMessageContaining("404");
    }

    @Test
    public void deleteBeneficiary() {
        jca.onRequest(ofType(HHDomesticBeneficiaryListRequestRecord.class, HHDomesticBeneficiaryListResponseRecord.class)).call((spec, req, res) -> {
            // Request
            assertThat(req.getUserId()).isEqualTo(USER_ID);
            assertThat(req.getAgreementNumber()).isEqualTo(AGREEMENT_ID);

            // Response
            final HHDomesticBeneficiaryListResponseBeneficiariesSegment segment = res.addBeneficiaries();
            segment.setNickname(NICKNAME);
            segment.setName(NAME);
            segment.setPaymentType(PAYMENT_TYPE);
            segment.setAccountNumber(ACCOUNT_NUMBER);
        });

        jca.onRequest(ofType(HHDomesticDeleteBeneficiaryRequestRecord.class, HHDomesticDeleteBeneficiaryResponseRecord.class)).call((spec, req, res) -> {
            // Request
            assertThat(req.getNickname()).isEqualTo(NICKNAME);
            assertThat(req.getAccountNumber()).isEqualTo(ACCOUNT_NUMBER);
            assertThat(req.getAgreementNumber()).isEqualTo(AGREEMENT_ID);
            assertThat(req.getUserId()).isEqualTo(USER_ID);
            assertThat(req.getPaymentType()).isEqualTo(PAYMENT_TYPE);
            assertThat(req.getOwnerId()).isEqualTo(Long.valueOf(USER_ID));

            // Response
            res.setErrorCode("");
        });

        final ResponseEntity<String> responseEntity = delete(BENEFICIARY_ID);
        if(responseEntity != null) {
            assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        }

    }

     private ResponseEntity<String> delete(String beneficiaryId) {
         final URI uri = basePath.subPath("banking/beneficiaries/{beneficiaryId}").withPathParameter("beneficiaryId", beneficiaryId).toURI();
         return rest.exchange(new RequestEntity<>(HttpMethod.DELETE, uri), new ParameterizedTypeReference<String>() {});
     }
}
