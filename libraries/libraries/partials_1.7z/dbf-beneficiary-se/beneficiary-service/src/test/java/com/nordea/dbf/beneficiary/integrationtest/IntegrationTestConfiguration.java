package com.nordea.dbf.beneficiary.integrationtest;

import com.nordea.dbf.agreement.facade.CorporateAgreementFacade;
import com.nordea.dbf.customer.agreements.se.AgreementDomainFacade;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import static org.mockito.Mockito.mock;

/**
 * Custom integration test configuration
 *
 */
@Configuration
public class IntegrationTestConfiguration {

  @Bean
  @Primary
  public AgreementDomainFacade agreementDomainFacade() {
    return mock(AgreementDomainFacade.class);
  }

  @Bean
  @Primary
  public CorporateAgreementFacade corporateAgreementFacade() {
    return mock(CorporateAgreementFacade.class);
  }
}
