package com.nordea.dbf.beneficiary.integrationtest;

import com.nordea.dbf.agreement.Agreement;
import com.nordea.dbf.agreement.Engagement;

import com.nordea.dbf.agreement.facade.CorporateAgreementFacade;
import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListResponseBeneficiariesSegment;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.CorporateBeneficiaryListResponseRecord;
import com.nordea.dbf.customer.agreements.se.AgreementDomainFacade;
import com.nordea.dbf.customer.agreements.se.integration.model.AgreementNumber;
import com.nordea.dbf.customer.agreements.se.integration.model.AgreementRole;
import com.nordea.dbf.customer.agreements.se.integration.model.AgreementType;
import com.nordea.dbf.customer.agreements.se.integration.model.UserIdentifierNumber;
import com.nordea.dbf.test.spec.auth.CorporateUser;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.Repeat;
import org.springframework.web.client.RestTemplate;
import rx.Observable;
import com.nordea.dbf.customer.agreements.se.integration.model.*;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import static com.nordea.dbf.test.jca.JCARequests.ofType;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by G95495 on 10-06-2015.
 */

@CorporateUser(userName = "194408012369", agreement = 3931251)
public class RetrieveCorporateBeneficiaryListTest extends AbstractIntegrationTestBase {

    private final String USER_ID = "194408012369";
    private final long AGREEMENT_ID = 3931251L;

    public static final ParameterizedTypeReference<List<Beneficiary>> BENEFICIARY_LIST =
            new ParameterizedTypeReference<List<Beneficiary>>() {};

    @Before
    public void setUp() {
        final Agreement agreement1 = new Agreement("Cust1", USER_ID, String.valueOf(AGREEMENT_ID));
        final Agreement agreement2 = new Agreement("Cust2", USER_ID, String.valueOf(AGREEMENT_ID));
        final List<Agreement> agreementList = new ArrayList<>();
        agreementList.add(agreement1);
        agreementList.add(agreement2);
        final Engagement engagement = new Engagement(agreementList, "V002300");
        when(corporateAgreementFacade.getCustomerEngagement(any())).thenReturn(Observable.just(engagement));

        final com.nordea.dbf.customer.agreements.se.integration.model.Agreement agreement = new com.nordea.dbf.customer.agreements.se.integration.model.Agreement(new UserIdentifierNumber("194408012369"), "194408012369", new AgreementNumber(3931251L), AgreementType.CORPORATE, AgreementRole.A);
        when(agreementDomainFacade.findAgreement(any(), any(), any())).thenReturn(Observable.just(agreement));
    }

    @Ignore ("TODO - Need to adjust to corp. db setup")
    @Test
    @Repeat(10)
    public void retrieveBeneficiaries() {
        // given
        setSample();
        // when
        final ResponseEntity<List<Beneficiary>> beneficiaryList = retrieve();
        // then
        List<Beneficiary> beneficiaries = beneficiaryList.getBody();
        assertThat(beneficiaries).hasSize(2);
        assertThat(beneficiaries).containsExactly(
                new Beneficiary().setName("testName1").setNickname("testNickName1").setDisplayNumber("12 111 3456")
                        .setTo("LBAN-SE-121113456").setCategory(Beneficiary.CategoryEnum.pg)
                        .setId("COR-PG-ePF-" + "1944080123-" + USER_ID),
                new Beneficiary().setName("testName2").setNickname("testNickName2").setDisplayNumber("45 341 5678")
                        .setTo("LBAN-SE-453415678").setCategory(Beneficiary.CategoryEnum.bg)
                        .setId("COR-BG-ePF-" + "1944080123-" + USER_ID));


    }

    private void setSample() {
        jca.onRequest(ofType(CorporateBeneficiaryListRequestRecord.class, CorporateBeneficiaryListResponseRecord.class))
                .call((interactionSpec, request, response) -> {
                    final CorporateBeneficiaryListResponseBeneficiariesSegment beneficiary1 = response.addBeneficiaries();

                    beneficiary1.setName("testName1");
                    beneficiary1.setNickname("testNickName1");
                    beneficiary1.setAgreementOwner(USER_ID);
                    beneficiary1.setUserId(USER_ID);
                    beneficiary1.setPaymentSubTypeEx("PG");
                    beneficiary1.setAccountNumber(String.valueOf(121113456));
                    beneficiary1.setFormattedAccNo("12 111 3456");

                    final CorporateBeneficiaryListResponseBeneficiariesSegment beneficiary2 = response.addBeneficiaries();

                    beneficiary2.setName("testName2");
                    beneficiary2.setNickname("testNickName2");
                    beneficiary2.setAgreementOwner(USER_ID);
                    beneficiary2.setUserId(USER_ID);
                    beneficiary2.setPaymentSubTypeEx("BG");
                    beneficiary2.setAccountNumber(String.valueOf(453415678));
                    beneficiary2.setFormattedAccNo("45 341 5678");

                });
    }

    private ResponseEntity<List<Beneficiary>> retrieve() {
        final URI uri = basePath.subPath("banking/beneficiaries").toURI();
        return rest.exchange(new RequestEntity<>(HttpMethod.GET, uri), BENEFICIARY_LIST);
    }
}
