package com.nordea.dbf.beneficiary.integrationtest;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.api.model.Payment;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.*;
import com.nordea.dbf.customer.agreements.se.AgreementDomainFacade;
import com.nordea.dbf.customer.agreements.se.integration.model.*;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.Repeat;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import rx.Observable;

import java.net.URI;
import java.util.List;

import static com.nordea.dbf.test.jca.JCARequests.ofType;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * Created by G95495 on 10-06-2015.
 */

@HouseholdUser(userName = "194008010011", agreement = 2172332)
public class RetrieveHouseholdBeneficiaryListTest extends AbstractIntegrationTestBase {

    private final String USER_ID = "196807130551";
    private final long AGREEMENT_ID = 3932910L;

    public static final ParameterizedTypeReference<List<Beneficiary>> BENEFICIARY_LIST =
            new ParameterizedTypeReference<List<Beneficiary>>() {};

    @Before
    public void setUp() {
        final Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID, new AgreementNumber(AGREEMENT_ID), AgreementType.PRIVATE, AgreementRole.A);
        when(agreementDomainFacade.findAgreement(any(), any(), any())).thenReturn(Observable.just(agreement));
    }

    @Test
    @Repeat(10)
    public void retrieveBeneficiaries() {
        // given
        setSample();
        // when
        final ResponseEntity<List<Beneficiary>> beneficiaryList = retrieve();
        // then
        List<Beneficiary> beneficiaries = beneficiaryList.getBody();
        assertThat(beneficiaries).hasSize(4);
        assertThat(beneficiaries).containsExactly(
                new Beneficiary().setId("HHDOM-PG-1234567892-testNickName1DOM")
                        .setCategory(Beneficiary.CategoryEnum.pg).setTo("PG-1234567892").setDisplayNumber("1234567892")
                        .setName("testName1DOM").setNickname("testNickName1DOM"),
                new Beneficiary().setId("HHDOM-PG-1234567893-testNickName2DOM")
                        .setCategory(Beneficiary.CategoryEnum.pg).setTo("PG-1234567893").setDisplayNumber("1234567893")
                        .setName("testName2DOM").setNickname("testNickName2DOM"),
                new Beneficiary().setId("HHCB-CB-1234567890-testNickName1CB")
//TODO: check implementation - returns accountFormat "CROSSBORDER-1234567890" - shouldn't format  "IBAN-NDEASESS-1234567890" be used?
//                        .setCategory(Beneficiary.CategoryEnum.cross_border).setTo("IBAN-NDEASESS-1234567890")
                        .setCategory(Beneficiary.CategoryEnum.cross_border).setTo("CROSSBORDER-1234567890")
                        .setDisplayNumber("1234567890").setName("testName1CB").setNickname("testNickName1CB"),
                new Beneficiary().setId("HHCB-CB-1234567891-testNickName2CB")
//TODO: check implementation - returns accountFormat "CROSSBORDER-1234567891" - shouldn't format  "IBAN-NDEASESS-1234567891" be used?
//                        .setCategory(Beneficiary.CategoryEnum.cross_border).setTo("IBAN-NDEASESS-1234567891")
                        .setCategory(Beneficiary.CategoryEnum.cross_border).setTo("CROSSBORDER-1234567891")
                        .setDisplayNumber("1234567891").setName("testName2CB").setNickname("testNickName2CB")

        );

    }

    private void setSample() {
        jca.onRequest(ofType(HHCrossBorderBeneficiaryListRequestRecord.class, HHCrossBorderBeneficiaryListResponseRecord.class))
                .call((interactionSpec, request, response) -> {
                    final HHCrossBorderBeneficiaryListResponseBeneficiariesSegment beneficiary1 = response.addBeneficiaries();

                    beneficiary1.setName("testName1CB");
                    beneficiary1.setNickname("testNickName1CB");
                    beneficiary1.setPaymentType("CB");
                    beneficiary1.setAccountNumber("1234567890");
                    beneficiary1.setLocalCodePN("SE");
                    beneficiary1.setSwiftCode("NDEASESS");

                    final HHCrossBorderBeneficiaryListResponseBeneficiariesSegment beneficiary2 = response.addBeneficiaries();

                    beneficiary2.setName("testName2CB");
                    beneficiary2.setNickname("testNickName2CB");
                    beneficiary2.setPaymentType("CB");
                    beneficiary2.setAccountNumber("1234567891");
                    beneficiary2.setLocalCodePN("SE");
                    beneficiary2.setSwiftCode("NDEASESS");
                });

        jca.onRequest(ofType(HHDomesticBeneficiaryListRequestRecord.class, HHDomesticBeneficiaryListResponseRecord.class))
                .call((interactionSpec, request, response) -> {
                    final HHDomesticBeneficiaryListResponseBeneficiariesSegment beneficiary1 = response.addBeneficiaries();

                    beneficiary1.setName("testName1DOM");
                    beneficiary1.setNickname("testNickName1DOM");
                    beneficiary1.setPaymentType("PG");
                    beneficiary1.setAccountNumber(1234567892);

                    final HHDomesticBeneficiaryListResponseBeneficiariesSegment beneficiary2 = response.addBeneficiaries();

                    beneficiary2.setName("testName2DOM");
                    beneficiary2.setNickname("testNickName2DOM");
                    beneficiary2.setPaymentType("PG");
                    beneficiary2.setAccountNumber(1234567893);

                });
    }

    private ResponseEntity<List<Beneficiary>> retrieve() {
        final URI uri = basePath.subPath("banking/beneficiaries").toURI();
        return rest.exchange(new RequestEntity<>(HttpMethod.GET, uri), BENEFICIARY_LIST);
    }
}
