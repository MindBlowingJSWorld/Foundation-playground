package com.nordea.dbf.beneficiary.integrationtest;

import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticAddBeneficiaryRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticAddBeneficiaryResponseRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticUpdateBeneficiaryRequestRecord;
import com.nordea.dbf.beneficiary.record.beneficiary.agreement.HHDomesticUpdateBeneficiaryResponseRecord;
import com.nordea.dbf.customer.agreements.se.AgreementDomainFacade;
import com.nordea.dbf.customer.agreements.se.integration.model.*;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import rx.Observable;

import java.net.URI;

import static com.nordea.dbf.test.jca.JCARequests.ofType;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * Created by G95495 on 10-06-2015.
 */

@HouseholdUser(userName = "196807130551", agreement = 3932910)
public class UpdateHouseholdDomesticBeneficiaryTest extends AbstractIntegrationTestBase {

    private final String USER_ID = "196807130551";
    private final long AGREEMENT_ID = 3932910L;
    private final String BENEFICIARY_ID = "HHDOM-PG-9019506-Marcus";
    private final String NICKNAME = "Marcus-S";
    private final String NAME = "Marcus Schmidt";

    private final Beneficiary beneficiaryObject = new Beneficiary();

    @Before
    public void setUp() {
        final Agreement agreement = new Agreement(new UserIdentifierNumber(USER_ID), USER_ID,
                new AgreementNumber(AGREEMENT_ID), AgreementType.PRIVATE, AgreementRole.A);
        when(agreementDomainFacade.findAgreement(any(), any(), any())).thenReturn(Observable.just(agreement));
        beneficiaryObject.setNickname(NICKNAME);
        beneficiaryObject.setTo("PG-9019506");
        beneficiaryObject.setName(NAME);
        beneficiaryObject.setCategory(Beneficiary.CategoryEnum.pg);
    }

    @Test
    public void updateBeneficiary() {
        // given
        setSample();
        // when
        ResponseEntity<Beneficiary> beneficiaryResponseEntity = update(BENEFICIARY_ID, beneficiaryObject);
        // then
        Beneficiary beneficiary = beneficiaryResponseEntity.getBody();
        assertThat(beneficiary.getId().equals("HHDOM-PG-" + "9019506-" + "Marcus"));
        assertThat(beneficiary.getCategory().equals(Beneficiary.CategoryEnum.pg));
        assertThat(beneficiary.getTo().equals("PG-9019506"));
        assertThat(beneficiary.getDisplayNumber().equals("9019506"));
        assertThat(beneficiary.getName().equals("Marcus Schmidt"));
        assertThat(beneficiary.getNickname().equals("Marcus-S"));
    }

    private void setSample() {
        jca.onRequest(ofType(HHDomesticUpdateBeneficiaryRequestRecord.class, HHDomesticUpdateBeneficiaryResponseRecord.class))
                .call((interactionSpec, request, response) -> {
                    response.setName("Marcus Schmidt");
                    response.setNickname("Marcus-S");
                    response.setPaymentType("PG");
                    response.setAccountNumber(1234567892);
                });
    }

    private ResponseEntity<Beneficiary> update(String beneficiaryId, Beneficiary beneficiary) {
        final URI uri = basePath.subPath("banking/beneficiaries/{beneficiaryId}").withPathParameter("beneficiaryId", beneficiaryId).toURI();
        return rest.exchange(new RequestEntity<>(beneficiary, HttpMethod.PUT, uri), Beneficiary.class);
    }

}
