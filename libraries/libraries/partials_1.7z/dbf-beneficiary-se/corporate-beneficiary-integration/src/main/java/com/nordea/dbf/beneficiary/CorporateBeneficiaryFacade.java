package com.nordea.dbf.beneficiary;


import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.http.ServiceRequestContext;
import rx.Observable;

import java.util.Optional;

/**
 * Created by k293170 on 2015-11-05.
 */
public interface CorporateBeneficiaryFacade {

    Observable<Beneficiary> getBeneficiariesForCustomer(String customerId);

    Observable<Beneficiary> getBeneficiary(String id);

    Observable<Beneficiary> createBeneficiary(ServiceRequestContext serviceRequestContext, Beneficiary beneficiary);

    Observable<Beneficiary> updateBeneficiary(ServiceRequestContext serviceRequestContext, Beneficiary beneficiary);

    Observable<Beneficiary> deleteBeneficiary(String id);
}
