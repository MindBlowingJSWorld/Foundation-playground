package com.nordea.dbf.beneficiary;

import com.nordea.dbf.api.model.Address;
import com.nordea.dbf.api.model.Beneficiary;
import com.nordea.dbf.beneficiary.db.BeneficiaryMappingQuery;
import com.nordea.dbf.beneficiary.db.BeneficiarySqlDelete;
import com.nordea.dbf.beneficiary.db.BeneficiarySqlUpdate;
import com.nordea.dbf.http.ServiceRequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.jdbc.object.SqlUpdate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.util.StringUtils;
import rx.Observable;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Created by k293170 on 2015-11-05.
 */
public class CorporateBeneficiaryFacadeImpl implements CorporateBeneficiaryFacade {
    private SimpleJdbcInsert simpleJdbcInsert;
    private BeneficiaryMappingQuery beneficiaryMappingQuery;
    private BeneficiarySqlUpdate beneficiarySqlUpdate;
    private SqlUpdate beneficiarySqlDelete;

    @Autowired
    public CorporateBeneficiaryFacadeImpl(DataSource dataSource) {
        this.simpleJdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("beneficiaries")
                .usingGeneratedKeyColumns("id");
        this.beneficiaryMappingQuery = new BeneficiaryMappingQuery(dataSource);
        this.beneficiarySqlUpdate = new BeneficiarySqlUpdate(dataSource);
        this.beneficiarySqlDelete = new BeneficiarySqlDelete(dataSource);
    }

    @Override
    public Observable<Beneficiary> getBeneficiariesForCustomer(String customerId) {
        List<Beneficiary> beneficiaryList = this.beneficiaryMappingQuery.execute(customerId);
        beneficiaryList.stream().forEach(beneficiary -> beneficiary.setId(getId(beneficiary, beneficiary.getId())));
        return Observable.from(beneficiaryList);
    }

    @Override
    public Observable<Beneficiary> getBeneficiary(String id) {
        return Observable.just(this.beneficiaryMappingQuery.findObject(id));
    }

    @Override
    public Observable<Beneficiary> createBeneficiary(ServiceRequestContext serviceRequestContext, Beneficiary beneficiary) {
        Number key = simpleJdbcInsert.executeAndReturnKey(getParameterSource(beneficiary, serviceRequestContext.getUserId().get()));
        //TODO: Refactor this to move the id generation logic out
        return Observable.just(beneficiary.setId(getId(beneficiary, key.toString())));
    }

    @Override
    public Observable<Beneficiary> updateBeneficiary(ServiceRequestContext serviceRequestContext, Beneficiary beneficiary) {
        this.beneficiarySqlUpdate.updateByNamedParam(getParameterSource(beneficiary, serviceRequestContext.getUserId().get()).getValues());
        return Observable.just(beneficiary);
    }

    @Override
    public Observable<Beneficiary> deleteBeneficiary(String id) {
        Map<String, Object> idMap = new HashMap<>();
        idMap.put("id", id.split("-")[2]);
        Observable<Beneficiary> observable = getBeneficiary(id);
        this.beneficiarySqlDelete.updateByNamedParam(idMap);
        return observable;
    }

    private MapSqlParameterSource getParameterSource(Beneficiary beneficiary, String customerId) {
        return new MapSqlParameterSource().addValue("account_number", beneficiary.getDisplayNumber())
                .addValue("iban", beneficiary.getTo()).addValue("name", beneficiary.getName())
                .addValue("address1", beneficiary.getAddress() == null ? "" : beneficiary.getAddress().getAddress1())
                .addValue("address2", beneficiary.getAddress() == null ? "" : beneficiary.getAddress().getAddress2())
                .addValue("address3", beneficiary.getAddress() == null ? "" : beneficiary.getAddress().getAddress3())
                .addValue("country", beneficiary.getCountry()).addValue("bic", beneficiary.getBic())
                .addValue("bank_code", beneficiary.getBranchCode()).addValue("bank_name", beneficiary.getBankName())
                .addValue("bank_address1", beneficiary.getBankAddress() == null ? "" : beneficiary.getBankAddress().getAddress1())
                .addValue("bank_address2", beneficiary.getBankAddress() == null ? "" : beneficiary.getBankAddress().getAddress2())
                .addValue("bank_address3", beneficiary.getBankAddress() == null ? "" : beneficiary.getBankAddress().getAddress3())
                .addValue("short_name", beneficiary.getNickname()).addValue("payment_type", "CORPORATE")
                .addValue("customer_id", customerId).addValue("user_id", customerId)
                .addValue("own_notes", beneficiary.getReference()).addValue("category", beneficiary.getCategory().name());
    }

    private String getId(Beneficiary beneficiary, String key) {
        StringBuilder id = new StringBuilder();
        if (Beneficiary.CategoryEnum.cross_border.equals(beneficiary.getCategory())) {
            id.append("CORPCB");
        } else {
            id.append("CORPDOM");
        }
        id.append("-").append(beneficiary.getDisplayNumber()).append("-").append(key).append("-")
                .append(beneficiary.getNickname());
        return id.toString();
    }

}
