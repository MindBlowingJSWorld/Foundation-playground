package com.nordea.dbf.beneficiary.db;

import com.nordea.dbf.api.model.Address;
import com.nordea.dbf.api.model.Beneficiary;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * Created by k293170 on 2015-11-30.
 */
public class BeneficiaryMappingQuery extends MappingSqlQuery<Beneficiary> {

    public BeneficiaryMappingQuery(DataSource ds) {
        super(ds, new StringBuilder("select id,account_number,iban,name,address1,address2,address3,country,bic,bank_code,")
                .append("bank_name,bank_address1,bank_address2,bank_address3,short_name,payment_type,own_notes,category ")
                .append("from beneficiaries where customer_id=?").toString());
        super.declareParameter(new SqlParameter("customerId", Types.VARCHAR));
        compile();
    }

    @Override
    protected Beneficiary mapRow(ResultSet resultSet, int i) throws SQLException {
        return new Beneficiary().setDisplayNumber(resultSet.getString("account_number"))
                .setName(resultSet.getString("name")).setTo(resultSet.getString("iban"))
                .setAddress(new Address().setAddress1(resultSet.getString("address1"))
                        .setAddress2(resultSet.getString("address2")).setAddress3(resultSet.getString("address3")))
                .setCountry(resultSet.getString("country")).setBic(resultSet.getString("bic"))
                .setBankName(resultSet.getString("bank_name")).setId(resultSet.getString("id"))
                .setBankAddress(new Address().setAddress1(resultSet.getString("bank_address1"))
                        .setAddress2("bank_address2").setAddress3(resultSet.getString("bank_address3")))
                .setNickname(resultSet.getString("short_name")).setReference(resultSet.getString("own_notes"))
                .setCategory(Beneficiary.CategoryEnum.valueOf(resultSet.getString("category")));
    }

}
