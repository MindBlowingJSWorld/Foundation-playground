package com.nordea.dbf.beneficiary.db;

import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.sql.Types;

/**
 * Created by k293170 on 2015-11-30.
 */
public class BeneficiarySqlDelete extends SqlUpdate {

    public BeneficiarySqlDelete(DataSource ds) {
        super(ds, "delete from beneficiaries where id=:id");
        SqlParameter[] parameters = new SqlParameter[1];
        parameters[0] = new SqlParameter("id", Types.INTEGER);
        setParameters(parameters);
        setRequiredRowsAffected(1);
    }
}
