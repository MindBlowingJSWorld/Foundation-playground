package com.nordea.dbf.beneficiary.db;

import com.nordea.dbf.api.model.Address;
import com.nordea.dbf.api.model.Beneficiary;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.SqlUpdate;

import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by k293170 on 2015-11-30.
 */
public class BeneficiarySqlUpdate extends SqlUpdate {

    public BeneficiarySqlUpdate(DataSource ds) {
        setDataSource(ds);
        setSql(new StringBuilder("update beneficiaries set ").append(parameterQuery()).append(" where id = :id").toString());
        SqlParameter[] parameters = new SqlParameter[15];
        parameters[0] = new SqlParameter("id", Types.INTEGER);
        parameters[1] = new SqlParameter("name", Types.VARCHAR);
        parameters[2] = new SqlParameter("iban", Types.VARCHAR);
        parameters[3] = new SqlParameter("address1", Types.VARCHAR);
        parameters[4] = new SqlParameter("address2", Types.VARCHAR);
        parameters[5] = new SqlParameter("address3", Types.VARCHAR);
        parameters[6] = new SqlParameter("country", Types.VARCHAR);
        parameters[7] = new SqlParameter("bic", Types.INTEGER);
        parameters[8] = new SqlParameter("bank_name", Types.INTEGER);
        parameters[9] = new SqlParameter("bank_address1", Types.INTEGER);
        parameters[10] = new SqlParameter("bank_address2", Types.INTEGER);
        parameters[11] = new SqlParameter("banl_address3", Types.INTEGER);
        parameters[12] = new SqlParameter("short_name", Types.INTEGER);
        parameters[13] = new SqlParameter("own_notes", Types.INTEGER);
        parameters[14] = new SqlParameter("category", Types.INTEGER);
        setParameters(parameters);
    }

    private String parameterQuery() {
        List<String> parameters = new ArrayList<>();
        parameters.add("name=:name");
        parameters.add("iban=:iban");
        parameters.add("address1=:address1");
        parameters.add("address2=:address2");
        parameters.add("address3=:address3");
        parameters.add("country=:country");
        parameters.add("bic=:bic");
        parameters.add("bank_name=:bank_name");
        parameters.add("bank_address1=:bank_address1");
        parameters.add("bank_address2=:bank_address2");
        parameters.add("bank_address3=:bank_address3");
        parameters.add("short_name=:short_name");
        parameters.add("own_notes=:own_notes");
        parameters.add("category=:category");
        return String.join(" and ", parameters);
    }
}
