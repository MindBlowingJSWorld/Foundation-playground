package com.nordea.dbf.beneficiary;

import com.nordea.dbf.api.model.Beneficiary;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Created by k293170 on 2015-11-05.
 */
public class CorporateBeneficiaryFacadeImplTest {

   /* private DataSource dataSource = Mockito.mock(DataSource.class);
    private CorporateBeneficiaryFacade corporateBeneficiaryFacade = new CorporateBeneficiaryFacadeImpl(dataSource);

    @Before
    public void setup() {
        when(jdbcTemplate.query(anyString(), any(String[].class), any(RowMapper.class))).thenReturn(beneficiaryList());
    }

    @Test
    public void testGetBeneficiaries() throws Exception {
        List<Beneficiary> beneficiaries = corporateBeneficiaryFacade.getBeneficiariesForCustomer("1234")
                .toList().toBlocking().first();
        assertThat(beneficiaries.get(0).getId()).isEqualTo("0");
    }

    @Test
    public void testGetBeneficiaryWithId() throws Exception {
        when(jdbcTemplate.query(anyString(), any(String[].class), any(RowMapper.class)))
                .thenReturn(beneficiary());
        Beneficiary beneficiary = corporateBeneficiaryFacade.getBeneficiary("1111").single().toBlocking().first();
        assertThat(beneficiary.getId()).isEqualTo("1");
        assertThat(beneficiary.getName()).isEqualTo("Beneficiary 1");
        assertThat(beneficiary.getCategory()).isEqualTo(Beneficiary.CategoryEnum.bg);
    }

    @Test
    public void testInsertValidBeneficiary() throws Exception {
        when(jdbcTemplate.update(any(PreparedStatementCreator.class), any(KeyHolder.class)))
                .thenAnswer(invocation -> {
                    Object[] args = invocation.getArguments();
                    Map<String, Object> keyMap = new HashMap<>();
                    keyMap.put("", 13);
                    ((GeneratedKeyHolder) args[1]).getKeyList().add(keyMap);
                    return 1;
                });
        Beneficiary beneficiary = corporateBeneficiaryFacade.createBeneficiary((Beneficiary) beneficiary().get(0)).single().toBlocking().first();
        assertThat(beneficiary.getId()).isEqualTo("13");
        assertThat(beneficiary.getName()).isEqualTo("Beneficiary 1");
        assertThat(beneficiary.getCategory()).isEqualTo(Beneficiary.CategoryEnum.bg);
    }


    @Test
    public void testUpdateValidBeneficiary() throws Exception {
        when(jdbcTemplate.update(any(PreparedStatementCreator.class), any(KeyHolder.class)))
                .thenAnswer(invocation -> {
                    Object[] args = invocation.getArguments();
                    Map<String, Object> keyMap = new HashMap<>();
                    keyMap.put("", 13);
                    ((GeneratedKeyHolder) args[1]).getKeyList().add(keyMap);
                    return 1;
                });
        Beneficiary beneficiary = corporateBeneficiaryFacade.updateBeneficiary((Beneficiary) beneficiary().get(0)).single().toBlocking().first();
        assertThat(beneficiary.getId()).isEqualTo("13");
        assertThat(beneficiary.getName()).isEqualTo("Beneficiary 1");
        assertThat(beneficiary.getCategory()).isEqualTo(Beneficiary.CategoryEnum.bg);
    }

    private List beneficiary() {
        List<Beneficiary> beneficiary = new ArrayList<>();
        beneficiary.add(new Beneficiary().setId("1").setName("Beneficiary 1").setCategory(Beneficiary.CategoryEnum.bg));
        return beneficiary;
    }

    private List beneficiaryList() {
        List beneficiaryList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            beneficiaryList.add(new Beneficiary().setId("" + i).setName("Beneficiary " + i)
            .setCategory(Beneficiary.CategoryEnum.bg));
        }
        return beneficiaryList;
    }*/
}