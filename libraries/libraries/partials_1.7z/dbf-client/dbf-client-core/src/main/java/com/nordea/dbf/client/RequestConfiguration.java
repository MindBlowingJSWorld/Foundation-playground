package com.nordea.dbf.client;

public final class RequestConfiguration {

    private final String applicationId;

    private final String sessionId;

    private final String requestId;

    private final String userId;

    private final String country;

    private final String channelId;

    private final Long agreementNumber;

    private final String authenticationMethod;

    private final String authenticationLevel;

    private RequestConfiguration(String applicationId, String sessionId, String requestId, String userId, String country, String channelId,
        Long agreementNumber, String authenticationMethod, String authenticationLevel) {
        this.applicationId = applicationId;
        this.sessionId = sessionId;
        this.requestId = requestId;
        this.userId = userId;
        this.country = country;
        this.channelId = channelId;
        this.agreementNumber = agreementNumber;
        this.authenticationMethod = authenticationMethod;
        this.authenticationLevel = authenticationLevel;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getUserId() {
        return userId;
    }

    public String getCountry() {
        return country;
    }

    public String getChannelId() {
        return channelId;
    }

    public Long getAgreementNumber() {
        return agreementNumber;
    }

    public String getAuthenticationMethod() {
        return authenticationMethod;
    }

    public String getAuthenticationLevel() {
        return authenticationLevel;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RequestConfiguration that = (RequestConfiguration) o;

        if (agreementNumber != null ? !agreementNumber.equals(that.agreementNumber) : that.agreementNumber != null)
            return false;
        if (authenticationLevel != null ? !authenticationLevel.equals(that.authenticationLevel) : that.authenticationLevel != null)
            return false;
        if (authenticationMethod != null ? !authenticationMethod.equals(that.authenticationMethod) : that.authenticationMethod != null)
            return false;
        if (country != null ? !country.equals(that.country) : that.country != null) return false;
        if (requestId != null ? !requestId.equals(that.requestId) : that.requestId != null) return false;
        if (sessionId != null ? !sessionId.equals(that.sessionId) : that.sessionId != null) return false;
        if (applicationId != null ? !applicationId.equals(that.applicationId) : that.applicationId != null) return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = sessionId != null ? sessionId.hashCode() : 0;
        result = 31 * result + (requestId != null ? requestId.hashCode() : 0);
        result = 31 * result + (applicationId != null ? applicationId.hashCode() : 0);
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = 31 * result + (country != null ? country.hashCode() : 0);
        result = 31 * result + (agreementNumber != null ? agreementNumber.hashCode() : 0);
        result = 31 * result + (authenticationMethod != null ? authenticationMethod.hashCode() : 0);
        result = 31 * result + (authenticationLevel != null ? authenticationLevel.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "RequestConfiguration{" +
                "sessionId='" + sessionId + '\'' +
                ", applicationId='" + applicationId + '\'' +
                ", requestId='" + requestId + '\'' +
                ", userId='" + userId + '\'' +
                ", country='" + country + '\'' +
                ", agreementNumber=" + agreementNumber +
                ", authenticationMethod='" + authenticationMethod + '\'' +
                ", authenticationLevel='" + authenticationLevel + '\'' +
                '}';
    }

    public static class Builder {

        private String applicationId;

        private String sessionId;

        private String requestId;

        private String userId;

        private String country;

        private String channelId;

        private Long agreementNumber;

        private String authenticationMethod;

        private String authenticationLevel;

        public Builder applicationId(String applicationId) {
            if (applicationId == null || applicationId.isEmpty()) {
                throw new IllegalArgumentException("applicationId can't be null or empty");
            }

            this.applicationId = applicationId;
            return this;
        }

        public Builder sessionId(String sessionId) {
            if (sessionId == null || sessionId.isEmpty()) {
                throw new IllegalArgumentException("sessionId can't be null or empty");
            }

            this.sessionId = sessionId;
            return this;
        }

        public Builder requestId(String requestId) {
            this.requestId = requestId;
            return this;
        }

        public Builder userId(String userId) {
            if (userId == null || userId.isEmpty()) {
                throw new IllegalArgumentException("userId can't be null or empty");
            }

            this.userId = userId;
            return this;
        }

        public Builder country(String country) {
            if (country == null || country.isEmpty()) {
                throw new IllegalArgumentException("country can't be null or empty");
            }

            this.country = country;
            return this;
        }

        public Builder channelId(String channelId) {
            if (channelId == null || channelId.isEmpty()) {
                throw new IllegalArgumentException("channelId can't be null or empty");
            }

            this.channelId = channelId;
            return this;
        }

        public Builder agreementNumber(Long agreementNumber) {
            this.agreementNumber = agreementNumber;
            return this;
        }

        public Builder authenticationMethod(String authenticationMethod) {
            if (authenticationMethod == null || authenticationMethod.isEmpty()) {
                throw new IllegalArgumentException("authenticationMethod can't be null or empty");
            }

            this.authenticationMethod = authenticationMethod;
            return this;
        }

        public Builder authenticationLevel(String authenticationLevel) {
            if (authenticationLevel == null || authenticationLevel.isEmpty()) {
                throw new IllegalArgumentException("authenticationLevel can't be null or empty");
            }

            this.authenticationLevel = authenticationLevel;
            return this;
        }

        public RequestConfiguration build() {
            if (applicationId == null) {
                throw new IllegalStateException("applicationId must be specified");
            }

            if (userId == null) {
                throw new IllegalStateException("userId must be specified");
            }

            if (sessionId == null) {
                throw new IllegalStateException("sessionId must be specified");
            }

            if (authenticationMethod == null) {
                throw new IllegalStateException("authenticationMethod must be specified");
            }

            if (authenticationLevel == null) {
                throw new IllegalStateException("authenticationLevel must be specified");
            }

            if (country == null) {
                throw new IllegalStateException("country must be specified");
            }

            if (channelId == null) {
                throw new IllegalStateException("channelId must be specified");
            }

            return new RequestConfiguration(applicationId, sessionId, requestId, userId, country, channelId, agreementNumber, authenticationMethod, authenticationLevel);
        }
    }

}
