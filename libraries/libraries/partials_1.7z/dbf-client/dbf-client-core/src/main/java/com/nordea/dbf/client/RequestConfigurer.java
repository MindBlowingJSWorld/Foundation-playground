package com.nordea.dbf.client;

public interface RequestConfigurer {

    RequestConfiguration getRequestConfiguration();

}
