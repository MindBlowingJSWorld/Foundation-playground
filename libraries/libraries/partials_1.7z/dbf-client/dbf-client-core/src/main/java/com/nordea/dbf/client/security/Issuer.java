package com.nordea.dbf.client.security;

import org.apache.commons.lang.Validate;

import java.security.interfaces.RSAPrivateKey;

public final class Issuer {

    private final String name;

    private final RSAPrivateKey privateKey;

    public Issuer(String name, RSAPrivateKey privateKey) {
        Validate.notEmpty(name, "name can't be null or empty");
        Validate.notNull(privateKey, "privateKey can't be null or empty");

        this.name = name;
        this.privateKey = privateKey;
    }

    public String name() {
        return name;
    }

    public RSAPrivateKey privateKey() {
        return privateKey;
    }

}
