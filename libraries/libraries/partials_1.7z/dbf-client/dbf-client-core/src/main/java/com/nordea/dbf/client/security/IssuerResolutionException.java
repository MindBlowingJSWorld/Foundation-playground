package com.nordea.dbf.client.security;

public class IssuerResolutionException extends RuntimeException {

    public IssuerResolutionException() {
    }

    public IssuerResolutionException(String message) {
        super(message);
    }

    public IssuerResolutionException(String message, Throwable cause) {
        super(message, cause);
    }

    public IssuerResolutionException(Throwable cause) {
        super(cause);
    }

    public IssuerResolutionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
