package com.nordea.dbf.client.security;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import java.io.*;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Issuers {

    public static final Pattern RESOURCE_SELECTOR_PATTERN = Pattern.compile("((?<type>(classpath)|(file)):)?(?<path>.+)");

    public enum KeyType {
        DER {
            @Override
            public RSAPrivateKey load(InputStream in) throws InvalidKeySpecException, NoSuchAlgorithmException, IOException {
                return (RSAPrivateKey) KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(IOUtils.toByteArray(in)));
            }
        },

        PEM {

            public static final String PKCS8_HEADER = "-----BEGIN PRIVATE KEY-----";
            public static final String PKCS8_TRAILER = "-----END PRIVATE KEY-----";
            public static final String RSA_HEADER = "-----BEGIN RSA PRIVATE KEY-----";
            public static final String RSA_TRAILER = "-----END RSA PRIVATE KEY-----";

            @Override
            public RSAPrivateKey load(InputStream in) throws InvalidKeySpecException, NoSuchAlgorithmException, IOException {
                final StringBuilder buffer = new StringBuilder(1024);
                final BufferedReader reader = new BufferedReader(new InputStreamReader(in));

                for (;;) {
                    final String line = reader.readLine();

                    if (line == null) {
                        throw new IllegalArgumentException("Invalid private key (PEM private key header not found)");
                    }

                    if (line.startsWith(RSA_HEADER)) {
                        throw new IllegalArgumentException(
                                "PKCS#1 encoded private key not supported. " +
                                "Convert your key to PKCS#8 using the following command: " +
                                    "openssl pkcs8 -topk8 -in $inputFile -out $outputFile -nocrypt");
                    }

                    if (line.startsWith(PKCS8_HEADER)) {
                        break;
                    }
                }

                for (;;) {
                    final String line = reader.readLine();

                    if (line == null) {
                        throw new IllegalArgumentException("Invalid private key (PEM private key trailer not found");
                    }

                    if (line.startsWith(PKCS8_TRAILER) || line.startsWith(RSA_TRAILER)) {
                        break;
                    }

                    buffer.append(line);
                }

                final String encodedKey = buffer.toString();
                final byte[] bytes = Base64.decodeBase64(encodedKey);

                return (RSAPrivateKey) KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(bytes));
            }
        };

        public abstract RSAPrivateKey load(InputStream in) throws InvalidKeySpecException, NoSuchAlgorithmException, IOException;

        public static KeyType fromFileName(String fileName) {
            Validate.notEmpty(fileName, "fileName can't be null or empty");

            final int n = fileName.lastIndexOf('.');

            if (n == -1) {
                throw new IllegalArgumentException("Invalid filename '" + fileName
                        + "'; directories and files without extension not supported");
            }

            final String extension = fileName.substring(n + 1).toLowerCase();

            switch (extension) {
                case "pem":
                    return PEM;
                case "der":
                    return DER;
                default:
                    throw new IllegalArgumentException("Invalid file name '" + fileName
                            + "'; extension '" + extension + "' is not supported");
            }
        }
    }

    public static Supplier<Issuer> fromResourceSelector(String issuerName, String resourceSelector, String defaultResourceType) throws IOException {
        Validate.notEmpty(issuerName, "issuerName can't be null or empty");
        Validate.notEmpty(resourceSelector, "resourceSelector can't be null or empty");
        Validate.notEmpty(defaultResourceType, "defaultResourceType can't be null or empty");

        final Matcher matcher = RESOURCE_SELECTOR_PATTERN.matcher(resourceSelector);

        if (!matcher.matches()) {
            throw new IllegalArgumentException("Invalid resource selector '" + resourceSelector + "'; must be (classpath|file)?:{path}");
        }

        final String path = matcher.group("path");

        String type = matcher.group("type");

        if (StringUtils.isEmpty(type)) {
            type = defaultResourceType;
        }

        switch (type) {
            case "classpath":
                return fromClassPath(issuerName, path);
            case "file":
                return fromFile(issuerName, path);
            default:
                throw new IllegalArgumentException("Invalid resource selector type: '" + type + "'");
        }
    }

    public static Supplier<Issuer> fromClassPath(String issuerName, String resourcePath) throws IOException {
        Validate.notEmpty(issuerName, "issuerName can't be null or empty");
        Validate.notEmpty(resourcePath,  "resourcePath can't be null or empty");

        try (final InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(resourcePath)) {
            if (in == null) {
                return Suppliers.ofInstance(null);
            }

            return Suppliers.ofInstance(new Issuer(issuerName, privateKeyFrom(in, KeyType.fromFileName(resourcePath))));
        }
    }

    public static Supplier<Issuer> fromFile(final String issuerName, final String fileName) {
        return fromFile(issuerName, fileName, System.getProperties());
    }

    public static Supplier<Issuer> fromFile(final String issuerName, final String fileName, final Properties properties) {
        Validate.notEmpty(issuerName, "issuerName can't be null or empty");
        Validate.notEmpty(fileName, "fileName can't be null or empty");

        return new Supplier<Issuer>() {
            @Override
            public Issuer get() {
                final String expendedFileName = expand(fileName, properties);

                try (final InputStream in = new FileInputStream(expendedFileName)) {
                    return new Issuer(issuerName, privateKeyFrom(in, KeyType.fromFileName(expendedFileName)));
                } catch (FileNotFoundException e) {
                    return null;
                } catch (IOException e) {
                    throw new IssuerResolutionException("Failed to read from file '" + expendedFileName + "'", e);
                }
            }
        };
    }

    private enum ExpansionState {
        VARIABLE,
        TEXT
    }

    private static String expand(final String string, Properties properties) {
        final StringBuilder result = new StringBuilder(string.length());

        ExpansionState state = ExpansionState.TEXT;

        int variableStart = -1;

        for (int i = 0; i <= string.length(); i++) {
            final int n = (i == string.length() ? -1 : string.charAt(i));

            switch (state) {
                case VARIABLE:
                    switch (n) {
                        case -1:
                            throw new IllegalArgumentException("Invalid file name '" + string + "'; property not terminated");
                        case '}':
                            state = ExpansionState.TEXT;

                            final String variableName = string.substring(variableStart + 1, i);
                            final String propertyValue = properties.getProperty(variableName);

                            if (propertyValue != null) {
                                result.append(propertyValue);
                            } else {
                                result.append('{').append(variableName).append('}');
                            }

                            break;
                    }
                    break;
                case TEXT:
                    switch (n) {
                        case '{':
                            variableStart = i;
                            state = ExpansionState.VARIABLE;
                            break;
                        case -1:
                            break;
                        default:
                            result.append((char) n);
                    }
                    break;
            }
        }

        return result.toString();
    }

    public static Supplier<Issuer> oneOf(final Supplier<Issuer> ... suppliers) {
        return new Supplier<Issuer>() {
            @Override
            public Issuer get() {
                for (final Supplier<Issuer> supplier : suppliers) {
                    final Issuer issuer = supplier.get();

                    if (issuer != null) {
                        return issuer;
                    }
                }

                throw new IssuerResolutionException("Failed to resolve issuer (no supplier was able to resolve)");
            }
        };
    }

    public static Supplier<Issuer> cached(final Supplier<Issuer> supplier) {
        return Suppliers.memoize(supplier);
    }

    private static RSAPrivateKey privateKeyFrom(final InputStream in, final KeyType keyType) {
        try {
            return keyType.load(in);
        } catch (InvalidKeySpecException | NoSuchAlgorithmException | IOException e) {
            throw new IssuerResolutionException("Failed to load private key", e);
        }
    }

}
