package com.nordea.dbf.client.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Supplier;
import com.nordea.dbf.client.RequestConfiguration;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.RsaSigner;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class LocalTokenProvider implements TokenProvider {

    private final ObjectMapper objectMapper;

    private final Supplier<Issuer> issuerSupplier;

    public LocalTokenProvider(ObjectMapper objectMapper, Supplier<Issuer> issuerSupplier) {
        if (objectMapper == null) {
            throw new IllegalArgumentException("objectMapper can't be null");
        }

        if (issuerSupplier == null) {
            throw new IllegalArgumentException("issuerSupplier can't be null");
        }

        this.objectMapper = objectMapper;
        this.issuerSupplier = issuerSupplier;
    }

    @Override
    public String getToken(RequestConfiguration requestConfiguration) {
        if (requestConfiguration == null) {
            throw new IllegalArgumentException("requestConfiguration can't be null");
        }

        final Map<String, Object> payload = new LinkedHashMap<>();
        final long iat = TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis());
        final long exp = iat + TimeUnit.HOURS.toSeconds(1);
        final Issuer issuer = issuerSupplier.get();

        if (issuer == null) {
            throw new IllegalStateException("No issuer was supplied; token can't be generated");
        }

        payload.put(ISSUER_TOKEN_KEY, issuer.name());
        payload.put(AUDIENCE_TOKEN_KEY, Collections.singletonList("osl"));
        payload.put(CLIENT_ID_TOKEN_KEY, requestConfiguration.getUserId());
        payload.put(JTI_TOKEN_KEY, requestConfiguration.getSessionId());
        payload.put(AUTH_METHOD_TOKEN_KEY, requestConfiguration.getAuthenticationMethod());
        payload.put(AUTH_LEVEL_TOKEN_KEY, requestConfiguration.getAuthenticationLevel());
        payload.put(CREATED_TOKEN_KEY, iat);
        payload.put(EXPIRES_TOKEN_KEY, exp);

        final Map<String, Object> grants = new LinkedHashMap<>();

        if (requestConfiguration.getAgreementNumber() != null) {
            grants.put(AGREEMENT_GRANT_KEY, requestConfiguration.getAgreementNumber());
        }

        payload.put(GRANTS_TOKEN_KEY, grants);

        final String payloadAsString;

        try {
            payloadAsString = objectMapper.writeValueAsString(payload);
        } catch (JsonProcessingException e) {
            throw new TokenProvisioningException("Failed to encode token payload as JSON", e);
        }

        return JwtHelper.encode(payloadAsString, new RsaSigner(issuer.privateKey())).getEncoded();
    }
}
