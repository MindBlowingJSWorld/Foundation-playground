package com.nordea.dbf.client.security;

import com.nordea.dbf.client.RequestConfiguration;

public interface TokenProvider {

    public static final String ISSUER_TOKEN_KEY = "iss";
    public static final String CLIENT_ID_TOKEN_KEY = "client_id";
    public static final String AUTH_METHOD_TOKEN_KEY = "am";
    public static final String AUTH_LEVEL_TOKEN_KEY = "al";
    public static final String GRANTS_TOKEN_KEY = "grants";
    public static final String EXPIRES_TOKEN_KEY = "exp";
    public static final String JTI_TOKEN_KEY = "jti";
    public static final String AUDIENCE_TOKEN_KEY = "aud";
    public static final String CREATED_TOKEN_KEY = "iat";
    public static final String AGREEMENT_GRANT_KEY = "agreement";

    String getToken(RequestConfiguration requestConfiguration);

}
