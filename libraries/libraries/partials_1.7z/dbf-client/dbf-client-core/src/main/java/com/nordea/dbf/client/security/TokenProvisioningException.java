package com.nordea.dbf.client.security;

public class TokenProvisioningException extends RuntimeException {

    public TokenProvisioningException() {
    }

    public TokenProvisioningException(String message) {
        super(message);
    }

    public TokenProvisioningException(String message, Throwable cause) {
        super(message, cause);
    }

    public TokenProvisioningException(Throwable cause) {
        super(cause);
    }

    public TokenProvisioningException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
