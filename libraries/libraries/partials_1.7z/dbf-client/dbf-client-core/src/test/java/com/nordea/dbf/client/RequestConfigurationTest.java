package com.nordea.dbf.client;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

public class RequestConfigurationTest {

    @Test
    public void requestConfigurationCanBeBuilt() {
        final RequestConfiguration configuration = RequestConfiguration.newBuilder()
                .agreementNumber(1234L)
                .applicationId("anApplication")
                .sessionId("aSession")
                .requestId("myRequest")
                .userId("myUser")
                .country("SE")
                .channelId("NETBANK")
                .authenticationMethod("BANKID")
                .authenticationLevel("HIGH")
                .build();

        assertThat(configuration.getAgreementNumber()).isEqualTo(1234L);
        assertThat(configuration.getSessionId()).isEqualTo("aSession");
        assertThat(configuration.getRequestId()).isEqualTo("myRequest");
        assertThat(configuration.getApplicationId()).isEqualTo("anApplication");
        assertThat(configuration.getCountry()).isEqualTo("SE");
        assertThat(configuration.getChannelId()).isEqualTo("NETBANK");
        assertThat(configuration.getUserId()).isEqualTo("myUser");
        assertThat(configuration.getAuthenticationMethod()).isEqualTo("BANKID");
        assertThat(configuration.getAuthenticationLevel()).isEqualTo("HIGH");
    }

    @Test
    public void agreementNumberAndRequestIdShouldBeOptional() {
        final RequestConfiguration configuration = RequestConfiguration.newBuilder()
                .sessionId("aSession")
                .applicationId("anApplication")
                .userId("myUser")
                .country("SE")
                .channelId("NETBANK")
                .authenticationMethod("BANKID")
                .authenticationLevel("HIGH")
                .build();

        assertThat(configuration.getSessionId()).isEqualTo("aSession");
        assertThat(configuration.getUserId()).isEqualTo("myUser");
        assertThat(configuration.getCountry()).isEqualTo("SE");
        assertThat(configuration.getChannelId()).isEqualTo("NETBANK");
        assertThat(configuration.getAgreementNumber()).isNull();
        assertThat(configuration.getRequestId()).isNull();
        assertThat(configuration.getAuthenticationMethod()).isEqualTo("BANKID");
        assertThat(configuration.getAuthenticationLevel()).isEqualTo("HIGH");
    }

    @Test
    public void userIdCannotBeNullOrEmpty() {
        try {
            RequestConfiguration.newBuilder().userId(null);
            fail("null userId should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            RequestConfiguration.newBuilder().userId("");
            fail("empty userId should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test(expected = IllegalStateException.class)
    public void buildShouldFailIfNoUserIdIsSpecified() {
        RequestConfiguration.newBuilder()
                .sessionId("aSession")
                .requestId("aRequest")
                .country("SE")
                .agreementNumber(1234L)
                .authenticationMethod("BANKID")
                .authenticationLevel("HIGH")
                .build();
    }

    @Test
    public void sessionIdCannotBeNullOrEmpty() {
        try {
            RequestConfiguration.newBuilder().sessionId(null);
            fail("null sessionId should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            RequestConfiguration.newBuilder().sessionId("");
            fail("empty sessionId should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test(expected = IllegalStateException.class)
    public void buildShouldFailIfNoSessionIdIsSpecified() {
        RequestConfiguration.newBuilder()
                .userId("aUser")
                .country("SE")
                .requestId("aRequest")
                .agreementNumber(1234L)
                .authenticationMethod("BANKID")
                .authenticationLevel("HIGH")
                .build();
    }

    @Test
    public void applicationIdCannotBeNullOrEmpty() {
      try {
        RequestConfiguration.newBuilder().applicationId(null);
        fail("null applicationId should be rejected");
      } catch (IllegalArgumentException e) {}

      try {
        RequestConfiguration.newBuilder().applicationId("");
        fail("empty applicationId should be rejected");
      } catch (IllegalArgumentException e) {}
    }

    @Test(expected = IllegalStateException.class)
    public void buildShouldFailIfNoApplicationIdIsSpecified() {
      RequestConfiguration.newBuilder()
        .userId("aUser")
          .country("SE")
          .sessionId("aSession")
        .requestId("aRequest")
        .agreementNumber(1234L)
        .authenticationMethod("BANKID")
        .authenticationLevel("HIGH")
        .build();
    }


    @Test(expected = IllegalStateException.class)
    public void authenticationMethodCannotBeOmitted() {
        RequestConfiguration.newBuilder()
            .userId("aUser")
            .country("SE")
            .sessionId("aSession")
            .requestId("aRequest")
            .agreementNumber(1234L)
            .authenticationLevel("HIGH")
            .build();
    }

    @Test(expected = IllegalStateException.class)
    public void authenticationLevelCannotBeOmitted() {
        RequestConfiguration.newBuilder()
            .userId("aUser")
            .country("SE")
            .sessionId("aSession")
            .requestId("aRequest")
            .agreementNumber(1234L)
            .authenticationMethod("BANKID")
            .build();
    }

    @Test
    public void authenticationMethodCannotBeNullOrEmpty() {
        try {
            RequestConfiguration.newBuilder().authenticationMethod(null);
            fail("null authenticationMethod should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            RequestConfiguration.newBuilder().authenticationMethod("");
            fail("empty authenticationMethod should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void authenticationLevelCannotBeNullOrEmpty() {
        try {
            RequestConfiguration.newBuilder().authenticationLevel(null);
            fail("null authenticationLevel should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            RequestConfiguration.newBuilder().authenticationLevel("");
            fail("empty authenticationLevel should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void countryCannotBeNullOrEmpty() {
        try {
            RequestConfiguration.newBuilder().country(null);
            fail("null country should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            RequestConfiguration.newBuilder().country("");
            fail("empty country should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test(expected = IllegalStateException.class)
    public void countryCannotBeOmitted() {
        RequestConfiguration.newBuilder()
            .agreementNumber(1234L)
            .applicationId("anApplication")
            .sessionId("aSession")
            .requestId("myRequest")
            .userId("myUser")
            .authenticationMethod("BANKID")
            .authenticationLevel("HIGH")
            .build();
    }

    @Test
    public void channelCannotBeNullOrEmpty() {
        try {
            RequestConfiguration.newBuilder().channelId(null);
            fail("channelId can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            RequestConfiguration.newBuilder().channelId("");
            fail("channelId can't be empty");
        } catch (IllegalArgumentException e) {
        }
    }

}
