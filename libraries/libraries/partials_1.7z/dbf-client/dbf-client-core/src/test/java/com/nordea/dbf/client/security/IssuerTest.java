package com.nordea.dbf.client.security;

import org.junit.Test;

import java.security.interfaces.RSAPrivateKey;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;

public class IssuerTest {

    private final RSAPrivateKey privateKey = mock(RSAPrivateKey.class);

    @Test
    public void constructorShouldRejectInvalidArguments() {
        try {
            new Issuer(null, privateKey);
            fail("name can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new Issuer("", privateKey);
            fail("name can't be empty");
        } catch (IllegalArgumentException e) {
        }

        try {
            new Issuer("DBF", null);
            fail("privateKey can't be null");
        } catch (IllegalArgumentException e) {
        }
    }
    
    @Test
    public void constructorShouldRetainNameAndKey() {
        final Issuer issuer = new Issuer("DBF", privateKey);
        
        assertThat(issuer.name()).isEqualTo("DBF");
        assertThat(issuer.privateKey()).isEqualTo(privateKey);
    }

}