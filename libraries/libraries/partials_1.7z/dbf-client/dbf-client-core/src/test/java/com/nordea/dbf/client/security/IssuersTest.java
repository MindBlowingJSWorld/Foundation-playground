package com.nordea.dbf.client.security;

import com.google.common.base.Supplier;
import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Test;
import org.mockito.InOrder;

import java.io.*;
import java.security.interfaces.RSAPrivateKey;
import java.util.Properties;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.*;

public class IssuersTest {

    public static final String KEY_CLASSPATH_RESOURCE = "security/dbf-test-internal/private_key.der";

    @After
    public void tearDown() {
        final File file = new File("./test_key.der");

        if (file.exists()) {
            file.delete();
        }
    }

    @Test
    public void fromClasspathShouldResolveKeyFromClasspath() throws IOException {
        final Supplier<Issuer> supplier = Issuers.fromClassPath("DBF", KEY_CLASSPATH_RESOURCE);
        final Issuer issuer = supplier.get();

        assertThat(issuer).isNotNull();
        assertThat(issuer.name()).isEqualTo("DBF");
        assertThat(issuer.privateKey()).isNotNull();
    }

    @Test
    public void fromClasspathShouldRejectInvalidArguments() throws IOException {
        try {
            Issuers.fromClassPath(null, KEY_CLASSPATH_RESOURCE);
            fail("null supplier name should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromClassPath("", KEY_CLASSPATH_RESOURCE);
            fail("empty supplier name should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromClassPath("DBF", null);
            fail("null resource path should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromClassPath("DBF", "");
            fail("empty resource path should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void fromClasspathShouldAlwaysReturnNullForInvalidResource() throws IOException {
        final Supplier<Issuer> supplier = Issuers.fromClassPath("DBF", "/invalid/key.der");

        assertThat(supplier.get()).isNull();
    }

    @Test
    public void fromFileShouldRejectInvalidArguments() throws IOException {
        try {
            Issuers.fromFile(null, "./test.der");
            fail("null issuer name should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromFile("", "./test.der");
            fail("empty issuer name should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromFile("dbf", null);
            fail("null fileName should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromFile(null, "");
            fail("empty issuer name should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void fromFileShouldReturnNullIfFileDoesNotExist() throws Exception {
        final Supplier<Issuer> supplier = Issuers.fromFile("dbf", "./test.der");

        assertThat(supplier.get()).isNull();
    }

    @Test
    public void fromFileShouldReturnIssuerFromFile() throws Exception {
        final Supplier<Issuer> supplier = Issuers.fromFile("dbf", "./test_key.der");

        copyPrivateKeyToFile();

        final Issuer issuer = supplier.get();

        assertThat(issuer.name()).isEqualTo("dbf");
        assertThat(issuer.privateKey()).isNotNull();
    }

    @Test
    public void oneOfShouldFailIfNoSupplierReturnsAResult() {
        final Supplier<Issuer> supplier = Issuers.oneOf(mock(Supplier.class), mock(Supplier.class));

        try {
            supplier.get();
            fail("oneOf should fail if no supplier matches");
        } catch (IssuerResolutionException e) {
        }
    }

    @Test
    public void oneOfShouldReturnFirstMatchingValue() throws IOException {
        final Supplier supplier1 = mock(Supplier.class, "s1");
        final Supplier supplier2 = mock(Supplier.class, "s2");
        final Supplier supplier3 = mock(Supplier.class, "s3");
        final Supplier<Issuer> supplier = Issuers.oneOf(supplier1, supplier2);
        final Issuer issuer = Issuers.fromClassPath("dbf", KEY_CLASSPATH_RESOURCE).get();

        when(supplier2.get()).thenReturn(issuer);

        assertThat(supplier.get()).isEqualTo(issuer);

        final InOrder inOrder = inOrder(supplier1, supplier2, supplier3);

        inOrder.verify(supplier1).get();
        inOrder.verify(supplier2).get();

        verifyZeroInteractions(supplier3);
    }

    @Test
    public void classpathResourceCanBeLoadedByResourceSelector() throws IOException {
        final Supplier<Issuer> supplier = Issuers.fromResourceSelector("dbf", "classpath:security/dbf-test-internal/private_key.der", "file");

        assertThat(supplier.get().name()).isEqualTo("dbf");
        assertThat(supplier.get().privateKey()).isNotNull();
    }

    @Test
    public void fileCanBeLoadedByResourceSelector() throws IOException {
        copyPrivateKeyToFile();

        final Supplier<Issuer> supplier = Issuers.fromResourceSelector("dbf", "file:./test_key.der", "file");
        final Issuer issuer = supplier.get();

        assertThat(issuer.name()).isEqualTo("dbf");
        assertThat(issuer.privateKey()).isNotNull();
    }

    @Test
    public void defaultResourceSelectorTypeShouldBeUsedIfNonIsSpecified() throws IOException {
        final Supplier<Issuer> supplier = Issuers.fromResourceSelector("dbf", "security/dbf-test-internal/private_key.der", "classpath");
        final Issuer issuer = supplier.get();

        assertThat(issuer.name()).isEqualTo("dbf");
        assertThat(issuer.privateKey()).isNotNull();
    }

    @Test
    public void fromResourceSelectorShouldRejectInvalidArguments() throws IOException {
        try {
            Issuers.fromResourceSelector(null, "classpath:.", "file");
            fail("null issuer should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromResourceSelector("", "classpath:.", "file");
            fail("empty issuer should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromResourceSelector("dbf", null, "file");
            fail("null resourceSelector should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromResourceSelector("dbf", "", "file");
            fail("empty resourceSelector should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromResourceSelector("dbf", "classpath:.", null);
            fail("null defaultResourceType should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.fromResourceSelector("dbf", "classpath:.", "");
            fail("empty defaultResourceType should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void pemKeyTypeCanBeResolvedFromFileName() {
        assertThat(Issuers.KeyType.fromFileName("test.pem")).isEqualTo(Issuers.KeyType.PEM);
        assertThat(Issuers.KeyType.fromFileName("test.PEM")).isEqualTo(Issuers.KeyType.PEM);
    }

    @Test
    public void derKeyTypeCanBeResolvedFromFileName() {
        assertThat(Issuers.KeyType.fromFileName("test.der")).isEqualTo(Issuers.KeyType.DER);
        assertThat(Issuers.KeyType.fromFileName("test.DER")).isEqualTo(Issuers.KeyType.DER);
    }

    @Test
    public void keyTypeCannotBeResolvedFromInvalidFileName() {
        try {
            Issuers.KeyType.fromFileName(null);
            fail("null fileName should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.KeyType.fromFileName("");
            fail("empty fileName should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void keyTypeCannotBeResolvedFromUnsupportedKeyType() {
        try {
            Issuers.KeyType.fromFileName("test.txt");
            fail("invalid extension should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Issuers.KeyType.fromFileName("mydirectory");
            fail("path without extension should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void privateKeyCanBeLoadedFromPkcs8PemFile() throws Exception {
        final ByteArrayInputStream in = new ByteArrayInputStream(("-----BEGIN PRIVATE KEY-----\n" +
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQD9LdXnX/l/byNU\n" +
                "Ra1Dn6FSD+n/OMCw6WjjUwaHVt4BsqWnaPd27dFC7jjbM486rye2+8AD2z4uEd9h\n" +
                "ltl1Gftp5R6MbMHQ231rY+2KeZG/BNRNhPrwqDUeOWYkCjdF2DkEYoldm37EIaXN\n" +
                "tgBi7PolY2oj5hRlAErqEOQBt3N/8F4Qb7Jafg+F83dp4A40/7aTMVpPscxuVsQG\n" +
                "3hb6PPThyZlbMPtu6yLHCpO205J7ksx2mX0NuFlTV5gEvDN8p+Cb7EqV5wEHGA+/\n" +
                "Kbb602ZPFOfGH5/sDkfp/3JHmr/uekIpeUPlpadNhcl5hIlL+kFsO0BJcO7aa7xE\n" +
                "x1mpaKmJAgMBAAECggEAeGsLmUAByEXRFO0LCuXq8cAV+MlChSKPO8gqi8aaU05o\n" +
                "EecQBKX6aQ4rRr8QOcZDann1CyCFQ55GlAEOru7LsMNEM2ArEy7CSYi+26UU2Djw\n" +
                "zWoZfMtUcGq2lR+yyGqeO+KuGTKzKZAjb2NIbcTu+Ud+nVJ6kst/1jJwcAyUR93W\n" +
                "gex11PLsPFk8oiUBwW2YszRrSFhAN588eAqdsPGBtqxqO12+GhzD/FWFlOilTGj/\n" +
                "ZfnAypgCqsbfPOy6etMFtOHqHEYUN1ldy6Nlc/4BnikA12PB4p8mvmMl4eOZ7Eu2\n" +
                "fR8IS6eITyQ8LF9gHky4S8vtRflNq9fwuEe1wUZecQKBgQD/ByX0sQpBIZH9fg4Q\n" +
                "Q3W3AesD9uvCSWElgJiw1WGi1l1wJyiDnmqSUaDiRgAALU6YHpINauwMGOKP3+Lw\n" +
                "FXsibXtsdu7AgygwX0n3tAna/85K9s5plTpPHugRX7gwvX0e2OnTjYu5wl6bhObP\n" +
                "U3dsTYh8mU/oolV9Wmf8SKaNVQKBgQD+JOIZCr4liRaCo9af8eOqCH+Z0yOtSrwD\n" +
                "oSiylXGgA92e+/kU6MvwsemANbvX17zHEKit3HYjsrqHMFavbd0yrAiXHKTbCPRO\n" +
                "Zx24TPnWosDiVfoa/usWeEZUJJLGHoFADXD7hSqGtL8H6LYZD46x7qTC1a5kuvf6\n" +
                "I9mgux9LZQKBgHHXeAsFqKUwXiIBTjfWVUrPUWCgrdc5uGLsR7zQU9hDxswUvtIa\n" +
                "Okp8o8u+IavyjZ38L4hLzXkM9r3w3DX98MyKgMkHQkavhZYqQzOOq8OV4zm1eKjL\n" +
                "E49UJZXz253uSFcnzyE/kzrl2COmLP4prSqsZZvxOCmJpY3ieH6205pNAoGAVT5N\n" +
                "0BR4XuKyeDM4JAHgWQHsus3FI7Tzh0wg+HWD3SYuycq+azMCZMNoDKb5UJZ+LU77\n" +
                "JQXTYnnqcrnV+ZWiIgLuBrGG4ikIuNuBbnXzPvjsNX6dGzzx4WGKRWLXEDjfJXrc\n" +
                "sKCj+PbbNG3r1lAPjsL65JcDnanQz0gDERRylLkCgYEA7Oj1/YUXrhDiKjSs5Ps4\n" +
                "/+xZ97n2Xp5iTogRSqoVw4N1VJqYTWR5/Dj72/HUPaMOwDgmAvuLXSWltBNUsus/\n" +
                "leVlDwOtY0IlZpYBJZxLNb5pySi074/NzcQp5HQsd4HfGCK4qMFcW50ArVxm24nF\n" +
                "V6pHbh+Hdia5tmG/ixmlmmg=\n" +
                "-----END PRIVATE KEY-----\n").getBytes());

        final RSAPrivateKey privateKey = Issuers.KeyType.PEM.load(in);

        assertThat(privateKey).isNotNull();
    }

    @Test
    public void privateKeyCanBeLoadedFromPemFileGeneratedFromCertificate() throws Exception {
        final String key = "-----BEGIN PRIVATE KEY-----\n" +
                "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAMUUVSnOGQo45KBC\n" +
                "LPFMESg7xXuFOlMImDDEp3V5Fburncr/aS/EzT62zrkPEMB5nM5ncjGQN067BQzz\n" +
                "Vxr3yE8MKQOJlaSZDVu3xEzXCzeidgrqp8A/UUDyFwl0SskLaBHjoAawIIX+ymiB\n" +
                "KAdaiR3pf2waQcY1nnrm4EtKnZjtAgMBAAECgYEAgP9jEx8M8sz0kRVft32TyWL+\n" +
                "S3CUEZ+RhnJiLhlYqWOWwDXYEuVddsxPmYAL9gBkLBI4A8si+IyfrK9m94bye+yg\n" +
                "ccKDJf0Qkzd7TbrGdhEYDUlAsjGqZfZfJUWMMYTbUEAFHjKmqKpjAGL7cXOVjzP3\n" +
                "MLieNCUTVQ10IDQdNX0CQQDuvnYJQk7a6KY6CXgilOaS31ua0vLxW1OBop/MZO96\n" +
                "VDYPB3MSn24n4IUjOO/zWVB7OEqPxwJ8taniTjDAiLD3AkEA01LxHyoi5uTesT8f\n" +
                "maLHDv26bxi5gFNBAGWjfEnaA5UaNCfqXsuwQyvT2c1h/oYP5A5BApyJot4Y+omt\n" +
                "4GWwOwJAdO7eW0yZ2MhoWja3G6D4ielSMbOugB5t+SmQwQiS7sR+McBBUVa7Glby\n" +
                "frztcbBGJgP9KQydID3N9mS7piGNIwJBAKvCZ07QPavza/keeD20axyJJ8Xyj5t4\n" +
                "j4WWFsoHcJam0rR/mOPRpIMEFV2arEJmjnXrC/Xma4wf/qdrzhJsNE8CQBWOnEmB\n" +
                "AxDf0KkDmJZsAgnxyxZuI2LkQSklhH+1/ZcFRnipR2GHHENJS4GkKYAjtLDhPr3V\n" +
                "BqESpUrcxQqiNNg=\n" +
                "-----END PRIVATE KEY-----\n";

        assertThat(Issuers.KeyType.PEM.load(new ByteArrayInputStream(key.getBytes()))).isNotNull();
    }

    @Test
    public void fromFileShouldAcceptSystemVariablesInFileName() throws IOException {
        copyPrivateKeyToFile();

        final Properties properties = new Properties();
        properties.setProperty("configuredKeyName", "test_key");

        final Supplier<Issuer> supplier = Issuers.fromFile("RBO", "{configuredKeyName}.der", properties);
        final Issuer issuer = supplier.get();

        assertThat(issuer).isNotNull();
        assertThat(issuer.name()).isEqualTo("RBO");
        assertThat(issuer.privateKey()).isNotNull();
    }

    @Test
    public void fromFileShouldAcceptFileTypeFromProperties() throws Exception {
        copyPrivateKeyToFile();

        final Properties properties = new Properties();
        properties.setProperty("keyType", "der");

        final Supplier<Issuer> supplier = Issuers.fromFile("RBO", "test_key.{keyType}", properties);
        final Issuer issuer = supplier.get();

        assertThat(issuer).isNotNull();
        assertThat(issuer.name()).isEqualTo("RBO");
        assertThat(issuer.privateKey()).isNotNull();
    }

    private void copyPrivateKeyToFile() throws IOException {
        try (final InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("security/dbf-test-internal/private_key.der")) {
            try (final OutputStream out = new FileOutputStream("./test_key.der")) {
                IOUtils.copy(in, out);
            }
        }
    }

}