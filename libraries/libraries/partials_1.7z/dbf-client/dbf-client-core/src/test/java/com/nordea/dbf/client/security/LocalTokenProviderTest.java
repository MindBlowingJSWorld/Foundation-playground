package com.nordea.dbf.client.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.client.RequestConfiguration;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.RsaVerifier;

import java.io.InputStream;
import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.entry;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;

public class LocalTokenProviderTest {

    private final ObjectMapper objectMapper = new ObjectMapper();

    private final RSAPrivateKey privateKey = rsaPrivateKey();

    private final Supplier<Issuer> issuerSupplier = Suppliers.ofInstance(new Issuer("DBF", privateKey));

    private final LocalTokenProvider provider = new LocalTokenProvider(objectMapper, issuerSupplier);

    @Test
    public void constructorShouldNotAcceptInvalidArguments() {
        try {
            new LocalTokenProvider(null, issuerSupplier);
            fail("null objectMapper should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            new LocalTokenProvider(mock(ObjectMapper.class), null);
            fail("null issuerSupplier should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void getTokenShouldNotAcceptNullRequestConfiguration() {
        provider.getToken(null);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void tokenShouldContainInformationFromRequestConfiguration() throws Exception {
        final RequestConfiguration requestConfiguration = RequestConfiguration.newBuilder()
                .applicationId("ROSME")
                .agreementNumber(1234L)
                .authenticationLevel("HIGH")
                .authenticationMethod("BANKID")
                .requestId("myRequest")
                .userId("myUser")
                .country("SE")
                .channelId("NETBANK")
                .sessionId("mySession")
                .build();

        final String token = provider.getToken(requestConfiguration);
        final Map<String, Object> tokenProperties = objectMapper.readValue(JwtHelper.decodeAndVerify(token, new RsaVerifier(rsaPublicKey())).getClaims(), Map.class);

        assertThat(tokenProperties).contains(entry(TokenProvider.AUTH_LEVEL_TOKEN_KEY, "HIGH"));
        assertThat(tokenProperties).contains(entry(TokenProvider.AUTH_METHOD_TOKEN_KEY, "BANKID"));
        assertThat(tokenProperties).contains(entry(TokenProvider.JTI_TOKEN_KEY, "mySession"));
        assertThat(tokenProperties).contains(entry(TokenProvider.ISSUER_TOKEN_KEY, "DBF"));
        assertThat(tokenProperties).contains(entry(TokenProvider.AUDIENCE_TOKEN_KEY, Arrays.asList("osl")));
        assertThat(tokenProperties).contains(entry(TokenProvider.GRANTS_TOKEN_KEY, ImmutableMap.of(LocalTokenProvider.AGREEMENT_GRANT_KEY, 1234)));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void tokenCanBeCreatedWithoutAgreement() throws Exception {
        final RequestConfiguration requestConfiguration = RequestConfiguration.newBuilder()
                .applicationId("ROSME")
                .authenticationLevel("HIGH")
                .authenticationMethod("BANKID")
                .requestId("myRequest")
                .userId("myUser")
                .country("SE")
                .channelId("NETBANK")
                .sessionId("mySession")
                .build();

        final String token = provider.getToken(requestConfiguration);
        final Map<String, Object> tokenProperties = objectMapper.readValue(JwtHelper.decodeAndVerify(token, new RsaVerifier(rsaPublicKey())).getClaims(), Map.class);

        assertThat(tokenProperties).contains(entry(TokenProvider.AUTH_LEVEL_TOKEN_KEY, "HIGH"));
        assertThat(tokenProperties).contains(entry(TokenProvider.AUTH_METHOD_TOKEN_KEY, "BANKID"));
        assertThat(tokenProperties).contains(entry(TokenProvider.JTI_TOKEN_KEY, "mySession"));
        assertThat(tokenProperties).contains(entry(TokenProvider.ISSUER_TOKEN_KEY, "DBF"));
        assertThat(tokenProperties).contains(entry(TokenProvider.AUDIENCE_TOKEN_KEY, Arrays.asList("osl")));
        assertThat(tokenProperties).contains(entry(TokenProvider.CLIENT_ID_TOKEN_KEY, "myUser"));
        assertThat(tokenProperties).contains(entry(TokenProvider.GRANTS_TOKEN_KEY, Collections.emptyMap()));
    }

    private RSAPrivateKey rsaPrivateKey() {
        try (final InputStream in = getClass().getResourceAsStream("/security/dbf-test-internal/private_key.der")) {
            if (in == null) {
                throw new RuntimeException("Private key not found on classpath");
            }

            return (RSAPrivateKey) KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(IOUtils.toByteArray(in)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private RSAPublicKey rsaPublicKey() {
        try (final InputStream in = getClass().getResourceAsStream("/security/dbf-test-internal/public_key.der")) {
            if (in == null) {
                throw new RuntimeException("Public key not found on classpath");
            }

            return (RSAPublicKey) KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(IOUtils.toByteArray(in)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
