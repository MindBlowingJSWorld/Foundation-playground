package com.nordea.dbf.client.jersey;

import javax.ws.rs.client.ClientRequestContext;

public class BaseURLServiceClientTarget implements ServiceClientTarget {

    private final String baseUrl;

    public BaseURLServiceClientTarget(String baseUrl) {
        if (baseUrl == null || baseUrl.isEmpty()) {
            throw new IllegalArgumentException("baseUrl can't be null or empty");
        }

        this.baseUrl = baseUrl;
    }

    @Override
    public boolean test(ClientRequestContext requestContext) {
        if (requestContext == null) {
            throw new IllegalArgumentException("requestContext can't be null");
        }

        return requestContext.getUri().toString().startsWith(baseUrl);
    }

    @Override
    public String toString() {
        return "BaseURLServiceClientTarget{" +
                "baseUrl='" + baseUrl + '\'' +
                '}';
    }
}
