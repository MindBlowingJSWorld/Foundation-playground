package com.nordea.dbf.client.jersey;

import javax.servlet.http.HttpServletRequest;

public interface HttpServletRequestProvider {

    HttpServletRequest get();

}
