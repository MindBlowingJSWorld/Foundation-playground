package com.nordea.dbf.client.jersey;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.client.ClientRequestContext;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;

public class MultipleBaseURLServiceClientTarget implements ServiceClientTarget {

  private final Set<String> baseUrls = new HashSet<String>();

  public MultipleBaseURLServiceClientTarget(String... baseUrls) {
    if (baseUrls == null || baseUrls.length == 0) {
      throw new IllegalArgumentException("baseUrl can't be null or empty");
    }
    
    for (String baseUrl : baseUrls) {
      if( baseUrl == null || baseUrl.isEmpty()) {
        throw new IllegalArgumentException("baseUrl can't be null or empty");
      }
    };

    Collections.addAll(this.baseUrls, baseUrls);
  }

  @Override
  public boolean test(final ClientRequestContext requestContext) {
    if (requestContext == null) {
      throw new IllegalArgumentException("requestContext can't be null");
    }

    return Collections2.filter(baseUrls, new Predicate<String>() {
      @Override
      public boolean apply(String baseUrl) {
        return requestContext.getUri().toString().startsWith(baseUrl);
      }
    }).size() > 0;
  }

  @Override
  public String toString() {
    return "MultipleBaseURLServiceClientTarget{" + "baseUrls='" + baseUrls.toString() + '\'' + '}';
  }
}
