package com.nordea.dbf.client.jersey;

import com.google.common.util.concurrent.SettableFuture;
import org.apache.commons.io.output.ByteArrayOutputStream;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.*;
import org.apache.http.concurrent.FutureCallback;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.message.BasicHeader;
import org.apache.http.nio.client.HttpAsyncClient;
import org.glassfish.jersey.client.ClientRequest;
import org.glassfish.jersey.client.ClientResponse;
import org.glassfish.jersey.client.spi.AsyncConnectorCallback;
import org.glassfish.jersey.client.spi.Connector;
import org.glassfish.jersey.message.internal.OutboundMessageContext;

import javax.ws.rs.core.Response;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class ServiceClientConnector implements Connector {

    private final HttpAsyncClient client;

    public ServiceClientConnector(HttpAsyncClient client) {
        this.client = client;
    }

    @Override
    public ClientResponse apply(ClientRequest request) {
        final Future<ClientResponse> future = apply(request, null);

        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Future<ClientResponse> apply(final ClientRequest request, AsyncConnectorCallback callback) {
        final SettableFuture<ClientResponse> future = SettableFuture.create();
        final HttpUriRequest httpRequest;

        try {
            httpRequest = createHttpRequest(request);
        } catch (IOException e) {
            future.setException(e);
            return future;
        }

        client.execute(httpRequest, new FutureCallback<HttpResponse>() {
            @Override
            public void completed(HttpResponse result) {
                final Response.ResponseBuilder responseBuilder = Response.status(result.getStatusLine().getStatusCode());

                for (final Header header : result.getAllHeaders()) {
                    responseBuilder.header(header.getName(), header.getValue());
                }

                try {
                    responseBuilder.entity(result.getEntity().getContent());
                } catch (IOException e) {
                    future.setException(e);
                }

                final ClientResponse clientResponse = new ClientResponse(request, responseBuilder.build());

                future.set(clientResponse);
            }

            @Override
            public void failed(Exception ex) {
                future.setException(ex);
            }

            @Override
            public void cancelled() {
                future.cancel(true);
            }
        });

        return future;
    }

    @Override
    public String getName() {
        return getClass().getSimpleName();
    }

    @Override
    public void close() {
        // Noop
    }

    protected HttpUriRequest createHttpRequest(ClientRequest request) throws IOException {
        final HttpUriRequest httpRequest = createHttpRequestForMethod(request);

        transferHeadersToHttpRequest(request, httpRequest);
        transferEntityToHttpRequest(request, httpRequest);

        return httpRequest;
    }

    /**
     * Transfers all available headers to the provided HTTP request.
     *
     * @param clientRequest The Jersey request that contains the HTTP headers that should be transferred.
     * @param httpRequest The HTTP request that should transport the headers to the service.
     */
    protected static void transferHeadersToHttpRequest(ClientRequest clientRequest, HttpUriRequest httpRequest) {
        for (final Map.Entry<String, List<Object>> entry : clientRequest.getHeaders().entrySet()) {
            for (final Object headerValue : entry.getValue()) {
                httpRequest.addHeader(new BasicHeader(entry.getKey(), String.valueOf(headerValue)));
            }
        }
    }

    /**
     * Transfers the request entity - if available - to the provided HTTP request. The request method must support
     * request entities or this method will fail. Also, a valid content type is required. If no entity is configured
     * on the request, nothing will be transfered.
     *
     * @param clientRequest The jersey request that potentially contains the request.
     * @param httpRequest The HTTP request to which the entity should be transferred.
     * @throws IOException Thrown if the entity can't be transferred.
     */
    protected static void transferEntityToHttpRequest(ClientRequest clientRequest, HttpUriRequest httpRequest) throws IOException {
        if (clientRequest.getEntity() != null) {
            if (!(httpRequest instanceof HttpEntityEnclosingRequestBase)) {
                throw new IllegalArgumentException("HTTP method '" + clientRequest.getMethod() + "' does not support entity");
            }

            final String contentType = clientRequest.getHeaderString("Content-Type");

            if (contentType == null) {
                throw new IllegalArgumentException("Request can't be sent without Content-Type header");
            }

            final HttpEntityEnclosingRequestBase httpRequestWithEntity = (HttpEntityEnclosingRequestBase) httpRequest;
            final ByteArrayOutputStream bous = new ByteArrayOutputStream();

            clientRequest.setStreamProvider(newOutputStreamStreamProvider(bous));
            clientRequest.writeEntity();

            httpRequestWithEntity.setEntity(new InputStreamEntity(new ByteArrayInputStream(bous.toByteArray()), ContentType.create(contentType)));
        }
    }

    /**
     * Create a new http request for method specified in the provided <code>ClientRequest</code>.
     *
     * @param request The <code>ClientRequest</code> that contains the HTTP method.
     * @return A new <code>HttpUriRequest</code> that is configured with the correct HTTP method.
     */
    protected static HttpUriRequest createHttpRequestForMethod(ClientRequest request) {
        switch (request.getMethod()){
            case "GET":
                return new HttpGet(request.getUri());
            case "POST":
                return new HttpPost(request.getUri());
            case "PATCH":
                return new HttpPatch(request.getUri());
            case "PUT":
                return new HttpPut(request.getUri());
            case "DELETE":
                return new HttpDelete(request.getUri());
            case "TRACE":
                return new HttpTrace(request.getUri());
            case "HEAD":
                return new HttpHead(request.getUri());
            case "OPTIONS":
                return new HttpOptions(request.getUri());
            default:
                throw new IllegalArgumentException("HTTP method '" + request.getMethod() + "' is not supported");
        }
    }
    /**
     * Returns a <code>StreamProvider</code> that simply wraps the provided <code>OutputStream</code>.
     *
     * @param out The <code>OutputStream</code> to which the client request entity should be written.
     * @return A <code>StreamProvider</code> that ensures that the entity is marshalled to the provided stream.
     */
    protected static OutboundMessageContext.StreamProvider newOutputStreamStreamProvider(final OutputStream out) {
        return new OutboundMessageContext.StreamProvider() {
            @Override
            public OutputStream getOutputStream(int i) throws IOException {
                return out;
            }
        };
    }
}
