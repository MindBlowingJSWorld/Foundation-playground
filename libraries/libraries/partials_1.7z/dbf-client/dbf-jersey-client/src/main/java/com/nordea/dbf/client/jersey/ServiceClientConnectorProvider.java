package com.nordea.dbf.client.jersey;

import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.glassfish.jersey.client.spi.Connector;
import org.glassfish.jersey.client.spi.ConnectorProvider;

import javax.ws.rs.client.Client;
import javax.ws.rs.core.Configuration;
import java.io.Closeable;
import java.io.IOException;

public class ServiceClientConnectorProvider implements ConnectorProvider, Closeable {

    private final CloseableHttpAsyncClient client = HttpAsyncClients.createMinimal();

    public ServiceClientConnectorProvider() {
        client.start();
    }

    @Override
    public Connector getConnector(Client client, Configuration runtimeConfig) {
        return new ServiceClientConnector(this.client);
    }

    @Override
    public void close() throws IOException {
        client.close();
    }
}
