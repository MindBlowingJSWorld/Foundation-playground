package com.nordea.dbf.client.jersey;

import org.glassfish.hk2.api.Factory;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.HttpUrlConnectorProvider;
import org.glassfish.jersey.jackson.JacksonFeature;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;


public class ServiceClientFactory implements Factory<Client> {

    private ServiceClientFilter serviceClientFilter;

    @Inject
    public ServiceClientFactory(ServiceClientFilter serviceClientFilter) {
        this.serviceClientFilter = serviceClientFilter;
    }

    @Override
    @Named(ServiceClient.NAME)
    @ServiceClient
    public Client provide() {
        final ClientConfig clientConfig = new ClientConfig()
                .register(JacksonFeature.class)
                .register(serviceClientFilter);

        try {
            Class.forName("org.apache.http.nio.client.HttpAsyncClient");
            clientConfig.connectorProvider(new ServiceClientConnectorProvider());
        } catch (ClassNotFoundException e) {
            clientConfig.property(HttpUrlConnectorProvider.SET_METHOD_WORKAROUND, true);
        }

        return ClientBuilder.newClient(clientConfig);
    }

    @Override
    public void dispose(Client instance) {
        instance.close();
    }
}
