package com.nordea.dbf.client.jersey;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Supplier;
import com.nordea.dbf.client.security.Issuer;
import com.nordea.dbf.client.security.Issuers;
import com.nordea.dbf.client.security.LocalTokenProvider;
import com.nordea.dbf.client.security.TokenProvider;
import org.aeonbits.owner.ConfigCache;
import org.apache.commons.lang.StringUtils;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.server.ContainerException;

import javax.inject.Singleton;
import javax.ws.rs.client.Client;
import javax.ws.rs.core.Feature;
import javax.ws.rs.core.FeatureContext;
import java.io.IOException;

public class ServiceClientFeature implements Feature {

    private final ServiceClientSecurityConfig securityConfig;

    private final ServiceClientTarget serviceClientTarget;

    private ServiceClientFeature(ServiceClientSecurityConfig securityConfig, ServiceClientTarget serviceClientTarget) {
        this.securityConfig = securityConfig;
        this.serviceClientTarget = serviceClientTarget;
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    @Override
    public boolean configure(FeatureContext context) {
        context.register(new AbstractBinder() {
            @Override
            protected void configure() {
                final String issuerName = securityConfig.privateKeyIssuerName();
                final String privateKeyPath = securityConfig.privateKeyPath();
                final Supplier<Issuer> issuerSupplier;

                try {
                    issuerSupplier = Issuers.fromResourceSelector(issuerName, privateKeyPath, "file");
                } catch (IOException e) {
                    throw new ContainerException("Failed to resolve issuer key from '" + privateKeyPath + "'", e);
                }

                bind(securityConfig).to(ServiceClientSecurityConfig.class);
                bind(serviceClientTarget).to(ServiceClientTarget.class);
                bind(new LocalTokenProvider(new ObjectMapper(), Issuers.cached(issuerSupplier))).to(TokenProvider.class);
                bind(ServiceClientFilter.class).in(Singleton.class).to(ServiceClientFilter.class);

                try {
                    bindFactory(ServiceClientFactory.class)
                            .to(Client.class)
                            .named(ServiceClient.NAME)
                            .qualifiedBy(ServiceClientFactory.class.getMethod("provide").getAnnotation(ServiceClient.class))
                            .in(Singleton.class)
                            .ranked(Integer.MIN_VALUE);
                } catch (NoSuchMethodException e) {
                    throw new ContainerException("Could not resolve ServiceClientFactory::provide() method", e);
                }
            }
        });

        return true;
    }

    public static class Builder {

        private ServiceClientSecurityConfig securityConfig;

        private ServiceClientTarget serviceClientTarget;

        public Builder securityConfig(ServiceClientSecurityConfig securityConfig) {
            if (securityConfig == null) {
                throw new IllegalArgumentException("securityConfig can't be null");
            }

            this.securityConfig = securityConfig;
            return this;
        }

        public Builder serviceUrlPattern(String serviceUrlPattern) {
            if (serviceUrlPattern == null || serviceUrlPattern.isEmpty()) {
                throw new IllegalArgumentException("serviceUrlPattern can't be null or empty");
            }

            checkServiceClientTargetNotSet();

            this.serviceClientTarget = new URLPatternServiceClientTarget(serviceUrlPattern);
            return this;
        }

        public Builder serviceBaseUrl(String serviceBaseUrl) {
            if (serviceBaseUrl == null || serviceBaseUrl.isEmpty()) {
                throw new IllegalArgumentException("serviceBaseUrl can't be null or empty");
            }

            checkServiceClientTargetNotSet();

            this.serviceClientTarget = new BaseURLServiceClientTarget(serviceBaseUrl);
            return this;
        }

        public Builder multipleServiceBaseUrls(String... serviceBaseUrls) {
          if (serviceBaseUrls == null || serviceBaseUrls.length == 0) {
              throw new IllegalArgumentException("serviceBaseUrls can't be null or empty");
          }

          checkServiceClientTargetNotSet();

          this.serviceClientTarget = new MultipleBaseURLServiceClientTarget(serviceBaseUrls);
          return this;
      }

        public ServiceClientFeature build() {
            if (securityConfig == null) {
                securityConfig = ConfigCache.getOrCreate(ServiceClientSecurityConfig.class, System.getProperties());
            }

            if (StringUtils.isEmpty(securityConfig.privateKeyPath())) {
                throw new ContainerException(
                    "Private key path for DBF token signing is not specified in configuration. " +
                    "Make sure you have specified 'com.nordea.environmenttype' with value (LOCAL|LOCAL_MOCK|DEV|TEST|PROD)." +
                    "If running in TEST or PROD, also make sure you provide a configuration file and private key. " +
                    "See https://confluence.oneadr.net:8443/display/DBTA/Client+configuration.");
            }

            return new ServiceClientFeature(securityConfig, serviceClientTarget);
        }

        private void checkServiceClientTargetNotSet() {
            if (serviceClientTarget != null) {
                throw new IllegalArgumentException("serviceClientTarget already set (set either serviceUrlPattern or serviceBaseUrl or multipleServiceBaseUrls, not all)");
            }
        }
    }

}
