package com.nordea.dbf.client.jersey;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;
import com.google.common.net.HttpHeaders;
import com.nordea.dbf.client.RequestConfiguration;
import com.nordea.dbf.client.RequestConfigurer;
import com.nordea.dbf.client.security.TokenProvider;
import com.nordea.dbf.model.http.DBFClientServiceRequestContext;
import com.nordea.dbf.model.http.DBFClientServiceRequestContextBuilder;

public class ServiceClientFilter implements ClientRequestFilter {


    /**
     * Non-standard HTTP header to propagate the service request context across multiple
     * systems in terms of logging.
     */
    public static final String CLIENT_CONTEXT_HEADER_NAME = "X-DBF-ServiceRequestContext";
    public static final String AUTH_HEADER_NAME = HttpHeaders.AUTHORIZATION;

    /**
     * Date format for the <code>Date</code> HTTP header which signifies the date of the client request.
     *
     * @see <a href="http://en.wikipedia.org/wiki/List_of_HTTP_header_fields">HTTP header fields</a>
     */
    private static final ThreadLocal<DateFormat> HTTP_DATE_FORMAT = new ThreadLocal<DateFormat>() {
        @Override
        protected DateFormat initialValue() {
            final SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
            dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
            return dateFormat;
        }
    };

    private final RequestConfigurer requestConfigurer;

    private final TokenProvider tokenProvider;

    private final ServiceClientTarget serviceClientTarget;

    private final HttpServletRequestProvider httpServletRequestProvider;

    @Inject
    public ServiceClientFilter(RequestConfigurer requestConfigurer,
                               TokenProvider tokenProvider,
                               ServiceClientTarget serviceClientTarget,
                               HttpServletRequestProvider httpServletRequestProvider) {
        this.requestConfigurer = requestConfigurer;
        this.tokenProvider = tokenProvider;
        this.serviceClientTarget = serviceClientTarget;
        this.httpServletRequestProvider = httpServletRequestProvider;
    }

    @Override
    public void filter(ClientRequestContext requestContext) throws IOException {
        if (serviceClientTarget.test(requestContext)) {
            final RequestConfiguration requestConfiguration = requestConfigurer.getRequestConfiguration();
            final String token = tokenProvider.getToken(requestConfiguration);
            requestContext.getHeaders().add(AUTH_HEADER_NAME, "Bearer " + token);

            final HttpServletRequest request = httpServletRequestProvider.get();

            propagateClientContext(request, requestContext, requestConfiguration);
            propagateForwardingInformation(request, requestContext);
            propagateLanguage(request, requestContext, requestConfiguration);
        }
    }

    private void propagateClientContext(HttpServletRequest request, ClientRequestContext requestContext, RequestConfiguration requestConfiguration) {
        DBFClientServiceRequestContextBuilder clientContextBuilder = new DBFClientServiceRequestContextBuilder();
        clientContextBuilder.applicationId(requestConfiguration.getApplicationId());
        clientContextBuilder.requestId(requestConfiguration.getRequestId());
        clientContextBuilder.sessionId(requestConfiguration.getSessionId());
        clientContextBuilder.channelId(requestConfiguration.getChannelId());
        clientContextBuilder.country(requestConfiguration.getCountry());
        clientContextBuilder.timeStamp(getClientTimeStamp(request));
        requestContext.getHeaders().add(CLIENT_CONTEXT_HEADER_NAME, serialize(clientContextBuilder.build()));
    }

    private void propagateLanguage(HttpServletRequest request, ClientRequestContext requestContext, RequestConfiguration requestConfiguration) {

        // If Accept Language Header is already set we should not override its value
        if(requestContext.getHeaderString(HttpHeaders.ACCEPT_LANGUAGE) !=null){
            return;
        }

        if (request != null && !StringUtils.isEmpty(request.getHeader(HttpHeaders.ACCEPT_LANGUAGE))) {
          requestContext.getHeaders().add(HttpHeaders.ACCEPT_LANGUAGE, request.getHeader(HttpHeaders.ACCEPT_LANGUAGE));
        } else if (!StringUtils.isEmpty(requestConfiguration.getCountry())) {
          requestContext.getHeaders().add(HttpHeaders.ACCEPT_LANGUAGE, requestConfiguration.getCountry());
        }
    }

    private long getClientTimeStamp(HttpServletRequest request){
        long clientTimeStamp = (request == null ? -1L : request.getDateHeader(HttpHeaders.DATE));
        if (clientTimeStamp <= 0) {
            clientTimeStamp = System.currentTimeMillis();
        }
        return clientTimeStamp;
    }

    private void propagateForwardingInformation(HttpServletRequest request, ClientRequestContext requestContext) {
        if (request != null) {
            final String forwardedFor = request.getHeader(HttpHeaders.X_FORWARDED_FOR);
            final List<String> requestPath = new LinkedList<>();

            if (!StringUtils.isEmpty(forwardedFor)) {
                requestPath.addAll(Arrays.asList(forwardedFor.split(",\\s*")));
            }

            requestPath.add(request.getRemoteAddr());

            requestContext.getHeaders().add(HttpHeaders.X_FORWARDED_FOR, Joiner.on(", ").join(requestPath));
        }
    }

    private String serialize(DBFClientServiceRequestContext context) {
        try {
            return new ObjectMapper().writeValueAsString(context);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Failed to serialize to json: "+super.toString(), e);
        }
    }

}
