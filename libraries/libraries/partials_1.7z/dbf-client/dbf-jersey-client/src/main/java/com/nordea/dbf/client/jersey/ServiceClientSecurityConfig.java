package com.nordea.dbf.client.jersey;

import org.aeonbits.owner.Config;

@Config.LoadPolicy(Config.LoadType.FIRST)
@Config.Sources({
        "file:${com.nordea.midas.appProperties}/dbf-client-security.properties",
        "classpath:dbf-client-security_${com.nordea.environmenttype}.properties",
        "classpath:dbf-client-security-default_${com.nordea.environmenttype}.properties",
        "classpath:dbf-client-security.properties"})
public interface ServiceClientSecurityConfig extends Config {

        @Key("dbf.client.security.privatekey.path")
        String privateKeyPath();

        @DefaultValue("dbf")
        @Key("dbf.client.security.privatekey.issuer")
        String privateKeyIssuerName();

}
