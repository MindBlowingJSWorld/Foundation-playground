package com.nordea.dbf.client.jersey;

import javax.ws.rs.client.ClientRequestContext;

public interface ServiceClientTarget {

    boolean test(ClientRequestContext requestContext);

}
