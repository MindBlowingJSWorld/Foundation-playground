package com.nordea.dbf.client.jersey;

import javax.ws.rs.client.ClientRequestContext;
import java.util.regex.Pattern;

public class URLPatternServiceClientTarget implements ServiceClientTarget {

    private final Pattern pathPattern;

    public URLPatternServiceClientTarget(String pathPattern) {
        if (pathPattern == null || pathPattern.isEmpty()) {
            throw new IllegalArgumentException("pathPattern can't be null or empty");
        }

        this.pathPattern = Pattern.compile(pathPattern.replace(".", "\\.").replace("*", ".*"));
    }

    @Override
    public boolean test(ClientRequestContext requestContext) {
        return pathPattern.matcher(requestContext.getUri().toString()).matches();
    }
}
