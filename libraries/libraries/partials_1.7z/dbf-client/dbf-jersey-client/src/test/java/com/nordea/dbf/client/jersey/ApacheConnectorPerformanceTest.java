package com.nordea.dbf.client.jersey;

import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.AbstractHandler;
import org.glassfish.jersey.client.ClientConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

public class ApacheConnectorPerformanceTest {

    private Server server;

    private int localPort;

    private final ServiceClientConnectorProvider connectorProvider = new ServiceClientConnectorProvider();

    private final Client client = ClientBuilder.newClient(new ClientConfig().connectorProvider(connectorProvider));

    private WebTarget target;

    @Before
    public void setup() throws Exception {
        try (final ServerSocket serverSocket = new ServerSocket(0)) {
            this.localPort = serverSocket.getLocalPort();
            this.server = new Server(localPort);
        }

        server.setHandler(new AbstractHandler() {
            @Override
            public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
                baseRequest.setHandled(true);
            }
        });

        server.start();
        target = client.target("http://localhost:" + localPort);
    }

    @After
    public void tearDown() throws Exception {
        server.stop();
        server.destroy();
        connectorProvider.close();
    }

    @Test
    public void runPerformanceTest() throws InterruptedException, BrokenBarrierException {
        final int threadCount = 2;
        final int maxCalls = 10000;
        final CyclicBarrier barrier = new CyclicBarrier(threadCount + 1);

        System.gc();

        final long freeMemoryBefore = Runtime.getRuntime().freeMemory();

        for (int thread = 0; thread < threadCount; thread++) {
            new Thread("test-thread-" + thread) {
                @Override
                public void run() {
                    long average = 0;

                    for (int i = 0; i < maxCalls; i++) {
                        final long start = System.nanoTime();

                        try {
                            final Response response = target.request().get();
                            assertThat(response.getStatus()).isEqualTo(200);
                        } finally {
                            final long end = System.nanoTime();
                            final long duration = end - start;

                            average = (average * i + duration) / (i + 1);
                        }
                    }

                    try {
                        barrier.await();
                    } catch (InterruptedException | BrokenBarrierException e) {
                    }

                    System.out.println("Thread " + Thread.currentThread().getName() + ", " + TimeUnit.NANOSECONDS.toMillis(average) + "ms per call in average");
                }
            }.start();
        }

        barrier.await();

        System.gc();
        final long freeMemoryAfter = Runtime.getRuntime().freeMemory();

        System.out.println(freeMemoryAfter - freeMemoryBefore + " bytes potentially 'leaked'");
    }

}
