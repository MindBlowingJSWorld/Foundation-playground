package com.nordea.dbf.client.jersey;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.URI;

import javax.ws.rs.client.ClientRequestContext;

import org.junit.Test;

public class BaseURLServiceClientTargetTest {

    private final BaseURLServiceClientTarget target = new BaseURLServiceClientTarget("http://localhost:1234/dbf");

    @Test
    public void constructorShouldNotAcceptNullOrEmptyBaseURL() {
        try {
            new BaseURLServiceClientTarget(null);
            fail("null baseURL should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            new BaseURLServiceClientTarget("");
            fail("empty baseURL should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testShouldNotAcceptNullRequestContext() {
        target.test(null);
    }

    @Test
    public void testShouldReturnTrueForMatchingUrl() throws Exception {
        final ClientRequestContext requestContext = mock(ClientRequestContext.class);
        when(requestContext.getUri()).thenReturn(URI.create("http://localhost:1234/dbf/foo"));

        assertThat(target.test(requestContext)).isTrue();
    }

    @Test
    public void testShouldReturnFalseForNonMatchingUrl() throws Exception {
        final ClientRequestContext requestContext = mock(ClientRequestContext.class);
        when(requestContext.getUri()).thenReturn(URI.create("http://localhost:1234/foo"));

        assertThat(target.test(requestContext)).isFalse();
    }

}