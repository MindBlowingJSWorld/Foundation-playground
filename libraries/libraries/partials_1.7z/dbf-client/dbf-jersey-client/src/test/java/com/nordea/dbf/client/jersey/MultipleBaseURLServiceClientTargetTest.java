package com.nordea.dbf.client.jersey;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.URI;

import javax.ws.rs.client.ClientRequestContext;

import org.junit.Test;

public class MultipleBaseURLServiceClientTargetTest {

  private final MultipleBaseURLServiceClientTarget target =
      new MultipleBaseURLServiceClientTarget("http://localhost:1234/dbf", "http://toinenhost.muualla/dbf2", "http://jokuhost:5456/dbf3");

  @Test(expected = IllegalArgumentException.class)
  public void constructorWithNullBaseURLShouldThrowIllegalArgumentException() {
    new MultipleBaseURLServiceClientTarget((String) null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void constructorWithEmptyBaseURLThrowIllegalArgumentException() {
    new MultipleBaseURLServiceClientTarget("");
  }

  @Test(expected = IllegalArgumentException.class)
  public void usageOfNonArgumentConstructorShouldThrowIllegalArgumentException() {
    new MultipleBaseURLServiceClientTarget();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testShouldNotAcceptNullRequestContext() {
    target.test(null);
  }

  @Test
  public void testShouldReturnTrueForMatchingUrl() throws Exception {
    final ClientRequestContext requestContext = mock(ClientRequestContext.class);
    when(requestContext.getUri()).thenReturn(URI.create("http://localhost:1234/dbf/foo"));

    assertThat(target.test(requestContext)).isTrue();
  }

  @Test
  public void testShouldReturnTrueForMatchingSecondUrl() throws Exception {
    final ClientRequestContext requestContext = mock(ClientRequestContext.class);
    when(requestContext.getUri()).thenReturn(URI.create("http://toinenhost.muualla/dbf2/foo"));

    assertThat(target.test(requestContext)).isTrue();
  }

  @Test
  public void testShouldReturnTrueForMatchingThirdUrl() throws Exception {
    final ClientRequestContext requestContext = mock(ClientRequestContext.class);
    when(requestContext.getUri()).thenReturn(URI.create("http://jokuhost:5456/dbf3/foo"));

    assertThat(target.test(requestContext)).isTrue();
  }

  @Test
  public void testShouldReturnFalseForNonMatchingUrl() throws Exception {
    final ClientRequestContext requestContext = mock(ClientRequestContext.class);
    when(requestContext.getUri()).thenReturn(URI.create("http://localhost:1234/foo"));

    assertThat(target.test(requestContext)).isFalse();
  }

}
