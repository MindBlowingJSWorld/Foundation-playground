package com.nordea.dbf.client.jersey;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import jdk.nashorn.internal.objects.annotations.Function;
import org.apache.commons.io.IOUtils;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.AbstractHandler;
import org.glassfish.jersey.client.ClientConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;

public class ServiceClientConnectorIntegrationTest {

    private final ServiceClientConnectorProvider connectorProvider = new ServiceClientConnectorProvider();

    private final Client client = ClientBuilder.newClient(new ClientConfig().connectorProvider(connectorProvider));

    private int localPort;

    private Server server;

    private WebTarget local;

    private final AtomicReference<BiConsumer<HttpServletRequest, HttpServletResponse>> responder = new AtomicReference<>();

    @Before
    public void setup() throws Exception {
        try (final ServerSocket serverSocket = new ServerSocket(0)) {
            this.localPort = serverSocket.getLocalPort();
            this.server = new Server(localPort);
        }

        this.local = client.target("http://localhost:" + localPort);

        server.setHandler(newAbstractHandler());
        server.start();
    }

    @After
    public void tearDown() throws Exception {
        server.stop();
        server.destroy();
        connectorProvider.close();
    }

    @Test
    public void getRequestWithResponseShouldBeSupportedByConnector() {
        responder.set(new BiConsumer<HttpServletRequest, HttpServletResponse>() {
            @Override
            public void accept(HttpServletRequest request, HttpServletResponse httpServletResponse) {
                assertThat(request.getMethod()).isEqualTo("GET");
                checkRequestAndSetSampleResponse(request, httpServletResponse);
            }
        });

        final Response response = local.path("/test").request().header("X-Request-Header", "test_request_value").get();

        checkResponse(response);
    }

    @Test
    public void postRequestWithRequestEntityAndResponseEntityShouldBeSupportedByConnector() {
        responder.set(new BiConsumer<HttpServletRequest, HttpServletResponse>() {
            @Override
            public void accept(HttpServletRequest request, HttpServletResponse httpServletResponse) {
                assertThat(request.getMethod()).isEqualTo("POST");
                checkRequestWithEntityAndSetSampleResponse(request, httpServletResponse);
            }
        });

        final Response response = local.path("/test").request()
                .header("X-Request-Header", "test_request_value")
                .post(Entity.text("RequestEntity"));

        checkResponse(response);
    }

    @Test
    public void patchRequestWithRequestEntityAndResponseEntityShouldBeSupportedByConnector() {
        responder.set(new BiConsumer<HttpServletRequest, HttpServletResponse>() {
            @Override
            public void accept(HttpServletRequest request, HttpServletResponse httpServletResponse) {
                assertThat(request.getMethod()).isEqualTo("PATCH");
                checkRequestWithEntityAndSetSampleResponse(request, httpServletResponse);
            }
        });

        final Response response = local.path("/test").request()
                .header("X-Request-Header", "test_request_value")
                .method("PATCH", Entity.text("RequestEntity"));

        checkResponse(response);
    }

    @Test
    public void putRequestWithRequestEntityAndResponseEntityShouldBeSupportedByConnector() {
        responder.set(new BiConsumer<HttpServletRequest, HttpServletResponse>() {
            @Override
            public void accept(HttpServletRequest request, HttpServletResponse httpServletResponse) {
                assertThat(request.getMethod()).isEqualTo("PUT");
                checkRequestWithEntityAndSetSampleResponse(request, httpServletResponse);
            }
        });

        final Response response = local.path("/test").request()
                .header("X-Request-Header", "test_request_value")
                .put(Entity.text("RequestEntity"));

        checkResponse(response);
    }

    private void checkRequestWithEntityAndSetSampleResponse(HttpServletRequest request, HttpServletResponse httpServletResponse) {
        checkRequestAndSetSampleResponse(request, httpServletResponse);

        try {
            assertThat(IOUtils.toString(request.getInputStream())).isEqualTo("RequestEntity");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void checkResponse(Response response) {
        assertThat(response.getStatus()).isEqualTo(201);
        assertThat(response.getHeaderString("X-Response-Header")).isEqualTo("test_response_value");
        assertThat(response.readEntity(String.class)).isEqualTo("ResponseEntity");
    }

    private void checkRequestAndSetSampleResponse(HttpServletRequest request, HttpServletResponse httpServletResponse) {
        assertThat(request.getPathInfo()).isEqualTo("/test");
        assertThat(request.getHeader("X-Request-Header")).isEqualTo("test_request_value");

        httpServletResponse.setContentType("text/plain");
        httpServletResponse.setHeader("X-Response-Header", "test_response_value");
        httpServletResponse.setStatus(201);

        try {
            httpServletResponse.getWriter().print("ResponseEntity");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private AbstractHandler newAbstractHandler() {
        return new AbstractHandler() {
            @Override
            public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
                responder.get().accept(request, response);
                baseRequest.setHandled(true);
            }
        };
    }
}
