package com.nordea.dbf.client.jersey;

import com.google.common.collect.ImmutableMap;
import org.apache.http.client.methods.*;
import org.glassfish.jersey.client.ClientRequest;
import org.glassfish.jersey.message.internal.OutboundMessageContext;
import org.junit.Test;
import org.mockito.InOrder;

import javax.ws.rs.core.MultivaluedHashMap;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class ServiceClientConnectorTest {

    private final ClientRequest clientRequest = mock(ClientRequest.class);

    @Test
    public void streamProviderShouldWrapTheProviderOutputStream() throws IOException {
        final OutputStream out = new ByteArrayOutputStream();
        final OutboundMessageContext.StreamProvider streamProvider = ServiceClientConnector.newOutputStreamStreamProvider(out);

        assertThat(streamProvider.getOutputStream(0)).isSameAs(out);
    }

    @Test
    public void createHttpRequestForMethodShouldCreateInstanceOfTheCorrectType() {
        assertThat(ServiceClientConnector.createHttpRequestForMethod(clientRequestWithMethod("GET"))).isInstanceOf(HttpGet.class);
        assertThat(ServiceClientConnector.createHttpRequestForMethod(clientRequestWithMethod("POST"))).isInstanceOf(HttpPost.class);
        assertThat(ServiceClientConnector.createHttpRequestForMethod(clientRequestWithMethod("PUT"))).isInstanceOf(HttpPut.class);
        assertThat(ServiceClientConnector.createHttpRequestForMethod(clientRequestWithMethod("PATCH"))).isInstanceOf(HttpPatch.class);
        assertThat(ServiceClientConnector.createHttpRequestForMethod(clientRequestWithMethod("TRACE"))).isInstanceOf(HttpTrace.class);
        assertThat(ServiceClientConnector.createHttpRequestForMethod(clientRequestWithMethod("HEAD"))).isInstanceOf(HttpHead.class);
        assertThat(ServiceClientConnector.createHttpRequestForMethod(clientRequestWithMethod("OPTIONS"))).isInstanceOf(HttpOptions.class);
        assertThat(ServiceClientConnector.createHttpRequestForMethod(clientRequestWithMethod("DELETE"))).isInstanceOf(HttpDelete.class);
    }

    @Test
    public void transferEntityShouldFailIfEntityIsSpecifiedForGet() throws IOException {
        when(clientRequest.getMethod()).thenReturn("GET");
        when(clientRequest.getEntity()).thenReturn("test");

        try {
            ServiceClientConnector.transferEntityToHttpRequest(clientRequest, mock(HttpUriRequest.class));
            fail("should fail if method does not support entity");
        } catch (IllegalArgumentException e) {
            assertThat(e.getMessage()).contains("GET");
        }
    }

    @Test
    public void transferEntityShouldFailIfNoContentTypeIsSpecified() throws IOException {
        when(clientRequest.getMethod()).thenReturn("POST");
        when(clientRequest.getEntity()).thenReturn("test");
        when(clientRequest.getHeaderString(eq("Content-Type"))).thenReturn(null);

        try {
            ServiceClientConnector.transferEntityToHttpRequest(clientRequest, mock(HttpPost.class));
            fail("entity should not be transferrable without a valid content type");
        } catch (IllegalArgumentException e) {
            assertThat(e.getMessage()).contains("Content-Type");
        }
    }

    @Test
    public void transferEntityShouldWriteEntityToHttpRequest() throws IOException {
        when(clientRequest.getMethod()).thenReturn("POST");
        when(clientRequest.getEntity()).thenReturn("test");
        when(clientRequest.getHeaderString(eq("Content-Type"))).thenReturn("text/plain");

        final HttpPost post = new HttpPost("http://localhost:1234");

        ServiceClientConnector.transferEntityToHttpRequest(clientRequest, post);

        final InOrder inOrder = inOrder(clientRequest);

        inOrder.verify(clientRequest).setStreamProvider(any(OutboundMessageContext.StreamProvider.class));
        inOrder.verify(clientRequest).writeEntity();

        assertThat(post.getEntity().getContentType().getValue()).isEqualTo("text/plain");
    }

    @Test
    public void transferHeadersToHttpRequestShouldCopyAllAvailableHeaders() throws IOException {
        when(clientRequest.getHeaders()).thenReturn(new MultivaluedHashMap<String, Object>(ImmutableMap.of(
                "Header1", "value1",
                "Header2", "value2")));

        final HttpPost post = new HttpPost();

        ServiceClientConnector.transferHeadersToHttpRequest(clientRequest, post);

        assertThat(post.getAllHeaders()).hasSize(2);
        assertThat(post.getFirstHeader("Header1").getValue()).isEqualTo("value1");
        assertThat(post.getFirstHeader("Header2").getValue()).isEqualTo("value2");
    }

    private ClientRequest clientRequestWithMethod(String method) {
        final ClientRequest clientRequest = mock(ClientRequest.class);
        when(clientRequest.getMethod()).thenReturn(method);
        return clientRequest;
    }

}
