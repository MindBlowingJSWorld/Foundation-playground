package com.nordea.dbf.client.jersey;

import com.nordea.dbf.client.RequestConfigurer;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.server.ApplicationHandler;
import org.glassfish.jersey.server.ResourceConfig;
import org.junit.Before;
import org.junit.Test;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.Client;
import javax.ws.rs.core.Feature;
import javax.ws.rs.core.FeatureContext;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ServiceClientDependencyInjectionTest {

    public static class ExampleComponent {

        @Inject
        @ServiceClient
        private Client client;

        public Client getClient() {
            return client;
        }
    }

    public static class ExampleApplication extends ResourceConfig {
        public ExampleApplication(final ServiceClientSecurityConfig securityConfig, final RequestConfigurer requestConfigurer, final String serviceUrlPattern, final Client otherClient) {
            register(new AbstractBinder() {
                @Override
                protected void configure() {
                    bind(otherClient).to(Client.class).ranked(Integer.MAX_VALUE);
                }
            });

            register(new AbstractBinder() {
                @Override
                protected void configure() {
                    bind(new HttpServletRequestProvider() {
                        @Override
                        public HttpServletRequest get() {
                            return mock(HttpServletRequest.class);
                        }
                    }).to(HttpServletRequestProvider.class);

                    bind(requestConfigurer).to(RequestConfigurer.class);
                    bind(ExampleComponent.class).to(ExampleComponent.class).in(Singleton.class);
                }
            });

            // Register through a Feature, similar to RBO
            register(new Feature() {
                @Override
                public boolean configure(FeatureContext context) {
                    context.register(ServiceClientFeature.newBuilder()
                            .securityConfig(securityConfig)
                            .serviceUrlPattern(serviceUrlPattern)
                            .build());

                    return true;
                }
            });
        }
    }

    @Test
    public void clientCanBeQualifiedByAnnotation() {
        final ServiceClientSecurityConfig securityConfig = mock(ServiceClientSecurityConfig.class);

        when(securityConfig.privateKeyIssuerName()).thenReturn("dbf");
        when(securityConfig.privateKeyPath()).thenReturn("classpath:security/dbf-test-internal/private_key.der");

        final Client otherClient = mock(Client.class);
        final ApplicationHandler handler = new ApplicationHandler(new ExampleApplication(securityConfig, mock(RequestConfigurer.class), "http://localhost/*", otherClient));

        final ExampleComponent exampleComponent = handler.getServiceLocator().getService(ExampleComponent.class);

        assertThat(exampleComponent.getClient()).isNotNull();
        assertThat(exampleComponent.getClient()).isNotEqualTo(otherClient);
    }

}
