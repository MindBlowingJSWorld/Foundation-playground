package com.nordea.dbf.client.jersey;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;
import com.nordea.dbf.client.RequestConfiguration;
import com.nordea.dbf.client.RequestConfigurer;
import com.nordea.dbf.client.security.TokenProvider;
import org.apache.commons.io.IOUtils;
import org.eclipse.jetty.server.Request;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.AbstractHandler;
import org.glassfish.hk2.api.Factory;
import org.glassfish.hk2.utilities.binding.AbstractBinder;
import org.glassfish.jersey.server.ApplicationHandler;
import org.glassfish.jersey.server.ResourceConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.RsaVerifier;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ServiceClientFeatureIntegrationTest {

    private static final String AUTHORIZATION_TEST_KEY = "authorization";
    private static final String CLIENT_CONTEXT_TEST_KEY = "clientContext";

    public static class JerseyClientFactory implements Factory<Client> {

        private final ServiceClientFilter clientRequestFilter;

        @Inject
        public JerseyClientFactory(ServiceClientFilter clientRequestFilter) {
            this.clientRequestFilter = clientRequestFilter;
        }

        @Override
        public Client provide() {
            return ClientBuilder.newBuilder().register(clientRequestFilter).build();
        }

        @Override
        public void dispose(Client instance) {
            instance.close();
        }
    }

    public static class ClientApplication extends ResourceConfig {
        public ClientApplication(final ServiceClientSecurityConfig securityConfig, final RequestConfigurer requestConfigurer, String serviceUrlPattern) {
            register(ServiceClientFeature.newBuilder()
                    .securityConfig(securityConfig)
                    .serviceUrlPattern(serviceUrlPattern)
                    .build());

            register(new AbstractBinder() {
                @Override
                protected void configure() {
                    bind(requestConfigurer).to(RequestConfigurer.class);
                    bindFactory(JerseyClientFactory.class).in(Singleton.class).to(Client.class);
                    bind(new HttpServletRequestProvider() {
                        @Override
                        public HttpServletRequest get() {
                            return null;
                        }
                    }).to(HttpServletRequestProvider.class);
                }
            });
        }
    }

    private final RequestConfigurer requestConfigurer = mock(RequestConfigurer.class);

    private ApplicationHandler handler;

    private Client client;

    private int localPort;

    private Server server;

    private String baseURI;

    @Before
    public void setup() throws Exception {
        try (final ServerSocket serverSocket = new ServerSocket(0)) {
            this.localPort = serverSocket.getLocalPort();
            this.server = new Server(localPort);
            this.baseURI = "http://localhost:" + localPort;
        }

        final ServiceClientSecurityConfig securityConfig = mock(ServiceClientSecurityConfig.class);

        when(securityConfig.privateKeyIssuerName()).thenReturn("dbf");
        when(securityConfig.privateKeyPath()).thenReturn("classpath:security/dbf-test-internal/private_key.der");

        this.handler = new ApplicationHandler(new ClientApplication(securityConfig, requestConfigurer, "http://localhost:" + localPort + "/test/dbf/*"));

        this.client = handler.getServiceLocator().getService(Client.class, ServiceClient.NAME);

        server.setHandler(createJettyHandler());
        server.start();
    }

    @After
    public void tearDown() throws Exception {
        this.server.stop();
        this.server.destroy();
    }

    @Test
    public void dbfContextShouldBeConfiguredOnDbfRequest() throws Exception {
        final RequestConfiguration requestConfiguration = RequestConfiguration.newBuilder()
                .applicationId("anApplication")
                .sessionId("aSessionId")
                .requestId("aRequestId")
                .userId("aUser")
                .country("SE")
                .channelId("NETBANK")
                .authenticationMethod("BANKID")
                .authenticationLevel("HIGH")
                .agreementNumber(1234L)
                .build();

        when(requestConfigurer.getRequestConfiguration()).thenReturn(requestConfiguration);

        final Map responseBody = executeAndGetResponse("test/dbf/example");

        assertBearerTokenValid(requestConfiguration, (String) responseBody.get(AUTHORIZATION_TEST_KEY));
        assertThat(responseBody.get(CLIENT_CONTEXT_TEST_KEY)).isNotNull();
    }

    @Test
    public void dbfContextShouldNotBeConfiguredForNonDbfRequest() throws Exception {
        final Map responseBody = executeAndGetResponse("test/example");

        assertThat(responseBody).isEmpty();
    }

    // Support methods
    //

    private Map executeAndGetResponse(String path) {
        final Response response = client.target(baseURI).path(path).request().get();
        assertThat(response.getStatus()).isEqualTo(200);

        return response.readEntity(Map.class);
    }

    private void assertBearerTokenValid(RequestConfiguration requestConfiguration, String authorization) throws IOException {
        assertThat(authorization).startsWith("Bearer ");

        final String tokenAsString = authorization.substring(7);
        final Jwt jwt = JwtHelper.decodeAndVerify(tokenAsString, new RsaVerifier(rsaPublicKey()));
        final Map tokenProperties = new ObjectMapper().readValue(jwt.getClaims(), Map.class);

        assertThat(tokenProperties.get(TokenProvider.JTI_TOKEN_KEY)).isEqualTo(requestConfiguration.getSessionId());
        assertThat(tokenProperties.get(TokenProvider.ISSUER_TOKEN_KEY)).isEqualTo("dbf");
        assertThat(tokenProperties.get(TokenProvider.AUDIENCE_TOKEN_KEY)).isEqualTo(Collections.singletonList("osl"));
        assertThat(tokenProperties.get(TokenProvider.AUTH_METHOD_TOKEN_KEY)).isEqualTo(requestConfiguration.getAuthenticationMethod());
        assertThat(tokenProperties.get(TokenProvider.AUTH_LEVEL_TOKEN_KEY)).isEqualTo(requestConfiguration.getAuthenticationLevel());
        assertThat(tokenProperties.get(TokenProvider.CLIENT_ID_TOKEN_KEY)).isEqualTo(requestConfiguration.getUserId());
        assertThat(tokenProperties.get(TokenProvider.GRANTS_TOKEN_KEY)).isNotNull();
        assertThat(((Map) tokenProperties.get(TokenProvider.GRANTS_TOKEN_KEY)).get(TokenProvider.AGREEMENT_GRANT_KEY)).isEqualTo(1234);
    }

    private RSAPublicKey rsaPublicKey() {
        try (final InputStream in = getClass().getResourceAsStream("/security/dbf-test-internal/public_key.der")) {
            return (RSAPublicKey) KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(IOUtils.toByteArray(in)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // Jetty
    //

    private AbstractHandler createJettyHandler() {
        return new AbstractHandler() {
            @Override
            public void handle(String target, Request baseRequest, HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
                final String authorization = request.getHeader(ServiceClientFilter.AUTH_HEADER_NAME);
                final String clientContext = request.getHeader(ServiceClientFilter.CLIENT_CONTEXT_HEADER_NAME);
                final List<String> fields = new LinkedList<>();

                response.setContentType("application/json");

                if (authorization != null) {
                    fields.add(String.format("\""+AUTHORIZATION_TEST_KEY+"\":\"%s\"", authorization));
                }

                if (clientContext != null) {
                    fields.add("\""+CLIENT_CONTEXT_TEST_KEY+"\":" + clientContext);
                }

                response.getWriter().print("{" + Joiner.on(",").join(fields) + "}");

                baseRequest.setHandled(true);
            }
        };
    }

}
