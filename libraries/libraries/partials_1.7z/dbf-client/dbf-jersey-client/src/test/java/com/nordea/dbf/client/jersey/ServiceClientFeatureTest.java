package com.nordea.dbf.client.jersey;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;
import java.net.URI;
import java.net.URISyntaxException;

import javax.ws.rs.client.ClientRequestContext;

import org.junit.Test;

import com.nordea.dbf.client.jersey.ServiceClientFeature.Builder;

public class ServiceClientFeatureTest {

  ClientRequestContext requestContext = mock(ClientRequestContext.class);
  
  private ServiceClientSecurityConfig securityConfig = new ServiceClientSecurityConfig() {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Override
    public String privateKeyPath() {
      return "privateKeyPath";
    }

    @Override
    public String privateKeyIssuerName() {
      return null;
    }
  };

  @Test
  public void testShouldFailWhenNoSecurityConfig() {
    try {
      ServiceClientFeature.newBuilder().build();
      fail("Should fail!");
    } catch (Exception e) {
      assertThat(e.getMessage()).isEqualTo(
          "Private key path for DBF token signing is not specified in configuration. Make sure you have specified 'com.nordea.environmenttype' with value (LOCAL|LOCAL_MOCK|DEV|TEST|PROD).If running in TEST or PROD, also make sure you provide a configuration file and private key. See https://confluence.oneadr.net:8443/display/DBTA/Client+configuration.");
    }
  }

  @Test
  public void testShouldNotFailWhenSecurityConfigGiven() {
    try {
      ServiceClientFeature.newBuilder().securityConfig(securityConfig).build();
    } catch (Exception e) {
      fail("Should not fail!");
    }
  }

  @Test
  public void testBaseUrl() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, URISyntaxException {
    when(requestContext.getUri()).thenReturn(URI.create("http://testuri/call"));
    ServiceClientFeature client = ServiceClientFeature.newBuilder().securityConfig(securityConfig).serviceBaseUrl("http://testuri").build();
    
    Field clientTargetField = ServiceClientFeature.class.getDeclaredField("serviceClientTarget");
    clientTargetField.setAccessible(true);
    
    ServiceClientTarget clientTarget = (ServiceClientTarget)clientTargetField.get(client);
    assertThat(clientTarget.test(requestContext)).isEqualTo(true);
  }

  @Test
  public void testBaseUrlPattern() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, URISyntaxException {
    when(requestContext.getUri()).thenReturn(URI.create("http://testuri/call"));
    ServiceClientFeature client = ServiceClientFeature.newBuilder().securityConfig(securityConfig).serviceUrlPattern("http://testuri/*").build();
    
    Field clientTargetField = ServiceClientFeature.class.getDeclaredField("serviceClientTarget");
    clientTargetField.setAccessible(true);
    
    ServiceClientTarget clientTarget = (ServiceClientTarget)clientTargetField.get(client);
    assertThat(clientTarget.test(requestContext)).isEqualTo(true);
  }

  @Test
  public void testMultiplseBaseUrl() throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException, URISyntaxException {
    ServiceClientFeature client = ServiceClientFeature.newBuilder().securityConfig(securityConfig).multipleServiceBaseUrls("http://testuri", "http://test2.testuri", "http://test3.testuri").build();
    
    Field clientTargetField = ServiceClientFeature.class.getDeclaredField("serviceClientTarget");
    clientTargetField.setAccessible(true);
    
    ServiceClientTarget clientTarget = (ServiceClientTarget)clientTargetField.get(client);
    when(requestContext.getUri()).thenReturn(URI.create("http://testuri/call"));
    assertThat(clientTarget.test(requestContext)).isEqualTo(true);
    when(requestContext.getUri()).thenReturn(URI.create("http://test2.testuri/call"));
    assertThat(clientTarget.test(requestContext)).isEqualTo(true);
    when(requestContext.getUri()).thenReturn(URI.create("http://test3.testuri/call"));
    assertThat(clientTarget.test(requestContext)).isEqualTo(true);
    when(requestContext.getUri()).thenReturn(URI.create("http://test/call"));
    assertThat(clientTarget.test(requestContext)).isEqualTo(false);
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOnlyOneAllowedOneBaseUrlAndPattern() {
    ServiceClientFeature.newBuilder().securityConfig(securityConfig).serviceBaseUrl("url").serviceUrlPattern("pattern");
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOnlyOneAllowedOneAndMultipleBaseUrl() {
    ServiceClientFeature.newBuilder().securityConfig(securityConfig).serviceBaseUrl("url").multipleServiceBaseUrls("uri1", "uri2");
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOnlyOneAllowedMultipleBaseUrlAndPattern() {
    ServiceClientFeature.newBuilder().securityConfig(securityConfig).multipleServiceBaseUrls("url1", "url2").serviceUrlPattern("pattern");
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOnlyOneAllowedMultipleAndOneBaseUrl() {
    ServiceClientFeature.newBuilder().securityConfig(securityConfig).multipleServiceBaseUrls("url1", "url2").serviceBaseUrl("url");
  }
  
  @Test (expected = IllegalArgumentException.class)
  public void testOnlyOneAllowedUrlPatternAndBaseUrl() {
    ServiceClientFeature.newBuilder().securityConfig(securityConfig).serviceUrlPattern("pattern").serviceBaseUrl("url");
  }

  @Test (expected = IllegalArgumentException.class)
  public void testOnlyOneAllowedUrlPatternAndMultipleBaseUrl() {
    ServiceClientFeature.newBuilder().securityConfig(securityConfig).serviceUrlPattern("pattern").multipleServiceBaseUrls("url1", "url2");
  }

}
