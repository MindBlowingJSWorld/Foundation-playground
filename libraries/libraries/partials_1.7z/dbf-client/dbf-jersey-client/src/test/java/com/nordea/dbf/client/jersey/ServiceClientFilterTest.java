package com.nordea.dbf.client.jersey;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.net.HttpHeaders;
import com.nordea.dbf.client.RequestConfiguration;
import com.nordea.dbf.client.RequestConfigurer;
import com.nordea.dbf.client.security.TokenProvider;
import com.nordea.dbf.model.http.DBFClientServiceRequestContext;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.core.MultivaluedMap;
import java.io.IOException;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@SuppressWarnings("unchecked")
public class ServiceClientFilterTest {

    private final RequestConfigurer requestConfigurer = mock(RequestConfigurer.class);
    private final TokenProvider tokenProvider = mock(TokenProvider.class);
    private final ServiceClientTarget serviceClientTarget = mock(ServiceClientTarget.class);
    private final HttpServletRequestProvider requestProvider = mock(HttpServletRequestProvider.class);
    private final ServiceClientFilter filter = new ServiceClientFilter(requestConfigurer, tokenProvider, serviceClientTarget, requestProvider);
    private final ClientRequestContext clientRequestContext = mock(ClientRequestContext.class);
    private final MultivaluedMap<String, Object> headers = mock(MultivaluedMap.class);
    private final HttpServletRequest servletRequest = mock(HttpServletRequest.class);

    @Before
    public void setup() {
        when(requestProvider.get()).thenReturn(servletRequest);
        when(clientRequestContext.getHeaders()).thenReturn(headers);
        when(servletRequest.getRemoteAddr()).thenReturn("127.0.0.1");
    }

    @Test
    public void clientServiceRequestContextShouldBeSetInRequest() throws IOException {
        // given
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(minimalRequestConfiguration());

        // when
        filter.filter(clientRequestContext);

        // then
        verify(headers).add(eq(ServiceClientFilter.CLIENT_CONTEXT_HEADER_NAME),
            argThat(new IsValidClientContextBuilder().build()));
    }

    @Test
    public void applicationIdShouldBeSetInClientServiceRequestContext() throws IOException {
        // given
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(builderWithMinimalRequestConfiguration().applicationId("APP1").build());

        // when
        filter.filter(clientRequestContext);

        // then
        verify(headers).add(eq(ServiceClientFilter.CLIENT_CONTEXT_HEADER_NAME),
            argThat(new IsValidClientContextBuilder().applicationId("APP1").build()));
    }

    @Test
    public void sessionIdShouldBeSetInClientServiceRequestContext() throws IOException {
        // given
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(builderWithMinimalRequestConfiguration().sessionId("SES1").build());

        // when
        filter.filter(clientRequestContext);

        // then
        verify(headers).add(eq(ServiceClientFilter.CLIENT_CONTEXT_HEADER_NAME),
            argThat(new IsValidClientContextBuilder().sessionId("SES1").build()));
    }

    @Test
    public void requestIdShouldBeSetInClientServiceRequestContext() throws IOException {
        // given
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(builderWithMinimalRequestConfiguration().requestId("REQ1").build());

        // when
        filter.filter(clientRequestContext);

        // then
        verify(headers).add(eq(ServiceClientFilter.CLIENT_CONTEXT_HEADER_NAME),
            argThat(new IsValidClientContextBuilder().requestId("REQ1").build()));
    }

    @Test
    public void channelIdShouldBeSetInClientServiceRequestContext() throws IOException {
        // given
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(builderWithMinimalRequestConfiguration().channelId("NETBANK").build());

        // when
        filter.filter(clientRequestContext);

        // then
        verify(headers).add(eq(ServiceClientFilter.CLIENT_CONTEXT_HEADER_NAME),
            argThat(new IsValidClientContextBuilder().channelId("NETBANK").build()));
    }

    @Test
    public void clientRequestDateShouldBeCreatedAndSetInClientServiceRequestContext() throws Exception {
        // given
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(builderWithMinimalRequestConfiguration().build());

        // when
        filter.filter(clientRequestContext);

        // then
        verify(headers).add(eq(ServiceClientFilter.CLIENT_CONTEXT_HEADER_NAME),
            argThat(new IsValidClientContextBuilder().timeStampSet(true).build()));
    }

    @Test
    public void clientRequestDateShouldBePropagatedToClientServiceRequestContextIfSetInDateHeader() throws Exception {
        // given
        long bogusTimeStamp = new DateTime(2013, 2,1 ,14,35).getMillis();
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(builderWithMinimalRequestConfiguration().build());
        when(servletRequest.getDateHeader(HttpHeaders.DATE)).thenReturn(bogusTimeStamp);

        // when
        filter.filter(clientRequestContext);

        // then
        verify(headers).add(eq(ServiceClientFilter.CLIENT_CONTEXT_HEADER_NAME),
            argThat(new IsValidClientContextBuilder().timeStamp(bogusTimeStamp).build()));
    }

    @Test
    public void remoteAddressShouldBeSetInRequest() throws IOException {
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(minimalRequestConfiguration());
        when(servletRequest.getRemoteAddr()).thenReturn("127.0.0.1");

        filter.filter(clientRequestContext);

        verify(headers).add("X-Forwarded-For", "127.0.0.1");
    }

    @Test
    public void remoteAddressShouldPrependForwardedHeader() throws IOException {
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(minimalRequestConfiguration());
        when(servletRequest.getRemoteAddr()).thenReturn("127.0.0.1");
        when(servletRequest.getHeader(eq("X-Forwarded-For"))).thenReturn("10.0.0.1");

        filter.filter(clientRequestContext);

        verify(headers).add("X-Forwarded-For", "10.0.0.1, 127.0.0.1");
    }

    @Test
    public void existingRequestPathShouldBePrependedToForwardedHeader() throws Exception {
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(minimalRequestConfiguration());
        when(servletRequest.getRemoteAddr()).thenReturn("127.0.0.1");
        when(servletRequest.getHeader(eq("X-Forwarded-For"))).thenReturn("10.0.0.1, 10.0.0.2");

        filter.filter(clientRequestContext);

        verify(headers).add("X-Forwarded-For", "10.0.0.1, 10.0.0.2, 127.0.0.1");
    }



    @Test
    public void languageShouldPrimarilyBeForwardedFromClientRequestContext() throws Exception {
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(minimalRequestConfiguration());
        when(clientRequestContext.getHeaderString(HttpHeaders.ACCEPT_LANGUAGE)).thenReturn("sv-SE");
        when(servletRequest.getHeader(eq(HttpHeaders.ACCEPT_LANGUAGE))).thenReturn("en-GB");

        filter.filter(clientRequestContext);

        verify(headers, never()).add(eq(HttpHeaders.ACCEPT_LANGUAGE), eq("en-GB"));
    }


    @Test
    public void languageShouldBeForwardedFromHTTPHeaderIfNotSetInClientRequestContext() throws Exception {
        when(serviceClientTarget.test(clientRequestContext)).thenReturn(true);
        when(requestConfigurer.getRequestConfiguration()).thenReturn(minimalRequestConfiguration());
        when(servletRequest.getHeader(eq(HttpHeaders.ACCEPT_LANGUAGE))).thenReturn("sv-SE");

        filter.filter(clientRequestContext);

        verify(headers).add(eq(HttpHeaders.ACCEPT_LANGUAGE), eq("sv-SE"));
    }

    protected static DBFClientServiceRequestContext deserializeClientContext(String json) {
        if (json == null) {
            return null;
        }

        try {
            return createForgivingFieldBasedMapper().readValue(json, DBFClientServiceRequestContext.class);
        } catch (IOException e) {
            throw new IllegalArgumentException("Failed to deserialize client context: " + json, e);
        }
    }

    public static ObjectMapper createForgivingFieldBasedMapper(){
        ObjectMapper jackson = new ObjectMapper();
        jackson.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        return jackson;
    }


    private class IsValidClientContext extends ArgumentMatcher {

        private final String applicationId;

        private String sessionId;

        private String requestId;

        private String country;

        private String channelId;

        private long timeStamp = -1L;

        private boolean timeStampSet = false;

        public IsValidClientContext (String applicationId, String sessionId, String requestId, String country, String channelId, long timeStamp, boolean timeStampSet){
            this.applicationId = applicationId;
            this.sessionId = sessionId;
            this.requestId = requestId;
            this.country = country;
            this.channelId = channelId;
            this.timeStamp = timeStamp;
            this.timeStampSet = timeStampSet;
        }

        public boolean matches(Object headerValue) {
            DBFClientServiceRequestContext clientContext = deserializeClientContext((String)headerValue);
            if(clientContext==null){
              return false;
            }
            if(StringUtils.isNotEmpty(applicationId) && ! applicationId.equals(clientContext.getApplicationId())){
              return false;
            }
            if(StringUtils.isNotEmpty(requestId) && ! requestId.equals(clientContext.getRequestId())){
              return false;
            }
            if(StringUtils.isNotEmpty(country) && ! country.equals(clientContext.getCountry())){
              return false;
            }
            if(StringUtils.isNotEmpty(channelId) && ! channelId.equals(clientContext.getChannelId())){
              return false;
            }
            if(StringUtils.isNotEmpty(sessionId) && !sessionId.equals(clientContext.getSessionId())){
              return false;
            }
            if(timeStamp > 0 && timeStamp != clientContext.getTimeStamp()){
              return false;
            }
            if(timeStampSet && clientContext.getTimeStamp()<=0){
              return false;
            }

            return true;
        }
    }

    private class IsValidClientContextBuilder{
        private String applicationId;

        private String sessionId;

        private String requestId;

        private String country;

        private String channelId;

        private long timeStamp = -1L;

        private boolean timeStampSet = false;

        public IsValidClientContextBuilder applicationId(String applicationId){
            this.applicationId = applicationId;
            return this;
        }

        public IsValidClientContextBuilder sessionId(String sessionId){
            this.sessionId = sessionId;
            return this;
        }

        public IsValidClientContextBuilder requestId(String requestId){
            this.requestId = requestId;
            return this;
        }

        public IsValidClientContextBuilder country(String country){
            this.country = country;
            return this;
        }

        public IsValidClientContextBuilder timeStamp(long timeStamp){
            this.timeStamp = timeStamp;
            return this;
        }

      public IsValidClientContextBuilder timeStampSet(boolean timeStampSet){
        this.timeStampSet = timeStampSet;
        return this;
      }

        public IsValidClientContextBuilder channelId(String channelId){
            this.channelId = channelId;
            return this;
        }

        public IsValidClientContext build(){
            return new IsValidClientContext(applicationId,  sessionId,  requestId,  country,  channelId,  timeStamp, timeStampSet);
        }
    }

    private RequestConfiguration minimalRequestConfiguration() {
        return builderWithMinimalRequestConfiguration().build();
    }

    private RequestConfiguration.Builder builderWithMinimalRequestConfiguration() {
        return RequestConfiguration.newBuilder()
            .applicationId("anApplication")
            .userId("myUser")
            .sessionId("mySession")
            .authenticationMethod("BANKID")
            .authenticationLevel("HIGH")
            .country("SE")
            .channelId("NETBANK");
    }
}
