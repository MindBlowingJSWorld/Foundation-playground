package com.nordea.dbf.client.jersey;

import org.junit.Test;

import javax.ws.rs.client.ClientRequestContext;
import java.net.URI;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class URLPatternServiceClientTargetTest {

    @Test
    public void pathPatternCannotBeNullOrEmpty() {
        try {
            new URLPatternServiceClientTarget(null);
            fail("null pathPattern should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            new URLPatternServiceClientTarget("");
            fail("empty pathPattern should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void urlPatternForFullUrlCanBeUsed() {
        final URLPatternServiceClientTarget target = new URLPatternServiceClientTarget("http://localhost:1234/test/*");
        final ClientRequestContext requestContext = mock(ClientRequestContext.class);

        when(requestContext.getUri()).thenReturn(URI.create("http://localhost:1234/test/foo"));

        assertThat(target.test(requestContext)).isTrue();
    }

    @Test
    public void differentUrlShouldNotMatch() {
        final URLPatternServiceClientTarget target = new URLPatternServiceClientTarget("http://localhost:1234/test/*");
        final ClientRequestContext requestContext = mock(ClientRequestContext.class);

        when(requestContext.getUri()).thenReturn(URI.create("http://localhost:1234/foo"));

        assertThat(target.test(requestContext)).isFalse();
    }

}