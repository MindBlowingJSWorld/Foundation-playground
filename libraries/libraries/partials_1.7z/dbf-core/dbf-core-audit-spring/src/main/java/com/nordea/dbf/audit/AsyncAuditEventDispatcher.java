package com.nordea.dbf.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Dispatches audit events to another dispatcher in a separate thread.
 */
public class AsyncAuditEventDispatcher implements AuditEventDispatcher, AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(AsyncAuditEventDispatcher.class);

    private final AuditEventFactory factory;
    private final BlockingQueue<AuditEvent> events;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public AsyncAuditEventDispatcher(AuditEventDispatcher dispatcher, int queueDepth) {
        this.events = new LinkedBlockingQueue<>(queueDepth);
        this.factory = dispatcher.getAuditLogEventFactory();
        this.executor.submit(worker(dispatcher, events));
    }

    @Override
    public void close() {
        executor.shutdown();
    }

    @Override
    public AuditEventFactory getAuditLogEventFactory() {
        return factory;
    }

    @Override
    public void audit(AuditEvent event) {
        if(!events.offer(event)) {
            throw new AuditFailureException(String.format("Async audit log queue is full (size=%d)", events.size()));
        }
    }

    private static Runnable worker(AuditEventDispatcher dispatcher, BlockingQueue<AuditEvent> events) {
        return () -> {
            while(true) {
                try {
                    dispatcher.audit(events.take());
                } catch (InterruptedException interrupted) {
                    LOG.info("AsyncAuditEventDispatcher is closing");
                    break;
                } catch (Throwable throwable) {
                    LOG.error("Async dispatch of audit event failed", throwable);
                }
            }
        };
    }
}
