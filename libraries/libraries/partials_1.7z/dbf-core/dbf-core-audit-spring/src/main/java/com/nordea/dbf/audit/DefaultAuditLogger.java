package com.nordea.dbf.audit;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.InternalServerErrorException;
import com.nordea.dbf.metadata.ApplicationMetaData;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class DefaultAuditLogger implements AuditLogger {

    @Autowired
    private ApplicationMetaData applicationMetaData;

    @Autowired
    private AuditEventDispatcher auditEventDispatcher;

    @Autowired
    private Environment environment;

    private InetAddress hostAddress;

    @PostConstruct
    public void setup() throws UnknownHostException {
        this.hostAddress = InetAddress.getLocalHost();
    }

    @Override
    public void log(AuditCategory category, Object message) {
        auditEventDispatcher.audit(contextEventBuilder()
                .severity(category.getSeverity())
                .auditCategory(category)
                .message(message)
                .build());
    }

    @Override
    public void log(AuditCategory category, Object message, Object result) {
        auditEventDispatcher.audit(contextEventBuilder()
                .severity(category.getSeverity())
                .auditCategory(category)
                .message(message)
                .result(result)
                .build());
    }

    @Override
    public void log(AuditCategory category, Severity severity, Object message, Object result) {
        auditEventDispatcher.audit(contextEventBuilder()
                .severity(severity)
                .auditCategory(category)
                .message(message)
                .result(result)
                .build());
    }

    protected String getHostAddress() {
        return hostAddress.toString();
    }

    protected AuditEventBuilder createAuditEventBuilder() {
        return auditEventDispatcher.getAuditLogEventFactory().createEventBuilder();
    }

    protected String getServiceId() {
        return applicationMetaData.getArtifactId() + "-" + applicationMetaData.getVersion();
    }

    protected AuditEventBuilder contextEventBuilder() {
        final ServiceRequestContext serviceRequestContext = ServiceRequestContextHolder.get().orElseThrow(
                () -> new InternalServerErrorException(new Error()
                        .setError(ErrorResponses.Types.INTERNAL_SERVER_ERROR)
                        .setErrorDescription("Audit logging failed. Service request context expected but not available.")));

        final AuditEventBuilder eventBuilder = createAuditEventBuilder();

        eventBuilder.userId(serviceRequestContext.getUserId().orElse(null));
        eventBuilder.serviceId(getServiceId());
        eventBuilder.channel(serviceRequestContext.getChannelId().orElse(null));
        eventBuilder.applicationId(serviceRequestContext.getApplicationId().orElse(null));
        eventBuilder.requestDomain(serviceRequestContext.getCountry().orElse(null));
        eventBuilder.requestId(serviceRequestContext.getRequestId().get());
        eventBuilder.timestamp(new DateTime(serviceRequestContext.getTimeStamp()));
        eventBuilder.serverName(getHostAddress());
        eventBuilder.sessionId(serviceRequestContext.getSessionId().orElse(null));
        StringBuilder clientView = new StringBuilder();
        clientView.append("[Agreement: ")
                .append(serviceRequestContext.getAgreementNumber().orElse(null))
                .append(", Authentication Method: ")
                .append(serviceRequestContext.getAuthenticationMethod().orElse("unknown"))
                .append("]");
        eventBuilder.clientView(clientView.toString());


        if (RequestContextHolder.getRequestAttributes() != null) {
            final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

            if (request != null) {
                eventBuilder.serviceEndPoint(request.getMethod() + " " + request.getRequestURI());
                eventBuilder.userLocation(request.getRemoteAddr());
            }
        }

        return eventBuilder;
    }

}

