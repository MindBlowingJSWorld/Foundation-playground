package com.nordea.dbf.audit.aop;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.audit.AuditBusinessObject;
import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.AuditLogger;
import com.nordea.dbf.audit.Severity;
import com.nordea.dbf.audit.annotation.Audit;
import com.nordea.dbf.audit.annotation.AuditHideValue;
import com.nordea.dbf.audit.config.AuditConfiguration;
import com.nordea.dbf.audit.util.IgnorableAuditContentAssigner;
import com.nordea.dbf.concurrent.Handover;
import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.util.StringTemplate;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.async.DeferredResult;

import javax.annotation.PostConstruct;
import java.lang.annotation.Annotation;
import java.lang.reflect.Parameter;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;

@Aspect
public class AuditAspect {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditAspect.class);

    private final ConcurrentHashMap<String, StringTemplate> descriptionTemplates = new ConcurrentHashMap<>();


    @Autowired
    AuditConfiguration.SerializingStyle serializingStyle;

    @Autowired
    private AuditLogger auditLogger;

    @Autowired(required = false)
    private ObjectMapper objectMapper;

    @Autowired(required = false)
    private ThreadContext threadContext = ThreadContext.DEFAULT;

    @PostConstruct
    public void prepare() {
        if (objectMapper == null) {
            this.objectMapper = new ObjectMapper();
        }
    }

    private AuditBusinessObject extractBusinessObject(ProceedingJoinPoint pjp) {
        Object[] arguments = pjp.getArgs();
        AuditBusinessObject auditBusinessObject = new AuditBusinessObject();
        Annotation[][] annotations = ((MethodSignature) pjp.getSignature()).getMethod().getParameterAnnotations();
        Parameter[] parameters =((MethodSignature) pjp.getSignature()).getMethod().getParameters();
        for (int i = 0; i < annotations.length; i++) {
            IgnorableAuditContentAssigner ignorableAuditContent = new IgnorableAuditContentAssigner(auditBusinessObject);
            for (Annotation annotation : annotations[i]) {
                Object argument = arguments[i];
                if (annotation.annotationType() == PathVariable.class) {
                    ignorableAuditContent.auditableRequestParameter(resolveParameterName(((PathVariable) annotation).value(), parameters[i]), String.valueOf(argument));
                } else if (annotation.annotationType() == RequestParam.class) {
                    ignorableAuditContent.auditableRequestParameter(resolveParameterName(((RequestParam) annotation).value(), parameters[i]), String.valueOf(argument));
                } else if (annotation.annotationType() == RequestBody.class) {
                    ignorableAuditContent.auditableRequestBody(argument);
                } else if (annotation.annotationType() == RequestHeader.class) {
                    ignorableAuditContent.auditableRequestHeader(resolveParameterName(((RequestHeader) annotation).value(), parameters[i]), String.valueOf(argument));
                } else if (annotation.annotationType() == AuditHideValue.class) {
                    ignorableAuditContent.hideContent();
                }
            }
            ignorableAuditContent.apply();
        }

        return auditBusinessObject;
    }

    private Object audit(final AuditCategory auditCategory, final ProceedingJoinPoint pjp) throws Throwable {
        Object result;
        StringBuilder responseMessage = new StringBuilder().append("HTTP Status Code: ");

        AuditBusinessObject auditBusinessObject = extractBusinessObject(pjp);

        try {
            result = pjp.proceed();
        } catch (Throwable throwable) {
            auditLogException(auditCategory, auditBusinessObject, throwable);
            throw throwable;
        }

        if (result instanceof ResponseEntity) {
            final ResponseEntity responseEntity = (ResponseEntity) result;

            auditLogResult(auditCategory, auditBusinessObject, responseMessage.append(responseEntity.getStatusCode().value()).toString());
        } else if (result instanceof DeferredResult) {
            final DeferredResult asyncResult = (DeferredResult) result;
            final Handover handover = threadContext.createHandover();

            asyncResult.onCompletion(() -> handover.in(() -> {
                if (asyncResult.getResult() instanceof Throwable) {
                    auditLogException(auditCategory, auditBusinessObject, (Throwable) asyncResult.getResult());
                } else if (asyncResult.getResult() instanceof ResponseEntity) {
                    ResponseEntity responseEntity = (ResponseEntity) asyncResult.getResult();
                    auditLogResult(auditCategory, auditBusinessObject, responseMessage.append(responseEntity.getStatusCode().value()).toString());
                } else {
                    auditLogResult(auditCategory, auditBusinessObject, responseMessage.append(HttpStatus.OK.value()).toString());
                }
            }));

            asyncResult.onTimeout(() -> handover.in(() -> auditLogException(auditCategory, auditBusinessObject, new TimeoutException())));
        } else {
            auditLogResult(auditCategory, auditBusinessObject, responseMessage.append(HttpStatus.OK.value()).toString());
        }

        return result;
    }

    @Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
    private void controllers() {
    }

    @Pointcut("execution(public * *(..))")
    private void publicMethod() {
    }

    @Pointcut("@annotation(audit)")
    private void auditAnnotated(Audit audit) {}

    @Around("controllers() && publicMethod() && !auditAnnotated(*)")
    public Object trackAudit(final ProceedingJoinPoint pjp) throws Throwable {
        return audit(AuditCategory.TRACK, pjp);
    }

    @Around("auditAnnotated(audit)")
    public Object audit(final ProceedingJoinPoint pjp, final Audit audit) throws Throwable {
        return audit(audit.category(), pjp);
    }

    private void auditLogException(AuditCategory auditCategory, AuditBusinessObject request, Throwable throwable) {
        String error = throwable.getClass().getName() + "(" + throwable.getMessage() + ")";
        try {
            auditLogger.log(auditCategory, Severity.ERROR, request, error);
        } catch (Exception e) {
            LOGGER.error("Failed to audit log application error: " + request + " - " + error + ".", e);
        }
    }

    private void auditLogResult(AuditCategory auditCategory, AuditBusinessObject request, Object result) {
        try {
            auditLogger.log(auditCategory, request, result);
        } catch (Exception e) {
            LOGGER.error("Failed to audit log event (this should be backed up)", e);
        }
    }

    private Function<String, String> argumentResolver(final ProceedingJoinPoint pjp) {
        return input -> {
            final Object value;

            try {
                value = pjp.getArgs()[Integer.parseInt(input)];
            } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                return "{" + input + "}";
            }

            try {
                return serializeDataObject(value);
            } catch (JsonProcessingException e) {
                return String.valueOf(value);
            }
        };
    }

    private String serializeDataObject(Object value) throws JsonProcessingException {
        if (serializingStyle == AuditConfiguration.SerializingStyle.TOSTRING) {
            return String.valueOf(value);
        } else {
            return objectMapper.writeValueAsString(value);
        }
    }

    private static String resolveParameterName(String annotatedName, Parameter parameter){
        //Annotation may not have parameter name defined and in that case use the argument name to have at least indexed arg names
        return StringUtils.isEmpty(annotatedName) ? parameter.getName() : annotatedName;
    }

    private static final class AuditWithStatus {

        private final int status;

        private final Object body;

        public AuditWithStatus(Object body, int status) {
            this.body = body;
            this.status = status;
        }

        public int getStatus() {
            return status;
        }

        public Object getBody() {
            return body;
        }

        public String toString() {
            return new StringBuilder().append("HTTP ").append(status)
                    .append(" with ").append(body).toString();
        }

        public String getMessage() {
            return new StringBuilder().append("HTTP Status Code: ").append(status).toString();
        }
    }

}
