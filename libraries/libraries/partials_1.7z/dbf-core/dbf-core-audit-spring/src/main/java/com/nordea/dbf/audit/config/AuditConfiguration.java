package com.nordea.dbf.audit.config;

import com.nordea.dbf.audit.AuditEventDispatcher;
import com.nordea.dbf.audit.AuditEventMarshaller;
import com.nordea.dbf.audit.AuditLogger;
import com.nordea.dbf.audit.DefaultAuditLogger;
import com.nordea.dbf.audit.aop.AuditAspect;
import com.nordea.dbf.audit.jaxb.JAXBAuditEventMarshaller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;

import javax.xml.bind.JAXBException;
import java.util.Locale;

@Configuration
@EnableAspectJAutoProxy
public class AuditConfiguration {
    public enum SerializingStyle {
        OBJECTMAPPER,
        TOSTRING;
    }

    @Bean
    public SerializingStyle serializingStyle(@Value("${dbf.audit.log.serializer:objectmapper}") String style) {
        return SerializingStyle.valueOf(style.toUpperCase(Locale.ENGLISH));
    }

    @Autowired
    private Environment environment;

    @Bean
    public AuditAspect auditAspect() {
        return new AuditAspect();
    }

    @Bean
    public AuditEventDispatcherFactory auditEventDispatcherFactory() {
        return new AuditEventDispatcherFactory();
    }

    @Bean
    public AuditEventDispatcher auditEventDispatcher() {
        return auditEventDispatcherFactory().createAuditEventDispatcher();
    }

    @Bean
    public AuditLogger auditLogger() {
        return new DefaultAuditLogger();
    }

    @Bean
    public AuditEventMarshaller auditEventMarshaller() throws JAXBException {
        return new JAXBAuditEventMarshaller();
    }

}
