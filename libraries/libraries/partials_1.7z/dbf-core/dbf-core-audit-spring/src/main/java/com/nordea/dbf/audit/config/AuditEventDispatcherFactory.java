package com.nordea.dbf.audit.config;

import com.nordea.dbf.audit.AsyncAuditEventDispatcher;
import com.nordea.dbf.audit.AuditEventDispatcher;
import com.nordea.dbf.audit.AuditEventMarshaller;
import com.nordea.dbf.audit.logi.LogIAuditEventDispatcher;
import com.nordea.dbf.audit.slf4j.Slf4JAuditEventDispatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AuditEventDispatcherFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuditEventDispatcherFactory.class);

    public static final Pattern LOGI_OVER_SLF4J = Pattern.compile("slf4j:(?<logName>.*)");

    public static final Pattern LOGI_OVER_LOCAL_JMS = Pattern.compile("local(:(?<queueName>.*))?");

    public static final Pattern LOGI_OVER_REMOTE_JMS = Pattern.compile("t3://(?<userName>[^:]+):(?<password>[^:]+)@(?<hosts>[^/]+)(/(?<queueName>.*))?");

    public static final String DEFAULT_QUEUE_NAME = "jms/LogIAuditLocalQueue";

    public static final String AUDIT_LOG_PROPERTY_NAME = "dbf.audit.log";

    public static final String AUDIT_LOG_ASYNC_QUEUE_MAX = "dbf.audit.log.async.max";

    public static final String DEFAULT_AUDIT_CONFIGURATION = "slf4j:audit";

    @Autowired
    private Environment environment;

    @Autowired
    private AuditEventMarshaller auditEventMarshaller;

    public AuditEventDispatcher createAuditEventDispatcher() {
        final String logDefinition = environment.getProperty(AUDIT_LOG_PROPERTY_NAME, DEFAULT_AUDIT_CONFIGURATION);

        final AuditEventDispatcher dispatcher = createLogIOverSlf4JLogger(logDefinition)
            .orElseGet(() -> createLogIOverLocalJMS(logDefinition).orElseGet(() -> createLogIOverRemoteJMS(logDefinition).orElse(null)));

        if (dispatcher == null) {
            throw new BeanCreationException("Invalid audit log configuration: " + logDefinition);
        }

        String asyncQueueDepth = environment.getProperty(AUDIT_LOG_ASYNC_QUEUE_MAX);
        return asyncQueueDepth == null ? dispatcher : new AsyncAuditEventDispatcher(dispatcher, Integer.parseInt(asyncQueueDepth));
    }

    protected Optional<AuditEventDispatcher> createLogIOverSlf4JLogger(String definition) {
        final Matcher matcher = LOGI_OVER_SLF4J.matcher(definition);

        if (!matcher.matches()) {
            return Optional.empty();
        }

        final String logName = matcher.group("logName");

        LOGGER.info("Creating SLF4J audit log dispatcher with category '{}'", logName);

        return Optional.<AuditEventDispatcher>of(new Slf4JAuditEventDispatcher(auditEventMarshaller, LoggerFactory.getLogger(logName)));
    }

    protected Optional<AuditEventDispatcher> createLogIOverLocalJMS(String definition) {
        final Matcher matcher = LOGI_OVER_LOCAL_JMS.matcher(definition);

        if (!matcher.matches()) {
            return Optional.empty();
        }

        final String queueName = matcher.group("queueName") != null ? matcher.group("queueName") : DEFAULT_QUEUE_NAME;

        LOGGER.info("Creating local JMS audit logger against JMS queue {}", queueName);

        return Optional.of(createDispatcherForLocalQueueName(queueName));
    }

    public Optional<AuditEventDispatcher> createLogIOverRemoteJMS(String definition) {
        final Matcher matcher = LOGI_OVER_REMOTE_JMS.matcher(definition);

        if (!matcher.matches()) {
            return Optional.empty();
        }

        final String userName = matcher.group("userName");
        final String password = matcher.group("password");
        final String url = "t3://" + matcher.group("hosts");
        final String queueName = matcher.group("queueName") != null ? matcher.group("queueName") : "jms/LogIAuditDistQueue";

        LOGGER.info("Creating remote JMS audit logger against destination {}/{}", url, queueName);

        return Optional.of(createDispatcherForRemoteQueueName(userName, password, url, queueName));
    }

    protected AuditEventDispatcher createDispatcherForLocalQueueName(String queueName) {
        return new LogIAuditEventDispatcher.Locator().marshaller(auditEventMarshaller)
                .queueName(queueName)
                .locate();
    }

    protected AuditEventDispatcher createDispatcherForRemoteQueueName(String userName, String password, String url, String queueName) {
        return new LogIAuditEventDispatcher.Connector().marshaller(auditEventMarshaller)
                .userName(userName)
                .password(password)
                .url(url)
                .queueName(queueName)
                .connect();
    }

}
