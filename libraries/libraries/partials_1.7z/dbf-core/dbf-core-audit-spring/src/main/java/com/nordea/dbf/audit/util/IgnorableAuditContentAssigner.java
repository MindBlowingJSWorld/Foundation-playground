package com.nordea.dbf.audit.util;

import com.nordea.dbf.audit.AuditBusinessObject;

import java.util.function.BiFunction;

public class IgnorableAuditContentAssigner {

    private static final BiFunction<AuditBusinessObject, ParameterContent, AuditBusinessObject> ADD_REQUEST_PARAM_TO_BUSINESS_OBJECT = (auditBusinessObject, keyValue) -> auditBusinessObject.addRequestParameter(keyValue.getParameterName(), keyValue.getParameterValue());
    private static final BiFunction<AuditBusinessObject, ParameterContent, AuditBusinessObject> ADD_REQUEST_HEADER_TO_BUSINESS_OBJECT = (auditBusinessObject, keyValue) -> auditBusinessObject.addRequestHeader(keyValue.getParameterName(), keyValue.getParameterValue());
    private static final BiFunction<AuditBusinessObject, Object, AuditBusinessObject> ADD_REQUEST_BODY_TO_BUSINESS_OBJECT = AuditBusinessObject::setRequestBody;
    private static final BiFunction<AuditBusinessObject, ParameterContent, AuditBusinessObject> EMPTY_ADD_PARAM = (a, b) -> a;
    private static final BiFunction<AuditBusinessObject, Object, AuditBusinessObject> EMPTY_BODY = (a, b) -> a;

    private BiFunction<AuditBusinessObject, ParameterContent, AuditBusinessObject> addParamToBusinessObject = EMPTY_ADD_PARAM;
    private BiFunction<AuditBusinessObject, Object, AuditBusinessObject> addBodyToBusinessObject = EMPTY_BODY;
    private ParameterContent.ParameterContentBuilder parameterContentBuilder = ParameterContent.builder();
    private AuditBusinessObject auditBusinessObject;

    public IgnorableAuditContentAssigner(AuditBusinessObject auditBusinessObject) {
        this.auditBusinessObject = auditBusinessObject;
    }

    public void auditableRequestParameter(String parameterName, String value) {
        addParamToBusinessObject = ADD_REQUEST_PARAM_TO_BUSINESS_OBJECT;
        parameterContentBuilder.parameterName(parameterName).parameterValue(value);
    }

    public void auditableRequestHeader(String parameterName, String value) {
        addParamToBusinessObject = ADD_REQUEST_HEADER_TO_BUSINESS_OBJECT;
        parameterContentBuilder.parameterName(parameterName).parameterValue(value);
    }

    public void auditableRequestBody(Object body) {
        addBodyToBusinessObject = ADD_REQUEST_BODY_TO_BUSINESS_OBJECT;
        parameterContentBuilder.body(body);
    }

    public void hideContent() {
        parameterContentBuilder.hideContent();
    }

    public void apply() {
        ParameterContent parameterContent = parameterContentBuilder.build();
        addParamToBusinessObject.apply(auditBusinessObject, parameterContent);
        addBodyToBusinessObject.apply(auditBusinessObject, parameterContent.getBody());
    }
}
