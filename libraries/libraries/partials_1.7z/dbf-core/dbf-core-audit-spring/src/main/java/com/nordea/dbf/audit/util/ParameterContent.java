package com.nordea.dbf.audit.util;

import java.util.Arrays;
import java.util.List;

class ParameterContent {
    private String parameterName;
    private String parameterValue;
    private Object body;

    private ParameterContent() {
    }

    String getParameterName() {
        return parameterName;
    }

    String getParameterValue() {
        return parameterValue;
    }

    Object getBody() {
        return body;
    }

    private void setParameterName(String parameterName) {
        this.parameterName = parameterName;
    }

    private void setParameterValue(String parameterValue) {
        this.parameterValue = parameterValue;
    }

    private void setBody(Object body) {
        this.body = body;
    }

    static ParameterContentBuilder builder() {
        return new ParameterContentBuilder();
    }

    static final class ParameterContentBuilder {
        //hard coded list of confidental parameter / header keys that always should be hidden.
        private static final List<String> CONFIDENTAL_KEYS = Arrays.asList("Authorization", "access_token", "refresh_token","code");
        private boolean hideContent;
        private String parameterName;
        private String parameterValue;
        private Object body;

        private ParameterContentBuilder() {
        }

        ParameterContentBuilder parameterName(String parameterName) {
            this.parameterName = parameterName;
            return this;
        }

        ParameterContentBuilder parameterValue(String parameterValue) {
            this.parameterValue = parameterValue;
            return this;
        }

        ParameterContentBuilder body(Object body) {
            this.body = body;
            return this;
        }

        ParameterContentBuilder hideContent() {
            this.hideContent = true;
            return this;
        }

        ParameterContent build() {
            if( hideContent || CONFIDENTAL_KEYS.contains(parameterName)){
                this.parameterValue = "[hidden]";
                this.body = body != null ? "[body of type "+body.getClass().getSimpleName()+" hidden]" : null;
            }
            ParameterContent parameterContent = new ParameterContent();
            parameterContent.setParameterName(parameterName);
            parameterContent.setParameterValue(parameterValue);
            parameterContent.setBody(body);
            return parameterContent;
        }
    }
}
