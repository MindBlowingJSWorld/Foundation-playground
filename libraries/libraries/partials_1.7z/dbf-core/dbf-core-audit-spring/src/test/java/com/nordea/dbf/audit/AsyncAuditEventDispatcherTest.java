package com.nordea.dbf.audit;

import org.junit.Test;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

public class AsyncAuditEventDispatcherTest {

    @Test
    public void shouldPropagateEvents() {
        RecordingDispatcher target = new RecordingDispatcher();
        try(AsyncAuditEventDispatcher auditEventDispatcher = new AsyncAuditEventDispatcher(target, Integer.MAX_VALUE)) {
            IntStream.range(0, 255).forEach(i -> auditEventDispatcher.audit(new TestEvent()));
            IntStream.range(0, 255).forEach(i -> {
                try {
                    assertNotNull(target.received.poll(1, TimeUnit.SECONDS));
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }

    @Test(expected = AuditFailureException.class)
    public void shouldThrowAuditExceptionOnQueueFull() {
        try(AsyncAuditEventDispatcher auditEventDispatcher = new AsyncAuditEventDispatcher(new SlowDispatcher(), 10)) {
            IntStream.range(0, 100).forEach(i -> auditEventDispatcher.audit(new TestEvent()));
        }
    }

    @Test
    public void shouldGetEventFactoryFromNextDispatcher() {
        try(AsyncAuditEventDispatcher auditEventDispatcher = new AsyncAuditEventDispatcher(new RecordingDispatcher(), 1)) {
            assertNotNull(auditEventDispatcher.getAuditLogEventFactory());
        }
    }

    static class RecordingDispatcher implements AuditEventDispatcher {

        final BlockingQueue<AuditEvent> received = new LinkedBlockingQueue<>();

        @Override
        public void audit(AuditEvent event) {
            received.add(event);
        }
        @Override
        public AuditEventFactory getAuditLogEventFactory() {
            return mock(AuditEventFactory.class);
        }
    }

    static class SlowDispatcher extends RecordingDispatcher {
        @Override
        public void audit(AuditEvent event) {
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            super.audit(event);
        }
    }

    static class TestEvent implements AuditEvent { }
}
