package com.nordea.dbf.audit;

import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import com.nordea.dbf.metadata.ApplicationMetaData;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.util.Optional;

import static org.mockito.Mockito.*;

/**
 * Created by N453640 on 2015-06-11.
 */
@RunWith(MockitoJUnitRunner.class)
public class DefaultAuditLoggerTest {

  @Mock
  private ApplicationMetaData applicationMetaData;

  @Mock
  private AuditEventDispatcher auditEventDispatcher;

  @Mock
  private Environment environment;

  @Mock
  private InetAddress inetAddress;

  @InjectMocks
  private DefaultAuditLogger target;

  @Mock
  private ServiceRequestContext serviceRequestContext;

  @Mock
  private AuditEventBuilder auditEventBuilder;

  @Mock
  private HttpServletRequest request;

  @Mock
  private AuditEventFactory auditEventFactory;

  @Before
  public void setUp(){
    ServiceRequestContextHolder.clear();
    ServiceRequestContextHolder.bind(serviceRequestContext);

    // request attribute of ServletRequestAttributes is final so need to create it like this
    RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

    AuditEventFactory auditEventFactory = mock(AuditEventFactory.class);
    when(auditEventDispatcher.getAuditLogEventFactory()).thenReturn(auditEventFactory);
    when(auditEventFactory.createEventBuilder()).thenReturn(auditEventBuilder);

  }

  @Test
  public void contextEventBuilderShouldGetApplicationIdFromServiceContext(){
    // given
    when(serviceRequestContext.getApplicationId()).thenReturn(Optional.of("APPONE"));
    when(serviceRequestContext.getUserId()).thenReturn(Optional.of("USER123"));
    when(serviceRequestContext.getChannelId()).thenReturn(Optional.of("NETBANK"));
    when(serviceRequestContext.getCountry()).thenReturn(Optional.of("SE"));
    when(serviceRequestContext.getRequestId()).thenReturn(Optional.of("REQ123"));
    when(serviceRequestContext.getSessionId()).thenReturn(Optional.of("SES321"));
    when(serviceRequestContext.getAgreementNumber()).thenReturn(Optional.of(1111111L));
    when(serviceRequestContext.getAuthenticationMethod()).thenReturn(Optional.of("mock"));


    // when
    auditEventBuilder = target.contextEventBuilder();

    // then
    verify(auditEventBuilder).applicationId("APPONE");
  }

  @Test
  public void contextEventBuilderShouldSetNullToApplicationIdIfMissingInServiceContext(){
    // given
    when(serviceRequestContext.getApplicationId()).thenReturn(Optional.empty());
    when(serviceRequestContext.getUserId()).thenReturn(Optional.of("USER123"));
    when(serviceRequestContext.getChannelId()).thenReturn(Optional.of("NETBANK"));
    when(serviceRequestContext.getCountry()).thenReturn(Optional.of("SE"));
    when(serviceRequestContext.getRequestId()).thenReturn(Optional.of("REQ123"));
    when(serviceRequestContext.getSessionId()).thenReturn(Optional.of("SES321"));
    when(serviceRequestContext.getAgreementNumber()).thenReturn(Optional.of(1111111L));
    when(serviceRequestContext.getAuthenticationMethod()).thenReturn(Optional.of("mock"));

    // when
    auditEventBuilder = target.contextEventBuilder();

    // then
    verify(auditEventBuilder).applicationId(null);
  }


}
