package com.nordea.dbf.audit.aop;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.audit.AuditBusinessObject;
import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.AuditLogger;
import com.nordea.dbf.audit.Severity;
import com.nordea.dbf.audit.annotation.Audit;
import com.nordea.dbf.audit.config.AuditConfiguration;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.async.DeferredResult;
import org.springframework.web.context.request.async.DeferredResultProcessingInterceptor;

import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AuditAspectTest {

    @Mock
    private ProceedingJoinPoint pjp;

    @Mock
    private Audit audit;

    @Mock
    private AuditLogger auditLogger;

    @Spy
    private final ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    private final AuditAspect auditAspect = new AuditAspect();

    @Test
    public void synchronousSuccessfulRequestShouldBeAudited() throws Throwable {
        MethodSignature signature = mock(MethodSignature.class);
        Method method = String.class.getMethod("toString");

        when(pjp.getSignature()).thenReturn(signature);
        when(signature.getMethod()).thenReturn(method);
        when(audit.category()).thenReturn(AuditCategory.BOOKKEEP);
        when(audit.description()).thenReturn("ExecuteOn {0}");
        when(pjp.getArgs()).thenReturn(new Object[]{"testArg"});
        when(pjp.proceed()).thenReturn("testResult");

        assertThat(auditAspect.audit(pjp, audit)).isEqualTo("testResult");

        final InOrder inOrder = inOrder(auditLogger, pjp);

        inOrder.verify(pjp).proceed();
        inOrder.verify(auditLogger).log(eq(AuditCategory.BOOKKEEP), any(AuditBusinessObject.class), eq("HTTP Status Code: 200"));
    }

    @Test
    public void synchronousFailedRequestShouldBeAudited() throws Throwable {
        final RuntimeException exception = new RuntimeException("anException");
        MethodSignature signature = mock(MethodSignature.class);
        Method method = String.class.getMethod("toString");

        when(signature.getMethod()).thenReturn(method);
        when(audit.category()).thenReturn(AuditCategory.BOOKKEEP);
        when(pjp.getArgs()).thenReturn(new Object[]{"testArg"});
        when(pjp.proceed()).thenThrow(exception);
        when(pjp.getSignature()).thenReturn(signature);

        assertThatThrownBy(() -> auditAspect.audit(pjp, audit)).isEqualTo(exception);

        final InOrder inOrder = inOrder(pjp, auditLogger);

        inOrder.verify(pjp).proceed();
        inOrder.verify(auditLogger).log(eq(AuditCategory.BOOKKEEP), eq(Severity.ERROR), any(AuditBusinessObject.class), eq("java.lang.RuntimeException(anException)"));
    }

    @Test
    public void asynchronousSuccessfulRequestShouldBeAudited() throws Throwable {
        final DeferredResult<String> deferredResult = new DeferredResult<>();
        MethodSignature signature = mock(MethodSignature.class);
        Method method = String.class.getMethod("toString");

        when(pjp.getSignature()).thenReturn(signature);
        when(signature.getMethod()).thenReturn(method);
        when(audit.category()).thenReturn(AuditCategory.BOOKKEEP);
        when(audit.description()).thenReturn("ExecuteOn {0}");
        when(pjp.getArgs()).thenReturn(new Object[]{"testArg"});
        when(pjp.proceed()).thenReturn(deferredResult);

        assertThat(auditAspect.audit(pjp, audit)).isSameAs(deferredResult);

        verifyZeroInteractions(auditLogger);
        verify(pjp).proceed();

        deferredResult.setResult("testResult");
        notifyCompleted(deferredResult);

        verify(auditLogger).log(eq(AuditCategory.BOOKKEEP), any(AuditBusinessObject.class), eq("HTTP Status Code: 200"));
    }

    @Test
    public void asynchronousFailedRequestShouldGetAuditLogged() throws Throwable {
        final DeferredResult<String> deferredResult = new DeferredResult<>();
        MethodSignature signature = mock(MethodSignature.class);
        Method method = String.class.getMethod("toString");

        when(pjp.getSignature()).thenReturn(signature);
        when(signature.getMethod()).thenReturn(method);

        when(audit.category()).thenReturn(AuditCategory.BOOKKEEP);
        when(audit.description()).thenReturn("ExecuteOn {0}");
        when(pjp.getArgs()).thenReturn(new Object[]{"testArg"});
        when(pjp.proceed()).thenReturn(deferredResult);

        assertThat(auditAspect.audit(pjp, audit)).isSameAs(deferredResult);

        verifyZeroInteractions(auditLogger);
        verify(pjp).proceed();

        deferredResult.setErrorResult(new RuntimeException("anException"));

        notifyCompleted(deferredResult);

        verify(auditLogger).log(eq(AuditCategory.BOOKKEEP), eq(Severity.ERROR), any(AuditBusinessObject.class), eq("java.lang.RuntimeException(anException)"));
    }

    private void notifyCompleted(DeferredResult<String> deferredResult) throws Exception {
        final Method method = deferredResult.getClass().getDeclaredMethod("getInterceptor");
        method.setAccessible(true);
        DeferredResultProcessingInterceptor interceptor = (DeferredResultProcessingInterceptor) method.invoke(deferredResult);
        interceptor.afterCompletion(null, deferredResult);
    }
}
