package com.nordea.dbf.audit.config;

import com.nordea.dbf.audit.AsyncAuditEventDispatcher;
import com.nordea.dbf.audit.AuditEventDispatcher;
import com.nordea.dbf.audit.slf4j.Slf4JAuditEventDispatcher;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.env.Environment;

import java.lang.reflect.Field;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class AuditEventDispatcherFactoryTest {

    private final Environment environment = mock(Environment.class);

    private final AuditEventDispatcherFactory factory = mock(AuditEventDispatcherFactory.class);

    @Before
    public void setup() throws Exception {
        final Field field = AuditEventDispatcherFactory.class.getDeclaredField("environment");
        field.setAccessible(true);
        field.set(factory, environment);

        when(factory.createAuditEventDispatcher()).thenCallRealMethod();
        when(factory.createLogIOverLocalJMS(anyString())).thenCallRealMethod();
        when(factory.createLogIOverRemoteJMS(anyString())).thenCallRealMethod();
        when(factory.createLogIOverSlf4JLogger(anyString())).thenCallRealMethod();
    }

    @Test
    public void logIOverSlf4jShouldBeConfiguredByDefault() {
        when(environment.getProperty(eq("dbf.audit.log"), anyString())).thenAnswer(
            invocationOnMock -> (String) invocationOnMock.getArguments()[1]);

        final AuditEventDispatcher dispatcher = factory.createAuditEventDispatcher();

        assertThat(dispatcher).isInstanceOf(Slf4JAuditEventDispatcher.class);
    }

    @Test
    public void logIOverJmsThroughJndiLookupCanBeConfigured() {
        when(environment.getProperty(eq("dbf.audit.log"), anyString())).thenReturn("local:jms/LogIAuditLocalQueue");

        final AuditEventDispatcher expectedDispatcher = mock(AuditEventDispatcher.class);

        when(factory.createDispatcherForLocalQueueName(anyString())).thenReturn(expectedDispatcher);

        final AuditEventDispatcher dispatcher = factory.createAuditEventDispatcher();

        assertThat(dispatcher).isEqualTo(expectedDispatcher);
        verify(factory).createDispatcherForLocalQueueName(eq("jms/LogIAuditLocalQueue"));
    }

    @Test
    public void logIOverRemoteJmsCanBeConfigured() {
        when(environment.getProperty(eq("dbf.audit.log"), anyString())).thenReturn("t3://aUserName:aPassword@host1:7501,host2:7501/jms/LogIAuditDistQueue");

        final AuditEventDispatcher expectedDispatcher = mock(AuditEventDispatcher.class);

        when(factory.createDispatcherForRemoteQueueName(anyString(), anyString(), anyString(), anyString())).thenReturn(expectedDispatcher);

        final AuditEventDispatcher dispatcher = factory.createAuditEventDispatcher();

        assertThat(dispatcher).isEqualTo(expectedDispatcher);

        verify(factory).createDispatcherForRemoteQueueName(eq("aUserName"), eq("aPassword"), eq("t3://host1:7501,host2:7501"), eq("jms/LogIAuditDistQueue"));
    }

    @Test
    public void asyncCanBeConfigured() {
        when(environment.getProperty(eq("dbf.audit.log"), anyString()))
                .thenAnswer(invocationOnMock -> invocationOnMock.getArguments()[1]);

        when(environment.getProperty("dbf.audit.log.async.max"))
                .thenReturn("10");

        final AuditEventDispatcher dispatcher = factory.createAuditEventDispatcher();

        assertThat(dispatcher).isInstanceOf(AsyncAuditEventDispatcher.class);
        ((AsyncAuditEventDispatcher) dispatcher).close();
    }

}
