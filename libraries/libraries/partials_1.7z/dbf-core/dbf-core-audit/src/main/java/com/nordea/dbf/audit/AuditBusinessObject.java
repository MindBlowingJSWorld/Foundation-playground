package com.nordea.dbf.audit;

import com.nordea.dbf.audit.jaxb.RequestResponseAdapter;
import com.nordea.dbf.audit.logi.LogIContext;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.*;

/**
 * Created by k293170 on 2016-07-12.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso(LogIContext.class)
@XmlRootElement(name = "auditingLogRequestObjects", namespace = "http://auditing.logi.nordea.com/object/v1")
public class AuditBusinessObject {



    @XmlElement(name = "requestParameters")
    private Map<String, String> requestParameters;

    @XmlElement(name = "requestHeaders")
    private Map<String, String> requestHeaders;

    @XmlElement(name = "requestBody")
    @XmlJavaTypeAdapter(RequestResponseAdapter.class)
    private Object requestBody;

    public AuditBusinessObject() {
        requestParameters = new HashMap<>();
        requestHeaders = new HashMap<>();
    }

    public AuditBusinessObject addRequestParameter(String requestParameterKey, String requestParameterValue) {
        requestParameters.put(requestParameterKey, requestParameterValue);
        return this;
    }

    public AuditBusinessObject addRequestHeader(String requestHeaderKey, String requestHeaderValue) {
        requestHeaders.put(requestHeaderKey, requestHeaderValue);
        return this;
    }

    public AuditBusinessObject setRequestBody(Object requestBody) {
        this.requestBody = requestBody;
        return this;
    }

    public Map<String, String> getRequestParameters() {
        return requestParameters;
    }

    public Map<String, String> getRequestHeaders() {
        return requestHeaders;
    }

    public Object getRequestBody() {
        return requestBody;
    }
}
