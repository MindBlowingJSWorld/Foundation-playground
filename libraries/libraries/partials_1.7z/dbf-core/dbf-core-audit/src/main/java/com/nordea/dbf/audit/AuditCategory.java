package com.nordea.dbf.audit;

public enum AuditCategory {

    LEGAL(com.nordea.dbf.audit.Severity.INFO),
    VIEW(com.nordea.dbf.audit.Severity.INFO),
    TRACK(com.nordea.dbf.audit.Severity.INFO),
    SECURITY(com.nordea.dbf.audit.Severity.INFO),
    CONTRACT(com.nordea.dbf.audit.Severity.INFO),
    BOOKKEEP(com.nordea.dbf.audit.Severity.INFO);

    private com.nordea.dbf.audit.Severity severity;

    AuditCategory(com.nordea.dbf.audit.Severity severity) {
        this.severity = severity;
    }

    public Severity getSeverity() {
        return severity;
    }

    /**
     * The retention times are copied from
     * com.nordea.logi:nordea-logi-jaxb-impl:2.2.5:nordea-logi-jaxb-impl-2.2.5.jar#com.nordea.logi.AuditingLogMessage
     * @return
     */
    public int retentionYears(){
        switch(this){
            case TRACK:
                return 1;
            case VIEW:
            case SECURITY:
            case CONTRACT:
                return 4;
            default:
                return 11;
        }
    }
}
