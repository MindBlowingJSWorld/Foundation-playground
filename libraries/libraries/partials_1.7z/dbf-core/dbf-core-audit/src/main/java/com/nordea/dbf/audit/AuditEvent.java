package com.nordea.dbf.audit;

public interface AuditEvent {

}
