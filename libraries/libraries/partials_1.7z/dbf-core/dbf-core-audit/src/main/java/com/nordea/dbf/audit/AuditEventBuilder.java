package com.nordea.dbf.audit;

import org.joda.time.DateTime;

public interface AuditEventBuilder {

    AuditEventBuilder timestamp(DateTime timeStamp);

    AuditEventBuilder userId(String userId);

    AuditEventBuilder applicationId(String applicationId);

    AuditEventBuilder severity(Severity severity);

    AuditEventBuilder sessionId(String sessionId);

    AuditEventBuilder requestId(String requestId);

    AuditEventBuilder result(Object result);

    AuditEventBuilder channel(String channel);

    AuditEventBuilder serverName(String serverName);

    AuditEventBuilder userLocation(String userLocation);

    AuditEventBuilder serviceId(String serviceId);

    AuditEventBuilder serviceEndPoint(String serviceEndPoint);

    AuditEventBuilder requestDomain(String requestDomain);

    AuditEventBuilder technicalUserId(String technicalUserId);

    AuditEventBuilder clientAction(String clientAction);

    AuditEventBuilder clientType(String clientType);

    AuditEventBuilder clientView(String clientView);

    AuditEventBuilder message(String message);

    AuditEventBuilder message(Object messageObject);

    AuditEventBuilder auditCategory(AuditCategory auditCategory);

    AuditEvent build();

}
