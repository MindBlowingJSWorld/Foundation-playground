package com.nordea.dbf.audit;

public interface AuditEventDispatcher {

    void audit(AuditEvent event);

    AuditEventFactory getAuditLogEventFactory();

}
