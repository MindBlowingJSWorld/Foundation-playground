package com.nordea.dbf.audit;

public interface AuditEventFactory {

    AuditEventBuilder createEventBuilder();

}
