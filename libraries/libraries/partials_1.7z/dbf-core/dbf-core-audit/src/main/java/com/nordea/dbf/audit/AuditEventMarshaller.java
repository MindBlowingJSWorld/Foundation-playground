package com.nordea.dbf.audit;

import java.io.IOException;
import java.io.OutputStream;

public interface AuditEventMarshaller {

    void marshal(AuditEvent event, OutputStream out) throws IOException;

}
