package com.nordea.dbf.audit;

public class AuditFailureException extends RuntimeException {

    public AuditFailureException() {
    }

    public AuditFailureException(String message) {
        super(message);
    }

    public AuditFailureException(String message, Throwable cause) {
        super(message, cause);
    }

    public AuditFailureException(Throwable cause) {
        super(cause);
    }

    public AuditFailureException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
