package com.nordea.dbf.audit;

public interface AuditLogger {

    /**
     * Audit logs the provided message in the specified category. This will retrieve information available in the
     * current request context and must therefore always be called in the request thread.
     *
     * @param category The category of the audit event.
     * @param message The message that should be audit logged.
     */
    void log(AuditCategory category, Object message);

    void log(AuditCategory category, Object message, Object result);

    void log(AuditCategory category, Severity severity, Object message, Object result);

}
