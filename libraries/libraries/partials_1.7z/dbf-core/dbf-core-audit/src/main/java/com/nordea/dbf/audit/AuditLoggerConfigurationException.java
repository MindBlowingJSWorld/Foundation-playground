package com.nordea.dbf.audit;

public class AuditLoggerConfigurationException extends RuntimeException {

    public AuditLoggerConfigurationException() {
    }

    public AuditLoggerConfigurationException(String message) {
        super(message);
    }

    public AuditLoggerConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }

    public AuditLoggerConfigurationException(Throwable cause) {
        super(cause);
    }

    public AuditLoggerConfigurationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
