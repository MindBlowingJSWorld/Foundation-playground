package com.nordea.dbf.audit;

public enum Severity {

    INFO,
    ERROR

}
