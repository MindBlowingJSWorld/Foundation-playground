package com.nordea.dbf.audit.jaxb;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class DateTimeAdapter extends XmlAdapter<String, DateTime> {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormat.forPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");

    @Override
    public DateTime unmarshal(String v) throws Exception {
        if (StringUtils.isEmpty(v)) {
            return null;
        }

        return DATE_TIME_FORMATTER.parseDateTime(v).toDateTime(DateTimeZone.UTC);
    }

    @Override
    public String marshal(DateTime v) throws Exception {
        if (v == null) {
            return StringUtils.EMPTY;
        }

        return DATE_TIME_FORMATTER.print(v.toDateTime(DateTimeZone.UTC));
    }
}
