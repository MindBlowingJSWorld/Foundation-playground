package com.nordea.dbf.audit.jaxb;

import com.nordea.dbf.audit.AuditEvent;
import com.nordea.dbf.audit.AuditEventMarshaller;
import com.nordea.dbf.audit.logi.LogIAuditEvent;
import com.sun.xml.bind.marshaller.DataWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class JAXBAuditEventMarshaller implements AuditEventMarshaller {

    private final JAXBContext jaxbContext;

    public JAXBAuditEventMarshaller() throws JAXBException {
        this.jaxbContext = JAXBContext.newInstance(LogIAuditEvent.class);
    }

    @Override
    public void marshal(AuditEvent event, OutputStream out) throws IOException {
        try {
            Marshaller marshaller = jaxbContext.createMarshaller();
            DataWriter dataWriter = new DataWriter(new OutputStreamWriter(out), "UTF-8", (chars, i, i1, b, writer) -> writer.write(chars, i, i1));
            marshaller.marshal(event, dataWriter);
        } catch (JAXBException e) {
            throw new IOException("Failed to marshal audit log event", e);
        }
    }
}
