package com.nordea.dbf.audit.jaxb;

import org.apache.commons.lang.StringUtils;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public class LocalDateAdapter extends XmlAdapter<String, LocalDate> {

    private final DateTimeFormatter DATE_FORMAT = DateTimeFormat.forPattern("yyyy-MM-dd");

    @Override
    public LocalDate unmarshal(String v) throws Exception {
        if (StringUtils.isEmpty(v)) {
            return null;
        }

        return DATE_FORMAT.parseLocalDate(v);
    }

    @Override
    public String marshal(LocalDate v) throws Exception {
        if (v == null) {
            return StringUtils.EMPTY;
        }

        return DATE_FORMAT.print(v);
    }
}
