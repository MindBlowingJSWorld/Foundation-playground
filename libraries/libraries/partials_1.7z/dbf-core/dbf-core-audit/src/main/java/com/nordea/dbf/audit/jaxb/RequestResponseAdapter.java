package com.nordea.dbf.audit.jaxb;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.CompactWriter;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.io.StringWriter;

public class RequestResponseAdapter extends XmlAdapter<String, Object> {
    @Override
    public String unmarshal(String s) throws Exception {
        throw new UnsupportedOperationException("Unable to unmarshal arbitrary content");
    }

    @Override
    public String marshal(Object o) throws Exception {
        XStream xStream = new XStream();
        StringWriter result = new StringWriter();
        xStream.marshal(o, new CompactWriter(result));
        return result.toString();
    }
}
