package com.nordea.dbf.audit.logi;

import com.nordea.dbf.audit.AuditBusinessObject;
import com.nordea.dbf.audit.AuditEvent;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({LogIContext.class, AuditBusinessObject.class})
@XmlRootElement(name = "auditingLogObjects", namespace = "http://auditing.logi.nordea.com/object/v1")
public class LogIAuditEvent implements AuditEvent {

    @XmlElement(name = "logIContext")
    private LogIContext logIContext;

    @XmlElement(name = "logIConstantData")
    private LogIConstantData logIConstantData;

    @XmlElement(name = "logINTPConstantData")
    private LogINTPConstantData logINTPConstantData;

    @XmlElement(name = "businessData")
    private Object businessData;

    private LogIAuditEvent() {
    }

    public static class Builder {

        private final LogIAuditEvent instance = new LogIAuditEvent();

        public Builder context(LogIContext context) {
            instance.logIContext = context;
            return this;
        }

        public Builder constantDate(LogIConstantData constantData) {
            instance.logIConstantData = constantData;
            return this;
        }

        public Builder ntpConstantData(LogINTPConstantData ntpConstantData) {
            instance.logINTPConstantData = ntpConstantData;
            return this;
        }

        public Builder businessData(String businessData) {
            instance.businessData = businessData;
            return this;
        }

        public Builder businessData(Object businessDataObject) {
            instance.businessData = businessDataObject;
            return this;
        }

        public LogIAuditEvent build() {
            return instance;
        }
    }
}
