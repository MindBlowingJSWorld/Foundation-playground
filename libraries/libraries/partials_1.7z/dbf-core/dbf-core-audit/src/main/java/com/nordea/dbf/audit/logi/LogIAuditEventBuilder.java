package com.nordea.dbf.audit.logi;

import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.AuditEvent;
import com.nordea.dbf.audit.AuditEventBuilder;
import com.nordea.dbf.audit.Severity;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;

public class LogIAuditEventBuilder implements AuditEventBuilder {

    private LogIAuditEvent.Builder eventObjectBuilder = new LogIAuditEvent.Builder();

    private final LogIBusinessServiceComponent.Builder businessServiceComponentBuilder = new LogIBusinessServiceComponent.Builder();

    private final LogIConstantData.Builder constantDataBuilder = new LogIConstantData.Builder();

    private final LogINTPConstantData.Builder ntpConstantDataBuilder = new LogINTPConstantData.Builder();

    private final LogIContext.Builder contextBuiler = new LogIContext.Builder();

    @Override
    public AuditEventBuilder timestamp(DateTime timeStamp) {
        contextBuiler.timestamp(timeStamp);
        return this;
    }

    @Override
    public AuditEventBuilder userId(String userId) {
        contextBuiler.userId(userId);
        return this;
    }

    @Override
    public AuditEventBuilder applicationId(String applicationId) {
        contextBuiler.applicationId(applicationId);
        return this;
    }

    @Override
    public AuditEventBuilder severity(Severity severity) {
        constantDataBuilder.severity(severity);
        return this;
    }

    @Override
    public AuditEventBuilder sessionId(String sessionId) {
        constantDataBuilder.sessionId(sessionId);
        return this;
    }

    @Override
    public AuditEventBuilder requestId(String requestId) {
        constantDataBuilder.requestId(requestId);
        return this;
    }

    @Override
    public AuditEventBuilder result(Object result) {
        constantDataBuilder.result(result);
        return this;
    }

    @Override
    public AuditEventBuilder channel(String channel) {
        constantDataBuilder.channelId(channel);
        return this;
    }

    @Override
    public AuditEventBuilder serverName(String serverName) {
        constantDataBuilder.serverName(serverName);
        return this;
    }

    @Override
    public AuditEventBuilder userLocation(String userLocation) {
        constantDataBuilder.userLocation(userLocation);
        return this;
    }

    @Override
    public AuditEventBuilder serviceId(String serviceId) {
        businessServiceComponentBuilder.id(serviceId);
        return this;
    }

    @Override
    public AuditEventBuilder serviceEndPoint(String serviceEndPoint) {
        businessServiceComponentBuilder.serviceName(serviceEndPoint);
        return this;
    }

    @Override
    public AuditEventBuilder requestDomain(String requestDomain) {
        ntpConstantDataBuilder.requestDomain(requestDomain);
        return this;
    }

    @Override
    public AuditEventBuilder technicalUserId(String technicalUserId) {
        ntpConstantDataBuilder.technicalUserId(technicalUserId);
        return this;
    }

    @Override
    public AuditEventBuilder clientAction(String clientAction) {
        ntpConstantDataBuilder.clientAction(clientAction);
        return this;
    }

    @Override
    public AuditEventBuilder clientType(String clientType) {
        ntpConstantDataBuilder.clientType(clientType);
        return this;
    }

    @Override
    public AuditEventBuilder clientView(String clientView) {
        ntpConstantDataBuilder.clientView(clientView);
        return this;
    }

    @Override
    public AuditEventBuilder message(String message) {
        eventObjectBuilder.businessData(message);
        return this;
    }

    @Override
    public AuditEventBuilder message(Object messageObject) {
        eventObjectBuilder.businessData(messageObject);
        return this;
    }

    @Override
    public AuditEventBuilder auditCategory(AuditCategory auditCategory) {
        constantDataBuilder.auditCategory(auditCategory);
        contextBuiler.retentionDate(new LocalDate().plusYears(auditCategory.retentionYears()));
        return this;
    }

    @Override
    public AuditEvent build() {
        constantDataBuilder.businessServiceComponent(businessServiceComponentBuilder.build());
        eventObjectBuilder.constantDate(constantDataBuilder.build());
        eventObjectBuilder.ntpConstantData(ntpConstantDataBuilder.build());
        eventObjectBuilder.context(contextBuiler.build());
        return eventObjectBuilder.build();
    }
}
