package com.nordea.dbf.audit.logi;

import com.nordea.dbf.audit.*;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.IllegalStateException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class LogIAuditEventDispatcher implements AuditEventDispatcher, AutoCloseable {

    private static final Logger LOGGER = LoggerFactory.getLogger(com.nordea.dbf.audit.logi.LogIAuditEventDispatcher.class);

    private final AuditEventMarshaller marshaller;
    private final Connection connection;
    private final Session session;
    private final MessageProducer messageProducer;

    public LogIAuditEventDispatcher(AuditEventMarshaller marshaller, Connection connection, Session session, MessageProducer messageProducer) {
        Validate.notNull(marshaller, "marshaller can't be null");
        Validate.notNull(connection, "connection can't be null");
        Validate.notNull(session, "session can't be null");
        Validate.notNull(messageProducer, "messageProducer can't be null");

        this.marshaller = marshaller;
        this.connection = connection;
        this.session = session;
        this.messageProducer = messageProducer;
    }

    @Override
    public void audit(AuditEvent event) {
        final ByteArrayOutputStream bout = new ByteArrayOutputStream();
        final long start = System.nanoTime();

        try {
            marshaller.marshal(event, bout);

            final String auditString = bout.toString("UTF-8");

            messageProducer.send(session.createTextMessage(auditString));
        } catch (IOException | JMSException e) {
            throw new AuditFailureException("Failed to audit log event", e);
        }

        LOGGER.info("Audit event successfully dispatched to LogI in {}ms", TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start));
    }

    @Override
    public AuditEventFactory getAuditLogEventFactory() {
        // Java 8:
        // LogIAuditEventBuilder::new
        // Java 7:
        return new AuditEventFactory() {
            @Override public AuditEventBuilder createEventBuilder() {
                return new LogIAuditEventBuilder();
            }
        };
    }

    @Override
    public void close() throws JMSException {
        messageProducer.close();
        session.close();
        connection.close();
    }

    @SuppressWarnings("unchecked")
    private static abstract class Configurer<T extends Configurer> {

        private AuditEventMarshaller marshaller;

        public T marshaller(AuditEventMarshaller marshaller) {
            this.marshaller = marshaller;
            return (T) this;
        }

        protected AuditEventDispatcher lookup(InitialContext initialContext, String queueName) {
            final Queue queue;

            try {
                queue = (Queue) initialContext.lookup(queueName);
            } catch (NamingException e) {
                throw new AuditLoggerConfigurationException("Failed to lookup remote audit queue '" + queueName + "'", e);
            }

            final ConnectionFactory connectionFactory;

            try {
                connectionFactory = (ConnectionFactory) initialContext.lookup("weblogic.jms.XAConnectionFactory");
            } catch (NamingException e) {
                throw new AuditLoggerConfigurationException("Failed to lookup weblogic XAConnectionFactory", e);
            }

            final Connection connection;
            try {
                connection = connectionFactory.createConnection();
            } catch (JMSException e) {
                throw new AuditLoggerConfigurationException("Failed to create JMS connection for audit logging");
            }

            final Session session;

            try {
                session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            } catch (JMSException e) {
                throw new AuditLoggerConfigurationException("Failed to create JMS session for auditing ", e);
            }

            final MessageProducer producer;
            try {
                producer = session.createProducer(queue);
            } catch (JMSException e) {
                throw new AuditLoggerConfigurationException("Failed to create message producer for '" + queueName + "'", e);
            }

            return new com.nordea.dbf.audit.logi.LogIAuditEventDispatcher(marshaller, connection, session, producer);
        }

    }

    public static class Connector extends Configurer<Connector> {

        private String url;

        private String userName;

        private String password;

        private String queueName = "jms/LogIAuditDistQueue";

        public Connector url(String url) {
            this.url = url;
            return this;
        }

        public Connector userName(String userName) {
            this.userName = userName;
            return this;
        }

        public Connector password(String password) {
            this.password = password;
            return this;
        }

        public Connector queueName(String queueName) {
            this.queueName = queueName;
            return this;
        }

        public AuditEventDispatcher connect() {
            if (StringUtils.isEmpty(url)) {
                throw new IllegalStateException("Valid URL must be provided");
            }

            if (StringUtils.isEmpty(userName)) {
                throw new IllegalStateException("Valid username must be provided");
            }

            if (StringUtils.isEmpty(password)) {
                throw new IllegalStateException("Valid password must be provided");
            }

            if (StringUtils.isEmpty(queueName)) {
                throw new IllegalStateException("Valid queueName must be provided");
            }

            LOGGER.info("Creating LogI connection to queue {} at URL {} under principal {}", queueName, url, userName);

            final InitialContext initialContext;

            try {
                initialContext = new InitialContext(new Hashtable<>(immutableMap(
                    entry(InitialContext.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory"),
                    entry(Context.PROVIDER_URL, url),
                    entry(Context.SECURITY_PRINCIPAL, userName),
                    entry(Context.SECURITY_CREDENTIALS, password)
                )));
            } catch (NamingException e) {
                throw new AuditLoggerConfigurationException("Failed to create initial JNDI context for remote queue lookup for url '" + url + "'", e);
            }

            LOGGER.info("JNDI context successfully created for remote URL {}", url);

            try {
                final AuditEventDispatcher dispatcher = lookup(initialContext, queueName);

                LOGGER.info("Remote LogI JMS queue {} successfully looked for URL {}", queueName, url);

                return dispatcher;
            } catch (Exception e) {
                throw new AuditLoggerConfigurationException("JMS configuration failed for queue '" + queueName + "'@'" + url + "'", e);
            }
        }
    }

    public static class Locator extends Configurer<Locator> {

        private String queueName = "jms/LogIAuditLocalQueue";

        public Locator queueName(String queueName) {
            this.queueName = queueName;
            return this;
        }

        public AuditEventDispatcher locate() {
            final InitialContext initialContext;

            try {
                initialContext = new InitialContext(new Hashtable<>(immutableMap(
                    entry(InitialContext.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory")
                )));
            } catch (NamingException e) {
                throw new AuditLoggerConfigurationException("Failed to create initial JNDI context for local queue lookup", e);
            }

            return lookup(initialContext, queueName);
        }

    }

    /**
     * Util method to get rid of the guava dependency
     */
    private static <K,V> Map.Entry<K,V> entry(final K k,final V v){
        if (k == null) {
            throw new NullPointerException("null key in entry: null=" + v);
        } else if (v == null) {
            throw new NullPointerException("null value in entry: " + k + "=null");
        }
        return new Map.Entry<K,V>(){

            @Override public K getKey() {
                return k;
            }

            @Override public V getValue() {
                return v;
            }

            @Override public V setValue(V value) {
                throw new UnsupportedOperationException();
            }
        };
    }
    /**
     * Util method to get rid of the guava dependency
     */
    private static <K,V> Map<K,V> immutableMap(Map.Entry<K,V>... entries){
        Map<K,V> tmp = new HashMap<>();
        for(Map.Entry<K, V> each:entries){
            tmp.put(each.getKey(),each.getValue());
        }
        return Collections.unmodifiableMap(tmp);
    }
}
