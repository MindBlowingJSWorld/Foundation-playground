package com.nordea.dbf.audit.logi;

import javax.xml.bind.annotation.XmlElement;

public class LogIBusinessServiceComponent {

    @XmlElement(name = "id")
    private String id;

    @XmlElement(name = "serviceName")
    private String serviceName;

    private LogIBusinessServiceComponent() {
    }

    public String getId() {
        return id;
    }

    public String getServiceName() {
        return serviceName;
    }

    public static final class Builder {

        private final com.nordea.dbf.audit.logi.LogIBusinessServiceComponent instance = new com.nordea.dbf.audit.logi.LogIBusinessServiceComponent();

        public Builder id(String id) {
            instance.id = id;
            return this;
        }

        public Builder serviceName(String serviceName) {
            instance.serviceName = serviceName;
            return this;
        }

        public com.nordea.dbf.audit.logi.LogIBusinessServiceComponent build() {
            return instance;
        }

    }

}
