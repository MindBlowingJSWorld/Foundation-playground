package com.nordea.dbf.audit.logi;

import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.Severity;
import com.nordea.dbf.audit.jaxb.RequestResponseAdapter;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

public class LogIConstantData {

    @XmlElement(name = "severityId")
    private Severity severity;

    @XmlElement(name = "sessionId")
    private String sessionId;

    @XmlElement(name = "requestId")
    private String requestId;

    @XmlElement(name = "result")
    @XmlJavaTypeAdapter(RequestResponseAdapter.class)
    private Object result;

    @XmlElement(name = "channelId")
    private String channelId;

    @XmlElement(name = "serverName")
    private String serverName;

    @XmlElement(name = "userLocation")
    private String userLocation;

    @XmlElement(name = "auditCategory")
    private AuditCategory auditCategory;

    @XmlElement(name = "businessServiceComponent")
    private LogIBusinessServiceComponent businessServiceComponent;

    private LogIConstantData() {
    }

    public Severity getSeverity() {
        return severity;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getRequestId() {
        return requestId;
    }

    public Object getResult() {
        return result;
    }

    public String getChannelId() {
        return channelId;
    }

    public String getServerName() {
        return serverName;
    }

    public String getUserLocation() {
        return userLocation;
    }

    public AuditCategory getAuditCategory() {
        return auditCategory;
    }

    public LogIBusinessServiceComponent getBusinessServiceComponent() {
        return businessServiceComponent;
    }

    public static final class Builder {

        private final com.nordea.dbf.audit.logi.LogIConstantData instance = new com.nordea.dbf.audit.logi.LogIConstantData();

        public Builder severity(Severity severity) {
            instance.severity = severity;
            return this;
        }

        public Builder sessionId(String sessionId) {
            instance.sessionId = sessionId;
            return this;
        }

        public Builder businessServiceComponent(LogIBusinessServiceComponent component) {
            instance.businessServiceComponent = component;
            return this;
        }

        public Builder requestId(String requestId) {
            instance.requestId = requestId;
            return this;
        }

        public Builder serverName(String serverName) {
            instance.serverName = serverName;
            return this;
        }

        public Builder userLocation(String userLocation) {
            instance.userLocation = userLocation;
            return this;
        }

        public Builder channelId(String channelId) {
            instance.channelId = channelId;
            return this;
        }

        public Builder result(Object result) {
            instance.result = result;
            return this;
        }

        public Builder auditCategory(AuditCategory auditCategory) {
            instance.auditCategory = auditCategory;
            return this;
        }

        public com.nordea.dbf.audit.logi.LogIConstantData build() {
            if (instance.severity == null) {
                instance.severity = instance.auditCategory.getSeverity();
            }

            return instance;
        }
    }
}
