package com.nordea.dbf.audit.logi;

import com.nordea.dbf.audit.jaxb.DateTimeAdapter;
import com.nordea.dbf.audit.jaxb.LocalDateAdapter;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


public class LogIContext {

    @XmlElement(name = "logTimestamp")
    @XmlJavaTypeAdapter(DateTimeAdapter.class)
    private DateTime timestamp;

    @XmlElement(name = "retentionDate")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate retentionDate;

    @XmlElement(name = "userId")
    private String userId;

    @XmlElement(name = "applicationId")
    private String applicationId;

    private LogIContext() {
    }

    public DateTime getTimestamp() {
        return timestamp;
    }

    public LocalDate getRetentionDate() {
        return retentionDate;
    }

    public String getUserId() {
        return userId;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public static class Builder {

        private final com.nordea.dbf.audit.logi.LogIContext instance = new com.nordea.dbf.audit.logi.LogIContext();

        public Builder timestamp(DateTime timestamp) {
            instance.timestamp = timestamp;
            return this;
        }

        public Builder retentionDate(LocalDate date) {
            instance.retentionDate = date;
            return this;
        }

        public Builder userId(String userId) {
            instance.userId = userId;
            return this;
        }

        public Builder applicationId(String applicationId) {
            instance.applicationId = applicationId;
            return this;
        }

        public com.nordea.dbf.audit.logi.LogIContext build() {
            return instance;
        }
    }
}
