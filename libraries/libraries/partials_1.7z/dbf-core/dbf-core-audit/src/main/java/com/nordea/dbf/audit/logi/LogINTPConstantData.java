package com.nordea.dbf.audit.logi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "logINTPConstantDataType",
        propOrder = {
                "technicalUserId",
                "requestDomain",
                "accountingUnit",
                "clientType",
                "clientComponent",
                "clientComponentVersion",
                "clientAction",
                "clientView"
        })
public class LogINTPConstantData {

    @XmlElement(name = "technicalUserId")
    private String technicalUserId;

    @XmlElement(name = "requestDomain")
    private String requestDomain;

    @XmlElement(name = "accountingUnit")
    private String accountingUnit;

    @XmlElement(name = "clientType", required = true)
    private String clientType;

    @XmlElement(name = "clientComponent", required = true)
    private String clientComponent;

    @XmlElement(name = "clientComponentVersion", required = true)
    private String clientComponentVersion;

    @XmlElement(name = "clientAction", required = true)
    private String clientAction;

    @XmlElement(name = "clientView")
    private String clientView;

    public String getTechnicalUserId() {
        return technicalUserId;
    }

    public String getRequestDomain() {
        return requestDomain;
    }

    public String getAccountingUnit() {
        return accountingUnit;
    }

    public String getClientType() {
        return clientType;
    }

    public String getClientComponent() {
        return clientComponent;
    }

    public String getClientComponentVersion() {
        return clientComponentVersion;
    }

    public String getClientAction() {
        return clientAction;
    }

    public String getClientView() {
        return clientView;
    }

    public static class Builder {

        private final com.nordea.dbf.audit.logi.LogINTPConstantData instance = new com.nordea.dbf.audit.logi.LogINTPConstantData();

        public Builder technicalUserId(String technicalUserId) {
            instance.technicalUserId = technicalUserId;
            return this;
        }

        public Builder accountingUnit(String accountingUnit) {
            instance.accountingUnit = accountingUnit;
            return this;
        }

        public Builder clientAction(String clientAction) {
            instance.clientAction = clientAction;
            return this;
        }

        public Builder clientType(String clientType) {
            instance.clientType = clientType;
            return this;
        }

        public Builder clientView(String clientView) {
            instance.clientView = clientView;
            return this;
        }

        public Builder clientComponent(String clientComponent) {
            instance.clientComponent = clientComponent;
            return this;
        }

        public Builder requestDomain(String requestDomain) {
            instance.requestDomain = requestDomain;
            return this;
        }

        public Builder clientComponentVersion(String clientComponentVersion) {
            instance.clientComponentVersion = clientComponentVersion;
            return this;
        }

        public com.nordea.dbf.audit.logi.LogINTPConstantData build() {
            return instance;
        }
    }

}
