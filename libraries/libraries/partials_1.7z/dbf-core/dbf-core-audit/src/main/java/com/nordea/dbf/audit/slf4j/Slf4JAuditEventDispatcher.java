package com.nordea.dbf.audit.slf4j;

import com.nordea.dbf.audit.*;
import com.nordea.dbf.audit.logi.LogIAuditEventBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class Slf4JAuditEventDispatcher implements AuditEventDispatcher {

    private static final Logger LOGGER = LoggerFactory.getLogger(com.nordea.dbf.audit.slf4j.Slf4JAuditEventDispatcher.class);

    private AuditEventMarshaller auditEventMarshaller;

    private final Logger logger;

    public Slf4JAuditEventDispatcher(AuditEventMarshaller auditEventMarshaller) {
        this(auditEventMarshaller, LoggerFactory.getLogger(com.nordea.dbf.audit.slf4j.Slf4JAuditEventDispatcher.class));
    }

    public Slf4JAuditEventDispatcher(AuditEventMarshaller auditEventMarshaller, Logger logger) {
        this.auditEventMarshaller = auditEventMarshaller;
        this.logger = logger;
    }

    @Override
    public void audit(AuditEvent event) {
        final ByteArrayOutputStream bout = new ByteArrayOutputStream();

        try {
            auditEventMarshaller.marshal(event, bout);
        } catch (IOException e) {
            LOGGER.error("Failed to marshal audit event: {}", event, e);
            return;
        }

        logger.info(bout.toString());
    }

    @Override
    public AuditEventFactory getAuditLogEventFactory() {
        //Java 8:
        //return LogIAuditEventBuilder::new;
        //Java 7:
        return new AuditEventFactory() {
            @Override public AuditEventBuilder createEventBuilder() {
                return new LogIAuditEventBuilder();
            }
        };
    }
}
