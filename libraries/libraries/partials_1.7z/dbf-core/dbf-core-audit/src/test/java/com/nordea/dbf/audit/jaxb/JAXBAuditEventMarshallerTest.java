package com.nordea.dbf.audit.jaxb;

import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.AuditEvent;
import com.nordea.dbf.audit.Severity;
import com.nordea.dbf.audit.logi.LogIAuditEventBuilder;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;
import org.junit.Before;
import org.junit.Test;

import javax.xml.bind.JAXBException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

public class JAXBAuditEventMarshallerTest {

  private final LogIAuditEventBuilder builder = new LogIAuditEventBuilder();
  private JAXBAuditEventMarshaller marshaller;

  private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormat.forPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");

  @Before
  public void setup() throws JAXBException {
    this.marshaller = new JAXBAuditEventMarshaller();
  }

  @Test
  public void marshalShouldReturnXmlRepresentationOfLoggedEvent() throws Exception {
    // Get the current timezone
    TimeZone timeZone = TimeZone.getDefault();
    int hours = (int) TimeUnit.MILLISECONDS.toHours(timeZone.getRawOffset());

    DateTime timeStamp = new DateTime().withDate(2015, 4, 21).withTime(12, 13, 14, 156).withZone(DateTimeZone.forOffsetHours(hours));
    final String string = marshal(builder
        .applicationId("ROSME")
        .severity(Severity.INFO)
        .channel("RBO")
        .message("MyMessage")
        .requestDomain("SE")
        .requestId("MyRequest")
        .result("MyResult")
        .serverName("MyServer")
        .serviceEndPoint("MyEndPoint")
        .serviceId("MyServiceId")
        .sessionId("MySession")
        .technicalUserId("MyTechUser")
        .timestamp(timeStamp)
        .userId("MyUser")
        .userLocation("MyUserLocation")
        .auditCategory(AuditCategory.LEGAL)
        .build());


    assertThat(string).contains("<applicationId>ROSME</applicationId>");
    String expectedDatetime = DATE_TIME_FORMATTER.print(timeStamp.toDateTime(DateTimeZone.UTC));
    assertThat(string).contains(expectedDatetime);
    // Beware! this test might fail if it runs at the transition between years.
    assertThat(string).contains("<retentionDate>"+ ISODateTimeFormat.date().print(new DateTime().plusYears(11))+"</retentionDate>");
    assertThat(string).contains("<userId>MyUser</userId");
    assertThat(string).contains("<severityId>INFO</severityId>");
    assertThat(string).contains("<sessionId>MySession</sessionId>");
    assertThat(string).contains("<requestId>MyRequest</requestId>");
    assertThat(string).contains("<result><string>MyResult</string></result>");
    assertThat(string).contains("<channelId>RBO</channelId>");
    assertThat(string).contains("<serverName>MyServer</serverName>");
    assertThat(string).contains("<userLocation>MyUserLocation</userLocation>");
    assertThat(string).contains("<auditCategory>LEGAL</auditCategory>");
    assertThat(string).contains("<id>MyServiceId</id>");
    assertThat(string).contains("<serviceName>MyEndPoint</serviceName>");
    assertThat(string).contains("<technicalUserId>MyTechUser</technicalUserId>");
    assertThat(string).contains("<requestDomain>SE</requestDomain>");
    assertThat(string).contains(">MyMessage<");
  }

  private String marshal(AuditEvent event) throws IOException {
    final ByteArrayOutputStream bout = new ByteArrayOutputStream();

    marshaller.marshal(event, bout);

    return bout.toString("UTF-8");
  }

}
