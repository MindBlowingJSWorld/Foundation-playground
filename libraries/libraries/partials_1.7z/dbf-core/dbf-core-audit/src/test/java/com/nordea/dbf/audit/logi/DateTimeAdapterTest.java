package com.nordea.dbf.audit.logi;

import com.nordea.dbf.audit.jaxb.DateTimeAdapter;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Test;

import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

public class DateTimeAdapterTest {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormat.forPattern("yyyy-MM-dd-HH.mm.ss.SSSSSS");

    private final DateTimeAdapter adapter = new DateTimeAdapter();
    private final DateTime exampleDateTime;
    public DateTimeAdapterTest() {
        // Get the current timezone
        TimeZone timeZone = TimeZone.getDefault();
        int hours = (int) TimeUnit.MILLISECONDS.toHours(timeZone.getRawOffset());
        exampleDateTime = new DateTime()
            .withDate(2015, 4, 21)
            .withTime(15, 30, 40, 123)
            .withZone(DateTimeZone.forOffsetHours(hours));
    }

    @Test
    public void marshalShouldReturnDateTime() throws Exception {
        final String actual = adapter.marshal(exampleDateTime);

        String expectedDatetime = DATE_TIME_FORMATTER.print(exampleDateTime.toDateTime(DateTimeZone.UTC));
        assertThat(actual).isEqualTo(expectedDatetime);
    }

    @Test
    public void unmarshalShouldReturnDateFromString() throws Exception {
        final DateTime actual = adapter.unmarshal("2015-04-21-15.30.40.123000");
        // Convert the two datetimes to Instant, since theq will have different zones (one has Chronology +02:00, the other has 'Europe/Paris')
        assertThat(actual.toInstant()).isEqualTo(exampleDateTime.toInstant());
    }

    @Test
    public void marshalShouldReturnEmptyStringForNullInput() throws Exception {
        assertThat(adapter.marshal(null)).isEqualTo(StringUtils.EMPTY);
    }

    @Test
    public void unmarshalShouldReturnNullForNullOrEmptyString() throws Exception {
        assertThat(adapter.unmarshal(null)).isNull();
        assertThat(adapter.unmarshal("")).isNull();
    }

}
