package com.nordea.dbf.audit.logi;

import com.nordea.dbf.audit.jaxb.LocalDateAdapter;
import org.apache.commons.lang.StringUtils;
import org.joda.time.LocalDate;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class LocalDateAdapterTest {

    private final LocalDateAdapter adapter = new LocalDateAdapter();

    private final LocalDate exampleDate = new LocalDate()
            .withYear(2015)
            .withMonthOfYear(4)
            .withDayOfMonth(21);

    @Test
    public void marshalShouldReturnDateAsString() throws Exception {
        assertThat(adapter.marshal(exampleDate)).isEqualTo("2015-04-21");
    }

    @Test
    public void unmarshalShouldReturnStringRepresentationOfDate() throws Exception {
        assertThat(adapter.unmarshal("2015-04-21")).isEqualTo(exampleDate);
    }

    @Test
    public void marshalShouldReturnEmptyStringForNull() throws Exception {
        assertThat(adapter.marshal(null)).isEqualTo(StringUtils.EMPTY);
    }

    @Test
    public void unmarshalShouldReturnNullForEmptyOrNullString() throws Exception {
        assertThat(adapter.unmarshal(null)).isNull();
        assertThat(adapter.unmarshal("")).isNull();;
    }

}
