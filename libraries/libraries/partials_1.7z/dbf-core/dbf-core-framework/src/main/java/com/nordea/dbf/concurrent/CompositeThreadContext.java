package com.nordea.dbf.concurrent;

import org.apache.commons.lang.Validate;

import java.util.Arrays;

public class CompositeThreadContext implements ThreadContext {

    private final ThreadContext[] threadContexts;

    public CompositeThreadContext(ThreadContext[] threadContexts) {
        Validate.notNull(threadContexts, "threadContexts can't be null");
        Validate.noNullElements(threadContexts, "threadContexts can't contain null elements");

        this.threadContexts = Arrays.copyOf(threadContexts, threadContexts.length);
    }

    @Override
    public Handover createHandover() {
        final Handover[] handovers = new Handover[threadContexts.length];

        for (int i = 0; i < threadContexts.length; i++) {
            handovers[i] = threadContexts[i].createHandover();
        }

        return new Handover() {
            @Override
            public void commit() {
                for (final Handover handover : handovers) {
                    handover.commit();
                }
            }

            @Override
            public void close() {
                for (final Handover handover : handovers) {
                    handover.close();
                }
            }
        };
    }
}
