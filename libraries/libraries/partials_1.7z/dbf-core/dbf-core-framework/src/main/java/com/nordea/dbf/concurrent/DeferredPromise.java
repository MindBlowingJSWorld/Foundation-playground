package com.nordea.dbf.concurrent;

import org.apache.commons.lang.Validate;
import rx.Observable;
import rx.Observer;
import rx.Subscriber;

import java.util.Optional;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/**
 * A <code>DeferredPromise</code> represents the outcome of an asynchronous operation. The
 * promise can be explicitly completed by its owner and any observer of the operation should
 * observe the promise through the <code>Observable</code> instance provided through
 * {@link DeferredPromise#toObservable()}. A <code>DeferredPromise</code> produces exactly
 * one value.
 *
 * @param <T> The type of the value produced by the asynch operation.
 */
public class DeferredPromise<T> {

    /**
     * Creates a new <code>DeferredPromise</code> that is initially not completed.
     *
     * @param <T> The type of the values produced by the owner of the promise.
     * @return A new promise that is not completed.
     */
    public static <T> DeferredPromise<T> create() {
        return new DeferredPromise<>();
    }

    /**
     * Creates a promise that is immediately completed with the provided value.
     *
     * @param value The resulting value.
     * @param <T>   The type of the result.
     * @return A promise that is immediately completed.
     */
    public static <T> DeferredPromise<T> of(T value) {
        Validate.notNull(value, "value can't be null");

        final DeferredPromise<T> promise = new DeferredPromise<>();

        promise.outcomeReference.set(new Outcome<T>(Optional.of(value), Optional.<Throwable>empty()));
        promise.stateReference.set(State.COMPLETED);

        return promise;
    }

    /**
     * Creates an immediately failed promise.
     *
     * @param throwable The cause of the failure.
     * @param <T>       The type of the result expected from a successful outcome.
     * @return A promise that is immediately failed.
     */
    public static <T> DeferredPromise<T> failure(Throwable throwable) {
        Validate.notNull(throwable, "throwable can't be null");

        final DeferredPromise<T> promise = new DeferredPromise<>();

        promise.outcomeReference.set(new Outcome<T>(Optional.<T>empty(), Optional.of(throwable)));
        promise.stateReference.set(State.COMPLETED);

        return promise;

    }

    /**
     * Current set of observes subscribed to the promise.
     */
    private final Queue<Observer> observers = new ConcurrentLinkedQueue<>();

    /**
     * Reference to the current state of the promise. Always pending initially and switched
     * to completed when the promise is completed or failed. The state-dependent methods
     * in the promise are delegated to the promise state, as the methods are dependent
     * on the state.
     */
    private final AtomicReference<State> stateReference = new AtomicReference<>(State.PENDING);

    /**
     * Reference to the promises outcome. This will be null when the promise is pending
     * and switched to non-null when the promise is failed or completed.
     */
    private final AtomicReference<Outcome<T>> outcomeReference = new AtomicReference<>();

    /**
     * Creates an observable from this promise. The observable will be notified whenever
     * this promise is completed or failed. If the promise is already completed or failed,
     * the observable will be notified immediately.
     *
     * @return An observable used to observe this promise.
     */
    public Observable<T> toObservable() {
        return Observable.create(new Observable.OnSubscribe<T>() {
            @Override
            public void call(Subscriber<? super T> subscriber) {
                stateReference.get().subscribe(DeferredPromise.this, subscriber);
            }
        });
    }

    /**
     * Completes the promise. This will notify any subscribed observerse <i>and</i> and future
     * observers about the successful outcome. The promise must be in pending state, or this
     * method will fail with a <code>IllegalStateException</code>.
     *
     * @param value The value produced by the owner of this promise.
     */
    public void complete(T value) {
        Validate.notNull(value, "value can't be null");
        stateReference.get().complete(this, new Outcome<T>(Optional.of(value), Optional.<Throwable>empty()));
    }

    /**
     * Fails the promise. This will notify any subscribed observers <i>and</i> any future observers
     * of the failure. The promise must be in pending state, or this method will fail with
     * an <code>IllegalStateException</code>.
     *
     * @param error The error that occured.
     */
    public void fail(Throwable error) {
        Validate.notNull(error, "error can't be null");
        stateReference.get().complete(this, new Outcome<T>(Optional.<T>empty(), Optional.of(error)));
    }

    /**
     * A <code>State</code> represents the current state of a promise. The state can either
     * be pending or completed. Handling of state changes in the promise are delegated to the
     * current state.
     */
    protected enum State {

        /**
         * Represents the pending state. This state appends new observers to a list for
         * future notification. The pending state can be completed, which updates the
         * value of the promise and switches the state to completed.
         */
        PENDING {
            @Override
            @SuppressWarnings("unchecked")
            void complete(DeferredPromise promise, Outcome outcome) {
                if (!promise.outcomeReference.compareAndSet(null, outcome)) {
                    throw alreadyCompletedException();
                }

                promise.stateReference.set(COMPLETED);

                // Notify all subscribed observers
                for (Observer observer = null; (observer = (Observer) promise.observers.poll()) != null; ) {
                    doComplete(observer, outcome);
                }
            }

            @SuppressWarnings("unchecked")
            @Override
            void subscribe(DeferredPromise promise, final Observer observer) {
                promise.observers.add(newIdempotentObserver(observer));

                if (promise.stateReference.get() != State.PENDING) {
                    doComplete(observer, (Outcome) promise.outcomeReference.get());

                    // Remove the observer from the list to avoid keeping stale references
                    promise.observers.remove(observer);
                }
            }
        },

        /**
         * The complete state is applied when a promise is finalized either with success
         * or failure. This state immediately notifies - without enlisting -
         */
        COMPLETED {
            @Override
            void complete(DeferredPromise promise, Outcome outcome) {
                throw alreadyCompletedException();
            }

            @Override
            void subscribe(DeferredPromise promise, Observer observer) {
                doComplete(observer, (Outcome) promise.outcomeReference.get());
            }
        };

        abstract void complete(DeferredPromise promise, Outcome outcome);

        abstract void subscribe(DeferredPromise promise, Observer observer);

    }

    private static IllegalStateException alreadyCompletedException() {
        return new IllegalStateException("Already completed");
    }

    /**
     * Notifies the provided observer about the specified outcome. If the outcome represents a
     * successul result, the observer will receive the value through onNext and will then be
     * immediately completed through onCompleted. If the outcome represents a failure, the
     * observer will get a single call to onError.
     *
     * @param observer The observer that should be notified.
     * @param outcome  The outcome of the promise.
     */
    @SuppressWarnings("unchecked")
    protected static void doComplete(Observer observer, Outcome outcome) {
        if (outcome.getError().isPresent()) {
            observer.onError((Throwable) outcome.getError().get());
        } else {
            observer.onNext(outcome.getValue().get());
            observer.onCompleted();
        }
    }

    /**
     * An <code>Outcome</code> represents either a successful result with a value or a failure
     * with the cause exception.
     *
     * @param <T> The type of the value for a successful outcome.
     */
    protected static final class Outcome<T> {

        private final Optional<T> value;

        private final Optional<Throwable> error;

        public Outcome(Optional<T> value, Optional<Throwable> error) {
            Validate.notNull(value, "value can't be null");
            Validate.notNull(error, "error can't be null");
            Validate.isTrue(value.isPresent() ^ error.isPresent(), "Either value or error must be present but not both");

            this.value = value;
            this.error = error;
        }

        public Optional<T> getValue() {
            return value;
        }

        public Optional<Throwable> getError() {
            return error;
        }
    }

    /**
     * Creates an idempotent observer that drops duplicate calls to onNext, onError and
     * onCompleted. Duplicate calls can occur when a subscription is created concurrently
     * with a promise being completed. That's acceptable to keep the promise non-blocking.
     *
     * @param observer The observer that should be made idempotent.
     * @return A new observer where the methods are safe to call multiple times.
     */
    protected static Observer newIdempotentObserver(final Observer observer) {
        return new Observer() {

            private final AtomicBoolean outcomeSet = new AtomicBoolean();

            private final AtomicBoolean completed = new AtomicBoolean();

            @Override
            public void onCompleted() {
                if (completed.compareAndSet(false, true)) {
                    observer.onCompleted();
                }
            }

            @Override
            public void onError(Throwable e) {
                if (outcomeSet.compareAndSet(false, true)) {
                    observer.onError(e);
                }
            }

            @SuppressWarnings("unchecked")
            @Override
            public void onNext(Object o) {
                if (outcomeSet.compareAndSet(false, true)) {
                    observer.onNext(o);
                }
            }
        };
    }

}
