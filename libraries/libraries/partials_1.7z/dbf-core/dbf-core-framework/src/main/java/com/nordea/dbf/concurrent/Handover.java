package com.nordea.dbf.concurrent;

public interface Handover extends AutoCloseable {

    Handover NOP = new Handover() {
        @Override
        public void commit() {
        }

        @Override
        public void close() {
        }
    };

    default void in(Runnable runnable) {
        commit();

        try {
            runnable.run();
        } finally {
            close();
        }
    }

    void commit();

    void close();
}
