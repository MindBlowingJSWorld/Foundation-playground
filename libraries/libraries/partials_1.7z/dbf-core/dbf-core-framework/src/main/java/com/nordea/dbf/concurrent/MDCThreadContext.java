package com.nordea.dbf.concurrent;

import org.slf4j.MDC;

import java.util.Collections;
import java.util.Map;

public class MDCThreadContext implements ThreadContext {

    @Override
    public Handover createHandover() {
        final Map<String, String> context = MDC.getCopyOfContextMap() != null ? MDC.getCopyOfContextMap() : Collections.<String, String>emptyMap();

        return new Handover() {
            @Override
            public void commit() {
                MDC.setContextMap(context);
            }

            @Override
            public void close() {
                MDC.clear();
            }
        };
    }
}
