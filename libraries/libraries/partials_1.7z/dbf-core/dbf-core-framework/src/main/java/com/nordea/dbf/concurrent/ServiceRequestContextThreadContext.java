package com.nordea.dbf.concurrent;

import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;

import java.util.Optional;

public class ServiceRequestContextThreadContext implements ThreadContext {

    @Override
    public Handover createHandover() {
        final Optional<ServiceRequestContext> serviceRequestContext = ServiceRequestContextHolder.get();

        if (!serviceRequestContext.isPresent()) {
            return Handover.NOP;
        }

        return new Handover() {

            private boolean inherited = false;

            @Override
            public void commit() {
                final Optional<ServiceRequestContext> currentContext = ServiceRequestContextHolder.get();

                if (!currentContext.isPresent()) {
                    ServiceRequestContextHolder.bind(serviceRequestContext.get());
                } else {
                    if (currentContext.get().equals(serviceRequestContext.get())) {
                        inherited = true;
                    } else {
                        throw new IllegalStateException("Conflicting service request context configured in thread=" + Thread.currentThread().getName());
                    }
                }
            }

            @Override
            public void close() {
                if (!inherited) {
                    ServiceRequestContextHolder.clear();
                }
            }
        };
    }
}
