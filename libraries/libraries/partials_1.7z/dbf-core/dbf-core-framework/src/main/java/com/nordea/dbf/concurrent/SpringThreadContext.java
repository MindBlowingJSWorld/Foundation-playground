package com.nordea.dbf.concurrent;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

public class SpringThreadContext implements ThreadContext {

    @Override
    public Handover createHandover() {
        final RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();

        if (requestAttributes == null) {
            return Handover.NOP;
        }

        return new Handover() {
            private RequestAttributes oldRequestAttributes;

            @Override
            public void commit() {
                this.oldRequestAttributes = RequestContextHolder.getRequestAttributes();

                RequestContextHolder.setRequestAttributes(requestAttributes);
            }

            @Override
            public void close() {
                RequestContextHolder.resetRequestAttributes();

                if (oldRequestAttributes != null) {
                    RequestContextHolder.setRequestAttributes(oldRequestAttributes);
                }
            }
        };
    }
}
