package com.nordea.dbf.concurrent;

/**
 * A <code>ThreadContext</code> provides management of the context bound to a thread.
 * In particular, it is used to transfer context information between threads whenever
 * a context switch is made. This is important, since e.g. the logback MDC context
 * is inherited by child threads, causing multiple switches per a child thread
 * to inherit the information of the original thread.
 */
public interface ThreadContext {

    ThreadContext DEFAULT = new CompositeThreadContext(new ThreadContext[]{
            new MDCThreadContext(),
            new ServiceRequestContextThreadContext(),
            new SpringThreadContext()
    });

    Handover createHandover();

}
