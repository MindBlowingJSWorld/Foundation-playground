package com.nordea.dbf.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.http.AntPatternRequestFilter;
import com.nordea.dbf.http.CorsFilter;
import com.nordea.dbf.http.DefaultHttpRequestDescriber;
import com.nordea.dbf.http.HttpRequestDescriber;
import com.nordea.dbf.http.RequestLoggingFilter;
import com.nordea.dbf.http.ServiceRequestContextFilter;
import com.nordea.dbf.http.contextappender.ClientRequestContextAppender;
import com.nordea.dbf.http.contextappender.LanguageAppender;
import com.nordea.dbf.http.contextappender.RequestIdAppender;
import com.nordea.dbf.http.contextappender.RequestRouteAppender;
import com.nordea.dbf.http.errorhandling.CustomHandlerExceptionResolver;
import com.nordea.dbf.http.errorhandling.GlobalExceptionHandler;
import com.nordea.dbf.logging.ConfigurationLogger;
import com.nordea.dbf.metadata.ApplicationMetaData;
import com.nordea.dbf.spring.ContextHandlerMethodArgumentResolver;
import com.nordea.dbf.spring.ServiceRequestContextMethodArgumentResolver;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.autoconfigure.web.DefaultErrorAttributes;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.boot.context.embedded.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.nordea.dbf.api.model.Error;

import javax.servlet.Filter;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Validator;
import java.io.IOException;
import java.util.*;
import java.util.function.Predicate;

@Configuration
@PropertySource(value = "classpath:dbf-defaults.properties", ignoreResourceNotFound = true)
public class ServiceConfiguration {

    @Autowired
    private Environment environment;

    @Lazy
    @Autowired(required = false)
    @Qualifier("requestContextFilterRegistration")
    private FilterRegistrationBean requestContextFilterRegistration;

    @Autowired
    private SecurityProperties securityProperties;


    @Bean
    public Validator validator() {
        return new LocalValidatorFactoryBean();
    }

    @Bean
    ServiceRequestContextMethodArgumentResolver serviceRequestContextMethodArgumentResolver() {
        return new ServiceRequestContextMethodArgumentResolver();
    }

    @Bean
    public WebMvcConfigurerAdapter contextArgumentAdapter() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
                argumentResolvers.add(new ContextHandlerMethodArgumentResolver());
                argumentResolvers.add(serviceRequestContextMethodArgumentResolver());
            }
        };
    }

    @Bean
    public CustomHandlerExceptionResolver customHandlerExceptionResolver() {
        return new CustomHandlerExceptionResolver();
    }

    /**
     * The below is a workaround to ensure the default ErrorController remaps the data to the expected error response model.
     * An alternative solution is to implement an Jetty ErrorHandler, but this avoid adding this dependency to core.
     */
    @Bean
    public ErrorAttributes errorAttributes() {
        return new DefaultErrorAttributes() {

            @Override
            public Map<String, Object> getErrorAttributes(
                RequestAttributes requestAttributes,
                boolean includeStackTrace) {
                Map<String, Object> errorAttributes = super.getErrorAttributes(requestAttributes, includeStackTrace);
                Map<String, Object> customErrorAttributes = new HashMap<>();
                customErrorAttributes.put("error", "error_" + errorAttributes.get("error").toString().toLowerCase().replace(" ", "_"));
                customErrorAttributes.put("error_description", errorAttributes.get("status") + " - " + errorAttributes.get("message"));
                customErrorAttributes.put("details", Arrays.asList(new ErrorDetails().setParam(errorAttributes.get("path").toString())));

                return customErrorAttributes;
            }

        };
    }

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper().registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
    }

    @Bean
    public GlobalExceptionHandler globalExceptionHandler() {
        return new GlobalExceptionHandler();
    }

    @Bean
    public ApplicationMetaData applicationMetaData() throws IOException {
        return new ApplicationMetaData.Builder()
                .groupId(environment.getProperty("dbf.application.groupId", StringUtils.EMPTY))
                .artifactId(environment.getProperty("dbf.application.artifactId", StringUtils.EMPTY))
                .version(environment.getProperty("dbf.application.version", StringUtils.EMPTY))
                .name(environment.getProperty("dbf.application.name", StringUtils.EMPTY))
                .build();
    }

    @Bean
    @Profile("debug")
    public ConfigurationLogger configurationLogger() {
        return new ConfigurationLogger();
    }

    @ConditionalOnProperty(name = "dbf.http.cors.enable")
    @Bean
    public FilterRegistrationBean corsFilter(@Value("${dbf.http.default.allowed.headers}") String defaultAllowedHeaders,
                                             @Value("${dbf.http.allowed.headers:}") String allowedHeaders) {
        final FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(new CorsFilter(defaultAllowedHeaders + (StringUtils.isNotEmpty(allowedHeaders) ? "," + allowedHeaders : "")));
        return filterRegistrationBean;
    }

    @Bean
    public FilterRegistrationBean requestContextFilterRegistration() {
        final FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(serviceRequestContextFilter());
        //Authentication token data appended to security context, so add this right after the security chain.
        filterRegistrationBean.setOrder(securityProperties != null ? securityProperties.getFilterOrder() + 1 : -99);
        return filterRegistrationBean;
    }

    @Bean
    public FilterRegistrationBean requestLoggingFilter() {
        final FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(new RequestLoggingFilter(httpRequestDescriber(), anonymousPathFilter()));
        //Service request context required to fill details to MDC. Place this right after it if found.
        filterRegistrationBean.setOrder(requestContextFilterRegistration != null ? requestContextFilterRegistration.getOrder() + 1 : -98);
        return filterRegistrationBean;
    }

    @Bean
    public Filter serviceRequestContextFilter() {
        return new ServiceRequestContextFilter();
    }

    @Bean
    public RequestRouteAppender requestRouteAppender() {
        return new RequestRouteAppender();
    }

    @Bean
    public LanguageAppender languageAppender() {
        return new LanguageAppender();
    }

    @Bean
    @ConditionalOnProperty("dbf.service.request.context.header.enabled")
    public ClientRequestContextAppender clientRequestContextAppender() {
        return new ClientRequestContextAppender(anonymousPathFilter());
    }

    @Bean
    public Predicate<HttpServletRequest> anonymousPathFilter() {
        return AntPatternRequestFilter.from(environment.getProperty("dbf.security.anonymous.paths",
                environment.getProperty("dbf.security.unrestricted.paths", StringUtils.EMPTY)));
    }

    @Bean
    public HttpRequestDescriber httpRequestDescriber() {
        return new DefaultHttpRequestDescriber();
    }

    @Bean
    @ConditionalOnProperty("dbf.independent.request.id.enabled")
    public RequestIdAppender requestIdAppender() {
        return new RequestIdAppender(environment.getProperty("dbf.request.id.header.name", "X-Request-ID"));
    }
}
