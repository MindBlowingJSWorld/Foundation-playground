package com.nordea.dbf.featuretoggle;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.util.StringTemplate;
import org.apache.commons.lang.Validate;
import org.springframework.core.env.Environment;

import java.util.Arrays;
import java.util.concurrent.ExecutionException;

import static com.nordea.dbf.util.StringTemplate.usingMap;

public class EnvironmentFeatureToggle implements FeatureToggle {

    private final Environment environment;

    private final StringTemplate featurePropertyTemplate;

    private final LoadingCache<String, Boolean> featureToggleCache = CacheBuilder.newBuilder().build(newCacheLoader());

    public EnvironmentFeatureToggle(Environment environment, String featurePropertyTemplate) {
        Validate.notNull(environment, "environment can't be null");

        this.environment = environment;
        this.featurePropertyTemplate = new StringTemplate(featurePropertyTemplate);

        if (!this.featurePropertyTemplate.getVariables().equals(Arrays.asList("feature"))) {
            throw new IllegalArgumentException("Feature toggle property template '" + featurePropertyTemplate
                    + "' is not valid; must contain exactly 1 variable: {feature}. Example: dbf.service.{feature}.enabled=true|false");
        }
    }

    @Override
    public boolean enabled(Feature feature) {
        Validate.notNull(feature, "feature can't be null");

        try {
            return featureToggleCache.get(feature.name());
        } catch (ExecutionException e) {
            if (e.getCause() instanceof RuntimeException) {
                throw (RuntimeException) e.getCause();
            }

            throw new IllegalStateException("Failed to load feature toggle configuration for feature: " + feature, e);
        }
    }

    private CacheLoader<String, Boolean> newCacheLoader() {
        return new CacheLoader<String, Boolean>() {
            @Override
            public Boolean load(String key) throws Exception {
                final String propertyKey = featurePropertyTemplate.expand(usingMap(ImmutableMap.of("feature", key)));

                return Boolean.valueOf(environment.getProperty(propertyKey, "false"));
            }
        };
    }
}
