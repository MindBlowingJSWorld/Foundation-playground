package com.nordea.dbf.featuretoggle;

public interface Feature {

    String name();

}
