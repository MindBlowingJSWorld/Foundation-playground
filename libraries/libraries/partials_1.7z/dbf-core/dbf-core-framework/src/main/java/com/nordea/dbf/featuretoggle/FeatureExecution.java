package com.nordea.dbf.featuretoggle;

import org.apache.commons.lang.Validate;

import java.util.function.Supplier;

public class FeatureExecution {

    private final Feature feature;

    private final Supplier<Boolean> activated;

    public FeatureExecution(Feature feature, Supplier<Boolean> activated) {
        Validate.notNull(feature, "feature can't be null");
        Validate.notNull(activated, "activated supplier can't be null");

        this.feature = feature;
        this.activated = activated;
    }

    public Feature feature() {
        return feature;
    }

    public boolean enabled() {
        return activated.get();
    }

    public void ensureEnabled() {
        ensureEnabled(() -> {});
    }

    public void ensureEnabled(Runnable runnable) {
        if (!enabled()) {
            runnable.run();
            throw new FeatureNotEnabledException(feature.name());
        }
    }

    public <T> GetAlternative<T> get(Supplier<T> supplier) {
        Validate.notNull(supplier, "supplier can't be null");
        return alternative -> {
            Validate.notNull(alternative, "alternative supplier can't be null");
            return activated.get() ? supplier.get() : alternative.get();
        };
    }

    public void run(Runnable runnable) {
        Validate.notNull(runnable, "runnable can't be null");

        if (activated.get()) {
            runnable.run();
        }
    }

    public interface GetAlternative<T> {

        T otherwise(Supplier<T> supplier);

    }
}
