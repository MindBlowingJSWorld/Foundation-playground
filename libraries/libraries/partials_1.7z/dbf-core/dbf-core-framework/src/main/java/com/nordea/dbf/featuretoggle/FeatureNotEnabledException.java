package com.nordea.dbf.featuretoggle;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;

public class FeatureNotEnabledException extends ErrorResponse {
    public FeatureNotEnabledException(String featureName) {
        this(featureName, StringUtils.EMPTY);
    }

    public FeatureNotEnabledException(String featureName, String message) {
        super(new Error()
            .setError(ErrorResponses.Codes.DISABLED)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(featureName))));
    }

}
