package com.nordea.dbf.featuretoggle;

public interface FeatureToggle {

    boolean enabled(Feature feature);

    default FeatureExecution on(Feature feature) {
        final boolean enabled = enabled(feature);

        return new FeatureExecution(feature, () -> enabled);
    }
}
