package com.nordea.dbf.filter;

import org.apache.commons.lang.Validate;

import java.time.LocalDate;
import java.util.Optional;

public class DateFilter implements Filter<LocalDate> {

    private final Optional<LocalDate> startDate;

    private final Optional<LocalDate> endDate;

    private DateFilter(Optional<LocalDate> startDate, Optional<LocalDate> endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }

    @Override
    public boolean accept(LocalDate instance) {
        if (instance == null) {
            return false;
        }

        if (startDate.isPresent()) {
            if (startDate.get().isAfter(instance)) {
                return false;
            }
        }

        if (endDate.isPresent()) {
            if (endDate.get().isBefore(instance)) {
                return false;
            }
        }

        return true;
    }

    public Optional<LocalDate> getStartDate() {
        return startDate;
    }

    public Optional<LocalDate> getEndDate() {
        return endDate;
    }

    public static DateFilter between(LocalDate startDate, LocalDate endDate) {
        Validate.notNull(startDate, "startDate can't be null");
        Validate.notNull(endDate, "endDate can't be null");
        Validate.isTrue(startDate.compareTo(endDate) <= 0, "startDate must be before endDate");

        return new DateFilter(Optional.of(startDate), Optional.of(endDate));
    }

    public static DateFilter after(LocalDate date) {
        Validate.notNull(date, "date can't be null");
        return new DateFilter(Optional.of(date), Optional.<LocalDate>empty());
    }

    public static DateFilter before(LocalDate date) {
        Validate.notNull(date, "date can't be null");
        return new DateFilter(Optional.<LocalDate>empty(), Optional.of(date));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DateFilter that = (DateFilter) o;

        if (!startDate.equals(that.startDate)) return false;
        return endDate.equals(that.endDate);

    }

    @Override
    public int hashCode() {
        int result = startDate.hashCode();
        result = 31 * result + endDate.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "DateFilter{" +
                "startDate=" + startDate +
                ", endDate=" + endDate +
                '}';
    }
}
