package com.nordea.dbf.filter;

import org.apache.commons.lang.Validate;

import java.time.LocalDate;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum DateFilterExpression implements FilterExpression<LocalDate, DateFilter> {

    BEFORE {

        private final Pattern PATTERN = Pattern.compile("(?:before\\()(\\d{4}(-\\d{2}(-\\d{2})?)?)(?:\\))");

        @Override
        public Optional<DateFilter> parse(String expression) {
            Validate.notNull(expression, "expression can't be null");

            final Matcher matcher = PATTERN.matcher(expression);

            if (!matcher.matches()) {
                return Optional.empty();
            }

            return Optional.of(DateFilter.before(LocalDate.parse(matcher.group(1))));
        }
    },
    BETWEEN {

        private final Pattern PATTERN = Pattern.compile("(?:between\\()(\\d{4}(?:-\\d{2}(?:-\\d{2})?)?)(?:,\\s*)(\\d{4}(?:-\\d{2}(?:-\\d{2})?)?)(?:\\))");

        @Override
        public Optional<DateFilter> parse(String expression) {
            Validate.notNull(expression, "expression can't be null");

            final Matcher matcher = PATTERN.matcher(expression);

            if (!matcher.matches()) {
                return Optional.empty();
            }

            return Optional.of(DateFilter.between(LocalDate.parse(matcher.group(1)), LocalDate.parse(matcher.group(2))));
        }
    },
    AFTER {

        private final Pattern PATTERN = Pattern.compile("(?:after\\()(\\d{4}(-\\d{2}(-\\d{2})?)?)(?:\\))");

        @Override
        public Optional<DateFilter> parse(String expression) {
            Validate.notNull(expression, "expression can't be null");

            final Matcher matcher = PATTERN.matcher(expression);

            if (!matcher.matches()) {
                return Optional.empty();
            }

            return Optional.of(DateFilter.after(LocalDate.parse(matcher.group(1))));
        }
    };


    @Override
    public Class<DateFilter> getFilterType() {
        return DateFilter.class;
    }

    @Override
    public Class<LocalDate> getValueType() {
        return LocalDate.class;
    }
}
