package com.nordea.dbf.filter;

import java.util.Objects;

public class EqualityFilter<T> implements Filter<T> {

    private final T expectedValue;

    public EqualityFilter(T expectedValue) {
        this.expectedValue = expectedValue;
    }

    @Override
    public boolean accept(T instance) {
        return Objects.equals(expectedValue, instance);
    }

    public T getExpectedValue() {
        return expectedValue;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EqualityFilter<?> that = (EqualityFilter<?>) o;

        return !(expectedValue != null ? !expectedValue.equals(that.expectedValue) : that.expectedValue != null);

    }

    @Override
    public int hashCode() {
        return expectedValue != null ? expectedValue.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "EqualityFilter{" +
                "expectedValue=" + expectedValue +
                '}';
    }
}
