package com.nordea.dbf.filter;

public interface Filter<T> {

    boolean accept(T instance);

}
