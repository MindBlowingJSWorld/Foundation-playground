package com.nordea.dbf.filter;

import java.util.Optional;

public interface FilterExpression<D, F extends Filter<D>> {

    Optional<F> parse(String expression);

    Class<F> getFilterType();

    Class<D> getValueType();

}
