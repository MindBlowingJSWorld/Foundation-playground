package com.nordea.dbf.filter;

import org.apache.commons.lang.Validate;

import java.util.List;
import java.util.Optional;

public class Filters {

    public static DateFilter dateFilterFrom(String string) {
        Validate.notEmpty(string, "string can't be null or empty");

        for (final DateFilterExpression expression : DateFilterExpression.values()) {
            final Optional<DateFilter> dateFilter = expression.parse(string);

            if (dateFilter.isPresent()) {
                return dateFilter.get();
            }
        }

        throw new IllegalArgumentException("Unsupported date filter expression '" + string + "'");
    }

    public static<T> ListFilter<T> listFilterOf(List<T> accounts) {
        return new ListFilter<>(accounts);
    }

    public static <T> Filter<T> equalTo(T value) {
        return new EqualityFilter<>(value);
    }
}
