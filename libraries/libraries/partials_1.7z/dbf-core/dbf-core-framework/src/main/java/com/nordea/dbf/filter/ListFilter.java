package com.nordea.dbf.filter;

import com.google.common.collect.ImmutableList;
import org.apache.commons.lang.Validate;

import java.util.List;

public class ListFilter<T> implements Filter<T> {

    private final List<T> values;

    public ListFilter(List<T> values) {
        Validate.notNull(values, "values can't be null");

        this.values = ImmutableList.copyOf(values);
    }

    public List<T> getValues() {
        return values;
    }

    @Override
    public boolean accept(T instance) {
        if (instance == null) {
            return false;
        }

        return values.contains(instance);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ListFilter<?> that = (ListFilter<?>) o;

        return values.equals(that.values);

    }

    @Override
    public int hashCode() {
        return values.hashCode();
    }

    @Override
    public String toString() {
        return "ListFilter{" +
                "values=" + values +
                '}';
    }
}
