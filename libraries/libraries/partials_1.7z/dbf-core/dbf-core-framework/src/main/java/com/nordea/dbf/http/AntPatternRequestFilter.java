package com.nordea.dbf.http;

import com.google.common.collect.ImmutableSet;
import com.nordea.dbf.util.PropertyConverter;
import org.apache.commons.lang.Validate;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import javax.servlet.http.HttpServletRequest;
import java.util.Collection;
import java.util.function.Predicate;

public class AntPatternRequestFilter implements Predicate<HttpServletRequest> {

    private final Collection<AntPathRequestMatcher> exclusions;

    private AntPatternRequestFilter(Collection<AntPathRequestMatcher> exclusions) {
        this.exclusions = exclusions;
    }

    @Override
    public boolean test(HttpServletRequest request) {
        for (AntPathRequestMatcher exclusion : exclusions) {
            if (exclusion.matches(request)) {
                return false;
            }
        }

        return true;
    }

    public static AntPatternRequestFilter from(String antExpression) {
        Validate.notEmpty(antExpression, "antExpression can't be null");

        final ImmutableSet.Builder<AntPathRequestMatcher> builder = ImmutableSet.builder();
        final String [] paths = PropertyConverter.splitPropertyOnPipe(antExpression);

        for (String antMatcherPattern : paths) {
            builder.add(new AntPathRequestMatcher(antMatcherPattern));
        }

        return new AntPatternRequestFilter(builder.build());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AntPatternRequestFilter that = (AntPatternRequestFilter) o;

        return exclusions.equals(that.exclusions);

    }

    @Override
    public int hashCode() {
        return exclusions.hashCode();
    }

    @Override
    public String toString() {
        return "AntPatternRequestFilter{" +
                "exclusions=" + exclusions +
                '}';
    }
}
