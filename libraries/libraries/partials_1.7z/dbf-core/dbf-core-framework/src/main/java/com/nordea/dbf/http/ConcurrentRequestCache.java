package com.nordea.dbf.http;

import org.apache.commons.lang.Validate;

import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * Simple cache implementation that applies locking only when values are being written.
 * Values are stored in a list, since a small number of values is typically cached.
 * The implementation will be fairly expensive if concurrent writes are made, since a
 * concurrent write operation will be completely retried in case of competing writes.
 * The DBF services - however - typically do not compete, since we're either (1) using single-threaded
 * operations or (2) reactive event-chains executing in different threads but serially.
 */
public class ConcurrentRequestCache implements RequestCache {

    private final AtomicReference<CacheEntry> head = new AtomicReference<>();

    public void clear() {
        head.set(null);
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T> T get(String key, Supplier<T> supplier) throws InterruptedException {
        Validate.notNull(key, "key can't be null");
        Validate.notNull(supplier, "supplier can't be null");

        CacheEntry previous = null;
        CacheEntry current = head.get();

        while (current != null) {
            if (current.name.equals(key)) {
                // Found a cache entry matching the cache key; use that
                break;
            }

            // Check the next node and keep a reference to the previous node so we can attach another
            // cache entry to the end if no matching cache entry exists
            previous = current;
            current = current.next.get();
        }

        if (current == null) {
            current = new CacheEntry(key);

            // Attempt to set the first element in the list (only occurs for the first cache entry)
            if (!head.compareAndSet(null, current)) {
                // attempt to append the cache entry to the end
                if (previous == null || !previous.next.compareAndSet(null, current)) {
                    // this means concurrent, competed writes; retry everything
                    return get(key, supplier);
                }
            }

            current.set(supplier.get());
        }

        return (T) current.get();
    }

    private static class CacheEntry {

        private final String name;

        private final AtomicReference<CacheEntry> next = new AtomicReference<>();

        private volatile Object value;

        public CacheEntry(String name) {
            this.name = name;
        }

        public void set(Object value) {
            synchronized (this) {
                this.value = value;
                notifyAll();
            }
        }

        public Object get() throws InterruptedException {
            if (value == null) {
                synchronized (this) {
                    while (value == null) {
                        wait();
                    }
                }
            }

            return value;
        }
    }
}
