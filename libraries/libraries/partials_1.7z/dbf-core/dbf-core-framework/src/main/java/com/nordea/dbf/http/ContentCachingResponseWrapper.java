package com.nordea.dbf.http;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ContentCachingResponseWrapper extends HttpServletResponseWrapper {

    final CachingOutputStream stream;

    public ContentCachingResponseWrapper(HttpServletResponse response) throws IOException {
        super(response);
        this.stream = new CachingOutputStream(response.getOutputStream());
    }

    public byte[] getCachedContent(){
        return stream.getCache().toByteArray();
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        return stream;
    }

    static class CachingOutputStream extends ServletOutputStream {

        final ByteArrayOutputStream cache = new ByteArrayOutputStream();
        final ServletOutputStream delegate;

        public CachingOutputStream(ServletOutputStream delegate) {
            this.delegate = delegate;
        }

        @Override
        public void write(int b) throws IOException {
            delegate.write(b);
            cache.write(b);
        }

        @Override
        public void write(byte[] b) throws IOException {
            delegate.write(b);
            cache.write(b);
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            delegate.write(b, off, len);
            cache.write(b, off, len);
        }

        @Override
        public boolean isReady() {
            return delegate.isReady();
        }

        @Override
        public void setWriteListener(WriteListener writeListener) {
            delegate.setWriteListener(writeListener);
        }

        @Override
        public void flush() throws IOException {
            delegate.flush();
        }

        @Override
        public void close() throws IOException {
            delegate.close();
        }

        @Override
        public void print(String s) throws IOException {
            delegate.print(s);
        }

        @Override
        public void println() throws IOException {
            delegate.println();
        }

        public ByteArrayOutputStream getCache() {
            return cache;
        }
    }

}
