package com.nordea.dbf.http;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

public final class DefaultHttpRequestDescriber implements HttpRequestDescriber {
    private static String loggableBearerAuthorizationValue(String value) {
        return value != null ? value.replaceAll("^Bearer.*", "Bearer <TOKEN>") : null;
    }

    @Override
    public String describe(HttpServletRequest instance) {
        final StringBuilder buffer = new StringBuilder();

        // Header
        buffer.append(instance.getMethod()).append(' ').append(instance.getRequestURI()).append(' ').append(instance.getProtocol()).append('\n');

        for (final Enumeration<String> headerNames = instance.getHeaderNames(); headerNames.hasMoreElements(); ) {
            final String headerName = headerNames.nextElement();

            buffer.append('\t').append(headerName).append(": ");

            for (final Enumeration<String> headerValues = instance.getHeaders(headerName); headerValues.hasMoreElements(); ) {
                buffer.append("Authorization".equals(headerName) ? loggableBearerAuthorizationValue(headerValues.nextElement()) : headerValues.nextElement());

                if (headerValues.hasMoreElements()) {
                    buffer.append(", ");
                }
            }

            if (headerNames.hasMoreElements()) {
                buffer.append('\n');
            }
        }
        return buffer.toString();
    }
}
