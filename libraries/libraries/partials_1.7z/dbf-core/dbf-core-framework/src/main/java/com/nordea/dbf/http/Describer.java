package com.nordea.dbf.http;

public interface Describer<T> {

    String describe(T instance);

}
