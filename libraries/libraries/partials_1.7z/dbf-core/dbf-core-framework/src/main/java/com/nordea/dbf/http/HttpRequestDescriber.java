package com.nordea.dbf.http;

import javax.servlet.http.HttpServletRequest;

public interface HttpRequestDescriber extends Describer<HttpServletRequest> {
}
