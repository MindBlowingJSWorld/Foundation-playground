package com.nordea.dbf.http;

import javax.servlet.http.HttpServletResponse;

public interface HttpResponseDescriber extends Describer<HttpServletResponse> {
}
