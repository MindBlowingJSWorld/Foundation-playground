package com.nordea.dbf.http;

import java.util.function.Supplier;

public interface RequestCache {

    RequestCache READ_THROUGH = new RequestCache() {
        @Override
        public <T> T get(String key, Supplier<T> supplier) throws InterruptedException {
            return supplier.get();
        }
    };

    <T> T get(String key, Supplier<T> supplier) throws InterruptedException;

}
