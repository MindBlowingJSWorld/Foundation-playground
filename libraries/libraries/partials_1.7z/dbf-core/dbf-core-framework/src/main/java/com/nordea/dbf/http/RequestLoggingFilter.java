package com.nordea.dbf.http;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Joiner;
import com.nordea.dbf.concurrent.Handover;
import com.nordea.dbf.concurrent.ThreadContext;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.util.StopWatch;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.AsyncEvent;
import javax.servlet.AsyncListener;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class RequestLoggingFilter extends OncePerRequestFilter {

    private final Logger logger = getLogger();

    private HttpRequestDescriber requestDescriber;

    private Predicate<HttpServletRequest> logFilter;

    private final ObjectWriter prettyJsonPrinter = new ObjectMapper().writerWithDefaultPrettyPrinter();

    public RequestLoggingFilter() {
    }

    public RequestLoggingFilter(HttpRequestDescriber requestDescriber, Predicate<HttpServletRequest> logFilter) {
        Validate.notNull(requestDescriber, "requestDescriber can't be null");
        Validate.notNull(logFilter, "logFilter can't be null");

        this.requestDescriber = requestDescriber;
        this.logFilter = logFilter;
    }

    @Override
    protected void initFilterBean() throws ServletException {
        super.initFilterBean();

        if (requestDescriber == null) {
            this.requestDescriber = WebApplicationContextUtils
                    .getRequiredWebApplicationContext(getServletContext())
                    .getBean(HttpRequestDescriber.class);
        }
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        fillRequestDetailsToMdc();
        if (!logFilter.test(request) || !logger.isDebugEnabled()) {
            try {
                filterChain.doFilter(request, response);
                return;
            }
            finally {
                MDC.clear();
            }
        }

        StopWatch sw = new StopWatch();
        sw.start();
        String requestDescription = requestDescriber.describe(request);
        logger.debug("Received HTTP request\n\t{}", requestDescription);

        final ContentCachingResponseWrapper wrappedResponse = new ContentCachingResponseWrapper(response);
        try {
            filterChain.doFilter(request, wrappedResponse);
        } finally {
            new ResponseCompletionLogger(request, requestDescription, wrappedResponse, sw).log();
            MDC.clear();
        }
    }

    private void fillRequestDetailsToMdc(){
        final Optional<ServiceRequestContext> requestContextOptional = ServiceRequestContextHolder.get();
        if (requestContextOptional.isPresent()) {

            final ServiceRequestContext requestContext = requestContextOptional.get();
            final Optional<String> requestId = requestContext.getRequestId();
            final Optional<String> sessionId = requestContext.getSessionId();
            final Optional<String> userId = requestContext.getUserId();
            final List<String> requestRoute = requestContext.getRequestRoute();

            MDC.put("clientIp", requestContext.getRemoteAddress());

            if (requestRoute.size() > 1) {
                MDC.put("proxy", Joiner.on("->").join(requestRoute.subList(1, requestRoute.size())));
            }

            if (requestId.isPresent()) {
                MDC.put("requestId", requestId.get());
            }

            if (sessionId.isPresent()) {
                MDC.put("sessionId", sessionId.get());
            }

            if (userId.isPresent()) {
                MDC.put("user", userId.get());
            }
        }
    }

    @VisibleForTesting
    protected Logger getLogger() {
        return LoggerFactory.getLogger(RequestLoggingFilter.class);
    }

    private class ResponseCompletionLogger implements Runnable, AsyncListener {
        private final HttpServletRequest request;
        private final String requestDescription;
        private final ContentCachingResponseWrapper responseWrapper;
        private final StopWatch watch;
        private Handover handover;
        public ResponseCompletionLogger(HttpServletRequest request, String requestDescription, ContentCachingResponseWrapper responseWrapper, StopWatch watch) {
            this.requestDescription = requestDescription;
            this.responseWrapper = responseWrapper;
            this.watch = watch;
            this.request = request;
        }

        public void log() {
            if (request.isAsyncStarted()) {
                handover = ThreadContext.DEFAULT.createHandover();
                request.getAsyncContext().addListener(this);
            } else {
                run();
            }
        }

        @Override
        public void run() {
            watch.stop();
            if (responseWrapper.getContentType()!=null && responseWrapper.getContentType().startsWith(MediaType.APPLICATION_JSON.toString())) {
                String bodyString = StringUtils.abbreviate(new String(responseWrapper.getCachedContent(), StandardCharsets.UTF_8), 1024);
                logger.debug("Completed HTTP request {} in {}ms with response: {}", StringUtils.substringBefore(requestDescription, "\n"), watch.getTotalTimeMillis(), bodyString);
            } else {
                logger.debug("Completed HTTP request {} in {}ms with response type: {}", StringUtils.substringBefore(requestDescription, "\n"), watch.getTotalTimeMillis(), responseWrapper.getContentType());
            }
        }

        @Override
        public void onComplete(AsyncEvent event) throws IOException {
            handover.in(this);
        }

        @Override
        public void onTimeout(AsyncEvent event) throws IOException {
            handover.in(this);
        }

        @Override
        public void onError(AsyncEvent event) throws IOException {
            handover.in(this);
        }

        @Override
        public void onStartAsync(AsyncEvent event) throws IOException {
        }
    }
}
