package com.nordea.dbf.http;

import com.nordea.dbf.model.http.DBFClientServiceRequestContext;
import com.nordea.dbf.model.http.DBFClientServiceRequestContextBuilder;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

public interface ServiceRequestContext {

    Optional<String> getApplicationId();

    Optional<String> getRequestId();

    Optional<String> getSessionId();

    Optional<String> getUserId();

    Optional<String> getAuthenticationMethod();

    Optional<String> getAuthenticationLevel();
    
    Optional<String> getAuthenticationToken();

    Optional<String> getChannelId();

    Optional<String> getCountry();

    Optional<Locale> getLanguage();

    Optional<Long> getAgreementNumber();

    String getRemoteAddress();

    long getTimeStamp();

    List<String> getRequestRoute();

    RequestCache getRequestCache();

    default DBFClientServiceRequestContext asDBFClientServiceRequestContext() {
      return new DBFClientServiceRequestContextBuilder().applicationId(getApplicationId().orElse(null)).channelId(getChannelId().orElse(null)).country(getCountry().orElse(null)).requestId(getRequestId().orElse(null)).sessionId(getSessionId().orElse(null)).timeStamp(getTimeStamp()).build();
    }
}
