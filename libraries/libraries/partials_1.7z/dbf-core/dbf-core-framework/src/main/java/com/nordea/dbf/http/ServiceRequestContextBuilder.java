package com.nordea.dbf.http;

import com.google.common.collect.ImmutableList;
import com.nordea.dbf.util.Optionals;
import org.apache.commons.lang.Validate;

import javax.validation.constraints.Size;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class ServiceRequestContextBuilder {

    private static final int GENERATED_ID_LENGTH = 10;
    private static final Random RANDOM = ThreadLocalRandom.current();
    private static final char[] SYMBOLS;

    static {
        StringBuilder tmp = new StringBuilder();
        for (char ch = '0'; ch <= '9'; ++ch) {
            tmp.append(ch);
        }
        for (char ch = 'a'; ch <= 'z'; ++ch) {
            tmp.append(ch);
        }
        SYMBOLS = tmp.toString().toCharArray();
    }

    private String applicationId;
    private String requestId;
    private String sessionId;
    private String userId;
    private String authenticationMethod;
    private String authenticationLevel;
    private String authenticationToken;
    private List<String> requestRoute;
    private String channelId;
    private String country;
    private Locale language;
    private Long agreementNumber;
    private long timeStamp = -1L;
    private RequestCache requestCache = RequestCache.READ_THROUGH;

    public ServiceRequestContextBuilder applicationId(String applicationId) {
        this.applicationId = applicationId;
        return this;
    }

    public ServiceRequestContextBuilder requestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public ServiceRequestContextBuilder sessionId(String sessionId) {
        this.sessionId = sessionId;
        return this;
    }

    public ServiceRequestContextBuilder userId(String userId) {
        this.userId = userId;
        return this;
    }

    public ServiceRequestContextBuilder authenticationMethod(String authenticationMethod) {
        this.authenticationMethod = authenticationMethod;
        return this;
    }

    public ServiceRequestContextBuilder authenticationLevel(String authenticationLevel) {
        this.authenticationLevel = authenticationLevel;
        return this;
    }

    public ServiceRequestContextBuilder authenticationToken(String authenticationToken) {
        this.authenticationToken = authenticationToken;
        return this;
    }

    public ServiceRequestContextBuilder channelId(String channelId) {
        this.channelId = channelId;
        return this;
    }

    public ServiceRequestContextBuilder country(String country) {
        this.country = country;
        return this;
    }

    public ServiceRequestContextBuilder language(Locale language) {
        this.language = language;
        return this;
    }

    public ServiceRequestContextBuilder agreementNumber(Long agreementNumber) {
        this.agreementNumber = agreementNumber;
        return this;
    }

    public ServiceRequestContextBuilder timeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
        return this;
    }

    public ServiceRequestContextBuilder requestRoute(List<String> requestRoute) {
        this.requestRoute = requestRoute == null ? null : ImmutableList.copyOf(requestRoute);
        return this;
    }

    public ServiceRequestContextBuilder requestCache(RequestCache requestCache) {
        Validate.notNull(requestCache, "requestCache can't be null");
        this.requestCache = requestCache;
        return this;
    }

    public ServiceRequestContext build() {
        if (requestId == null) {
            requestId = generateId();
        }

        if (timeStamp == -1L) {
            timeStamp = System.currentTimeMillis();
        }

        return new ServiceRequestContextImpl(Optional.ofNullable(applicationId),
                Optional.ofNullable(requestId),
                Optional.ofNullable(sessionId),
                Optional.ofNullable(userId),
                Optional.ofNullable(authenticationMethod),
                Optional.ofNullable(authenticationLevel),
                Optional.ofNullable(authenticationToken),
                Optional.ofNullable(channelId),
                Optional.ofNullable(country),
                Optional.ofNullable(language),
                Optional.ofNullable(agreementNumber),
                requestRoute, timeStamp < 0L ? System.currentTimeMillis() : timeStamp,
                requestCache);
    }

    /**
     * Generate an ID suitable to be handled as requestId. The reason we have an internal/manual
     * generation of a random string (instead of generating UUID, for instance) is that it need to
     * be of maximum 10 characters to be compatible with underlying backend systems.
     *
     * @return a generated ID
     */
    String generateId() {
        char[] buf = new char[GENERATED_ID_LENGTH];
        for (int idx = 0; idx < buf.length; ++idx) {
            buf[idx] = SYMBOLS[RANDOM.nextInt(SYMBOLS.length)];
        }
        return new String(buf);
    }

    private static final class ServiceRequestContextImpl implements ServiceRequestContext {

        @Size(max=10)
        private final Optional<String> applicationId;

        @Size(max=20)
        private final Optional<String> requestId;

        @Size(max=56)
        private final Optional<String> sessionId;

        @Size(max=22)
        private final Optional<String> userId;

        @Size(max=10)
        private final Optional<String> authenticationMethod;

        @Size(max=10)
        private final Optional<String> authenticationLevel;

        private final Optional<String> authenticationToken;

        @Size(max=10)
        private final Optional<String> channel;

        @Size(max=10)
        private final Optional<String> country;

        private final Optional<Locale> language;

        private final Optional<Long> agreementNumber;

        private final List<String> requestRoute;

        private final long timeStamp;

        private final RequestCache requestCache;

        public ServiceRequestContextImpl(Optional<String> applicationId, Optional<String> requestId,
                                         Optional<String> sessionId,
                                         Optional<String> userId,
                                         Optional<String> authenticationMethod,
                                         Optional<String> authenticationLevel,
                                         Optional<String> authenticationToken,
                                         Optional<String> channelId,
                                         Optional<String> country,
                                         Optional<Locale> language,
                                         Optional<Long> agreementNumber,
                                         List<String> requestRoute,
                                         long timeStamp, RequestCache requestCache) {
            this.applicationId = applicationId;
            this.requestId = requestId;
            this.sessionId = sessionId;
            this.userId = userId;
            this.authenticationMethod = authenticationMethod;
            this.authenticationLevel = authenticationLevel;
            this.authenticationToken = authenticationToken;
            this.channel = channelId;
            this.country = country;
            this.language = language;
            this.agreementNumber = agreementNumber;
            this.requestRoute = requestRoute != null ? requestRoute : Collections.EMPTY_LIST;
            this.timeStamp = timeStamp;
            this.requestCache = requestCache;
        }


        @Override
        public Optional<String> getApplicationId() {
            return applicationId;
        }

        @Override
        public Optional<String> getRequestId() {
            return requestId;
        }

        @Override
        public Optional<String> getSessionId() {
            return sessionId;
        }

        @Override
        public Optional<String> getUserId() {
            return userId;
        }

        @Override
        public Optional<String> getAuthenticationMethod() {
            return authenticationMethod;
        }

        @Override
        public Optional<String> getAuthenticationLevel() {
            return authenticationLevel;
        }

        @Override
        public Optional<String> getAuthenticationToken() {
            return authenticationToken;
        }

        @Override
        public Optional<String> getChannelId() {
            return channel;
        }

        @Override
        public Optional<String> getCountry() {
            return country;
        }

        @Override
        public Optional<Locale> getLanguage() {
            return language;
        }

        @Override
        public String getRemoteAddress() {
            return getRequestRoute().stream().findFirst().orElse(null);
        }

        @Override
        public long getTimeStamp() {
            return timeStamp;
        }

        @Override
        public List<String> getRequestRoute() {
            return requestRoute;
        }

        @Override
        public RequestCache getRequestCache() {
            return requestCache;
        }

        @Override
        public Optional<Long> getAgreementNumber() {
            return agreementNumber;
        }


        @Override
        public boolean equals(Object o) {
            if (this == o)
                return true;
            if (o == null || getClass() != o.getClass())
                return false;

            ServiceRequestContextImpl that = (ServiceRequestContextImpl) o;

            if (timeStamp != that.timeStamp)
                return false;
            if (agreementNumber != null ? !agreementNumber.equals(that.agreementNumber) : that.agreementNumber != null)
                return false;
            if (applicationId != null ? !applicationId.equals(that.applicationId) : that.applicationId != null)
                return false;
            if (authenticationLevel != null ? !authenticationLevel.equals(that.authenticationLevel) : that.authenticationLevel != null)
                return false;
            if (authenticationMethod != null ? !authenticationMethod.equals(that.authenticationMethod) : that.authenticationMethod != null)
                return false;
            if (channel != null ? !channel.equals(that.channel) : that.channel != null)
                return false;
            if (country != null ? !country.equals(that.country) : that.country != null)
                return false;
            if (language != null ? !language.equals(that.language) : that.language != null)
                return false;
            if (requestId != null ? !requestId.equals(that.requestId) : that.requestId != null)
                return false;
            if (requestRoute != null ? !requestRoute.equals(that.requestRoute) : that.requestRoute != null)
                return false;
            if (sessionId != null ? !sessionId.equals(that.sessionId) : that.sessionId != null)
                return false;
            if (userId != null ? !userId.equals(that.userId) : that.userId != null)
                return false;

            return true;
        }

        @Override
        public int hashCode() {
            int result = applicationId != null ? applicationId.hashCode() : 0;
            result = 31 * result + (requestId != null ? requestId.hashCode() : 0);
            result = 31 * result + (sessionId != null ? sessionId.hashCode() : 0);
            result = 31 * result + (userId != null ? userId.hashCode() : 0);
            result = 31 * result + (authenticationMethod != null ? authenticationMethod.hashCode() : 0);
            result = 31 * result + (authenticationLevel != null ? authenticationLevel.hashCode() : 0);
            result = 31 * result + (channel != null ? channel.hashCode() : 0);
            result = 31 * result + (country != null ? country.hashCode() : 0);
            result = 31 * result + (language != null ? language.hashCode() : 0);
            result = 31 * result + (agreementNumber != null ? agreementNumber.hashCode() : 0);
            result = 31 * result + (requestRoute != null ? requestRoute.hashCode() : 0);
            result = 31 * result + (int) (timeStamp ^ (timeStamp >>> 32));
            return result;
        }

        @Override
        public String toString() {
            return "ServiceRequestContextImpl{" +
                    "applicationId=" + Optionals.toString(applicationId) +
                    ", requestId=" + Optionals.toString(requestId) +
                    ", sessionId=" + Optionals.toString(sessionId) +
                    ", userId=" + Optionals.toString(userId) +
                    ", authenticationMethod=" + Optionals.toString(authenticationMethod) +
                    ", authenticationLevel=" + Optionals.toString(authenticationLevel) +
                    ", channelId=" + Optionals.toString(channel) +
                    ", country=" + Optionals.toString(country) +
                    ", language=" + Optionals.toString(language) +
                    ", agreementNumber=" + Optionals.toString(agreementNumber) +
                    ", requestRoute=" + requestRoute +
                    ", timeStamp=" + timeStamp +
                    "}";

        }

    }
}
