package com.nordea.dbf.http;

import com.nordea.dbf.http.contextappender.ServiceRequestContextAppender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * A Filter to build service request context with a set of appenders provided as indepenedent Spring beans.
 */
public class ServiceRequestContextFilter extends OncePerRequestFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceRequestContextFilter.class);

    @Autowired
    private List<ServiceRequestContextAppender> serviceRequestContextAppenders;


    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            ServiceRequestContextHolder.bind(appendDetails(request).build());
            filterChain.doFilter(request, response);
        } finally {
            ServiceRequestContextHolder.clear();
            LOGGER.trace("Service request context filter finalized filter chain. Service request context cleared.");
        }
    }

    protected ServiceRequestContextBuilder appendDetails(HttpServletRequest request){
        ServiceRequestContextBuilder builder = new ServiceRequestContextBuilder();
        serviceRequestContextAppenders.forEach(appender -> appender.append(request, builder));
        return builder;
    }

    public void setServiceRequestContextAppenders(List<ServiceRequestContextAppender> serviceRequestContextAppenders) {
        this.serviceRequestContextAppenders = serviceRequestContextAppenders;
    }
}
