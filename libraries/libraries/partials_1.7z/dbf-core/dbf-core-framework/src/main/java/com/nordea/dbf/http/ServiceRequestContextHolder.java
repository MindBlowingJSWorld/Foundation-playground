package com.nordea.dbf.http;

import org.apache.commons.lang.Validate;

import java.util.Optional;

public final class ServiceRequestContextHolder {

    private static final ThreadLocal<ServiceRequestContext> THREAD_LOCAL = new ThreadLocal<>();

    private ServiceRequestContextHolder() {
    }

    public static Optional<ServiceRequestContext> get() {
        return Optional.ofNullable(THREAD_LOCAL.get());
    }

    public static void bind(ServiceRequestContext requestContext) {
        Validate.notNull(requestContext, "requestContext can't be null");

        final ServiceRequestContext existingRequestContext = THREAD_LOCAL.get();

        if (existingRequestContext != null) {
            throw new IllegalStateException("Request context already configured for request \""
                    + existingRequestContext + "\". in thread  \"" +Thread.currentThread()+ "\". Can't bind request \"" + requestContext + "\"");
        }
        THREAD_LOCAL.set(requestContext);
    }

    public static void clear() {
        THREAD_LOCAL.remove();
    }
}
