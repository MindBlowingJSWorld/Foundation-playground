package com.nordea.dbf.http.contextappender;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.http.ServiceRequestContextBuilder;
import com.nordea.dbf.model.http.DBFClientServiceRequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.security.access.AccessDeniedException;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.function.Predicate;

import static org.apache.commons.lang.StringUtils.isEmpty;
import static org.apache.commons.lang.StringUtils.isNotEmpty;

@Order(3)
public class ClientRequestContextAppender implements ServiceRequestContextAppender {
    public static final String CLIENT_CONTEXT_HEADER_NAME = "X-DBF-ServiceRequestContext";
    private static final Logger LOGGER = LoggerFactory.getLogger(ClientRequestContextAppender.class);
    private final Predicate<HttpServletRequest> anonymousPathFilter;

    private final ObjectMapper forgivingObjectMapper;

    public ClientRequestContextAppender(Predicate<HttpServletRequest> anonymousPathFilter) {
        this.anonymousPathFilter = anonymousPathFilter;

        this.forgivingObjectMapper = new ObjectMapper();
        this.forgivingObjectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    }

    @Override
    public void append(HttpServletRequest request, ServiceRequestContextBuilder builder) {
        DBFClientServiceRequestContext clientContext =
                deserializeClientContext(request.getHeader(CLIENT_CONTEXT_HEADER_NAME));

        //if path is anonymous and client context header value is not present then client context is not needed.
        // anonymousPathFilter.test() returns false if the request is excluded as anonymous, therefore the negation.
        if (!anonymousPathFilter.test(request) && clientContext == null) {
            return;
        }

        failOnCondition(clientContext == null, "Client context header required, but not found.", request.getContextPath());
        // Fail if required and not failOnCondition
        failOnCondition(isEmpty(clientContext.getApplicationId()), "ApplicationId must be set in client context", request.getContextPath());
        failOnCondition(isEmpty(clientContext.getCountry()), "Country must be set in client context", request.getContextPath());
        failOnCondition(isEmpty(clientContext.getChannelId()), "ChannelId must be set in client context", request.getContextPath());

        LOGGER.debug("Valid client context header found: {}. Appending to service request context.", clientContext);

        builder.country(clientContext.getCountry());
        builder.channelId(clientContext.getChannelId());
        builder.applicationId(clientContext.getApplicationId());
        builder.sessionId(clientContext.getSessionId());

        if (isNotEmpty(clientContext.getRequestId())) {
            builder.requestId(clientContext.getRequestId());
        }

        if (clientContext.getTimeStamp() > 0) {
            builder.timeStamp(clientContext.getTimeStamp());
        }
    }

    private void failOnCondition(boolean invalid, String message, String resourcePath) {
        if (invalid) {
            LOGGER.info("Unauthorized access attempt to resource " + resourcePath + " caused by " + message);
            throw new AccessDeniedException("Header " + CLIENT_CONTEXT_HEADER_NAME + " was not valid: " + message);
        }
    }

    private DBFClientServiceRequestContext deserializeClientContext(String json) {
        if (isEmpty(json)) {
            return null;
        }

        try {
            return forgivingObjectMapper.readValue(json, DBFClientServiceRequestContext.class);
        } catch (IOException e) {
            throw new IllegalArgumentException("Failed to deserialize client context: " + json, e);
        }
    }
}
