package com.nordea.dbf.http.contextappender;

import com.nordea.dbf.http.ServiceRequestContextBuilder;
import org.springframework.core.annotation.Order;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.apache.commons.lang.StringUtils.isEmpty;

@Order(1)
public class LanguageAppender implements ServiceRequestContextAppender {

    public static final Pattern HTTP_LANGUAGE_PATTERN = Pattern.compile("(?<language>\\w{2})(-(?<country>\\w{2}))?");

    @Override
    public void append(HttpServletRequest request, ServiceRequestContextBuilder builder) {
        final String language = request.getHeader("Accept-Language");

        if (isEmpty(language)) {
            return;
        }

        final Matcher matcher = HTTP_LANGUAGE_PATTERN.matcher(language);

        if (matcher.lookingAt()) {
            final String httpLanguage = matcher.group("language");
            final String httpCountry = matcher.group("country");

            final Locale locale;

            if (httpCountry != null) {
                locale = new Locale(httpLanguage, httpCountry);
            } else {
                locale = new Locale(httpLanguage);
            }

            builder.language(locale);
        }
    }
}
