package com.nordea.dbf.http.contextappender;

import com.nordea.dbf.http.ServiceRequestContextBuilder;
import org.apache.commons.lang.StringUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * Request id appender to be used when request id is sent separately in X-Request-Id header instead of as a part of
 * service request context json header.
 */
public class RequestIdAppender implements ServiceRequestContextAppender {
    private final String requestIdHeaderName;

    public RequestIdAppender(String requestIdHeaderName) {
        this.requestIdHeaderName = requestIdHeaderName;
    }

    @Override
    public void append(HttpServletRequest request, ServiceRequestContextBuilder builder) {
        String requestId = request.getHeader(requestIdHeaderName);
        if(StringUtils.isNotEmpty(requestId)) {
            builder.requestId(requestId);
        }
    }
}
