package com.nordea.dbf.http.contextappender;

import com.nordea.dbf.http.ServiceRequestContextBuilder;
import org.springframework.core.annotation.Order;

import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.apache.commons.lang.StringUtils.isEmpty;

@Order(2)
public class RequestRouteAppender implements ServiceRequestContextAppender {

    public static final String X_FORWARDED_FOR = "X-Forwarded-For";

    @Override
    public void append(HttpServletRequest request, ServiceRequestContextBuilder builder) {
        final List<String> route = new LinkedList<>();
        final String forwardedFor = request.getHeader(X_FORWARDED_FOR);

        if (!isEmpty(forwardedFor)) {
            route.addAll(Arrays.asList(forwardedFor.split(",\\s*")));
        }

        route.add(request.getRemoteAddr());

        builder.requestRoute(route);
    }
}
