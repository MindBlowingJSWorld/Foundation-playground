package com.nordea.dbf.http.contextappender;

import com.nordea.dbf.http.ServiceRequestContextBuilder;

import javax.servlet.http.HttpServletRequest;

public interface ServiceRequestContextAppender {
    void append(HttpServletRequest request, ServiceRequestContextBuilder builder);
}
