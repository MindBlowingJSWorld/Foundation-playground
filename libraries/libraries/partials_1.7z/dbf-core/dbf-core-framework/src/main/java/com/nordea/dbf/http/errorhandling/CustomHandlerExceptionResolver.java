package com.nordea.dbf.http.errorhandling;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CustomHandlerExceptionResolver implements HandlerExceptionResolver, Ordered {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomHandlerExceptionResolver.class);

    private MappingJackson2JsonView jsonView = new MappingJackson2JsonView();

    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        jsonView.setExtractValueFromSingleKeyModel(true);
        LOGGER.error(ex.getMessage(), ex);
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

        final Error error;

        if (ex instanceof ErrorResponse) {
            error = ((ErrorResponse) ex).getErrorResponse();
        } else {
            error = new Error().setError(ErrorResponses.Codes.UNKNOWN).setErrorDescription(ex.getMessage());
        }

        return new ModelAndView(jsonView, "error", error);
    }

    @Override
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }
}
