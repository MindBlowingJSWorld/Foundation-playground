package com.nordea.dbf.http.errorhandling;

import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.http.errorhandling.exception.*;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.Optional;

import com.nordea.dbf.api.model.Error;

public class ErrorResponses {
    private static final String ERROR_PREFIX = "error_core_";

    public interface Types {

         /**
          * Signifies that something is wrong with the client request, e.g. invalid method or parameter
          * value. The error code defines more specifically what was wrong.
          */
         String BAD_REQUEST = "bad_request";

         /**
          * Signifies that something was wrong with the token in the context of the request. For example,
          * the user id or agreement was not valid in the context of the request (e.g. does not exist
          * in the dependent system).
          */
         String INVALID_AUTHENTICATION = "invalid_authentication";

         /**
          * Signifies that the desired entity wasn't found.
          */
         String NOT_FOUND = "not_found";

         /**
          * Signifies that an internal server error has occurred.
          */
         String INTERNAL_SERVER_ERROR = "internal_server_error";

         /**
          * Signifies that an error has occured in the backend.
          */
         String BACKEND_ERROR = "backend_error";

         /**
          * Specifies that the operation requires signing. The sub-type specifies more about
          * how the error should be handled.
          */
         String CONFIRMATION_REQUIRED = "sign_required";

         /**
          * Specifies that a necessary pre-condition for the operation was not met. Pre-conditions specified by RFC 2616 as these:
          * <ul>
          *     <li>If-Match
          *     <li>If-Modified-Since
          *     <li>If-None-Match
          *     <li>If-Range
          *     <li>If-Unmodified-Since
          * </ul> The sub-type specifies more about how the error should be handled.
          */
        String PRECONDITION_FAILED = "precondition_failed";
     }

    public interface Codes {

        /**
         * Signifies that a field has an incorrect value.
         */
        String INVALID_FIELD = ERROR_PREFIX + "invalid_field";

        /**
         * A timeout has occurred. The "field" in the error response should contain the dependent system.
         */
        String TIMEOUT = ERROR_PREFIX + "timeout";

        /**
         * The cause of the exception is not known.
         */
        String UNKNOWN = ERROR_PREFIX + "unknown";

        /**
         * The request was not understood.
         */
        String NOT_UNDERSTOOD = ERROR_PREFIX + "not_understood";

        /**
         * Signifies that the desired entity wasn't found.
         */
        String NOT_FOUND = ERROR_PREFIX + "not_found";

        /**
         * Signifies that a database error has occured in the backend.
         */
        String DATABASE_ERROR = ERROR_PREFIX + "database_error";

        /**
         * User was not authorized to access a resource.
         */
        String UNAUTHORIZED = ERROR_PREFIX + "unauthorized";

        /**
         * A pre-required operation has not yet completed. Typically, sign_required+incomplete
         * means that a sign is initiated but not yet completed.
         */
        String INCOMPLETE = ERROR_PREFIX + "incomplete";

        /**
         * Operation was cancelled.
         */
        String CANCELLED = ERROR_PREFIX + "cancelled";

        /**
         * Operation failed.
         */
        String FAILED = ERROR_PREFIX + "failed";

        String DISABLED = ERROR_PREFIX + "disabled";

    }

    /**
     * Returns an error response that signifies that the contents of the token is trusted but not
     * valid. Typical example is if a user id or agreement number was not found in a dependant system.
     *
     * @param field The authentication field that was not accepted
     * @param value The field value that was not acceptable.
     * @return An error response instance signifying invalid trusted authentication.
     */
    public static Error invalidAuthentication(String field, Object value) {
        return new Error()
                .setError(Types.INVALID_AUTHENTICATION)
                .setErrorDescription("The authentication field is not acceptable")
                .setDetails(Arrays.asList(new ErrorDetails().setParam(String.valueOf(field))));
    }

    public static Error requestNotUnderstood(String message, Optional<String> field) {
        return new Error()
            .setError(Codes.NOT_UNDERSTOOD)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(field.orElse(StringUtils.EMPTY))));
    }

    /**
     * Creates an error response designating some invalid input. Typical example is an account number that
     * represents an invalid resource.
     *
     * @param parameterName The name of the parameter that was invalid.
     * @param message A message that should be displayed to the client.
     * @return An error response representing the error.
     */
    public static Error invalidRequestParameter(String parameterName, String message) {
        return new Error()
            .setError(Codes.INVALID_FIELD)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(parameterName)));
    }

    /**
     * Returns a throwable exception representing invalid user input.
     *
     * @param parameterName The name of the parameter that was invalid.
     * @param message A descriptive message.
     * @return An exception that can be thrown in response to the invalid parameter value.
     */
    public static BadRequestException invalidRequestParameterException(String parameterName, String message) {
        return new BadRequestException(invalidRequestParameter(parameterName, message));
    }

    /**
     * Creates an error response designating not met pre-condition. Typical example is an If-Match header that
     * dosn't match.
     *
     * @param parameterName The name of the parameter that was invalid.
     * @param message A message that should be displayed to the client.
     * @return An error response representing the error.
     */
    public static Error preconditionFailed(String parameterName, String message) {
        return new Error()
            .setError(Codes.FAILED)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(parameterName)));
    }

    /**
     * Returns a throwable exception representing pre-condition failed.
     *
     * @param parameterName The name of the parameter that was invalid.
     * @param message A descriptive message.
     * @return An exception that can be thrown in response to the invalid parameter value.
     */
    public static PreconditionFailedException preconditionFailedException(String parameterName, String message) {
        return new PreconditionFailedException(invalidRequestParameter(parameterName, message));
    }

    /**
     * Returns an error code indicating that a resource was not found. This is a bad request since
     * the client requested a resource that does not exist.
     *
     * @param parameterName The parameterName identifying the resource.
     * @param message A descriptive message.
     * @return An error response describing the error.
     */
    public static Error requestedResourceNotFound(String parameterName, String message) {
        return new Error()
            .setError(Codes.NOT_FOUND)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(parameterName)));
    }

    /**
     * Returns a throwable exception that indicates that a requested resource could not be found.
     *
     * @param parameterName The name of the parameter identifying the resource.
     * @param message A descriptive message.
     * @return An exception that can be thrown in response to the erroneous request.
     */
    public static NotFoundException requestedResourceNotFoundException(String parameterName, String message) {
        return new NotFoundException(requestedResourceNotFound(parameterName, message));
    }

    /**
     * Error response signaling an error in a dependent system. For instance, if a database error occurs
     * in the main-frame.
     *
     * @param code The error code detailing the type of the backend error.
     * @param serviceName The name of the service that failed, e.g. IMS, FQ or whatever descriptive name exists for the service.
     * @param message A descriptive message.
     * @return An error response describing the error.
     */
    public static Error backendError(String code, String serviceName, String message) {
        return new Error()
            .setError(code)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(serviceName)));
    }

    /**
     * Returns a throwable exception that can be thrown in response to a backend error.
     *
     * @param code The error code.
     * @param serviceName The service name.
     * @param message The message of the exception.
     * @return A throwable error.
     */
    public static BackendException backendErrorException(String code, String serviceName, String message) {
        return new BackendException(backendError(code, serviceName, message));
    }

    /**
     * Returns an error response that denotes a timeout.
     *
     * @param serviceName The name of the service that timed out.
     * @param message An informative message.
     * @return An <code>Error</code> representing the timeout.
     */
    public static Error backendTimeout(String serviceName, String message) {
        return new Error()
            .setError(Codes.TIMEOUT)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(serviceName)));
    }

    public static BackendException backendTimeoutException(String serviceName, String message) {
        return new BackendException(backendTimeout(serviceName, message));
    }

    /**
     * A confirmation is in progress. The operation will complete when the user has successfully signed
     * the request but has not done that yet so the operation did not continue.
     *
     * @param orderId The orderId of the signing process instance.
     * @param message A message to the consumer.
     * @return An error response representing the error.
     */
    public static Error confirmationInProgress(String orderId, String message) {
        return new Error()
            .setError(Codes.INCOMPLETE)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam("OrderId: " + orderId)));
    }

    public static ConfirmationInProgressException confirmationInProgressException(String orderId, String message) {
        return new ConfirmationInProgressException(confirmationInProgress(orderId, message));
    }

    /**
     * A confirmation operation failed. This occurs when a signing process is initiated but failed
     * while or prior to polling the operation for continuation. This should make the client stop polling the signing
     * process and abandon the operation.
     *
     * @param orderId The orderId of the signing process instance.
     * @param message A message displayed to the consumer-
     * @return An error response representing the confirmation failure.
     */
    public static Error confirmationFailed(String orderId, String message) {
        return new Error()
            .setError(Codes.FAILED)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam("OrderId: " + orderId)));
    }

    public static ConfirmationFailedException confirmationFailedException(String orderId, String message) {
        return new ConfirmationFailedException(confirmationFailed(orderId, message));
    }

    /**
     * A confirmation operation was cancelled. This occurs when a signing process is initiated but cancelled
     * while polling the operation for continuation. This should make the client stop polling the signing
     * process and abandon the operation.
     *
     * @param orderId The orderId of the signing process instance.
     * @param message A message displayed to the consumer-
     * @return An error response representing the confirmation cancellation.
     */
    public static Error confirmationCancelled(String orderId, String message) {
        return new Error()
            .setError(Codes.CANCELLED)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam("OrderId: " + orderId)));
    }

    public static ConfirmationCancelledException confirmationCancelledException(String orderId, String message) {
        return new ConfirmationCancelledException(confirmationCancelled(orderId, message));
    }

    public static Error unauthorizedAccess(String message, String param) {
        return new Error()
            .setError(Codes.UNAUTHORIZED)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(param)));
    }

    public static UnauthorizedException unauthorizedAccessException(String message, String param) {
        return new UnauthorizedException(unauthorizedAccess(message, param));
    }

    public static Error internalError(String message, String param) {
        return new Error()
            .setError(Codes.UNKNOWN)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(param)));
    }

    public static InternalServerErrorException internalErrorException(String message, String param) {
        return new InternalServerErrorException(internalError(message, param));
    }
}
