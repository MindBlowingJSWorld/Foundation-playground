package com.nordea.dbf.http.errorhandling;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.featuretoggle.FeatureNotEnabledException;
import com.nordea.dbf.http.errorhandling.exception.*;
import com.nordea.dbf.json.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.TypeMismatchException;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.multiaction.NoSuchRequestHandlingMethodException;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.file.AccessDeniedException;
import java.util.Arrays;
import java.util.Optional;


import com.nordea.dbf.api.model.Error;


/**
 * Global exception handler that maps exceptions to a HTTP response with the proper response code and a dbf api compliant error response
 * message.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private MappingJackson2JsonView jsonView = new MappingJackson2JsonView();

    // Gotta catch 'em all
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(value = Exception.class)
    public ModelAndView defaultErrorHandler(HttpServletRequest req, Exception e) throws Exception {
        jsonView.setExtractValueFromSingleKeyModel(true);
        LOGGER.error(e.getMessage(), e);

        final Error error;

        if (e instanceof ErrorResponse) {
            error = ((ErrorResponse) e).getErrorResponse();
        } else {
            error = new Error().setError(ErrorResponses.Codes.UNKNOWN).setErrorDescription(e.getMessage());
        }

        return new ModelAndView(jsonView, "error", error);
    }

    @ExceptionHandler(GenericServiceResponseException.class)
    public ModelAndView handleGenericServiceResponseException(HttpServletRequest request, HttpServletResponse response, GenericServiceResponseException exception) {
        final MappingJackson2JsonView jsonView = new MappingJackson2JsonView();
        response.setStatus(exception.getStatus());

        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ExceptionHandler({MissingServletRequestParameterException.class, ServletRequestBindingException.class, TypeMismatchException.class,  MissingServletRequestPartException.class, BindException.class})
    public ModelAndView handleSpringExceptions(FeatureNotEnabledException exception) {
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(FeatureNotEnabledException.class)
    public ModelAndView handleFeatureNotEnabled(FeatureNotEnabledException exception) {
        return createModelAndView(exception);
    }

    // TODO: Shouldn't this be .FORBIDDEN instead ?
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(SecurityException.class)
    public ModelAndView handleSecurityException(HttpServletRequest request, Exception exception) {
        final MappingJackson2JsonView jsonView = new MappingJackson2JsonView();
        return new ModelAndView(jsonView, "error", new Error()
                .setError(ErrorResponses.Codes.UNAUTHORIZED)
                .setErrorDescription("not authorized to access resource"));
    }

    @ResponseStatus(value = HttpStatus.ACCEPTED)
    @ExceptionHandler(AcceptedException.class)
    public ModelAndView handleAcceptedException(HttpServletRequest req, Exception exception) {
        LOGGER.debug(exception.getMessage(), exception);
        final MappingJackson2JsonView jsonView = new MappingJackson2JsonView();
        jsonView.setExtractValueFromSingleKeyModel(true);

        Optional<Object> objectOptional = ((AcceptedException) exception).getObject();
        if (objectOptional.isPresent()) {
            return new ModelAndView(jsonView, "result", objectOptional.get());
        } else {
            return new ModelAndView(jsonView);
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @ExceptionHandler(ConfirmationInProgressException.class)
    public ModelAndView handleConfirmationInProgress(HttpServletRequest req, Exception exception) {
        LOGGER.debug(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.METHOD_NOT_ALLOWED)
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ModelAndView handleMethodNotAllowed(HttpServletRequest req, Exception exception) {
        LOGGER.debug(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.UNSUPPORTED_MEDIA_TYPE)
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ModelAndView handleHttpMediaTypeNotSupportedException(HttpServletRequest req, Exception exception) {
        LOGGER.debug(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.NOT_ACCEPTABLE)
    @ExceptionHandler(HttpMediaTypeNotAcceptableException.class)
    public ModelAndView handleHttpMediaTypeNotAcceptableException(HttpServletRequest req, Exception exception) {
        LOGGER.debug(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    @ExceptionHandler({NotFoundException.class, NoSuchRequestHandlingMethodException.class, NoHandlerFoundException.class})
    public ModelAndView handleNotFound(HttpServletRequest req, Exception exception) {
        LOGGER.debug(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(BadRequestException.class)
    public ModelAndView handleBadRequest(HttpServletRequest req, Exception exception) {
        LOGGER.debug(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.PRECONDITION_FAILED)
    @ExceptionHandler(PreconditionFailedException.class)
    public ModelAndView handlePreconditionFailed(HttpServletRequest req, Exception exception) {
        LOGGER.debug(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ModelAndView handleHttpMessageNotReadableException(HttpServletRequest req, Exception exception) {
        jsonView.setExtractValueFromSingleKeyModel(true);
        LOGGER.warn(exception.getMessage(), exception);
        Throwable exceptionCause = exception.getCause();
        Error error;
        if (exceptionCause instanceof JsonParseException) {
            error = new Error().setError("error_core_json_parsing_error")
                .setErrorDescription( ((JsonParseException) exceptionCause).getOriginalMessage());
        } else if (exceptionCause instanceof UnrecognizedPropertyException) {
            error = new Error().setError("error_core_json_mapping_error")
                .setErrorDescription("Unknown property")
                .setDetails(Arrays.asList(new ErrorDetails().setParam(((UnrecognizedPropertyException) exceptionCause).getPropertyName())));
        } else if (exceptionCause instanceof JsonMappingException) {
            error = new Error().setError("error_core_json_mapping")
                .setErrorDescription( ((JsonParseException) exceptionCause).getOriginalMessage())
                .setDetails(Arrays.asList(new ErrorDetails().setParam(((JsonMappingException) exceptionCause).getPathReference())));
        } else {
            error = new Error().setError("error_core_http_message_not_readable")
                .setErrorDescription("Couldn't properly read the request message");
        }

        return new ModelAndView(jsonView, "error", error);
    }

    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler({InternalServerErrorException.class, JCAConnectionRecordException.class, UnsuccessfulBackendExecutionException.class})
    public ModelAndView handleInternalServerError(HttpServletRequest req, Exception exception) {
        LOGGER.error(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
    @ExceptionHandler(RangeUnsatisfiableException.class)
    public ModelAndView handleRangeError(HttpServletRequest request, Exception exception) {
        LOGGER.info(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.FORBIDDEN)
    @ExceptionHandler(ForbiddenException.class)
    public ModelAndView handleForbiddenError(HttpServletRequest request, Exception exception) {
        LOGGER.info(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.FORBIDDEN)
    @ExceptionHandler({UnauthorizedException.class, AccessDeniedException.class})
    public ModelAndView handleUnauthorizedError(HttpServletRequest request, Exception exception) {
        LOGGER.info(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.NOT_IMPLEMENTED)
    @ExceptionHandler(NotImplementedException.class)
    public ModelAndView handleNotImplementedError(HttpServletRequest request, Exception exception) {
        LOGGER.info(exception.getMessage(), exception);
        return createModelAndView(exception);
    }

    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ModelAndView methodArgumentNotValid(HttpServletRequest request, MethodArgumentNotValidException exception) {
        LOGGER.info(exception.getMessage(), exception);
        final String parameterName = getParameterName(exception);
        final String message = getMessage(exception);
        final Error error = new Error().setError(ErrorResponses.Codes.INVALID_FIELD)
            .setErrorDescription(message)
            .setDetails(Arrays.asList(new ErrorDetails().setParam(parameterName)));
        return new ModelAndView(jsonView, "error", error);
    }

    private ModelAndView createModelAndView(Exception exception) {
        Error error = null;
        if (exception instanceof ErrorResponse) {
            error = ((ErrorResponse) exception).getErrorResponse();
        } else if (exception instanceof ServletException) {
            error = new Error().setError(ErrorResponses.Codes.UNKNOWN).setErrorDescription(exception.getMessage());
        } else {
            error = getResponse(exception, Error.class);
        }
        jsonView.setExtractValueFromSingleKeyModel(true);
        return new ModelAndView(jsonView, "error", error);
    }

    private <T> ModelAndView createModelAndView(Exception exception, Class<T> responseClass) {
        jsonView.setExtractValueFromSingleKeyModel(true);
        return new ModelAndView(jsonView, "error", getResponse(exception, responseClass));
    }

    private <T> T getResponse(Exception exception, Class<T> responseClass) {
        T response = null;
        try {
            response = JsonUtils.fromJson(exception.getMessage(), responseClass);
        } catch (JsonProcessingException e) {
            LOGGER.error("Couldn't deserialize " + responseClass.getSimpleName() + " JSON", e);
            try {
                response = responseClass.newInstance();
            } catch (InstantiationException | IllegalAccessException e1) {
                LOGGER.error("Couldn't instantiate " + responseClass.getSimpleName() + "!", e);
            }
        }
        return response;
    }

    private String getParameterName(MethodArgumentNotValidException exception) {
        if (exception.getBindingResult() == null || !exception.getBindingResult().hasErrors()) {
            return exception.getParameter().getParameterName();
        }

        FieldError fieldError = exception.getBindingResult().getFieldError();
        return fieldError.getField();
    }

    private String getMessage(MethodArgumentNotValidException exception) {
        if (exception.getBindingResult() == null || !exception.getBindingResult().hasErrors()) {
            return exception.getMessage();
        }

        FieldError fieldError = exception.getBindingResult().getFieldError();
        return fieldError.getDefaultMessage();
    }
}
