package com.nordea.dbf.http.errorhandling.exception;

import java.util.Optional;

/**
 * Exception that signals that the request have been accepted for processing, but not completed.
 *
 * A typical use-case is the initiation of the signing process for payments.
 *
 * The acceptedException takes an optional object for serialization as an argument.
 */
public class AcceptedException extends RuntimeException {
    public final Object object;

    public AcceptedException() {
        this.object = null;
    }

    public AcceptedException(Object object) {
        this.object = object;
    }

    public Optional<Object> getObject() {
        return Optional.ofNullable(this.object);
    }
}
