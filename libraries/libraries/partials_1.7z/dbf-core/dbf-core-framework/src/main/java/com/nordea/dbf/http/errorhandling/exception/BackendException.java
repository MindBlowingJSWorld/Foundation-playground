package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;

public class BackendException extends ErrorResponse {

    public BackendException(Error error) {
        super(error);
    }

    public BackendException(Error error, Throwable cause) {
        super(error, cause);
    }
}
