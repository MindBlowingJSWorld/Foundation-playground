package com.nordea.dbf.http.errorhandling.exception;


import com.nordea.dbf.api.model.Error;

/**
 * Exception for bad client requests
 */
public class BadRequestException extends ErrorResponse {

    public BadRequestException(Error error) {
        super(error);
    }

    public BadRequestException(Error error, Throwable cause) {
        super(error, cause);
    }
}
