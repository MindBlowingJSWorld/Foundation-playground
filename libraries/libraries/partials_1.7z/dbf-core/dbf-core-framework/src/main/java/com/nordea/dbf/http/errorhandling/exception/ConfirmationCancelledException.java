package com.nordea.dbf.http.errorhandling.exception;


import com.nordea.dbf.api.model.Error;

/**
 * Confirmation - i.e. signing - has been cancelled. Might be due to a timeout
 * or something similar.
 */
public class ConfirmationCancelledException extends ErrorResponse {

    public ConfirmationCancelledException(Error error) {
        super(error);
    }
}
