package com.nordea.dbf.http.errorhandling.exception;


import com.nordea.dbf.api.model.Error;

/**
 * Confirmation - i.e. signing - has failed.
 */
public class ConfirmationFailedException extends ErrorResponse {

    public ConfirmationFailedException(Error error) {
        super(error);
    }
}
