package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;

/**
 * A <code>ConfirmationInProgressException</code> is thrown when polling a signing process
 * that has not yet completed. This should indicate that the consumer should continue
 * polling the signing process. This is not an exception per se, but is an exception to
 * the full-success flow since the operation can't continue until the user has successfully
 * signed the request.
 */
public class ConfirmationInProgressException extends ErrorResponse {

    public ConfirmationInProgressException(Error error) {
        super(error);
    }
}
