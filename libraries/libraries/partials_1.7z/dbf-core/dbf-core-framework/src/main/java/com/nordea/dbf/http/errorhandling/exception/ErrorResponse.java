package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.json.JsonUtils;

public abstract class ErrorResponse extends RuntimeException {
    private final Error error;

    public ErrorResponse(Error error) {
        this.error = error;
    }

    public ErrorResponse(Error error, Throwable cause) {
        super(cause);
        this.error = error;
    }

    public ErrorResponse(Error error, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(error.getErrorDescription(), cause, enableSuppression, writableStackTrace);
        this.error = error;
    }

    public Error getErrorResponse() {
        return error;
    }

    public String getMessage() {
        String message = JsonUtils.toJson(error);
        if (this.getCause() != null) {
            message = message + System.lineSeparator() +  super.getMessage();
        }
        return message;
    }

}
