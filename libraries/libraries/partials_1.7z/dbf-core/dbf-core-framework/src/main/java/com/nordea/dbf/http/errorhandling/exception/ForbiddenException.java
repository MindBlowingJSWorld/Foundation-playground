package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;

public class ForbiddenException extends ErrorResponse {

    public ForbiddenException(Error error) {
        super(error);
    }

    public ForbiddenException(Error error, Throwable cause) {
        super(error, cause);
    }
}
