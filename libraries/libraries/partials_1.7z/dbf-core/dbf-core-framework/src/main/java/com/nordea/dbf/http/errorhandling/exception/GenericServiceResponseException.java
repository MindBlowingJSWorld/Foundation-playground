package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;

public class GenericServiceResponseException extends ErrorResponse implements HasHttpStatus {
    private final int httpStatus;

    public GenericServiceResponseException(Error error, int httpStatus) {
        super(error);
        this.httpStatus = httpStatus;
    }

    @Override
    public int getStatus() {
        return httpStatus;
    }

    @Override
    public String getMessage() {
        return "HTTP " + httpStatus + ": " + super.getMessage();
    }
}
