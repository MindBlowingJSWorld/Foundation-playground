package com.nordea.dbf.http.errorhandling.exception;

public interface HasHttpStatus {

    int getStatus();

}
