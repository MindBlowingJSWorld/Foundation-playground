package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;

/**
 * Exception that signals an internal server error
 */
public class InternalServerErrorException extends ErrorResponse {

    public InternalServerErrorException(Error error) {
        super(error);
    }

    public InternalServerErrorException(Error error, Throwable cause) {
        super(error, cause);
    }
}
