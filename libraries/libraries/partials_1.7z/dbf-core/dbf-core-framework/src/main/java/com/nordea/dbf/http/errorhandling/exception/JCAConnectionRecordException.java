package com.nordea.dbf.http.errorhandling.exception;


import com.nordea.dbf.api.model.Error;

/**
 * Exception used to signal that a JCA connection has failed or that the records used are erroneous
 *
 */
public class JCAConnectionRecordException extends ErrorResponse {

  public JCAConnectionRecordException(Error error) {
    super(error);
  }

  public JCAConnectionRecordException(Error error, Throwable cause) {
    super(error, cause);
  }
}
