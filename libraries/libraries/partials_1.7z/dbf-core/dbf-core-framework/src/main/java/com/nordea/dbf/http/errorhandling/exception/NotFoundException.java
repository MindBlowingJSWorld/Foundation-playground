package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;

/**
 * Exception that signals that the desired entity wasn't found
 */
public class NotFoundException  extends ErrorResponse {

  public NotFoundException(Error error) {
    super(error);
  }

  public NotFoundException(Error error, Throwable cause) {
    super(error, cause);
  }
}
