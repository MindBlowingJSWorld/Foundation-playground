package com.nordea.dbf.http.errorhandling.exception;


import com.nordea.dbf.api.model.Error;

/**
 * Exception that signals that the endpoint is not implemented
 */
public class NotImplementedException extends ErrorResponse {

  public NotImplementedException(Error error) {
    super(error);
  }

  public NotImplementedException(Error error, Throwable cause) {
    super(error, cause);
  }
}
