package com.nordea.dbf.http.errorhandling.exception;


import com.nordea.dbf.api.model.Error;

/**
 * Exception for not met preconditions.
 * RFC 2616
 * If-Match
 * If-Modified-Since
 * If-None-Match
 * If-Range
 * If-Unmodified-Since
 */
public class PreconditionFailedException  extends ErrorResponse {

    public PreconditionFailedException(Error error) {
        super(error);
    }

    public PreconditionFailedException(Error error, Throwable cause) {
        super(error, cause);
    }
}
