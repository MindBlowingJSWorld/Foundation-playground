package com.nordea.dbf.http.errorhandling.exception;


import com.nordea.dbf.api.model.Error;

public class RangeUnsatisfiableException extends ErrorResponse {

    public RangeUnsatisfiableException(Error error) {
        super(error);
    }

    public RangeUnsatisfiableException(Error error, Throwable cause) {
        super(error, cause);
    }
}
