package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;

/**
 * Exception for unauthorized requests
 *
 */
public class UnauthorizedException extends ErrorResponse {

  public UnauthorizedException(Error error) {
    super(error);
  }

  public UnauthorizedException(Error error, Throwable cause) {
    super(error, cause);
  }
}
