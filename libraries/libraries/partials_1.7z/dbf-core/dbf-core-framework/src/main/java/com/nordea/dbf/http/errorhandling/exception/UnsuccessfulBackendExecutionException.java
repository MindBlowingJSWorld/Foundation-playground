package com.nordea.dbf.http.errorhandling.exception;

import com.nordea.dbf.api.model.Error;

/**
 * Exception that signals an unsuccessful legacy backend service execution
 *
 */
public class UnsuccessfulBackendExecutionException extends ErrorResponse {

  public UnsuccessfulBackendExecutionException(Error error) {
    super(error);
  }

  public UnsuccessfulBackendExecutionException(Error error, Throwable cause) {
    super(error, cause);
  }
}
