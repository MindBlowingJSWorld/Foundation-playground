package com.nordea.dbf.integration;

import com.nordea.dbf.http.ServiceRequestContext;
import rx.Observable;

import java.util.Optional;

public interface Converter<S, T> {

    Observable<T> convert(Optional<ServiceRequestContext> requestContext, S source);

}
