package com.nordea.dbf.json;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

import java.util.Date;
import java.util.Optional;

/**
 * Custom mapper
 *
 * @deprecated Use default objectMapper Spring bean and java.time instead.
 */
@Deprecated
public class CustomObjectMapper extends ObjectMapper {

    public CustomObjectMapper() {
    }

    private CustomObjectMapper(Optional<String> dateFormat) {
        final SimpleModule module = new SimpleModule();

        module.addSerializer(Date.class, (dateFormat.isPresent() ? new JsonDateSerializer(dateFormat.get()) : new JsonDateSerializer()));

        this.registerModule(module);
        this.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {

        private Optional<String> dateFormat = Optional.empty();

        public Builder dateFormat(String dateFormat) {
            this.dateFormat = Optional.of(dateFormat);
            return this;
        }

        public CustomObjectMapper build() {
            return new CustomObjectMapper(dateFormat);
        }
    }

}
