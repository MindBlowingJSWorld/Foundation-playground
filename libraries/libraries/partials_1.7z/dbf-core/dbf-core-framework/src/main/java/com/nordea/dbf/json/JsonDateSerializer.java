package com.nordea.dbf.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.apache.commons.lang.Validate;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Custom Jackson serializer for java.util.date
 */
public class JsonDateSerializer extends JsonSerializer<Date> {

    public static String DEFAULT_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

    private DateFormat dateTimeFormatter;

    public JsonDateSerializer() {
        this(DEFAULT_PATTERN);
    }

    public JsonDateSerializer(String dateTimeFormatter) {
        this(new SimpleDateFormat(dateTimeFormatter));
    }

    public JsonDateSerializer(DateFormat dateTimeFormatter) {
        Validate.notNull(dateTimeFormatter, "dateTimeFormatter can't be null");
        this.dateTimeFormatter = dateTimeFormatter;
    }

    @Override
    public void serialize(Date date, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeString(dateTimeFormatter.format(date));
    }
}
