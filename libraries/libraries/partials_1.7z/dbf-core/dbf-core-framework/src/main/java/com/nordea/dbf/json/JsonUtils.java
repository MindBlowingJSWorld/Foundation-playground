package com.nordea.dbf.json;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JSR310Module;

import java.io.IOException;

/**
 * Utility class to marshal and unmarshal Java objects as JSON
 */
public class JsonUtils {

    private JsonUtils() {
    }

    private static ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JSR310Module())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

    static {
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }

    public static String toPrettyJson(final Object o) {
        if (o == null) {
            return null;
        }

        try {
            return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(o);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Could not serialize to JSON string", e);
        }
    }

    public static String toJson(final Object o) {
        if (o == null) {
            return null;
        }
        try {
            return mapper.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Could not serialize to JSON string", e);
        }
    }

    public static <T> T fromJson(final String string, final Class<T> klass) throws JsonProcessingException {
        try {
            return mapper.readValue(string, klass);
        } catch (JsonProcessingException e) {
            throw e;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
