package com.nordea.dbf.logging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.PropertySource;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class ConfigurationLogger implements ApplicationListener<ContextRefreshedEvent> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationLogger.class);

    @Autowired
    private ConfigurableEnvironment environment;

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        final Map<String, Map<String, Map<String, String>>> propertiesBySource = new HashMap<>();

        for (final PropertySource propertySource : environment.getPropertySources()) {
            if (!(propertySource instanceof EnumerablePropertySource)) {
                propertiesBySource.put(propertySource.getName(), Collections.<String, Map<String, String>>emptyMap());
            } else {
                final EnumerablePropertySource enumerablePropertySource = (EnumerablePropertySource) propertySource;
                final Map<String, Map<String, String>> properties = new HashMap<>();

                for (final String propertyName : enumerablePropertySource.getPropertyNames()) {
                    final String value = String.valueOf(enumerablePropertySource.getProperty(propertyName));

                    final ImmutableMap.Builder<String, String> builder = ImmutableMap.<String, String>builder()
                            .put("value", value);

                    try {
                        final String resolved = String.valueOf(environment.getProperty(propertyName));

                        if (!Objects.equals(value, resolved)) {
                            builder.put("resolved", resolved);
                        }
                    } catch (Exception e) {
                        builder.put("unresolvable", e.getClass().getSimpleName() + ":" + e.getMessage());
                    }

                    properties.put(propertyName, builder.build());
                }

                propertiesBySource.put(propertySource.getName(), properties);
            }
        }

        try {
            LOGGER.info("Service started with configuration:\n{}",
                    objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(propertiesBySource));
        } catch (JsonProcessingException e) {
            throw new BeanCreationException("Failed to enumerate configuration for logging", e);
        }
    }
}
