package com.nordea.dbf.logging;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Logging {

    public static String mask(String string) {
        if (string == null) {
            return null;
        }

        if (StringUtils.isEmpty(string)) {
            return StringUtils.EMPTY;
        }

        try {
            final byte[] result = MessageDigest.getInstance("SHA-256").digest(string.getBytes("UTF-8"));

            return Base64.encodeBase64String(result);
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            throw new UnsupportedOperationException("String can't be digested due to missing UTF-8 support");
        }
    }

}
