package com.nordea.dbf.messaging;

import org.apache.commons.lang.Validate;
import rx.Observable;

/**
 * Implementation of message channel that directly passes a message to a message handler.
 */
public class DirectMessageChannel implements MessageChannel {

    private final MessageHandler<?, ?> messageHandler;

    public DirectMessageChannel(MessageHandler<?, ?> messageHandler) {
        Validate.notNull(messageHandler, "messageHandler can't be null");
        this.messageHandler = messageHandler;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Observable<Message<?>> deliver(Message<?> message) {
        Validate.notNull(message, "message can't be null");

        Object r = messageHandler.deliver((Message) message);
        return (Observable<Message<?>>) r;
    }
}
