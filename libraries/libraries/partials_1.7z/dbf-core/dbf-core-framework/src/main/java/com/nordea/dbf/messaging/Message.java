package com.nordea.dbf.messaging;

import com.nordea.dbf.http.ServiceRequestContext;
import org.apache.commons.lang.Validate;

import java.util.Optional;

/**
 * A <code>Message</code> is a placeholder for some arbitrary payload with context and meta information.
 * In particular, it holds the <code>ServiceRequestContext</code> that contains the user/request/session
 * information and it contains an optional reference to a preceding message that was some sort of input
 * to the message.
 *
 * @param <T> The type of the payload.
 */
public final class Message<T> {

    private final Optional<ServiceRequestContext> serviceRequestContext;

    private final T payload;

    private final Optional<Message<?>> request;

    private Message(T payload, Optional<Message<?>> request, Optional<ServiceRequestContext> serviceRequestContext) {
        this.payload = payload;
        this.request = request;
        this.serviceRequestContext = serviceRequestContext;
    }

    public T getPayload() {
        return payload;
    }

    public<R> R getPayload(Class<R> type) {
        return this.as(type).getPayload();
    }

    @SuppressWarnings("unchecked")
    public<R> Message<R> as(Class<R> type) {
        Validate.notNull(type, "type can't be null");

        if (payload != null && !type.isInstance(payload)) {
            throw new IllegalArgumentException("Payload '" + payload + "' is not an instance of '" + type.getName() + "'");
        }

        return (Message<R>) this;
    }

    public Optional<Message<?>> getRequest() {
        return request;
    }

    public Optional<ServiceRequestContext> getServiceRequestContext() {
        return serviceRequestContext;
    }

    /**
     * Creates a continuation of the current message with a new payload. This method will return a message
     * that contains a reference to the current message and it also retains the service request context.
     *
     * @param payload The payload of the message.
     * @param <R> The type of the payload.
     * @return A message that is a continuation of the current message.
     */
    public<R> Message<R> continuationWith(R payload) {
        return new Message<>(payload, Optional.<Message<?>>of(this), serviceRequestContext);
    }

    public static<T> Message<T> fromPayload(T payload) {
        return new Message<>(payload, Optional.<Message<?>>empty(), Optional.<ServiceRequestContext>empty());
    }

    public static InContextContinuation in(ServiceRequestContext context) {
        return new InContextContinuation() {
            @Override
            public <T> Message<T> withPayload(T payload) {
                return new Message<>(payload, Optional.empty(), Optional.of(context));
            }
        };
    }

    public static Builder<?> builder() {
        return new Builder<>();
    }

    public interface InContextContinuation {

        <T> Message<T> withPayload(T payload);

    }

    public static class Builder<T> {

        private T payload;

        private Optional<Message<?>> request = Optional.empty();

        private Optional<ServiceRequestContext> serviceRequestContext = Optional.empty();

        @SuppressWarnings("unchecked")
        public<S> Builder<S> payload(S payload) {
            final Builder builder = (Builder) this;
            builder.payload = payload;
            return builder;
        }

        public Builder<T> inResponseTo(Message<?> request) {
            this.request = Optional.<Message<?>>of(request);
            return this;
        }

        public Builder<T> serviceRequestContext(ServiceRequestContext serviceRequestContext) {
            this.serviceRequestContext = Optional.of(serviceRequestContext);
            return this;
        }

        public Message<T> build() {
            if (!serviceRequestContext.isPresent()) {
                if (this.request.isPresent()) {
                    Message<?> request = this.request.get();

                    while (request != null) {
                        if (request.serviceRequestContext.isPresent()) {
                            serviceRequestContext = request.serviceRequestContext;
                            break;
                        }

                        request = request.getRequest().orElse(null);
                    }
                }
            }

            return new Message<>(payload, request, serviceRequestContext);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Message<?> message = (Message<?>) o;

        if (!serviceRequestContext.equals(message.serviceRequestContext)) return false;
        if (payload != null ? !payload.equals(message.payload) : message.payload != null) return false;
        return request.equals(message.request);

    }

    @Override
    public int hashCode() {
        int result = serviceRequestContext.hashCode();
        result = 31 * result + (payload != null ? payload.hashCode() : 0);
        result = 31 * result + request.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Message{" +
                "serviceRequestContext=" + serviceRequestContext +
                ", payload=" + payload +
                ", request=" + request +
                '}';
    }
}
