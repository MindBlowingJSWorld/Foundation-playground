package com.nordea.dbf.messaging;

import org.apache.commons.lang.Validate;
import rx.Observable;
import rx.functions.Func1;

/**
 * A message channel that delivers a message to a message channel and then forwards the response of
 * that channel to a second channel. This is useful to e.g. enhance-and-forward messages.
 */
public class MessageBridge implements MessageChannel {

    private final MessageChannel sourceMessageChannel;

    private final MessageChannel targetMessageChannel;

    public MessageBridge(MessageChannel sourceMessageChannel, MessageChannel targetMessageChannel) {
        Validate.notNull(sourceMessageChannel, "sourceMessageChannel can't be null");
        Validate.notNull(targetMessageChannel, "targetMessageChannel can't be null");

        this.sourceMessageChannel = sourceMessageChannel;
        this.targetMessageChannel = targetMessageChannel;
    }

    @Override
    public Observable<Message<?>> deliver(Message<?> message) {
        Validate.notNull(message, "message can't be null");

        return sourceMessageChannel.deliver(message).flatMap(new Func1<Message<?>, Observable<Message<?>>>() {
            @Override
            public Observable<Message<?>> call(Message<?> message) {
                return targetMessageChannel.deliver(message);
            }
        });
    }
}
