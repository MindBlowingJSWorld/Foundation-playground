package com.nordea.dbf.messaging;

import org.apache.commons.lang.Validate;
import rx.Observable;
import rx.functions.Func1;

import java.util.List;

/**
 * A <code>MessageChannel</code> that broadcasts a message to a set of channels and returns a
 * flat stream of response messages.
 */
public class MessageBroadcaster implements MessageChannel {

    private final List<MessageChannel> targetMessageChannels;

    public MessageBroadcaster(List<MessageChannel> targetMessageChannels) {
        Validate.notNull(targetMessageChannels, "targetMessageChannels can't be null");
        this.targetMessageChannels = targetMessageChannels;
    }

    @Override
    public Observable<Message<?>> deliver(final Message<?> message) {
        Validate.notNull(message, "message can't be null");

        return Observable.from(targetMessageChannels).flatMap(new Func1<MessageChannel, Observable<Message<?>>>() {
            @Override
            public Observable<Message<?>> call(MessageChannel messageChannel) {
                return messageChannel.deliver(message);
            }
        });
    }
}
