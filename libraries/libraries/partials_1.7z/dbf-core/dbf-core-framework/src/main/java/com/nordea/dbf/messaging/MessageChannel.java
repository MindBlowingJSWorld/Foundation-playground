package com.nordea.dbf.messaging;

import rx.Observable;

/**
 * A <code>MessageChannel</code> accepts any type of messages and attempts to deliver it to
 * an appropriate end-point. A message channel is a generic transport construct in contrast to
 * a <code>MessageHandler</code> which would typically accept a particular type of message and
 * handle it.
 */
public interface MessageChannel {

    Observable<Message<?>> deliver(Message<?> message);

}
