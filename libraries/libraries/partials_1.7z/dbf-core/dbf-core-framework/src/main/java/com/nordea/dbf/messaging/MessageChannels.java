package com.nordea.dbf.messaging;

import org.apache.commons.lang.Validate;

import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for creating message channels.
 */
public class MessageChannels {

    public static MessageChannel direct(MessageHandler<?, ?> messageHandler) {
        Validate.notNull(messageHandler, "messageHandler can't be null");
        return new DirectMessageChannel(messageHandler);
    }

    public static List<MessageChannel> direct(List<MessageHandler<?, ?>> messageHandlers) {
        Validate.notNull(messageHandlers, "messageHandlers can't be null");

        final ArrayList<MessageChannel> messageChannels = new ArrayList<>(messageHandlers.size());

        for (final MessageHandler<?, ?> messageHandler : messageHandlers) {
            messageChannels.add(new DirectMessageChannel(messageHandler));
        }

        return messageChannels;
    }

}
