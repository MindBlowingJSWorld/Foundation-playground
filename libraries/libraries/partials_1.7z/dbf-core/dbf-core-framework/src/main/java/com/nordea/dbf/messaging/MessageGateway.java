package com.nordea.dbf.messaging;

/**
 * Marker interface that denotes a message handler that transforms and transmits a message
 * externally. For example, an IMS gateway sends a message to IMS through JCA etc.
 *
 * @param <M> The type of the message handled by the gateway.
 * @param <R> The result type of the gateway.
 */
public interface MessageGateway<M, R> extends MessageHandler<M, R> {
}
