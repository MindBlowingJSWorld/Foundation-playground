package com.nordea.dbf.messaging;

import rx.Observable;

/**
 * A <code>MessageHandler</code> is a message end-point responsible for doing processing of a message.
 * A typical case is a payment retrieval message handler, that would actually retrieve payments from an
 * external system and return those to the requester. A message handler can return 0 or more messages
 * in response to a message.
 *
 * @param <M> The type of messages accepted by this handler.
 * @param <R> The result messages produced by this handler.
 */
public interface MessageHandler<M, R> {

    Observable<Message<R>> deliver(Message<M> message);

}
