package com.nordea.dbf.messaging;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;


/**
 * Exception that is thrown if a message can't be routed.
 */
public class MessageNotRoutableException extends ErrorResponse {

    public MessageNotRoutableException() {
        super(new Error().setError(ErrorResponses.Codes.NOT_UNDERSTOOD));
    }

    public MessageNotRoutableException(String message) {
        super(new Error().setError(ErrorResponses.Codes.NOT_UNDERSTOOD).setErrorDescription(message));
    }

    public MessageNotRoutableException(String message, Throwable cause) {
        super(new Error().setError(ErrorResponses.Codes.NOT_UNDERSTOOD).setErrorDescription(message), cause);
    }

    public MessageNotRoutableException(Throwable cause) {
        super(new Error().setError(ErrorResponses.Codes.NOT_UNDERSTOOD), cause);
    }

    public MessageNotRoutableException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(new Error().setError(ErrorResponses.Codes.NOT_UNDERSTOOD).setErrorDescription(message), cause, enableSuppression, writableStackTrace);
    }
}
