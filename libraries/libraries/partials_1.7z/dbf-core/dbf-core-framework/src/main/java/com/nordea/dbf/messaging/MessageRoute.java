package com.nordea.dbf.messaging;

import rx.Observable;

import java.util.Optional;

public interface MessageRoute {

    /**
     * Attempt to apply the deliver. If the deliver is not applicabe to the provided message, an absent optional
     * should be returned.
     *
     * @param message The message that should be delivered to the deliver.
     * @return Optional with an observable of the message
     */
    Optional<Observable<Message<?>>> deliver(Message<?> message);

}
