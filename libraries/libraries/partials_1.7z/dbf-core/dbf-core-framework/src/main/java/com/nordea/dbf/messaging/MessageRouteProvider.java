package com.nordea.dbf.messaging;

import java.util.List;

/**
 * A provider of message routes.
 */
public interface MessageRouteProvider {

    List<MessageRoute> getRoutes();

}
