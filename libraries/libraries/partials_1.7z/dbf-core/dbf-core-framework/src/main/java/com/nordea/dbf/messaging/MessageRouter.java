package com.nordea.dbf.messaging;

import rx.Observable;

public interface MessageRouter extends MessageChannel {

    @Override
    Observable<Message<?>> deliver(Message<?> message);

}
