package com.nordea.dbf.messaging;

import com.google.common.collect.ImmutableList;
import org.apache.commons.lang.Validate;
import org.springframework.aop.framework.AopProxyUtils;
import rx.Observable;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;

import static com.nordea.dbf.messaging.MessageChannels.direct;

/**
 * Support class for creating and managing message routes.
 */
public class MessageRoutes {

    public static RouterBuilder router() {
        return new RouterBuilder();
    }

    public static<T> Predicate<T> anything() {
        return m -> true;
    }

    public static MessageChannel unhandled() {
        return message -> Observable.error(new MessageNotRoutableException("No route was suitable for message: " + message));
    }

    public static MessageChannel unhandled(String text) {
        return message -> Observable.error(new MessageNotRoutableException(text));
    }

    public static<T> SubRouteBuilder2<T> route(Function<Message<?>, Observable<T>> function) {
        Validate.notNull(function, "function can't be null");

        final ValueMessageRouter.Builder<T> builder = ValueMessageRouter.on(function);

        return new SubRouteBuilder2<T>() {
            @Override
            public MessageRoute build() {
                return builder.build();
            }

            @Override
            public SubRouteThenBuilder<T, SubRouteBuilder2<T>> when(Predicate<T> predicate) {
                return messageChannel -> {
                    builder.when(predicate).then(messageChannel);
                    return this;
                };
            }
        };
    }

    public static final class RouterBuilder {

        private final ImmutableList.Builder<MessageRoute> routes = ImmutableList.builder();

        public <T> SubRouteBuilder1<T> routeOn(Function<Message<?>, Observable<T>> function) {
            final RouterBuilder routerBuilder = this;
            final ValueMessageRouter.Builder<T> builder = ValueMessageRouter.on(function);

            return new SubRouteBuilder1<T>() {
                @Override
                public SubRouteThenBuilder<T, SubRouteBuilder1<T>> when(Predicate<T> predicate) {
                    return messageChannel -> {
                        builder.when(predicate).then(messageChannel);
                        return this;
                    };
                }

                @Override
                public RouterBuilder done() {
                    routes.add(builder.build());
                    return routerBuilder;
                }
            };
        }

        public RouterBuilderRouteContinuation route(Predicate<Message<?>> predicate) {
            Validate.notNull(predicate, "predicate can't be null");

            return messageChannel -> {
                routes.add(messageRouteOf(predicate, messageChannel));
                return this;
            };
        }

        public RouterBuilder by(MessageRoute messageRoute) {
            Validate.notNull(messageRoute, "messageRoute can't be null");
            routes.add(messageRoute);
            return this;
        }

        public MessageRouter build() {
            return new StaticMessageRouter(routes.build());
        }

    }

    private static MessageRoute messageRouteOf(Predicate<Message<?>> predicate, MessageChannel messageChannel) {
        return message -> {
            if (!predicate.test(message)) {
                return Optional.empty();
            }

            return Optional.of(messageChannel.deliver(message));
        };
    }

    /**
     * Creates a message route based on the type signature of the provided message handler.
     *
     * @param messageHandler The message handler.
     * @return A <code>MessageRoute</code> that accepts only messages matching the message handler
     * signature.
     */
    @SuppressWarnings("unchecked")
    public static MessageRoute fromMessageHandler(final MessageHandler messageHandler) {
        Validate.notNull(messageHandler, "messageHandler can't be null");

        final Class<?> messageHandlerClass = AopProxyUtils.ultimateTargetClass(messageHandler);

        for (final Type genericInterface : messageHandlerClass.getGenericInterfaces()) {
            if (!(genericInterface instanceof ParameterizedType)) {
                continue;
            }

            final ParameterizedType parameterizedInterface = (ParameterizedType) genericInterface;

            if (!MessageHandler.class.isAssignableFrom((Class<?>) parameterizedInterface.getRawType())) {
                continue;
            }

            final Class<?> inputType = (Class<?>) parameterizedInterface.getActualTypeArguments()[0];
            final Class<?> returnType = (Class<?>) parameterizedInterface.getActualTypeArguments()[1];

            return new MessageRoute() {
                @Override
                public Optional<Observable<Message<?>>> deliver(Message<?> message) {
                    if (!inputType.isInstance(message.getPayload())) {
                        return Optional.empty();
                    }

                    return Optional.<Observable<Message<?>>>of(messageHandler.deliver(message));
                }

                @Override
                public String toString() {
                    return "MessageRoute{Message<" + inputType.getSimpleName() + ">:" + returnType.getSimpleName() + " -> " + messageHandler + "}";
                }
            };
        }

        throw new IllegalArgumentException("Signature could not be inspected for type " + messageHandler.getClass().getName());
    }

    // Coercion

    public static List<MessageRoute> fromMessageHandlers(List<MessageHandler> messageHandlers) {
        Validate.notNull(messageHandlers, "messageHandlers can't be null");

        final ArrayList<MessageRoute> messageRoutes = new ArrayList<>(messageHandlers.size());

        for (final MessageHandler messageHandler : messageHandlers) {
            messageRoutes.add(fromMessageHandler(messageHandler));
        }

        return messageRoutes;
    }

    // Predicates

    @SuppressWarnings("unchecked")
    public static Predicate<Message<?>> whenPayload(final Predicate<?> predicate) {
        Validate.notNull(predicate, "predicate can't be null");
        return input -> {
            Validate.notNull(input, "input can't be null");
            return ((Predicate) predicate).test(input.getPayload());
        };
    }

    public static <T> Predicate<Object> isInstanceOf(Class<T> type) {
        Validate.notNull(type, "type can't be null");
        return t -> t != null && type.isInstance(t);
    }

    public interface SubRouteBuilder<T, B extends SubRouteBuilder<T, B>> {

        SubRouteThenBuilder<T, B> when(Predicate<T> predicate);

    }

    public interface SubRouteBuilder1<T> extends SubRouteBuilder<T, SubRouteBuilder1<T>> {

        RouterBuilder done();

    }

    public interface SubRouteBuilder2<T> extends SubRouteBuilder<T, SubRouteBuilder2<T>> {

        MessageRoute build();

    }

    public interface SubRouteThenBuilder<T, B extends SubRouteBuilder<T, B>> {

        B then(MessageChannel messageChannel);

        default B then(MessageHandler messageHandler) {
            return then(direct(messageHandler));
        }
    }

    public interface RouterBuilderRouteContinuation {

        RouterBuilder to(MessageChannel messageChannel);

        default RouterBuilder to(MessageHandler messageHandler) {
            return to(direct(messageHandler));
        }

    }

}
