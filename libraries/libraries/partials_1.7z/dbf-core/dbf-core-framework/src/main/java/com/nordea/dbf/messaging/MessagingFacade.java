package com.nordea.dbf.messaging;

import org.apache.commons.lang.Validate;
import rx.Observable;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * Facade towards the messaging configuration. Since components within the messaging system
 * may need to feed itself with messages, a lazy-lookup of the main entry point is required.
 * This is handled by this class, which resolves the main entry point when and only when
 * a message is handled.
 */
public class MessagingFacade implements MessageChannel {

    private final AtomicReference<MessageChannel> messageChannelRef = new AtomicReference<>();

    private final Supplier<MessageChannel> entryPointSupplier;

    public MessagingFacade(Supplier<MessageChannel> entryPointSupplier) {
        Validate.notNull(entryPointSupplier, "entryPointSupplier can't be null");
        this.entryPointSupplier = entryPointSupplier;
    }

    @Override
    public Observable<Message<?>> deliver(Message<?> message) {
        Validate.notNull(message, "message can't be null");

        final MessageChannel messageChannel = Optional.ofNullable(messageChannelRef.get()).orElseGet(() -> {
            final MessageChannel resolvedMessageChannel = entryPointSupplier.get();

            messageChannelRef.compareAndSet(null, resolvedMessageChannel);

            return resolvedMessageChannel;
        });

        return messageChannel.deliver(message);
    }
}
