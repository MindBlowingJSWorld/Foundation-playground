package com.nordea.dbf.messaging;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.async.DeferredResult;
import rx.Observable;
import rx.Subscriber;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Function;

public class Observables {

    private static final Logger LOGGER = LoggerFactory.getLogger(Observables.class);

    public static<T> DeferredResult<T> deferredResultOf(Observable<T> observable) {
        return deferredResultOf(observable, Function.<Throwable>identity(), t -> {});
    }

    public static<T> DeferredResult<T> deferredResultOf(Observable<T> observable, Function<Throwable, Throwable> exceptionMapper) {
        return deferredResultOf(observable, exceptionMapper, t -> {});
    }

    public static<T> DeferredResult<T> deferredResultOf(Observable<T> observable, Consumer<T> completeCallback) {
        return deferredResultOf(observable, Function.<Throwable>identity(), completeCallback);
    }

    public static<T> DeferredResult<T> deferredResultOf(Observable<T> observable, Function<Throwable, Throwable> exceptionMapper, Consumer<T> completeCallback) {
        Validate.notNull(observable, "observable can't be null");
        Validate.notNull(exceptionMapper, "exceptionMapper can't be null");
        Validate.notNull(completeCallback, "completeCallback can't be null");

        final DeferredResult<T> result = new DeferredResult<>();
        final AtomicReference<T> ref = new AtomicReference<>();

        observable.single().subscribe(new Subscriber<T>() {
            @Override
            public void onCompleted() {
                result.setResult(ref.get());
                completeCallback.accept(ref.get());
            }

            @Override
            public void onError(Throwable throwable) {
                // Unwrap hystrix exceptions
                // FIXME: Replace with a dependency to Hystrix.
                String exceptionName = throwable.getClass().getSimpleName();
                if (("HystrixRuntimeException".equals(exceptionName) || "HystrixBadRequestException".equals(exceptionName))
                        && Objects.nonNull(throwable.getCause())) {
                    result.setErrorResult(exceptionMapper.apply(throwable.getCause()));
                } else {
                    result.setErrorResult(exceptionMapper.apply(throwable));
                }
            }

            @Override
            public void onNext(T t) {
                if (!ref.compareAndSet(null, t)) {
                    throw new IllegalStateException("Result already acquired");
                }
            }
        });

        return result;
    }

    public static<A extends AutoCloseable> ManageContinuation<A> manage(final A resource) {
        Validate.notNull(resource, "resource can't be null");

        return new ManageContinuation<A>() {
            @Override
            public <T> Observable<T> on(Observable<T> observable) {
                Validate.notNull(observable, "observable can't be null");

                return observable.doOnTerminate(() -> {
                    try {
                        resource.close();
                    } catch (Exception e) {
                        LOGGER.warn("Resource \"{}\" might not have been closed properly", e);
                    }
                });
            }
        };
    }

    public interface ManageContinuation<A extends AutoCloseable> {

        <T> Observable<T> on(Observable<T> resource);

    }
}
