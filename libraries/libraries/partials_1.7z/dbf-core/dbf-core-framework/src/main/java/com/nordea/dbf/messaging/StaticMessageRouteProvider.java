package com.nordea.dbf.messaging;

import com.google.common.collect.ImmutableList;
import org.apache.commons.lang.Validate;

import java.util.List;

/**
 * A <code>MessageRouteProvider</code> that returns a static list of <code>MessageRoute</code>s.
 */
public class StaticMessageRouteProvider implements MessageRouteProvider {

    private final List<MessageRoute> routes;

    public StaticMessageRouteProvider(List<MessageRoute> routes) {
        Validate.notNull(routes, "routes can't be null");
        this.routes = ImmutableList.copyOf(routes);
    }

    @Override
    public List<MessageRoute> getRoutes() {
        return routes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StaticMessageRouteProvider that = (StaticMessageRouteProvider) o;

        return routes.equals(that.routes);

    }

    @Override
    public int hashCode() {
        return routes.hashCode();
    }

    @Override
    public String toString() {
        return "StaticRouteProvider{" +
                "routes=" + routes +
                '}';
    }
}
