package com.nordea.dbf.messaging;

import org.apache.commons.lang.Validate;
import rx.Observable;

import java.util.List;
import java.util.Optional;

public class StaticMessageRouter implements MessageRouter {

    private final MessageRouteProvider messageRouteProvider;

    public StaticMessageRouter(List<MessageRoute> messageRoutes) {
        this(new StaticMessageRouteProvider(messageRoutes));
    }

    public StaticMessageRouter(MessageRouteProvider messageRouteProvider) {
        Validate.notNull(messageRouteProvider, "messageRouteProvider can't be null");
        this.messageRouteProvider = messageRouteProvider;
    }

    @Override
    public Observable<Message<?>> deliver(Message<?> message) {
        Validate.notNull(message, "message can't be null");

        final List<MessageRoute> messageRoutes = messageRouteProvider.getRoutes();

        for (final MessageRoute messageRoute : messageRoutes) {
            final Optional<Observable<Message<?>>> result = messageRoute.deliver(message);

            if (result.isPresent()) {
                return result.get();
            }
        }

        return Observable.error(new MessageNotRoutableException(String.valueOf(message) + " -> " + messageRoutes));
    }
}
