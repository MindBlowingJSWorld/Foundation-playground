package com.nordea.dbf.messaging;

import com.google.common.collect.ImmutableList;
import org.apache.commons.lang.Validate;
import rx.Observable;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Routes a message based on some value extracted from the message or the message context. Typically,
 * e.g. classify the user's customer segment and select one of a set of routes based on that. The lookup
 * will only be performed once, but multiple routes can be evaluated.
 *
 * @param <T> The type of the value to route on.
 */
public class ValueMessageRouter<T> implements MessageRoute {

    private final Function<Message<?>, Observable<T>> function;

    private final List<ValueRoute<T>> messageRoutes;

    private ValueMessageRouter(Function<Message<?>, Observable<T>> function, List<ValueRoute<T>> messageRoutes) {
        Validate.notNull(function, "function can't be null");
        Validate.notNull(messageRoutes, "messageRoutes can't be null");

        this.function = function;
        this.messageRoutes = ImmutableList.copyOf(messageRoutes);
    }

    @Override
    public Optional<Observable<Message<?>>> deliver(Message<?> message) {
        Validate.notNull(message, "message can't be null");

        return (Optional<Observable<Message<?>>>) function.apply(message)
                .flatMap((T value) -> Observable.from(messageRoutes)
                        .filter(messageRoute -> messageRoute.test(value))
                        .firstOrDefault(null)
                        .map(messageRoute -> messageRoute == null ? Optional.<Observable<Message<?>>>empty() : Optional.of(messageRoute.deliver(message))))
                .toBlocking()
                .single();
    }

    public static <T> Builder<T> on(Function<Message<?>, Observable<T>> function) {
        Validate.notNull(function, "function can't be null");

        final ImmutableList.Builder<ValueRoute<T>> routes = ImmutableList.builder();

        return new Builder<T>() {
            @Override
            public WhenContinuation<T> when(Predicate<T> predicate) {
                Validate.notNull(predicate, "predicate can't be null");
                return messageChannel -> {
                    Validate.notNull(messageChannel, "messageChannel can't be null");
                    routes.add(new ValueRoute<T>(predicate, messageChannel));
                    return this;
                };
            }

            @Override
            public ValueMessageRouter<T> build() {
                return new ValueMessageRouter<>(function, routes.build());
            }
        };
    }

    public interface Builder<T> {

        WhenContinuation<T> when(Predicate<T> predicate);

        ValueMessageRouter<T> build();

    }

    @FunctionalInterface
    public interface WhenContinuation<T> {

        Builder<T> then(MessageChannel messageChannel);

    }


    public static class ValueRoute<T> implements Predicate<T>, MessageChannel {

        private final Predicate<T> predicate;

        private final MessageChannel messageChannel;

        public ValueRoute(Predicate<T> predicate, MessageChannel messageChannel) {
            this.predicate = predicate;
            this.messageChannel = messageChannel;
        }

        @Override
        public Observable<Message<?>> deliver(Message<?> message) {
            return messageChannel.deliver(message);
        }

        @Override
        public boolean test(T t) {
            return predicate.test(t);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            ValueRoute<?> that = (ValueRoute<?>) o;

            if (!predicate.equals(that.predicate)) return false;
            return messageChannel.equals(that.messageChannel);

        }

        @Override
        public int hashCode() {
            int result = predicate.hashCode();
            result = 31 * result + messageChannel.hashCode();
            return result;
        }

        @Override
        public String toString() {
            return "ValueRoute{" +
                    "predicate=" + predicate +
                    ", messageChannel=" + messageChannel +
                    '}';
        }
    }

}
