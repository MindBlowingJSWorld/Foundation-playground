package com.nordea.dbf.messaging.annotation;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation used on message handlers to denote they handle a particular type of messages only.
 * This is used to automatically setup routes for messages of a particular type. Example:
 *
 * <code>
 * MessageTypeHandler
 * public class MyMessageHandler implements MessageHandler&lt;MyMessageRequest, MyMessageResponse&gt; {
 *
 *     public Observable&lt;Message&lt;MyMessageResponse&gt;&gt; deliver(Message&lt;MyMessageRequest&gt; message) { ... }
 *
 * }
 * </code>
 */
@Component
@Qualifier
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface MessageTypeHandler {
}
