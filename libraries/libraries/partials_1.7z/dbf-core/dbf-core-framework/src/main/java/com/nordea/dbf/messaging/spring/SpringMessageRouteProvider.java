package com.nordea.dbf.messaging.spring;

import com.google.common.base.Joiner;
import com.nordea.dbf.messaging.MessageHandler;
import com.nordea.dbf.messaging.MessageRoute;
import com.nordea.dbf.messaging.MessageRouteProvider;
import com.nordea.dbf.messaging.MessageRoutes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.util.List;

/**
 * Component that creates a router to available message handlers by means of message type routing. All
 * message handles in the spring context will be eligible for message delivery.
 */
@SuppressWarnings("unchecked")
public class SpringMessageRouteProvider implements MessageRouteProvider {

    private static final Logger LOGGER = LoggerFactory.getLogger(SpringMessageRouteProvider.class);

    @Autowired
    private List<MessageHandler> messageHandlers;

    private volatile List<MessageRoute> messageRoutes;

    @PostConstruct
    public void configureRoutes() {
        this.messageRoutes = MessageRoutes.fromMessageHandlers(messageHandlers);

        LOGGER.info("Created message routes:\n\t{}", Joiner.on("\n\t").join(messageRoutes));
    }
    @Override
    public List<MessageRoute> getRoutes() {
        return messageRoutes;
    }
}
