package com.nordea.dbf.messaging.spring;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.nordea.dbf.messaging.*;
import com.nordea.dbf.messaging.annotation.MessageTypeHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import rx.Observable;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Message router that routes messages to spring components that has the {@link MessageTypeHandler} annotation.
 * A predicate can be provided to include only a set of components in the routing.
 */
public class SpringMessageTypeRouter implements MessageRouter {
    
    @Autowired
    private ApplicationContext applicationContext;

    private final Predicate<MessageHandler> predicate;

    public SpringMessageTypeRouter() {
        this(Predicates.<MessageHandler>alwaysTrue());
    }

    public SpringMessageTypeRouter(Predicate<MessageHandler> predicate) {
        this.predicate = predicate;
    }

    private volatile StaticMessageRouter targetMessageRouter;
    
    @PostConstruct
    public void setup() {
        final Map<String, Object> beans = applicationContext.getBeansWithAnnotation(MessageTypeHandler.class);
        final List<MessageRoute> messageRoutes = new ArrayList<>(beans.size());
        
        for (final Map.Entry<String, Object> entry : beans.entrySet()) {
            final MessageHandler messageHandler = (MessageHandler) entry.getValue();

            if (predicate.apply(messageHandler)) {
                messageRoutes.add(MessageRoutes.fromMessageHandler(messageHandler));
            }
        }
        
        this.targetMessageRouter = new StaticMessageRouter(messageRoutes);
    }

    @Override
    public Observable<Message<?>> deliver(Message<?> message) {
        return targetMessageRouter.deliver(message);
    }
}
