package com.nordea.dbf.metadata;

public class ApplicationMetaData {

    private final String groupId;

    private final String artifactId;

    private final String version;

    private final String name;

    private ApplicationMetaData(String groupId, String artifactId, String version, String name) {
        this.groupId = groupId;
        this.artifactId = artifactId;
        this.version = version;
        this.name = name;
    }

    public String getGroupId() {
        return groupId;
    }

    public String getArtifactId() {
        return artifactId;
    }

    public String getVersion() {
        return version;
    }

    public String getName() {
        return name;
    }

    @Override public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        ApplicationMetaData that = (ApplicationMetaData) o;

        if (groupId != null ? !groupId.equals(that.groupId) : that.groupId != null)
            return false;
        if (artifactId != null ? !artifactId.equals(that.artifactId) : that.artifactId != null)
            return false;
        if (version != null ? !version.equals(that.version) : that.version != null)
            return false;
        return !(name != null ? !name.equals(that.name) : that.name != null);

    }

    @Override public int hashCode() {
        int result = groupId != null ? groupId.hashCode() : 0;
        result = 31 * result + (artifactId != null ? artifactId.hashCode() : 0);
        result = 31 * result + (version != null ? version.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ApplicationMetaData{" +
                "groupId='" + groupId + '\'' +
                ", artifactId='" + artifactId + '\'' +
                ", version='" + version + '\'' +
                ", name='" + name + '\'' +
                '}';
    }

    public static class Builder {

        private String groupId;

        private String artifactId;

        private String version;

        private String name;

        public Builder groupId(String groupId) {
            this.groupId = groupId;
            return this;
        }

        public Builder artifactId(String artifactId) {
            this.artifactId = artifactId;
            return this;
        }

        public Builder version(String version) {
            this.version = version;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public ApplicationMetaData build() {
            return new ApplicationMetaData(groupId, artifactId, version, name);
        }
    }
}
