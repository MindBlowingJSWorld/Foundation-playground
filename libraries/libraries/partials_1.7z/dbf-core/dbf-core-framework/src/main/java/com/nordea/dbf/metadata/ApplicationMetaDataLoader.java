package com.nordea.dbf.metadata;

import java.io.IOException;
import java.io.InputStream;

public interface ApplicationMetaDataLoader {

    ApplicationMetaData load(InputStream in) throws IOException;

}
