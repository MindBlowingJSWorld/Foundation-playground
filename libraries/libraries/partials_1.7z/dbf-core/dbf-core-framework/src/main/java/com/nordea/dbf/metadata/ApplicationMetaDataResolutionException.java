package com.nordea.dbf.metadata;

public class ApplicationMetaDataResolutionException extends RuntimeException {

    public ApplicationMetaDataResolutionException() {
    }

    public ApplicationMetaDataResolutionException(String message) {
        super(message);
    }

    public ApplicationMetaDataResolutionException(String message, Throwable cause) {
        super(message, cause);
    }

    public ApplicationMetaDataResolutionException(Throwable cause) {
        super(cause);
    }

    public ApplicationMetaDataResolutionException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
