package com.nordea.dbf.metadata;

import org.springframework.core.io.Resource;

import java.util.Optional;

public interface ApplicationMetaDataResolver {

    Optional<Resource> getApplicationMetaDataSource();

}
