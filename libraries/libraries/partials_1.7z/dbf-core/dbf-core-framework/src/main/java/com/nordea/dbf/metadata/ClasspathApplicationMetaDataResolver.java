package com.nordea.dbf.metadata;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;

public class ClasspathApplicationMetaDataResolver implements ApplicationMetaDataResolver {

    public static final String MAVEN_PATTERN = "classpath:META-INF/maven/**/pom.xml";

    private static final Logger LOGGER = LoggerFactory.getLogger(ClasspathApplicationMetaDataResolver.class);

    @Autowired
    private ResourcePatternResolver resourcePatternResolver;

    @Override
    public Optional<Resource> getApplicationMetaDataSource() {
        final Resource[] resources;

        try {
            resources = resourcePatternResolver.getResources(MAVEN_PATTERN);
        } catch (IOException e) {
            LOGGER.warn("pom.xml is not locatable on classpath", e);
            return Optional.empty();
        }

        for (final Resource resource : resources) {
            try (final InputStream in = resource.getInputStream()) {
                if (IOUtils.toString(in, "UTF-8").contains("<packaging>war</packaging>")) {
                    LOGGER.info("Returning application meta-data from file '{}'", resource);
                    return Optional.of(resource);
                }
            } catch (IOException e) {
                LOGGER.warn("Resource could not be loaded from classpath: '{}'", resource.getFilename(), e);
            }
        }

        LOGGER.info("No application resources found on class path for pom-files: {}", resources);

        return Optional.empty();
    }
}
