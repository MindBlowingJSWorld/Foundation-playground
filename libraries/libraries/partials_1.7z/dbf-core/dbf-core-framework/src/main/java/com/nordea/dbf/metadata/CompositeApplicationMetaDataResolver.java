package com.nordea.dbf.metadata;

import com.google.common.collect.ImmutableList;
import org.apache.commons.lang.Validate;
import org.springframework.core.io.Resource;

import java.util.List;
import java.util.Optional;

public class CompositeApplicationMetaDataResolver implements ApplicationMetaDataResolver {

    private final List<ApplicationMetaDataResolver> resolvers;

    public CompositeApplicationMetaDataResolver(List<ApplicationMetaDataResolver> resolvers) {
        Validate.notNull(resolvers, "resolvers can't be null");
        this.resolvers = ImmutableList.copyOf(resolvers);
    }

    @Override
    public Optional<Resource> getApplicationMetaDataSource() {
        for (final ApplicationMetaDataResolver resolver : resolvers) {
            final Optional<Resource> resource = resolver.getApplicationMetaDataSource();

            if (resource.isPresent()) {
                return resource;
            }
        }

        return Optional.empty();
    }
}
