package com.nordea.dbf.metadata;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import java.io.File;
import java.net.URL;
import java.util.Optional;

public class ExplodedBootApplicationMetaDataResolver implements ApplicationMetaDataResolver {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExplodedBootApplicationMetaDataResolver.class);

    @Autowired
    private ApplicationContext applicationContext;

    @Override
    public Optional<Resource> getApplicationMetaDataSource() {
        final Object application = applicationContext.getBean("application");
        final Class<?> applicationClass = application.getClass().getSuperclass();
        final URL location = applicationClass.getProtectionDomain().getCodeSource().getLocation();

        if (!location.toString().matches("file:.+/target/classes/?")) {
            return Optional.empty();
        }

        final File pomFile = new File(System.getProperty("user.dir"), "pom.xml");

        if (!pomFile.exists()) {
            return Optional.empty();
        }

        LOGGER.info("Loading application meta-data from file {}", pomFile.getAbsolutePath());

        return Optional.<Resource>of(new FileSystemResource(pomFile));
    }
}
