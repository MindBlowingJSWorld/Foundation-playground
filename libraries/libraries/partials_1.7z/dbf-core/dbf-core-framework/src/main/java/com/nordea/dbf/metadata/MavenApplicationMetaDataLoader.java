package com.nordea.dbf.metadata;

import com.google.common.base.Joiner;
import com.google.common.base.Objects;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;
import java.io.IOException;
import java.io.InputStream;
import java.util.Stack;

public class MavenApplicationMetaDataLoader implements ApplicationMetaDataLoader {

    private enum ParseState {

        INIT,
        PROJECT

    }

    @Override
    public ApplicationMetaData load(InputStream in) throws IOException {
        final ApplicationMetaData.Builder builder = new ApplicationMetaData.Builder();

        try {
            SAXParserFactory.newInstance().newSAXParser().parse(in, new DefaultHandler() {

                private Stack<String> path = new Stack<String>();

                private String text;

                @Override
                public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
                    if (path.isEmpty()) {
                        if (!qName.equals("project")) {
                            throw new IllegalArgumentException("Invalid project file");
                        }

                        if (!Objects.equal("http://maven.apache.org/POM/4.0.0", attributes.getValue("xmlns"))) {
                            throw new IllegalArgumentException("project must be in maven namespace");
                        }
                    }

                    path.push(qName);
                }

                @Override
                public void characters(char[] ch, int start, int length) throws SAXException {
                    this.text = new String(ch, start, length);
                }

                @Override
                public void endElement(String uri, String localName, String qName) throws SAXException {
                    switch (Joiner.on("/").join(path)) {
                        case "project/groupId":
                            builder.groupId(text);
                            break;
                        case "project/artifactId":
                            builder.artifactId(text);
                            break;
                        case "project/version":
                            builder.version(text);
                            break;
                        case "project/name":
                            builder.name(text);
                            break;
                    }

                    path.pop();
                }
            });
        } catch (SAXException | ParserConfigurationException e) {
            throw new ApplicationMetaDataResolutionException("Failed to load application meta data", e);
        }

        return builder.build();
    }
}
