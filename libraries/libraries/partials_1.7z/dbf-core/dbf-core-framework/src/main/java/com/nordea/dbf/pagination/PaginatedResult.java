package com.nordea.dbf.pagination;

import java.util.List;

/**
 * Created by k293170 on 2015-05-01.
 */
public class PaginatedResult<T> {
    private List<T> results;
    private Pagination pagination;

    public PaginatedResult(List<T> results, Pagination pagination) {
        this.results = results;
        this.pagination = pagination;
    }

    public List<T> getResults() {
        return results;
    }

    public Pagination getPagination() {
        return pagination;
    }
}
