package com.nordea.dbf.pagination;

import java.text.ParseException;
import java.util.Optional;

/**
 * Created by k293170 on 2015-05-01.
 *
 */
public class Pagination {
    private Integer startIndex;
    private Optional<Integer> endIndex;
    private Optional<Integer> totalCount;

    public static Pagination fromString(final String rangeString) throws ParseException {
        if (rangeString == null || rangeString.isEmpty()) {
            return new Pagination(0);
        }
        String[] ranges = rangeString.split("/");
        Integer start, end = null, totalCount = null;
        if (ranges.length != 2 && ranges.length != 1) {
            throw new ParseException("Incorrect Range specified. Range must be in the form start, start-end or start-end/total", rangeString.length());
        } else if (ranges.length == 2) {
            try {
                totalCount = Integer.parseInt(ranges[1]);
            } catch (NumberFormatException nfe) {
                throw new ParseException("Incorrect total count specified. Total count must be numeric", rangeString.indexOf(ranges[1]));
            }
        }
        String[] indices = ranges[0].split("-");
        if (indices.length != 2 && indices.length != 1) {
            throw new ParseException("Incorrect Range specified. Range must be in the form start, start-end or start-end/total", 0);
        } else {
            try {
                start = Integer.parseInt(indices[0]);
                if (indices.length == 2) {
                    end = Integer.parseInt(indices[1]);
                } else {
                    if (totalCount != null) {
                        throw new ParseException("Incorrect Range specified. Range must be in the form start, start-end or start-end/total", 0);
                    }
                }
            } catch (NumberFormatException nfe) {
                throw new ParseException("Incorrect start-end range specified. It must be in the format start or start-end with start and end both numeric.", 0);
            }
            if (end != null && (start > end || start < 0 || end < 0)) {
                throw new ParseException("Incorrect Range specified. Range must be in the form start, start-end or start-end/total and start must be smaller than or equal to end", 0);
            }
        }
        return new Pagination(start, Optional.ofNullable(end), Optional.ofNullable(totalCount));
    }

    public Pagination(Integer startIndex, Optional<Integer> endIndex, Optional<Integer> totalCount) {
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.totalCount = totalCount;
    }

    public Pagination(Integer startIndex, Optional<Integer> endIndex) {
        this(startIndex, endIndex, Optional.<Integer>empty());
    }

    public Pagination(Integer startIndex) {
        this(startIndex, Optional.<Integer>empty(), Optional.<Integer>empty());
    }

    public boolean isComplete() {
      return totalCount.isPresent() && totalCount.get().equals(endIndex.get()) && startIndex == 0;
    }

    public boolean hasLimit() {
        return endIndex.isPresent();
    }

    public Integer getStartIndex() {
        return startIndex;
    }

    public Optional<Integer> getEndIndex() {
        return endIndex;
    }

    public Optional<Integer> getTotalCount() {
        return totalCount;
    }

    public Integer fetchedCount() {
        return endIndex.orElse(0) - startIndex;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder().append(startIndex);

        if (endIndex.isPresent()) {
            sb.append('-').append(endIndex.get());
        }
        if (totalCount.isPresent()) {
            sb.append('/').append(totalCount.get());
        }
        return sb.toString();
    }
}
