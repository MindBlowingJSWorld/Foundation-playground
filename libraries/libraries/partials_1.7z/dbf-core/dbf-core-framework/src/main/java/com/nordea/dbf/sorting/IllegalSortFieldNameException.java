package com.nordea.dbf.sorting;

/**
 * Exception to quantify which field was illegal in a sort definition string
 */
public class IllegalSortFieldNameException extends RuntimeException {
    public IllegalSortFieldNameException(String message) {
        super(message);
    }
}
