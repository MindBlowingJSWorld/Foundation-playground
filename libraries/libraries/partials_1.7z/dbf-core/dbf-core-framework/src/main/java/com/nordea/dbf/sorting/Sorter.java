package com.nordea.dbf.sorting;

import java.util.List;
import java.util.function.Function;

/**
 * A class that contains a sort (compare like) method to sorting instances of type S in a reactive flow
 *
 * @param <S> the type thats being sorted in the reactive flow
 * @see SorterFactory for a more detailled description, and how to create a Sorter
 * @see <a href="https://confluence.oneadr.net:8443/display/DBNS/REST%3A+2.+Sorting">Sorting doc in confluence</a>
 */
public class Sorter<S> {

    private final List<Function<S, Comparable>> sortByFields;
    private final int[] sortOrderDirection;

    Sorter(List<Function<S, Comparable>> sortByGetters, int[] sortOrderDirection) {
        this.sortByFields = sortByGetters;
        this.sortOrderDirection = sortOrderDirection;
    }

    public Integer sort(S t1, S t2) {
        return sort(t1, t2, 0);
    }

    private Integer sort(S t1, S t2, int level) {
        if (level >= sortByFields.size()) {
            return 0;
        }
        Function<S, Comparable> getter = sortByFields.get(level);
        Comparable value1 = getter.apply(t1);
        Comparable value2 = getter.apply(t2);

        @SuppressWarnings("unchecked") // we know for sure getters return same comparable type (same getter method applied to two different instances)
                int i = value1 != null && value2 != null ? value1.compareTo(value2)
                : value1 == null && value2 == null ? 0
                : value1 == null ? 1
                : -1;
        int ret = sortOrderDirection[level] * i;
        if (ret == 0) {
            return sort(t1, t2, level + 1);
        }
        return ret;
    }
}
