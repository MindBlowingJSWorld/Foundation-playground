package com.nordea.dbf.sorting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**

 * Mechanism to build a sort Function for a reactive flow, from a sort_by query parameter string.
 * <br><br>
 * Example of first step (configuration, done only once) - Make a factory with metainformation about the e.g. the Transaction class.
 * The meta factory knows the sort keys "id", "date" and "amount", and the corresponding getter methods for each sort key:
 * <br><br>
 * <code>
 * private static final Sorter.Factory&lt;Transaction&gt; transactionSorterFactory = new Sorter.Factory.Builder&lt;Transaction&gt;()
 * .add("id", Transaction::getId)
 * .add("date", Transaction::getDate)
 * .add("amount", Transaction::getAmount)
 * .build();
 * </code>
 * <br><br>
 * Example of second step (sort preparation, done multiple times, typical one pr. request) - Make a sorter for a
 * sort_by parameter - the example uses a value from a request parameter, but if this is not present it defaults back
 * to a standard sort order:
 * <br><br>
 * <code>
 * Sorter&lt;Transaction&gt; sorter = transactionSorterFactory.getSorter(sortBy!=null ? sortBy : "date,id");
 * </code>
 * After this, the sorter::sort can be used as a reference in a reactive flow:
 * <code>
 * return deferredResultOf(accountService.getTransactions(customerId, agreementId, claims.getSsn(), accountId)
 * .toSortedList(sorter::sort)
 * .map(transactionResults -&gt; {
 * return new ResponseEntity&lt;&gt;(transactionResults, headers, status);
 * }));
 * </code>
 * <br><br>
 * The sort_by parameter should be a comma seperated list of sort prioritized names identical to the names given to the factory.
 * These names ought to be snake_cased as pr. convention. Names can be prefixed with +/- or postfixed with -asc/-desc
 * to indicate ascending or descending sort order for that field.
 * <br><br>
 * If two values are equal, then sorting will evaluate the
 * following parameter values for order.
 * <br><br>
 * if the SorterFactory::getSorter method is given an field name that is not configured it will fail deliberately *
 *
 * @param <F> the type thats being sorted in the reactive flow
 * @see <a href="https://confluence.oneadr.net:8443/display/DBNS/REST%3A+2.+Sorting">Sorting doc in confluence</a>
 */
public class SorterFactory<F> {
    private static final String DESC_POSTFIX = "-desc";
    private static final String DESC_PREFIX = "-";
    private static final String ASC_POSTFIX = "-asc";
    private static final String ASC_PREFIX = "+";

    public static class Builder<B> {
        private Map<String, Function<B, Comparable>> buildingGetters = new HashMap<>();

        public Builder<B> add(String snake_case_name, Function<B, Comparable> getter) {
            buildingGetters.put(snake_case_name, getter);
            return this;
        }

        public SorterFactory<B> build() {
            return new SorterFactory<>(buildingGetters);
        }
    }

    private final Map<String, Function<F, Comparable>> getters;

    private SorterFactory(Map<String, Function<F, Comparable>> getters) {
        this.getters = getters;
    }

    /**
     * Gets (creates) a specific sorter for a specfic sort_by query string
     * <br><br>
     * If a default value is required, then a good place to set this value is in the request header annotation under defaultValue="xxx"
     *
     * @param sortBy the sort_by query value
     * @return the sorter to use in a reactive flow
     */
    public Sorter<F> getSorter(String sortBy) {
        String[] sortByFields = sortBy != null && sortBy.length() > 0 ? sortBy.split(",") : new String[0];
        int[] order = new int[sortByFields.length];
        List<Function<F, Comparable>> sortByGetters = new ArrayList<>();
        for (int i = 0; i < sortByFields.length; i++) {
            order[i] = 1;
            if (sortByFields[i].startsWith(DESC_PREFIX)) {
                sortByFields[i] = sortByFields[i].substring(1);
                order[i] = -1;
            } else if (sortByFields[i].startsWith(ASC_PREFIX)) {
                sortByFields[i] = sortByFields[i].substring(1);
            } else {
                if (sortByFields[i].endsWith(DESC_POSTFIX)) {
                    sortByFields[i] = sortByFields[i].substring(0, sortByFields[i].length() - DESC_POSTFIX.length());
                    order[i] = -1;
                } else if (sortByFields[i].endsWith(ASC_POSTFIX)) {
                    sortByFields[i] = sortByFields[i].substring(0, sortByFields[i].length() - ASC_POSTFIX.length());
                }
            }
            Function<F, Comparable> e = getters.get(sortByFields[i]);
            if (null == e) {
                throw new IllegalSortFieldNameException(String.format("Illegal sort field name '%s' (from sort string '%s')", sortByFields[i], sortBy));
            }
            sortByGetters.add(e);
        }
        return new Sorter<>(sortByGetters, order);
    }
}
