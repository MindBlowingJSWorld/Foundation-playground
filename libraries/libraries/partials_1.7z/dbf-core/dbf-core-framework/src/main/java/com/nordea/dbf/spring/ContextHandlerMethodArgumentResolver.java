package com.nordea.dbf.spring;

import com.nordea.dbf.annotation.RequestId;
import com.nordea.dbf.annotation.SessionId;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import org.apache.commons.lang.Validate;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import java.lang.annotation.Annotation;
import java.util.Optional;

public class ContextHandlerMethodArgumentResolver implements HandlerMethodArgumentResolver {

    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        Validate.notNull(methodParameter, "methodParameter");

        return annotationOf(methodParameter).isPresent();
    }

    @Override
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer, NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {
        final Optional<Annotation> annotationOptional = annotationOf(methodParameter);

        if (!annotationOptional.isPresent()) {
            throw new IllegalArgumentException("No supported annotation on parameter");
        }

        final Annotation annotation = annotationOptional.get();
        final Optional<ServiceRequestContext> requestContext = ServiceRequestContextHolder.get();

        if (!requestContext.isPresent()) {
            return null;
        }

        if (annotation instanceof SessionId) {
            return requestContext.get().getSessionId().orElse(null);
        }

        if (annotation instanceof RequestId) {
            return requestContext.get().getRequestId().orElse(null);
        }

        throw new UnsupportedOperationException("Unsupported annotation '" + annotation + "'");
    }

    private Optional<Annotation> annotationOf(final MethodParameter methodParameter) {
        for (final Annotation annotation : methodParameter.getParameterAnnotations()) {
            if (annotation instanceof RequestId) {
                return Optional.of(annotation);
            }

            if (annotation instanceof SessionId) {
                return Optional.of(annotation);
            }
        }

        return Optional.empty();
    }

}
