package com.nordea.dbf.spring;

import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import java.util.Optional;
import java.util.Set;

public class ServiceRequestContextMethodArgumentResolver implements HandlerMethodArgumentResolver {

    @Autowired
    private Validator validator;

    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        return methodParameter.getParameterType().equals(ServiceRequestContext.class);
    }

    @Override
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer, NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {

        final Optional<ServiceRequestContext> serviceRequestContext = ServiceRequestContextHolder.get();

        if (serviceRequestContext.isPresent()) {
            Set<ConstraintViolation<ServiceRequestContext>> violations = validator.validate(serviceRequestContext.get());
            if (violations.isEmpty()) {
                return serviceRequestContext.get();
            }
            else {
                throw new BadRequestException(createErrorResponse(violations));
            }
        }
        else {
            throw new BadRequestException(ErrorResponses.invalidAuthentication("Token", null));
        }
    }
    private Error createErrorResponse(Set<ConstraintViolation<ServiceRequestContext>> violations) {
        ConstraintViolation<ServiceRequestContext> violation = violations.iterator().next();
        String propertyPathName = violation.getPropertyPath().iterator().next().getName();
        String message = violation.getMessage();
        return ErrorResponses.invalidAuthentication(propertyPathName,message);
    }
}
