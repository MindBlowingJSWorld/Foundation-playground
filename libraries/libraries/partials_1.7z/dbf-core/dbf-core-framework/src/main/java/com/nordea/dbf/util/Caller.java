package com.nordea.dbf.util;

import org.apache.commons.lang.Validate;

import java.util.Arrays;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * Meta-information about a caller. Can be used to pass the caller context for traceability.
 */
public class Caller {

    private final StackTraceElement[] stackTrace;

    private final int stackTraceOffset;

    private Caller(StackTraceElement[] stackTrace, int stackTraceOffset) {
        this.stackTrace = stackTrace;
        this.stackTraceOffset = stackTraceOffset;
    }

    public static Caller here() {
        final StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();

        return new Caller(stackTrace, 2);
    }

    public String getMethodName() {
        return stackTrace[stackTraceOffset].getMethodName();
    }

    public String getClassName() {
        return stackTrace[stackTraceOffset].getClassName();
    }

    public int getLineNumber() {
        return stackTrace[stackTraceOffset].getLineNumber();
    }

    public Optional<Caller> getCaller() {
        if (stackTraceOffset >= stackTrace.length - 1) {
            return Optional.empty();
        }

        return Optional.of(new Caller(stackTrace, stackTraceOffset + 1));
    }

    public StackTraceElement[] getOriginalStackTrace() {
        return stackTrace;
    }

    public Optional<Caller> where(Predicate<Caller> predicate) {
        Validate.notNull(predicate, "predicate can't be null");

        Optional<Caller> caller = Optional.of(this);

        do {
            if (predicate.test(caller.get())) {
                return caller;
            }

            caller = caller.get().getCaller();
        } while (caller.isPresent());

        return Optional.empty();
    }

    public static Predicate<Caller> inPackage(final String packageName) {
        Validate.notEmpty(packageName, "packageName can't be null or empty");

        return input -> input.getClassName().startsWith(packageName);
    }

    public static Predicate<Caller> not(Predicate<Caller> predicate) {
        Validate.notNull(predicate, "predicate can't be null");
        return predicate.negate();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Caller caller = (Caller) o;

        if (stackTraceOffset != caller.stackTraceOffset) return false;
        // Probably incorrect - comparing Object[] arrays with Arrays.equals
        return Arrays.equals(stackTrace, caller.stackTrace);

    }

    @Override
    public int hashCode() {
        int result = Arrays.hashCode(stackTrace);
        result = 31 * result + stackTraceOffset;
        return result;
    }

    @Override
    public String toString() {
        return "Caller{className=\"" + getClassName() + "\", methodName=\"" + getMethodName() + "\", lineNumber=" + getLineNumber() + "}";
    }
}
