package com.nordea.dbf.util;

import com.google.common.collect.ImmutableList;
import org.apache.commons.lang.Validate;
import org.springframework.beans.BeanUtils;
import org.springframework.util.ReflectionUtils;

import java.beans.PropertyDescriptor;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public class Difference {
    
    private final List<Property> properties;

    private Difference(List<Property> properties) {
        this.properties = properties;
    }

    public Difference filter(Predicate<Property> function) {
        Validate.notNull(function, "function can't be null");

        final ImmutableList.Builder<Property> builder = ImmutableList.builder();

        properties.stream().filter(function::test).forEach(builder::add);

        return new Difference(builder.build());
    }

    public static<T> Difference between(T leftObject, T rightObject) {
        Validate.notNull(leftObject, "leftObject can't be null");
        Validate.notNull(rightObject, "rightObject can't be null");

        if (!leftObject.getClass().equals(rightObject.getClass())) {
            throw new IllegalArgumentException("Objects must be of the same type");
        }

        final PropertyDescriptor[] properties = BeanUtils.getPropertyDescriptors(leftObject.getClass());
        final ImmutableList.Builder<Property> differingProperties = ImmutableList.builder();

        for (final PropertyDescriptor property : properties) {
            final Object value1 = ReflectionUtils.invokeMethod(property.getReadMethod(), leftObject);
            final Object value2 = ReflectionUtils.invokeMethod(property.getReadMethod(), rightObject);

            if (!(Objects.equals(value1, value2) || (value1 == null ^ value2 == null))) {
                //TODO Special handling of Dates
                if (value1 instanceof Date && value2 instanceof Date) {
                  //Ignore as of now...
                  continue;
                }
              
                //Special handling of lists, one or the the other list is allowed to be empty...
                if (value1 instanceof List<?> && value2 instanceof List<?>) {
                  if (((List<?>) value1).isEmpty() ^ ((List<?>) value2).isEmpty()) {
                    continue;
                  }
                }
              
                differingProperties.add(new Property(property.getName(), value1, value2));
            }
        }

        return new Difference(differingProperties.build());
    }

    public static Difference none() {
        return new Difference(Collections.<Property>emptyList());
    }

    public Property getProperty(String propertyName) {
        Validate.notEmpty(propertyName, "propertyName can't be null");

        return properties.stream().filter(p -> p.getName().equals(propertyName))
                .findFirst()
                .orElse(null);
    }

    public List<Property> properties() {
        return properties;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Difference that = (Difference) o;

        return properties.equals(that.properties);

    }

    @Override
    public int hashCode() {
        return properties.hashCode();
    }

    @Override
    public String toString() {
        return "Difference{" +
                "properties=" + properties +
                '}';
    }

    public static class Property {

        private final String name;

        private final Object leftValue;

        private final Object rightValue;

        protected Property(String name, Object leftValue, Object rightValue) {
            Validate.notEmpty(name, "name can't be null or empty");
            
            this.name = name;
            this.leftValue = leftValue;
            this.rightValue = rightValue;
        }

        public String getName() {
            return name;
        }

        public Object getLeftValue() {
            return leftValue;
        }

        public Object getRightValue() {
            return rightValue;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Property property = (Property) o;

            if (!name.equals(property.name)) return false;
            if (leftValue != null ? !leftValue.equals(property.leftValue) : property.leftValue != null) return false;
            return !(rightValue != null ? !rightValue.equals(property.rightValue) : property.rightValue != null);

        }

        @Override
        public int hashCode() {
            int result = name.hashCode();
            result = 31 * result + (leftValue != null ? leftValue.hashCode() : 0);
            result = 31 * result + (rightValue != null ? rightValue.hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            return "Property{" +
                    "name='" + name + '\'' +
                    ", leftValue='" + leftValue + '\'' +
                    ", rightValue='" + rightValue + '\'' +
                    '}';
        }
    }

    public static<T> Predicate<Difference> exactly(String propertyName, T value1, T value2) {
        Validate.notEmpty(propertyName, "propertyName can't be null or empty");

        return difference -> {
            if (difference.properties.size() != 1) {
                return false;
            }

            final Property property = difference.properties.get(0);

            if (!Objects.equals(propertyName, property.getName())) {
                return false;
            }

            if (!Objects.equals(value1, property.getLeftValue())) {
                return false;
            }

            if (!Objects.equals(value2, property.getRightValue())) {
                return false;
            }

            return true;
        };
    }

}
