package com.nordea.dbf.util;

import java.util.function.Supplier;

public class Initializer {

    public static <T> T from(Supplier<T> supplier) {
        return supplier.get();
    }

}
