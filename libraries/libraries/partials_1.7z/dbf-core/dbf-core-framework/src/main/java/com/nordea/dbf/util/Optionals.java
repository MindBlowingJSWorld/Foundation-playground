package com.nordea.dbf.util;

import java.util.Optional;

public class Optionals {

    public static String toString(Optional<?> optional) {
        if (optional == null) {
            return "null";
        }

        if (!optional.isPresent()) {
            return "absent";
        }

        final Object object = optional.get();

        if (object instanceof String) {
            return "\"" + object + "\"";
        }

        return String.valueOf(object);
    }

}
