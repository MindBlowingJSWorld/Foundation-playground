package com.nordea.dbf.util;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;

import static org.apache.commons.lang.StringUtils.isEmpty;
import static org.apache.commons.lang.StringUtils.isNotBlank;

public class PropertyConverter {
    private static final Logger LOG = LoggerFactory.getLogger(PropertyConverter.class);

    public static String[] splitPropertyOnPipe(String elements) {
        Validate.notNull(elements, "elements can't be null");

        final Set<String> result = new HashSet<>();

        if (!isEmpty(elements)) {
            // Split the property on bar
            for (String element : elements.split("\\|+")) {
                element = element.trim();
                if (isNotBlank(element)) {
                    LOG.trace("Adding element '" + element + "' to set.");
                    result.add(element);
                } else {
                    LOG.trace("Skip adding empty element '" + element + "' to set.");
                }
            }
        }

        return result.toArray(new String[result.size()]);
    }


}
