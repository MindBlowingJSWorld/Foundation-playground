package com.nordea.dbf.util;

import com.google.common.base.Function;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Simple utility class for replacing variables in strings. Example:
 * <pre><code>
 * final StringTemplate template = new StringTemplate("/path/to/{something}");
 * final String actualPath = template.expand(usingMap(ImmutableMap.of("something", "xyz"))); // actualPath = "/path/to/xyz"
 * </code></pre>
 */
public final class StringTemplate {

    private enum ParseState {
        STATIC,
        VARIABLE
    }

    private final String path;

    private final List<Node> nodes;

    public StringTemplate(final String path) {
        Validate.notEmpty(path, "path can't be null or empty");

        this.path = path;
        this.nodes = parse(path);
    }

    public String expand(Function<String, String> variableResolver) {
        Validate.notNull(variableResolver, "variableResolver can't be null");

        final StringBuilder buffer = new StringBuilder();

        for (final Node node : nodes) {
            buffer.append(node.toString(variableResolver));
        }

        return buffer.toString();
    }

    public List<String> getVariables() {
        return nodes.stream()
                .filter(node -> node instanceof VariableNode)
                .map(node -> ((VariableNode) node).variableName)
                .collect(Collectors.toList());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        StringTemplate template = (StringTemplate) o;

        return path.equals(template.path);
    }

    @Override
    public int hashCode() {
        return path.hashCode();
    }

    @Override
    public String toString() {
        return "PathTemplate{" +
                "path='" + path + '\'' +
                '}';
    }

    public static Function<String, String> usingMap(final Map<String, Object> map) {
        Validate.notNull(map, "map can't be null");

        return input -> String.valueOf(map.get(input));
    }

    private static List<Node> parse(String path) {
        final StringBuilder buffer = new StringBuilder(path.length());
        final List<Node> nodes = new ArrayList<>();

        ParseState state = ParseState.STATIC;

        for (int i = 0; i <= path.length(); i++) {
            final int n = (i == path.length() ? -1 : path.charAt(i));

            switch (state) {
                case STATIC: {
                    switch (n) {
                        case '{':
                            state = ParseState.VARIABLE;
                        case -1:
                            final String text = buffer.toString();

                            if (!StringUtils.isEmpty(text)) {
                                nodes.add(new TextNode(text));
                            }

                            buffer.delete(0, buffer.length());
                            break;
                        default:
                            buffer.append((char) n);
                    }

                    break;
                }

                case VARIABLE: {
                    switch (n) {
                        case '}':
                            state = ParseState.STATIC;

                            nodes.add(new VariableNode(buffer.toString()));
                            buffer.delete(0, buffer.length());

                            break;
                        default:
                            buffer.append((char) n);
                    }

                    break;
                }
            }
        }
        return nodes;
    }

    private interface Node {

        String toString(Function<String, String> function);

    }

    private static final class TextNode implements Node {

        private final String text;

        public TextNode(String text) {
            this.text = text;
        }

        @Override
        public String toString(Function<String, String> function) {
            return text;
        }
    }

    private static final class VariableNode implements Node {

        private final String variableName;

        public VariableNode(String variableName) {
            this.variableName = variableName;
        }

        @Override
        public String toString(Function<String, String> function) {
            return function.apply(variableName);
        }
    }

}
