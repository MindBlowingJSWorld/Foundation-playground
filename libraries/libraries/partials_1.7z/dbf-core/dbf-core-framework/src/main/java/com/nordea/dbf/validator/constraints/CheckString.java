package com.nordea.dbf.validator.constraints;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.*;



@Constraint(validatedBy = CheckStringValidator.class)
@Retention(RetentionPolicy.RUNTIME)
@Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER })
public @interface CheckString {

	String message() default "CheckString constraint";

	Class<?>[] groups() default {};

	Class<? extends Payload>[] payload() default {};

	CheckStringType checkType() default CheckStringType.LETTERS;
	
}
