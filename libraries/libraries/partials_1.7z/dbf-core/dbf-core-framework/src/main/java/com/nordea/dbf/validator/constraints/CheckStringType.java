package com.nordea.dbf.validator.constraints;

public enum CheckStringType {
	EVERYTHING,  //placeholder for true. ignore any check.
	LETTERS, 	 //blacklists known htmlentities, sqlinjections, escape characters. 
	STRICT       //whitelist only known letters and digits with isLetterOrDigit(char ch)
}