package com.nordea.dbf.validator.constraints;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class CheckStringValidator implements ConstraintValidator<CheckString, CharSequence> {

	private CheckStringType chkType;
	private Set<Character> badCharSet = "/<>;#^&?`\\\"\'".chars().mapToObj(e -> (char) e).collect(Collectors.toSet());
	private HashSet<Character> checkSet = new HashSet<Character>(badCharSet);

	public void initialize(CheckString chkstring) {
				this.chkType = chkstring.checkType();
	}

	public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
		
		if (this.chkType == CheckStringType.EVERYTHING) {
			return true;
		}

		// this needs to be fast.
		// http://stackoverflow.com/questions/8894258/fastest-way-to-iterate-over-all-the-chars-in-a-string
		// .contains should be O(1)

		if (this.chkType == CheckStringType.LETTERS) {
			for (int i = 0; i < value.length(); i++) {
				if (checkSet.contains(value.charAt(i))) {
					return false;
				}
			}
			return true;
		}

		if (this.chkType == CheckStringType.STRICT) {
			for (int i = 0; i < value.length(); i++) {
				if (!Character.isLetterOrDigit(value.charAt(i)) && !Character.isWhitespace(value.charAt(i))) {
					return false;
				}
			}
			return true;
		}

		return false;
	}

}
