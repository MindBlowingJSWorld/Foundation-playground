package com.nordea.dbf.concurrent;

import org.junit.Before;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

public class CompositeThreadContextTest {

    private final ThreadContext target1 = mock(ThreadContext.class);
    private final ThreadContext target2 = mock(ThreadContext.class);
    private final CompositeThreadContext threadContext = new CompositeThreadContext(new ThreadContext[]{target1, target2});
    private final Handover handover1 = mock(Handover.class);
    private final Handover handover2 = mock(Handover.class);

    @Before
    public void setup() {
        when(target1.createHandover()).thenReturn(handover1);
        when(target2.createHandover()).thenReturn(handover2);
    }

    @Test
    public void threadContextCannotBeInvalid() {
        assertThatThrownBy(() -> new CompositeThreadContext(null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new CompositeThreadContext(new ThreadContext[]{null})).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void commitShouldCallAllDelegatedThreadContexts() {
        final Handover handover = threadContext.createHandover();

        handover.commit();

        verify(handover1).commit();
        verify(handover2).commit();
    }

    @Test
    public void closeShouldCallAllDelegatedThreadContexts() {
        final Handover handover = threadContext.createHandover();

        handover.close();

        verify(handover1).close();
        verify(handover2).close();
    }

}
