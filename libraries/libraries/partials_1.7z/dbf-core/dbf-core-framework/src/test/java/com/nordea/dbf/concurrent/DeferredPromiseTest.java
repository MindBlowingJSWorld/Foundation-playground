package com.nordea.dbf.concurrent;

import org.junit.Test;
import org.mockito.InOrder;
import rx.Observer;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@SuppressWarnings("unchecked")
public class DeferredPromiseTest {

    private final Observer observer = mock(Observer.class);

    @Test
    public void observerShouldGetNotifiedImmediatelyIfPromiseIsCompleted() {
        // Given
        final DeferredPromise<String> promise = DeferredPromise.create();
        promise.complete("foo");

        // When
        promise.toObservable().subscribe(observer);

        // Then
        final InOrder inOrder = inOrder(observer);

        inOrder.verify(observer).onNext(eq("foo"));
        inOrder.verify(observer).onCompleted();
    }

    @Test
    public void observerShouldGetNotifiedWhenPromiseCompleted() {
        // Given
        final DeferredPromise<String> promise = DeferredPromise.create();

        // When
        promise.toObservable().subscribe(observer);

        verifyZeroInteractions(observer);

        promise.complete("foo");

        // Then
        final InOrder inOrder = inOrder(observer);

        inOrder.verify(observer).onNext(eq("foo"));
        inOrder.verify(observer).onCompleted();
    }

    @Test(expected = IllegalArgumentException.class)
    public void promiseCannotBeFailedWithNullException() {
        DeferredPromise.create().fail(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void promiseCannotBeCompletedWithNullValue() {
        DeferredPromise.create().complete(null);
    }

    @Test
    public void observerShouldGetNotifiedImmediatelyIfPromiseIsFailed() throws Exception {
        // Given
        final Exception exception = new Exception("anException");
        final DeferredPromise<String> promise = DeferredPromise.create();

        promise.fail(exception);

        // When
        promise.toObservable().subscribe(observer);

        // Then
        verify(observer).onError(eq(exception));
        verifyNoMoreInteractions(observer);
    }

    @Test
    public void observerShouldGetNotifiedWhenPromiseFails() {
        // Given
        final DeferredPromise<String> promise = DeferredPromise.create();
        final Exception anException = new Exception("anException");

        // When
        promise.toObservable().subscribe(observer);
        verifyZeroInteractions(observer);

        promise.fail(anException);

        // Then
        verify(observer).onError(eq(anException));
        verifyNoMoreInteractions(observer);
    }

    @Test
    public void completedPromiseCannotBeCompleted() {
        final DeferredPromise<Object> promise = DeferredPromise.create();

        promise.complete("foo");

        try {
            promise.complete("bar");
            fail("completed promise should reject completed");
        } catch (IllegalStateException e) {
        }
    }

    @Test
    public void completedPromiseCannotBeFailed() {
        final DeferredPromise<Object> promise = DeferredPromise.create();

        promise.complete("foo");

        try {
            promise.fail(new RuntimeException());
            fail("completed promise should reject fail");
        } catch (IllegalStateException e) {
        }
    }

    @Test
    public void failedPromiseCannotBeCompleted() {
        final DeferredPromise<Object> promise = DeferredPromise.create();

        promise.fail(new RuntimeException());

        try {
            promise.complete("foo");
            fail("failed promise should reject complete");
        } catch (IllegalStateException e) {
        }
    }

    @Test
    public void failedPromiseCannotBeFailed() {
        final DeferredPromise<Object> promise = DeferredPromise.create();

        promise.fail(new RuntimeException());

        try {
            promise.fail(new Exception());
            fail("failed promise should reject fail");
        } catch (IllegalStateException e) {
        }
    }

    @Test
    public void idempotentObserverShouldIgnoreDuplicateOnNext() {
        // Given
        final Observer idempotentObserver = DeferredPromise.newIdempotentObserver(
            DeferredPromise.newIdempotentObserver(observer));

        // When
        idempotentObserver.onNext("foo");
        idempotentObserver.onNext("foo");

        // Then
        verify(observer, times(1)).onNext(eq("foo"));
    }

    @Test
    public void idempotentObserverShouldIgnoreDuplicateOnComplete() {
        // Given
        final Observer idempotentObserver = DeferredPromise.newIdempotentObserver(
            DeferredPromise.newIdempotentObserver(observer));

        // When
        idempotentObserver.onCompleted();
        idempotentObserver.onCompleted();

        // Then
        verify(observer, times(1)).onCompleted();
    }

    @Test
    public void idempotentObserverShouldIgnoreDuplicateOnError() {
        // Given
        final Observer idempotentObserver = DeferredPromise.newIdempotentObserver(
            DeferredPromise.newIdempotentObserver(observer));

        final RuntimeException e = new RuntimeException();

        // When
        idempotentObserver.onError(e);
        idempotentObserver.onError(e);

        // Then
        verify(observer, times(1)).onError(eq(e));
    }

    @Test
    public void outcomeMustContainValidOptionals() {
        try {
            new DeferredPromise.Outcome<String>(null, Optional.<Throwable>empty());
            fail("null value optional should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            new DeferredPromise.Outcome<String>(Optional.<String>empty(), null);
            fail("null exception optional should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void outcomeCannotContainAbsentValueAndException() {
        new DeferredPromise.Outcome<String>(Optional.<String>empty(), Optional.<Throwable>empty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void bothResultAndErrorCannotBePresentInOutcome() {
        new DeferredPromise.Outcome<String>(Optional.of("foo"), Optional.<Throwable>of(
            new RuntimeException()));
    }

    @Test
    public void doCompleteShouldNotifyAndCompleteObserverForSuccessfulOutcome() {
        DeferredPromise.doComplete(observer,
            new DeferredPromise.Outcome(Optional.of("foo"), Optional.<Throwable>empty()));

        final InOrder inOrder = inOrder(observer);

        inOrder.verify(observer).onNext(eq("foo"));
        inOrder.verify(observer).onCompleted();
        verifyNoMoreInteractions(observer);
    }

    @Test
    public void doCompleteShouldNotifyObserverAboutError() {
        final RuntimeException exception = new RuntimeException();

        DeferredPromise.doComplete(observer,
            new DeferredPromise.Outcome(Optional.<String>empty(), Optional.of(exception)));

        final InOrder inOrder = inOrder(observer);

        inOrder.verify(observer).onError(eq(exception));
        verifyNoMoreInteractions(observer);
    }

    @Test(expected = IllegalArgumentException.class)
    public void promiseCannotBeImmediatelyCompletedWithNullValue() {
        DeferredPromise.of(null);
    }

    @Test
    public void immediatelyCompletedPromiseCanBeCreated() {
        assertThat(DeferredPromise.of("foo").toObservable().toBlocking().single()).isEqualTo("foo");
    }

    @Test
    public void immediatelyFailedPromiseCanBeCreated() {
        final RuntimeException exception = new RuntimeException("anError");

        try {
            DeferredPromise.failure(exception).toObservable().toBlocking().single();
            fail("immediately failed future should propagate error");
        } catch (Exception e) {
            assertThat(e).isEqualTo(exception);
        }
    }
}
