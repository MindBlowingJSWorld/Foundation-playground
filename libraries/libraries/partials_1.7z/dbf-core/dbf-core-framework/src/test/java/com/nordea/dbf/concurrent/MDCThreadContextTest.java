package com.nordea.dbf.concurrent;

import com.google.common.collect.ImmutableMap;
import com.google.common.util.concurrent.SettableFuture;
import org.junit.After;
import org.junit.Test;
import org.slf4j.MDC;

import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

public class MDCThreadContextTest {

    private final MDCThreadContext context = new MDCThreadContext();

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @After
    public void tearDown() {
        MDC.clear();

        executor.shutdown();
    }

    @Test
    public void mdcContextShouldBeCarriedOverToNewThread() throws Exception {
        final ImmutableMap<String, String> properties1 = ImmutableMap.of("foo", "bar");
        final ImmutableMap<String, String> properties2 = ImmutableMap.of("foo", "baz");

        MDC.setContextMap(properties1);

        final SettableFuture<Map<String, String>> thread1Properties = SettableFuture.create();
        final Handover handover1 = context.createHandover();
        executor.execute(() -> handover1.in(() -> thread1Properties.set(MDC.getCopyOfContextMap())));
        assertThat(thread1Properties.get(1, TimeUnit.SECONDS)).isEqualTo(properties1);

        MDC.setContextMap(properties2);

        final SettableFuture<Map<String, String>> thread2Properties = SettableFuture.create();
        final Handover handover2 = context.createHandover();
        executor.execute(() -> handover2.in(() -> thread2Properties.set(MDC.getCopyOfContextMap())));
        assertThat(thread2Properties.get(1, TimeUnit.SECONDS)).isEqualTo(properties2);
    }

    protected Thread execute(Runnable runnable) {
        final Thread thread = new Thread(runnable);

        thread.start();

        return thread;
    }

}
