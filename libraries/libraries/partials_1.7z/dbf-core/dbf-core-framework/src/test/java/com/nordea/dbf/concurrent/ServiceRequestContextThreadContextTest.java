package com.nordea.dbf.concurrent;

import com.google.common.util.concurrent.SettableFuture;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import org.junit.After;
import org.junit.Test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class ServiceRequestContextThreadContextTest {

    private final ServiceRequestContextThreadContext threadContext = new ServiceRequestContextThreadContext();

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @After
    public void tearDown() {
        ServiceRequestContextHolder.clear();
        executor.shutdown();
    }

    @Test
    public void serviceContextShouldBeCarriedOverToNewThread() throws Exception {
        final ServiceRequestContext requestContext = mock(ServiceRequestContext.class);

        ServiceRequestContextHolder.bind(requestContext);

        final Handover handover = threadContext.createHandover();
        final SettableFuture<ServiceRequestContext> future = SettableFuture.create();

        executor.execute(() -> handover.in(() -> future.set(ServiceRequestContextHolder.get().get())));

        assertThat(future.get(1, TimeUnit.SECONDS)).isEqualTo(requestContext);
    }
}
