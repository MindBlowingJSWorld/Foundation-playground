package com.nordea.dbf.concurrent;

import com.google.common.util.concurrent.SettableFuture;
import org.junit.After;
import org.junit.Test;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class SpringThreadContextTest {

    private final SpringThreadContext threadContext = new SpringThreadContext();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final RequestAttributes requestAttributes = mock(RequestAttributes.class);

    @After
    public void tearDown() {
        executor.shutdown();
        RequestContextHolder.resetRequestAttributes();
    }

    @Test
    public void noHandOverShouldBeMadeIfNoContextIsConfigured() throws Exception {
        // given
        final Future<RequestAttributes> future = getContextAsync();

        // when
        final RequestAttributes requestAttributes = future.get();

        // then
        assertThat(requestAttributes).isNull();
    }

    @Test
    public void existingRequestContextShouldBeTransferredToNewThread() throws Exception {
        // given
        RequestContextHolder.setRequestAttributes(requestAttributes);
        final Future<RequestAttributes> future = getContextAsync();

        // when
        final RequestAttributes requestAttributes = future.get();

        // then
        assertThat(requestAttributes).isSameAs(this.requestAttributes);
    }

    @Test
    public void oldRequestAttributesShouldBeRestoredIfConfigured() {
        // given
        final RequestAttributes otherRequestAttributes = mock(RequestAttributes.class);
        RequestContextHolder.setRequestAttributes(otherRequestAttributes);
        final Handover handover = threadContext.createHandover();

        RequestContextHolder.setRequestAttributes(requestAttributes);

        // when
        handover.commit();

        // then
        assertThat(RequestContextHolder.getRequestAttributes()).isSameAs(otherRequestAttributes);

        // when
        handover.close();

        // then
        assertThat(RequestContextHolder.getRequestAttributes()).isSameAs(requestAttributes);
    }

    private Future<RequestAttributes> getContextAsync() {
        final SettableFuture<RequestAttributes> future = SettableFuture.create();
        final Handover handover = threadContext.createHandover();

        executor.execute(() -> handover.in(() -> future.set(RequestContextHolder.getRequestAttributes())));

        return future;
    }

}
