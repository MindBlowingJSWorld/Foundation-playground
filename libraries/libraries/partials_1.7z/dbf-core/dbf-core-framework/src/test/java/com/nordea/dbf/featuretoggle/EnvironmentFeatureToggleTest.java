package com.nordea.dbf.featuretoggle;

import org.junit.Test;
import org.springframework.core.env.Environment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

public class EnvironmentFeatureToggleTest {

    private final Environment environment = mock(Environment.class);

    private final FeatureToggle featureToggle = new EnvironmentFeatureToggle(environment, "feature.{feature}.enabled");

    @Test
    public void constructorShouldRejectInvalidArguments() {
        assertThatThrownBy(() -> new EnvironmentFeatureToggle(null, "{feature}")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new EnvironmentFeatureToggle(environment, null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new EnvironmentFeatureToggle(environment, "")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new EnvironmentFeatureToggle(environment, "static_string")).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new EnvironmentFeatureToggle(environment, "invalid.{feature}.{replacement}")).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void enabledShouldRejectNullFeature() {
        assertThatThrownBy(() -> featureToggle.enabled(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void enabledShouldReturnTrueIfFeatureIsExplicitlyEnabled() {
        when(environment.getProperty(eq("feature.FEATURE1.enabled"), eq("false"))).thenReturn("true");
        when(environment.getProperty(eq("feature.FEATURE2.enabled"), eq("false"))).thenReturn("false");

        assertThat(featureToggle.enabled(TestFeature.FEATURE1)).isTrue();
        assertThat(featureToggle.enabled(TestFeature.FEATURE2)).isFalse();
    }

    @Test
    public void resultFromFeatureCanBeExecuted() {
        when(environment.getProperty(eq("feature.FEATURE1.enabled"), eq("false"))).thenReturn("true");
        when(environment.getProperty(eq("feature.FEATURE2.enabled"), eq("false"))).thenReturn("false");

        final String result1 = featureToggle.on(TestFeature.FEATURE1)
                .get(() -> "foo")
                .otherwise(() -> "bar");

        final String result2 = featureToggle.on(TestFeature.FEATURE2)
                .get(() -> "foo")
                .otherwise(() -> "bar");

        assertThat(result1).isEqualTo("foo");
        assertThat(result2).isEqualTo("bar");
    }

    private enum TestFeature implements Feature {
        FEATURE1,
        FEATURE2
    }

}
