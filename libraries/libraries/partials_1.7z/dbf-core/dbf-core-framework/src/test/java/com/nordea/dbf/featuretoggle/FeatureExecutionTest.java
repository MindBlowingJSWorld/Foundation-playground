package com.nordea.dbf.featuretoggle;

import org.junit.Test;

import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

public class FeatureExecutionTest {

    private final FeatureExecution active = new FeatureExecution(mock(Feature.class), () -> true);

    private final FeatureExecution inactive = new FeatureExecution(mock(Feature.class), () -> false);

    @Test
    public void constructorShouldRejectInvalidArguments() {
        assertThatThrownBy(() -> new FeatureExecution(null, mock(Supplier.class))).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new FeatureExecution(mock(Feature.class), null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void getShouldReturnActiveSupplierIfToggleIsEnabled() {
        final String result = active.get(() -> "foo").otherwise(() -> "bar");

        assertThat(result).isEqualTo("foo");
    }

    @Test
    public void getShouldReturnInactiveSupplierIfToggleIsDisabled() {
        final String result = inactive.get(() -> "foo").otherwise(() -> "bar");

        assertThat(result).isEqualTo("bar");
    }

    @Test
    public void getShouldRejectInvalidSuppliers() {
        assertThatThrownBy(() -> active.get(null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> active.get(mock(Supplier.class)).otherwise(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void runShouldRejectInvalidArgument() {
        assertThatThrownBy(() -> active.run(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void runShouldCallRunnableIfActivated() {
        final Runnable runnable = mock(Runnable.class);

        active.run(runnable);

        verify(runnable).run();
    }

    @Test
    public void runShouldNotCallRunnableIfInactive() {
        final Runnable runnable = mock(Runnable.class);

        inactive.run(runnable);

        verifyZeroInteractions(runnable);
    }

    @Test
    public void ensureEnabledShouldReturnIfFeatureIsEnabled() {
        active.ensureEnabled();
        active.ensureEnabled(() -> {});
    }

    @Test
    public void ensureEnaledShouldThrowIfFeatureIsDisabled() {
        assertThatThrownBy(inactive::ensureEnabled).isInstanceOf(FeatureNotEnabledException.class);

        final Runnable runnable = mock(Runnable.class);
        assertThatThrownBy(() -> inactive.ensureEnabled(runnable)).isInstanceOf(FeatureNotEnabledException.class);
        verify(runnable).run();
    }

}
