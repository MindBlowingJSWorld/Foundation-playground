package com.nordea.dbf.filter;

import org.junit.Test;

import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

public class DateFilterExpressionTest {

    @Test
    public void allFiltersShouldRejectNullExpression() {
        for (final DateFilterExpression expression : DateFilterExpression.values()) {
            try {
                expression.parse(null);
                fail("null expression should be rejected");
            } catch (IllegalArgumentException e) {
            }
        }
    }

    @Test
    public void filterTypeAndValueTypeShouldBeDefinedInAllFilters() {
        for (final DateFilterExpression expression : DateFilterExpression.values()) {
            assertThat(expression.getFilterType()).isEqualTo(DateFilter.class);
            assertThat(expression.getValueType()).isEqualTo(LocalDate.class);
        }
    }

    @Test
    public void beforeFilterShouldRejectInvalidFormat() {
        assertThat(DateFilterExpression.BEFORE.parse("after(2015-01-01)")).isEqualTo(Optional.empty());
        assertThat(DateFilterExpression.BEFORE.parse("before(invalid)")).isEqualTo(Optional.empty());
    }

    @Test
    public void beforeFilterShouldAcceptValidFormat() {
        assertThat(DateFilterExpression.BEFORE.parse("before(2015-01-01)")).isEqualTo(Optional.of(DateFilter.before(LocalDate.parse("2015-01-01"))));
        // assertThat(DateFilterExpression.BEFORE.parse("before(2015-01)")).isEqualTo(Optional.of(DateFilter.before(LocalDate.parse("2015-01"))));
        // assertThat(DateFilterExpression.BEFORE.parse("before(2015)")).isEqualTo(Optional.of(DateFilter.before(LocalDate.parse("2015"))));
    }

    @Test
    public void afterFilterShouldRejectInvalidFormat() {
        assertThat(DateFilterExpression.AFTER.parse("before(2015-01-01)")).isEqualTo(Optional.empty());
        assertThat(DateFilterExpression.AFTER.parse("after(invalid)")).isEqualTo(Optional.empty());
    }

    @Test
    public void afterFilterShouldAcceptValidFormat() {
        assertThat(DateFilterExpression.AFTER.parse("after(2015-01-01)")).isEqualTo(Optional.of(DateFilter.after(LocalDate.parse("2015-01-01"))));
        // assertThat(DateFilterExpression.AFTER.parse("after(2015-01)")).isEqualTo(Optional.of(DateFilter.after(LocalDate.parse("2015-01"))));
        // assertThat(DateFilterExpression.AFTER.parse("after(2015)")).isEqualTo(Optional.of(DateFilter.after(LocalDate.parse("2015"))));
    }

    @Test
    public void betweenFilterShouldRejectInvalidFormat() {
        assertThat(DateFilterExpression.BETWEEN.parse("before(2015-01-01)")).isEqualTo(Optional.empty());
        assertThat(DateFilterExpression.BETWEEN.parse("between(2015-01-01)")).isEqualTo(Optional.empty());
        assertThat(DateFilterExpression.BETWEEN.parse("between(2015-01-01, invalid)")).isEqualTo(Optional.empty());
    }

    @Test
    public void betweenFilterShouldAcceptValidFormat() {
        assertThat(DateFilterExpression.BETWEEN.parse("between(2015-01-01, 2015-01-02)")).isEqualTo(Optional.of(DateFilter.between(LocalDate.parse("2015-01-01"), LocalDate.parse("2015-01-02"))));
        //assertThat(DateFilterExpression.BETWEEN.parse("between(2015-01,2015-02)")).isEqualTo(Optional.of(DateFilter.between(LocalDate.parse("2015-01"), LocalDate.parse("2015-02"))));
        //assertThat(DateFilterExpression.BETWEEN.parse("between(2015, 2016)")).isEqualTo(Optional.of(DateFilter.between(LocalDate.parse("2015"), LocalDate.parse("2016"))));
    }
}
