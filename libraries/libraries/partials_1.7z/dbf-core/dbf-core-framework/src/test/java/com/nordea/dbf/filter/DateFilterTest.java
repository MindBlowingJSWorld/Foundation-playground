package com.nordea.dbf.filter;

import org.junit.Test;

import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

public class DateFilterTest {

    @Test
    public void dateIntervalCannotHaveNullStartOrEndDate() {
        try {
            DateFilter.between(null, LocalDate.now());
            fail("null startDate should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            DateFilter.between(LocalDate.now(), null);
            fail("null endDate should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void dateIntervalCannotHaveEndDateBeforeStartDate() {
        DateFilter.between(LocalDate.parse("2015-01-02"), LocalDate.parse("2015-01-01"));
    }

    @Test
    public void dateIntervalShouldCreateDateFilterWithStartAndEndDate() {
        final LocalDate startDate = LocalDate.parse("2015-01-01");
        final LocalDate endDate = LocalDate.parse("2015-01-02");
        final DateFilter dateFilter = DateFilter.between(startDate, endDate);

        assertThat(dateFilter.getStartDate()).isEqualTo(Optional.of(startDate));
        assertThat(dateFilter.getEndDate()).isEqualTo(Optional.of(endDate));
    }

    @Test(expected = IllegalArgumentException.class)
    public void afterDateFilterCannotHaveNullReferenceDate() {
        DateFilter.after(null);
    }

    @Test
    public void afterDateFilterShouldHaveStartDateButNoEndDate() {
        final LocalDate startDate = LocalDate.parse("2015-01-01");
        final DateFilter dateFilter = DateFilter.after(startDate);

        assertThat(dateFilter.getStartDate()).isEqualTo(Optional.of(startDate));
        assertThat(dateFilter.getEndDate()).isEqualTo(Optional.empty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void beforeDateFilterCannotHaveNullReferenceDate() {
        DateFilter.before(null);
    }

    @Test
    public void beforeDateFilterShouldHaveEndDateButNoStartDate() {
        final LocalDate endDate = LocalDate.parse("2015-01-01");
        final DateFilter filter = DateFilter.before(endDate);

        assertThat(filter.getStartDate()).isEqualTo(Optional.empty());
        assertThat(filter.getEndDate()).isEqualTo(Optional.of(endDate));
    }

    @Test
    public void nullDateShouldNotBeAccepted() {
        assertThat(DateFilter.before(LocalDate.now()).accept(null)).isFalse();
    }

    @Test
    public void intervalFilterShouldOnlyAcceptDatesWithinInterval() {
        final DateFilter filter = DateFilter.between(LocalDate.parse("2015-01-01"), LocalDate.parse("2015-01-31"));

        assertThat(filter.accept(LocalDate.parse("2014-12-30"))).isFalse();
        assertThat(filter.accept(LocalDate.parse("2015-01-01"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-01-02"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-01-31"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-02-01"))).isFalse();
    }

    @Test
    public void beforeFilterShouldAcceptOnlyDatesBefore() {
        final DateFilter filter = DateFilter.before(LocalDate.parse("2015-01-31"));

        assertThat(filter.accept(LocalDate.parse("2014-12-30"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-01-01"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-01-02"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-01-31"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-02-01"))).isFalse();
    }

    @Test
    public void afterFilterShouldOnlyAcceptDatesAfter() {
        final DateFilter filter = DateFilter.after(LocalDate.parse("2015-01-01"));

        assertThat(filter.accept(LocalDate.parse("2014-12-30"))).isFalse();
        assertThat(filter.accept(LocalDate.parse("2015-01-01"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-01-02"))).isTrue();
        assertThat(filter.accept(LocalDate.parse("2015-01-31"))).isTrue();
    }

}
