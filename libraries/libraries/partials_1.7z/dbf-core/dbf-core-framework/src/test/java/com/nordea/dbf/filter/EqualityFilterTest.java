package com.nordea.dbf.filter;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class EqualityFilterTest {

    @Test
    public void filterShouldAcceptEqualValue() {
        assertThat(new EqualityFilter<>("foo").accept(new String("foo"))).isTrue();
    }

    @Test
    public void filterShouldNotAcceptUnEqualValue() {
        assertThat(new EqualityFilter<>("foo").accept("bar")).isFalse();
    }

    @Test
    public void expectedValueCanBeRetrieved() {
        assertThat(new EqualityFilter<>("foo").getExpectedValue()).isEqualTo("foo");
    }

}
