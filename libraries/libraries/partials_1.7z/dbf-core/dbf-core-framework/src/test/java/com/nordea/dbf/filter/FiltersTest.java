package com.nordea.dbf.filter;

import org.junit.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

public class FiltersTest {

    @Test
    public void dateFilterFromShouldNotAcceptNullOrEmptyFilter() {
        try {
            Filters.dateFilterFrom(null);
            fail("null string should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            Filters.dateFilterFrom("");
            fail("empty string should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void invalidDateExpressionShouldBeRejected() {
        try {
            Filters.dateFilterFrom("invalid");
            fail("invalid expression should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void dateFilterCanRepresentRange() {
        final DateFilter dateFilter = Filters.dateFilterFrom("between(2014-01-01, 2014-01-31)");

        assertThat(dateFilter.getStartDate().get().toString()).isEqualTo("2014-01-01");
        assertThat(dateFilter.getEndDate().get().toString()).isEqualTo("2014-01-31");
    }

    @Test
    public void dateFilterCanRepresentEarliestDate() {
        final DateFilter dateFilter = Filters.dateFilterFrom("after(2015-01-01)");

        assertThat(dateFilter.getStartDate().get().toString()).isEqualTo("2015-01-01");
        assertThat(dateFilter.getEndDate()).isEqualTo(Optional.empty());
    }

    @Test
    public void dateFilterCanRepresentLatestDate() {
        final DateFilter dateFilter = Filters.dateFilterFrom("before(2015-01-31)");

        assertThat(dateFilter.getStartDate()).isEqualTo(Optional.empty());
        assertThat(dateFilter.getEndDate().get().toString()).isEqualTo("2015-01-31");
    }
}
