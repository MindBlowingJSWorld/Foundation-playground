package com.nordea.dbf.filter;

import org.junit.Test;

import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class ListFilterTest {

    @Test
    public void acceptableValuesCannotBeNull() {
        assertThatThrownBy(() -> new ListFilter<String>(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void providedAcceptableValuesShouldBeAccessible() {
        final ListFilter<String> filter = new ListFilter<>(Arrays.asList("foo", "bar"));

        assertThat(filter.getValues()).containsExactly("foo", "bar");
    }

    @Test
    public void acceptShouldRejectNull() {
        assertThat(new ListFilter<>(Arrays.asList("foo")).accept(null)).isFalse();
    }

    @Test
    public void stringNotInSetShouldNotBeAccepted() {
        assertThat(new ListFilter<>(Arrays.asList("foo", "bar")).accept("baz")).isFalse();
    }

    @Test
    public void stringInAcceptableSetShouldBeAccepted() {
        final Filter<String> filter = new ListFilter<>(Arrays.asList("foo", "bar"));

        assertThat(filter.accept("foo")).isTrue();
        assertThat(filter.accept("bar")).isTrue();
    }

}
