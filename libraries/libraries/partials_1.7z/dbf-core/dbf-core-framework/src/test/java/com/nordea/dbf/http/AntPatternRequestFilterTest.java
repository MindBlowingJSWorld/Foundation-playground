package com.nordea.dbf.http;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;

import javax.servlet.http.HttpServletRequest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AntPatternRequestFilterTest {

    private AntPatternRequestFilter filter;

    @Before
    public void setup() {
        this.filter = AntPatternRequestFilter.from("/test/**|/another/test/**");
    }

    @Test
    public void antPatternCannotBeInvalid() {
        assertThatThrownBy(() -> AntPatternRequestFilter.from(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void excludedPathShouldNotMatchRequest() {
        assertThat(filter.test(requestFor("/test/foo"))).isFalse();
        assertThat(filter.test(requestFor("/test/bar"))).isFalse();
        assertThat(filter.test(requestFor("/another/test/foo"))).isFalse();
        assertThat(filter.test(requestFor("/another/test/bar"))).isFalse();
    }

    @Test
    public void nonExcludedPathShouldMatchRequest() {
        assertThat(filter.test(requestFor("/xyz"))).isTrue();
        assertThat(filter.test(requestFor("/baz"))).isTrue();
        assertThat(filter.test(requestFor("/foo/bar/baz"))).isTrue();
        assertThat(filter.test(requestFor("/"))).isTrue();
    }

    protected HttpServletRequest requestFor(String path) {
        final HttpServletRequest request = mock(HttpServletRequest.class);

        when(request.getServletPath()).thenReturn(StringUtils.EMPTY);
        when(request.getPathInfo()).thenReturn(path);

        return request;
    }

}
