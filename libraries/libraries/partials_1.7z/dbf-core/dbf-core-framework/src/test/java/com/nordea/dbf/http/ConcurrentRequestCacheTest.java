package com.nordea.dbf.http;

import org.junit.Test;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

public class ConcurrentRequestCacheTest {

    private final ConcurrentRequestCache cache = new ConcurrentRequestCache();

    @Test
    public void getShouldRejectInvalidArguments() {
        assertThatThrownBy(() -> cache.get(null, () -> null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> cache.get("foo", null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void getShouldReturnValueFromSupplierOnTheFirstCall() throws InterruptedException {
        final Supplier<String> supplier = mock(Supplier.class);

        when(supplier.get()).thenReturn("1234");

        final String result = cache.get("foo", supplier);

        assertThat(result).isEqualTo("1234");
    }

    @Test
    public void getShouldReturnCachedValueSecondCall() throws InterruptedException {
        final Supplier<String> supplier = mock(Supplier.class);

        when(supplier.get()).thenReturn("1234");

        final String result1 = cache.get("foo", supplier);
        final String result2 = cache.get("foo", supplier);

        assertThat(result1).isEqualTo(result2);

        verify(supplier, times(1)).get();
    }

    @Test
    public void getShouldNotReturnCachedValueForDifferentKey() throws InterruptedException {
        final String result1 = cache.get("foo", () -> "value1");
        final String result2 = cache.get("bar", () -> "value2");

        assertThat(result1).isEqualTo("value1");
        assertThat(result2).isEqualTo("value2");
    }

    @Test
    public void clearShouldRemoveAllCacheEntries() throws InterruptedException {
        final Supplier<String> supplier = mock(Supplier.class);

        when(supplier.get()).thenReturn("bar");

        final String value1 = cache.get("foo", supplier);
        assertThat(value1).isEqualTo("bar");

        cache.clear();
        final String value2 = cache.get("foo", supplier);

        assertThat(value2).isEqualTo("bar");

        verify(supplier, times(2)).get();
    }

    @Test
    public void cacheEntriesCanBeRetrievedConcurrently() throws Exception {
        final int threadCount = 4;
        final ExecutorService executor = Executors.newFixedThreadPool(threadCount);

        try {
            final Supplier<String> supplier1 = supplierOf("resultValue1");
            final Supplier<String> supplier2 = supplierOf("resultValue2");

            for (int iteration = 0; iteration < 100; iteration++) {
                final ArrayList<Future> futures1 = new ArrayList<>(threadCount);
                final ArrayList<Future> futures2 = new ArrayList<>(threadCount);

                for (int i = 0; i < threadCount; i++) {
                    futures1.add(i, executor.submit(() -> cache.get("foo", supplier1)));
                    futures2.add(i, executor.submit(() -> cache.get("bar", supplier2)));
                }

                for (Future future : futures1) {
                    assertThat(future.get()).isEqualTo("resultValue1");
                }

                for (Future future : futures2) {
                    assertThat(future.get()).isEqualTo("resultValue2");
                }

                futures1.clear();
                futures2.clear();
                cache.clear();
            }
        } finally {
            executor.shutdown();
        }
    }

    private Supplier<String> supplierOf(String resultValue) {
        final AtomicBoolean inProgress = new AtomicBoolean();
        return () -> {
            if (!inProgress.compareAndSet(false, true)) {
                throw new RuntimeException();
            }

            try {
                Thread.sleep(ThreadLocalRandom.current().nextInt(10));
            } catch (InterruptedException e) {
                Thread.interrupted();
            } finally {
                inProgress.set(false);
            }

            return resultValue;
        };
    }
}
