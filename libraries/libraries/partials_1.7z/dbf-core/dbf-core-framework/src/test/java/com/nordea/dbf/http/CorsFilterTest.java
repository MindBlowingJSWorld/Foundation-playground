package com.nordea.dbf.http;

import org.junit.Test;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class CorsFilterTest {

    private CorsFilter corsFilter = new CorsFilter("header1,header2");

    @Test
    public void testOptionsRequestIsHandledCorrectly() throws ServletException, IOException {
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpServletRequest request = mock(HttpServletRequest.class);
        FilterChain filterChain = mock(FilterChain.class);
        when(request.getMethod()).thenReturn("OPTIONS");
        corsFilter.doFilterInternal(request,response, filterChain);
        verify(response).setHeader("Access-Control-Allow-Origin", "*");
        verify(response).setHeader("Access-Control-Allow-Methods", "POST, GET, DELETE, PATCH, PUT");
        verify(response).setHeader("Access-Control-Max-Age", "3600");
        verify(response).setHeader("Access-Control-Allow-Headers", "header1,header2");
        verify(response).setStatus(HttpServletResponse.SC_OK);
        verifyZeroInteractions(filterChain);
    }

    @Test
    public void testOtherThanOptionsMethodContinuesFilterChain() throws ServletException, IOException {
        HttpServletResponse response = mock(HttpServletResponse.class);
        HttpServletRequest request = mock(HttpServletRequest.class);
        FilterChain filterChain = mock(FilterChain.class);
        when(request.getMethod()).thenReturn("GET");
        corsFilter.doFilterInternal(request,response, filterChain);
        verify(filterChain).doFilter(eq(request), eq(response));
    }
}
