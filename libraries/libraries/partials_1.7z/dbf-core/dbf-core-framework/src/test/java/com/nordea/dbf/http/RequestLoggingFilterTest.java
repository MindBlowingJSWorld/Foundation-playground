package com.nordea.dbf.http;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;
import org.slf4j.Logger;
import org.slf4j.MDC;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collections;
import java.util.function.Predicate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.hamcrest.core.StringContains.containsString;
import static org.mockito.Mockito.*;

public class RequestLoggingFilterTest {

    private final HttpRequestDescriber describer = mock(HttpRequestDescriber.class);

    private final Logger logger = mock(Logger.class);

    private final Predicate logFilter = mock(Predicate.class);

    private final RequestLoggingFilter filter = new RequestLoggingFilter(describer, logFilter) {
        @Override
        protected Logger getLogger() {
            return RequestLoggingFilterTest.this.logger;
        }
    };
    private final HttpServletRequest request = mock(HttpServletRequest.class);
    private final HttpServletResponse response = mock(HttpServletResponse.class);
    private final FilterChain filterChain = mock(FilterChain.class);

    @Before
    public void setup() {
        when(logFilter.test(any())).thenReturn(true);
    }

    @After
    public void tearDown() {
        ServiceRequestContextHolder.clear();
    }

    @Test
    public void constructorShouldNotAcceptInvalidArguments() {
        assertThatThrownBy(() -> new RequestLoggingFilter(null, request -> true)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new RequestLoggingFilter(describer, null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void requestShouldNotBeLoggedIfDebugLoggingIsDisabled() throws IOException, ServletException {
        when(logger.isDebugEnabled()).thenReturn(false);

        filter.doFilter(request, response, filterChain);

        verify(logger, times(1)).isDebugEnabled();
        verifyNoMoreInteractions(logger);
        verify(filterChain).doFilter(eq(request), eq(response));
    }

    @Test
    public void requestAndCompletionShouldBeLoggedIfDebugIsEnabled() throws IOException, ServletException {
        when(describer.describe(eq(request))).thenReturn("aRequest");
        when(logger.isDebugEnabled()).thenReturn(true);

        filter.doFilter(request, response, filterChain);

        final InOrder inOrder = inOrder(logger);

        inOrder.verify(logger).debug(anyString(), eq("aRequest"));
        inOrder.verify(logger).debug(argThat(containsString("ms")),anyString(), anyLong(),anyString());
    }

    @Test
    public void mdcContextShouldBeConfigured() throws IOException, ServletException {
        when(logger.isDebugEnabled()).thenReturn(true);
        ServiceRequestContextHolder.bind(new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .sessionId("aSession")
                .requestId("aRequest")
                .build());

        doAnswer(invocationOnMock -> {
            assertThat(MDC.get("sessionId")).isEqualTo("aSession");
            assertThat(MDC.get("requestId")).isEqualTo("aRequest");

            return null;
        }).when(filterChain).doFilter(eq(request), eq(response));

        filter.doFilter(request, response, filterChain);

        verify(filterChain).doFilter(eq(request), isA(ContentCachingResponseWrapper.class));
    }

    @Test
    public void requestsCanBeFilteredFromLogging() throws ServletException, IOException {
        when(logFilter.test(eq(request))).thenReturn(false);

        filter.doFilter(request, response, filterChain);

        verifyZeroInteractions(logger);
        verify(filterChain).doFilter(eq(request), eq(response));
    }
}
