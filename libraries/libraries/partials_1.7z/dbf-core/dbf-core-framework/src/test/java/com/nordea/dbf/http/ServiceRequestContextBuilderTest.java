package com.nordea.dbf.http;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Locale;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class ServiceRequestContextBuilderTest {

    @Test
    public void generateIdShouldGenerateIdOf10Positions() {
        String generatedId = new ServiceRequestContextBuilder().generateId();
        assertThat(generatedId).isNotEmpty();
        assertThat(generatedId.length()).isEqualTo(10);
    }

    @Test
    public void contextWithAllPropertiesCanBeBuilt() {
        final ServiceRequestContext context = completeServiceRequestContextBuilder()
                .build();

        assertThat(context.getApplicationId()).isEqualTo(Optional.of("app1"));
        assertThat(context.getRequestId()).isEqualTo(Optional.of("myRequest"));
        assertThat(context.getSessionId()).isEqualTo(Optional.of("mySession"));
        assertThat(context.getUserId()).isEqualTo(Optional.of("myUser"));
        assertThat(context.getAuthenticationMethod()).isEqualTo(Optional.of("BANKID"));
        assertThat(context.getAuthenticationLevel()).isEqualTo(Optional.of("HIGH"));
        assertThat(context.getRemoteAddress()).isEqualTo("127.0.0.1");
        assertThat(context.getChannelId()).isEqualTo(Optional.of("RBO"));
        assertThat(context.getCountry()).isEqualTo(Optional.of("SE"));
        assertThat(context.getLanguage()).isEqualTo(Optional.of(new Locale("sv")));
        assertThat(context.getTimeStamp()).isEqualTo(1234L);
        assertThat(context.getAgreementNumber()).isEqualTo(Optional.of(1000L));
    }

    @Test
    public void requestRouteCanBeSpecifiedOnServiceRequestContext() {
        final ServiceRequestContext context = completeServiceRequestContextBuilder()
                .requestRoute(Arrays.asList("foo", "bar", "baz"))
                .build();

        assertThat(context.getRequestRoute()).isEqualTo(Arrays.asList("foo", "bar", "baz"));
    }

    @Test
    public void remoteAddressShouldBeFetchedFromRequestRoute() {
        final ServiceRequestContext context = completeServiceRequestContextBuilder().requestRoute(Arrays.asList("foo", "bar")).build();

        assertThat(context.getRemoteAddress()).isEqualTo("foo");
    }

    @Test
    public void timeStampShouldBeSetToCurrentIfNotSet() {
        final long before = System.currentTimeMillis();
        final ServiceRequestContext context = completeServiceRequestContextBuilder().timeStamp(-1L).build();
        final long after = System.currentTimeMillis();

        assertThat(context.getTimeStamp()).isBetween(before, after);
    }

    @Test
    public void toStringValueShouldContainCustomerId() {
        final ServiceRequestContext serviceRequestContext = completeServiceRequestContextBuilder().build();
        assertThat(serviceRequestContext.toString()).contains("myUser");
    }


    @Test
    public void buildFromReturnsCorrectServiceRequestContextFromOptionalParameter() {
        String appId = new ServiceRequestContextBuilder().build().getApplicationId().orElse(null);
        assertThat(appId).isNull();
        appId = new ServiceRequestContextBuilder().applicationId("app").build().getApplicationId().orElse(null);
        assertThat(appId).isEqualTo("app");

    }

    private ServiceRequestContextBuilder completeServiceRequestContextBuilder() {
        return new ServiceRequestContextBuilder().applicationId("app1")
                .requestId("myRequest")
                .sessionId("mySession")
                .userId("myUser")
                .authenticationMethod("BANKID")
                .authenticationLevel("HIGH")
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .channelId("RBO")
                .country("SE")
                .agreementNumber(1000L)
                .language(new Locale("sv"))
                .timeStamp(1234L);
    }

}
