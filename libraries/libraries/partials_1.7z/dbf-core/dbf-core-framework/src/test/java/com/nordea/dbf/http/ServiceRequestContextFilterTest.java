package com.nordea.dbf.http;

import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.http.contextappender.ClientRequestContextAppender;
import com.nordea.dbf.model.http.DBFClientServiceRequestContext;
import com.nordea.dbf.util.ServiceContextMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;

import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.Future;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ServiceRequestContextFilterTest {

    private ServiceContextMock serviceContextMock = new ServiceContextMock();

    @Before
    public void setup() {
        serviceContextMock.setup();
    }

    @After
    public void tearDown() {
        ServiceRequestContextHolder.clear();
        SecurityContextHolder.clearContext();
    }

    @Test
    public void anonymousRequestContextShouldBeConfiguredIfNoAuthenticationOrRequestIdIsConfigured() throws Exception {
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();

        serviceContextMock.doFilter();

        assertThat(requestContext.get().get().getSessionId().isPresent()).isFalse();
        assertThat(requestContext.get().get().getRemoteAddress()).isEqualTo("127.0.0.1");

        assertThat(ServiceRequestContextHolder.get().isPresent()).isFalse();
        serviceContextMock.verifyDoFilter();
    }

    @Test(expected = AccessDeniedException.class)
    public void validationFailureShouldBeTriggerIfNoClientContextInHTTPHeader() throws Exception {
        // given
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(null);
        // when
        serviceContextMock.doFilter();
    }

    @Test
    public void serializationOfClientContextShouldAllowUnknownAttributes() throws Exception {
        // given
        String serializedClientContext = "{\"applicationId\" : \"APP2\","
            + "\"country\" : \"NO\","
            + "\"channelId\" : \"NETBANK\","
            + "\"unknownAttribute\" : \"\"}";
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serializedClientContext);
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getApplicationId()).isEqualTo(Optional.of("APP2"));
    }

    @Test(expected = AccessDeniedException.class)
    public void validationFailureShouldBeTriggerIfNoChannelIdInClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
                serviceContextMock.getContextBuilderWithMandatoryValuesSet().channelId(null).build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        // when
        serviceContextMock.doFilter();
    }

    @Test(expected = AccessDeniedException.class)
    public void validationFailureShouldBeTriggerIfNoCountryInClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().country(null).build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        // when
        serviceContextMock.doFilter();
    }

    @Test(expected = AccessDeniedException.class)
    public void validationFailureShouldBeTriggerIfNoApplicationIdInClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().applicationId(null).build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        // when
        serviceContextMock.doFilter();
    }

    @Test
    public void applicationIdShouldBeGottenFromClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().applicationId("APP2").build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getApplicationId()).isEqualTo(Optional.of("APP2"));
    }

    @Test
    public void requestIdShouldBeGottenFromClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().requestId("REQ1").build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getRequestId()).isEqualTo(Optional.of("REQ1"));
    }

    @Test
    public void timestampShouldBeGottenFromClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().timeStamp(12312412l).build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getTimeStamp()).isEqualTo(12312412l);
    }

    @Test
    public void timestampShouldBeGeneratedIfNotGottenFromClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().timeStamp(0).build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getTimeStamp()).isNotNull();
        assertThat(requestContext.get().get().getTimeStamp()).isGreaterThan(0);
    }

    @Test
    public void sessionIdShouldBeGottenFromClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().sessionId("SES3").build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getSessionId()).isEqualTo(Optional.of("SES3"));
    }

    @Test
    public void channelIdShouldBeGottenFromClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().channelId("NETBANK").build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getChannelId()).isEqualTo(Optional.of("NETBANK"));
    }

    @Test
    public void countryShouldBeGottenFromClientContextInHTTPHeader() throws Exception {
        // given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().country("NO").build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getCountry()).isEqualTo(Optional.of("NO"));
    }

    @Test
    public void requestIdShouldBeGeneratedIfNotSuppliedInHeader() throws Exception {
        //given
        DBFClientServiceRequestContext clientContext =
            serviceContextMock.getContextBuilderWithMandatoryValuesSet().requestId(null).build();
        when(serviceContextMock.request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME))).thenReturn(serviceContextMock.serialize(clientContext));
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getRequestId().isPresent()).isTrue();
    }


    @Test
    public void userIdShouldNotBeConfiguredForUnknownAuthentication() throws Exception {
        // given
        final SecurityContext context = mock(SecurityContext.class);
        when(context.getAuthentication()).thenReturn(mock(Authentication.class));
        SecurityContextHolder.setContext(context);
        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();
        // when
        serviceContextMock.doFilter();
        // then
        assertThat(requestContext.get().get().getUserId().isPresent()).isFalse();
        assertThat(requestContext.get().get().getRemoteAddress()).isEqualTo("127.0.0.1");
    }

    @Test
    public void userIdShouldNotBeConfiguredForUnknownAuthenticationDetails() throws Exception {
        final SecurityContext context = mock(SecurityContext.class);
        final Authentication authentication = mock(Authentication.class);
        when(context.getAuthentication()).thenReturn(authentication);
        when(authentication.getDetails()).thenReturn("foobar");
        SecurityContextHolder.setContext(context);

        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();

        serviceContextMock.doFilter();

        assertThat(requestContext.get().get().getUserId().isPresent()).isFalse();
        assertThat(requestContext.get().get().getRemoteAddress()).isEqualTo("127.0.0.1");
    }

    @Test
    public void userIdShouldNotBeConfiguredForDetailsWithoutTokenId() throws Exception {
        final SecurityContext context = mock(SecurityContext.class);
        final Authentication authentication = mock(Authentication.class);

        when(context.getAuthentication()).thenReturn(authentication);
        when(authentication.getDetails()).thenReturn(Collections.emptyMap());

        SecurityContextHolder.setContext(context);

        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();

        serviceContextMock.doFilter();

        assertThat(requestContext.get().get().getUserId().isPresent()).isFalse();
        assertThat(requestContext.get().get().getRemoteAddress()).isEqualTo("127.0.0.1");
    }

    @Test
    public void userIdShouldNotBeConfiguredForDetailsWithInvalidTokenId() throws Exception {
        final SecurityContext context = mock(SecurityContext.class);
        final Authentication authentication = mock(Authentication.class);

        final OAuth2AuthenticationDetails details = new OAuth2AuthenticationDetails(mock(HttpServletRequest.class));
        details.setDecodedDetails(ImmutableMap.of("jti", 1234));

        when(context.getAuthentication()).thenReturn(authentication);
        when(authentication.getDetails()).thenReturn(details);

        SecurityContextHolder.setContext(context);

        final Future<Optional<ServiceRequestContext>> requestContext =serviceContextMock.requestContext();

        serviceContextMock.doFilter();

        assertThat(requestContext.get().get().getUserId().isPresent()).isFalse();
        assertThat(requestContext.get().get().getRemoteAddress()).isEqualTo("127.0.0.1");
    }


    @Test
    public void languageWithCountryShouldBeConfiguredFromHttpHeader() throws Exception {
        when(serviceContextMock.request.getHeader(eq("Accept-Language"))).thenReturn("sv-SE");

        serviceContextMock.doFilter();

        final ServiceRequestContext requestContext = serviceContextMock.applyRequestContext();

        assertThat(requestContext.getLanguage()).isEqualTo(Optional.of(new Locale("sv", "SE")));
    }

    @Test
    public void languageWithoutCountryShouldBeConfiguredFromHttpHeader() throws Exception {
        when(serviceContextMock.request.getHeader(eq("Accept-Language"))).thenReturn("sv");

        serviceContextMock.doFilter();

        final ServiceRequestContext requestContext = serviceContextMock.applyRequestContext();

        assertThat(requestContext.getLanguage()).isEqualTo(Optional.of(new Locale("sv")));
    }

    @Test
    public void remoteAddressShouldBeSetFromXFordwardedForIfAvailable() {
        when(serviceContextMock.request.getHeader(eq("X-Forwarded-For"))).thenReturn("10.0.0.1");

        final ServiceRequestContext context = serviceContextMock.applyRequestContext();

        assertThat(context.getRemoteAddress()).isEqualTo("10.0.0.1");
    }

    @Test
    public void forwardedRequestShouldGetCompleteRoute() {
        when(serviceContextMock.request.getRemoteAddr()).thenReturn("127.0.0.1");
        when(serviceContextMock.request.getHeader(eq("X-Forwarded-For"))).thenReturn("10.0.0.1, 10.0.0.2");

        final ServiceRequestContext context = serviceContextMock.applyRequestContext();

        assertThat(context.getRequestRoute()).containsExactly("10.0.0.1", "10.0.0.2", "127.0.0.1");
    }
}
