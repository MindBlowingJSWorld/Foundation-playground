package com.nordea.dbf.http.errorhandling;

import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.http.errorhandling.exception.ConfirmationInProgressException;
import org.junit.Test;

import com.nordea.dbf.api.model.Error;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class ErrorResponsesTest {

    @Test
    public void invalidAuthenticationShouldReturnDescriptiveErrorResponse() {
        final Error error = ErrorResponses.invalidAuthentication("agreement", 1234L);

        assertThat(error.getError()).isEqualTo(ErrorResponses.Types.INVALID_AUTHENTICATION);
        assertThat(error.getErrorDescription()).contains("The authentication field is not acceptable");
        assertThat(error.getDetails().size()).isEqualTo(1);
        assertThat(error.getDetails().get(0).getParam()).isEqualTo("agreement");
    }

    @Test
    public void notUnderstoodShouldContainDescriptiveErrorResponse() {
        final Error error = ErrorResponses.requestNotUnderstood("notUnderstood", Optional
                .<String>empty());

        assertThat(error.getError()).isEqualTo(ErrorResponses.Codes.NOT_UNDERSTOOD);
        assertThat(error.getErrorDescription()).isEqualTo("notUnderstood");
    }

    @Test
    public void invalidParameterShouldReturnDescriptiveErrorResponse() {
        final Error error = ErrorResponses.invalidRequestParameter("myparam", "invalid_param");

        assertThat(error.getError()).isEqualTo(ErrorResponses.Codes.INVALID_FIELD);
        assertThat(error.getDetails().get(0).getParam()).isEqualTo("myparam");
        assertThat(error.getErrorDescription()).isEqualTo("invalid_param");
    }

    @Test
    public void invalidParameterExceptionShouldReturnExceptionWithErrorResponse() {
        final BadRequestException exception = ErrorResponses.invalidRequestParameterException("foo", "bar");

        assertThat(exception.getErrorResponse()).isEqualTo(ErrorResponses.invalidRequestParameter("foo", "bar"));
    }

    @Test
    public void notFoundShouldReturnDescriptiveErrorResponse() {
        final Error error = ErrorResponses.requestedResourceNotFound("foo", "a_message");

        assertThat(error.getError()).isEqualTo(ErrorResponses.Codes.NOT_FOUND);
        assertThat(error.getDetails().get(0).getParam()).isEqualTo("foo");
        assertThat(error.getErrorDescription()).isEqualTo("a_message");
    }

    @Test
    public void backendErrorShouldReturnDescriptiveErrorResponse() {
        final Error error = ErrorResponses.backendError("aCode", "aService", "aMessage");

        assertThat(error.getError()).isEqualTo("aCode");
        assertThat(error.getDetails().get(0).getParam()).isEqualTo("aService");
        assertThat(error.getErrorDescription()).isEqualTo("aMessage");
    }

    @Test
    public void backendTimeoutShouldReturnDescriptiveErrorMessage() {
        final Error error = ErrorResponses.backendTimeout("aService", "aMessage");

        assertThat(error.getError()).isEqualTo(ErrorResponses.Codes.TIMEOUT);
        assertThat(error.getDetails().get(0).getParam()).isEqualTo("aService");
        assertThat(error.getErrorDescription()).isEqualTo("aMessage");
    }

    @Test
    public void confirmationInProgressShouldReturnDescriptiveErrorResponse() {
        final Error error = ErrorResponses.confirmationInProgress("1234", "notCompleted");

        assertThat(error.getError()).isEqualTo(ErrorResponses.Codes.INCOMPLETE);
        assertThat(error.getDetails().get(0).getParam()).isEqualTo("OrderId: 1234");
        assertThat(error.getErrorDescription()).isEqualTo("notCompleted");
    }

    @Test
    public void confirmationInProgressExceptionShouldReturnCorrectException() {
        final ConfirmationInProgressException exception = ErrorResponses.confirmationInProgressException("1234", "aMessage");

        assertThat(exception.getErrorResponse().getError()).isEqualTo(ErrorResponses.Codes.INCOMPLETE);
        assertThat(exception.getErrorResponse().getDetails().get(0).getParam()).isEqualTo("OrderId: 1234");
        assertThat(exception.getErrorResponse().getErrorDescription()).isEqualTo("aMessage");
    }
}
