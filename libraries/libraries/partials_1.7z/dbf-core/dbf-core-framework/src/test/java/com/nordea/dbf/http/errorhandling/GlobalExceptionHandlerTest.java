package com.nordea.dbf.http.errorhandling;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.featuretoggle.FeatureNotEnabledException;
import com.nordea.dbf.http.errorhandling.exception.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.annotation.ResponseStatusExceptionResolver;
import org.springframework.web.servlet.mvc.method.annotation.ExceptionHandlerExceptionResolver;
import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;

import java.lang.reflect.Method;
import java.util.Optional;

import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration()
public class GlobalExceptionHandlerTest {

    private MockMvc mockMvc;
    private Exception ex;

    @Configuration
    static class Config {

    }

    @RestController
        public class ExceptionController {
            @RequestMapping(value="/throwException",
                            method= RequestMethod.GET)
            public void exceptionThrower() throws Exception {
                throw ex;
            }
    }

    @Before
    public void setup() {
        StandaloneMockMvcBuilder standaloneMockMvcBuilder = MockMvcBuilders.standaloneSetup(new ExceptionController());
        standaloneMockMvcBuilder.setControllerAdvice(new GlobalExceptionHandler());
        mockMvc = standaloneMockMvcBuilder.build();
    }

    // Verify that spring internal exceptions are properly handled as well
    @Test
    public void testNoHandlerFoundException() throws Exception {
        this.ex = new NoHandlerFoundException("GET", "/throwException", null);
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.NOT_FOUND.value())).andDo(r -> System.out.println("Response: " + r.getResponse().getContentAsString()));
    }

    @Test
    public void testFeatureNotEnabledException() throws Exception {
        this.ex = new FeatureNotEnabledException("");
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.BAD_REQUEST.value()));
    }

    @Test
    public void testRangeUnsatisfiableException() throws Exception {
        this.ex = new RangeUnsatisfiableException(new Error().setErrorDescription("Dummy"), new IllegalArgumentException("Test runtime exception"));
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.REQUESTED_RANGE_NOT_SATISFIABLE.value()));
    }

    @Test
    public void testSecurityException() throws Exception {
        this.ex = new SecurityException("");
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.BAD_REQUEST.value()));
    }

    @Test
    public void testAcceptedException() throws Exception {
        this.ex = new AcceptedException();
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.ACCEPTED.value())).andExpect(r -> r.getResponse().getContentAsString().equals("{}"));

        this.ex = new AcceptedException(new Error().setError("A dummy error for parsing"));
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.ACCEPTED.value())).andExpect(r -> r.getResponse().getContentAsString().equals("{\"error\":\"A dummy error for parsing\"}"));
    }

    @Test
    public void testConfirmationInProgressException() throws Exception {
        this.ex = new ConfirmationInProgressException(new Error());
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.OK.value()));
    }

    @Test
    public void testNotFoundException() throws Exception {
        this.ex = new NotFoundException(new Error());
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.NOT_FOUND.value()));
    }

    @Test
    public void testBadRequestException() throws Exception {
        this.ex = new BadRequestException(new Error());
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.BAD_REQUEST.value()));
    }

    @Test
    public void testHttpMessageNotReadableException() throws Exception {
        // Consider implementing all cases to cover all branches of the exception handler
        this.ex = new HttpMessageNotReadableException("");
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.BAD_REQUEST.value()));
    }

    @Test
    public void testInternalServerErrorException() throws Exception {
        this.ex = new InternalServerErrorException(new Error());
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    }

    @Test
    public void testJCAConnectionRecordException() throws Exception {
        this.ex = new JCAConnectionRecordException(new Error());
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    }

    @Test
    public void testUnsuccessfulBackendExecutionException() throws Exception {
        this.ex = new UnsuccessfulBackendExecutionException(new Error());
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    }

    @Test
    public void testUnauthorizedException() throws Exception {
        this.ex = new UnauthorizedException(new Error());
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.FORBIDDEN.value()));
    }

    @Test
    public void testNotImplementedException() throws Exception {
        this.ex = new NotImplementedException(new Error());
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.NOT_IMPLEMENTED.value()));
    }

    @Test
    public void testMethodArgumentNotValidException() throws Exception {
        Method method = String.class.getMethods()[0];
        this.ex = new MethodArgumentNotValidException(new MethodParameter(method, 1), mock(BindingResult.class));
        mockMvc.perform((get("/throwException"))).andExpect(status().is(HttpStatus.BAD_REQUEST.value()));
    }
}
