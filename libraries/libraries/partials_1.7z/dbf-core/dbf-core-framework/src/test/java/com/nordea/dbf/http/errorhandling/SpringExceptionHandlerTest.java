package com.nordea.dbf.http.errorhandling;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.config.ServiceConfiguration;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.Assert.fail;

@SpringApplicationConfiguration(classes = {SpringExceptionHandlerTest.TestApplication.class, ServiceConfiguration.class })
@WebAppConfiguration
@IntegrationTest("server.port=" + SpringExceptionHandlerTest.PORT)
@RunWith(SpringJUnit4ClassRunner.class)
public class SpringExceptionHandlerTest {
    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void testSpringExceptionNotFound() {
        try {
            restTemplate.getForObject("http://localhost:" + PORT + "/nonexisting", String.class);
        } catch(HttpClientErrorException e) {
            try {
                objectMapper.readValue(e.getResponseBodyAsString(), Error.class);
            } catch (IOException e1) {
                fail(String.format("The returned model is not a proper Error model %s %s", System.lineSeparator(), e.getResponseBodyAsString()));
            }
        }
    }

    @Test
    public void testSpringMethodArgumentTypeMismatchException() {
        try {
            restTemplate.postForEntity("http://localhost:" + PORT + "/methodArgument", "InvalidData", String.class);
        } catch(HttpClientErrorException e) {
            try {
                objectMapper.readValue(e.getResponseBodyAsString(), Error.class);
            } catch (IOException e1) {
                fail(String.format("The returned model is not a proper Error model %s %s", System.lineSeparator(), e.getResponseBodyAsString()));
            }
        }
    }

    @Test
    public void testSpringMissingServletRequestParameterException() {
        try {
            restTemplate.postForEntity("http://localhost:" + PORT + "/missingArgument", "OneParam", String.class);
        } catch(HttpClientErrorException e) {
            try {
                objectMapper.readValue(e.getResponseBodyAsString(), Error.class);
            } catch (IOException e1) {
                fail(String.format("The returned model is not a proper Error model %s %s", System.lineSeparator(), e.getResponseBodyAsString()));
            }
        }
    }



    // Setup
    public static final int PORT = 32770;
    private RestTemplate restTemplate;

    @BeforeClass
    public static void setupClass() {
        System.setProperty("security.basic.enabled", "false");
        System.setProperty("server.error.whitelabel.enabled", "false");
    }

    @Before
    public void setup() {
        restTemplate = new RestTemplate();
    }

    @RestController
    public static class testController {
        @RequestMapping(value = "/methodArgument",
            method = RequestMethod.POST)
        public ResponseEntity<String> methodArgument(@RequestParam int parameter) {
            return ResponseEntity.ok("Happy days");
        }

        @RequestMapping(value = "/missingArgument",
            method = RequestMethod.POST)
        public ResponseEntity<String> missingArgument(@RequestParam String first, @RequestParam int second) {
            return ResponseEntity.ok("Happy days");
        }
    }




            @SpringBootApplication
    public static class TestApplication extends SpringBootServletInitializer {

        @Override
        protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
            return application.sources(TestApplication.class);
        }

        public static void main(String[] args) {
            SpringApplication.run(TestApplication.class, args);
        }

    }
}
