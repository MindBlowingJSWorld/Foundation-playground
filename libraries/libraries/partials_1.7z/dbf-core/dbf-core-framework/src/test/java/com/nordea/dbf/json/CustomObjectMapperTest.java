package com.nordea.dbf.json;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;

public class CustomObjectMapperTest {

    @Test
    public void dateFormatCanBeSpecified() throws Exception {
        final CustomObjectMapper mapper = CustomObjectMapper.builder()
                .dateFormat("yyyyMMdd")
                .build();

        final String json = mapper.writeValueAsString(Collections.singletonMap("date", new SimpleDateFormat("yyyy-MM-dd").parse("2015-01-02")));

        assertThat(json).contains("\"date\":\"20150102\"");
    }

}