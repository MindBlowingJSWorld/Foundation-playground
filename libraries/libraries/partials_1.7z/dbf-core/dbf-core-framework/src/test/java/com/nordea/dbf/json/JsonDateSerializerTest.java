package com.nordea.dbf.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.junit.Test;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class JsonDateSerializerTest {

    private final JsonDateSerializer serializer = new JsonDateSerializer();
    private final JsonGenerator jsonGenerator = mock(JsonGenerator.class);
    private final SerializerProvider serializerProvider = mock(SerializerProvider.class);

    @Test
    public void serializeShouldGenerateISOStringByDefault() throws Exception {
        final Date date = new SimpleDateFormat("yyyy-MM-dd").parse("2015-01-02");

        serializer.serialize(date, jsonGenerator, serializerProvider);

        verify(jsonGenerator).writeString(eq("2015-01-02T00:00:00.000" + timeZoneSuffix(date)));
    }

    @Test
    public void serializeShouldUseProvidedDateFormat() throws IOException, ParseException {
        final JsonDateSerializer serializer = new JsonDateSerializer("yyyy-MM-dd");

        serializer.serialize(new SimpleDateFormat("yyyy-MM-dd").parse("2015-01-02"), jsonGenerator, serializerProvider);

        verify(jsonGenerator).writeString(eq("2015-01-02"));
    }

    private String timeZoneSuffix(Date date) {
        final long timeZoneOffset = (TimeZone.getDefault().getOffset(date.getTime()) / 3600000L);
        return (timeZoneOffset < 0 ? "-" : "+") + String.format("%02d00", timeZoneOffset);
    }

}