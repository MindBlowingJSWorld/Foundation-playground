package com.nordea.dbf.logging;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class LoggingTest {

    @Test
    public void maskedStringShouldBeNullForNullString() {
        assertThat(Logging.mask(null)).isNull();
    }

    @Test
    public void maskedStringShouldBeEmptyForEmpty() {
        assertThat(Logging.mask("")).isEmpty();
    }

    @Test
    public void maskedStringShouldDifferFromOriginalString(){
        assertThat(Logging.mask("1234")).isNotEqualTo("1234");
    }

    @Test
    public void maskedStringShouldBeTheSameForTheSameString() {
        assertThat(Logging.mask("1234")).isEqualTo(Logging.mask("1234"));
        assertThat(Logging.mask("abcd")).isEqualTo(Logging.mask("abcd"));
    }

    @Test
    public void maskedStringShouldBeDifferentForDifferentInputStrings() {
        assertThat(Logging.mask("1234")).isNotEqualTo(Logging.mask("abcd"));
    }

}