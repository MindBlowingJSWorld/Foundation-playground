package com.nordea.dbf.messaging;

import org.junit.Test;
import rx.Observable;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DirectMessageChannelTest {

    private final MessageHandler messageHandler = mock(MessageHandler.class);

    private final MessageChannel channel = new DirectMessageChannel(messageHandler);

    @Test(expected = IllegalArgumentException.class)
    public void targetMessageChannelCannotBeNull() {
        new DirectMessageChannel(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void deliveredMessageCannotBeNull() {
        channel.deliver(null);
    }

    @Test
    public void messageShouldBeDeliveredToMessageHandler() {
        final Message<String> message = Message.fromPayload("req");
        final Observable<String> response = Observable.just("res");
        final Observable<Observable<String>> observable = Observable.just(response);

        when(messageHandler.deliver(eq(message))).thenReturn(observable);

        assertThat(channel.deliver(message)).isSameAs(observable);
    }

}