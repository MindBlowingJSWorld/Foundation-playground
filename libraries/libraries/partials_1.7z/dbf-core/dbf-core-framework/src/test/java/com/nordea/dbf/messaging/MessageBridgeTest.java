package com.nordea.dbf.messaging;

import org.junit.Test;
import rx.Observable;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MessageBridgeTest {

    private final MessageChannel sourceChannel = mock(MessageChannel.class);

    private final MessageChannel targetChannel = mock(MessageChannel.class);

    private final MessageBridge bridge = new MessageBridge(sourceChannel, targetChannel);

    @Test
    public void sourceOrTargetChannelCannotBeNull() {
        try {
            new MessageBridge(null, mock(MessageChannel.class));
            assertThat("source channel can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new MessageBridge(mock(MessageChannel.class), null);
            fail("target channel can't be null");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void responseFromSourceChannelShouldBeForwardedToTargetChannel() throws Exception {
        final Message<String> message = Message.fromPayload("test");
        final Message<String> intermediate = Message.fromPayload("intermediate");
        final Message<String> result = Message.fromPayload("result");

        when(sourceChannel.deliver(eq(message))).thenReturn(Observable.<Message<?>>just(intermediate));
        when(targetChannel.deliver(eq(intermediate))).thenReturn(Observable.<Message<?>>just(result));

        final Observable<Message<?>> observable = bridge.deliver(message);

        assertThat(observable.toBlocking().single()).isEqualTo(result);
    }

    @Test(expected = IllegalArgumentException.class)
    public void nullMessageCannotBeDelivered() {
        bridge.deliver(null);
    }

}
