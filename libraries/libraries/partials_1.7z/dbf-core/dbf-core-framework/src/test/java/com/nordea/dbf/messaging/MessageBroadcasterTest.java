package com.nordea.dbf.messaging;

import org.junit.Test;
import rx.Observable;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MessageBroadcasterTest {

    private final MessageChannel messageChannel1 = mock(MessageChannel.class);

    private final MessageChannel messageChannel2 = mock(MessageChannel.class);

    private final MessageBroadcaster channel = new MessageBroadcaster(Arrays.asList(messageChannel1, messageChannel2));

    @Test(expected = IllegalArgumentException.class)
    public void targetMessageChannelsCannotBeNull() {
        new MessageBroadcaster(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void deliverShouldNotAcceptNullMessage() {
        channel.deliver(null);
    }

    @Test
    public void deliverShouldAggregateAllResponsesFromTargetChannels() throws Exception {
        when(messageChannel1.deliver(any(Message.class))).thenReturn(Observable.<Message<?>>just(Message.fromPayload("foo")));
        when(messageChannel2.deliver(any(Message.class))).thenReturn(Observable.<Message<?>>just(Message.fromPayload("bar"), Message.fromPayload("baz")));

        final Observable<Message<?>> observable = channel.deliver(Message.fromPayload("request"));
        final List<Message<?>> result = observable.toList().toBlocking().single();

        assertThat(result).containsExactly(Message.fromPayload("foo"), Message.fromPayload("bar"), Message.fromPayload("baz"));
    }

}
