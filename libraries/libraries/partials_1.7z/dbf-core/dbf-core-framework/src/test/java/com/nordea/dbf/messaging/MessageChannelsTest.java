package com.nordea.dbf.messaging;

import org.junit.Test;
import rx.Observable;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class MessageChannelsTest {

    @Test(expected = IllegalArgumentException.class)
    public void directShouldNotAcceptNullHandler() {
        MessageChannels.direct((MessageHandler<?, ?>) null);
    }

    @Test
    public void directMessageChannelShouldImmediatelyDelegateToHandler() {
        final MessageHandler messageHandler = mock(MessageHandler.class);
        final Observable result = mock(Observable.class);

        when(messageHandler.deliver(any(Message.class))).thenReturn(result);

        final Message<String> message = Message.fromPayload("example");

        MessageChannels.direct(messageHandler).deliver(message);

        verify(messageHandler).deliver(eq(message));
    }

    @Test
    public void directMessageChannelsShouldReturnChannelsForHandlers() {
        final MessageHandler messageHandler1 = mock(MessageHandler.class);
        final MessageHandler messageHandler2 = mock(MessageHandler.class);
        final List<MessageChannel> channels = MessageChannels.direct(Arrays.<MessageHandler<?, ?>>asList(messageHandler1, messageHandler2));

        for (final MessageChannel channel : channels) {
            channel.deliver(Message.fromPayload("foo"));
        }

        verify(messageHandler1).deliver(eq(Message.fromPayload("foo")));
        verify(messageHandler2).deliver(eq(Message.fromPayload("foo")));
    }

}