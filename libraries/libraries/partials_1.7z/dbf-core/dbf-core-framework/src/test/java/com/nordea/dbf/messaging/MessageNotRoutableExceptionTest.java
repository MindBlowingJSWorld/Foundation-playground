package com.nordea.dbf.messaging;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class MessageNotRoutableExceptionTest {

    @Test
    public void exceptionShouldContainErrorResponse() {
        final MessageNotRoutableException exception = new MessageNotRoutableException("anError");
        final Error error = exception.getErrorResponse();

        assertThat(error.getError()).isEqualTo(ErrorResponses.Codes.NOT_UNDERSTOOD);
        assertThat(error.getErrorDescription()).isEqualTo("anError");
    }

}
