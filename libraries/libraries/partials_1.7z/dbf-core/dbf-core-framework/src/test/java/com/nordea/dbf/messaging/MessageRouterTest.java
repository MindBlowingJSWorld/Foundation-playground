package com.nordea.dbf.messaging;

import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import rx.Observable;
import rx.functions.Action1;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class MessageRouterTest {

    private final MessageRoute route1 = mock(MessageRoute.class);

    private final MessageRoute route2 = mock(MessageRoute.class);

    private final MessageRouter router = new StaticMessageRouter(Arrays.asList(route1, route2));

    @Test(expected = IllegalArgumentException.class)
    public void routesCannotBeNull() {
        new StaticMessageRouter((List<MessageRoute>) null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void sendShouldNotAcceptNullMessage() {
        router.deliver(null);
    }

    @Test
    public void routeShouldReturnFailedFutureIfNoRouteMatches() throws Exception {
        final Message<String> message = Message.fromPayload("value");

        when(route1.deliver(eq(message))).thenReturn(Optional.<Observable<Message<?>>>empty());
        when(route2.deliver(eq(message))).thenReturn(Optional.<Observable<Message<?>>>empty());

        final Observable<Message<?>> future = router.deliver(message);

        final ArgumentCaptor<Exception> captor = ArgumentCaptor.forClass(Exception.class);
        final Action1 errorAction = mock(Action1.class);

        future.subscribe(mock(Action1.class), errorAction);

        verify(errorAction).call(captor.capture());

        assertThat(captor.getValue()).isInstanceOf(ErrorResponse.class);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void firstMatchingRouteShouldBeApplied() {
        final Message<String> message = Message.fromPayload("value");

        final Observable<Message<?>> result = (Observable) Observable.just(Message.fromPayload("test"));

        when(route1.deliver(eq(message))).thenReturn(Optional.of(result));

        assertThat(router.deliver(message)).isEqualTo(result);

        verifyZeroInteractions(route2);
    }

}
