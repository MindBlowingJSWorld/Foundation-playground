package com.nordea.dbf.messaging;

import org.junit.Test;
import rx.Observable;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.nordea.dbf.messaging.MessageRoutes.isInstanceOf;
import static com.nordea.dbf.messaging.MessageRoutes.route;
import static java.util.function.Predicate.isEqual;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class MessageRoutesTest {

    @Test(expected = IllegalArgumentException.class)
    public void fromMessageHandlerShouldNotAcceptNull() {
        MessageRoutes.fromMessageHandler(null);
    }

    @Test
    public void fromMessageHandlerShouldFailIfSignatureIsMissing() {
        final MessageHandler messageHandler = new MessageHandler() {
            @Override
            public Observable deliver(Message message) {
                throw new UnsupportedOperationException();
            }
        };

        try {
            MessageRoutes.fromMessageHandler(messageHandler);
            fail("invalid messageHandler should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void fromMessageHandlerShouldCreateRouteForType() throws InterruptedException, ExecutionException, TimeoutException {
        final MessageHandler<String, String> messageHandler = new MessageHandler<String, String>() {
            @Override
            public Observable<Message<String>> deliver(Message<String> message) {
                return Observable.just(Message.fromPayload("pong " + message.getPayload()));
            }
        };

        final MessageRoute route = MessageRoutes.fromMessageHandler(messageHandler);

        assertThat(route.deliver(Message.fromPayload(1234))).isEqualTo(Optional.empty());
        assertThat(route.deliver(Message.fromPayload("ping")).get().toBlocking().single()).isEqualTo(Message.fromPayload("pong ping"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void fromMessageHandlersShouldRejectNull() {
        MessageRoutes.fromMessageHandler(null);
    }

    @Test
    public void fromMessageHandlersShouldCreateRoutes() throws InterruptedException, ExecutionException, TimeoutException {
        final MessageHandler<Integer, String> handler1 = new MessageHandler<Integer, String>() {
            @Override
            public Observable<Message<String>> deliver(Message<Integer> message) {
                return Observable.just(Message.fromPayload(String.valueOf(message.getPayload())));
            }
        };

        final MessageHandler<Double, String> handler2 = new MessageHandler<Double, String>() {
            @Override
            public Observable<Message<String>> deliver(Message<Double> message) {
                return Observable.just(Message.fromPayload(String.valueOf(message.getPayload())));
            }
        };

        final List<MessageRoute> routes = MessageRoutes.fromMessageHandlers(Arrays.<MessageHandler>asList(handler1, handler2));
        final MessageRouter router = new StaticMessageRouter(routes);

        assertThat(router.deliver(Message.fromPayload(1234)).toBlocking().single()).isEqualTo(Message.fromPayload("1234"));
        assertThat(router.deliver(Message.fromPayload(1234d)).toBlocking().single()).isEqualTo(Message.fromPayload("1234.0"));
    }

    @Test
    public void isInstanceOfShouldRejectNullType() {
        assertThatThrownBy(() -> isInstanceOf(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void isInstanceOfShouldMatchInstanceOfCorrectType() {
        assertThat(isInstanceOf(String.class).test("foo")).isTrue();
    }

    @Test
    public void isInstanceOfShouldNotMatchInstanceOfIncorrectType() {
        assertThat(isInstanceOf(String.class).test(1234)).isFalse();
    }

    @Test
    public void messageRouterCanBeBuilt() {
        final Message<?> message1 = Message.builder().build();
        final Message<?> message2 = Message.builder().build();
        final MessageChannel messageChannel1 = mock(MessageChannel.class);
        final MessageChannel messageChannel2 = mock(MessageChannel.class);

        final MessageRouter router = MessageRoutes.router()
                .route(message -> message == message1).to(messageChannel1)
                .route(message -> message == message2).to(messageChannel2)
                .build();

        when(messageChannel1.deliver(any(Message.class))).thenReturn(Observable.just(Message.fromPayload("msg1")));
        when(messageChannel2.deliver(any(Message.class))).thenReturn(Observable.just(Message.fromPayload("msg2")));

        assertThat(router.deliver(message1).toBlocking().single()).isEqualTo(Message.fromPayload("msg1"));
        assertThat(router.deliver(message2).toBlocking().single()).isEqualTo(Message.fromPayload("msg2"));
        assertThatThrownBy(() -> router.deliver(Message.builder().build()).toBlocking().single()).isInstanceOf(MessageNotRoutableException.class);
    }

    @Test
    public void messageRoutesCanBeBuiltOnDerivedValues() {
        final MessageChannel messageChannel1 = message -> Observable.just(Message.fromPayload("msg1"));
        final MessageChannel messageChannel2 = message -> Observable.just(Message.fromPayload("msg2"));

        final MessageRouter router = MessageRoutes.router()
                .routeOn(message -> Observable.just(message.getPayload()))
                    .when(isInstanceOf(String.class)).then(messageChannel1)
                    .when(isInstanceOf(Integer.class)).then(messageChannel2)
                    .done()
                .build();

        assertThat(router.deliver(Message.fromPayload("foo")).toBlocking().single()).isEqualTo(Message.fromPayload("msg1"));
        assertThat(router.deliver(Message.fromPayload(1234)).toBlocking().single()).isEqualTo(Message.fromPayload("msg2"));
    }

    @Test
    public void explicitRouteCanBeDeclared() {
        final MessageRouter router = MessageRoutes.router()
                .by(message -> Optional.of(Observable.just(message.continuationWith("pong"))))
                .build();

        assertThat(router.deliver(Message.fromPayload("ping")).toBlocking().single().getPayload()).isEqualTo("pong");
    }

    @Test
    public void subRouteByValueCanBeInstalled() {
        final MessageChannel channel1 = message -> Observable.just(Message.fromPayload("A"));
        final MessageChannel channel2 = message -> Observable.just(Message.fromPayload("B"));

        final MessageRouter router = MessageRoutes.router()
                .by(route(message -> Observable.just(message.getPayload()))
                        .when(isEqual("a")).then(channel1)
                        .when(isEqual("b")).then(channel2)
                        .build())
                .build();

        assertThat(router.deliver(Message.fromPayload("a")).toBlocking().single().getPayload()).isEqualTo("A");
        assertThat(router.deliver(Message.fromPayload("b")).toBlocking().single().getPayload()).isEqualTo("B");
    }

}
