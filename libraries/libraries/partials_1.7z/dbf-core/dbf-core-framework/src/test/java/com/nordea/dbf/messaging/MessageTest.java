package com.nordea.dbf.messaging;

import com.nordea.dbf.http.ServiceRequestContext;
import org.junit.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class MessageTest {

    @Test
    public void fromPayloadShouldRetainPayload() {
        final Message<String> message = Message.fromPayload("payload");

        assertThat(message.getPayload()).isEqualTo("payload");
        assertThat(message.getRequest()).isEqualTo(Optional.empty());
    }

    @Test
    public void messagesWithEqualPayloadAndNothingElseShouldBeEqual() {
        final Message<String> message1 = Message.fromPayload("value");
        final Message<String> message2 = Message.fromPayload("value");

        assertThat(message1).isEqualTo(message2);
        assertThat(message2.hashCode()).isEqualTo(message2.hashCode());
    }

    @Test
    public void toStringValueShouldContainPayload() {
        final Message<String> message = Message.fromPayload("value");

        assertThat(message.toString()).contains("value");
    }

    @Test
    public void responseMessageWithPayloadCanBeBuilt() {
        final Message message = Message.builder()
                .payload("foo")
                .inResponseTo(Message.fromPayload("bar"))
                .build();

        assertThat(message.getPayload()).isEqualTo("foo");
        assertThat(message.getRequest()).isEqualTo(Optional.of(Message.fromPayload("bar")));
    }

    @Test
    public void messageWithServiceRequestContextCanBeBuilt() {
        final ServiceRequestContext context = mock(ServiceRequestContext.class);
        final Message message = Message.builder()
                .payload("test")
                .serviceRequestContext(context)
                .build();

        assertThat(message.getServiceRequestContext()).isEqualTo(Optional.of(context));
    }

    @Test
    public void serviceRequestContextCanBeInheritedFromRequestMessage() {
        final ServiceRequestContext context = mock(ServiceRequestContext.class);
        final Message<String> request = Message.<String>builder()
                .payload("req")
                .serviceRequestContext(context)
                .build();

        final Message<String> message = Message.<String>builder()
                .inResponseTo(request)
                .payload("test")
                .build();

        assertThat(message.getServiceRequestContext()).isEqualTo(Optional.of(context));
    }

    @Test
    public void continuationShouldReturnDerivedMessage() {
        final ServiceRequestContext context = mock(ServiceRequestContext.class);
        final Message<String> request = Message.<String>builder()
                .serviceRequestContext(context)
                .payload("test")
                .build();

        assertThat(request.continuationWith("continue")).isEqualTo(Message.<String>builder()
                .serviceRequestContext(context)
                .inResponseTo(request)
                .payload("continue")
                .build());
    }

    @Test(expected = IllegalArgumentException.class)
    public void asShouldNotAcceptNullArg() {
        Message.fromPayload("foo").as(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void asShouldFailForInvalidPayloadType() {
        Message.fromPayload("1234").as(Integer.class);
    }

    @Test
    public void asShouldReturnCastMessage() {
        final Message<Object> source = Message.<Object>fromPayload("1234");
        final Message<String> target = source.as(String.class);

        assertThat(source).isSameAs(target);
    }

    @Test
    public void getPayloadAsTypeShouldReturnPayload() {
        assertThat(Message.fromPayload("foo").getPayload(String.class)).isEqualTo("foo");
    }

    @Test
    public void messageWithContextAndPayloadCanBeBuilt() {
        final ServiceRequestContext context = mock(ServiceRequestContext.class);
        final Message<String> message = Message.in(context).withPayload("foo");

        assertThat(message.getPayload()).isEqualTo("foo");
        assertThat(message.getServiceRequestContext()).isEqualTo(Optional.of(context));
    }

}
