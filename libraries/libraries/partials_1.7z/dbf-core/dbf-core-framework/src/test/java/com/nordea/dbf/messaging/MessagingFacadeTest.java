package com.nordea.dbf.messaging;

import org.junit.Test;
import rx.Observable;

import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class MessagingFacadeTest {

    private final MessageChannel entryPoint = mock(MessageChannel.class);

    private final Supplier<MessageChannel> supplier = mock(Supplier.class);

    private final MessagingFacade facade = new MessagingFacade(supplier);

    @Test
    public void entryPointSupplierCannotBeNull() {
        assertThatThrownBy(() -> new MessagingFacade(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void deliverShouldResolveEntryPoint() {
        when(supplier.get()).thenReturn(entryPoint);

        final Message<String> request = Message.fromPayload("request");
        final Message<String> response = Message.fromPayload("response");

        when(entryPoint.deliver(eq(request))).thenReturn(Observable.just(response));

        assertThat(facade.deliver(request).toBlocking().single()).isEqualTo(response);

        verify(supplier).get();
        verify(entryPoint).deliver(eq(request));
    }

    @Test
    public void deliverShouldNotResolveEntryPointIfAlreadyResolved() {
        when(supplier.get()).thenReturn(entryPoint);

        facade.deliver(Message.fromPayload("msg1"));
        facade.deliver(Message.fromPayload("msg2"));

        verify(supplier, times(1)).get();
    }

}
