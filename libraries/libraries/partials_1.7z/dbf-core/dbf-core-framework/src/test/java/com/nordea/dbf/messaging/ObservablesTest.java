package com.nordea.dbf.messaging;

import org.junit.Test;
import org.springframework.web.context.request.async.DeferredResult;
import rx.Observable;

import java.util.function.Consumer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class ObservablesTest {

    @Test
    public void deferredResultShouldSucceedIfObservableSucceeds() {
        final DeferredResult<String> result = Observables.deferredResultOf(Observable.just("foo"));

        assertThat(result.getResult()).isEqualTo("foo");
    }

    @Test
    public void deferredResultShouldFailIfObservableFails() {
        final RuntimeException exception = new RuntimeException();
        final DeferredResult<Object> result = Observables.deferredResultOf(Observable.error(
                exception));

        assertThat(result.getResult()).isSameAs(exception);
    }

    @Test
    public void deferredResultShouldFailIfMultipleValuesAreReturned() {
        final DeferredResult<Integer> result = Observables.deferredResultOf(Observable.just(1, 2, 3));

        assertThat(result.getResult()).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void manageShouldNotAcceptNullResource() {
        assertThatThrownBy(() -> Observables.manage(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void manageShouldNotAcceptNullObservable() {
        assertThatThrownBy(() -> Observables.manage(mock(AutoCloseable.class)).on(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void managedResourceShouldBeClosedWhenObservableCompleted() throws Exception {
        final AutoCloseable resource = mock(AutoCloseable.class);
        final Observable<String> observable = Observables.manage(resource).on(
            Observable.just("foo"));

        assertThat(observable.toBlocking().single()).isEqualTo("foo");
        verify(resource).close();
    }

    @Test
    public void observableErrorCanBeTransformed() {
        final Exception expected = new RuntimeException("bar");
        final DeferredResult<Object> deferredResult = Observables
            .deferredResultOf(Observable.error(new RuntimeException("foo")), throwable -> expected);

        assertThat(deferredResult.getResult()).isEqualTo(expected);
    }

    @Test
    public void deferredResultShouldNotifyCallbackWhenCompleted() {
        final Consumer consumer = mock(Consumer.class);

        Observables.deferredResultOf(Observable.just("foo"), consumer);

        verify(consumer).accept(eq("foo"));
    }

}
