package com.nordea.dbf.messaging;

import org.junit.Test;

import java.util.Arrays;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

public class StaticMessageRouteProviderTest {

    private final MessageRoute route1 = mock(MessageRoute.class);
    private final MessageRoute route2 = mock(MessageRoute.class);
    private final StaticMessageRouteProvider provider = new StaticMessageRouteProvider(Arrays.asList(route1, route2));

    @Test(expected = IllegalArgumentException.class)
    public void routesCannotBeNull() {
        new StaticMessageRouteProvider(null);
    }

    @Test
    public void routesShouldBeRetained() {
        assertThat(provider.getRoutes()).containsExactly(route1, route2);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void routesShouldNotBeMutable() {
        provider.getRoutes().add(mock(MessageRoute.class));
    }

}