package com.nordea.dbf.messaging;

import org.junit.Test;
import rx.Observable;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;

import static java.util.function.Predicate.isEqual;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;

public class ValueMessageRouterTest {

    @Test
    @SuppressWarnings("unchecked")
    public void constructorShouldRejectInvalidArguments() {
        assertThatThrownBy(() -> ValueMessageRouter.on(null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> ValueMessageRouter.on(mock(Function.class)).when(null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> ValueMessageRouter.on(mock(Function.class)).when(mock(Predicate.class)).then(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void noRouteShouldMatchIfNoEndPointsExist() {
        final ValueMessageRouter<String> router = ValueMessageRouter.on(message -> Observable.just("foo")).build();
        final Optional<Observable<Message<?>>> result = router.deliver(Message.fromPayload("aMessage"));

        assertThat(result.isPresent()).isFalse();
    }

    @Test
    public void messageShouldBeRoutedToMatchingRoute() {
        final MessageChannel messageChannel1 = message -> Observable.just(Message.fromPayload("channel1:" + message.getPayload()));
        final MessageChannel messageChannel2 = message -> Observable.just(Message.fromPayload("channel2:" + message.getPayload()));

        final ValueMessageRouter<Object> router = ValueMessageRouter.on(message -> Observable.just(message.getPayload()))
                .when(isEqual("foo")).then(messageChannel1)
                .when(isEqual("bar")).then(messageChannel2)
                .build();

        assertThat(router.deliver(Message.fromPayload("foo")).get().toBlocking().single()).isEqualTo(Message.fromPayload("channel1:foo"));
        assertThat(router.deliver(Message.fromPayload("bar")).get().toBlocking().single()).isEqualTo(Message.fromPayload("channel2:bar"));
        assertThat(router.deliver(Message.fromPayload("baz")).isPresent()).isFalse();
    }

    @Test
    public void onlyOneMessageChannelShouldReceiveMessage() {
        final MessageChannel messageChannel1 = message -> Observable.just(Message.fromPayload("channel1:" + message.getPayload()));
        final MessageChannel messageChannel2 = message -> Observable.just(Message.fromPayload("channel2:" + message.getPayload()));

        final ValueMessageRouter<String> router = ValueMessageRouter.on(m -> Observable.just("test"))
                .when(str -> true).then(messageChannel1)
                .when(str -> true).then(messageChannel2)
                .build();

        final Message<?> message = router.deliver(Message.fromPayload("test")).get().toBlocking().single();

        assertThat(message.getPayload()).isEqualTo("channel1:test");
    }
}
