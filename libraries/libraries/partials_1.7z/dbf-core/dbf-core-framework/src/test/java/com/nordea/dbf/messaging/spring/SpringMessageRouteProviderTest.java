package com.nordea.dbf.messaging.spring;

import com.nordea.dbf.messaging.*;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import rx.Observable;

import static org.assertj.core.api.Assertions.assertThat;

public class SpringMessageRouteProviderTest {

    @Test
    public void routesShouldBeSetupForAvailableMessageRoutes() throws Exception {
        final AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(TestConfiguration.class);
        final MessageRouteProvider provider = applicationContext.getBean(MessageRouteProvider.class);
        final MessageRouter router = new StaticMessageRouter(provider);

        Assertions.assertThat(router.deliver(Message.fromPayload(1234)).toBlocking().single()).isEqualTo(Message.fromPayload("integer:1234"));
        assertThat(router.deliver(Message.fromPayload(1234d)).toBlocking().single()).isEqualTo(Message.fromPayload("double:1234.0"));
    }

    @Configuration
    public static class TestConfiguration {

        @Bean
        public MessageRouteProvider springMessageRouteProvider() {
            return new SpringMessageRouteProvider();
        }

        @Bean
        public MessageHandler1 messageHandler1() {
            return new MessageHandler1();
        }

        @Bean
        public MessageHandler2 messageHandler2() {
            return new MessageHandler2();
        }
    }

    public static class MessageHandler1 implements MessageHandler<Integer, String> {
        @Override
        public Observable<Message<String>> deliver(Message<Integer> message) {
            return Observable.just(Message.fromPayload("integer:" + message.getPayload()));
        }
    }

    public static class MessageHandler2 implements MessageHandler<Double, String> {
        @Override
        public Observable<Message<String>> deliver(Message<Double> message) {
            return Observable.just(Message.fromPayload("double:" + message.getPayload()));
        }
    }

}
