package com.nordea.dbf.messaging.spring;

import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.messaging.Message;
import com.nordea.dbf.messaging.MessageHandler;
import com.nordea.dbf.messaging.MessageNotRoutableException;
import com.nordea.dbf.messaging.annotation.MessageTypeHandler;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;
import rx.Observable;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.class)
public class SpringMessageTypeRouterTest {

    private final Predicate predicate = mock(Predicate.class);
    private final Handler1 handler1 = new Handler1();
    private final Handler2 handler2 = new Handler2();

    @Mock
    private ApplicationContext applicationContext;

    @InjectMocks
    private final SpringMessageTypeRouter routerWithoutPredicate = new SpringMessageTypeRouter();

    @InjectMocks
    private final SpringMessageTypeRouter routerWithPredicate = new SpringMessageTypeRouter(predicate);

    @Before
    public void setup() {
        when(applicationContext.getBeansWithAnnotation(eq(MessageTypeHandler.class))).thenReturn(ImmutableMap.<String, Object>of(
                "handler1", handler1,
                "handler2", handler2
        ));
    }

    @Test
    public void routerForAllMessageTypeHandlersCanBeCreated() throws Exception {
        routerWithoutPredicate.setup();

        assertThat(routerWithoutPredicate.deliver(Message.fromPayload("hello")).toBlocking().single().getPayload()).isEqualTo(
            "string_handler");
        assertThat(routerWithoutPredicate.deliver(Message.fromPayload(1234)).toBlocking().single().getPayload()).isEqualTo(
            "int_handler");
    }

    @Test
    public void routerForSelectedMessageTypesCanBeCreated() throws Exception {
        when(predicate.apply(eq(handler1))).thenReturn(true);
        when(predicate.apply(eq(handler2))).thenReturn(false);

        routerWithPredicate.setup();

        assertThat(routerWithPredicate.deliver(Message.fromPayload("hello")).toBlocking().single().getPayload()).isEqualTo(
            "string_handler");

        assertThatThrownBy(() -> routerWithPredicate.deliver(Message.fromPayload(1234)).toBlocking().single()).isInstanceOf(MessageNotRoutableException.class);
    }

    public static class Handler1 implements MessageHandler<String, Object> {
        @Override
        public Observable<Message<Object>> deliver(Message<String> message) {
            return Observable.just(message.<Object>continuationWith("string_handler"));
        }
    }

    public static class Handler2 implements MessageHandler<Integer, Object> {
        @Override
        public Observable<Message<Object>> deliver(Message<Integer> message) {
            return Observable.just(message.<Object>continuationWith("int_handler"));
        }
    }

}
