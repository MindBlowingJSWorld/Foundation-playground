package com.nordea.dbf.metadata;

import org.junit.Before;
import org.junit.Test;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;

import java.lang.reflect.Field;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ClasspathApplicationMetaDataResolverTest {

    private final ClasspathApplicationMetaDataResolver resolver = new ClasspathApplicationMetaDataResolver();

    private final ResourcePatternResolver resourcePatternResolver = mock(ResourcePatternResolver.class);

    @Before
    public void setup() throws Exception {
        final Field field = ClasspathApplicationMetaDataResolver.class.getDeclaredField("resourcePatternResolver");
        field.setAccessible(true);
        field.set(resolver, this.resourcePatternResolver);
    }

    @Test
    public void pomFileWithWarPackagingShouldBeLoaded() throws Exception {
        final ByteArrayResource expectedResource = new ByteArrayResource("<project><packaging>war</packaging></project>".getBytes());

        when(resourcePatternResolver.getResources(eq(ClasspathApplicationMetaDataResolver.MAVEN_PATTERN))).thenReturn(new Resource[]{
                expectedResource
        });

        assertThat(resolver.getApplicationMetaDataSource()).isEqualTo(Optional.of(expectedResource));
    }

    @Test
    public void pomFileWithJarPackagingShouldNotBeLoaded() throws Exception {
        final ByteArrayResource expectedResource = new ByteArrayResource("<project><packaging>jar</packaging></project>".getBytes());

        when(resourcePatternResolver.getResources(eq(ClasspathApplicationMetaDataResolver.MAVEN_PATTERN))).thenReturn(new Resource[]{
                expectedResource
        });

        assertThat(resolver.getApplicationMetaDataSource()).isEqualTo(Optional.empty());
    }

    @Test
    public void absentOptionalShouldBeReturnedIfNoMatchingResourcesExist() throws Exception {
        when(resourcePatternResolver.getResources(eq(ClasspathApplicationMetaDataResolver.MAVEN_PATTERN))).thenReturn(new Resource[]{
        });

        assertThat(resolver.getApplicationMetaDataSource()).isEqualTo(Optional.empty());
    }
}
