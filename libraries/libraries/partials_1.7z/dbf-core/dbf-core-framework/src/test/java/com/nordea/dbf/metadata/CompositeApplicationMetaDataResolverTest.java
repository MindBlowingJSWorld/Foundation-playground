package com.nordea.dbf.metadata;

import org.junit.Test;
import org.mockito.InOrder;
import org.springframework.core.io.Resource;

import java.util.Arrays;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class CompositeApplicationMetaDataResolverTest {

    private final ApplicationMetaDataResolver resolver1 = mock(ApplicationMetaDataResolver.class);

    private final ApplicationMetaDataResolver resolver2 = mock(ApplicationMetaDataResolver.class);

    private final CompositeApplicationMetaDataResolver resolver = new CompositeApplicationMetaDataResolver(Arrays.asList(resolver1, resolver2));

    @Test(expected = IllegalArgumentException.class)
    public void targetResolversCannotBeNull() {
        new CompositeApplicationMetaDataResolver(null);
    }

    @Test
    public void getApplicationMetaDataSourceShouldReturnFirstResolvedMetaData() {
        final Resource resource = mock(Resource.class);

        when(resolver1.getApplicationMetaDataSource()).thenReturn(Optional.<Resource>empty());
        when(resolver2.getApplicationMetaDataSource()).thenReturn(Optional.of(resource));

        assertThat(resolver.getApplicationMetaDataSource()).isEqualTo(Optional.of(resource));

        final InOrder inOrder = inOrder(resolver1, resolver2);

        inOrder.verify(resolver1).getApplicationMetaDataSource();
        inOrder.verify(resolver2).getApplicationMetaDataSource();
    }

    @Test
    public void getApplicationMetaDataSourceShouldReturnAbsentIfNoneMatches() {
        when(resolver1.getApplicationMetaDataSource()).thenReturn(Optional.<Resource>empty());
        when(resolver2.getApplicationMetaDataSource()).thenReturn(Optional.<Resource>empty());

        assertThat(resolver.getApplicationMetaDataSource()).isEqualTo(Optional.empty());
    }

}
