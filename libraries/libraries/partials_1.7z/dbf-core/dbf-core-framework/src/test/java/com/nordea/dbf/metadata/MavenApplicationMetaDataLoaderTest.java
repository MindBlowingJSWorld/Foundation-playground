package com.nordea.dbf.metadata;

import org.junit.Test;

import java.io.ByteArrayInputStream;

import static org.assertj.core.api.Assertions.assertThat;

public class MavenApplicationMetaDataLoaderTest {

    private final MavenApplicationMetaDataLoader loader = new MavenApplicationMetaDataLoader();

    @Test(expected = IllegalArgumentException.class)
    public void loadShouldRejectIncorrectXml() throws Exception {
        load("<project><groupId>foo</groupId><artifactId>bar</artifactId><version>1.0</version></project>");
    }

    @Test
    public void applicationMetaDataShouldContainMavenProperties() throws Exception {
        final ApplicationMetaData metaData = load("<project xmlns=\"http://maven.apache.org/POM/4.0.0\"\n" +
                "         xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
                "         xsi:schemaLocation=\"http://maven.apache.org/POM/4.0.0\n" +
                "                             http://maven.apache.org/xsd/maven-4.0.0.xsd\">\n" +
                "    <modelVersion>4.0.0</modelVersion>\n" +
                "    <groupId>com.nordea.dbf</groupId>\n" +
                "    <artifactId>dbf-core-framework</artifactId>\n" +
                "    <version>1.0-SNAPSHOT</version>\n" +
                "    <name>DBF core framework</name>" +
                "</project>");

        assertThat(metaData.getGroupId()).isEqualTo("com.nordea.dbf");
        assertThat(metaData.getArtifactId()).isEqualTo("dbf-core-framework");
        assertThat(metaData.getVersion()).isEqualTo("1.0-SNAPSHOT");
        assertThat(metaData.getName()).isEqualTo("DBF core framework");
    }

    protected ApplicationMetaData load(String xml) throws Exception {
        return loader.load(new ByteArrayInputStream(xml.getBytes()));
    }

}