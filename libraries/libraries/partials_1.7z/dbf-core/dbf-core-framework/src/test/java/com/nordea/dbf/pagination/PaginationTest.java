package com.nordea.dbf.pagination;

import org.junit.Test;

import java.text.ParseException;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

/**
 * Created by k293170 on 2015-05-18.
 */
public class PaginationTest {

    @Test
    public void testLongerLengthPaginationString() {
        try {
            Pagination.fromString("1-30/45/60");
            fail("A pagination in the form X/Y/Z should fail.");
        } catch (ParseException pe) {
            assertThat(pe).hasMessage("Incorrect Range specified. Range must be in the form start, start-end or start-end/total");
            assertThat(pe.getErrorOffset()).isEqualTo(10);
        }
    }

    @Test
    public void testIncorrectTotalCountPaginationString() {
        try {
            Pagination.fromString("1-30/XYZ");
            fail("A pagination of the form X-Y/invalid Z should fail");
        } catch (ParseException pe) {
            assertThat(pe).hasMessage("Incorrect total count specified. Total count must be numeric");
            assertThat(pe.getErrorOffset()).isEqualTo(5);
        }
    }

    @Test
         public void testIncorrectStartEndRangePaginationString() {
        try {
            Pagination.fromString("1/60");
            fail("A pagination of the form X/Z should fail");
        } catch (ParseException pe) {
            assertThat(pe).hasMessage("Incorrect Range specified. Range must be in the form start, start-end or start-end/total");
            assertThat(pe.getErrorOffset()).isEqualTo(0);
        }

        try {
            Pagination.fromString("1-3-6/60");
            fail("A pagination of the form X-Y-Z/A should fail");
        } catch (ParseException pe) {
            assertThat(pe).hasMessage("Incorrect Range specified. Range must be in the form start, start-end or start-end/total");
            assertThat(pe.getErrorOffset()).isEqualTo(0);
        }
    }

    @Test
    public void testIncorrectStartEndValuesPaginationString() {
        try {
            Pagination.fromString("1-X/60");
            fail("A pagination of the form X-invalid Y/Z should fail");
        } catch (ParseException pe) {
            assertThat(pe).hasMessage("Incorrect start-end range specified. It must be in the format start or start-end with start and end both numeric.");
            assertThat(pe.getErrorOffset()).isEqualTo(0);
        }

        try {
            Pagination.fromString("-20/60");
            fail("A pagination of the form invalid -Y/Z should fail");
        } catch (ParseException pe) {
            assertThat(pe).hasMessage("Incorrect start-end range specified. It must be in the format start or start-end with start and end both numeric.");
            assertThat(pe.getErrorOffset()).isEqualTo(0);
        }
    }

    @Test
    public void testIncorrectStartEndValuesWithStartLargerThanEndPaginationString() {
        try {
            Pagination.fromString("30-5/60");
            fail("A pagination of the form X-Y/Z with X larger than Y should fail");
        } catch (ParseException pe) {
            assertThat(pe).hasMessage("Incorrect Range specified. Range must be in the form start, start-end or start-end/total and start must be smaller than or equal to end");
            assertThat(pe.getErrorOffset()).isEqualTo(0);
        }
    }

    @Test
    public void testIncorrectStartEndValuesWithStartNegativePaginationString() {
        try {
            Pagination.fromString("-1-20/60");
            fail("A pagination of the form -X-Y/Z should fail");
        } catch (ParseException pe) {
            assertThat(pe).hasMessage("Incorrect Range specified. Range must be in the form start, start-end or start-end/total");
            assertThat(pe.getErrorOffset()).isEqualTo(0);
        }
    }

    @Test
    public void testCorrectStartEndAndTotalParsedFromValidString() {
        try {
            Pagination pagination = Pagination.fromString("0-20/60");
            assertThat(pagination.getStartIndex()).isEqualTo(0);
            assertThat(pagination.getEndIndex().get()).isEqualTo(20);
            assertThat(pagination.getTotalCount().get()).isEqualTo(60);
            assertThat(pagination.fetchedCount()).isEqualTo(20);
        } catch (ParseException pe) {
            fail("Parse Exception should not be raised with valid string parsing");
        }
    }

    @Test
    public void testCorrectStartAndEndParsedFromValidString() {
        try {
            Pagination pagination = Pagination.fromString("0-20");
            assertThat(pagination.getStartIndex()).isEqualTo(0);
            assertThat(pagination.getEndIndex().get()).isEqualTo(20);
            assertThat(pagination.getTotalCount()).isEmpty();
            assertThat(pagination.fetchedCount()).isEqualTo(20);
            assertThat(pagination.isComplete()).isEqualTo(false);
        } catch (ParseException pe) {
            fail("Parse Exception should not be raised with valid string parsing");
        }
    }

    @Test
    public void testCorrectStartParsedFromValidString() {
        try {
            Pagination pagination = Pagination.fromString("0");
            assertThat(pagination.getStartIndex()).isEqualTo(0);
            assertThat(pagination.getEndIndex()).isEmpty();
            assertThat(pagination.getTotalCount()).isEmpty();
            assertThat(pagination.fetchedCount()).isEqualTo(0);
            assertThat(pagination.isComplete()).isEqualTo(false);
        } catch (ParseException pe) {
            fail("Parse Exception should not be raised with valid string parsing");
        }
    }

    @Test
    public void testStringifiedRangeForPagination() {
        Pagination pagination = new Pagination(1, Optional.of(20), Optional.of(60));
        assertThat(pagination.toString()).isEqualTo("1-20/60");
    }

    @Test
    public void testStringifiedRangeForPaginationWithNoTotal() {
        Pagination pagination = new Pagination(0, Optional.of(20));
        assertThat(pagination.toString()).isEqualTo("0-20");
    }
}
