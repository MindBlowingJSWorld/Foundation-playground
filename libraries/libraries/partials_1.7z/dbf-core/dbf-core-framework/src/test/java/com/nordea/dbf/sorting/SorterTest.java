package com.nordea.dbf.sorting;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import rx.Observable;
import rx.Observer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.inOrder;

@RunWith(MockitoJUnitRunner.class)
public class SorterTest {

    @Mock
    private Observer<Data> observer;

    private static final DateFormat dfDate = new SimpleDateFormat("ddMMyyyy");

    private static class Data {
        private int id;
        private String name;
        private String someValue;
        private Date date;

        public Data(int id, String name, String someValue, Date date) {
            this.id = id;
            this.name = name;
            this.someValue = someValue;
            this.date = date;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public Date getDate() {
            return date;
        }

        public String getSomeValue() {
            return someValue;
        }
    }

    private List<Data> data;

    private static final SorterFactory<Data> dataSorterFactory = new SorterFactory.Builder<Data>()
            .add("id", Data::getId)
            .add("name", Data::getName)
            .add("some_value", Data::getSomeValue)
            .add("date", Data::getDate)
            .build();

    @Before
    public void setUp() throws Exception {
        data = Arrays.asList(
                new Data(3, "Three", "CC", dfDate.parse("03012016")),
                new Data(5, "Five", "AA", dfDate.parse("05012016")),
                new Data(0, "Zero", "BB", null),
                new Data(1, "One", "BB", dfDate.parse("01012016")),
                new Data(4, "Four", "AA", dfDate.parse("04012016")),
                new Data(2, "Two", "AA", dfDate.parse("02012016"))
        );
    }

    @Test
    public void sortsAscendingUsingPlus() {
        // Given
        Sorter<Data> sorter = dataSorterFactory.getSorter("+name");
        // When
        Observable<Data> observable = Observable.from(data).toSortedList(sorter::sort).flatMapIterable(data -> data);
        observable.subscribe(observer);
        //Then
        InOrder inOrder = inOrder(observer);
        inOrder.verify(observer).onNext(data.get(1));
        inOrder.verify(observer).onNext(data.get(4));
        inOrder.verify(observer).onNext(data.get(3));
        inOrder.verify(observer).onNext(data.get(0));
        inOrder.verify(observer).onNext(data.get(5));
        inOrder.verify(observer).onNext(data.get(2));
    }

    @Test
    public void sortsAscendingUsingAsc() {
        // Given
        Sorter<Data> sorter = dataSorterFactory.getSorter("name-asc");
        // When
        Observable<Data> observable = Observable.from(data).toSortedList(sorter::sort).flatMapIterable(data -> data);
        observable.subscribe(observer);
        //Then
        InOrder inOrder = inOrder(observer);
        inOrder.verify(observer).onNext(data.get(1));
        inOrder.verify(observer).onNext(data.get(4));
        inOrder.verify(observer).onNext(data.get(3));
        inOrder.verify(observer).onNext(data.get(0));
        inOrder.verify(observer).onNext(data.get(5));
        inOrder.verify(observer).onNext(data.get(2));
    }

    @Test
    public void sortsDescendingUsingMinus() {
        // Given
        Sorter<Data> sorter = dataSorterFactory.getSorter("-name");
        // When
        Observable<Data> observable = Observable.from(data).toSortedList(sorter::sort).flatMapIterable(data -> data);
        observable.subscribe(observer);
        //Then
        InOrder inOrder = inOrder(observer);
        inOrder.verify(observer).onNext(data.get(2));
        inOrder.verify(observer).onNext(data.get(5));
        inOrder.verify(observer).onNext(data.get(0));
        inOrder.verify(observer).onNext(data.get(3));
        inOrder.verify(observer).onNext(data.get(4));
        inOrder.verify(observer).onNext(data.get(1));
    }

    @Test
    public void sortsDescendingUsingDesc() {
        // Given
        Sorter<Data> sorter = dataSorterFactory.getSorter("name-desc");
        // When
        Observable<Data> observable = Observable.from(data).toSortedList(sorter::sort).flatMapIterable(data -> data);
        observable.subscribe(observer);
        //Then
        InOrder inOrder = inOrder(observer);
        inOrder.verify(observer).onNext(data.get(2));
        inOrder.verify(observer).onNext(data.get(5));
        inOrder.verify(observer).onNext(data.get(0));
        inOrder.verify(observer).onNext(data.get(3));
        inOrder.verify(observer).onNext(data.get(4));
        inOrder.verify(observer).onNext(data.get(1));
    }

    @Test
    public void sortsOnSecondaryValueIfEqualPrimaryValue() {
        // Given
        Sorter<Data> sorter = dataSorterFactory.getSorter("some_value,id-desc");
        // When
        Observable<Data> observable = Observable.from(data).toSortedList(sorter::sort).flatMapIterable(data -> data);
        observable.subscribe(observer);
        //Then
        InOrder inOrder = inOrder(observer);
        inOrder.verify(observer).onNext(data.get(1));
        inOrder.verify(observer).onNext(data.get(4));
        inOrder.verify(observer).onNext(data.get(5));
        inOrder.verify(observer).onNext(data.get(3));
        inOrder.verify(observer).onNext(data.get(2));
        inOrder.verify(observer).onNext(data.get(0));
    }

    @Test
    public void noSortIfNullFields() {
        // Given
        Sorter<Data> sorter = dataSorterFactory.getSorter(null);
        // When
        Observable<Data> observable = Observable.from(data).toSortedList(sorter::sort).flatMapIterable(data -> data);
        observable.subscribe(observer);
        //Then
        InOrder inOrder = inOrder(observer);
        inOrder.verify(observer).onNext(data.get(0));
        inOrder.verify(observer).onNext(data.get(1));
        inOrder.verify(observer).onNext(data.get(2));
        inOrder.verify(observer).onNext(data.get(3));
        inOrder.verify(observer).onNext(data.get(4));
        inOrder.verify(observer).onNext(data.get(5));
    }

    @Test
    public void noSortIfNoFields() {
        // Given
        Sorter<Data> sorter = dataSorterFactory.getSorter("");
        // When
        Observable<Data> observable = Observable.from(data).toSortedList(sorter::sort).flatMapIterable(data -> data);
        observable.subscribe(observer);
        //Then
        InOrder inOrder = inOrder(observer);
        inOrder.verify(observer).onNext(data.get(0));
        inOrder.verify(observer).onNext(data.get(1));
        inOrder.verify(observer).onNext(data.get(2));
        inOrder.verify(observer).onNext(data.get(3));
        inOrder.verify(observer).onNext(data.get(4));
        inOrder.verify(observer).onNext(data.get(5));
    }

    @Test
    public void sortHasNullValue() {
        // Given
        Sorter<Data> sorter = dataSorterFactory.getSorter("date,id");
        // When
        Observable<Data> observable = Observable.from(data).toSortedList(sorter::sort).flatMapIterable(data -> data);
        observable.subscribe(observer);
        //Then
        InOrder inOrder = inOrder(observer);
        inOrder.verify(observer).onNext(data.get(3));
        inOrder.verify(observer).onNext(data.get(5));
        inOrder.verify(observer).onNext(data.get(0));
        inOrder.verify(observer).onNext(data.get(4));
        inOrder.verify(observer).onNext(data.get(1));
        inOrder.verify(observer).onNext(data.get(2));
    }
}
