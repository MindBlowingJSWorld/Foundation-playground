package com.nordea.dbf.spring;

import com.nordea.dbf.annotation.RequestId;
import com.nordea.dbf.annotation.SessionId;
import com.nordea.dbf.http.ServiceRequestContextBuilder;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import java.lang.annotation.Annotation;
import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ContextHandlerMethodArgumentResolverTest {

    private final ContextHandlerMethodArgumentResolver resolver = new ContextHandlerMethodArgumentResolver();

    @After
    public void tearDown() {
        ServiceRequestContextHolder.clear();
    }

    @Test(expected = IllegalArgumentException.class)
    public void supportsParameterShouldRejectNullArg() {
        resolver.supportsParameter(null);
    }

    @Test
    public void supportsParametersShouldReturnTrueIfMethodParameterContainsSupportedAnnotation() {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{
                        mock(RequestId.class)},
                new Annotation[]{mock(SessionId.class)});

        assertThat(resolver.supportsParameter(parameter)).isTrue();
        assertThat(resolver.supportsParameter(parameter)).isTrue();
    }

    @Test
    public void supportsParametersShouldReturnFalseForDifferentAnnotations() {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(Qualifier.class)});

        assertThat(resolver.supportsParameter(parameter)).isFalse();
    }

    @Test
    public void resolveArgumentShouldResolveSessionIdForSessionIdAnnotation() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(SessionId.class)});

        ServiceRequestContextHolder.bind(new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .sessionId("1234")
                .build());

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));
        assertThat(value).isEqualTo("1234");

        ServiceRequestContextHolder.clear();
    }

    @Test
    public void resolveShouldFailIfMethodDoesNotContainAnnotation() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(Annotation.class)});

        try {
            resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));
            fail("resolve should fail if parameter does not contain supported annotation");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void resolveShouldReturnNullIfNoRequestContextIsConfigured() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(RequestId.class)}, new Annotation[]{mock(SessionId.class)});

        final Object value1 = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));
        assertThat(value1).isNull();

        final Object value2 = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));
        assertThat(value2).isNull();
    }

    @Test
    public void nullSessionIdShouldBeInjectedIfNoSessionIdIsConfigured() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(SessionId.class)});

        ServiceRequestContextHolder.bind(new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .build());

        assertThat(resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class))).isNull();
    }

    @Test
    public void requestIdShouldBeInjectedIfConfigured() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(RequestId.class)});

        ServiceRequestContextHolder.bind(new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .requestId("1234")
                .build());

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));

        assertThat(value).isEqualTo("1234");
    }

    @Test
    public void requestIdShouldBeGeneratedIfNotConfigured() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(RequestId.class)});

        ServiceRequestContextHolder.bind(new ServiceRequestContextBuilder()
                .requestRoute(Collections.singletonList("127.0.0.1"))
                .build());

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));

        assertThat(value).isNotNull();
    }

}
