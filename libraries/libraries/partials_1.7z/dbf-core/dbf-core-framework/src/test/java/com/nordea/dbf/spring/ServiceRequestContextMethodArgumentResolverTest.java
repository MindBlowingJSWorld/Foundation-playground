package com.nordea.dbf.spring;

import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.support.RequestContext;

import javax.validation.Validator;
import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
@RunWith(MockitoJUnitRunner.class)
public class ServiceRequestContextMethodArgumentResolverTest {

    @Mock
    private Validator validator;

    @InjectMocks
    private ServiceRequestContextMethodArgumentResolver resolver = new ServiceRequestContextMethodArgumentResolver();

    private final MethodParameter methodParameter = mock(MethodParameter.class);


    @Before
    public void setUp() {
        when(validator.validate(ServiceRequestContext.class)).thenReturn(Collections.emptySet());
    }
    @After
    public void tearDown() {
        ServiceRequestContextHolder.clear();
    }

    @Test
    public void parameterWithServiceRequestContextTypeShouldBeSupported() {
        when(methodParameter.getParameterType()).thenReturn((Class) ServiceRequestContext.class);

        assertThat(resolver.supportsParameter(methodParameter)).isTrue();
    }

    @Test
    public void parameterOfUnsupportedTypeShouldNotBeSupported() {
        when(methodParameter.getParameterType()).thenReturn((Class) RequestContext.class);

        assertThat(resolver.supportsParameter(methodParameter)).isFalse();
    }

    @Test
    public void resolveShouldReturnConfiguredServiceRequestContext() throws Exception {
        final ServiceRequestContext context = mock(ServiceRequestContext.class);

        ServiceRequestContextHolder.bind(context);

        when(methodParameter.getParameterType()).thenReturn((Class) ServiceRequestContext.class);

        final ServiceRequestContext resolved = (ServiceRequestContext)resolver.resolveArgument(methodParameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));

        assertThat(resolved).isEqualTo(context);
    }

    @Test
    public void resolveShouldReturnNullIfNothingIsBound() throws Exception {
        when(methodParameter.getParameterType()).thenReturn((Class) ServiceRequestContext.class);

        assertThatThrownBy(()-> resolver.resolveArgument(methodParameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class)))
                .isExactlyInstanceOf(BadRequestException.class);
    }

}
