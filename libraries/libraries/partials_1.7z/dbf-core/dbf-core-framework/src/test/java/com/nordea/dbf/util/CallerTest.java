package com.nordea.dbf.util;

import org.junit.Test;

import java.util.Optional;
import java.util.function.Predicate;

import static com.nordea.dbf.util.Caller.inPackage;
import static org.assertj.core.api.Assertions.assertThat;

public class CallerTest {

    @Test
    public void currentCallerLocationCanBeRetrieved() {
        final Caller caller = Caller.here();

        assertThat(caller.getMethodName()).isEqualTo("currentCallerLocationCanBeRetrieved");
        assertThat(caller.getClassName()).isEqualTo(CallerTest.class.getName());
    }

    @Test
    public void callerOfCallerCanBeRetrieved() {
        final Caller caller = getNestedCaller();

        assertThat(caller.getMethodName()).isEqualTo("getNestedCaller");
        assertThat(caller.getCaller().get().getMethodName()).isEqualTo("callerOfCallerCanBeRetrieved");
    }

    @Test
    public void inPackageShouldMatchCallersInPackage() {
        assertThat(inPackage("com.nordea.dbf.util").test(Caller.here())).isTrue();
        assertThat(inPackage("com.nordea.dbf").test(Caller.here())).isTrue();
        assertThat(inPackage("com.nordea").test(Caller.here())).isTrue();
        assertThat(inPackage("org.junit").test(Caller.here()));
    }

    @Test
    public void notShouldNegatePredicate() {
        final Predicate predicate = c -> true;
        final Predicate negatedPredicate = Caller.not(predicate);

        assertThat(negatedPredicate.test(Caller.here())).isFalse();
    }

    @Test
    public void callerFromDifferentPackageCanBeFoundWithPredicate() {
        final Optional<Caller> caller =
            Caller.here().where(Caller.not(inPackage("com.nordea.dbf.util")));

        assertThat(caller.isPresent()).isTrue();
        assertThat(caller.get().getClassName()).doesNotMatch("com\\.nordea\\.dbf\\.util.*");
    }

    protected Caller getNestedCaller() {
        return Caller.here();
    }

}
