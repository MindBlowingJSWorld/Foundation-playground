package com.nordea.dbf.util;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class DifferenceTest {

    @Test
    public void betweenShouldRejectNullLeftOrRight() {
        assertThatThrownBy(() -> Difference.between("a", null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Difference.between(null, "b")).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void nothingShouldBeDifferentBetweenSameInstances() {
        final ExampleObject a = new ExampleObject("foo", 1, null, null);

        assertThat(Difference.between(a, a)).isEqualTo(Difference.none());
    }

    @Test
    public void nothingShouldBeDifferentBetweenEqualInstances() {
        final ExampleObject a = new ExampleObject("foo", 1, null, null);
        final ExampleObject b = new ExampleObject("foo", 1, null, null);

        assertThat(Difference.between(a, b)).isEqualTo(Difference.none());
    }

    @Test
    public void propertyDifferencesShouldBeSpecifiedInDifference() {
        final Difference difference = Difference.between(new ExampleObject("foo", 1, null, null), new ExampleObject("bar", 2, null, null));

        final List<Difference.Property> properties = difference.properties();
        assertThat(properties).hasSize(2);

        final Difference.Property property1 = properties.get(0);
        assertThat(property1.getName()).isEqualTo("property1");
        assertThat(property1.getLeftValue()).isEqualTo("foo");
        assertThat(property1.getRightValue()).isEqualTo("bar");

        final Difference.Property property2 = properties.get(1);
        assertThat(property2.getName()).isEqualTo("property2");
        assertThat(property2.getLeftValue()).isEqualTo(1);
        assertThat(property2.getRightValue()).isEqualTo(2);
    }

    @Test
    public void propertiesWillNotBeComparedWithNull() {
        final ExampleObject object1 = new ExampleObject(null, 1, null, null);
        final ExampleObject object2 = new ExampleObject("foo", 1, null, null);

        assertThat(Difference.between(object1, object2).properties()).doesNotContain(new Difference.Property("property1", null, "foo"));
        assertThat(Difference.between(object2, object1).properties()).doesNotContain(new Difference.Property("property1", "foo", null));
    }

    @Test
    public void propertiesWillNotBeComparedWithEmptyLists() {
        List<String> value1 = Collections.emptyList();
        List<String> value2 = Arrays.asList("foo");
        final ExampleObject object1 = new ExampleObject(null, 1, value1, null);
        final ExampleObject object2 = new ExampleObject(null, 1, value2, null);

        assertThat(Difference.between(object1, object2).properties()).doesNotContain(new Difference.Property("property3", value1, value2));
        assertThat(Difference.between(object2, object1).properties()).doesNotContain(new Difference.Property("property3", value2, value1));
    }

    @Test
    public void propertiesWillNotBeComparedIfItDates() {
        Date value1 = new Date();
        Date value2 = new Date(0);
        final ExampleObject object1 = new ExampleObject(null, 1, null, value1);
        final ExampleObject object2 = new ExampleObject(null, 1, null, value2);

        assertThat(Difference.between(object1, object2).properties()).doesNotContain(new Difference.Property("property4", value1, value2));
        assertThat(Difference.between(object2, object1).properties()).doesNotContain(new Difference.Property("property4", value2, value1));
    }

    @Test
    public void exactlyPredicateShouldMatchOnlyEqualDifference() {
        assertThat(Difference.exactly("property1", "foo", "bar").test(Difference.between(new ExampleObject("foo", 1, null, null), new ExampleObject("bar", 1, null, null)))).isTrue();
        assertThat(Difference.exactly("property1", "bar", "foo").test(Difference.between(new ExampleObject("foo", 1, null, null), new ExampleObject("bar", 1, null, null)))).isFalse();
    }

    @Test
    public void getPropertyShouldRejectInvalidPropertyName() {
        final ExampleObject obj = new ExampleObject("foo", 1, Collections.<String>emptyList(), null);
        final Difference difference = Difference.between(obj, obj);

        assertThatThrownBy(() -> difference.getProperty(null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> difference.getProperty("")).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void getPropertyShouldReturnNullIfNoMatchingDifferingPropertyExists() {
        final ExampleObject obj = new ExampleObject("foo", 1, Collections.<String>emptyList(), null);
        final Difference difference = Difference.between(obj, obj);

        assertThat(difference.getProperty("invalidProperty")).isNull();
    }

    @Test
    public void getPropertyShouldReturnDifferingProperty() {
        final ExampleObject property1 = new ExampleObject("foo", 1, Collections.<String>emptyList(), null);
        final ExampleObject property2 = new ExampleObject("bar", 1, Collections.<String>emptyList(), null);
        final Difference difference = Difference.between(property1, property2);
        final Difference.Property differingProperty = difference.getProperty("property1");

        assertThat(differingProperty).isNotNull();
        assertThat(differingProperty.getName()).isEqualTo("property1");
        assertThat(differingProperty.getLeftValue()).isEqualTo("foo");
        assertThat(differingProperty.getRightValue()).isEqualTo("bar");
    }

    public final static class ExampleObject {

        private final String property1;
        private final int property2;
        private final List<String> property3;
        private final Date property4;

        public ExampleObject(String property1, int property2, List<String> property3, Date property4) {
          this.property1 = property1;
          this.property2 = property2;
          this.property3 = property3;
          this.property4 = property4;
        }

        public String getProperty1() {
            return property1;
        }

        public int getProperty2() {
            return property2;
        }
        
        public List<String> getProperty3() {
          return property3;
        }
  
        public Date getProperty4() {
            return property4;
        }
    }
}
