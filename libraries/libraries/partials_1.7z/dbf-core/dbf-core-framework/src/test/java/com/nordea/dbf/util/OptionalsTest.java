package com.nordea.dbf.util;

import org.junit.Test;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

public class OptionalsTest {

    @Test
    public void toStringShouldReturnNullForNullOptional() {
        assertThat(Optionals.toString(null)).isEqualTo("null");
    }

    @Test
    public void toStringShouldReturnAbsentForAbsentOptional() {
        assertThat(Optionals.toString(Optional.empty())).isEqualTo("absent");
    }

    @Test
    public void toStringShouldReturnValueToStringForObject() {
        assertThat(Optionals.toString(Optional.of(1234))).isEqualTo("1234");
    }

    @Test
    public void toStringShouldReturnQuotedStringForStringValue() {
        assertThat(Optionals.toString(Optional.of("foo"))).isEqualTo("\"foo\"");
    }

}
