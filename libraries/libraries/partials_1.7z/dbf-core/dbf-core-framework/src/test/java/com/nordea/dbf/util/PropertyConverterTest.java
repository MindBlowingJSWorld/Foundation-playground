package com.nordea.dbf.util;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class PropertyConverterTest {

    @Test
    public void expressionCannotBeNull() {
        assertThatThrownBy(() -> PropertyConverter.splitPropertyOnPipe(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void emptyExpressionShouldYieldEmptyResult() {
        assertThat(PropertyConverter.splitPropertyOnPipe("")).isEmpty();
    }

    @Test
    public void expressionCanContainSingleElement() {
        assertThat(PropertyConverter.splitPropertyOnPipe("foo")).containsExactly("foo");
    }

    @Test
    public void testSplitPropertyOnBar() throws Exception {
        final String[] actual = PropertyConverter.splitPropertyOnPipe("a|b|c|   \t\r\n  |   \t   ws\t \r\n");
        assertThat(actual).containsExactly("a", "b", "c", "ws");
    }
}
