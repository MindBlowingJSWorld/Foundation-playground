package com.nordea.dbf.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.common.collect.ImmutableList;
import com.google.common.util.concurrent.SettableFuture;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextFilter;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import com.nordea.dbf.http.contextappender.ClientRequestContextAppender;
import com.nordea.dbf.http.contextappender.LanguageAppender;
import com.nordea.dbf.http.contextappender.RequestRouteAppender;
import com.nordea.dbf.http.contextappender.ServiceRequestContextAppender;
import com.nordea.dbf.model.http.DBFClientServiceRequestContext;
import com.nordea.dbf.model.http.DBFClientServiceRequestContextBuilder;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;
import java.util.function.Predicate;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@SuppressWarnings("unchecked")
public class ServiceContextMock {

    public final Predicate requestFilter = mock(Predicate.class);

    public final ServiceRequestContextFilter filter = new ServiceRequestContextFilter();

    public final HttpServletRequest request = mock(HttpServletRequest.class);

    public final HttpServletResponse response = mock(HttpServletResponse.class);

    public final FilterChain filterChain = mock(FilterChain.class);

    public static ObjectMapper createMapper(boolean indent) {
        ObjectMapper jackson = new ObjectMapper();
        jackson.configure(SerializationFeature.INDENT_OUTPUT, indent);
        jackson.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        return jackson;
    }

    public void setup(List<ServiceRequestContextAppender> appenders) {
        filter.setServiceRequestContextAppenders(appenders);
        when(request.getRemoteAddr()).thenReturn("127.0.0.1");
        when(request.getHeader(eq(ClientRequestContextAppender.CLIENT_CONTEXT_HEADER_NAME)))
                .thenReturn(serialize(getContextBuilderWithMandatoryValuesSet().build()));
        when(requestFilter.test(eq(request))).thenReturn(true);
    }
    public void setup() {
        setup(ImmutableList.of(new LanguageAppender(),new RequestRouteAppender(),new ClientRequestContextAppender(requestFilter)));
    }


    public ServiceRequestContext applyRequestContext() {
        try {
            final Future<Optional<ServiceRequestContext>> requestContext = requestContext();

            filter.doFilter(request, response, filterChain);

            return requestContext.get().get();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Future<Optional<ServiceRequestContext>> requestContext() {
        final SettableFuture<Optional<ServiceRequestContext>> future = SettableFuture.create();

        try {
            doAnswer(invocationOnMock -> {
                future.set(ServiceRequestContextHolder.get());
                return null;
            }).when(filterChain).doFilter(eq(request), eq(response));
        } catch (IOException | ServletException e) {
            throw new RuntimeException(e);
        }

        return future;
    }

    public String serialize(DBFClientServiceRequestContext context) {
        try {
            return createMapper(true).writeValueAsString(context);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Failed to serialize to json: "+super.toString(), e);
        }
    }

    public DBFClientServiceRequestContextBuilder getContextBuilderWithMandatoryValuesSet() {
        return new DBFClientServiceRequestContextBuilder().applicationId("APP1").channelId("NETBANK").country("NO");
    }

    public void doFilter() throws ServletException, IOException {
        filter.doFilter(request,response,filterChain);
    }

    public void verifyDoFilter() throws IOException, ServletException {
        verify(filterChain).doFilter(eq(request), eq(response));
    }
}
