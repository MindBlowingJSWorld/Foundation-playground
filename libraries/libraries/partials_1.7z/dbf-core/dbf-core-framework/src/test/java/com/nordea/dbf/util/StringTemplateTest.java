package com.nordea.dbf.util;

import com.google.common.base.Function;
import com.google.common.collect.ImmutableMap;
import org.junit.Test;

import static com.nordea.dbf.util.StringTemplate.usingMap;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class StringTemplateTest {

    private final Function function = mock(Function.class);

    @Test
    public void constructorShouldRejectInvalidPath() {
        try {
            new StringTemplate(null);
            fail("null path should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            new StringTemplate("");
            fail("empty path should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }
    
    @Test
    public void staticPathCanBeFormatted() {
        assertThat(new StringTemplate("foo").expand(function)).isEqualTo("foo");
    }

    @Test
    public void pathTemplateCanHaveVariableStart() {
        final StringTemplate template = new StringTemplate("{foo}/bar");

        when(function.apply(eq("foo"))).thenReturn("FOO");

        assertThat(template.expand(function)).isEqualTo("FOO/bar");
    }

    @Test
    public void pathTemplateCanHaveVariableMiddle() {
        final StringTemplate template = new StringTemplate("foo/{bar}/baz");

        when(function.apply(eq("bar"))).thenReturn("BAR");

        assertThat(template.expand(function)).isEqualTo("foo/BAR/baz");
    }

    @Test
    public void pathTemplateCanHaveVariableEnd() {
        final StringTemplate template = new StringTemplate("foo/bar/{baz}");

        when(function.apply(eq("baz"))).thenReturn("BAZ");

        assertThat(template.expand(function)).isEqualTo("foo/bar/BAZ");
    }

    @Test(expected = IllegalArgumentException.class)
    public void expandShouldNotAcceptNullFunction() {
        new StringTemplate("foo").expand(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void usingMapShouldRejectNull() {
        usingMap(null);
    }

    @Test
    public void pathCanBeExpandedUsingMapp() {
        final StringTemplate template = new StringTemplate("{foo}/{bar}/{baz}");
        final String string = template.expand(usingMap(ImmutableMap.<String, Object>of(
                "foo", "FOO",
                "bar", "BAR",
                "baz", "BAZ"
        )));

        assertThat(string).isEqualTo("FOO/BAR/BAZ");
    }

    @Test
    public void stringTemplatesWithEqualExpressionsShouldBeEqual(){
        final StringTemplate instance1 = new StringTemplate("foo{bar}");
        final StringTemplate instance2 = new StringTemplate("foo{bar}");

        assertThat(instance1).isEqualTo(instance2);
        assertThat(instance1.hashCode()).isEqualTo(instance2.hashCode());
    }

    @Test
    public void stringTemplatesWithDifferentExpressionsShouldBeUnEqual() {
        final StringTemplate instance1 = new StringTemplate("foo{bar}");
        final StringTemplate instance2 = new StringTemplate("foo{baz}");

        assertThat(instance1).isNotEqualTo(instance2);
        assertThat(instance1.hashCode()).isNotEqualTo(instance2.hashCode());
    }

    @Test
    public void stringTemplateShouldNotBeEqualToNullOrInstanceOfDifferentType() {
        assertThat(new StringTemplate("foo{bar}")).isNotEqualTo(null);
        assertThat(new StringTemplate("foo{bar}")).isNotEqualTo("foo{bar}");
    }

    @Test
    public void toStringValueShouldContainExpression() {
        final StringTemplate stringTemplate = new StringTemplate("foo{bar}");

        assertThat(stringTemplate.toString()).contains("foo{bar}");
    }

    @Test
    public void allVariablesCanBeRetrieved() {
        final StringTemplate template = new StringTemplate("a{b}c{d}e{f}");

        assertThat(template.getVariables()).containsExactly("b", "d", "f");
    }

}
