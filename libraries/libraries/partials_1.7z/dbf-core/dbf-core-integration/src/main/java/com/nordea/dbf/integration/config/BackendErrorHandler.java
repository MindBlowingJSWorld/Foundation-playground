package com.nordea.dbf.integration.config;


import com.nordea.dbf.http.errorhandling.exception.ErrorResponse;

import java.util.Optional;

public interface BackendErrorHandler {

    <T extends ErrorResponse> Optional<T> exceptionOf(int kbearb, int krc);

    default void check(int kbearbh, int krc) {
        exceptionOf(kbearbh, krc).ifPresent(e -> {
            throw e;
        });
    }

}
