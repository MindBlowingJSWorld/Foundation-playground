package com.nordea.dbf.integration.config;

import javax.resource.ResourceException;
import javax.resource.cci.Connection;

public interface Connector {

    Connection connect() throws ResourceException;

}
