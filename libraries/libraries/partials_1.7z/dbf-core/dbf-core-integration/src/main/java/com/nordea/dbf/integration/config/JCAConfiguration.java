package com.nordea.dbf.integration.config;

import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import com.nordea.serviceconsumer.providers.JCAConnectionProvider;
import com.nordea.serviceconsumer.providers.defaults.JCAConnectionProviderImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

/**
 * Implementation of a JCA configuration provider that retrieves configuration details from
 * the Spring <code>Environment</code>.
 */
@Configuration
public class JCAConfiguration {

    @Bean
    public JCAConnectionProvider jcaConnectionProvider() {
        return new JCAConnectionProviderImpl();
    }

    @Bean
    @Autowired
    public ConfigurationProvider configurationProvider(final Environment environment) {
        return new ConfigurationProvider() {
            @Override
            public String getProperty(String name, String defaultValue) {
                return environment.getProperty(name, defaultValue);
            }

            @Override
            public String getProperty(String name) {
                return environment.getProperty(name);
            }
        };
    }

    @Bean
    public Connector connector(final JCAConnectionProvider connectionProvider, final ConfigurationProvider configurationProvider) {
        return () -> connectionProvider.getConnection(configurationProvider);
    }

}
