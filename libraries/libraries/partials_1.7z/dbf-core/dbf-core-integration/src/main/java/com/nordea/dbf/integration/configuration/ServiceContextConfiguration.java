package com.nordea.dbf.integration.configuration;

/**
 * Created by K293170 on 2015-04-15.
 */
public class ServiceContextConfiguration {
    private String technicalUserId;
    private String clientType;
    private String test;
    private String clientComponent;
    private String accountingUnit;
    private String officeMode;

    public String getTechnicalUserId() {
        return technicalUserId;
    }

    public void setTechnicalUserId(String technicalUserId) {
        this.technicalUserId = technicalUserId;
    }

    public String getClientType() {
        return clientType;
    }

    public void setClientType(String clientType) {
        this.clientType = clientType;
    }

    public String getTest() {
        return test;
    }

    public void setTest(String test) {
        this.test = test;
    }

    public String getClientComponent() {
        return clientComponent;
    }

    public void setClientComponent(String clientComponent) {
        this.clientComponent = clientComponent;
    }

    public String getAccountingUnit() {
        return accountingUnit;
    }

    public void setAccountingUnit(String accountingUnit) {
        this.accountingUnit = accountingUnit;
    }

    public String getOfficeMode() {
        return officeMode;
    }

    public void setOfficeMode(String officeMode) {
        this.officeMode = officeMode;
    }
}
