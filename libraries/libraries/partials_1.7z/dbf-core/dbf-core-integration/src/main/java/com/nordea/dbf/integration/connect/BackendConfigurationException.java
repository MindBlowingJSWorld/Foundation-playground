package com.nordea.dbf.integration.connect;

public class BackendConfigurationException extends RuntimeException {

    public BackendConfigurationException() {
    }

    public BackendConfigurationException(String message) {
        super(message);
    }

    public BackendConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }

    public BackendConfigurationException(Throwable cause) {
        super(cause);
    }

    public BackendConfigurationException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
