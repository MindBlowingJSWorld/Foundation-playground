package com.nordea.dbf.integration.connect;

import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import rx.Observable;

import java.util.Optional;

/**
 * Generic transaction executor that can execute transactions using an arbitrary integration mechanism.
 */
public interface BackendConnection<RequestBase, ResponseBase> extends AutoCloseable {

    default <Request extends RequestBase, Response extends ResponseBase> Observable<Response> execute(Request request, Class<Response> response) {
        return execute(ServiceRequestContextHolder.get(), request, response);
    }

    default <Request extends RequestBase, Response extends ResponseBase> Observable<Response> execute(Request request, Response response) {
        return execute(ServiceRequestContextHolder.get(), request, response);
    }

    <Request extends RequestBase, Response extends ResponseBase> Observable<Response> execute(Optional<ServiceRequestContext> context, Request request, Class<Response> response);

    <Request extends RequestBase, Response extends ResponseBase> Observable<Response> execute(Optional<ServiceRequestContext> context, Request request, Response response);

    @Override
    void close();
}
