package com.nordea.dbf.integration.connect;

public class BackendConnectivityException extends RuntimeException {

    public BackendConnectivityException() {
    }

    public BackendConnectivityException(String message) {
        super(message);
    }

    public BackendConnectivityException(String message, Throwable cause) {
        super(message, cause);
    }

    public BackendConnectivityException(Throwable cause) {
        super(cause);
    }

    public BackendConnectivityException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
