package com.nordea.dbf.integration.connect;

public interface BackendConnector<RequestBase, ResponseBase> {

    BackendConnection<RequestBase, ResponseBase> connect();

}
