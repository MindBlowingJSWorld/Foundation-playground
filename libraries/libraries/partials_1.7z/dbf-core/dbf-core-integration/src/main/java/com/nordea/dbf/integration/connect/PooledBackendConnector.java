package com.nordea.dbf.integration.connect;

import com.nordea.dbf.concurrent.Handover;
import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.http.ServiceRequestContext;
import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Supplier;

import static java.lang.System.currentTimeMillis;
import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * BackendConnector that pools connections. Does not block any threads but queues subscribers and
 * executes operations when a connection is available.
 *
 * The pool starts a new thread for closing idle connections. To stop this thread and close all connections
 * caller must invoke destroy().
 *
 * @param <T> Request type
 * @param <R> Response type
 */
public class PooledBackendConnector<T,R> implements BackendConnector<T, R>, BackendConnection<T,R> {

    private final Supplier<BackendConnection<T,R>> connectionFactory;
    private final int maxSize;

    private final ScheduledExecutorService idleThread = Executors.newSingleThreadScheduledExecutor();
    private final long maxIdleMillis;

    private final ThreadContext threadContext;

    final AtomicInteger size = new AtomicInteger();
    final BlockingQueue<ConnectionEntry<T,R>> connections;
    final BlockingQueue<Subscriber<? super ConnectionEntry<T,R>>> subscribers;
    final AtomicLong subscriberAdded = new AtomicLong();

    public PooledBackendConnector(Supplier<BackendConnection<T,R>> connectionFactory, int maxSize, ThreadContext threadContext) {
        this(connectionFactory, maxSize, 90, 120, threadContext);
    }

    public PooledBackendConnector(Supplier<BackendConnection<T,R>> connectionFactory, int maxSize,
                                  int maxIdleSeconds, int idleCheckIntervalSeconds,
                                  ThreadContext threadContext) {

        this.connectionFactory = connectionFactory;
        this.maxSize = maxSize;
        this.connections = new ArrayBlockingQueue<>(maxSize);
        this.subscribers = new LinkedBlockingDeque<>();
        this.maxIdleMillis = SECONDS.toMillis(maxIdleSeconds);
        this.threadContext = threadContext;

        idleThread.scheduleAtFixedRate(closeIdleConnectionsTask(),
                idleCheckIntervalSeconds, idleCheckIntervalSeconds, SECONDS);
    }

    @Override
    public BackendConnection<T,R> connect() {
        return this; // don't block on connect
    }

    @Override
    public void close() {
        // no-op
    }

    @Override
    public <Request extends T, Response extends R> Observable<Response> execute(
            Optional<ServiceRequestContext> context, Request request, Class<Response> response) {

        return getConnection()
                .flatMap(entry -> entry.connection.execute(context, request, response)
                                    .doOnTerminate(() -> releaseConnection(entry)));
    }

    @Override
    public <Request extends T, Response extends R> Observable<Response> execute(
            Optional<ServiceRequestContext> context, Request request, Response response) {

        return getConnection()
                .flatMap(entry -> entry.connection.execute(context, request, response)
                                    .doOnTerminate(() -> releaseConnection(entry)));
    }

    public void destroy() throws Exception {
        idleThread.shutdown();

        while(!subscribers.isEmpty()) {
            Subscriber<? super ConnectionEntry<T, R>> subscriber = subscribers.poll();
            if(subscriber == null) {
                break;
            }
            subscriber.onError(new InterruptedException("PooledBackendConnector pool closed"));
        }
        while(size.get() > 0) {
            ConnectionEntry<T, R> entry = connections.poll(10, SECONDS);
            if(entry == null) {
                break;
            }
            closeConnection(entry);
        }
    }

    private Observable<ConnectionEntry<T,R>> getConnection() {

        Handover handover = threadContext.createHandover();

        return Observable.create(target -> {

            Subscriber<? super ConnectionEntry<T, R>> subscriber = new HandoverSubscriber<>(handover, target);

            ConnectionEntry<T, R> leased = connections.poll();
            if (leased != null) {
                subscriber.onNext(leased);
                subscriber.onCompleted();
                return;
            }

            if (tryIncrementSize()) {
                try {
                    subscriber.onNext(new ConnectionEntry<>(connectionFactory.get()));
                    subscriber.onCompleted();
                } catch (Throwable throwable) {
                    size.decrementAndGet();
                    subscriber.onError(throwable);
                }
                return;
            }

            subscribers.add(subscriber);
            subscriberAdded.incrementAndGet();
        });
    }

    private void releaseConnection(ConnectionEntry<T,R> entry) {
        releaseConnection(entry, true);
    }

    private void releaseConnection(ConnectionEntry<T,R> entry, boolean updateLastUsed) {

        long snapshot = subscriberAdded.get();
        Subscriber<? super ConnectionEntry<T, R>> queued = subscribers.poll();

        if (queued == null) {
            if (updateLastUsed) {
                entry.lastUsed.set(currentTimeMillis());
            }
            connections.add(entry);
            if (snapshot != subscriberAdded.get() && (queued = subscribers.poll()) != null) {
                getConnection().subscribe(queued);
            }
            return;
        }

        Observable.just(entry)
                .subscribeOn(Schedulers.trampoline())
                .observeOn(Schedulers.computation())
                .subscribe(queued);
    }

    private boolean tryIncrementSize() {
        while(true) {
            final int current = size.get();
            if(current == maxSize) {
                return false;
            }
            if(size.compareAndSet(current, current + 1)) {
                return true;
            }
        }
    }

    private void closeConnection(ConnectionEntry<T,R> entry) {
        entry.connection.close();
        size.decrementAndGet();
    }

    @SuppressWarnings("MismatchedQueryAndUpdateOfCollection")
    private Runnable closeIdleConnectionsTask() {
        return () -> {
            List<ConnectionEntry<T,R>> entries = new ArrayList<>(connections.size());
            if(connections.drainTo(entries) > 0) {
                entries.forEach(entry -> {
                    if (currentTimeMillis() - entry.lastUsed.get() > maxIdleMillis) {
                        closeConnection(entry);
                    } else {
                        releaseConnection(entry, false);
                    }
                });
            }
        };
    }

    static class ConnectionEntry<T,R> {

        final BackendConnection<T,R> connection;
        final AtomicLong lastUsed = new AtomicLong();

        ConnectionEntry(BackendConnection<T, R> connection) {
            this.connection = connection;
        }
    }

    static class HandoverSubscriber<T> extends Subscriber<T> {

        final Handover handover;
        final Subscriber<T> subscriber;

        HandoverSubscriber(Handover handover, Subscriber<T> subscriber) {
            this.handover = handover;
            this.subscriber = subscriber;
        }
        @Override
        public void onCompleted() {
            handover.in(subscriber::onCompleted);
        }
        @Override
        public void onError(Throwable e) {
            handover.in(() -> subscriber.onError(e));
        }
        @Override
        public void onNext(T t) {
            handover.in(() -> subscriber.onNext(t));
        }
    }
}
