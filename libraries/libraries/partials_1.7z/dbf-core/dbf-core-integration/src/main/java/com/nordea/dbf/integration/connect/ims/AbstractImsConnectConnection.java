package com.nordea.dbf.integration.connect.ims;

import com.nordea.dbf.concurrent.DeferredPromise;
import com.nordea.dbf.concurrent.Handover;
import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.integration.connect.BackendConfigurationException;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnectivityException;
import com.nordea.sc.jca.BackendInteractionSpec;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.resource.ResourceException;
import javax.resource.cci.Connection;
import javax.resource.cci.Interaction;
import javax.resource.cci.Record;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public abstract class AbstractImsConnectConnection<RequestBase extends Record, ResponseBase extends Record> implements BackendConnection<RequestBase, ResponseBase> {

    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractImsConnectConnection.class);

    private final Connection connection;

    private final ImsConfigurationSupplier configurationSupplier;

    private final ThreadContext threadContext;

    protected AbstractImsConnectConnection(Connection connection,
                                           ImsConfigurationSupplier configurationSupplier,
                                           ThreadContext threadContext) {
        Validate.notNull(connection, "connection can't be null");
        Validate.notNull(configurationSupplier, "configurationSupplier can't be null");
        Validate.notNull(threadContext, "threadContext can't be null");

        this.connection = connection;
        this.configurationSupplier = configurationSupplier;
        this.threadContext = threadContext;
    }

    protected Connection getConnection() {
        return connection;
    }

    protected ImsConfigurationSupplier getConfigurationSupplier() {
        return configurationSupplier;
    }

    protected <Request extends RequestBase, Response extends ResponseBase> Observable<Response> executeAsync(final Request request, final Class<Response> responseType, final String transactionCode) {
        final Response response;

        try {
            response = responseType.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            throw new IllegalArgumentException("Response record '" + responseType.getName() + "' must contain a public default constructor", e);
        }

        return executeAsync(request, response, transactionCode);
    }

    protected <Request extends RequestBase, Response extends ResponseBase> Observable<Response> executeAsync(final Request request, final Response response, final String transactionCode) {
        final long start = System.nanoTime();
        final String commandId = UUID.randomUUID().toString();
        final Interaction interaction;

        try {
            interaction = connection.createInteraction();
        } catch (ResourceException e) {
            throw new BackendConnectivityException("Could not create JCA interaction", e);
        }

        final ImsConfiguration configuration = configurationSupplier.get(request, response);
        final BackendInteractionSpec backendSpec = createBackendInteractionSpec(transactionCode, configuration, request, response);
        final DeferredPromise<Response> promise = DeferredPromise.create();
        final Handover handover = threadContext.createHandover();

        backendSpec.setAsyncCallback(new BackendInteractionSpec.IAsyncCallback() {
            @Override
            public void responseCompleted() {
                handover.in(() -> {
                    try {
                        checkResponse(commandId, request, response);
                    } catch (Throwable e) {
                        LOGGER.warn("Error when checking JCA response record", e);
                    }

                    try {
                        promise.complete(response);

                        LOGGER.info("IMS transaction \"{}\" with commandId={} outcome=completed after duration={}ms",
                                request.getClass().getSimpleName(), commandId,
                                TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start));
                    } catch (Throwable e) {
                        promise.fail(e);

                        LOGGER.info("IMS transaction \"{}\" with commandId={} outcome=failed after duration={}ms",
                                request.getClass().getSimpleName(), commandId,
                                TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start), e);
                    }
                });
            }

            @Override
            public void responseFailed(Throwable throwable) {
                handover.in(() -> {
                    LOGGER.info("IMS transaction \"{}\" with commandId={} failed after {}ms",
                            request.getClass().getSimpleName(), commandId,
                            TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start), throwable);

                    promise.fail(throwable);
                });
            }
        });

        backendSpec.getProperties().setProperty("debuglog",
                String.valueOf(configuration.isDebugLoggingEnabled()));
        backendSpec.getProperties().setProperty("sendtransactionid",
                String.valueOf(configuration.shouldSendTransactionId()));
        backendSpec.setServerIdentifier(configuration.getServerIdentifier());

        LOGGER.info("Issuing IMS transaction \"{}\" with commandId={}",
                request.getClass().getSimpleName(), commandId);

        preConfigure(request, response, configuration);

        try {
            if (!interaction.execute(backendSpec, request, response)) {
                return Observable.error(new BackendConfigurationException("Transaction '" + request.getClass().getName() + "' was not accepted by JCA adapter"));
            }
        } catch (ResourceException e) {
            throw new BackendConnectivityException("Transaction '" + request.getClass().getName() + "' could not be executed", e);
        }

        return promise.toObservable();
    }

    @Override
    public void close() {
        try {
            connection.close();
        } catch (ResourceException e) {
            throw new BackendConnectivityException("JCA connection was not released properly", e);
        }
    }

    protected BackendInteractionSpec createBackendInteractionSpec(String transactionCode, ImsConfiguration configuration,
                                                                  RequestBase request, ResponseBase response) {
        return new BackendInteractionSpec(configuration.getBackendType(), transactionCode);
    }

    protected void preConfigure(RequestBase request, ResponseBase response, ImsConfiguration configuration) {
    }

    protected void checkResponse(String commandId, RequestBase request, ResponseBase response) {
    }
}
