package com.nordea.dbf.integration.connect.ims;

import com.google.common.collect.ImmutableList;
import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import org.apache.commons.lang.Validate;

import javax.resource.cci.Record;
import java.util.function.BiPredicate;

public class Configurations {

    /**
     * Returns a configuration supplier that always returns the same configuration.
     *
     * @param configuration The configuration that should be returned.
     * @return A supplier that returns the provided configuration.
     */
    public static ImsConfigurationSupplier singleton(final ImsConfiguration configuration) {
        Validate.notNull(configuration, "configuration can't be null");

        return (request, response) -> configuration;
    }

    public static String transactionCodeOf(Record record) {
        Validate.notNull(record, "record can't be null");

        if (record instanceof M8MessageHeaderRequestRecord) {
            return ((M8MessageHeaderRequestRecord) record).getTransactionCode();
        }

        if (record instanceof F9MessageHeaderRequestRecord) {
            return ((F9MessageHeaderRequestRecord) record).getTransactionCode();
        }

        throw new IllegalArgumentException("Record not recognized: " + record.getClass().getName());
    }

    public static Builder builder() {
        final ImmutableList.Builder<ConfigurationCandidate> builder = ImmutableList.builder();

        return new Builder() {
            @Override
            public WhenContinuation when(BiPredicate<Record, Record> predicate) {
                return configuration -> {
                    builder.add(new ConfigurationCandidate(predicate, configuration));
                    return this;
                };
            }

            @Override
            public ImsConfigurationSupplier build() {
                final ImmutableList<ConfigurationCandidate> candidates = builder.build();

                return (request, response) -> {
                    for (final ConfigurationCandidate candidate : candidates) {
                        if (candidate.getPredicate().test(request, response)) {
                            return candidate.getConfiguration();
                        }
                    }

                    throw new IllegalArgumentException("Unsupported request/response: " + request + ", " + response);
                };
            }
        };
    }

    public interface Builder {

        WhenContinuation when(BiPredicate<Record, Record> predicate);

        ImsConfigurationSupplier build();
    }

    public interface WhenContinuation {

        Builder then(ImsConfiguration configuration);

    }

    private static class ConfigurationCandidate {

        private final BiPredicate<Record, Record> predicate;

        private final ImsConfiguration configuration;

        public ConfigurationCandidate(BiPredicate<Record, Record> predicate, ImsConfiguration configuration) {
            this.predicate = predicate;
            this.configuration = configuration;
        }

        public BiPredicate<Record, Record> getPredicate() {
            return predicate;
        }

        public ImsConfiguration getConfiguration() {
            return configuration;
        }
    }


}
