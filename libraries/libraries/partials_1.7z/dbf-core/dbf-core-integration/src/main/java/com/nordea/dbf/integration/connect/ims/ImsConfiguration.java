package com.nordea.dbf.integration.connect.ims;

import com.nordea.sc.jca.BackendInteractionSpec;
import org.apache.commons.lang.Validate;

public class ImsConfiguration {

    private final BackendInteractionSpec.BackendType backendType;

    private final String serverIdentifier;

    private final boolean debugLog;

    private final boolean sendTransactionId;

    private ImsConfiguration(BackendInteractionSpec.BackendType backendType, boolean debugLog,
        boolean sendTransactionId, String serverIdentifier) {
        Validate.notNull(backendType, "backendType must be provided");
        Validate.notEmpty(serverIdentifier, "serverIdentifier can't be null or empty");

        this.backendType = backendType;
        this.debugLog = debugLog;
        this.sendTransactionId = sendTransactionId;
        this.serverIdentifier = serverIdentifier;
    }

    public BackendInteractionSpec.BackendType getBackendType() {
        return backendType;
    }

    public boolean isDebugLoggingEnabled() {
        return debugLog;
    }

    public boolean shouldSendTransactionId() {
        return sendTransactionId;
    }

    public String getServerIdentifier() {
        return serverIdentifier;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {

        private BackendInteractionSpec.BackendType backendType = BackendInteractionSpec.BackendType.TYPE_GENERIC;

        private boolean debugLog = false;

        private boolean sendTransactionId = false;

        private String serverIdentifier;

        public Builder backendType(BackendInteractionSpec.BackendType backendType) {
            this.backendType = backendType;
            return this;
        }

        public Builder serverIdentifier(String serverIdentifier) {
            this.serverIdentifier = serverIdentifier;
            return this;
        }

        public Builder debugLog(boolean debugLog) {
            this.debugLog = debugLog;
            return this;
        }

        public Builder sendTransactionId(boolean sendTransactionId) {
            this.sendTransactionId = sendTransactionId;
            return this;
        }

        public ImsConfiguration build() {
            return new ImsConfiguration(backendType, debugLog, sendTransactionId, serverIdentifier);
        }

    }

}
