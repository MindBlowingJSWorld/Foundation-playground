package com.nordea.dbf.integration.connect.ims;

import javax.resource.cci.Record;

public interface ImsConfigurationSupplier {

    ImsConfiguration get(Record request, Record response);

}
