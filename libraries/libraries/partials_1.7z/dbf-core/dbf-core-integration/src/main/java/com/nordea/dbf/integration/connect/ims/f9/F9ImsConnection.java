package com.nordea.dbf.integration.connect.ims.f9;

import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.F9MessageHeaderResponseRecord;

public interface F9ImsConnection extends BackendConnection<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> {
}
