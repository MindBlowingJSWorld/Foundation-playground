package com.nordea.dbf.integration.connect.ims.f9;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import com.nordea.dbf.integration.connect.ims.AbstractImsConnectConnection;
import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.F9MessageHeaderResponseRecord;
import com.nordea.pn.service.util.LogonMethodData;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.resource.cci.Connection;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

public class F9ImsConnectionImpl extends AbstractImsConnectConnection<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> implements F9ImsConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(F9ImsConnectionImpl.class);

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd");

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HHmmss00");

    private final TransactionSequence transactionSequence;

    F9ImsConnectionImpl(Connection connection,
                        TransactionSequence transactionSequence,
                        ImsConfigurationSupplier configurationSupplier,
                        ThreadContext threadContext) {
        super(connection, configurationSupplier, threadContext);
        this.transactionSequence = transactionSequence;
    }

    @Override
    public <Request extends F9MessageHeaderRequestRecord, Response extends F9MessageHeaderResponseRecord> Observable<Response> execute(Request request, Class<Response> response) {
        return execute(ServiceRequestContextHolder.get(), request, response);
    }

    @Override
    public <Request extends F9MessageHeaderRequestRecord, Response extends F9MessageHeaderResponseRecord> Observable<Response> execute(Optional<ServiceRequestContext> context,
                                                                                                                                       Request request,
                                                                                                                                       Response response) {
        validateRequest(context, request);
        preConfigureRequest(context, request);

        return super.executeAsync(request, response, request.getTransactionCode());
    }

    @Override
    public <Request extends F9MessageHeaderRequestRecord, Response extends F9MessageHeaderResponseRecord> Observable<Response> execute(Optional<ServiceRequestContext> context,
                                                                                                                                       Request request,
                                                                                                                                       Class<Response> responseType) {
        validateRequest(context, request);
        preConfigureRequest(context, request);

        return super.executeAsync(request, responseType, request.getTransactionCode());
    }

    private <Request extends F9MessageHeaderRequestRecord> void validateRequest(Optional<ServiceRequestContext> context, Request request) {
        Validate.notNull(context, "context can't be null");
        Validate.notNull(request, "request can't be null");
        Validate.notEmpty(request.getTransactionCode(), "request.transactionCode can't be null or empty");
        Validate.notEmpty(request.getMessageId(), "request.messageId can't be null or empty");
    }

    /**
     * Pre-configures the request. This will add missing parts of the request from teh provided context.
     *
     * @param context   The context
     * @param request
     * @param <Request>
     */
    private <Request extends F9MessageHeaderRequestRecord> void preConfigureRequest(Optional<ServiceRequestContext> context, Request request) {
        configureRequestContext(context, request);
        configureChronology(request);
        configureConstants(request);
    }

    /**
     * Configures constant fields on the request. These are taken from the PN connectivityservice
     * and should be investigated further.
     *
     * @param request   The request that should be configured.
     * @param <Request> The type of the request.
     */
    private <Request extends F9MessageHeaderRequestRecord> void configureConstants(Request request) {
        request.setRacfId2(LogonMethodData.CAP);
        request.setSenderCode(0);
        request.setVersionCode(LogonMethodData.FTKD);
    }

    /**
     * Configures the current date, time and transaction number on the request.
     *
     * @param request   The request that should be configured.
     * @param <Request> The type of the request.
     */
    private <Request extends F9MessageHeaderRequestRecord> void configureChronology(Request request) {
        final LocalDateTime now = LocalDateTime.now();

        request.setTransationDate(DATE_FORMAT.format(now));
        request.setTransationTime(TIME_FORMAT.format(now));
        request.setTransactionNumber(transactionSequence.next());
    }

    /**
     * Configures the request context of the request unless it is already configured. If the request is missing
     * context information, the service request context must be present.
     *
     * @param context   The <code>ServiceRequestContext</code> that denotes the user request context.
     * @param request   The request that should be configured.
     * @param <Request> The type of the request.
     */
    private <Request extends F9MessageHeaderRequestRecord> void configureRequestContext(Optional<ServiceRequestContext> context, Request request) {
        if (request.getUserId() == 0L) {
            request.setUserId(Long.valueOf(context.get().getUserId().get()));
        }

        if (request.getAgreement() == 0) {
            request.setAgreement(context.get().getAgreementNumber().get().intValue());
        }

        if (StringUtils.isEmpty(request.getRacfId1())) {
            request.setRacfId1(context.get().getUserId().get().substring(0, 8));
        }
    }

    @Override
    protected void preConfigure(F9MessageHeaderRequestRecord request, F9MessageHeaderResponseRecord response, ImsConfiguration configuration) {
        LOGGER.info("Executing F9 IMS transaction record={}, transactionCode={}, messageId={}, transactionNumber={}",
                request.getRecordName(), request.getTransactionCode(), request.getMessageId(), request.getTransactionNumber());
    }
}
