package com.nordea.dbf.integration.connect.ims.f9;

import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.F9MessageHeaderResponseRecord;

public interface F9ImsConnector extends BackendConnector<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> {

    @Override
    F9ImsConnection connect();

}
