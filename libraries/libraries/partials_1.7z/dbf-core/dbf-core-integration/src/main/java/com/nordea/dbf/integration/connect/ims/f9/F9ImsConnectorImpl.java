package com.nordea.dbf.integration.connect.ims.f9;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.integration.connect.BackendConnectivityException;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.dbf.integration.connect.ims.jca.JCAConnectionSupplier;
import org.apache.commons.lang.Validate;

import javax.resource.ResourceException;
import javax.resource.cci.Connection;

public class F9ImsConnectorImpl implements F9ImsConnector {

    private final JCAConnectionSupplier jcaConnectionSupplier;

    private final ImsConfigurationSupplier imsConfigurationSupplier;

    private final TransactionSequence hostTransactionSequence;

    private final ThreadContext threadContext;

    public F9ImsConnectorImpl(JCAConnectionSupplier jcaConnectionSupplier,
                              ImsConfigurationSupplier configurationSupplier) {
        this(jcaConnectionSupplier, configurationSupplier, TransactionSequence.DEFAULT, ThreadContext.DEFAULT);
    }

    public F9ImsConnectorImpl(JCAConnectionSupplier jcaConnectionSupplier,
                              ImsConfigurationSupplier configurationSupplier,
                              TransactionSequence hostTransactionSequence,
                              ThreadContext threadContext) {
        Validate.notNull(jcaConnectionSupplier, "jcaConnectionSupplier can't be null");
        Validate.notNull(configurationSupplier, "imsConfigurationSupplier can't be null");
        Validate.notNull(hostTransactionSequence, "hostTransactionSequence can't be null");
        Validate.notNull(threadContext, "threadContext can't be null");

        this.jcaConnectionSupplier = jcaConnectionSupplier;
        this.imsConfigurationSupplier = configurationSupplier;
        this.hostTransactionSequence = hostTransactionSequence;
        this.threadContext = threadContext;
    }

    @Override
    public F9ImsConnection connect() {
        final Connection connection;

        try {
            connection = jcaConnectionSupplier.getConnection();
        } catch (ResourceException e) {
            throw new BackendConnectivityException("Failed to create JCA connection", e);
        }

        return new F9ImsConnectionImpl(connection, hostTransactionSequence, imsConfigurationSupplier, threadContext);
    }
}
