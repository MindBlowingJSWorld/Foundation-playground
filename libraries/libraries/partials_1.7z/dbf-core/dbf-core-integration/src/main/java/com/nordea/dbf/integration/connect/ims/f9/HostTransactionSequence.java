package com.nordea.dbf.integration.connect.ims.f9;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Generates transactions based on the IPv4 number of the host.
 */
public class HostTransactionSequence implements TransactionSequence {

    private final AtomicInteger currentValue;

    private HostTransactionSequence(int baseSequenceNumber) {
        this.currentValue = new AtomicInteger(baseSequenceNumber);
    }

    @Override
    public int next() {
        return currentValue.getAndIncrement() & 0x7FFFFFFF;
    }

    public static HostTransactionSequence fromLocalHost() throws UnknownHostException {
        final byte[] address = InetAddress.getLocalHost().getAddress();

        return new HostTransactionSequence(Arrays.hashCode(address));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HostTransactionSequence sequence = (HostTransactionSequence) o;

        return currentValue.equals(sequence.currentValue);

    }

    @Override
    public int hashCode() {
        return currentValue.hashCode();
    }

    @Override
    public String toString() {
        return "HostTransactionSequence{" +
                "currentValue=" + currentValue +
                '}';
    }
}
