package com.nordea.dbf.integration.connect.ims.f9;

import com.nordea.dbf.util.Initializer;

import java.net.UnknownHostException;

/**
 * A transaction sequence is used to assign unique transaction numbers to transactions.
 */
public interface TransactionSequence {

    TransactionSequence DEFAULT = Initializer.from(() -> {
        try {
            return HostTransactionSequence.fromLocalHost();
        } catch (UnknownHostException e) {
            throw new ExceptionInInitializerError(e);
        }
    });

    int next();

}
