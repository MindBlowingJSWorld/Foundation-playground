package com.nordea.dbf.integration.connect.ims.fi;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.integration.connect.BackendConnectivityException;
import com.nordea.dbf.integration.connect.ims.AbstractImsConnectConnection;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import rx.Observable;

import javax.resource.cci.Connection;
import java.util.Optional;

public class ImsConnection extends AbstractImsConnectConnection<ImsRecord,ImsRecord> {

    public ImsConnection(Connection connection,
                         ImsConfigurationSupplier configurationSupplier,
                         ThreadContext threadContext) {
        super(connection, configurationSupplier, threadContext);
    }

    @Override
    public <T extends ImsRecord, R extends ImsRecord> Observable<R> execute(Optional<ServiceRequestContext> context, T request, Class<R> response) {
        return executeAsync(request, response, request.getTransactionCode()).flatMap(res -> sendErrorOnFailure(request, res));
    }

    @Override
    public <T extends ImsRecord, R extends ImsRecord> Observable<R> execute(Optional<ServiceRequestContext> context, T request, R response) {
        return executeAsync(request, response, request.getTransactionCode()).flatMap(res -> sendErrorOnFailure(request, res));
    }

    <T extends ImsRecord> Observable<T> sendErrorOnFailure(ImsRecord request, T response) {
        String rc = response.getReturnCode(request.isPackedBitmap(), request.getCharset());
        if(rc == null || rc.isEmpty()) {
            return Observable.error(new BackendConnectivityException("Return code not available"));
        }
        if(rc.startsWith("V2000")) {
            return Observable.error(new ImsException(rc, "System error"));
        }
        if(rc.length() > 5 && !rc.regionMatches(5, "000", 0, Math.min(rc.length() - 5, 3))) {
            return Observable.error(new ImsException(rc, "Transaction error"));
        }
        return Observable.just(response);
    }
}
