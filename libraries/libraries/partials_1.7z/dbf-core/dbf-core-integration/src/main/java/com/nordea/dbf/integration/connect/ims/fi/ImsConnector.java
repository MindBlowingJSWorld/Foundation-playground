package com.nordea.dbf.integration.connect.ims.fi;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.integration.connect.BackendConnectivityException;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.dbf.integration.connect.ims.jca.JCAConnectionSupplier;

import javax.resource.ResourceException;

public class ImsConnector implements BackendConnector<ImsRecord,ImsRecord> {

    private final JCAConnectionSupplier jcaConnectionSupplier;
    private final ImsConfigurationSupplier configurationSupplier;
    private final ThreadContext threadContext;

    public ImsConnector(JCAConnectionSupplier jcaConnectionSupplier,
                        ImsConfigurationSupplier configurationSupplier,
                        ThreadContext threadContext) {
        this.jcaConnectionSupplier = jcaConnectionSupplier;
        this.configurationSupplier = configurationSupplier;
        this.threadContext = threadContext;
    }

    @Override
    public ImsConnection connect() {
        try {
            return new ImsConnection(jcaConnectionSupplier.getConnection(), configurationSupplier, threadContext);
        } catch (ResourceException e) {
            throw new BackendConnectivityException("Failed to create JCA connection", e);
        }
    }
}
