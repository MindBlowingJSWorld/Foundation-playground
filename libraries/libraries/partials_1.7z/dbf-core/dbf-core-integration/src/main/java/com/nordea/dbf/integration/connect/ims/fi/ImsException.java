package com.nordea.dbf.integration.connect.ims.fi;

public class ImsException extends RuntimeException {

    private final String errorCode;

    public ImsException(String errorCode, String message) {
        super(message + ": " + errorCode);
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }
}
