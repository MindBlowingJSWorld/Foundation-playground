package com.nordea.dbf.integration.connect.ims.fi;

import javax.resource.cci.Record;
import javax.resource.cci.Streamable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Arrays;

public class ImsRecord implements Record, Streamable {

    private static final int HEADER_OFFSET = 59;
    private static final int SEPARATOR = 0x0b;

    private byte bytes[];
    private final String transactionCode;
    private final boolean packedBitmap;
    private final Charset charset;

    public ImsRecord() {
        this(null, null, false, null);
    }

    public ImsRecord(String transactionCode, byte[] bytes, boolean packedBitmap, Charset charset) {
        this.bytes = bytes;
        this.transactionCode = transactionCode;
        this.packedBitmap = packedBitmap;
        this.charset = charset;
    }

    public byte[] getBytes() {
        return bytes;
    }
    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }
    public String getTransactionCode() {
        return transactionCode;
    }
    public Charset getCharset() {
        return charset;
    }
    public boolean isPackedBitmap() {
        return packedBitmap;
    }

    public String getReturnCode(boolean requestIsBitMap, Charset requestCharset) {
        if(bytes == null) {
            return null;
        }
        if(!requestIsBitMap) {
            return new String(Arrays.copyOfRange(bytes, HEADER_OFFSET + 16, HEADER_OFFSET + 24), requestCharset);
        }
        if(!hasPackedField(1)) {
            return "00000";
        }

        int start = HEADER_OFFSET + getBitmapLen();
        if(hasPackedField(0)) {
            while(bytes[start++] != SEPARATOR){ /* increment ptr until until field 1 starts */ }
        }
        int end = start;
        while(bytes[++end] != SEPARATOR){ /* increment ptr until until field 1 ends */ }

        return new String(Arrays.copyOfRange(bytes, start, end), requestCharset);
    }

    @Override
    public void read(InputStream inputStream) throws IOException {
        bytes = new byte[inputStream.available()];
        if(inputStream.read(bytes) != bytes.length) {
            throw new IllegalStateException("Stream read failure");
        }
    }

    @Override
    public void write(OutputStream outputStream) throws IOException {
        outputStream.write(bytes);
        outputStream.flush();
    }

    @Override
    public String toString() {
        return String.format("%s(len=%d)", transactionCode, bytes != null ? bytes.length : 0);
    }

    @Override
    public String getRecordName() { return null; }
    @Override
    public void setRecordName(String recordName) { }
    @Override
    public void setRecordShortDescription(String recordShortDescription) { }
    @Override
    public String getRecordShortDescription() { return null; }
    @Override
    public Object clone() throws CloneNotSupportedException{ return super.clone(); }

    private boolean hasPackedField(int index) {
        int bNr = index + (index / 63);
        return (bytes[HEADER_OFFSET + (bNr / 8)] & (0x80 >> (bNr % 8))) != 0;
    }

    private int getBitmapLen() {
        int e = 1;
        while ((bytes[HEADER_OFFSET + e * 8 - 1] & 1) != 0) {
            ++e;
        }
        return e * 8;
    }


}
