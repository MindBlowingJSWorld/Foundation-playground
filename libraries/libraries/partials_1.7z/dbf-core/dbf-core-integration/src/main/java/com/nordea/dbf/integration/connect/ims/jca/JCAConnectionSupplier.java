package com.nordea.dbf.integration.connect.ims.jca;

import javax.resource.ResourceException;
import javax.resource.cci.Connection;

public interface JCAConnectionSupplier {

    Connection getConnection() throws ResourceException;
}
