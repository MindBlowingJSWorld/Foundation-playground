package com.nordea.dbf.integration.connect.ims.m8;

import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;

public interface M8ImsConnection extends BackendConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> {
}
