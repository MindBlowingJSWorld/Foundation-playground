package com.nordea.dbf.integration.connect.ims.m8;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.integration.connect.ims.AbstractImsConnectConnection;
import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.resource.cci.Connection;
import java.util.Optional;

public class M8ImsConnectionImpl extends AbstractImsConnectConnection<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> implements M8ImsConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(M8ImsConnectionImpl.class);

    public M8ImsConnectionImpl(Connection connection, ImsConfigurationSupplier configurationSupplier, ThreadContext threadContext) {
        super(connection, configurationSupplier, threadContext);
    }

    @Override
    public <Request extends M8MessageHeaderRequestRecord, Response extends M8MessageHeaderResponseRecord> Observable<Response> execute(Optional<ServiceRequestContext> context, Request request, Response response) {
        Validate.notNull(response, "response can't be null");

        validateRequest(context, request);
        preconfigureRequest(context, request);

        return executeAsync(request, response, request.getTransactionCode());
    }

    @Override
    public <Request extends M8MessageHeaderRequestRecord, Response extends M8MessageHeaderResponseRecord> Observable<Response> execute(Optional<ServiceRequestContext> context, Request request, Class<Response> responseType) {
        Validate.notNull(responseType, "responseType can't be null");

        validateRequest(context, request);
        preconfigureRequest(context, request);

        return executeAsync(request, responseType, request.getTransactionCode());
    }

    private <Request extends M8MessageHeaderRequestRecord> void preconfigureRequest(Optional<ServiceRequestContext> context, Request request) {
        if (context.isPresent()) {
            request.setApplicationId(context.get().getApplicationId().orElse(StringUtils.EMPTY));
            request.setRequestId(context.get().getRequestId().orElse(StringUtils.EMPTY));
            request.setSessionId(context.get().getSessionId().orElse(StringUtils.EMPTY));
            request.setCountry(context.get().getCountry().orElse(StringUtils.EMPTY));

            if (context.get().getLanguage().isPresent()) {
                request.setLanguage(context.get().getLanguage().get().getLanguage());
            }
        }
    }

    private <Request extends M8MessageHeaderRequestRecord> void validateRequest(Optional<ServiceRequestContext> context, Request request) {
        Validate.notNull(context, "context can't be null");
        Validate.notNull(request, "request can't be null");
        Validate.notEmpty(request.getTransactionCode(), "transactionCode can't be null or empty");
        Validate.notEmpty(request.getMessageId(), "messageId can't be null or empty");
    }

    @Override
    protected void preConfigure(M8MessageHeaderRequestRecord request, M8MessageHeaderResponseRecord response, ImsConfiguration configuration) {
        LOGGER.info("Executing M8 IMS transaction record={}, transactionCode={}, messageId={}",
                request.getClass().getSimpleName(), request.getTransactionCode(), request.getMessageId());
    }

    @Override
    protected void checkResponse(String commandId, M8MessageHeaderRequestRecord request, M8MessageHeaderResponseRecord response) {
        if (response.getKbearb() != 0 && response.getKrc() != 0) {
            LOGGER.info("JCA request with commandId={} completed with kbearb={} and krc={}", commandId, response.getKbearb(), response.getKrc());
        }
    }
}
