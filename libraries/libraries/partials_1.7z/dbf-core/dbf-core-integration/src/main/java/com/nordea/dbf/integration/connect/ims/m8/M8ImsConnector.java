package com.nordea.dbf.integration.connect.ims.m8;

import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;

public interface M8ImsConnector extends BackendConnector<M8MessageHeaderRequestRecord, M8MessageHeaderResponseRecord> {

    @Override
    M8ImsConnection connect();
}
