package com.nordea.dbf.integration.connect.ims.m8;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.integration.connect.BackendConnectivityException;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.dbf.integration.connect.ims.jca.JCAConnectionSupplier;
import org.apache.commons.lang.Validate;

import javax.resource.ResourceException;
import javax.resource.cci.Connection;

public class M8ImsConnectorImpl implements M8ImsConnector {

    private final JCAConnectionSupplier jcaConnectionSupplier;

    private final ImsConfigurationSupplier imsConfigurationSupplier;

    private final ThreadContext threadContext;

    public M8ImsConnectorImpl(JCAConnectionSupplier jcaConnectionSupplier,
                              ImsConfigurationSupplier imsConfigurationSupplier) {
        this(jcaConnectionSupplier, imsConfigurationSupplier, ThreadContext.DEFAULT);
    }

    public M8ImsConnectorImpl(JCAConnectionSupplier jcaConnectionSupplier,
                              ImsConfigurationSupplier imsConfigurationSupplier,
                              ThreadContext threadContext) {
        Validate.notNull(jcaConnectionSupplier, "jcaConnectionSupplier can't be null");
        Validate.notNull(imsConfigurationSupplier, "imsConfigurationSupplier can't be null");
        Validate.notNull(threadContext, "threadContext can't be null");

        this.jcaConnectionSupplier = jcaConnectionSupplier;
        this.imsConfigurationSupplier = imsConfigurationSupplier;
        this.threadContext = threadContext;
    }

    @Override
    public M8ImsConnection connect() {
        final Connection connection;

        try {
            connection = jcaConnectionSupplier.getConnection();
        } catch (ResourceException e) {
            throw new BackendConnectivityException("Failed to acquire JCA connection", e);
        }

        return new M8ImsConnectionImpl(connection, imsConfigurationSupplier, threadContext);
    }
}
