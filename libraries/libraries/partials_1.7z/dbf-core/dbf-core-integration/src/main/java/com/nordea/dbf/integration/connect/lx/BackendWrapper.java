package com.nordea.dbf.integration.connect.lx;

import com.nordea.automapper.runtime.ReplyObject;
import com.nordea.automapper.runtime.RequestObject;
import com.nordea.serviceconsumer.BackendCaller;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;

import javax.resource.ResourceException;
import java.util.Properties;

/**
 * Interface for the Automapper Backend class wrapper
 *
 */
public interface BackendWrapper {

  void setConfigurationProvider(ConfigurationProvider configurationProvider);

  <T extends ReplyObject> void transmitAsync(Class<T> replyClass, RequestObject request,
                                             BackendCaller.Callback<T> callback, String destination,
                                             Properties properties) throws ResourceException;

}
