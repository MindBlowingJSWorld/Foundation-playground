package com.nordea.dbf.integration.connect.lx;

import com.nordea.automapper.runtime.ReplyObject;
import com.nordea.automapper.runtime.RequestObject;
import com.nordea.serviceconsumer.Backend;
import com.nordea.serviceconsumer.BackendCaller;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;

import javax.resource.ResourceException;
import java.util.Properties;

/**
 * Implementation using the standard Automapper Backend
 *
 */
public class DefaultBackendWrapper implements BackendWrapper {

  @Override
  public void setConfigurationProvider(ConfigurationProvider configurationProvider) {
    Backend.getBackendCaller().setConfigurationProvider(configurationProvider);
  }

  @Override
  public <T extends ReplyObject> void transmitAsync(Class<T> replyClass, RequestObject request, BackendCaller.Callback<T> callback, String destination, Properties properties) throws ResourceException {
    Backend.transmitAsync(replyClass, request, callback, destination, properties);
  }
}
