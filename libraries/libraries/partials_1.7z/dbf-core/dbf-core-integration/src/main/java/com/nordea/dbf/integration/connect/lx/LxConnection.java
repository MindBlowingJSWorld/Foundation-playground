package com.nordea.dbf.integration.connect.lx;

import com.nordea.automapper.runtime.ReplyObject;
import com.nordea.automapper.runtime.RequestObject;
import com.nordea.dbf.integration.connect.BackendConnection;

public interface LxConnection extends BackendConnection<RequestObject, ReplyObject> {
}
