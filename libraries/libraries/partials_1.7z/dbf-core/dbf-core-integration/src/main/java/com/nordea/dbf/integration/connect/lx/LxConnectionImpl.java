package com.nordea.dbf.integration.connect.lx;

import com.nordea.automapper.runtime.AutoMapperRecord;
import com.nordea.automapper.runtime.ReplyObject;
import com.nordea.automapper.runtime.RequestObject;
import com.nordea.dbf.api.model.ErrorDetails;
import com.nordea.dbf.concurrent.DeferredPromise;
import com.nordea.dbf.concurrent.Handover;
import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.BackendException;
import com.nordea.serviceconsumer.BackendCaller;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import org.apache.commons.lang.NotImplementedException;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import com.nordea.dbf.api.model.Error;

import javax.resource.ResourceException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Optional;
import java.util.Properties;

/**
 * Connection that wraps an asynchronous automapper backend call
 */
public class LxConnectionImpl implements LxConnection {

    private static final Logger LOGGER = LoggerFactory.getLogger(LxConnectionImpl.class);

    private final String destination;
    private final ConfigurationProvider configurationProvider;
    private final ThreadContext threadContext;
    private final BackendWrapper backendWrapper;

    public LxConnectionImpl(ConfigurationProvider configurationProvider, String destination, ThreadContext threadContext,
                            BackendWrapper backendWrapper) {
        Validate.notNull(configurationProvider, "The configurationProvider can't be null");
        Validate.isTrue(StringUtils.isNotEmpty(destination), "The destination can't be a null or empty");
        Validate.notNull(threadContext, "The threadContext can't be null");
        Validate.notNull(backendWrapper, "The backend wrapper can't be null");
        this.configurationProvider = configurationProvider;
        this.destination = destination;
        this.threadContext = threadContext;
        this.backendWrapper = backendWrapper;
        backendWrapper.setConfigurationProvider(configurationProvider);
    }

    protected <Request extends RequestObject, Response extends ReplyObject> Observable<Response> executeAsync(
            ServiceRequestContext serviceRequestContext, Request request, Class<Response> response) {

        final DeferredPromise<Response> promise = DeferredPromise.create();
        final Handover handover = threadContext.createHandover();

        request.setServiceContext(createServiceContext(serviceRequestContext));

        LOGGER.info("Executing AutoMapper call serviceName={}, operationName={}, transactionId={}, messageId={}, destination={}",
                request.getServiceName(), request.getOperationName(), request.getTransactionId(), request.getMessageId(), destination);

        try {
            backendWrapper.transmitAsync(response, request, new BackendCaller.Callback<Response>() {
                @Override
                public void responseFailed(Throwable throwable) {
                    handover.in(() -> {
                        LOGGER.info("AutoMapper call failed");
                        promise.fail(throwable);
                    });
                }

                @Override
                public void responseCompleted(Response response) {
                    handover.in(() -> {
                        LOGGER.info("Automapper call completed with a successful response? {}", response.isSuccessfulResponse());
                        if (!response.isSuccessfulResponse()) {
                            LOGGER.info("Automapper call error reply: {}", response.getErrorReply().toString());
                        }
                        promise.complete(response);
                    });
                }
            }, destination, new Properties());
        } catch (ResourceException e) {
            LOGGER.info("AutoMapper call serviceName={}, operationName={}, transactionId={}, messageId={}, destination={} {} threw exception {}",
                request.getServiceName(), request.getOperationName(), request.getTransactionId(), request.getMessageId(), destination, System.getProperty("line.separator"), e.getMessage());
            throw new BackendException(new Error().setError("backend_execution_exception").setErrorDescription("LX backend execution failed").setDetails(Arrays.asList(new ErrorDetails().setParam(e.getMessage()))));
        }

        return promise.toObservable();
    }

    @Override
    public <Request extends RequestObject, Response extends ReplyObject> Observable<Response> execute(Optional<ServiceRequestContext> context, Request request, Class<Response> response) {
        Validate.isTrue(context.isPresent(), "ServiceRequestContext can't be null");
        Validate.notNull(request, "Request can't be null");
        Validate.notNull(response, "Response type can't be null");
        return executeAsync(context.get(), request, response);
    }

    @Override
    public <Request extends RequestObject, Response extends ReplyObject> Observable<Response> execute(Optional<ServiceRequestContext> context, Request request, Response response) {
        throw new NotImplementedException("Method not available for LX connections.");
    }

    protected AutoMapperRecord.ServiceContext createServiceContext(ServiceRequestContext serviceRequestContext) {
        AutoMapperRecord.ServiceContext context = new AutoMapperRecord.ServiceContext();

        context.setTechnicalUserId(configurationProvider.getProperty("technicalUserId"));
        context.setClientType(configurationProvider.getProperty("clientType"));
        context.setTest(configurationProvider.getProperty("test"));
        context.setClientComponent(configurationProvider.getProperty("clientComponent"));
        context.setAccountingUnit(configurationProvider.getProperty("accountingUnit"));
        context.setOfficeMode(configurationProvider.getProperty("officeMode"));

        context.setApplicationId(serviceRequestContext.getApplicationId().orElse(StringUtils.EMPTY));
        context.setRequestDomain(serviceRequestContext.getCountry().get());
        context.setUserLocation(serviceRequestContext.getRemoteAddress());
        context.setClientTimeStamp(Instant.ofEpochMilli(serviceRequestContext.getTimeStamp()).toString());
        context.setAuthMethod(serviceRequestContext.getAuthenticationMethod().get());
        context.setChannelId(serviceRequestContext.getChannelId().get());
        context.setSessionId(serviceRequestContext.getUserId().get());
        context.setRequestId(serviceRequestContext.getRequestId().orElse(""));
        context.setUserId(serviceRequestContext.getUserId().get());
        return context;
    }


    @Override
    public void close() {
    }
}
