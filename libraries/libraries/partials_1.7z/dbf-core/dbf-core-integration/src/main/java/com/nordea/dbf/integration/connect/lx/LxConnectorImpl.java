package com.nordea.dbf.integration.connect.lx;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

/**
 * Connector for Automapper based LX connections
 *
 */
public class LxConnectorImpl implements LxConnector {

  private ConfigurationProvider configurationProvider;
  private String destination;
  private BackendWrapper backendWrapper;

  public LxConnectorImpl(ConfigurationProvider configurationProvider, String destination, BackendWrapper backendWrapper) {
    Validate.notNull(configurationProvider, "The configurationProvider can't be null");
    Validate.isTrue(StringUtils.isNotEmpty(destination), "The destination can't be a null or empty");
    this.configurationProvider = configurationProvider;
    this.destination = destination;
    this.backendWrapper = backendWrapper;
  }

  @Override
  public LxConnection connect() {
    return new LxConnectionImpl(configurationProvider, destination, ThreadContext.DEFAULT, backendWrapper);
  }
}
