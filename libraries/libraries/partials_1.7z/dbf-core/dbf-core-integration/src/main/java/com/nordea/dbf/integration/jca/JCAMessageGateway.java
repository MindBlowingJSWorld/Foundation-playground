package com.nordea.dbf.integration.jca;

import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.dbf.messaging.Message;
import com.nordea.dbf.messaging.MessageGateway;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import rx.Observable;

import javax.resource.cci.Record;

import static com.nordea.dbf.messaging.Observables.manage;

public class JCAMessageGateway implements MessageGateway<JCARequest, Record> {

    private static final Logger LOGGER = LoggerFactory.getLogger(JCAMessageGateway.class);

    private BackendConnector backendConnector;

    public JCAMessageGateway(BackendConnector backendConnector) {
        this.backendConnector = backendConnector;
    }

    @Override
    @SuppressWarnings("unchecked")
    public Observable<Message<Record>> deliver(final Message<JCARequest> message) {
        final BackendConnection connection = backendConnector.connect();

        final Observable observable = callBackend(connection, message).map(message::continuationWith);

        return manage(connection).on(observable);
    }

    private Observable callBackend(BackendConnection connection, Message<JCARequest> message) {
        return connection.execute(message.getServiceRequestContext(),
                message.getPayload().getRequest(), message.getPayload().getResponse());
    }
}
