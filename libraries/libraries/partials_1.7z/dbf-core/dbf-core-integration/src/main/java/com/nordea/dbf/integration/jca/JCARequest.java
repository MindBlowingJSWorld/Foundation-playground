package com.nordea.dbf.integration.jca;

import javax.resource.cci.Record;

public final class JCARequest {

    private final Record request;

    private final Class<? extends Record> response;

    private JCARequest(Record request,
                       Class<? extends Record> response) {
        this.request = request;
        this.response = response;
    }


    public Record getRequest() {
        return request;
    }

    public Class<? extends Record> getResponse() {
        return response;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {

        private Record request;

        private Class<? extends Record> responseType;


        public Builder request(Record request) {
            this.request = request;
            return this;
        }

        public Builder responseType(Class<? extends Record> responseType) {
            this.responseType = responseType;
            return this;
        }

        public JCARequest build() {
            return new JCARequest(request, responseType);
        }
    }

}
