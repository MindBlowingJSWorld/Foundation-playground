package com.nordea.dbf.integration.logging;

public interface InteractionLogger {

    void log(Object request, Object response);

}
