package com.nordea.dbf.integration.logging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.google.common.collect.ImmutableMap;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class JSONInteractionLogger implements InteractionLogger {

    private static final Logger LOGGER = LoggerFactory.getLogger(JSONInteractionLogger.class);

    private final MessageSink messageSink;

    private final ObjectMapper objectMapper;

    private final ObjectWriter objectWriter;

    public JSONInteractionLogger(MessageSink messageSink) {
        this(messageSink, new ObjectMapper());
    }

    public JSONInteractionLogger(MessageSink messageSink, ObjectMapper objectMapper) {
        Validate.notNull(messageSink, "messageSink can't be null");
        Validate.notNull(objectMapper, "objectMapper can't be null");

        this.messageSink = messageSink;
        this.objectMapper = objectMapper;
        this.objectWriter = objectMapper.writer().withDefaultPrettyPrinter();
    }

    @Override
    public void log(Object request, Object response) {
        final Map<String, Object> interaction = ImmutableMap.of(
                "request", request,
                "response", response
        );

        try {
            messageSink.dump(objectWriter.writeValueAsString(interaction));
        } catch (JsonProcessingException e) {
            LOGGER.warn("Failed to marshal request/response to JSON", e);
        }
    }
}
