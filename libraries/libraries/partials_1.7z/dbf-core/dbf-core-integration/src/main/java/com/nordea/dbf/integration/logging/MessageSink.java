package com.nordea.dbf.integration.logging;

public interface MessageSink {

    void dump(String message);

}
