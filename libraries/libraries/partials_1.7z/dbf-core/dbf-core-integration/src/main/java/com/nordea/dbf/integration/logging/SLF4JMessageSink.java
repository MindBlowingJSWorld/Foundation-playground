package com.nordea.dbf.integration.logging;

import org.apache.commons.lang.Validate;
import org.slf4j.Logger;

public class SLF4JMessageSink implements MessageSink {

    private final Logger logger;

    public SLF4JMessageSink(Logger logger) {
        Validate.notNull(logger, "logger can't be null");
        this.logger = logger;
    }

    @Override
    public void dump(String message) {
        Validate.notNull(message, "message can't be null");

        logger.info(message);
    }
}
