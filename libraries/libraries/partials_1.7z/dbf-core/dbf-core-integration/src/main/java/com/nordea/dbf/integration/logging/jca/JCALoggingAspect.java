package com.nordea.dbf.integration.logging.jca;

import com.nordea.dbf.integration.logging.InteractionLogger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;

import javax.resource.ResourceException;
import javax.resource.cci.Connection;
import javax.resource.cci.Interaction;
import javax.resource.cci.InteractionSpec;
import javax.resource.cci.Record;

@Aspect
public class JCALoggingAspect {

    public static final String CREATE_INTERACTION_SIGNATURE = "createInteraction()Ljavax/resource/cci/Interaction;";

    public static final String EXECUTE_SIGNATURE = "execute(Ljavax/resource/cci/InteractionSpec;Ljavax/resource/cci/Record;Ljavax/resource/cci/Record;)Z";

    @Autowired
    private InteractionLogger interactionLogger;

    @Around("execution(* com.nordea.serviceconsumer.providers.JCAConnectionProvider.getConnection(..))")
    public Object overrideConnection(ProceedingJoinPoint pjp) throws Throwable {
        final Connection targetConnection = (Connection) pjp.proceed();

        return Enhancer.create(Connection.class, (MethodInterceptor) (o, method, objects, methodProxy) -> {
            switch (methodProxy.getSignature().toString()) {
                case CREATE_INTERACTION_SIGNATURE:
                    return overrideInteraction(targetConnection);
            }

            return methodProxy.invoke(targetConnection, objects);
        });
    }

    private Object overrideInteraction(Connection targetConnection) throws ResourceException {
        final Interaction targetInteraction = targetConnection.createInteraction();

        return Enhancer.create(Interaction.class, (MethodInterceptor) (o, method, arguments, methodProxy) -> {
            switch (methodProxy.getSignature().toString()) {
                case EXECUTE_SIGNATURE:
                    final Record request = (Record) arguments[1];
                    final Record response = (Record) arguments[2];

                    try {
                        return targetInteraction.execute((InteractionSpec) arguments[0], request, response);
                    } finally {
                        interactionLogger.log(request, response);
                    }
            }

            return methodProxy.invoke(targetInteraction, arguments);
        });
    }
}
