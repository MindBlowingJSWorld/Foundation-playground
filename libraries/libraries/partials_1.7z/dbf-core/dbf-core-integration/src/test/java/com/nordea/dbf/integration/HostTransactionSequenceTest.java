package com.nordea.dbf.integration;

import com.nordea.dbf.integration.connect.ims.f9.HostTransactionSequence;
import org.junit.Test;

import java.net.UnknownHostException;

import static org.assertj.core.api.Assertions.assertThat;

public class HostTransactionSequenceTest {

    @Test
    public void transactionSequenceShouldYieldIncrementalNumbers() throws UnknownHostException {
        final HostTransactionSequence sequence = HostTransactionSequence.fromLocalHost();

        final int first = sequence.next();
        final int second = sequence.next();

        assertThat(first).isEqualTo(second - 1);
        assertThat(first).isNotEqualTo(0);
        assertThat(first).isPositive();
    }

}