package com.nordea.dbf.integration;

import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import com.nordea.sc.jca.BackendInteractionSpec;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ImsConfigurationTest {

    public static final String SERVER_IDENTIFIER = "seims";

    @Test
    public void configurationCanBeCreatedThroughBuilder() {
        final ImsConfiguration configuration = ImsConfiguration.builder()
                .debugLog(true)
                .sendTransactionId(true)
                .backendType(BackendInteractionSpec.BackendType.TYPE_IMS_SE)
                .serverIdentifier(SERVER_IDENTIFIER)
                .build();

        assertThat(configuration.getBackendType()).isEqualTo(BackendInteractionSpec.BackendType.TYPE_IMS_SE);
        assertThat(configuration.shouldSendTransactionId()).isTrue();
        assertThat(configuration.isDebugLoggingEnabled()).isTrue();
        assertThat(configuration.getServerIdentifier()).isEqualTo(SERVER_IDENTIFIER);
    }

}
