package com.nordea.dbf.integration.connect;

import com.nordea.dbf.concurrent.Handover;
import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.http.ServiceRequestContext;
import org.junit.Test;
import org.slf4j.MDC;
import rx.Observable;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.IntStream;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class PooledBackendConnectorTest {

    @Test
    public void shouldPoolConnections() throws Exception {
        try(Pool pool = pool(1)) {
            PooledBackendConnector<String,String> connector = pool.connector;

            String request = UUID.randomUUID().toString();
            String response = connector.execute(null, request, String.class)
                    .flatMap(msg -> {

                        assertEquals(1, connector.size.get());
                        assertEquals(0, connector.subscribers.size());

                        return connector.execute(null, msg + "!", String.class);
                    })
                    .toBlocking()
                    .single();

            assertEquals(request + "!", response);
        }
    }

    @Test
    public void shouldCloseIdleConnections() throws Exception {
        try(Pool pool = pool(1, 1, 1)) {
            PooledBackendConnector<String, String> connector = pool.connector;
            assertEquals("msg", connector.execute(null, "msg", String.class).toBlocking().single());
            assertEquals(1, connector.connections.size());

            SECONDS.sleep(3);

            assertEquals(0, connector.connections.size());
        }
    }

    @Test
    public void shouldNotGrowPoolOverCapacityOrStackOverflow() throws Exception {

        final int poolSize = 25;
        try(Pool pool = pool(poolSize, 10, 30)) {

            ExecutorService executor = new ThreadPoolExecutor(50, 50, 60, SECONDS, new LinkedBlockingQueue<>());
            PooledBackendConnector<String, String> connector = pool.connector;

            try {
                int depth = 100000;
                CountDownLatch latch = new CountDownLatch(depth);

                Collection<Callable<Void>> tasks = new ArrayList<>(depth);
                IntStream.range(0, depth).forEach(i -> {
                    Callable<Void> c = () -> {
                        connector.execute(null, String.valueOf(i), String.class)
                                .subscribe(s -> {
                                    latch.countDown();
                                    int size = connector.size.get();
                                    assertTrue(String.valueOf(size), connector.size.get() <= poolSize);
                                }, Throwable::printStackTrace);
                        return null;
                    };
                    tasks.add(c);
                });

                executor.invokeAll(tasks);
                assertTrue(latch.await(180, SECONDS));
            } finally {
                executor.shutdown();
            }
        }
    }

    @Test
    public void shouldPropagateThreadContext() throws Exception {
        BlockingQueue<String> queue = new LinkedBlockingQueue<>();
        try(Pool pool = pool(3)) {
            MDC.put("tid", "x");
            pool.connector.execute(null, "1", String.class).subscribe(queue::add);
            pool.connector.execute(null, "1", String.class).subscribe(queue::add);
            pool.connector.execute(null, "1", String.class).subscribe(queue::add);

            assertEquals("1x", queue.poll(5, SECONDS));
            assertEquals("1x", queue.poll(5, SECONDS));
            assertEquals("1x", queue.poll(5, SECONDS));
        } finally {
            MDC.clear();
        }
    }

    Pool pool(int size) {
        return pool(size, 5, 10);
    }
    Pool pool(int size, int maxIdle, int idleCheckInterval) {
        return new Pool(new PooledBackendConnector<>(this::connectionFactory, size, maxIdle, idleCheckInterval, WellBehavingMDCContext.INSTANCE));
    }

    private BackendConnection<String,String> connectionFactory() {
        return new BackendConnection<String,String>() {
            @Override
            @SuppressWarnings("unchecked")
            public <T extends String, R extends String> Observable<R> execute(Optional<ServiceRequestContext> context, T request, Class<R> response) {
                try {
                    TimeUnit.NANOSECONDS.sleep(new Random().nextInt(10));
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                String valueInThreadContext = MDC.get("tid");
                return Observable.just(valueInThreadContext == null ? (R) request : (R) (request + valueInThreadContext));
            }
            @Override
            public <T extends String, R extends String> Observable<R> execute(Optional<ServiceRequestContext> context, T request, R response) {
                throw new UnsupportedOperationException();
            }
            @Override
            public void close() {

            }
        };
    }

    static class Pool implements AutoCloseable {

        final PooledBackendConnector<String,String> connector;

        Pool(PooledBackendConnector<String, String> connector) {
            this.connector = connector;
        }
        @Override
        public void close() throws Exception {
            connector.destroy();
        }
    }

    enum WellBehavingMDCContext implements ThreadContext {

        INSTANCE;

        @Override
        public Handover createHandover() {

            Map<String, String> push = MDC.getCopyOfContextMap();
            AtomicReference<Map<String, String>> pop = new AtomicReference<>();

            return new Handover() {
                @Override
                public void commit() {
                    pop.set(MDC.getCopyOfContextMap());
                    if(push != null) {
                        MDC.setContextMap(push);
                    } else {
                        MDC.clear();
                    }
                }
                @Override
                public void close() {
                    if(pop.get() == null) {
                        MDC.clear();
                    } else {
                        MDC.setContextMap(pop.get());
                    }
                }
            };
        }
    }
}
