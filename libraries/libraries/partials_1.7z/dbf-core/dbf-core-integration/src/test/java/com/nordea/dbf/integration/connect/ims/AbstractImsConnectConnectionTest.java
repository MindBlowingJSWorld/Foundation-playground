package com.nordea.dbf.integration.connect.ims;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.sc.jca.BackendInteractionSpec;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import rx.Observable;

import javax.resource.cci.Connection;
import javax.resource.cci.Interaction;
import javax.resource.cci.InteractionSpec;
import javax.resource.cci.Record;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class AbstractImsConnectConnectionTest {

    private final Connection connection = mock(Connection.class);

    private final ImsConfigurationSupplier configurationSupplier = mock(ImsConfigurationSupplier.class);
    private final ThreadContext threadContext = ThreadContext.DEFAULT;

    @Test(expected = IllegalArgumentException.class)
    public void constructorShouldNotAcceptNullConnection() {
        newInstance(null, configurationSupplier, threadContext);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorShouldNotAcceptNullConfigurationSupplier() {
        newInstance(connection, null, threadContext);
    }

    @Test
    public void connectShouldExecuteCommandThroughConnection() throws Exception {
        final Record request = mock(Record.class);
        final Record response = mock(Record.class);

        when(configurationSupplier.get(eq(request), eq(response))).thenReturn(ImsConfiguration.builder()
                .debugLog(true)
                .sendTransactionId(false)
                .backendType(BackendInteractionSpec.BackendType.TYPE_IMS_SE)
                .serverIdentifier("seims")
                .build());

        final Interaction interaction = mock(Interaction.class);

        when(connection.createInteraction()).thenReturn(interaction);
        when(interaction.execute(any(InteractionSpec.class), any(Record.class), any(Record.class))).thenReturn(true);

        final Observable observable = newInstance(connection, configurationSupplier, threadContext).executeAsync(request, response, "XXX123");
        final ArgumentCaptor<BackendInteractionSpec> argumentCaptor = ArgumentCaptor.forClass(BackendInteractionSpec.class);

        verify(interaction).execute(argumentCaptor.capture(), eq(request), eq(response));

        final BackendInteractionSpec interactionSpec = argumentCaptor.getValue();

        assertThat(interactionSpec.getAsyncCallback()).isNotNull();
        assertThat(interactionSpec.getProperties().getProperty("debuglog")).isEqualTo("true");
        assertThat(interactionSpec.getProperties().get("sendtransactionid")).isEqualTo("false");

        interactionSpec.getAsyncCallback().responseCompleted();

        assertThat(observable.toBlocking().single()).isEqualTo(response);
    }

    protected AbstractImsConnectConnection newInstance(Connection connection, ImsConfigurationSupplier configurationSupplier, final ThreadContext threadContext) {
        return new AbstractImsConnectConnection(connection, configurationSupplier, threadContext) {
            @Override
            public Observable execute(Object o, Class response) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Observable execute(Optional context, Object o, Class response) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Observable execute(Optional optional, Object o, Object o2) {
                throw new UnsupportedOperationException();
            }
        };
    }

}
