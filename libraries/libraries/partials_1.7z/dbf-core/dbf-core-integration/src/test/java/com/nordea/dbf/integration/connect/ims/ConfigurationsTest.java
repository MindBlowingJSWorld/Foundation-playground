package com.nordea.dbf.integration.connect.ims;

import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.sc.jca.BackendInteractionSpec;
import org.junit.Test;

import javax.resource.cci.Record;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ConfigurationsTest {

    @Test
    public void singletonShouldNotAcceptNullConfiguration() {
        try {
            Configurations.singleton(null);
            fail("null configuration should be rejected");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void singletonShouldAlwaysReturnTheProvidedConfiguration() {
        final ImsConfiguration configuration = ImsConfiguration.builder()
                .serverIdentifier("seims")
                .backendType(BackendInteractionSpec.BackendType.TYPE_GENERIC)
                .build();
        final ImsConfigurationSupplier supplier = Configurations.singleton(configuration);

        assertThat(supplier.get(mock(Record.class), mock(Record.class))).isSameAs(configuration);
        assertThat(supplier.get(mock(Record.class), mock(Record.class))).isSameAs(configuration);
    }

    @Test
    public void transactionCodeCanBeResolvedFromM8RequestRecord() {
        final M8MessageHeaderRequestRecord request = mock(M8MessageHeaderRequestRecord.class);

        when(request.getTransactionCode()).thenReturn("1234");

        assertThat(Configurations.transactionCodeOf(request)).isEqualTo("1234");
    }

    @Test
    public void transactionCodeOfCanBeResolvedFromF9RequestRecord() {
        final F9MessageHeaderRequestRecord request = mock(F9MessageHeaderRequestRecord.class);

        when(request.getTransactionCode()).thenReturn("2345");

        assertThat(Configurations.transactionCodeOf(request)).isEqualTo("2345");
    }

    @Test
    public void transactionCodeCannotBeExtractedForInvalidRecord() {
        assertThatThrownBy(() -> Configurations.transactionCodeOf(null)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> Configurations.transactionCodeOf(mock(Record.class))).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void dynamicConfigurationCanBeBuilt() {
        final Record request1 = mock(Record.class);
        final Record request2 = mock(Record.class);
        final ImsConfiguration conf1 = mock(ImsConfiguration.class);
        final ImsConfiguration conf2 = mock(ImsConfiguration.class);

        final ImsConfigurationSupplier configuration = Configurations.builder()
                .when((req, res) -> req == request1).then(conf1)
                .when((req, res) -> req == request2).then(conf2)
                .build();

        assertThat(configuration.get(request1, mock(Record.class))).isSameAs(conf1);
        assertThat(configuration.get(request2, mock(Record.class))).isSameAs(conf2);
        assertThatThrownBy(() -> configuration.get(mock(Record.class), mock(Record.class))).isInstanceOf(IllegalArgumentException.class);
    }

}
