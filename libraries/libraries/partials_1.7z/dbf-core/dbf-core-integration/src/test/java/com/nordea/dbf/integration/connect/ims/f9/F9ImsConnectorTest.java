package com.nordea.dbf.integration.connect.ims.f9;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.dbf.integration.connect.ims.jca.JCAConnectionSupplier;
import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.F9MessageHeaderResponseRecord;
import org.junit.Test;

import javax.resource.ResourceException;
import javax.resource.cci.Connection;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

public class F9ImsConnectorTest {

    private final JCAConnectionSupplier jcaConnectionSupplier = mock(JCAConnectionSupplier.class);
    private final ImsConfigurationSupplier imsConfigurationSupplier = mock(ImsConfigurationSupplier.class);
    private final TransactionSequence transactionSequence = mock(TransactionSequence.class);
    private final ThreadContext threadContext = mock(ThreadContext.class);

    @Test
    public void constructorShouldNotAcceptInvalidParameters() {
        assertThatThrownBy(() -> new F9ImsConnectorImpl(null, imsConfigurationSupplier, transactionSequence, threadContext)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new F9ImsConnectorImpl(jcaConnectionSupplier, null, transactionSequence, threadContext)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new F9ImsConnectorImpl(jcaConnectionSupplier, imsConfigurationSupplier, null, threadContext)).isInstanceOf(IllegalArgumentException.class);
        assertThatThrownBy(() -> new F9ImsConnectorImpl(jcaConnectionSupplier, imsConfigurationSupplier, transactionSequence, null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void connectShouldReturnNewConnection() throws ResourceException {
        final F9ImsConnector connector = new F9ImsConnectorImpl(jcaConnectionSupplier, imsConfigurationSupplier, transactionSequence, threadContext);

        when(jcaConnectionSupplier.getConnection()).thenReturn(mock(Connection.class));

        final BackendConnection<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> connection = connector.connect();

        assertThat(connection).isNotNull();

        verify(jcaConnectionSupplier).getConnection();
    }

}
