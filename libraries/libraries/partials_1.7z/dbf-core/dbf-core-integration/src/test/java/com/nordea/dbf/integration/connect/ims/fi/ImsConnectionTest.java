package com.nordea.dbf.integration.connect.ims.fi;

import com.nordea.dbf.concurrent.MDCThreadContext;
import com.nordea.dbf.integration.connect.BackendConnectivityException;
import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import org.junit.Test;

import javax.resource.cci.Connection;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;

public class ImsConnectionTest {

    @Test
    public void shouldThrowExceptionOnInvalidReturnCode() throws Exception {
        try {
            ImsRecord record = record("V3300303");
            connection().sendErrorOnFailure(record, record).toBlocking().single();
            fail("Should throw exception on failed return code");
        } catch (ImsException e) {
            assertEquals("V3300303", e.getErrorCode());
        }
    }

    @Test
    public void shouldEmitRecordOnSuccess() {
        ImsRecord record = record("00000000");
        assertEquals(record, connection().sendErrorOnFailure(record, record).toBlocking().single());
    }

    @Test
    public void shouldEmitRecordOnValidReturnCode() {
        ImsRecord record = new ImsRecord(null, Base64.getDecoder().decode("UDIzMzAwMyAxMTJPUzAwMDAwMDAwMDAwPz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/PzE1MTEyNj" +
                "EzMDQzMzInboCAECAAAaAAAAAAAAAAMTIwMDM1MDAwMDkwOTcLMAs1MDEwMDAwKwsyMDE1MTExNwtLW1lUVFxUSUxJCzIzMDM5MzE3" +
                "OTELMQtLe3l0dHx0aWxpCzAzNDgLMQsxMjAwCysLMTIwMAs1MDEwMDAwKwswCw=="),
                true, StandardCharsets.ISO_8859_1);

        assertEquals(record, connection().sendErrorOnFailure(record, record).toBlocking().single());

        record = new ImsRecord(null, Base64.getDecoder().decode(
                "UDIzMDYyMCAxMjBPVDAwMDAwMDAwMDAwPz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/PzE1MTEyNjEzMDQzMzIAAAAAAAAAAA=="),
                true, StandardCharsets.ISO_8859_1);

        assertEquals(record, connection().sendErrorOnFailure(record, record).toBlocking().single());
    }

    @Test
    public void shouldEmitRecordOnVariableLengthReturnCode() {

        ImsRecord record = new ImsRecord(null, Base64.getDecoder().decode("UDIzMDkzNkkxMzZJQjAwMDAwMDAwMDAwPz8/Pz8/Pz8/" +
                "Pz8/Pz8/Pz8/Pz8/PzE2MDEyMjEzNTUxMjJ4AAAAYAAAAcAAAAMAAAAAMDAwMDAwMDALMDAxCzAwMDAwMDAwMDAxNTIyMDczMjILMD" +
                "AwMDAwMDAwMDE1MjIwNzMyMgsyOTALMjUwCzEwNDczNTAwMDE4MjY5CzEwNDczNTAwMDE4MjY5CzEyMzRyCzEyMzRyCw=="),
                true, StandardCharsets.ISO_8859_1);

        assertEquals(record, connection().sendErrorOnFailure(record, record).toBlocking().single());

    }

    @Test
    public void shouldEmitErrorOnInvalidReturnCode() {
        byte[] res = Base64.getDecoder().decode("UDIzMDYxNjAxNTJJVDAwMDAwMDAwMDAwPz8/Pz8/Pz8/Pz8/Pz8/Pz8/Pz8/PzE1MTEyNj" +
                "EzMDQzMzLf//z/I9K+AAtWMjMwNjEwNwswMAsxCzUwMDAwMCsLKws1MDAwMDArCzQwNDI2ODcLMjMwMzkzMTc5MQtQQVlWVklSVEFO" +
                "RU4gTUFUVEkLMDAwMDAwMDALKwswMDAwMDAwMAsrCysLKwsrCysLKwswMDAwMDALMDAwMDAwCzMwMAtFCzELTk9SREVBIEdPTEQLNz" +
                "Q4NjALRVVSSUJPUiAzCwswMQsrCwsxMDAwKwszMDALMTAwMDALKwsxCzEwMDArCysLKws1MzAwKwsxMAsL");
        ImsRecord record = new ImsRecord(null, res, true, StandardCharsets.ISO_8859_1);
        try {
            connection().sendErrorOnFailure(record, record).toBlocking().single();
            fail();
        } catch (ImsException ie) {
            assertEquals("V2306107", ie.getErrorCode());
        }
    }

    @Test(expected = BackendConnectivityException.class)
    public void shouldThrowExceptionOnMissingReturnCode() throws Exception {
        connection().sendErrorOnFailure(new ImsRecord(), new ImsRecord()).toBlocking().single();
    }

    static ImsRecord record(String rc) {
        ImsRecord record = new ImsRecord(null, null, false, Charset.forName("Cp1143"));
        ByteBuffer buffer = (ByteBuffer) ByteBuffer.allocate(67 + 16).position(67 + 8);
        if(rc != null) {
            buffer.put(rc.getBytes(Charset.forName("Cp1143")));
        }
        record.setBytes(buffer.array());
        return record;
    }

    static ImsConnection connection() {
        return new ImsConnector(
                () -> mock(Connection.class),
                (req,res) -> ImsConfiguration.builder().build(),
                new MDCThreadContext()
        ).connect();
    }
}
