package com.nordea.dbf.integration.connect.ims.m8;

import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.pn.service.records.M8MessageHeaderRequestRecord;
import com.nordea.pn.service.records.M8MessageHeaderResponseRecord;
import org.junit.Before;
import org.junit.Test;

import javax.resource.cci.Connection;
import javax.resource.cci.Interaction;
import java.util.Optional;

import static org.mockito.Mockito.*;

/**
 * Created by N453640 on 2015-06-05.
 */
public class M8ImsConnectionTest {

  private static Connection connection = mock(Connection.class);
  private static  ImsConfigurationSupplier configurationSupplier = mock(ImsConfigurationSupplier.class);
  private static  ThreadContext threadContext = mock(ThreadContext.class);
  private static ImsConfiguration imsConfiguration = mock(ImsConfiguration.class);
  private static Interaction interaction = mock(Interaction.class);

  M8ImsConnectionImpl target = null;

  @Before
  public void setUp() throws Exception{
    target = new M8ImsConnectionImpl(connection, configurationSupplier, threadContext);
    when(configurationSupplier.get(any(javax.resource.cci.Record.class), any(javax.resource.cci.Record.class))).thenReturn(imsConfiguration);
    when(connection.createInteraction()).thenReturn(interaction);
  }

  @Test
  public void shouldGetApplicationFromServiceContext(){
    // given
    M8MessageHeaderRequestRecord request = mock(M8MessageHeaderRequestRecord.class);
    M8MessageHeaderResponseRecord response = mock(M8MessageHeaderResponseRecord.class);
    ServiceRequestContext context = mock(ServiceRequestContext.class );
    when(context.getApplicationId()).thenReturn(Optional.of("APP-01"));
    when(request.getTransactionCode()).thenReturn("TC1");
    when(request.getMessageId()).thenReturn("MS1");
    when(context.getRequestId()).thenReturn(Optional.empty());
    when(context.getSessionId()).thenReturn(Optional.empty());
    when(context.getCountry()).thenReturn(Optional.empty());
    when(context.getLanguage()).thenReturn(Optional.empty());

    // when
    target.execute(Optional.of(context), request, response);

    // then
    verify(request).setApplicationId("APP-01");

  }
}
