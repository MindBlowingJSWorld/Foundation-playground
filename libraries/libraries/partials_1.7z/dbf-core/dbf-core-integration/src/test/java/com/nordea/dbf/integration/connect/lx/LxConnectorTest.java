package com.nordea.dbf.integration.connect.lx;

import com.nordea.automapper.runtime.ReplyObject;
import com.nordea.automapper.runtime.RequestObject;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import org.junit.Test;

import javax.resource.ResourceException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;

/**
 * Unit tests for the LX Connector using Automapper
 *
 */
public class LxConnectorTest {

  private String destination = "osb";
  private ConfigurationProvider configurationProvider = mock(ConfigurationProvider.class);
  private BackendWrapper backendWrapper = mock(BackendWrapper.class);

  @Test
  public void constructorShouldNotAcceptInvalidParameters() {
    assertThatThrownBy(() -> new LxConnectorImpl(null, destination, backendWrapper)).isInstanceOf(IllegalArgumentException.class);
    assertThatThrownBy(() -> new LxConnectorImpl(configurationProvider, null, backendWrapper)).isInstanceOf(IllegalArgumentException.class);
  }

  @Test
  public void connectShouldReturnNewConnection() throws ResourceException {
    // when
    final LxConnector connector = new LxConnectorImpl(configurationProvider, destination, backendWrapper);
    final BackendConnection<RequestObject, ReplyObject> connection = connector.connect();
    // then
    assertThat(connection).isNotNull();
  }


}
