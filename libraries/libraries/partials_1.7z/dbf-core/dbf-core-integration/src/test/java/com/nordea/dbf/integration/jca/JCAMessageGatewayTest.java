package com.nordea.dbf.integration.jca;

import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.dbf.messaging.Message;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;
import rx.Observable;

import javax.resource.cci.Record;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class JCAMessageGatewayTest {

    private final BackendConnector backendConnector = mock(BackendConnector.class);
    private final JCAMessageGateway gateway = new JCAMessageGateway(backendConnector);
    private final BackendConnection backendConnection = mock(BackendConnection.class);
    private final ServiceRequestContext requestContext = mock(ServiceRequestContext.class);

    @Before
    public void setup() throws Exception {
        when(backendConnector.connect()).thenReturn(backendConnection);
    }

    @Test
    public void successfulTransactionShouldRespondWithRecord() throws Exception {
        final Record requestRecord = mock(Record.class);
        final ExampleResponseRecord responseRecord = mock(ExampleResponseRecord.class);

        when(backendConnection.execute(eq(Optional.of(requestContext)), eq(requestRecord), eq(ExampleResponseRecord.class))).thenReturn(Observable.just(responseRecord));

        final Observable<Message<Record>> observable = gateway.deliver(Message.builder()
                .serviceRequestContext(requestContext)
                .payload(JCARequest.builder()
                        .request(requestRecord)
                        .responseType(ExampleResponseRecord.class)
                        .build())
                .build());

        assertThat(observable.toBlocking().single().getPayload()).isInstanceOf(ExampleResponseRecord.class);

        final InOrder inOrder = inOrder(backendConnection);

        inOrder.verify(backendConnection).execute(eq(Optional.of(requestContext)), eq(requestRecord), eq(ExampleResponseRecord.class));
        inOrder.verify(backendConnection).close();
    }

    public static class ExampleResponseRecord implements Record {

        @Override
        public String getRecordName() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setRecordName(String name) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void setRecordShortDescription(String description) {
            throw new UnsupportedOperationException();
        }

        @Override
        public String getRecordShortDescription() {
            throw new UnsupportedOperationException();
        }

        @Override
        public Object clone() throws CloneNotSupportedException {
            return super.clone();
        }
    }

}
