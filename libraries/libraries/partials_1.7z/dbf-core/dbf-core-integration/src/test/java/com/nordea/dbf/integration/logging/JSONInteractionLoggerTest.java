package com.nordea.dbf.integration.logging;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.mockito.ArgumentCaptor;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class JSONInteractionLoggerTest {

    private final MessageSink messageSink = mock(MessageSink.class);

    private final ObjectMapper objectMapper = new ObjectMapper();

    private final JSONInteractionLogger logger = new JSONInteractionLogger(messageSink, objectMapper);

    @Test(expected = IllegalArgumentException.class)
    public void messageSinkCannotBeNull() {
        new JSONInteractionLogger(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void objectMapperCannotBeNull() {
        new JSONInteractionLogger(messageSink, null);
    }

    @Test
    public void logShouldDumpJsonRepresentationOfRequestAndResponseInSink() throws Exception {
        logger.log("myRequest", "myResponse");

        final ArgumentCaptor<String> argumentCaptor = ArgumentCaptor.forClass(String.class);

        verify(messageSink).dump(argumentCaptor.capture());

        final String dumpedValue = argumentCaptor.getValue();

        final JsonNode node = objectMapper.readValue(dumpedValue, JsonNode.class);

        assertThat(node.get("request").asText()).isEqualTo("myRequest");
        assertThat(node.get("response").asText()).isEqualTo("myResponse");
    }

}