package com.nordea.dbf.integration.logging;

import org.junit.Test;
import org.slf4j.Logger;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class SLF4JMessageSinkTest {

    private final Logger logger = mock(Logger.class);
    private final SLF4JMessageSink messageSink = new SLF4JMessageSink(logger);

    @Test(expected = IllegalArgumentException.class)
    public void loggerCannotBeNull() {
        new SLF4JMessageSink(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void dumpShouldRejectNullMessage() {
        messageSink.dump(null);
    }

    @Test
    public void dumpShouldInfoLogMessage() {
        messageSink.dump("aValue");

        verify(logger).info(eq("aValue"));
    }

}