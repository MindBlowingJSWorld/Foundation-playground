package com.nordea.dbf.integration.logging.jca;

import com.nordea.dbf.integration.logging.InteractionLogger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.resource.cci.Connection;
import javax.resource.cci.Interaction;
import javax.resource.cci.InteractionSpec;
import javax.resource.cci.Record;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class JCALoggingAspectTest {

    @Mock
    private InteractionLogger interactionLogger;

    @Mock
    private ProceedingJoinPoint pjp;

    @InjectMocks
    private final JCALoggingAspect aspect = new JCALoggingAspect();

    @Test
    public void connectionShouldBeOverriddenAndInteractionLogged() throws Throwable {
        final Connection targetConnection = mock(Connection.class);
        final Interaction targetInteraction = mock(Interaction.class);

        when(pjp.proceed()).thenReturn(targetConnection);
        when(targetConnection.createInteraction()).thenReturn(targetInteraction);

        final Connection connection = (Connection) aspect.overrideConnection(pjp);
        final Interaction interaction = connection.createInteraction();

        final InteractionSpec spec = mock(InteractionSpec.class);
        final Record request = mock(Record.class, "request");
        final Record response = mock(Record.class, "response");

        interaction.execute(spec, request, response);

        final InOrder inOrder = inOrder(interactionLogger, targetInteraction);

        inOrder.verify(targetInteraction).execute(eq(spec), eq(request), eq(response));
        inOrder.verify(interactionLogger).log(eq(request), eq(response));
    }

}