package com.nordea.dbf.model.http;

/**
 * Created by N453640 on 2015-05-26.
 */
public class DBFClientServiceRequestContext {

  private String applicationId;

  private String sessionId;

  private String requestId;

  private String country;

  private String channelId;

  private long timeStamp = -1L;

  /**
   * Supplying default constructor and setters for all fields to make model compliant with all serializers
   */
  public DBFClientServiceRequestContext(){}

  public DBFClientServiceRequestContext(String applicationId, String sessionId,
      String requestId,
      String country,
      String channelId, long timeStamp) {
    this.applicationId = applicationId;
    this.sessionId = sessionId;
    this.requestId = requestId;
    this.country = country;
    this.channelId = channelId;
    this.timeStamp = timeStamp;
  }

  public String getSessionId() {
    return sessionId;
  }

  public String getRequestId() {
    return requestId;
  }

  public String getCountry() {
    return country;
  }

  public String getChannelId() {
    return channelId;
  }

  public String getApplicationId() {
    return applicationId;
  }

  public long getTimeStamp() {
    return timeStamp;
  }

  public void setTimeStamp(long timeStamp) {
    this.timeStamp = timeStamp;
  }

  public void setApplicationId(String applicationId) {
    this.applicationId = applicationId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public void setRequestId(String requestId) {
    this.requestId = requestId;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public void setChannelId(String channelId) {
    this.channelId = channelId;
  }

  @Override public String toString() {
    return "DBFClientServiceRequestContext{" +
        "applicationId='" + applicationId + '\'' +
        ", sessionId='" + sessionId + '\'' +
        ", requestId='" + requestId + '\'' +
        ", country='" + country + '\'' +
        ", channelId='" + channelId + '\'' +
        ", timeStamp=" + timeStamp +
        '}';
  }
}
