package com.nordea.dbf.model.http;

/**
 * Created by N453640 on 2015-05-28.
 */
public class DBFClientServiceRequestContextBuilder {

  private  String applicationId;

  private  String sessionId;

  private  String requestId;

  private  String country;

  private  String channelId;

  private long timeStamp;

  public DBFClientServiceRequestContextBuilder applicationId(String applicationId){
    this.applicationId = applicationId;
    return this;
  }

  public DBFClientServiceRequestContextBuilder sessionId(String sessionId){
    this.sessionId = sessionId;
    return this;
  }

  public DBFClientServiceRequestContextBuilder requestId(String requestId){
    this.requestId = requestId;
    return this;
  }

  public DBFClientServiceRequestContextBuilder country(String country){
    this.country = country;
    return this;
  }

  public DBFClientServiceRequestContextBuilder channelId(String channelId){
    this.channelId = channelId;
    return this;
  }

  public DBFClientServiceRequestContextBuilder timeStamp(long timeStamp){
    this.timeStamp = timeStamp;
    return this;
  }

  public DBFClientServiceRequestContext build() {
    return new DBFClientServiceRequestContext( applicationId,  sessionId,
         requestId,
         country,
         channelId, timeStamp);
  }
}
