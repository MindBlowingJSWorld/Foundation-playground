package com.nordea.dbf.model.http;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by N453640 on 2015-05-28.
 */
public class DBFClientServiceRequestContextBuilderTest {

  @Test
  public void builderShouldCreateFullContext(){
    // given
    DBFClientServiceRequestContextBuilder builder = new DBFClientServiceRequestContextBuilder();

    // when
    DBFClientServiceRequestContext context = builder.applicationId("APP1").channelId("WEB").country("SE").requestId("REQ123").sessionId(
        "SES123").timeStamp(12352312l).build();

    // then
    assertThat(context).isNotNull();
    assertThat(context.getApplicationId()).isEqualTo("APP1");
    assertThat(context.getRequestId()).isEqualTo("REQ123");
    assertThat(context.getSessionId()).isEqualTo("SES123");
    assertThat(context.getChannelId()).isEqualTo("WEB");
    assertThat(context.getCountry()).isEqualTo("SE");
    assertThat(context.getTimeStamp()).isEqualTo(12352312l);
  }

}
