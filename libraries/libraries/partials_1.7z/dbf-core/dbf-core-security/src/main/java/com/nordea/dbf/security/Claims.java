package com.nordea.dbf.security;

import org.apache.commons.lang.Validate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.provider.token.AccessTokenConverter;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * Claims separate from the authentication class to enable method injection in rest controllers.
 */
@SuppressWarnings("unchecked")
public class Claims {

    public static final String COUNTRY_LONG_FORMAT = "country";
    public static final String ISSUED_AT = "iat";
    public static final String NOT_BEFORE = "nbf";
    public static final String AUDIENCE = AccessTokenConverter.AUD;
    public static final String SUB = "sub";
    public static final String UID = "uid";
    public static final String SSN = "ssn";
    public static final String COUNTRY = "c";
    public static final String SCOPE = AccessTokenConverter.SCOPE;
    public static final String GRANTS = "grants";
    public static final String ISSUER = "iss";
    public static final String AUTHENTICATION_LEVEL = "al";
    public static final String AUTHENTICATION_METHOD = "am";
    public static final String CHANNEL = "ch";
    public static final String SEGMENT = "sgm";
    public static final String SESSION_ID = "sid";

    public static final String SEGMENT_CORPORATE = "corporate";
    public static final String SEGMENT_HOUSEHOLD = "household";

    private final String clientId;
    private final String subject;
    private final String uid;
    private final String ssn;
    private final String country;
    private final String method;
    private final String level;
    private final String issuer;
    private final String channel;
    private final String segment;
    private final Collection<? extends GrantedAuthority> scopes;
    private final Map<String, ?> additionalClaims;
    private final String sessionId;
    private List<ResourceGrant> grants;
    private Long agreementNumber;

    public Claims(String clientId, String subject, String uid, String ssn, String issuer, Collection<String> scopes, String country, String method,
                  String level, String channel, Object grants, String sessionId, String segment, Map<String, ?> additionalClaims) {
        Validate.notEmpty(subject, "principal can't be null or empty");
        Validate.notEmpty(issuer, "issuer can't be null or empty");
        Validate.notEmpty(uid, "uid can't be null or empty");
        Validate.notEmpty(scopes, "scopes can't be null or empty");
        Validate.notEmpty(country, "country can't be null or empty");
        Validate.notEmpty(method, "method can't be null or empty");
        Validate.notEmpty(level, "level can't be null or empty");
        Validate.notEmpty(channel, "channel can't be null or empty");
        Validate.notEmpty(sessionId, "sessionId can't be null or empty");

        this.clientId = clientId;
        this.issuer = issuer;
        this.uid = uid;
        this.ssn = ssn;

        parseGrants(grants);
        this.subject = subject;
        this.scopes = AuthorityUtils.commaSeparatedStringToAuthorityList(StringUtils
                .collectionToCommaDelimitedString(scopes));
        this.country = country;
        this.method = method;
        this.level = level;
        this.channel = channel;
        this.segment = segment;
        this.sessionId = sessionId;
        this.additionalClaims = additionalClaims != null ? additionalClaims : Collections.emptyMap();
    }

    public Map<String, ?> getAdditionalClaims() {
        return additionalClaims;
    }

    public Optional<Long> getAgreementNumber() {
        return Optional.ofNullable(agreementNumber);
    }

    public String getChannel() {
        return channel;
    }

    public String getCountry() {
        return country;
    }

    public List<ResourceGrant> getGrants() {
        return grants;
    }

    public String getIssuer() {
        return issuer;
    }

    public String getLevel() {
        return level;
    }

    public String getMethod() {
        return method;
    }

    public String getSubject() {
        return subject;
    }

    public Collection<? extends GrantedAuthority> getScopes() {
        return scopes;
    }

    public String getUid() {
        return uid;
    }

    public String getSsn() {
        return ssn;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getSegment() {
        return segment;
    }

    public String getClientId() {
        return clientId;
    }

    public boolean isSegmentCorporate(){
        return SEGMENT_CORPORATE.equals(segment);
    }

    public boolean isSegmentHousehold(){
        return SEGMENT_HOUSEHOLD.equals(segment);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Claims claims = (Claims) o;

        if (!clientId.equals(claims.clientId)) return false;
        if (!subject.equals(claims.subject)) return false;
        if (!uid.equals(claims.uid)) return false;
        if (ssn != null ? !ssn.equals(claims.ssn) : claims.ssn != null) return false;
        if (!country.equals(claims.country)) return false;
        if (!method.equals(claims.method)) return false;
        if (!level.equals(claims.level)) return false;
        if (!issuer.equals(claims.issuer)) return false;
        if (!channel.equals(claims.channel)) return false;
        if (segment != null ? !segment.equals(claims.segment) : claims.segment != null) return false;
        if (!scopes.equals(claims.scopes)) return false;
        if (additionalClaims != null ? !additionalClaims.equals(claims.additionalClaims) : claims.additionalClaims != null)
            return false;
        if (!sessionId.equals(claims.sessionId)) return false;
        if (grants != null ? !grants.equals(claims.grants) : claims.grants != null) return false;
        return agreementNumber != null ? agreementNumber.equals(claims.agreementNumber) : claims.agreementNumber == null;

    }

    @Override
    public int hashCode() {
        int result = clientId.hashCode();
        result = 31 * result + subject.hashCode();
        result = 31 * result + uid.hashCode();
        result = 31 * result + (ssn != null ? ssn.hashCode() : 0);
        result = 31 * result + country.hashCode();
        result = 31 * result + method.hashCode();
        result = 31 * result + level.hashCode();
        result = 31 * result + issuer.hashCode();
        result = 31 * result + channel.hashCode();
        result = 31 * result + (segment != null ? segment.hashCode() : 0);
        result = 31 * result + scopes.hashCode();
        result = 31 * result + (additionalClaims != null ? additionalClaims.hashCode() : 0);
        result = 31 * result + sessionId.hashCode();
        result = 31 * result + (grants != null ? grants.hashCode() : 0);
        result = 31 * result + (agreementNumber != null ? agreementNumber.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Claims{" +
                "clientId='" + clientId + '\'' +
                ", subject='" + subject + '\'' +
                ", uid='" + uid + '\'' +
                ", ssn='" + ssn + '\'' +
                ", country='" + country + '\'' +
                ", method='" + method + '\'' +
                ", level='" + level + '\'' +
                ", issuer='" + issuer + '\'' +
                ", channel='" + channel + '\'' +
                ", segment='" + segment + '\'' +
                ", scopes=" + scopes +
                ", additionalClaims=" + additionalClaims +
                ", sessionId='" + sessionId + '\'' +
                ", grants=" + grants +
                ", agreementNumber=" + agreementNumber +
                '}';
    }

    private void parseGrants(Object grants) {
        this.grants = new ArrayList<>();
        Long agreementNumber = null;
        if (grants != null && grants instanceof Map) {

            final Map<String, Object> grantMap = (Map<String, Object>) grants;
            for (final Map.Entry<String, Object> entry : grantMap.entrySet()) {
                final String resourceName = entry.getKey();
                Object resource = entry.getValue();
                //todo: do we need agreement still inside grant as it is now also own easily accessible property?
                if ("agreement".equals(resourceName)) {
                    agreementNumber = ((Number) resource).longValue();
                    resource = agreementNumber;
                }
                this.grants.add(new ResourceGrant(resourceName, resource));
            }
        }
        this.agreementNumber = agreementNumber;
    }
}
