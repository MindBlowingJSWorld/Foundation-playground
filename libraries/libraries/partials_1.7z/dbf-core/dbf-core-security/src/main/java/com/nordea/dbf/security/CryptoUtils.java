package com.nordea.dbf.security;

import com.google.common.primitives.Bytes;
import org.apache.commons.codec.binary.Base64;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

public class CryptoUtils {
    private static final byte[] publicKeyHeader = "-----BEGIN PUBLIC KEY-----".getBytes(StandardCharsets.UTF_8);
    private static final byte[] publicKeyTrailer = "-----END PUBLIC KEY-----".getBytes(StandardCharsets.UTF_8);
    private static final byte[] certificateHeader = "-----BEGIN CERTIFICATE-----".getBytes(StandardCharsets.UTF_8);
    private static final byte[] certificateTrailer = "-----END CERTIFICATE-----".getBytes(StandardCharsets.UTF_8);

    public static RSAPublicKey loadRSAPublicKey(byte[] bytes) throws NoSuchAlgorithmException, InvalidKeySpecException, CertificateException {
        RSAPublicKey result = null;
        int start = Bytes.indexOf(bytes, publicKeyHeader);
        if(start > -1) {
            start += publicKeyHeader.length;
            int end = Bytes.indexOf(bytes, publicKeyTrailer);
            if(end > -1 && end > start) {
                byte[] base64Bytes = new byte[end - start];
                System.arraycopy(bytes, start, base64Bytes, 0, base64Bytes.length);
                byte[] keyBytes = Base64.decodeBase64(base64Bytes);
                result = (RSAPublicKey)KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(keyBytes));
            }

        } else {
            start = Bytes.indexOf(bytes, certificateHeader);
            if (start > -1) {
                start += certificateHeader.length;
                int end = Bytes.indexOf(bytes, certificateTrailer);
                if(end > -1 && end > start) {
                    byte[] base64Bytes = new byte[end - start];
                    System.arraycopy(bytes, start, base64Bytes, 0, base64Bytes.length);
                    byte[] keyBytes = Base64.decodeBase64(base64Bytes);
                    result = (RSAPublicKey) CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(keyBytes)).getPublicKey();
                }
            }
        }

        if(result == null) {
            if(start < 0) {
                throw new SecurityConfigurationException("Incorrect format (header not found)");
            } else {
                throw new SecurityConfigurationException("Incorrect format (trailer not found)");
            }
        }

        return result;
    }
}
