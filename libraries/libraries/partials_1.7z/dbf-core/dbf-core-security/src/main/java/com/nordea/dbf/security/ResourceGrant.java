package com.nordea.dbf.security;

import org.apache.commons.lang.Validate;
import org.springframework.security.core.GrantedAuthority;

public final class ResourceGrant<T> implements GrantedAuthority {

    private final String name;

    private final T resource;

    public ResourceGrant(String name, T resource) {
        Validate.notEmpty(name, "name can't be null or empty");
        Validate.notNull(resource, "resorce can't be null or empty");

        this.name = name;
        this.resource = resource;
    }

    public String getName() {
        return name;
    }

    public Object getResource() {
        return resource;
    }

    @Override
    public String getAuthority() {
        return name + ":" + resource;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ResourceGrant that = (ResourceGrant) o;

        if (!name.equals(that.name)) return false;
        if (!resource.equals(that.resource)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + resource.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "ResourceGrant{" +
                "name='" + name + '\'' +
                ", resource=" + resource +
                '}';
    }
}
