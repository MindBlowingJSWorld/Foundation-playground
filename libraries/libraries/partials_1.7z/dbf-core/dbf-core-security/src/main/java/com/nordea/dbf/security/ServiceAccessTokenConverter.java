package com.nordea.dbf.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.InvalidSignatureException;
import org.springframework.security.jwt.crypto.sign.RsaVerifier;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.InvalidGrantException;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;

import java.security.KeyPair;
import java.security.SignatureException;
import java.security.interfaces.RSAPublicKey;
import java.util.*;

import static com.nordea.dbf.security.Claims.*;

@SuppressWarnings("unchecked")
public class ServiceAccessTokenConverter extends JwtAccessTokenConverter {

    public static final String COUNTRY_LONG_FORMAT = Claims.COUNTRY_LONG_FORMAT;
    private static final Logger log = LoggerFactory.getLogger(ServiceAccessTokenConverter.class);
    private final ObjectMapper objectMapper;
    private Map<String, RSAPublicKey> verifierKeys;
    private String ninaaClientId;

    /**
     * Constructor to create token converter for token deserialization and verification support
     *
     * @param verifierKeys  Issuer specific public keys to verify token signature mapped by the issuer name.
     * @param ninaaClientId Optional NINAA client id - if set, the jwt will be checked and if the ninaaClientId is equal to aud, "osl" is added to aud list.
     */
    public ServiceAccessTokenConverter(Map<String, RSAPublicKey> verifierKeys, String ninaaClientId) {
        Validate.notNull(verifierKeys, "verifierKeyLocator can't be null");
        this.objectMapper = new ObjectMapper();
        this.verifierKeys = verifierKeys;
        this.ninaaClientId = ninaaClientId;
    }

    /**
     * Constructor to create converter with token creation and signing support.
     *
     * @param issuer  Token issuer. There should be only one single issuer in the dbf for the tokens.
     * @param keyPair Key pair holding Token issuer private key to sign tokens and public key to verify the token validity.
     * @deprecated Token creation functionality is moved to dbf-authentication-common.
     */
    @Deprecated
    public ServiceAccessTokenConverter(String issuer, KeyPair keyPair) {
        this.setKeyPair(keyPair);
        RSAPublicKey rsaVerifierKey = (RSAPublicKey) keyPair.getPublic();
        this.verifierKeys = ImmutableMap.of(issuer, rsaVerifierKey);
        //Token serialization made with JwtAccessTokenConverter default implementation
        this.objectMapper = null;
        //Composite token converter is used to serialize token. We want this to be the composite.
        setAccessTokenConverter(this);
    }

    @Override
    public OAuth2Authentication extractAuthentication(Map<String, ?> parameters) {

        //Ensure map is mutable to remove all but possible extra claims that are appended to service authentication.
        Map<String, Object> mutableClaims = new HashMap<>(parameters);

        ServiceAuthentication serviceAuthentication;
        Set<String> scope;
        try {
            Validate.notNull(mutableClaims, "token properties can't be null");
            scope = new LinkedHashSet<>(mutableClaims.containsKey(SCOPE) ? (Collection<String>) mutableClaims.remove(SCOPE)
                    : Collections.emptySet());

            Set<String> resourceIds = new LinkedHashSet<>();
            Object aud = mutableClaims.remove(AUD); //Now handle that aud can be both a list of strings and a single string
            if (aud != null) {
                if (aud instanceof Collection<?>) {
                    resourceIds.addAll((Collection<String>) aud);
                } else {
                    String audstring = (String) aud;
                    resourceIds.add(audstring);
                    if (ninaaClientId != null) {
                        if (ninaaClientId.equals(audstring)) { //If ninaa clientid has been set check if its equal to aud in the ticket
                            resourceIds.add("osl"); //osl is required to call the service
                        }
                    }
                }
            }
            String clientId = (String) mutableClaims.remove(CLIENT_ID);
            //Old tokens do not have sub field and customer id is stored in the client_id param.
            String principal = mutableClaims.containsKey(SUB) ? (String) mutableClaims.remove(SUB) : clientId;
            String country = mutableClaims.containsKey(COUNTRY) ? (String) mutableClaims.remove(COUNTRY) : (String) mutableClaims.remove(COUNTRY_LONG_FORMAT);
            serviceAuthentication =
                    new ServiceAuthentication(
                            principal,
                            (String) mutableClaims.remove(UID),
                            (String) mutableClaims.remove(SSN),
                            (String) mutableClaims.remove(ISSUER),
                            scope,
                            country,
                            (String) mutableClaims.remove(AUTHENTICATION_METHOD),
                            (String) mutableClaims.remove(AUTHENTICATION_LEVEL),
                            (String) mutableClaims.remove(CHANNEL),
                            mutableClaims.remove(GRANTS),
                            (String) mutableClaims.remove(SESSION_ID),
                            (String) mutableClaims.remove(SEGMENT),
                            mutableClaims,
                            clientId
                    );


            OAuth2Request request = new OAuth2Request(new HashMap<>(), clientId, serviceAuthentication.getAuthorities(), true, scope, resourceIds, null, null,
                    null);
            return new OAuth2Authentication(request, serviceAuthentication);
        } catch (IllegalArgumentException validationFailure) {
            log.info("Invalid token content: " + parameters, validationFailure);
            throw new InvalidTokenException("Invalid token content.", validationFailure);
        }
    }

    /**
     * @deprecated Access token creation moved to dbf-authentication-common, because creating tokens should not be visible for
     * all the foundation services.
     */
    @Deprecated
    @Override
    public Map<String, ?> convertAccessToken(OAuth2AccessToken token, OAuth2Authentication authentication) {
        Map<String, Object> response = new LinkedHashMap<>();
        OAuth2Request clientToken = authentication.getOAuth2Request();

        if (!authentication.isClientOnly()) {
            Authentication userAuthentication = authentication.getUserAuthentication();
            response.put(SUB, authentication.getName());
            if (userAuthentication instanceof ServiceAuthentication) {
                ServiceAuthentication serviceAuthentication = (ServiceAuthentication) userAuthentication;
                response.put(UID, serviceAuthentication.getUid());
                response.put(SSN, serviceAuthentication.getSsn());
                response.put(COUNTRY, serviceAuthentication.getCountry());
                response.put(ISSUER, serviceAuthentication.getIssuer());
                response.put(GRANTS, serviceAuthentication.getGrantsAsMap());
                response.put(AUTHENTICATION_LEVEL, serviceAuthentication.getLevel());
                response.put(AUTHENTICATION_METHOD, serviceAuthentication.getMethod());
                response.put(CHANNEL, serviceAuthentication.getChannel());
                response.put(SEGMENT, serviceAuthentication.getSegment());
                response.put(SESSION_ID, serviceAuthentication.getSessionId());
                response.putAll(serviceAuthentication.getAdditionalClaims());
            } else {
                log.info("Invalid user authentication: {}", userAuthentication);
                throw new InvalidTokenException("Invalid user authentication.");
            }

            if (authentication.getAuthorities() != null && !authentication.getAuthorities().isEmpty()) {
                response.put(SCOPE, AuthorityUtils.authorityListToSet(authentication.getAuthorities()));
            }
        } else {
            throw new InvalidGrantException("Client credentials grant not supported.");
        }

        if (token.getAdditionalInformation().containsKey(JTI)) {
            response.put(JTI, token.getAdditionalInformation().get(JTI));
            token.getAdditionalInformation().remove(JTI);
        }

        if (token.getExpiration() != null) {
            response.put(EXP, token.getExpiration().getTime() / 1000L);
        }

        if (clientToken.getResourceIds() != null && !clientToken.getResourceIds().isEmpty()) {
            response.put(AUDIENCE, clientToken.getResourceIds());
        }

        response.put(CLIENT_ID, clientToken.getClientId());

        response.putAll(token.getAdditionalInformation());
        long iat = issuedAt();
        response.put(ISSUED_AT, iat);
        response.put(NOT_BEFORE, iat);

        DefaultOAuth2AccessToken dToken = (DefaultOAuth2AccessToken) token;

        dToken.setScope(null);
        return response;
    }

    @Override
    public OAuth2AccessToken extractAccessToken(String value, Map<String, ?> map) {
        DefaultOAuth2AccessToken token = new DefaultOAuth2AccessToken(value);
        Map<String, Object> info = new HashMap<>(map);
        info.remove(EXP);
        info.remove(AUDIENCE);
        info.remove(CLIENT_ID);
        info.remove(SCOPE);
        long expirationMillis = (Long) map.get(EXP) * 1000L;
        token.setExpiration(new Date(expirationMillis));
        Collection<String> scope = (Collection<String>) map.get(SCOPE);
        if (scope != null) {
            token.setScope(new HashSet<>(scope));
        }
        token.setAdditionalInformation(info);
        return token;
    }

    @Override
    public Map<String, Object> decode(String token) {
        final Map properties;

        try {
            final String claims = JwtHelper.decode(token).getClaims();
            properties = objectMapper.readValue(claims.getBytes("UTF-8"), Map.class);
        } catch (Exception e) {
            log.info("Token claims deserialization failed. Invalid token: {}", token);
            throw new InvalidTokenException("Token is not valid json", e);
        }

        //Make sure expiration time is always long value later on.
        if (properties.containsKey(EXP) && properties.get(EXP) instanceof Integer) {
            Integer intValue = (Integer) properties.get(EXP);
            properties.put(EXP, new Long(intValue));
        }

        final String issuer = (String) properties.get("iss");
        if (StringUtils.isBlank(issuer)) {
            throw new InvalidTokenException("Token contains no issuer (\"iss\" field)");
        }

        RSAPublicKey verifierKey = verifierKeys.get(issuer);
        if (verifierKey == null) {
            log.info("Invalid issuer found in the jwt: {}", issuer);
            throw new InvalidTokenException("Token issued by unknown issuer");
        }

        try {
            JwtHelper.decodeAndVerify(token, new RsaVerifier(verifierKey));
        } catch (InvalidSignatureException e) {
            log.info("Token contains invalid signature. Token is: {}", token);
            throw new InvalidTokenException("Token contains invalid signature", e);
        } catch (RuntimeException e) {
            if (e.getCause() instanceof SignatureException) {
                throw new InvalidTokenException("Provided token contains an invalid signature", e);
            }
            throw new InvalidTokenException("Token could not be validated due to an unexpected exception", e);
        }
        return properties;
    }

    private long issuedAt() {
        return System.currentTimeMillis() / 1000L;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        //Own verifier handling implemented so overwriting this to avoid unnecessary warnings in the log..
    }
}
