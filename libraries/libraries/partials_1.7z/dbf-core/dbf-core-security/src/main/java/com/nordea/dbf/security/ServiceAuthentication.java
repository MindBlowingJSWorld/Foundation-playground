package com.nordea.dbf.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@SuppressWarnings("unchecked")
public class ServiceAuthentication implements Authentication {

    //Claims in separate delegate object to enable spring mvc argument resolving for the claims.
    private final Claims claims;
    private boolean authenticated;

    public ServiceAuthentication(String principal, String uid, String ssn, String issuer, Collection<String> scopes, String country, String method,
                                 String level, String channel, Object grants, String sessionId, String segment, Map<String, ?> additionalClaims, String clientId) {
        this.claims = new Claims(clientId,principal,uid,ssn, issuer, scopes, country, method, level, channel, grants, sessionId, segment, additionalClaims);
        this.authenticated = true;
    }

    public Claims getClaims() {
        return claims;
    }

    public String getClientId() {
        return claims.getClientId();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return claims.getScopes();
    }

    public Collection<? extends ResourceGrant> getGrants() {
        return claims.getGrants();
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public Object getDetails() {
        return claims.getAdditionalClaims();
    }

    public Map<String, ?> getAdditionalClaims() {
        return claims.getAdditionalClaims();
    }

    @Override
    public String getPrincipal() {
        return claims.getSubject();
    }

    @Override
    public boolean isAuthenticated() {
        return authenticated;
    }

    @Override
    public void setAuthenticated(boolean authenticated) throws IllegalArgumentException {
        this.authenticated = authenticated;
    }

    @Override
    public String getName() {
        return claims.getSubject();
    }

    public String getChannel() {
        return claims.getChannel();
    }

    public String getCountry() {
        return claims.getCountry();
    }

    public String getIssuer() {
        return claims.getIssuer();
    }

    public String getLevel() {
        return claims.getLevel();
    }

    public String getMethod() {
        return claims.getMethod();
    }

    public Map<String, Object> getGrantsAsMap() {
        return claims.getGrants().stream().collect(Collectors.toMap(ResourceGrant::getName, ResourceGrant::getResource));
    }

    public Optional<Long> getAgreementNumber() {
        return claims.getAgreementNumber();
    }

    public String getUid() {
        return claims.getUid();
    }

    public String getSsn() {
        return claims.getSsn();
    }

    public String getSessionId() {
        return claims.getSessionId();
    }

    public String getSegment() {
        return claims.getSegment();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ServiceAuthentication that = (ServiceAuthentication) o;

        return authenticated == that.authenticated && claims.equals(that.claims);

    }

    @Override
    public int hashCode() {
        int result = claims.hashCode();
        result = 31 * result + (authenticated ? 1 : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ServiceAuthentication{" +
                "authenticated=" + authenticated +
                ", claims=" + claims +
                '}';
    }
}
