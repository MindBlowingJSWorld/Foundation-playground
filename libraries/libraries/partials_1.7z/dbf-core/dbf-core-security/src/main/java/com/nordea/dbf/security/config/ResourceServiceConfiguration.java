package com.nordea.dbf.security.config;

import com.nordea.dbf.util.PropertyConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfiguration;

import java.util.Arrays;

@Configuration
public class ResourceServiceConfiguration extends ResourceServerConfiguration {
    private static final Logger LOG = LoggerFactory.getLogger(ServiceSecurityConfiguration.class);

    @Autowired
    private Environment environment;

    @Autowired(required = false)
    private ServiceHttpSecurityConfigurer serviceHttpSecurityConfigurer;

    public static final String[] getAnonymousPaths(Environment environment) {
        // Merge the anonymous paths (if any exists) with the restricted ones.
        String anonymous = environment.getProperty("dbf.security.anonymous.paths", "");
        if (anonymous.isEmpty() ) {
            anonymous = environment.getProperty("dbf.security.unrestricted.paths", "");
        } else {
            anonymous += "|" + environment.getProperty("dbf.security.unrestricted.paths", "");
        }
        final String[] anonymousPaths = PropertyConverter.splitPropertyOnPipe(anonymous);
        LOG.info("Permit unauthenticated access to paths " + Arrays.toString(anonymousPaths) + ".");
        return anonymousPaths;
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        // need to ignore unrestricted paths in web security also to avoid token parsing for unauthenticated paths.
        final String[] anonAntMatchers = getAnonymousPaths(environment);

        web.ignoring().antMatchers(anonAntMatchers);

        web.ignoring().antMatchers(HttpMethod.OPTIONS, "/**");

        //apply service specific web security configurations if available.
        if (serviceHttpSecurityConfigurer != null) {
            serviceHttpSecurityConfigurer.configure(web);
        }
    }
}
