package com.nordea.dbf.security.config;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;

/**
 * Allows service specific configuration of resource security constraints. HttpSecurity configuration can be used to configure
 * token based authorization constraints and WebSecurity to configure generic spring security constraints.
 * Notice that if token parsing needs to be skipped for some paths then web security configuration is needed. Otherwise
 * spring-oauth will try to parse token before http security constraints take place.
 */
public interface ServiceHttpSecurityConfigurer {
    void configure(HttpSecurity http) throws Exception;

    default void configure(WebSecurity web) throws Exception {
    }

}
