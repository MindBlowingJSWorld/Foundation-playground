package com.nordea.dbf.security.config;

import com.nordea.dbf.audit.config.AuditConfiguration;
import com.nordea.dbf.security.CryptoUtils;
import com.nordea.dbf.security.SecurityConfigurationException;
import com.nordea.dbf.security.ServiceAccessTokenConverter;
import com.nordea.dbf.security.spring.*;
import com.nordea.dbf.security.spring.servicecontext.AuthenticationTokenAppender;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.interfaces.RSAPublicKey;
import java.util.*;

import static com.nordea.dbf.security.config.ResourceServiceConfiguration.getAnonymousPaths;
import static org.apache.commons.lang.StringUtils.isBlank;

@Configuration
@Import(ResourceServiceConfiguration.class)
public class ServiceSecurityConfiguration extends ResourceServerConfigurerAdapter {
    private static final Logger LOG = LoggerFactory.getLogger(ServiceSecurityConfiguration.class);

    @Autowired
    private Environment environment;

    @Autowired(required = false)
    private ServiceHttpSecurityConfigurer serviceHttpSecurityConfigurer;

    //will be available only if auditing is enabled with @EnableAuditing
    @Autowired(required = false)
    private ServiceAuthenticationEventHandler serviceAuthenticationEventHandler;

    @Autowired(required = false)
    private AuthenticationFailureAuditLogger authenticationFailureAuditLogger;

    @Bean
    WebMvcConfigurerAdapter securityArgumentConfigurer() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
                argumentResolvers.add(new PrincipalHandlerMethodArgumentResolver());
                argumentResolvers.add(new GrantHandlerMethodArgumentResolver());
                argumentResolvers.add(new TokenFieldMethodArgumentResolver());
                argumentResolvers.add(new ClaimsMethodArgumentResolver());
                argumentResolvers.add(new UidHandlerMethodArgumentResolver());
                argumentResolvers.add(new CountryHandlerMethodArgumentResolver());
                argumentResolvers.add(new SsnHandlerMethodArgumentResolver());
                argumentResolvers.add(new CidHandlerMethodArgumentResolver());
            }
        };
    }

    @Override
    public void configure(ResourceServerSecurityConfigurer resourceServerSecurityConfigurer) throws Exception {

        final ResourceTokenService tokenServices = new ResourceTokenService(new JwtTokenStore(serviceAccessTokenConverter()) );

        resourceServerSecurityConfigurer
                .tokenServices(tokenServices)
                .resourceId("osl") //todo: change to dbf when all the services have been updated to support also dbf resource id.
                .stateless(true);

        if (serviceAuthenticationEventHandler != null) {
            resourceServerSecurityConfigurer
                    .eventPublisher(serviceAuthenticationEventHandler)
                    .accessDeniedHandler(serviceAuthenticationEventHandler);
        }
    }

    /**
     * This function checks if the certificate file contains an iss= section in the pem file content.
     * If it does, the value after iss= is returned. This is then used as the issuer instead of the filename.
     * Used for NINAA jwts, which have a iss which does map well to a filename (https://ninaa-dev.oneadr.net)
     *
     * @param filecontent content in which iss= should be found
     * @return an optional that if populated contains the parsed iss= value
     */
    private Optional<String> getOverridePrettyName(byte[] filecontent) {
        String content = new String(filecontent, StandardCharsets.UTF_8);
        String[] split = content.split("\n");
        if (split.length > 0) {
            if (split[0].startsWith("iss=")) {
                return Optional.of(split[0].substring("iss=".length()));
            }
        }
        return Optional.empty();
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        final String[] anonAntMatchers = getAnonymousPaths(environment);

        // Setup permit all access for dbf.security.anonymous.paths paths and enforce security for everything else
        http.authorizeRequests()
                .antMatchers(anonAntMatchers).permitAll();

        //Configure service level security here before requiring fully authenticated for all other paths.
        if (serviceHttpSecurityConfigurer != null) {
            serviceHttpSecurityConfigurer.configure(http);
        }

        http.authorizeRequests()
                .anyRequest().fullyAuthenticated()
                .and()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

    }

    @ConditionalOnBean(AuditConfiguration.class)
    @Bean
    ServiceAuthenticationEventHandler serviceAuthenticationEventHandler() {
        return new ServiceAuthenticationEventHandler(authenticationFailureAuditLogger());
    }

    @ConditionalOnBean(AuditConfiguration.class)
    @Bean
    AuthenticationFailureAuditLogger authenticationFailureAuditLogger() {
        return new AuthenticationFailureAuditLogger();
    }

    @Bean
    AuthenticationTokenAppender authenticationTokenAppender() {
        return new AuthenticationTokenAppender();
    }

    @Bean
    ServiceAccessTokenConverter serviceAccessTokenConverter(){
        final String paths = environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*");
        if (isBlank(paths)) {
            throw new BeanCreationException("Property 'dbf.security.verfierkey.paths' is blank.");
        }

        // Build public key map
        Map<String, RSAPublicKey> verifierKeys = new HashMap<>();

        for (String resourcePath : paths.split(";")) {
            File filePath = null;
            try {
                if (resourcePath.startsWith("classpath:")) {
                    final PathMatchingResourcePatternResolver pathResolver = new PathMatchingResourcePatternResolver(ServiceSecurityConfiguration.class.getClassLoader());
                    final Resource[] resources = pathResolver.getResources(resourcePath);
                    for (Resource resource : resources) {
                        String prettyName = resource.getFilename().replaceFirst("\\.(?:pem|crt)", "").replaceFirst("_(v\\d+)$", "@$1");
                        byte[] filecontent = IOUtils.toByteArray(resource.getInputStream());
                        Optional<String> overridePrettyName = getOverridePrettyName(filecontent);
                        String key = overridePrettyName.orElse(prettyName);
                        verifierKeys.put(key, CryptoUtils.loadRSAPublicKey(filecontent));
                        LOG.debug("Loaded accepted public key {} from {}", key, resource.getFilename());
                    }

                } else {
                    if (resourcePath.startsWith("file://")) {
                        filePath = new File(resourcePath.substring(7));
                    } else {
                        filePath = new File(resourcePath);
                    }
                    // TODO: Look into using the PathMatchingResourcePatternResolver
                    if (filePath.exists()) {
                        if (filePath.isDirectory() && filePath.listFiles() != null) {
                            for (File file : filePath.listFiles()) {
                                if (file.getName().endsWith("pem") || file.getName().endsWith("crt")) {
                                    try {
                                        String prettyName = file.getName().replaceFirst("\\.(?:pem|crt)", "").replaceFirst("_(v\\d+)$", "@$1");
                                        byte[] filecontent = Files.readAllBytes(file.toPath());
                                        Optional<String> overridePrettyName = getOverridePrettyName(filecontent);
                                        String key = overridePrettyName.orElse(prettyName);
                                        verifierKeys.put(key, CryptoUtils.loadRSAPublicKey(filecontent));
                                        LOG.debug("Loaded accepted public key {} from {}", key, file.getName());
                                    } catch (Exception ex) {
                                        LOG.warn("Could not load public key '" + file.getName() + "' from path " + resourcePath, ex);
                                    }
                                }
                            }

                        } else {
                            String prettyName = filePath.getName().replaceFirst("\\.(?:pem|crt)", "").replaceFirst("_(v\\d+)$", "@$1");
                            byte[] filecontent = Files.readAllBytes(filePath.toPath());
                            Optional<String> overridePrettyName = getOverridePrettyName(filecontent);
                            String key = overridePrettyName.orElse(prettyName);
                            verifierKeys.put(key, CryptoUtils.loadRSAPublicKey(filecontent));
                            LOG.debug("Loaded accepted public key {} from {}", key, filePath.getName());
                        }

                    } else {
                        LOG.warn("Failed to find key in path '" + resourcePath + "'");
                    }
                }
            } catch (Exception ex) {
                if (filePath != null) {
                    LOG.warn("Could not load public key '" + filePath.getName() + "' from path " + resourcePath, ex);
                } else {
                    LOG.warn("Could not load public key '" + resourcePath + "'", ex);
                }
            }
        }

        if (verifierKeys.size() == 0) {
            throw new SecurityConfigurationException("Failed to load any keys");
        }

        String ninaaClientId = environment.getProperty("dbf.security.allowed.ninaa.client_id");
        return new ServiceAccessTokenConverter(Collections.unmodifiableMap(verifierKeys), ninaaClientId);
    }
}
