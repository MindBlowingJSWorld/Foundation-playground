package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.annotation.Grant;
import org.springframework.core.MethodParameter;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;

import java.lang.annotation.Annotation;
import java.util.Optional;

public abstract class AbstractHandlerMethodArgumentResolver implements HandlerMethodArgumentResolver {

    protected final Optional<Grant> grantOf(final MethodParameter methodParameter) {
        for (final Annotation annotation : methodParameter.getParameterAnnotations()) {

            final Grant grant = AnnotationUtils.getAnnotation(annotation,Grant.class);
//            final Grant grant = AnnotationUtils.findAnnotation(annotation.annotationType(), Grant.class);
            if (grant != null) {
                return Optional.of(grant);
            }
        }
        return Optional.empty();
    }

//    protected final Optional<Grant> grantOf(final MethodParameter methodParameter) {
//        return Arrays.asList(methodParameter.getParameterAnnotations())
//                .stream()
//                .filter(a-> Grant.class.isAssignableFrom(a.getClass()))
//                .findFirst()
//                .map(a -> (Grant) a);
//    }
}
