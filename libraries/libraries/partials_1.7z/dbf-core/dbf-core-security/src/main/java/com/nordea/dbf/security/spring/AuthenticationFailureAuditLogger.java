package com.nordea.dbf.security.spring;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.AuditEvent;
import com.nordea.dbf.audit.AuditEventDispatcher;
import com.nordea.dbf.audit.Severity;
import com.nordea.dbf.http.HttpRequestDescriber;
import com.nordea.dbf.metadata.ApplicationMetaData;
import com.nordea.dbf.model.http.DBFClientServiceRequestContext;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.Optional;

public class AuthenticationFailureAuditLogger {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationFailureAuditLogger.class);

    @Autowired
    private AuditEventDispatcher auditEventDispatcher;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private HttpRequestDescriber httpRequestDescriber;

    @Autowired
    private ApplicationMetaData applicationMetaData;

    private InetAddress hostAddress;

    public void auditLogAuthenticationFailure(Exception exception) {

        final HttpServletRequest request = RequestContextHolder.getRequestAttributes() != null ? ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest() : null;

        if (request == null) {
            LOGGER.warn("Failed authentication (no request in context). exception: {} ", exception);
            return;
        }

        final String authorizationBearer = request.getHeader("Authorization");

        if (StringUtils.isEmpty(authorizationBearer)) {
            auditLogAuthenticationFailure(exception, "No Authorization token provided in request", request);
            return;
        }

        if (!authorizationBearer.startsWith("Bearer ")) {
            auditLogAuthenticationFailure(exception, "Invalid Authorization in request (expected Bearer <1>.<2>.<3>", request);
            return;
        }

        final Map token;

        try {
            token = objectMapper.readValue(JwtHelper.decode(authorizationBearer.substring(7)).getClaims(), Map.class);
        } catch (Exception e) {
            auditLogAuthenticationFailure(exception, "Authorization token not readable from HTTP request", request);
            return;
        }

        final Optional<DBFClientServiceRequestContext> context = Optional.ofNullable(request.getHeader("X-DBF-ServiceRequestContext")).map(str -> {
            try {
                return objectMapper.readValue(str, DBFClientServiceRequestContext.class);
            } catch (Exception e) {
                auditLogAuthenticationFailure(exception, "DBF client service request context not readable from HTTP request", request);
                return null;
            }
        });

        final String requestId = context.map(DBFClientServiceRequestContext::getRequestId).orElse(null);
        final String sessionId = token.containsKey("sid") ? (String) token.get("sid") : context.map(DBFClientServiceRequestContext::getSessionId).orElse(null);

        final AuditEvent auditEvent = auditEventDispatcher.getAuditLogEventFactory().createEventBuilder()
                .applicationId(context.map(DBFClientServiceRequestContext::getApplicationId).orElse(null))
                .auditCategory(AuditCategory.SECURITY)
                .channel(context.map(DBFClientServiceRequestContext::getChannelId).orElse(null))
                .message(String.format("Authorization of request failed: request=%s, exception=%s, token=%s", httpRequestDescriber.describe(request), exception, token))
                .clientAction(request.getMethod() + " " + request.getPathInfo())
                .serviceEndPoint(request.getRequestURI())
                .userId(resolveUserId(token))
                .timestamp(new DateTime(context.map(ctx -> ctx.getTimeStamp() == -1L ? System.currentTimeMillis() : ctx.getTimeStamp()).orElse(System.currentTimeMillis())))
                .requestId(requestId)
                .sessionId(sessionId)
                .serverName(hostAddress.toString())
                .serviceId(applicationMetaData.getArtifactId() + "-" + applicationMetaData.getVersion())
                .severity(Severity.ERROR)
                .userLocation(request.getRemoteAddr())
                .build();

        auditEventDispatcher.audit(auditEvent);

        LOGGER.info("Authorization of session={}, request={} failed (audit logged): {}", sessionId, requestId, exception);
    }

    @PostConstruct
    public void setup() throws UnknownHostException {
        this.hostAddress = InetAddress.getLocalHost();
    }

    private String resolveUserId(Map claims) {
        return (String) (claims.containsKey("sub") && !"n/a".equals(claims.get("sub")) ? claims.get("sub") :
                claims.containsKey("uid") ? claims.get("uid") : claims.get("client_id"));
    }

    // Audit all events not linked to a Token or ServiceRequestContext
    public void auditLogAuthenticationFailure(Exception ex, HttpServletRequest request) {

    }

    // Audit all events not linked to a Token or ServiceRequestContext with a message
    public void auditLogAuthenticationFailure(Exception exception, String message, HttpServletRequest request) {
        LOGGER.warn(message + ": {}", httpRequestDescriber.describe(request));

        // Try to gather details if any, given a partial complete header.
        final String authorizationBearerString = request.getHeader("Authorization");
        Map token = null;

        try {
            if (! StringUtils.isEmpty(authorizationBearerString)) {
                token = objectMapper.readValue(JwtHelper.decode(authorizationBearerString.substring(7)).getClaims(), Map.class);
            }
        } catch (Exception e) {
            token = null;
        }
        final String serviceRequestContextString = request.getHeader("X-DBF-ServiceRequestContext");
        DBFClientServiceRequestContext serviceRequestContext = null;

        try {
            if (! StringUtils.isEmpty(serviceRequestContextString)) {
                serviceRequestContext = objectMapper.readValue(serviceRequestContextString, DBFClientServiceRequestContext.class);
            }
        } catch (Exception e) {
            serviceRequestContext = null;
        }

        String requestId = null;
        String sessionId = null;
        String applicationId = null;
        String channelId = null;
        String userId = null;
        DateTime timestamp = new DateTime(System.currentTimeMillis());

        // Derive any information available
        if (serviceRequestContext != null) {
            requestId = serviceRequestContext.getRequestId();
            sessionId = serviceRequestContext.getSessionId();
            applicationId = serviceRequestContext.getApplicationId();
            if (serviceRequestContext.getTimeStamp() != -1L) {
                timestamp = new DateTime(serviceRequestContext.getTimeStamp());
            }
        }

        if (token != null) {
            sessionId = token.containsKey("sid") ? (String) token.get("sid") : sessionId;
            channelId = token.containsKey("c") ? (String) token.get("c") : null;
            userId = resolveUserId(token);
        }

        final AuditEvent auditEvent = auditEventDispatcher.getAuditLogEventFactory().createEventBuilder()
                .applicationId(applicationId == null ? "ROSME" : applicationId)
                .auditCategory(AuditCategory.SECURITY)
                .channel(channelId)
                .message(String.format(message + ": {}", httpRequestDescriber.describe(request), exception, token))
                .clientAction(request.getMethod() + " " + request.getPathInfo())
                .serviceEndPoint(request.getRequestURI())
                .userId(userId)
                .timestamp(timestamp)
                .requestId(requestId)
                .sessionId(sessionId)
                .serverName(hostAddress.toString())
                .serviceId(applicationMetaData.getArtifactId() + "-" + applicationMetaData.getVersion())
                .severity(Severity.ERROR)
                .userLocation(request.getRemoteAddr())
                .build();

        auditEventDispatcher.audit(auditEvent);

        LOGGER.info("Authorization of session={}, request={} failed (audit logged): {}", sessionId, requestId, exception);
    }
}
