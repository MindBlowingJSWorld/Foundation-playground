package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.annotation.Cid;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import static com.nordea.dbf.security.spring.ServiceSecurityContext.getServiceAuthentication;

public class CidHandlerMethodArgumentResolver extends AbstractHandlerMethodArgumentResolver {

    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        return methodParameter.getParameterAnnotation(Cid.class) != null;
    }

    @Override
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer, NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {
        return getServiceAuthentication().getAdditionalClaims().get(Cid.ATRRIBUTE_NAME);
    }
}
