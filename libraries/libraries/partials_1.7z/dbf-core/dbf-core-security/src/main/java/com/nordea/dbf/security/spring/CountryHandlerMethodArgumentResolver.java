package com.nordea.dbf.security.spring;

import com.google.common.collect.ImmutableSet;
import com.nordea.dbf.security.annotation.Country;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import static com.nordea.dbf.security.spring.ServiceSecurityContext.getServiceAuthentication;

public class CountryHandlerMethodArgumentResolver extends AbstractHandlerMethodArgumentResolver {

    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        return methodParameter.getParameterAnnotation(Country.class) != null;
    }

    @Override
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer, NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {
        String country;
        try {
            country = getServiceAuthentication().getCountry();
        } catch (SecurityException e) {
            country = nativeWebRequest.getParameter("country");
        }
        if (country == null) {
            throw new SecurityException("Country is required");
        }
        if (!ImmutableSet.of("NO", "SE", "FI", "DK").contains(country)) {
            throw new SecurityException("Country not valid: " + country);
        }

        return country;
    }
}
