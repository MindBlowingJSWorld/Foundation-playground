package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.ResourceGrant;
import com.nordea.dbf.security.ServiceAuthentication;
import com.nordea.dbf.security.annotation.Grant;
import org.springframework.core.MethodParameter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import static com.nordea.dbf.security.spring.ServiceSecurityContext.getServiceAuthentication;

public class GrantHandlerMethodArgumentResolver extends AbstractHandlerMethodArgumentResolver {

    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        return grantOf(methodParameter).isPresent();
    }

    @Override
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer, NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {
        final Grant grant = grantOf(methodParameter).get();
        final ServiceAuthentication authentication = getServiceAuthentication();

        for (final GrantedAuthority grantedAuthority : authentication.getGrants()) {
                final ResourceGrant resourceGrant = (ResourceGrant) grantedAuthority;
                if (resourceGrant.getName().equals(grant.value())) {
                    return resourceGrant.getResource();
                }
        }

        throw new SecurityException("No grant available in authentication");
    }
}
