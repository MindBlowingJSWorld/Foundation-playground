package com.nordea.dbf.security.spring;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;

/**
 * Token service implementation for the OAuth2 Resource servers to build the Spring security authentication
 * object from the access token.
 */
public class ResourceTokenService implements ResourceServerTokenServices {

    private TokenStore tokenStore;

    public ResourceTokenService(TokenStore tokenStore) {
        this.tokenStore = tokenStore;
    }

    public OAuth2AccessToken readAccessToken(String accessToken) {
        return tokenStore.readAccessToken(accessToken);
    }

    @Override
    public OAuth2Authentication loadAuthentication(String accessTokenValue) throws AuthenticationException,
            InvalidTokenException {
        OAuth2AccessToken accessToken = tokenStore.readAccessToken(accessTokenValue); // tokenStore is null?
        if (accessToken == null) {
            throw new InvalidTokenException("Invalid access token.");
        } else if (accessToken.isExpired()) {
            tokenStore.removeAccessToken(accessToken);
            throw new InvalidTokenException("Access token expired.");
        }

        return tokenStore.readAuthentication(accessToken);
    }
}