package com.nordea.dbf.security.spring;

import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.provider.error.OAuth2AuthenticationEntryPoint;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by K306010 on 2016-02-16.
 */
public class ServiceAuthenticationEntryPoint extends OAuth2AuthenticationEntryPoint {

    private AuthenticationFailureAuditLogger authenticationFailureAuditLogger;

    public ServiceAuthenticationEntryPoint(AuthenticationFailureAuditLogger authenticationFailureAuditLogger) {
        this.authenticationFailureAuditLogger = authenticationFailureAuditLogger;
    }

    @Override
    public void commence(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, AuthenticationException e) throws IOException, ServletException {
        if (authenticationFailureAuditLogger != null) {
            if(e instanceof InsufficientAuthenticationException) {
                authenticationFailureAuditLogger.auditLogAuthenticationFailure(e);
            }
        }
        this.doHandle(httpServletRequest, httpServletResponse, e);
    }
}
