package com.nordea.dbf.security.spring;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;

public class ServiceAuthenticationEventHandler extends OAuth2AccessDeniedHandler implements AuthenticationEventPublisher  {

    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceAuthenticationEventHandler.class);

    private AuthenticationFailureAuditLogger authenticationFailureAuditLogger;

    @Autowired
    public ServiceAuthenticationEventHandler(AuthenticationFailureAuditLogger authenticationFailureAuditLogger) {
        this.authenticationFailureAuditLogger = authenticationFailureAuditLogger;
    }

    @Override
    public void publishAuthenticationSuccess(Authentication authentication) {
        LOGGER.debug("Token authentication successfull: {}.", authentication);
    }

    @Override
    public void publishAuthenticationFailure(AuthenticationException exception, Authentication authentication) {
        LOGGER.debug("Token authentication {}\nfailed to\n{}.", authentication, exception);
    }

    @Override
    protected ResponseEntity<OAuth2Exception> enhanceResponse(ResponseEntity<OAuth2Exception> result, Exception authException) {
        OAuth2Exception exception = result.getBody();
        authenticationFailureAuditLogger.auditLogAuthenticationFailure(exception);
        return result;
    }
}
