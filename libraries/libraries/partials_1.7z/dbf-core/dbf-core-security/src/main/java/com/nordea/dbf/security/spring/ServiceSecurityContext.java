package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.ServiceAuthentication;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

public class ServiceSecurityContext {

    private ServiceSecurityContext() {
    }

    public static ServiceAuthentication getServiceAuthentication() {
        OAuth2Authentication oAuth2Authentication = getOauth2Authentiation();
        if (oAuth2Authentication.getUserAuthentication() instanceof ServiceAuthentication) {
            return (ServiceAuthentication) oAuth2Authentication.getUserAuthentication();
        } else {
            throw new SecurityException("Invalid user authentication in security context");
        }
    }

    public static OAuth2Authentication getOauth2Authentiation() {
        final SecurityContext securityContext = SecurityContextHolder.getContext();

        if (securityContext == null) {
            throw new SecurityException("No configured security context");
        }

        final Authentication authentication = securityContext.getAuthentication();

        if (authentication == null) {
            throw new SecurityException("No authentication in security context");
        }
        if ((authentication instanceof OAuth2Authentication) && authentication.isAuthenticated()) {
            return (OAuth2Authentication) authentication;
        } else {
            throw new SecurityException("Invalid authentication in security context");
        }
    }
}
