package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.ServiceAuthentication;
import com.nordea.dbf.security.annotation.AuthenticationLevel;
import com.nordea.dbf.security.annotation.AuthenticationMethod;
import org.apache.commons.lang.Validate;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import java.lang.annotation.Annotation;
import java.util.Optional;

import static com.nordea.dbf.security.spring.ServiceSecurityContext.getServiceAuthentication;

public class TokenFieldMethodArgumentResolver extends AbstractHandlerMethodArgumentResolver {

    @Override
    public boolean supportsParameter(MethodParameter methodParameter) {
        Validate.notNull(methodParameter, "methodParameter can't be null");
        return annotationOf(methodParameter).isPresent();
    }

    @Override
    @SuppressWarnings("unchecked")
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer modelAndViewContainer, NativeWebRequest nativeWebRequest, WebDataBinderFactory webDataBinderFactory) throws Exception {

        ServiceAuthentication serviceAuthentication;
        try {
            serviceAuthentication = getServiceAuthentication();
        } catch (SecurityException e) {
            return null;
        }

        final Optional<Annotation> annotationOptional = annotationOf(methodParameter);

        if (!annotationOptional.isPresent()) {
            throw new IllegalArgumentException("No supported annotation found on parameter");
        }

        final Annotation annotation = annotationOptional.get();

        if (annotation instanceof AuthenticationLevel) {
            return serviceAuthentication.getLevel();
        }

        if (annotation instanceof AuthenticationMethod) {
            return serviceAuthentication.getMethod();
        }

        throw new UnsupportedOperationException("Unsupported annotation");
    }

    private Optional<Annotation> annotationOf(MethodParameter parameter) {
        for (final Annotation annotation : parameter.getParameterAnnotations()) {
            if (annotation instanceof AuthenticationMethod) {
                return Optional.of(annotation);
            }

            if (annotation instanceof AuthenticationLevel) {
                return Optional.of(annotation);
            }
        }

        return Optional.empty();
    }

}

