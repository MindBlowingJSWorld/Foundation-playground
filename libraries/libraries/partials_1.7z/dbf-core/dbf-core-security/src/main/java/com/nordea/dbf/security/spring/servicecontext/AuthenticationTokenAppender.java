package com.nordea.dbf.security.spring.servicecontext;

import com.nordea.dbf.http.ServiceRequestContextBuilder;
import com.nordea.dbf.http.contextappender.ServiceRequestContextAppender;
import com.nordea.dbf.security.ServiceAuthentication;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;

import javax.servlet.http.HttpServletRequest;


@Order(Ordered.LOWEST_PRECEDENCE)
public class AuthenticationTokenAppender implements ServiceRequestContextAppender {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationTokenAppender.class);

    @Override
    public void append(HttpServletRequest request, ServiceRequestContextBuilder builder) {

        Authentication currentAuthentication = SecurityContextHolder.getContext().getAuthentication();
        if (currentAuthentication == null || !(currentAuthentication instanceof OAuth2Authentication)) {
            return;
        }

        LOGGER.debug("Appending token values to service request context.");

        OAuth2Authentication oauth2Authentiation = (OAuth2Authentication) currentAuthentication;
        final OAuth2AuthenticationDetails oAuth2AuthenticationDetails = (OAuth2AuthenticationDetails) oauth2Authentiation.getDetails();

        builder.authenticationToken((oAuth2AuthenticationDetails.getTokenType()) + ' ' + oAuth2AuthenticationDetails.getTokenValue());

        ServiceAuthentication userAuthentication = (ServiceAuthentication) oauth2Authentiation.getUserAuthentication();

        //token sub field is not in use at the moment, because there is no common country independent user id available.
        //try to get the user id from the uid additional claim
        if ("n/a".equals(userAuthentication.getName()) || StringUtils.isBlank(userAuthentication.getName())) {
            builder.userId(userAuthentication.getUid());
        } else {
            builder.userId(userAuthentication.getName());
        }
        //used in audit logging, needs to be upper case.
        builder.applicationId(userAuthentication.getClientId().toUpperCase());

        builder.channelId(userAuthentication.getChannel());
        builder.country(userAuthentication.getCountry());
        builder.authenticationMethod(userAuthentication.getMethod());
        builder.authenticationLevel(userAuthentication.getLevel());
        builder.sessionId(userAuthentication.getSessionId());
        userAuthentication.getAgreementNumber().ifPresent(builder::agreementNumber);
    }
}
