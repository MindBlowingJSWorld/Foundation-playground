package com.nordea.dbf.security;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AuthenticationUtil {

    public static void authenticate(Map<String, Object> token, ServiceAuthentication userAuthentication) {
        final SecurityContext securityContext = mock(SecurityContext.class);

        OAuth2Request request = new OAuth2Request() {
            @Override
            public String getClientId() {
                return (String) token.get("client_id");
            }

            @Override
            public boolean isApproved() {
                return true;
            }
        };

        final OAuth2Authentication oAuth2Authentication = new OAuth2Authentication(request, userAuthentication);

        final OAuth2AuthenticationDetails details = new OAuth2AuthenticationDetails(mock(HttpServletRequest.class));
        details.setDecodedDetails(token);

        oAuth2Authentication.setDetails(details);

        SecurityContextHolder.setContext(securityContext);

        when(securityContext.getAuthentication()).thenReturn(oAuth2Authentication);
    }
}
