package com.nordea.dbf.security;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.interfaces.RSAPublicKey;

public class CryptoUtilsTest {

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    @Test
    public void testLoadRSAPublicKeyShouldReturnResultWhenItsPemFile() throws Exception {
        byte[] bytes = Files.readAllBytes(Paths.get(this.getClass().getClassLoader().getResource("keys/public_key.pem").toURI()));
        RSAPublicKey result = CryptoUtils.loadRSAPublicKey(bytes);
        Assert.assertNotNull(result);
        Assert.assertEquals("RSA", result.getAlgorithm());
    }

    @Test
    public void testLoadRSAPublicKeyShouldReturnResultWhenItsCrtFile() throws Exception {
        byte[] bytes = Files.readAllBytes(Paths.get(this.getClass().getClassLoader().getResource("keys/testcert.crt").toURI()));
        RSAPublicKey result = CryptoUtils.loadRSAPublicKey(bytes);
        Assert.assertNotNull(result);
        Assert.assertEquals("RSA", result.getAlgorithm());
    }
}
