package com.nordea.dbf.security;

import com.fasterxml.jackson.core.JsonParseException;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import org.apache.commons.io.IOUtils;
import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.InvalidSignatureException;
import org.springframework.security.jwt.crypto.sign.RsaSigner;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;

public class ServiceAccessTokenConverterTest {

    private ServiceAccessTokenConverter converter;

    private Map<String, RSAPublicKey> verifierKeys = new HashMap<>();
    private RSAPrivateKey privateKey;

    @Before
    public void setup() throws Exception {
        byte[] bytes = Files.readAllBytes(Paths.get(this.getClass().getClassLoader().getResource("keys/public_key.pem").toURI()));
        RSAPublicKey publicKey = CryptoUtils.loadRSAPublicKey(bytes);
        verifierKeys.put("test", publicKey);
        converter = new ServiceAccessTokenConverter(verifierKeys,  null);

        try (final InputStream in = getClass().getResourceAsStream("/security/test/private_key.der")) {
            if (in == null) {
                throw new IllegalStateException("Test key not found on class path");
            }

            this.privateKey = (RSAPrivateKey) KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(IOUtils.toByteArray(in)));
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorShouldNotAcceptNullVerifierKeyLocator() throws InvalidKeySpecException, NoSuchAlgorithmException {
        new ServiceAccessTokenConverter(null, (String)null);
    }

    @Test
    public void decodeShouldVerifyShouldRetrieveKeyAndVerify() {
        final String payload = "{\"aud\":\"dbf\",\"iss\":\"test\",\"jti\":\"mytoken\"}";
        final String token = JwtHelper.encode(payload, new RsaSigner(privateKey)).getEncoded();

        final Map<String, Object> decoded = converter.decode(token);

        assertThat(decoded.get("iss")).isEqualTo("test");
        assertThat(decoded.get("jti")).isEqualTo("mytoken");
    }

    @Test
    public void decodeShouldFailIfContentContainsMalformedJson() {
        final String token = JwtHelper.encode("invalid json", new RsaSigner(privateKey)).getEncoded();

        try {
            converter.decode(token);
            fail("invalid json payload should be rejected");
        } catch (InvalidTokenException e) {
            assertThat(e.getMessage()).contains("is not valid json");
            assertThat(e.getCause()).isInstanceOf(JsonParseException.class);
        }
    }

    @Test
    public void decodeShouldFailIfTokenContainsNoPayload() {
        final String token = JwtHelper.encode("{}", new RsaSigner(privateKey)).getEncoded();

        try {
            converter.decode(token);
            fail("token with no issuer should be rejected");
        } catch (InvalidTokenException e) {
            assertThat(e.getMessage()).contains("iss");
        }
    }

    @Test
    public void decodeShouldFailIfTokenContainsUnknownIssuer() {
        final String token = JwtHelper.encode("{\"iss\":\"unknown\"}", new RsaSigner(privateKey)).getEncoded();

        try {
            converter.decode(token);
            fail("decode should fail for unknown issuer");
        } catch (InvalidTokenException e) {
            assertThat(e.getMessage()).contains("unknown");
        }
    }

    @Test
    public void decodeShouldFailIfTokenContainsInvalidSignature() {
        final String token1 = JwtHelper.encode("{\"aud\":\"dbf\",\"iss\":\"test\",\"jti\":\"t1\"}", new RsaSigner(privateKey)).getEncoded();
        final String token2 = JwtHelper.encode("{\"aud\":\"dbf\",\"iss\":\"test\",\"jti\":\"t2\"}", new RsaSigner(privateKey)).getEncoded();
        final String invalidToken = token1.substring(0, token1.lastIndexOf('.')) + '.' + token2.substring(token2.lastIndexOf('.') + 1);

        assertThat(converter.decode(token1)).contains(entry("jti", "t1"));
        assertThat(converter.decode(token2)).contains(entry("jti", "t2"));

        try {
            converter.decode(invalidToken);
            fail("invalid token should be rejected");
        } catch (InvalidTokenException e) {
            assertThat(e.getCause()).isInstanceOf(InvalidSignatureException.class);
        }
    }

    @Test
    public void authenticationShouldContainGrantsFromToken() {
        final OAuth2Authentication authentication = converter.extractAuthentication(
                ImmutableMap.<String, Object>builder()
                        .put("client_id", "client1234")
                        .put("sub", "1234")
                        .put("uid", "abcde")
                        .put("ssn", "01010111111")
                        .put("iss", "dbf-authentication-dev")
                        .put("scope", ImmutableSet.of("some.scope"))
                        .put("c", "FI")
                        .put("am", "mta")
                        .put("al", "1")
                        .put("ch", "channel")
                        .put("grants", ImmutableMap.<String, Object>of("agreement", 1234L))
                        .put("sgm", "household")
                        .put("sid", "1243")
                        .build()
        );

        ServiceAuthentication serviceAuthentication = (ServiceAuthentication) authentication.getUserAuthentication();
        assertThat(serviceAuthentication.getGrants()).containsExactly(new ResourceGrant<>("agreement", 1234L));
        assertThat(serviceAuthentication.getAgreementNumber()).isEqualTo(Optional.of(1234L));
    }

    @Test
    public void authenticationShouldHandleAudienceAsListAndString() {
        converter.extractAuthentication(
                ImmutableMap.<String, Object>builder()
                        .put("client_id", "client1234")
                        .put("sub", "1234")
                        .put("uid", "abcde")
                        .put("ssn", "01010111111")
                        .put("iss", "dbf-authentication-dev")
                        .put("scope", ImmutableSet.of("some.scope"))
                        .put("c", "FI")
                        .put("am", "mta")
                        .put("al", "1")
                        .put("ch", "channel")
                        .put("sgm", "household")
                        .put("sid", "1243")
                        .put("grants", ImmutableMap.<String, Object>of("agreement", 1234L))
                        .put("aud", Collections.singleton("osl"))
                        .build()
        );

        converter.extractAuthentication(
                ImmutableMap.<String, Object>builder()
                        .put("client_id", "client1234")
                        .put("sub", "1234")
                        .put("uid", "abcde")
                        .put("ssn", "01010111111")
                        .put("iss", "dbf-authentication-dev")
                        .put("scope", ImmutableSet.of("some.scope"))
                        .put("c", "FI")
                        .put("am", "mta")
                        .put("al", "1")
                        .put("ch", "channel")
                        .put("sgm", "household")
                        .put("sid", "1243")
                        .put("grants", ImmutableMap.<String, Object>of("agreement", 1234L))
                        .put("aud", "BbJv5oN0XlzfrqCSopVU")
                        .build()
        );
    }

    @Test
    public void authenticationShouldHandleNinaaAudience() {
        ServiceAccessTokenConverter converter2 = new ServiceAccessTokenConverter(verifierKeys, "ninaaclientidthing");

        OAuth2Authentication authentication = converter2.extractAuthentication(
                ImmutableMap.<String, Object>builder()
                        .put("client_id", "client1234")
                        .put("sub", "1234")
                        .put("uid", "abcde")
                        .put("ssn", "01010111111")
                        .put("iss", "dbf-authentication-dev")
                        .put("scope", ImmutableSet.of("some.scope"))
                        .put("c", "FI")
                        .put("am", "mta")
                        .put("al", "1")
                        .put("ch", "channel")
                        .put("sgm", "household")
                        .put("sid", "1243")
                        .put("grants", ImmutableMap.<String, Object>of("agreement", 1234L))
                        .put("aud", "ninaaclientidthing")
                        .build()
        );
        assertThat(authentication.getOAuth2Request().getResourceIds().contains("ninaaclientidthing"));
        assertThat(authentication.getOAuth2Request().getResourceIds().contains("osl"));

        converter2 = new ServiceAccessTokenConverter(verifierKeys, null);

        authentication = converter2.extractAuthentication(
                ImmutableMap.<String, Object>builder()
                        .put("client_id", "client1234")
                        .put("sub", "1234")
                        .put("uid", "abcde")
                        .put("ssn", "01010111111")
                        .put("iss", "dbf-authentication-dev")
                        .put("scope", ImmutableSet.of("some.scope"))
                        .put("c", "FI")
                        .put("am", "mta")
                        .put("al", "1")
                        .put("ch", "channel")
                        .put("sgm", "household")
                        .put("sid", "1243")
                        .put("grants", ImmutableMap.<String, Object>of("agreement", 1234L))
                        .put("aud", "ninaaclientidthing")
                        .build()
        );
        assertThat(authentication.getOAuth2Request().getResourceIds().contains("ninaaclientidthing"));
        assertThat(!authentication.getOAuth2Request().getResourceIds().contains("osl"));
    }

    private TypeSafeMatcher<Map<String, Object>> containsIssuer(final String issuer) {
        return new TypeSafeMatcher<Map<String, Object>>() {
            @Override
            protected boolean matchesSafely(Map<String, Object> stringObjectMap) {
                return issuer.equals(stringObjectMap.get("iss"));
            }

            @Override
            public void describeTo(Description description) {
                description.appendText("mapThat(contains(\"iss\", \"" + issuer + "\"))");
            }
        };
    }

}
