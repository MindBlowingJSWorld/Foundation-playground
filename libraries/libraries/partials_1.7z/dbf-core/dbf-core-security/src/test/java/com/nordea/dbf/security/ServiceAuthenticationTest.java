package com.nordea.dbf.security;

import com.google.common.collect.ImmutableMap;
import org.junit.Test;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;

public class ServiceAuthenticationTest {

    private static final Map EMPTY_GRANTS = Collections.EMPTY_MAP;

    @Test
    public void constructorShouldNotAcceptInvalidArguments() {
        try {
            new ServiceAuthentication(null, null, null,null,null, null, null, null, null, EMPTY_GRANTS, null, null, null,null);
            fail("principal can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("", null,null,null, null, null, null, null, null, EMPTY_GRANTS, null, null, null,null);
            fail("empty principal should be rejected");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null,"dbf-test@v1", null, null, null, null, null, EMPTY_GRANTS, null, null, null,null);
            fail("issuer can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null,"dbf-test@v1", null, null, null, null, null, EMPTY_GRANTS, null, null, null,null);
            fail("scopes can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null,"dbf-test@v1", new HashSet<>(), null, null, null, null, EMPTY_GRANTS, null, null, null,null);
            fail("scopes can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null,"dbf-test@v1", Collections.singleton("some.scope"), null, null, null, null, EMPTY_GRANTS, null, null, null,null);
            fail("country can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null,"dbf-test@v1", Collections.singleton("some.scope"), "FI", null, null, null, EMPTY_GRANTS, null, null, null,null);
            fail("method can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null, "dbf-test@v1", Collections.singleton("some.scope"), "FI", "some_method", null, null, EMPTY_GRANTS, null, null, null,null);
            fail("level can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null,"dbf-test@v1", Collections.singleton("some.scope"), "FI", "some_method", "1", null, EMPTY_GRANTS, null, null, null,null);
            fail("channel can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null,"dbf-test@v1", Collections.singleton("some.scope"), "FI", "some_method", "1", "channel", EMPTY_GRANTS, null, null, null,null);
            fail("session id can't be null");
        } catch (IllegalArgumentException e) {
        }

        try {
            new ServiceAuthentication("1234", null,null,"dbf-test@v1", Collections.singleton("some.scope"), "FI", "some_method", "1", "channel", EMPTY_GRANTS,"session", null, null,null);
            fail("session id can't be null");
        } catch (IllegalArgumentException e) {
        }
    }

    @Test
    public void authoritiesAndPrincipalsShouldBeDefined() {
        final ServiceAuthentication authentication = new ServiceAuthentication("1234","foo","foo", "dbf-test@v1", Collections.singleton("some.scope"), "FI", "some_method", "1", "channel", EMPTY_GRANTS, "session", "segment", null, "client");

        assertThat(authentication.getPrincipal()).isEqualTo("1234");
        assertThat(authentication.getName()).isEqualTo("1234");
        assertThat(authentication.getAuthorities()).containsExactly(new SimpleGrantedAuthority("some.scope"));
    }

    @Test
    public void grantsShouldBeDefined() {
        final Map<String, Long> grants = ImmutableMap.of("agreement", 12345L);
        final ServiceAuthentication authentication =new ServiceAuthentication("1234","foo","foo", "dbf-test@v1", Collections.singleton("some.scope"), "FI", "some_method", "1", "channel", grants, "session", "segment", null, "client");

        assertThat(authentication.getGrants()).containsExactly(new ResourceGrant<>("agreement", 12345L));
    }

    @Test
    public void authenticationShouldInitiallyBeAuthenticated() {
        assertThat(new ServiceAuthentication("1234","foo","foo", "dbf-test@v1", Collections.singleton("some.scope"), "FI", "some_method", "1", "channel", EMPTY_GRANTS, "session", "segment", null, "client").isAuthenticated()).isTrue();
    }

    @Test
    public void authenticationCanBeSetToAuthenticated() {
        final ServiceAuthentication auth = new ServiceAuthentication("1234","foo","foo", "dbf-test@v1", Collections.singleton("some.scope"), "FI", "some_method", "1", "channel", EMPTY_GRANTS, "session", "segment", null, "client");

        auth.setAuthenticated(true);

        assertThat(auth.isAuthenticated()).isTrue();
    }


}