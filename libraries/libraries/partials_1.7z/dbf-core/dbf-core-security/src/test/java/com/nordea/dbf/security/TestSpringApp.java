package com.nordea.dbf.security;

import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.annotation.EnableServiceConfiguration;
import com.nordea.dbf.audit.AuditCategory;
import com.nordea.dbf.audit.annotation.Audit;
import com.nordea.dbf.audit.annotation.AuditHideValue;
import com.nordea.dbf.audit.annotation.EnableAuditing;
import com.nordea.dbf.concurrent.Handover;
import com.nordea.dbf.concurrent.ThreadContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import com.nordea.dbf.security.annotation.EnableServiceSecurity;
import com.nordea.dbf.security.annotation.Uid;
import com.nordea.dbf.security.config.ServiceHttpSecurityConfigurer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.MediaType;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.Map;

import static org.junit.Assert.assertNotNull;

@SpringBootApplication
@EnableServiceConfiguration
@EnableServiceSecurity
@EnableAuditing
public class TestSpringApp {

    public static void main(String[] args) {
        SpringApplication.run(TestSpringApp.class, args);
    }

    @Component
    static class CustomHttpConfigurer implements ServiceHttpSecurityConfigurer {
        @Override
        public void configure(HttpSecurity http) throws Exception {
            http.authorizeRequests()
                    .antMatchers("/scoped").access("#oauth2.hasScope('somescope')")
                    .antMatchers("/getasync").access("#oauth2.hasScope('somescope')")
                    .antMatchers("/permitall").permitAll();
        }
    }

    @RestController
    static class TestResource {

        @Audit(description = "{0}, {1}", category = AuditCategory.TRACK)
        @RequestMapping(value = "/fullyauthenticated", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
        public Map getScoped(@Uid String uid, Claims claims) {
            return ImmutableMap.builder().put("uid", uid).put("claims", claims).build();
        }

        @Audit(description = "scoped called", category = AuditCategory.TRACK)
        @RequestMapping(value="/scoped", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
        public String getScoped() {
            return "scoped";
        }

        @RequestMapping(value="/unrestricted", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
        public String getUnrestricted() {
            return "unrestricted";
        }

        @RequestMapping(value="/permitall", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
        public String getPermitAll() {
            return "permitall";
        }


        @Audit(description = "auditignore called", category = AuditCategory.TRACK)
        @RequestMapping(value="/auditignore",  produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
        public String auditIgnore(@RequestHeader @AuditHideValue String ignore, @RequestHeader String audit) {
            return "auditignore";
        }

        @Audit(description = "{0}, {1}", category = AuditCategory.TRACK)
        @RequestMapping(value="/getasync", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
        public DeferredResult<String> asyncGet() {
            DeferredResult<String> result = new DeferredResult<>();
            Handover handover = ThreadContext.DEFAULT.createHandover();
            Runnable async = () -> handover.in(()-> {
                //Security context is not atm handed over to async threads and probably it's better so.
                //assertNotNull(ServiceSecurityContext.getServiceAuthentication());
                assertNotNull(ServiceRequestContextHolder.get().get());
                result.setResult("getasync");
            });
            new Thread(async).start();
            return result;
        }
    }
}
