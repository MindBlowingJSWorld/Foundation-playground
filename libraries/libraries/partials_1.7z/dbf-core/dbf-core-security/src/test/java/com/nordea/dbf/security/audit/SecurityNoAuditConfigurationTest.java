package com.nordea.dbf.security.audit;

import com.nordea.dbf.security.config.ServiceSecurityConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = TestAppWithSecurityNoAudit.class)
@WebAppConfiguration
@IntegrationTest("server.port:0")
public class SecurityNoAuditConfigurationTest {

    @Autowired
    private ServiceSecurityConfiguration securityConfiguration;

    @Test
    public void testSecurityConfigured(){
        assertNotNull(securityConfiguration);
    }
}
