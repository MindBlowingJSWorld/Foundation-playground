package com.nordea.dbf.security.audit;

import com.nordea.dbf.annotation.EnableServiceConfiguration;
import com.nordea.dbf.security.annotation.EnableServiceSecurity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableServiceConfiguration
@EnableServiceSecurity
public class TestAppWithSecurityNoAudit {
    public static void main(String[] args) {
        SpringApplication.run(TestAppWithSecurityNoAudit.class, args);
    }
}

