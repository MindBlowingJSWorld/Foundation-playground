package com.nordea.dbf.security.config;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.env.Environment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

/**
 * Created by K306010 on 2016-04-26.
 */

@RunWith(MockitoJUnitRunner.class)
public class ResourceServiceConfigurationTest {
    @Mock
    private Environment environment;

    @Before
    public void setUp() {
        when(environment.getProperty("com.nordea.environmenttype")).thenReturn("UNIT_TEST");
    }

    @Test
    public void testAnonymousWithRestrictedOnlyPaths() throws Exception {
        when(environment.getProperty(eq("dbf.security.anonymous.paths"), any(String.class))).thenReturn("");
        when(environment.getProperty(eq("dbf.security.unrestricted.paths"), any(String.class))).thenReturn("**/api-docs/**|/**/*.jsp|/mx/**");
        final String[] anonAntMatchers = ResourceServiceConfiguration.getAnonymousPaths(environment);
        assertThat(anonAntMatchers).containsExactly("**/api-docs/**","/**/*.jsp","/mx/**");
    }

    @Test
    public void testMergeOfAnonymousPaths() throws Exception {
        when(environment.getProperty(eq("dbf.security.anonymous.paths"), any(String.class))).thenReturn("/v2/api-docs");
        when(environment.getProperty(eq("dbf.security.unrestricted.paths"), any(String.class))).thenReturn("**/api-docs/**|/**/*.jsp|/mx/**");
        final String[] anonAntMatchers = ResourceServiceConfiguration.getAnonymousPaths(environment);
        assertThat(anonAntMatchers).containsExactly("/v2/api-docs", "**/api-docs/**","/**/*.jsp","/mx/**");
    }
}
