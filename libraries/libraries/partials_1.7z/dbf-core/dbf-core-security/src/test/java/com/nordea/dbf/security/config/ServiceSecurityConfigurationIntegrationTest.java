package com.nordea.dbf.security.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.security.TestSpringApp;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.Validate;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.RsaSigner;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Map;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = TestSpringApp.class)
@WebAppConfiguration
@IntegrationTest("server.port:0")
public class ServiceSecurityConfigurationIntegrationTest {

    public static final String PRIVATE_KEY_PATH = "/security/test/private_key.der";
    public static final RSAPrivateKey PRIVATE_KEY;
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceSecurityConfigurationIntegrationTest.class);

    static {
        try (final InputStream in = ServiceSecurityConfigurationIntegrationTest.class.getResourceAsStream(PRIVATE_KEY_PATH)) {
            if (in == null) {
                throw new ExceptionInInitializerError("Could not locate signer key for test from resource '" + PRIVATE_KEY_PATH + "'");
            }

            PRIVATE_KEY = (RSAPrivateKey) KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(IOUtils.toByteArray(in)));
        } catch (IOException e) {
            throw new ExceptionInInitializerError("Failed to load signer key for test (" + e.getMessage() + ")");
        } catch (NoSuchAlgorithmException e) {
            throw new ExceptionInInitializerError("Could not locate RSA key generator (" + e.getMessage() + ")");
        } catch (InvalidKeySpecException e) {
            throw new ExceptionInInitializerError("Signer key in resource \"" + PRIVATE_KEY_PATH + "\" is not valid: " + e.getMessage());
        }
    }

    private RestTemplate restTemplate = new TestRestTemplate();
    @Value("${local.server.port}")
    private int port;

    private static String fromPayload(Object payload) {
        Validate.notNull(payload, "payload can't be null");

        final String claims;

        try {
            claims = OBJECT_MAPPER.writeValueAsString(payload);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Payload can't be encoded as JSON: " + payload, e);
        }

        return JwtHelper.encode(claims, new RsaSigner(PRIVATE_KEY)).getEncoded();
    }


    private static String createBearerAuth(String scope) throws IOException {
        long iat = System.currentTimeMillis() / 1000;
        long exp = iat + 1000;
        ImmutableMap claims =
                ImmutableMap.builder()
                        .put("sub", "testuser")
                        .put("iss", "dbf-local@v1")
                        .put("client_id", "client")
                        .put("scope", new String[]{scope})
                        .put("exp", exp)
                        .put("am", "mta")
                        .put("al", "3")
                        .put("ch", "dbf")
                        .put("nbf", iat)
                        .put("iat", iat)
                        .put("c", "FI")
                        .put("sid", UUID.randomUUID().toString())
                        .put("uid", "12345")
                        .put("ssn", "12345")
                        .put("sgm", "household")
                        .build();

        return "Bearer " + fromPayload(claims);
    }

    private static String createExpiredBearerAuth(String scope) throws IOException {
        long iat = System.currentTimeMillis() / 1000;
        long exp = iat - 1;
        ImmutableMap claims =
                ImmutableMap.builder()
                        .put("sub", "testuser")
                        .put("iss", "dbf-local@v1")
                        .put("client_id", "client")
                        .put("scope", new String[]{scope})
                        .put("exp", exp)
                        .put("am", "mta")
                        .put("al", "3")
                        .put("ch", "dbf")
                        .put("nbf", iat)
                        .put("iat", iat)
                        .put("c", "FI")
                        .put("uid", "12345")
                        .put("sid", "112")
                        .put("sgm", "household")
                        .build();

        return "Bearer " + fromPayload(claims);
    }

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testRequestScopedResourceWithValidTokenIsAuthorized() throws Exception {

        String authorization = createBearerAuth("somescope");
        LOGGER.info("Auth header: {}", authorization);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorization);

        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/scoped"));

        ResponseEntity<String> entity = restTemplate.exchange(request, String.class);
        assertEquals(HttpStatus.OK, entity.getStatusCode());
        assertEquals("scoped", entity.getBody());
    }

    @Test
    public void testRequestFullyAuthenticatedResourceWithValidTokenIsAuthorized() throws Exception {

        String authorization = createBearerAuth("somescope");
        LOGGER.info("Auth header: {}", authorization);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorization);

        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/fullyauthenticated"));

        ResponseEntity<Map> entity = restTemplate.exchange(request, Map.class);
        assertEquals(HttpStatus.OK, entity.getStatusCode());
        assertEquals("12345", entity.getBody().get("uid"));
        assertTrue(entity.getBody().get("claims") instanceof Map);
        Map claims = (Map) entity.getBody().get("claims");
        assertEquals("testuser", claims.get("subject"));
    }

    @Test
    public void testAuditIgnoreRequestParameterIsNotAuditLogged() throws Exception {

        String authorization = createBearerAuth("somescope");
        LOGGER.info("Auth header: {}", authorization);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorization);
        headers.set("ignore", "this should not be audit logged");
        headers.set("audit", "this should be audit logged");

        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/auditignore"));

        ResponseEntity<String> entity = restTemplate.exchange(request, String.class);
        assertEquals(HttpStatus.OK, entity.getStatusCode());
    }


    @Test
    public void testRequestFullyAuthenticatedResourceWithoutTokenIsUnauthorized() throws Exception {
        RequestEntity<String> request = new RequestEntity<>(
                null, null, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/fullyauthenticated"));

        ResponseEntity<Map> entity = restTemplate.exchange(request, Map.class);
        assertEquals(HttpStatus.UNAUTHORIZED, entity.getStatusCode());
        Map<String, Object> errorResponse = entity.getBody();
        LOGGER.info("Error response: {}", errorResponse);
        assertEquals("unauthorized", errorResponse.get("error"));
    }

    @Test
    public void testRequestFullyAuthenticatedResourceWithExpiredTokenIsUnauthorized() throws Exception {

        String authorization = createExpiredBearerAuth("somescope");
        LOGGER.info("Auth header: {}", authorization);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorization);

        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/fullyauthenticated"));

        ResponseEntity<Map> entity = restTemplate.exchange(request, Map.class);
        assertEquals(HttpStatus.UNAUTHORIZED, entity.getStatusCode());
        Map<String, Object> errorResponse = entity.getBody();
        LOGGER.info("Error response: {}", errorResponse);
        assertEquals("invalid_token", errorResponse.get("error"));
        assertEquals("Access token expired.", errorResponse.get("error_description"));
    }

    @Test
    public void testRequestScopedResourceWithInsufficientScopeInTokenIsForbidden() throws Exception {

        String authorization = createBearerAuth("falsescope");
        LOGGER.info("Auth header: {}", authorization);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorization);
        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/scoped"));

        ResponseEntity<Map<String, Object>> entity = restTemplate.exchange(request, new ParameterizedTypeReference<Map<String, Object>>() {
        });
        assertEquals(HttpStatus.FORBIDDEN, entity.getStatusCode());
        Map<String, Object> errorResponse = entity.getBody();
        LOGGER.info("Error response: {}", errorResponse);
        assertEquals("insufficient_scope", errorResponse.get("error"));
    }


    @Test
    public void testRequestUnrestrictedPathIsAllowed() throws Exception {
        RequestEntity<String> request = new RequestEntity<>(
                null, null, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/unrestricted"));

        ResponseEntity<String> entity = restTemplate.exchange(request, String.class);
        assertEquals(HttpStatus.OK, entity.getStatusCode());
        assertEquals("unrestricted", entity.getBody());
    }


    @Test
    public void testRequestUnrestrictedPathWithExpiredTokenIsAllowed() throws Exception {
        String authorization = createExpiredBearerAuth("scope");
        LOGGER.info("Auth header: {}", authorization);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorization);

        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/unrestricted"));

        ResponseEntity<String> entity = restTemplate.exchange(request, String.class);
        assertEquals(HttpStatus.OK, entity.getStatusCode());
        assertEquals("unrestricted", entity.getBody());
    }


    @Test
    @Ignore("permit all via http security is not supported yet due to ServiceRequestContextFilter inability to handle other than permit all paths defined by dbf.security.unrestricted.paths and dbf.security.anonymous.paths ")
    public void testRequestCustomPermitAllPathIsAllowed() throws Exception {

        RequestEntity<String> request = new RequestEntity<>(
                null, null, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/permitall"));

        ResponseEntity<String> entity = restTemplate.exchange(request, String.class);
        assertEquals(HttpStatus.OK, entity.getStatusCode());
        assertEquals("permitall", entity.getBody());
    }

    @Test
    public void testInvalidBearerAuthenticationHeaderReturnsInvalidTokenError() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer invalid");
        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/fullyauthenticated"));

        ResponseEntity<Map> entity = restTemplate.exchange(request, Map.class);
        assertEquals(HttpStatus.UNAUTHORIZED, entity.getStatusCode());
        assertEquals("invalid_token", entity.getBody().get("error"));
    }

    @Test
    public void testRequestGetAsyncResourceWithValidTokenIsAuthorized() throws Exception {

        String authorization = createBearerAuth("somescope");
        LOGGER.info("Auth header: {}", authorization);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorization);

        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/getasync"));

        ResponseEntity<String> entity = restTemplate.exchange(request, String.class);
        assertEquals(HttpStatus.OK, entity.getStatusCode());
        assertEquals("getasync", entity.getBody());
    }

    @Test
    public void testRequestGetAsyncResourceWithInvalidBearerHeaderIsUnauthorized() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer invalid token");

        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/getasync"));

        ResponseEntity<Map> entity = restTemplate.exchange(request, Map.class);
        assertEquals(HttpStatus.UNAUTHORIZED, entity.getStatusCode());
        assertEquals("invalid_token", entity.getBody().get("error"));
    }

    @Test
    public void testRequestGetAsyncResourceWithFalseScopeIsForbidden() throws Exception {

        String authorization = createBearerAuth("falsescope");
        LOGGER.info("Auth header: {}", authorization);
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", authorization);

        RequestEntity<String> request = new RequestEntity<>(
                null, headers, HttpMethod.GET, URI.create("http://localhost:" + this.port + "/getasync"));

        ResponseEntity<Map> entity = restTemplate.exchange(request, Map.class);
        assertEquals(HttpStatus.FORBIDDEN, entity.getStatusCode());
        assertEquals("insufficient_scope", entity.getBody().get("error"));
    }
}
