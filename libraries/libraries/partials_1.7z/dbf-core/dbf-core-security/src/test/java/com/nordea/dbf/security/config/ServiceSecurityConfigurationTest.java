package com.nordea.dbf.security.config;

import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.Appender;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.core.env.Environment;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ServiceSecurityConfigurationTest {

    @Mock
    private Environment environment;

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private ServiceSecurityConfiguration serviceSecurityConfiguration;

    @Before
    public void setUp() {
        when(environment.getProperty("com.nordea.environmenttype")).thenReturn("UNIT_TEST");
    }

    @Test
    public void testConfigureReadingClassPathFolder() throws Exception {
        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn("classpath:**/keys/*.pem");
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();
        serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);

    }

    @Test
    public void testConfigureReadingClassPathFile() throws Exception {
        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn("classpath:**/keys/public_key.pem");
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();
        serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
    }

    @Test
    public void testConfigureReadingClassPathFileMissing() throws Exception {
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();

        ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
        final Appender mockAppender = mock(Appender.class);
        when(mockAppender.getName()).thenReturn("MOCK");
        root.addAppender(mockAppender);

        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn("classpath://keys/missing.pem");

        try {
            serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
            fail("Failed to throw Exception");

        } catch (Exception ex) {
            assertNotNull(ex);
        }

        // Verify that we logged an event
        verify(mockAppender).doAppend(argThat(new ArgumentMatcher() {
            @Override
            public boolean matches(final Object argument) {
                return ((LoggingEvent) argument).getFormattedMessage().contains("Could not load public key");
            }
        }));
    }

    @Test
    public void testConfigureReadingFileUrlFolder() throws Exception {
        String path = Thread.currentThread().getContextClassLoader().getResource("keys/").getPath();
        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn("file://" + path);
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();
        serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
    }

    @Test
    public void testConfigureReadingFileUrlFile() throws Exception {
        String path = Thread.currentThread().getContextClassLoader().getResource("keys/public_key.pem").getPath();
        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn("file://" + path);
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();
        serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
    }

    @Test(expected = BeanCreationException.class)
    public void shouldThrowWhenNoProfileIsSet() throws Exception {
        when(environment.getProperty("dbf.security.verfierkey.paths", "")).thenReturn("");
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();
        serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
    }

    @Test
    public void testConfigureReadingFileUrlMissing() throws Exception {
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();

        ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
        final Appender mockAppender = mock(Appender.class);
        when(mockAppender.getName()).thenReturn("MOCK");
        root.addAppender(mockAppender);

        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn("file://keys/missing.pem");

        try {
            serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
            fail("Failed to throw Exception");

        } catch (Exception ex) {
            assertNotNull(ex);
        }

        // Verify that we logged an event
        verify(mockAppender).doAppend(argThat(new ArgumentMatcher() {
            @Override
            public boolean matches(final Object argument) {
                return ((LoggingEvent) argument).getFormattedMessage().contains("Failed to find key in path");
            }
        }));
    }

    @Test
    public void testConfigureReadingFolder() throws Exception {
        String path = Thread.currentThread().getContextClassLoader().getResource("keys/").getPath();
        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn(path);
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();
        serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
    }

    @Test
    public void testConfigureReadingFile() throws Exception {
        String path = Thread.currentThread().getContextClassLoader().getResource("keys/public_key.pem").getPath();
        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn(path);
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();
        serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
    }

    @Test
    public void testConfigureReadingFileMissing() throws Exception {
        final ResourceServerSecurityConfigurer resourceServerSecurityConfigurer = new ResourceServerSecurityConfigurer();

        ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory.getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
        final Appender mockAppender = mock(Appender.class);
        when(mockAppender.getName()).thenReturn("MOCK");
        root.addAppender(mockAppender);

        when(environment.getProperty("dbf.security.verfierkey.paths", "classpath:security/dbf/*.*")).thenReturn("keys/missing.pem");

        try {
            serviceSecurityConfiguration.configure(resourceServerSecurityConfigurer);
            fail("Failed to throw Exception");

        } catch (Exception ex) {
            assertNotNull(ex);
        }

        // Verify that we logged an event
        verify(mockAppender).doAppend(argThat(new ArgumentMatcher() {
            @Override
            public boolean matches(final Object argument) {
                return ((LoggingEvent) argument).getFormattedMessage().contains("Failed to find key in path");
            }
        }));
    }
}
