package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.ServiceAuthentication;
import com.nordea.dbf.security.annotation.Agreement;
import com.nordea.dbf.security.annotation.Grant;
import org.junit.After;
import org.junit.Test;
import org.springframework.core.MethodParameter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import java.lang.annotation.Annotation;
import java.util.Optional;

import static com.nordea.dbf.security.spring.ServiceSecurityContext.getServiceAuthentication;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.*;

public class AbstractHandlerMethodArgumentResolverTest {

    private final AbstractHandlerMethodArgumentResolver resolver = mock(AbstractHandlerMethodArgumentResolver.class,
            withSettings().defaultAnswer(CALLS_REAL_METHODS));

    private final MethodParameter parameter = mock(MethodParameter.class);
    private final SecurityContext securityContext = mock(SecurityContext.class);

    @After
    public void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    public void grantOfShouldReturnAbsentOptionalIfMethodArgIsMissingAnnotation() {
        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[0]);
        
        assertThat(resolver.grantOf(parameter).isPresent()).isFalse();
    }

    @Test
    public void grantOfShouldReturnDirectGrant() {
        final Grant grant = mock(Grant.class);
        when(grant.annotationType()).thenReturn((Class) Grant.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{grant});

        assertThat(resolver.grantOf(parameter)).isEqualTo(Optional.of(grant));
    }

    @Test
    @SuppressWarnings("unchecked")
    public void grantOfShouldReturnIndirectGrant() {
        final Agreement agreement = mock(Agreement.class);

        when(agreement.annotationType()).thenReturn((Class) Agreement.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{agreement});

        assertThat(resolver.grantOf(parameter)).isEqualTo(Optional.of(Agreement.class.getAnnotation(Grant.class)));
    }

    @Test(expected = SecurityException.class)
    public void getValidAuthenticationShouldFailIfNoSecurityContextIsConfigured() {
        getServiceAuthentication();
    }

    @Test
    public void getValidAuthenticationShouldFailIfSecurityContextContainsNoAuthentication() {
        SecurityContextHolder.setContext(securityContext);

        try {
            getServiceAuthentication();
            fail("should fail if no authentication in context");
        } catch (SecurityException e) {
        }
    }

    @Test
    public void getValidAuthenticationShouldFailIfNotAuthenticated() {
        when(securityContext.getAuthentication()).thenReturn(mock(Authentication.class));
        SecurityContextHolder.setContext(securityContext);

        try {
            getServiceAuthentication();
            fail("should fail if unauthenticated context");
        } catch (SecurityException e) {
        }
    }

    @Test
    public void getValidAuthenticationShouldReturnAuthentication() {
        final Authentication authentication = mock(Authentication.class);
        OAuth2Authentication oAuth2Authentication = mock(OAuth2Authentication.class);
        when(oAuth2Authentication.isAuthenticated()).thenReturn(true);
        ServiceAuthentication userAuthenticaiton = mock(ServiceAuthentication.class);

        when(securityContext.getAuthentication()).thenReturn(oAuth2Authentication);
        when(oAuth2Authentication.getUserAuthentication()).thenReturn(userAuthenticaiton);
        when(authentication.isAuthenticated()).thenReturn(true);

        SecurityContextHolder.setContext(securityContext);

        assertThat(getServiceAuthentication()).isEqualTo(userAuthenticaiton);
    }
}
