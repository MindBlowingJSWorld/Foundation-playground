package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.Claims;
import com.nordea.dbf.security.ServiceAuthentication;
import org.junit.Test;
import org.springframework.core.MethodParameter;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
public class ClaimsMethodArgumentResolverTest {
    private final MethodParameter methodParameter = mock(MethodParameter.class);
    private ClaimsMethodArgumentResolver resolver = new ClaimsMethodArgumentResolver();

    @Test
    public void supportsParameterShouldReturnTrueForSupportedAnnotations() {
        when(methodParameter.getParameterType()).thenReturn((Class) Claims.class);
        assertThat(resolver.supportsParameter(methodParameter)).isTrue();

    }

    @Test
    public void parameterOfUnsupportedTypeShouldNotBeSupported() {
        when(methodParameter.getParameterType()).thenReturn((Class) ServiceAuthentication.class);
        assertThat(resolver.supportsParameter(methodParameter)).isFalse();
    }

    @Test
    public void resolveShouldReturnConfiguredServiceRequestContext() throws Exception {
        when(methodParameter.getParameterType()).thenReturn((Class) Claims.class);

        SecurityContext securityContext = mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);

        ServiceAuthentication serviceAuthentication = mock(ServiceAuthentication.class);
        Claims claims = mock(Claims.class);
        OAuth2Authentication oAuth2Authentication = mock(OAuth2Authentication.class);
        when(oAuth2Authentication.isAuthenticated()).thenReturn(true);
        when(serviceAuthentication.getClaims()).thenReturn(claims);
        when(oAuth2Authentication.getUserAuthentication()).thenReturn(serviceAuthentication);
        when(securityContext.getAuthentication()).thenReturn(oAuth2Authentication);

        final Object resolved = resolver.resolveArgument(methodParameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));

        assertThat(resolved).isEqualTo(claims);
    }

}
