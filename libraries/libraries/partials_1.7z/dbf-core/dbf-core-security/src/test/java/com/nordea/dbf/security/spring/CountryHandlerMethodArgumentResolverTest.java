package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.ServiceAuthentication;
import com.nordea.dbf.security.annotation.Country;
import org.junit.After;
import org.junit.Test;
import org.springframework.core.MethodParameter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import java.util.Collections;

import static com.nordea.dbf.security.AuthenticationUtil.authenticate;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class CountryHandlerMethodArgumentResolverTest {
    CountryHandlerMethodArgumentResolver resolver = new CountryHandlerMethodArgumentResolver();

    @After
    public void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    public void countryFromRequestParameterShouldNotOverrideCountryFromToken() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);
        when(parameter.getParameterAnnotation(Country.class)).thenReturn(mock(Country.class));
        final NativeWebRequest webRequest = mock(NativeWebRequest.class);
        when(webRequest.getParameter("country")).thenReturn("NO");

        authenticate(null, createDefaultAuthentication("123456"));

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), webRequest, mock(WebDataBinderFactory.class));
        assertThat(value).isEqualTo("FI");
    }

    @Test
    public void countryCanBeResolvedFromAuthToken() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);
        when(parameter.getParameterAnnotation(Country.class)).thenReturn(mock(Country.class));

        authenticate(null, createDefaultAuthentication("123456"));

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));
        assertThat(value).isEqualTo("FI");
    }


    @Test(expected = SecurityException.class)
    public void shouldOnlyResolveValidCountryCodes() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);
        when(parameter.getParameterAnnotation(Country.class)).thenReturn(mock(Country.class));

        final NativeWebRequest webRequest = mock(NativeWebRequest.class);
        when(webRequest.getParameter("country")).thenReturn("RU");

        resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), webRequest, mock(WebDataBinderFactory.class));
    }

    private ServiceAuthentication createDefaultAuthentication(String uid) {
        return new ServiceAuthentication(
                "1234",
                uid,
                "01010111111",
                "dbf-authentication-dev",
                Collections.<String>singleton("some.scope"),
                "FI",
                "BANKID",
                "HIGH",
                "channel",
                null, "session", "household", null, "client"
        );
    }
}
