package com.nordea.dbf.security.spring;

import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.ServiceRequestContextHolder;
import com.nordea.dbf.security.ServiceAuthentication;
import com.nordea.dbf.security.spring.servicecontext.AuthenticationTokenAppender;
import com.nordea.dbf.util.ServiceContextMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collections;
import java.util.Optional;
import java.util.concurrent.Future;

import static com.nordea.dbf.security.AuthenticationUtil.authenticate;
import static org.assertj.core.api.Assertions.assertThat;


public class ServiceRequestContextFromAuthenticationTokenTests {

    private ServiceContextMock serviceContextMock = new ServiceContextMock();

    @Before
    public void setup() {
        serviceContextMock.setup(Collections.singletonList(new AuthenticationTokenAppender()));
    }


    @After
    public void tearDown() {
        ServiceRequestContextHolder.clear();
        SecurityContextHolder.clearContext();
    }

    @Test
    public void dbfTokenDetailsConfiguredForValidToken() throws Exception {
        ServiceAuthentication authentication =
                new ServiceAuthentication(
                        "1234",
                        "1234",
                        "1234",
                        "dbf-authentication-dev",
                        Collections.singleton("some.scope"),
                        "SE",
                        "BANKID",
                        "HIGH",
                        "channel",
                        Collections.singletonMap("agreement", 12345L),
                        "session",
                        "household",
                        null,
                        "client"
                );

        authenticate(Collections.singletonMap("client_id", "client"), authentication);

        Future<Optional<ServiceRequestContext>> requestContextFuture = serviceContextMock.requestContext();
        serviceContextMock.doFilter();

        ServiceRequestContext requestContext = requestContextFuture.get().get();


        assertThat(requestContext.getUserId()).isEqualTo(Optional.of("1234"));
        assertThat(requestContext.getApplicationId()).isEqualTo(Optional.of("CLIENT")); //application id is always uppercase even though client id in the token is lowercase
        assertThat(requestContext.getChannelId()).isEqualTo(Optional.of("channel"));
        assertThat(requestContext.getAuthenticationMethod()).isEqualTo(Optional.of("BANKID"));
        assertThat(requestContext.getAuthenticationLevel()).isEqualTo(Optional.of("HIGH"));
        assertThat(requestContext.getAgreementNumber()).isEqualTo(Optional.of(12345L));
        assertThat(requestContext.getCountry()).isEqualTo(Optional.of("SE"));
    }

    @Test
    public void authenticationMethodAndLevelShouldBeConfiguredForValidToken() throws Exception {
        ServiceAuthentication authentication =
                new ServiceAuthentication(
                        "1234",
                        "1234",
                        "1234",
                        "dbf-authentication-dev",
                        Collections.singleton("some.scope"),
                        "SE",
                        "BANKID",
                        "HIGH",
                        "channel",
                        Collections.singletonMap("agreement", 12345L),
                        "session",
                        "household",
                        null,
                        "client"
                );
        authenticate(ImmutableMap.<String, Object>of("am", "BANKID", "al", "HIGH"), authentication);

        final Future<Optional<ServiceRequestContext>> requestContextFuture = serviceContextMock.requestContext();
        serviceContextMock.doFilter();

        final ServiceRequestContext requestContext = requestContextFuture.get().get();


        assertThat(requestContext.getAuthenticationMethod()).isEqualTo(Optional.of("BANKID"));
        assertThat(requestContext.getAuthenticationLevel()).isEqualTo(Optional.of("HIGH"));
    }

    @Test
    public void agreementNumberShouldBeConfiguredIfAvailable() throws Exception {
        ServiceAuthentication authentication =
                new ServiceAuthentication(
                        "1234",
                        "1234",
                        "1234",
                        "dbf-authentication-dev",
                        Collections.singleton("some.scope"),
                        "SE",
                        "BANKID",
                        "HIGH",
                        "channel",
                        Collections.singletonMap("agreement", 12345L),
                        "session",
                        "household",
                        null,
                        "client"
                );

        authenticate(null, authentication);

        final Future<Optional<ServiceRequestContext>> requestContextFuture = serviceContextMock.requestContext();
        serviceContextMock.doFilter();

        final ServiceRequestContext requestContext = requestContextFuture.get().get();

        assertThat(requestContext.getAgreementNumber()).isEqualTo(Optional.of(12345L));
    }
}
