package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.ServiceAuthentication;
import com.nordea.dbf.security.annotation.Ssn;
import org.junit.After;
import org.junit.Test;
import org.springframework.core.MethodParameter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import java.util.Collections;

import static com.nordea.dbf.security.AuthenticationUtil.authenticate;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SsnHandlerMethodArgumentResolverTest {
    private final SsnHandlerMethodArgumentResolver resolver = new SsnHandlerMethodArgumentResolver();

    @After
    public void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    public void ssnCanBeResolved() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotation(Ssn.class)).thenReturn(mock(Ssn.class));

        authenticate(null, createDefaultAuthentication("123456"));

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));

        assertThat(value).isEqualTo("123456");
    }

    private ServiceAuthentication createDefaultAuthentication(String ssn) {
        return new ServiceAuthentication(
                "1234",
                "1234",
                ssn,
                "not-dbf-authentication-dev",
                Collections.singleton("some.scope"),
                "sv",
                "BANKID",
                "HIGH",
                "ch",
                null,
                "s",
                "household",
                Collections.singletonMap("agreement", 12345L), "client"
        );
    }
}
