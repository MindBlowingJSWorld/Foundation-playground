package com.nordea.dbf.security.spring;

import com.google.common.collect.ImmutableMap;
import com.nordea.dbf.security.ServiceAuthentication;
import com.nordea.dbf.security.annotation.AuthenticationLevel;
import com.nordea.dbf.security.annotation.AuthenticationMethod;
import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.MethodParameter;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.Map;

import static com.nordea.dbf.security.AuthenticationUtil.authenticate;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TokenFieldMethodArgumentResolverTest {

    private final TokenFieldMethodArgumentResolver resolver = new TokenFieldMethodArgumentResolver();

    @After
    public void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test(expected = IllegalArgumentException.class)
    public void supportsParameterShouldNotAcceptNullArg() {
        resolver.supportsParameter(null);
    }

    @Test
    public void supportsParameterShouldReturnFalseForUnsupportedAnnotations() {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(Qualifier.class)});

        assertThat(resolver.supportsParameter(parameter)).isFalse();
    }

    @Test
    public void supportsParameterShouldReturnTrueForSupportedAnnotations() {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(AuthenticationMethod.class)}, new Annotation[]{mock(AuthenticationLevel.class)});

        assertThat(resolver.supportsParameter(parameter)).isTrue();
        assertThat(resolver.supportsParameter(parameter)).isTrue();
    }

    @Test
    public void resolveShouldReturnNullIfNoSecurityIsConfigured() throws Exception {
        assertThat(resolver.resolveArgument(mock(MethodParameter.class), mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class))).isNull();

        SecurityContextHolder.setContext(mock(SecurityContext.class));

        assertThat(resolver.resolveArgument(mock(MethodParameter.class), mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class))).isNull();
    }

    @Test
    public void authenticationMethodCanBeResolved() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);
        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(AuthenticationMethod.class)});

        authenticate(ImmutableMap.of("am", "BANKID"), createDefaultAuthentication());

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));

        assertThat(value).isEqualTo("BANKID");
    }

    @Test
    public void authenticationLevelCanBeResolved() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(AuthenticationLevel.class)});

        authenticate(ImmutableMap.of("al", "HIGH"), createDefaultAuthentication());

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));

        assertThat(value).isEqualTo("HIGH");
    }

    @Test
    public void resolveShouldFailIfNoSupportedAnnotationIsFound() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotations()).thenReturn(new Annotation[]{mock(Qualifier.class)});

        authenticate(ImmutableMap.of("am", "BANKID"), createDefaultAuthentication());

        try {
            resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));
            fail("resolve should fail if no supported annotation is found");
        } catch (IllegalArgumentException e) {
        }
    }

    private ServiceAuthentication createDefaultAuthentication() {
        return new ServiceAuthentication(
                "1234",
                "1234",
                "1234",
                "not-dbf-authentication-dev",
                Collections.singleton("some.scope"),
                "sv",
                "BANKID",
                "HIGH",
                "ch",
                null,
                "s",
                "household",
                Collections.singletonMap("agreement", 12345L),
                "client"
        );
    }

    private void configureAuthentication(Map<String, String> tokenDetails) {
        final SecurityContext context = mock(SecurityContext.class);
        final OAuth2Authentication authentication = mock(OAuth2Authentication.class);
        final OAuth2AuthenticationDetails oAuth2AuthenticationDetails = mock(OAuth2AuthenticationDetails.class);

        when(authentication.getDetails()).thenReturn(oAuth2AuthenticationDetails);
        when(oAuth2AuthenticationDetails.getDecodedDetails()).thenReturn(tokenDetails);
        when(context.getAuthentication()).thenReturn(authentication);

        SecurityContextHolder.setContext(context);
    }

}