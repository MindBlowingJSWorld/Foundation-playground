package com.nordea.dbf.security.spring;

import com.nordea.dbf.security.ServiceAuthentication;
import com.nordea.dbf.security.annotation.Uid;
import org.junit.After;
import org.junit.Test;
import org.springframework.core.MethodParameter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;

import java.util.Collections;

import static com.nordea.dbf.security.AuthenticationUtil.authenticate;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UidHandlerMethodArgumentResolverTest {
    private final UidHandlerMethodArgumentResolver resolver = new UidHandlerMethodArgumentResolver();

    @After
    public void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    public void uidCanBeResolved() throws Exception {
        final MethodParameter parameter = mock(MethodParameter.class);

        when(parameter.getParameterAnnotation(Uid.class)).thenReturn(mock(Uid.class));

        authenticate(null, createDefaultAuthentication("123456"));

        final Object value = resolver.resolveArgument(parameter, mock(ModelAndViewContainer.class), mock(NativeWebRequest.class), mock(WebDataBinderFactory.class));

        assertThat(value).isEqualTo("123456");
    }

    private ServiceAuthentication createDefaultAuthentication(String uid) {
        return new ServiceAuthentication(
                "1234",
                uid,
                "1234",
                "dbf-authentication-dev",
                Collections.singleton("some.scope"),
                "SE",
                "BANKID",
                "HIGH",
                "channel",
                Collections.singletonMap("agreement", 12345L),
                "session",
                "household",
                null,
                "client"
        );
    }
}
