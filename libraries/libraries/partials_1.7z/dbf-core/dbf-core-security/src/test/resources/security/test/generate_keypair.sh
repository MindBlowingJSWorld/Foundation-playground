#!/usr/bin/env bash

openssl genrsa -out private_key.pem 2048
openssl pkcs8 -topk8 -inform PEM -outform DER -in private_key.pem -out private_key.der -nocrypt

# openssl rsa -in private_key.pem -inform PEM -out private_key.der -outform DER

# openssl rsa -pubout -in private_key.pem -out public_key.pem
# openssl rsa -inform DER -outform DER -pubout -in private_key.der -out test_public_key.der

openssl rsa -pubout -in private_key.pem -out public_key.pem
# openssl rsa -in public_key.pem -inform PEM -out test_public_key.der -outform DER