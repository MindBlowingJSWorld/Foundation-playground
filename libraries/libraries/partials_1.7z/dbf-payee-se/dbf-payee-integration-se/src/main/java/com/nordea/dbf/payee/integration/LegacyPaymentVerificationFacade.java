package com.nordea.dbf.payee.integration;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentRequestPaymentSegment;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentRequestRecord;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentResponseRecord;
import com.nordea.dbf.payee.service.PGBGValidationReturnCode;
import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.F9MessageHeaderResponseRecord;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import rx.Observable;

import java.util.Optional;

import static com.nordea.dbf.messaging.Observables.manage;

@Service
public class LegacyPaymentVerificationFacade {

    /**
     * The transaction type of the <code>VerifyPaymentRequestRecord</code>.
     */
    private static final int TRANSACTION_TYPE = 7300;

    /**
     * The transaction code of the <code>VerifyPaymentRequestRecord</code>.
     */
    private static final String TRANSACTION_CODE = "F97030";

    /**
     * The function code of the <code>VerifyPaymentRequestRecord</code>.
     */
    private static final int FUNCTION_CODE = 4;

    private BackendConnector<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> connector;

    @Autowired
    public LegacyPaymentVerificationFacade(BackendConnector<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> connector) {
        Validate.notNull(connector, "connector can't be null");
        this.connector = connector;
    }

    /**
     * Verifies payment towards the specified <code>accountKey</code> and returns the validation
     * information returned from the legacy system.
     *
     * @param context    The context in which this request is being executed.
     * @param accountKey The account key of the payment that should be validated.
     * @return Verification information for the provided account key.
     */
    @HystrixCommand(groupKey = "JCA", commandKey = "verifyPayment")
    public Observable<VerifyPaymentResponseRecord> verifyPayment(ServiceRequestContext context,
                                                                 AccountKey accountKey) {
        Validate.notNull(context, "context can't be null");
        Validate.notNull(accountKey, "accountKey can't be null");

        final BackendConnection<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord>
                connection = connector.connect();

        final VerifyPaymentRequestRecord requestRecord = new VerifyPaymentRequestRecord();
        requestRecord.initialize();
        requestRecord.setFunction(FUNCTION_CODE);
        requestRecord.setTransactionType(TRANSACTION_TYPE);
        requestRecord.setTransactionCode(TRANSACTION_CODE);

        final VerifyPaymentRequestPaymentSegment segment = requestRecord.addPayment();
        segment.setType(accountKey.getPrefix().name());
        segment.setPaymentNumber(Long.parseLong(accountKey.getAccountNumber().getAccountNumber()));

        return manage(connection).on(connection
                .execute(Optional.of(context), requestRecord, VerifyPaymentResponseRecord.class)
                .map(verifyPaymentResponseRecord -> {
                    validateResponse(verifyPaymentResponseRecord);
                    return verifyPaymentResponseRecord;
                }));
    }

    /**
     * Validates the provided response record. If the response is erroneous, an exception will be thrown.
     *
     * @param verifyPaymentResponseRecord A response record to validate.
     */
    private void validateResponse(VerifyPaymentResponseRecord verifyPaymentResponseRecord) {
        switch (PGBGValidationReturnCode.fromCode(verifyPaymentResponseRecord.getReturnCode1())) {
            case OK_WITHOUT_OCR:
            case OK_WITH_OCR:
                break;
            case PG_BG_FLAG_MISSING:
                throw ErrorResponses
                        .invalidRequestParameterException("accountNumber", "Not a PG/BG account");
            case CHECK_NUMBER_ERROR:
                throw ErrorResponses.invalidRequestParameterException("accountNumber", "checkNumber error");
            case PG_BG_NUMBER_MISSING:
                throw ErrorResponses
                        .requestedResourceNotFoundException("accountNumber", "PG/BG number missing");
            case PARAMETER_ERROR:
                throw ErrorResponses.invalidRequestParameterException(StringUtils.EMPTY, "Parameter error");
            case INVALID_REFERENCE_NUMBER:
                throw ErrorResponses
                        .invalidRequestParameterException(StringUtils.EMPTY, "Invalid reference number");
            case DATABASE_ERROR:
                throw ErrorResponses.backendErrorException(ErrorResponses.Codes.DATABASE_ERROR, "ims/f9",
                        "database error in response to F97030");
            case CHECKNUMBER_ERROR_REFERENCE_NUMBER:
                throw ErrorResponses.invalidRequestParameterException(StringUtils.EMPTY,
                        "Invalid check number/reference number");
            case PERMISSION_ERROR:
                throw ErrorResponses.invalidRequestParameterException(StringUtils.EMPTY, "Not accessible");
            case SOURCE_ACCOUNT_MISSING:
                throw ErrorResponses
                        .requestedResourceNotFoundException(StringUtils.EMPTY, "Invalid reference number");
            default:
                throw ErrorResponses.backendErrorException(String.valueOf(verifyPaymentResponseRecord.getReturnCode1()), verifyPaymentResponseRecord.getTransactionCode(), "Unknown error");
        }
    }
}
