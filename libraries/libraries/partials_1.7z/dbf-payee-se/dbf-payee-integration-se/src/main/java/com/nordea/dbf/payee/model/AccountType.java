package com.nordea.dbf.payee.model;

import com.google.common.base.Objects;
import org.apache.commons.lang.Validate;

import java.util.regex.Pattern;

public enum AccountType {

    NORMAL_BANK_ACCOUNT("B", Pattern.compile("^[0-9]{7}$"), 7, 7),
    HANDELSBANKEN_ACCOUNT("H", Pattern.compile("^[0-9]{1,9}$"), 1, 9),
    PERSON_NUMBER_ACCOUNT("P", Pattern.compile("^[0-9]{10}$"), 10, 10),
    S("S", Pattern.compile("^[0-9]{1,11}$"), 1, 11), // SEE #TODO below
    T("T", Pattern.compile("^[0-9]{1,10}"), 1, 10),
    GIRO_ACCOUNT("G", Pattern.compile("^[0-9]{1,10}"), 1, 10);

    private final String code;

    private final Pattern pattern;

    private final int minLength;

    private final int maxLength;

    AccountType(String code, Pattern pattern, int minLength, int maxLength) {
        this.code = code;
        this.pattern = pattern;
        this.minLength = minLength;
        this.maxLength = maxLength;
    }

    public String getCode() {
        return code;
    }

    public Pattern getPattern() {
        return pattern;
    }

    public int getMinLength() {
        return minLength;
    }

    public int getMaxLength() {
        return maxLength;
    }

    public static AccountType fromCode(String code) {
        Validate.notEmpty(code, "code can't be null or empty");

        for (final AccountType accountType : values()) {
            if (Objects.equal(accountType.getCode(), code)) {
                return accountType;
            }
        }

        throw new IllegalArgumentException("Legacy account type '" + code + "' is not supported");
    }
}
