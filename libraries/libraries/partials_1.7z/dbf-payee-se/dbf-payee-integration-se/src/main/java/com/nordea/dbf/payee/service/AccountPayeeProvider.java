package com.nordea.dbf.payee.service;

import com.google.common.collect.Iterators;
import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.payee.model.AccountType;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseBanksSegment;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseRecord;
import com.nordea.dbf.payee.service.PayeeProvider;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import rx.Observable;
import rx.functions.Func1;

@Service
public class AccountPayeeProvider implements PayeeProvider {

    private final LegacyBankInfoFacade legacyBankInfoFacade;

    @Autowired
    public AccountPayeeProvider(LegacyBankInfoFacade legacyBankInfoFacade) {
        Validate.notNull(legacyBankInfoFacade, "legacyBankInfoFacade can't be null");
        this.legacyBankInfoFacade = legacyBankInfoFacade;
    }

    @Override
    public Observable<Payee> getPayee(ServiceRequestContext context, final AccountKey accountKey) {
        Validate.notNull(context, "context can't be null");
        Validate.notNull(accountKey, "accountKey can't be null");

        final int clearingNumber = Integer.parseInt(accountKey.getBranchId().get());

        return legacyBankInfoFacade.getBanks(context)
                .flatMap(toBankSegments())
                .filter(isClearingNumberOwner(clearingNumber))
                .map(toValidatedPayee(accountKey));
    }

    /**
     * Returns a function that transforms a <code>BankInfoResponseBanksSegment</code> to
     * a payee given an <code>AccountKey</code>. If the provided account key does not comply
     * with the rules stipulated in the bank segment, the method will fail.
     *
     * @param accountKey The accountKey to validate.
     * @return A function that transforms a bank segment to a {@link Payee}.
     */
    // #TODO for SWEDBANK the validation should base on they account number rule.
    private Func1<BankInfoResponseBanksSegment, Payee> toValidatedPayee(AccountKey accountKey) {
        final String accountNumber = accountKey.getAccountNumber().getAccountNumber();
        final String accountNumberWithoutBranchId = accountNumber.substring(4, accountNumber.length());

        return bank -> {
            final AccountType accountType = AccountType.fromCode(bank.getAccountType());

            validateAccountNumber(accountNumberWithoutBranchId, bank, accountType);

            return new Payee().setBankName(bank.getBankName()).setCountry("SE");
        };
    }

    private void validateAccountNumber(String accountNumberWithoutBranchId, BankInfoResponseBanksSegment bank, AccountType accountType) {
        if (accountNumberWithoutBranchId.length() < accountType.getMinLength()) {
            throw ErrorResponses.invalidRequestParameterException("account_key",
                "Account numbers in bank " + bank.getBankName() + " (" + bank
                    .getBankShortName() + ") must be at least " + accountType
                    .getMinLength() + " digits");
        }

        if (accountNumberWithoutBranchId.length() > accountType.getMaxLength()) {
            throw ErrorResponses.invalidRequestParameterException("account_key",
                "Account numbers in bank " + bank.getBankName() + " (" + bank
                    .getBankShortName() + ") must be at at most " + accountType
                    .getMaxLength() + " digits");
        }
    //#TODO: The code below is not reachable because the ExternalAccountKey has simular pattern matcher
        if (!accountType.getPattern().matcher(accountNumberWithoutBranchId).matches()) {
            throw ErrorResponses.invalidRequestParameterException("account_key",
                "Account numbers in bank " + bank.getBankName() + " (" + bank
                    .getBankShortName() + ") must match pattern /" + accountType.getPattern().pattern() + "/");
        }
    }

    /**
     * Returns a function that given a <code>BankInfoResponseRecord</code> returns an observable
     * of <code>BankInfoResponseBanksSegment</code>.
     *
     * @return A function that allows for flattening a <code>BankInfoResponseRecord</code>.
     */
    private Func1<BankInfoResponseRecord, Observable<BankInfoResponseBanksSegment>> toBankSegments() {
        return bankInfoResponseRecord -> Observable.from(Iterators.<BankInfoResponseBanksSegment>toArray(bankInfoResponseRecord.getBanks(),
            BankInfoResponseBanksSegment.class));
    }

    /**
     * Returns a filter that accepts only the bank segment that includes the provided clearing
     * number.
     *
     * @param clearingNumber The clearing number to select bank from.
     * @return A filter that selects a bank segment given the specified clearing number.
     */
    private Func1<BankInfoResponseBanksSegment, Boolean> isClearingNumberOwner(final int clearingNumber) {
        return bank -> {
            final Integer from = bank.getFromClNo();
            final Integer to = bank.getToClNo();

            return clearingNumber >= from && clearingNumber <= to;
        };
    }
}
