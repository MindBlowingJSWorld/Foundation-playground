package com.nordea.dbf.payee.service;

import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payee.iban.CrossBorderPayeeResolver;
import org.apache.commons.lang.Validate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import rx.Observable;

@Service
public class IbanPayeeProvider implements PayeeProvider {

    private final CrossBorderPayeeResolver crossBorderPayeeResolver;

    @Autowired
    public IbanPayeeProvider(CrossBorderPayeeResolver crossBorderPayeeResolver) {
        Validate.notNull(crossBorderPayeeResolver, "ibanPayeeResolver can't be null");
        this.crossBorderPayeeResolver = crossBorderPayeeResolver;
    }

    @Override
    public Observable<Payee> getPayee(ServiceRequestContext context, AccountKey accountKey) {
        return crossBorderPayeeResolver.lookupIbanNumber(context, accountKey.getAccountNumber().getAccountNumber())
                .map(p -> new Payee()
                        .setCountry(p.getCountry())
                        .setSepaCountry(p.getSepaCountry()));
    }
}
