package com.nordea.dbf.payee.service;

import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.payee.integration.LegacyPaymentVerificationFacade;
import com.nordea.dbf.payee.service.PayeeProvider;
import org.apache.commons.lang.Validate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import rx.Observable;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class LegacyPGBGPayeeProvider implements PayeeProvider {

    private final LegacyPaymentVerificationFacade legacyPaymentVerificationFacade;

    @Autowired
    public LegacyPGBGPayeeProvider(LegacyPaymentVerificationFacade legacyPaymentVerificationFacade) {
        Validate.notNull(legacyPaymentVerificationFacade, "legacyPaymentVerificationProvider can't be null");
        this.legacyPaymentVerificationFacade = legacyPaymentVerificationFacade;
    }

    @Override
    public Observable<Payee> getPayee(ServiceRequestContext context, final AccountKey accountKey) {
        return legacyPaymentVerificationFacade.verifyPayment(context, accountKey).map(verifyPaymentResponseRecord -> {
            final String ocrControl = verifyPaymentResponseRecord.getOcrControl1();
            final int returnCode = verifyPaymentResponseRecord.getReturnCode1();
            final Payee.OcrEnum ocr = ocrRuleFromString(ocrControl, returnCode);

            if (verifyPaymentResponseRecord.getResponseCode() != 0) {
                throw ErrorResponses
                        .backendErrorException(ErrorResponses.Codes.UNKNOWN, "ims", verifyPaymentResponseRecord.getOwnerName1());
            }

            return new Payee().setCountry("SE")
                    .setOwnerName(verifyPaymentResponseRecord.getOwnerName1())
                    .setNextDate(LocalDate.parse(verifyPaymentResponseRecord.getNewPaymentDate1(), DateTimeFormatter.BASIC_ISO_DATE))
                    .setOcr(ocr);
        });
    }

    /**
     * Creates an OCR rule from the specified response.
     *
     * @param ocrControl The value from the response record. Should be H, M or empty.
     * @param returnCode A return code of 1 means that it's a PG account with ocr control. For PG accounts the ocrControl string is empty
     * @return OCR rule.
     */
    private Payee.OcrEnum ocrRuleFromString(String ocrControl, int returnCode) {
        final Payee.OcrEnum ocr;

        if ("H".equals(ocrControl)) {
            ocr = Payee.OcrEnum.hard;
        } else if ("M".equals(ocrControl)) {
            ocr = Payee.OcrEnum.soft;
        } else if (returnCode == 1) {
            ocr = Payee.OcrEnum.hard;
        } else {
            ocr = Payee.OcrEnum.no;
        }

        return ocr;
    }
}
