package com.nordea.dbf.payee.service;


public enum PGBGValidationReturnCode {

    OK_WITHOUT_OCR(0),
    OK_WITH_OCR(1),
    PG_BG_FLAG_MISSING(10),
    CHECK_NUMBER_ERROR(20),
    PG_BG_NUMBER_MISSING(21),
    PARAMETER_ERROR(22),
    INVALID_REFERENCE_NUMBER(23),
    DATABASE_ERROR(24),
    CHECKNUMBER_ERROR_REFERENCE_NUMBER(25),
    PERMISSION_ERROR(26),
    SOURCE_ACCOUNT_MISSING(27),
    UNKNOWN(-1);

    private final int code;

    PGBGValidationReturnCode(int code) {
        this.code = code;
    }

    public static PGBGValidationReturnCode fromCode(int code) {
        for (final PGBGValidationReturnCode value : values()) {
            if (value.code == code) {
                return value;
            }
        }

        return UNKNOWN;
    }

}
