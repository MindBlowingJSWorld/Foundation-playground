package com.nordea.dbf.payee.service;

import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import rx.Observable;

public interface PayeeProvider {

    Observable<Payee> getPayee(ServiceRequestContext context, AccountKey accountKey);

}
