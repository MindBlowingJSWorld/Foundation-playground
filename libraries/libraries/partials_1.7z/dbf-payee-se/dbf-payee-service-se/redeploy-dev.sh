#!/usr/bin/env bash

targets=RBO-service-cluster02
name=dbf-payee-se-dev02
adminUrl=t3://vda1cs0355.qaoneadr.local:7210
user=deployer
password=deployer1234
source=target/dbf-payee-se-service-0.1-SNAPSHOT.war

mvn com.oracle.weblogic:weblogic-maven-plugin:undeploy -P!dev,undeploy \
    -Dtargets=$targets      \
    -Dname=$name            \
    -Dadminurl=$adminUrl    \
    -Duser=$user            \
    -Dpassword=$password

mvn com.oracle.weblogic:weblogic-maven-plugin:deploy -P!dev,deploy \
    -Dremote=true \
    -Dupload=true \
    -Dsource=$source    \
    -Dtargets=$targets  \
    -Dname=$name        \
    -Dadminurl=$adminUrl    \
    -Duser=$user            \
    -Dpassword=$password