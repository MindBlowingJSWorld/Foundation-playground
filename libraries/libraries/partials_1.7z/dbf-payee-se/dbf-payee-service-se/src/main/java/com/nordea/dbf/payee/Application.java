package com.nordea.dbf.payee;

import com.nordea.dbf.annotation.EnableServiceConfiguration;
import com.nordea.dbf.audit.annotation.EnableAuditing;
import com.nordea.dbf.security.annotation.EnableServiceSecurity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableServiceConfiguration
@EnableServiceSecurity
@EnableAuditing
@EnableHystrix
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
