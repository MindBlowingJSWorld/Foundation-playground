package com.nordea.dbf.payee.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.dbf.integration.connect.ims.Configurations;
import com.nordea.dbf.integration.connect.ims.ImsConfiguration;
import com.nordea.dbf.integration.connect.ims.ImsConfigurationSupplier;
import com.nordea.dbf.integration.connect.ims.f9.F9ImsConnectorImpl;
import com.nordea.dbf.integration.connect.ims.jca.JCAConnectionSupplier;
import com.nordea.dbf.integration.connect.lx.BackendWrapper;
import com.nordea.dbf.integration.connect.lx.DefaultBackendWrapper;
import com.nordea.dbf.integration.connect.lx.LxConnector;
import com.nordea.dbf.integration.connect.lx.LxConnectorImpl;
import com.nordea.dbf.integration.logging.InteractionLogger;
import com.nordea.dbf.integration.logging.JSONInteractionLogger;
import com.nordea.dbf.integration.logging.SLF4JMessageSink;
import com.nordea.dbf.integration.logging.jca.JCALoggingAspect;
import com.nordea.dbf.payee.iban.CrossBorderPayeeResolver;
import com.nordea.dbf.payee.iban.lx.LxCrossBorderPayeeResolver;
import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.F9MessageHeaderResponseRecord;
import com.nordea.sc.jca.BackendInteractionSpec;
import com.nordea.serviceconsumer.providers.ConfigurationProvider;
import com.nordea.serviceconsumer.providers.JCAConnectionProvider;
import com.nordea.serviceconsumer.providers.defaults.JCAConnectionProviderImpl;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.web.context.request.async.DeferredResult;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import java.time.LocalDate;

@Configuration
@PropertySources({
        @PropertySource(value = "classpath:payee_${com.nordea.environmenttype}.properties", ignoreResourceNotFound = true),
        @PropertySource("classpath:payee.properties"),
        @PropertySource(value = "file:/${com.nordea.midas.appProperties}/common.properties", ignoreResourceNotFound = true)
})
public class PayeeConfiguration {

    @Autowired
    private Environment environment;

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .ignoredParameterTypes(LocalDate.class)
                .genericModelSubstitutes(DeferredResult.class)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.nordea.dbf.payee"))
                .build()
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        return new ApiInfo(
                "Payee REST API",
                "The API for the payee service.",
                "API TOS",
                "Terms of service",
                "ameya.gargesh@consult.nordea.com",
                "License of API",
                "API license URL");
    }


    @Bean
    public ConfigurationProvider configurationProvider() {
        return new ConfigurationProvider() {
            @Override
            public String getProperty(String name, String defaultValue) {
                return environment.getProperty(name, defaultValue);
            }

            @Override
            public String getProperty(String name) {
                return environment.getProperty(name);
            }
        };
    }

    @Bean
    public BackendWrapper backendWrapper() {
        return new DefaultBackendWrapper();
    }

    @Bean
    public LxConnector lxConnector(ConfigurationProvider configurationProvider, BackendWrapper backendWrapper) {
        return new LxConnectorImpl(configurationProvider, "osb", backendWrapper);
    }

    @Bean
    public CrossBorderPayeeResolver crossBorderPayeeResolver(LxConnector lxConnector) {
        return new LxCrossBorderPayeeResolver(lxConnector);
    }


    @Bean
    public JCAConnectionProvider jcaConnectionProvider() {
        return new JCAConnectionProviderImpl();
    }

    @Bean
    public JCAConnectionSupplier jcaConnectionSupplier(
            final JCAConnectionProvider jcaConnectionProvider, final ConfigurationProvider configurationProvider) {
        return () -> jcaConnectionProvider.getConnection(configurationProvider);
    }

    @Bean
    public ImsConfigurationSupplier imsConfigurationSupplier(ConfigurationProvider configurationProvider) {
        return Configurations.singleton(ImsConfiguration.builder()
                .serverIdentifier(configurationProvider.getProperty("jca.serveridentifier"))
                .backendType(BackendInteractionSpec.BackendType.TYPE_GENERIC)
                .debugLog(Boolean.valueOf(configurationProvider.getProperty("jca.debug", "false")))
                .build());
    }

    @Bean
    public BackendConnector<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> backendConnector(
            JCAConnectionSupplier jcaConnectionSupplier, ImsConfigurationSupplier imsConfigurationSupplier) {
        return new F9ImsConnectorImpl(jcaConnectionSupplier, imsConfigurationSupplier);
    }

    @Bean
    public LegacyBankInfoFacade legacyBankInfoFacade(BackendConnector<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> connector) {
        return new LegacyBankInfoFacade(connector);
    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer properties() {
        return new PropertySourcesPlaceholderConfigurer();
    }

    @Bean
    @Profile("debug")
    public JCALoggingAspect jcaLoggingAspect() {
        return new JCALoggingAspect();
    }

    @Bean
    @Profile("debug")
    @Autowired(required = false)
    public InteractionLogger interactionLogger(ObjectMapper objectMapper) {
        return new JSONInteractionLogger(
                new SLF4JMessageSink(LoggerFactory.getLogger("interaction")),
                objectMapper == null ? new ObjectMapper() : objectMapper);
    }
}
