package com.nordea.dbf.payee.resources;

import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.ErrorResponses;
import com.nordea.dbf.json.JsonUtils;
import com.nordea.dbf.payee.service.AccountPayeeProvider;
import com.nordea.dbf.payee.service.IbanPayeeProvider;
import com.nordea.dbf.payee.service.LegacyPGBGPayeeProvider;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.NoSuchElementException;

import static com.nordea.dbf.messaging.Observables.deferredResultOf;

@RestController
public class PayeeResourceImpl {

    private static final Logger LOGGER = LoggerFactory.getLogger(PayeeResourceImpl.class);

    private final AccountPayeeProvider accountPayeeProvider;
    private final LegacyPGBGPayeeProvider legacyPGBGPayeeProvider;
    private final IbanPayeeProvider ibanPayeeProvider;

    @Autowired
    public PayeeResourceImpl(AccountPayeeProvider accountPayeeProvider,
                             LegacyPGBGPayeeProvider legacyPGBGPayeeProvider,
                             IbanPayeeProvider ibanPayeeProvider) {
        this.accountPayeeProvider = accountPayeeProvider;
        this.legacyPGBGPayeeProvider = legacyPGBGPayeeProvider;
        this.ibanPayeeProvider = ibanPayeeProvider;
    }

    @ApiOperation(value = "Get Payees", nickname = "getPayee", httpMethod = "GET")
    @RequestMapping(value = "/banking/payee/{accountKey}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses(
            @ApiResponse(code = 200, message = "SUCCESS")
    )
    public DeferredResult<Payee> getAccountNumber(@PathVariable("accountKey") String accountKeyAsString, ServiceRequestContext context) {
        final AccountKey accountKey;

        try {
            accountKey = AccountKey.fromString(accountKeyAsString);
        } catch (IllegalArgumentException e) {
            LOGGER.info("Got invalid account key for validated account lookup: {}", accountKeyAsString);
            LOGGER.error(ExceptionUtils.getStackTrace(e));
            throw ErrorResponses.invalidRequestParameterException("accountKey", e.getMessage());
        }

        switch (accountKey.getPrefix()) {
            case PG:
            case BG:
                return deferredResultOf(legacyPGBGPayeeProvider.getPayee(context, accountKey), result -> {
                    LOGGER.info("Looked up PG/BG payee for accountKey={}: payee={}", accountKey, JsonUtils.toJson(result));
                });
            case LBAN:
                return deferredResultOf(accountPayeeProvider.getPayee(context, accountKey), throwable -> {
                    if (throwable instanceof NoSuchElementException) {
                        LOGGER.info("No payee resolved for provider accountKey={}", accountKeyAsString);
                        return ErrorResponses.requestedResourceNotFoundException("account_key",
                                "No account receiver found for account key '" + accountKeyAsString + "'");
                    }

                    LOGGER.warn("Failed to lookup payee for accountKey={}", accountKey);

                    return throwable;
                }, result -> LOGGER.info("Looked up LBAN payee for accountKey={}: payee={}", accountKey, JsonUtils.toJson(result)));
            case IBAN: {
                return deferredResultOf(ibanPayeeProvider.getPayee(context, accountKey), result -> {
                    LOGGER.info("Looked up IBAN payee for accountKey={}: payee={}", accountKey, JsonUtils.toJson(result));
                });
            }
            default:
                throw ErrorResponses.invalidRequestParameterException("accountKey",
                        "Account key not supported (PG/BG/LBAN/IBAN supported)");
        }
    }

}
