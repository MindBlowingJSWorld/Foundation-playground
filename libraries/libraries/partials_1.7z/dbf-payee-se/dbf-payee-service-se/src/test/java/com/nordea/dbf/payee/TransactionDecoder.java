package com.nordea.dbf.payee;

import com.nordea.infra.record.converters.CPConverter;
import org.apache.commons.lang.StringUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TransactionDecoder {

    public static final Pattern PATTERN = Pattern.compile("[0-9,A-F]{4}:(?<group1>( [0-9,A-F]{2})+) (-(?<group2>( [0-9,A-F]{2})+))?");

    public static void main(String[] args) throws Exception {
        final byte[] buffer = toBytes(args[0]);
        final CPConverter converter = CPConverter.getConverter("cp1143");
        final char[] result = new char[buffer.length];

        converter.getChars(buffer, 0, buffer.length, result);

        System.out.println(new String(result));
    }

    private static byte[] toBytes(String arg) throws IOException {
        final ArrayList<String> allBytes = new ArrayList<>(256);

        try (final InputStream in = new FileInputStream(arg)) {
            final BufferedReader reader = new BufferedReader(new InputStreamReader(in));

            for (String line; (line = reader.readLine()) != null; ) {
                final Matcher matcher = PATTERN.matcher(line);

                System.out.println(line);

                if (!matcher.lookingAt()) {
                    throw new IllegalArgumentException("Unsupported format: " + line);
                }

                final String group1 = matcher.group("group1");
                final String group2 = matcher.group("group2");
                final String bytesAsString = (group1 + (group2 == null ? StringUtils.EMPTY : group2)).trim();
                final String[] bytes = bytesAsString.split("\\s+");

                allBytes.addAll(Arrays.asList(bytes));
            }
        }

        final byte[] buffer = new byte[allBytes.size()];

        for (int i = 0; i < allBytes.size(); i++) {
            buffer[i] = (byte) Integer.parseInt(allBytes.get(i), 16);
        }
        return buffer;
    }

}

