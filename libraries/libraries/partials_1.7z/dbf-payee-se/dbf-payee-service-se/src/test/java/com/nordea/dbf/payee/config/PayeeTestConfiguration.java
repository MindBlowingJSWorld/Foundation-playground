package com.nordea.dbf.payee.config;

import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.dbf.integration.connect.ims.f9.F9ImsConnection;
import com.nordea.dbf.integration.connect.ims.f9.F9ImsConnector;
import com.nordea.dbf.payee.iban.CrossBorderPayeeResolver;
import com.nordea.dbf.payee.integration.LegacyPaymentVerificationFacade;
import com.nordea.dbf.payee.service.AccountPayeeProvider;
import com.nordea.dbf.payee.service.IbanPayeeProvider;
import com.nordea.dbf.payee.service.LegacyPGBGPayeeProvider;
import com.nordea.pn.service.records.F9MessageHeaderRequestRecord;
import com.nordea.pn.service.records.F9MessageHeaderResponseRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Configuration
public class PayeeTestConfiguration {

    @Bean
    @Autowired
    @Primary
    public AccountPayeeProvider accountPayeeProvider(LegacyBankInfoFacade legacyBankInfoFacade) {
        return new AccountPayeeProvider(legacyBankInfoFacade);
    }

    @Bean
    @Primary
    public CrossBorderPayeeResolver crossBorderPayeeResolver() {
        return mock(CrossBorderPayeeResolver.class);
    }

    @Bean
    @Autowired
    @Primary
    public IbanPayeeProvider ibanPayeeProvider(CrossBorderPayeeResolver crossBorderPayeeResolver) {
        return new IbanPayeeProvider(crossBorderPayeeResolver);
    }

    @Bean
    @Autowired
    @Primary
    F9ImsConnector f9ImsConnector(F9ImsConnection f9ImsConnection) {
        F9ImsConnector f9ImsConnector = mock(F9ImsConnector.class);
        when(f9ImsConnector.connect()).thenReturn(f9ImsConnection);
        return f9ImsConnector;
    }

    @Bean
    @Primary
    F9ImsConnection f9ImsConnection() {
        return mock(F9ImsConnection.class);
    }

    @Bean
    @Autowired
    @Primary
    LegacyPaymentVerificationFacade legacyPaymentVerificationFacade(BackendConnector<F9MessageHeaderRequestRecord, F9MessageHeaderResponseRecord> connector) {
        return new LegacyPaymentVerificationFacade(connector);
    }

    @Bean
    @Primary
    @Autowired
    public LegacyPGBGPayeeProvider pgbgPayeeProvider(LegacyPaymentVerificationFacade legacyPaymentVerificationFacade) {
        return new LegacyPGBGPayeeProvider(legacyPaymentVerificationFacade);
    }

    @Bean
    public LegacyBankInfoFacade legacyBankInfoFacade() {
        return mock(LegacyBankInfoFacade.class);
    }
}
