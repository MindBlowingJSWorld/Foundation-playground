package com.nordea.dbf.payee.integration;

import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.BackendException;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.integration.connect.BackendConnection;
import com.nordea.dbf.integration.connect.BackendConnector;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentRequestPaymentSegment;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentRequestRecord;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentResponseRecord;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import rx.Observable;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class LegacyPaymentVerificationFacadeTest {

  private static final int ACCOUNT_IS_NOT_BG_PG = 10;
  private static final int ACCOUNT_NUMBER_IS_NOT_OK = 20;
  private static final int BGPG_NUMBER_IS_MISSING = 21;
  private static final int PARAMETER_ERROR = 22;
  private static final int INVALID_REFERENCE_NUMBER = 23;
  private static final int DATABASE_ERROR = 24;
  private static final int CHECK_NUMBER_ERROR_REFERENCE_NUMBER = 25;
  private static final int PERMISSION_ERROR = 26;
  private static final int SOURCE_ACCOUNT_MISSING = 27;
  private static final int UNKNOWN = -1;

  private final BackendConnector connector = mock(BackendConnector.class);
  private final LegacyPaymentVerificationFacade provider =
          new LegacyPaymentVerificationFacade(connector);
  private final ServiceRequestContext context = mock(ServiceRequestContext.class);
  private final BackendConnection connection = mock(BackendConnection.class);

  @Before public void setup() {
    when(connector.connect()).thenReturn(connection);
  }

  @Test(expected = IllegalArgumentException.class) public void connectorCannotBeNull() {
    new LegacyBankInfoFacade(null);
  }

  @Test public void verifyPaymentShouldRejectInvalidArguments() {
    try {
      provider.verifyPayment(null, AccountKey.fromString("PG-1234"));
      fail("null context should be rejected");
    } catch (IllegalArgumentException e) {
    }

    try {
      provider.verifyPayment(context, null);
      fail("null accountKey should be rejected");
    } catch (IllegalArgumentException e) {
    }
  }

  @Test public void verifyPaymentShouldReturnResponseFromTransaction() {
    final VerifyPaymentResponseRecord responseRecord = mock(VerifyPaymentResponseRecord.class);

    when(connection
        .execute(eq(Optional.of(context)), anyObject(), eq(VerifyPaymentResponseRecord.class)))
        .thenReturn(Observable.just(responseRecord));

    assertThat(
        provider.verifyPayment(context, AccountKey.fromString("PG-1234")).toBlocking().single())
        .isEqualTo(responseRecord);

    final ArgumentCaptor<VerifyPaymentRequestRecord> requestCaptor =
        ArgumentCaptor.forClass(VerifyPaymentRequestRecord.class);

    verify(connection).execute(eq(Optional.of(context)), requestCaptor.capture(),
        eq(VerifyPaymentResponseRecord.class));

    final VerifyPaymentRequestRecord request = requestCaptor.getValue();

    assertThat(request.getTransactionCode()).isEqualTo("F97030");
    assertThat(request.getTransactionType()).isEqualTo(7300);
    assertThat(request.getNumberOfPGBG()).isEqualTo(1);

    final VerifyPaymentRequestPaymentSegment segment = (VerifyPaymentRequestPaymentSegment) request.getPayment().next();
    assertThat(segment.getType()).isEqualTo("PG");
    assertThat(segment.getPaymentNumber()).isEqualTo(1234L);
  }

  @Test(expected = BadRequestException.class) public void verifyPaymentShouldThrowExceptionWhenAccountIsNotBGPG() {
    backendErrorTest(ACCOUNT_IS_NOT_BG_PG);
  }

  @Test(expected = BadRequestException.class) public void verifyPaymentShouldThrowExceptionWhenAccountNumberIsNotOk() {
    backendErrorTest(ACCOUNT_NUMBER_IS_NOT_OK);
  }

  @Test(expected = NotFoundException.class) public void verifyPaymentShouldThrowExceptionAccountNumberMissing() {
    backendErrorTest(BGPG_NUMBER_IS_MISSING);
  }

  @Test(expected = BadRequestException.class) public void verifyPaymentShouldThrowExceptionParameterError() {
    backendErrorTest(PARAMETER_ERROR);
  }

  @Test(expected = BadRequestException.class) public void verifyPaymentShouldThrowExceptionInvalidReferenceNumber() {
    backendErrorTest(INVALID_REFERENCE_NUMBER);
  }

  @Test(expected = BackendException.class) public void verifyPaymentShouldThrowExceptionWhenDatabaseError() {
    backendErrorTest(DATABASE_ERROR);
  }

  @Test(expected = BadRequestException.class) public void verifyPaymentShouldThrowExceptionWhenCheckNumberError() {
    backendErrorTest(CHECK_NUMBER_ERROR_REFERENCE_NUMBER);
  }

  @Test(expected = BadRequestException.class) public void verifyPaymentShouldThrowExceptionWhenPermissionError() {
    backendErrorTest(PERMISSION_ERROR);
  }

  @Test(expected = NotFoundException.class) public void verifyPaymentShouldThrowExceptionWhenSourceAccountMissing() {
    backendErrorTest(SOURCE_ACCOUNT_MISSING);
  }

  @Test(expected = BackendException.class) public void verifyPaymentShouldThrowExceptionWhenUnknownErrorCode() {
    backendErrorTest(UNKNOWN);
  }

  private void backendErrorTest(int errorCode) {
    final VerifyPaymentResponseRecord responseRecord = mock(VerifyPaymentResponseRecord.class);

    when(connection
            .execute(eq(Optional.of(context)), anyObject(), eq(VerifyPaymentResponseRecord.class)))
            .thenReturn(Observable.just(responseRecord));
    when(responseRecord.getReturnCode1()).thenReturn(errorCode);

    provider.verifyPayment(context, AccountKey.fromString("PG-1234")).toBlocking().single();
  }

}
