package com.nordea.dbf.payee.integrationtest;

import com.nordea.dbf.payee.Application;
import com.nordea.dbf.payee.config.PayeeTestConfiguration;
import com.nordea.dbf.test.Resetable;
import com.nordea.dbf.test.annotation.ServiceIntegrationTest;
import com.nordea.dbf.test.http.Path;
import com.nordea.dbf.test.jca.JCARouter;
import com.nordea.dbf.test.jca.config.JCATestConfiguration;
import com.nordea.dbf.test.rest.Requests;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = {Application.class, PayeeTestConfiguration.class, JCATestConfiguration.class})
@WebAppConfiguration
@ServiceIntegrationTest
public abstract class AbstractIntegrationTestBase {

    @Value("${local.server.port}")
    protected int port;

    protected String baseUrl;

    protected RestTemplate rest;

    protected Path basePath;

    @Autowired
    protected JCARouter jca;

    @Autowired(required = false)
    private List<Resetable> resetableResources;

    @BeforeClass
    public static void configureEnvironment() throws Exception {
        System.setProperty("com.nordea.environmenttype", "UNIT_TEST");
        System.setProperty("dbf.payee.bankinfo.source", "legacy");
    }

    @Before
    public void configureRest() {
        if (resetableResources != null) {
            resetableResources.forEach(Resetable::reset);
        }

        this.baseUrl = "http://localhost:" + port;
        this.basePath = new Path(baseUrl);
        this.rest = new RestTemplate();

        rest.setErrorHandler(new DefaultResponseErrorHandler());
        Requests.configure(rest);
    }
}
