package com.nordea.dbf.payee.integrationtest;

import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseBanksSegment;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseRecord;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Test;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

@HouseholdUser(userName = "194008010011", agreement = 2172332)
public class AccountRetrievalIntegrationTest extends AbstractIntegrationTestBase {

    @Autowired
    LegacyBankInfoFacade legacyBankInfoFacade;

    @Test
    public void validAccountNumberCanBeLookedUp() {
        BankInfoResponseRecord responseRecord = new BankInfoResponseRecord();
        final BankInfoResponseBanksSegment bank = responseRecord.addBanks();

        bank.setBankShortName("B1");
        bank.setBankName("Bank1");
        bank.setAccountType("B");
        bank.setFromClNo(1000);
        bank.setToClNo(1999);

        when(legacyBankInfoFacade.getBanks(any(ServiceRequestContext.class)))
                .thenReturn(Observable.just(responseRecord));

        final Payee payee = rest.getForObject("http://localhost:" + port + "/banking/payee/LBAN-SE-10001234567",
                Payee.class);

        assertThat(payee).isEqualTo(new Payee().setCountry("SE").setBankName("Bank1"));
    }
}
