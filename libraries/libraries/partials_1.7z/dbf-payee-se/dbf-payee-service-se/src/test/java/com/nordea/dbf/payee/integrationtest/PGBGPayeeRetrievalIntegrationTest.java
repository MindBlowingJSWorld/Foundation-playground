package com.nordea.dbf.payee.integrationtest;

import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.integration.connect.ims.f9.F9ImsConnection;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentRequestRecord;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentResponseRecord;
import com.nordea.dbf.test.spec.auth.HouseholdUser;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import rx.Observable;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;

@HouseholdUser(userName = "194008010011", agreement = 2172332)
public class PGBGPayeeRetrievalIntegrationTest extends AbstractIntegrationTestBase {

    @Autowired
    F9ImsConnection f9ImsConnection;

    @Test
    public void validPgPayeeCanBeRetrieved() {
        VerifyPaymentResponseRecord responseRecord = new VerifyPaymentResponseRecord();
        responseRecord.setOwnerName1("APayee");
        responseRecord.setOcrControl1("H");
        responseRecord.setNewPaymentDate1("20150530");
        responseRecord.setReturnCode1(0);

        when(f9ImsConnection.execute(any(), isA(VerifyPaymentRequestRecord.class), any(Class.class)))
                .thenReturn(Observable.just(responseRecord));

        final Payee payee = rest.getForObject("http://localhost:" + port + "/banking/payee/PG-1234", Payee.class);

        assertThat(payee.getCountry()).isEqualTo("SE");
        assertThat(payee.getNextDate()).isEqualTo(LocalDate.of(2015, 5, 30));
        assertThat(payee.getOwnerName()).isEqualTo("APayee");
        assertThat(payee.getOcr()).isEqualTo(Payee.OcrEnum.hard);
    }
}
