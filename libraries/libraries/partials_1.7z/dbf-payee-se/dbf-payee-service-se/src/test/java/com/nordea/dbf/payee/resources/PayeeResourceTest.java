package com.nordea.dbf.payee.resources;

import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.errorhandling.exception.GenericServiceResponseException;
import com.nordea.dbf.payee.service.AccountPayeeProvider;
import com.nordea.dbf.payee.service.IbanPayeeProvider;
import com.nordea.dbf.payee.service.LegacyPGBGPayeeProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MvcResult;
import rx.Observable;

import java.time.LocalDate;
import java.util.NoSuchElementException;

import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringJUnit4ClassRunner.class)
public class PayeeResourceTest extends ResourceTestBase {

    private final AccountPayeeProvider accountPayeeProvider;
    private final LegacyPGBGPayeeProvider legacyPGBGPayeeProvider;
    private final IbanPayeeProvider ibanPayeeProvider;

    private final PayeeResourceImpl payeeResource;

    public PayeeResourceTest() {
        accountPayeeProvider = mock(AccountPayeeProvider.class);
        legacyPGBGPayeeProvider = mock(LegacyPGBGPayeeProvider.class);
        ibanPayeeProvider = mock(IbanPayeeProvider.class);

        payeeResource = new PayeeResourceImpl(accountPayeeProvider, legacyPGBGPayeeProvider, ibanPayeeProvider);
    }

    @Before
    public void setUp() throws Exception {
        super.setUp(payeeResource);
    }

    @Test
    public void getPayeeFromBGPGWithCorrectAccountKeyThroughResource() {
        // given
        final String accountKeyAsString = "PG-1234";
        final Payee expected = new Payee().setOwnerName("My Payee").setOcr(Payee.OcrEnum.no).setNextDate(LocalDate.parse("2016-02-08"));

        final AccountKey accountKey = AccountKey.fromString(accountKeyAsString);
        when(legacyPGBGPayeeProvider.getPayee(same(serviceRequestContext),eq(accountKey))).thenReturn(Observable.just(expected));

        // when
        MvcResult mvcResult;
        try {
            mvcResult = mockMvc.perform(get("/banking/payee/"+ accountKeyAsString))
                    .andExpect(request().asyncStarted())
                    .andReturn();

            // then
            mockMvc.perform(asyncDispatch(mvcResult))
                    .andExpect(status().isOk())
                    .andExpect(content().json(objectMapper.writeValueAsString(expected)));


        } catch (Exception ex) {
            fail("Something is really wrong here!");
        }

    }

    @Test
    public void getPayeeFromLBANWithCorrectAccountKeyThroughResource() {
        // given
        final String accountKeyAsString = "LBAN-SE-15001231231";
        final Payee expected = new Payee().setBankName("MyBank1").setCountry("SE");

        final AccountKey accountKey = AccountKey.fromString(accountKeyAsString);
        when(accountPayeeProvider.getPayee(same(serviceRequestContext),eq(accountKey))).thenReturn(Observable.just(expected));

        // when
        MvcResult mvcResult;
        try {
            mvcResult = mockMvc.perform(get("/banking/payee/"+ accountKeyAsString))
                    .andExpect(request().asyncStarted())
                    .andReturn();

            // then
            mockMvc.perform(asyncDispatch(mvcResult))
                    .andExpect(status().isOk())
                    .andExpect(content().json(objectMapper.writeValueAsString(expected)));


        } catch (Exception ex) {
            fail("Something is really wrong here!");
        }
    }

    @Test
    public void getPayeeFromLBANWithCorrectAccountKeyThroughResourceThrowOfNoSuchElement() {
        // given
        final String accountKeyAsString = "LBAN-SE-15001231231";
        final AccountKey accountKey = AccountKey.fromString(accountKeyAsString);

        when(accountPayeeProvider.getPayee(same(serviceRequestContext),eq(accountKey))).thenReturn(Observable.error(new NoSuchElementException()));

        // when
        MvcResult mvcResult;
        try {
            mvcResult = mockMvc.perform(get("/banking/payee/"+ accountKeyAsString))
                    .andExpect(request().asyncStarted())
                    .andReturn();

            // then
            mockMvc.perform(asyncDispatch(mvcResult))
                    .andExpect(status().isNotFound());


        } catch (Exception ex) {
            fail("Something is really wrong here!");
        }

    }

    @Test
    public void getPayeeFromLBANWithCorrectAccountKeyThroughResourceThrowOfOther() {
        // given
        final String accountKeyAsString = "LBAN-SE-15001231231";
        final AccountKey accountKey = AccountKey.fromString(accountKeyAsString);

        when(accountPayeeProvider.getPayee(same(serviceRequestContext),eq(accountKey)))
                .thenReturn(Observable.error(new GenericServiceResponseException(new Error(),500)));

        // when
        MvcResult mvcResult;
        try {
            mvcResult = mockMvc.perform(get("/banking/payee/"+ accountKeyAsString))
                    .andExpect(request().asyncStarted())
                    .andReturn();

            // then
            mockMvc.perform(asyncDispatch(mvcResult))
                    .andExpect(status().isInternalServerError());


        } catch (Exception ex) {
            fail("Something is really wrong here!");
        }

    }

    @Test
    public void getPayeeFromIBANWithCorrectAccountKeyThroughResource() {
        // given
        final String accountKeyAsString = "IBAN-NDEASESS-SE3630000000032022204581";
        final AccountKey accountKey = AccountKey.fromString(accountKeyAsString);

        final Payee expected = new Payee()
                .setCountry("SE")
                .setSepaCountry(true);


        when(ibanPayeeProvider.getPayee(same(serviceRequestContext),eq(accountKey))).thenReturn(Observable.just(expected));

        // when
        MvcResult mvcResult;
        try {
            mvcResult = mockMvc.perform(get("/banking/payee/"+ accountKeyAsString))
                    .andExpect(request().asyncStarted())
                    .andReturn();

            // then
            mockMvc.perform(asyncDispatch(mvcResult))
                    .andExpect(status().isOk())
                    .andExpect(content().json(objectMapper.writeValueAsString(expected)));


        } catch (Exception ex) {
            fail("Something is really wrong here!");
        }

    }

    @Test
    public void getPayeeWithInCorrectAccountKeyThroughResource() {
        // given
        final String accountKeyAsString = "LBA-SE-150";

        // when
        try {
            mockMvc.perform(get("/banking/payee/"+ accountKeyAsString))
        // then
                    .andExpect(status().isBadRequest());

        } catch (Exception ex) {
            fail("Something is really wrong here!");
        }
    }
}
