package com.nordea.dbf.payee.resources;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nordea.dbf.api.model.Error;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.http.errorhandling.exception.HasHttpStatus;
import com.nordea.dbf.http.errorhandling.exception.NotFoundException;
import com.nordea.dbf.json.JsonUtils;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

@SpringApplicationConfiguration(classes = MockServletContext.class)
@WebAppConfiguration
public class ResourceTestBase {

    @Mock
    protected ServiceRequestContext serviceRequestContext;

    @Mock
    private HandlerMethodArgumentResolver handlerMethodArgumentResolver;

    @Mock
    private HandlerExceptionResolver handlerExceptionResolver;


    @Mock
    protected View mockView;

    protected MockMvc mockMvc;

    protected ObjectMapper objectMapper = Jackson2ObjectMapperBuilder.json().build();

    public void setUp(Object resource) throws Exception {
        MockitoAnnotations.initMocks(this);
        mockMvc = standaloneSetup(resource)
                .setCustomArgumentResolvers(handlerMethodArgumentResolver)
                .setHandlerExceptionResolvers(handlerExceptionResolver)
                .setSingleView(mockView)
                .build();

        when(handlerMethodArgumentResolver.supportsParameter(any(MethodParameter.class))).thenAnswer(invocation -> (((MethodParameter)invocation.getArguments()[0]).getParameterType().equals(ServiceRequestContext.class)));
        when(handlerMethodArgumentResolver.resolveArgument(anyObject(), anyObject(), anyObject(), anyObject())).thenReturn(serviceRequestContext);
        when(handlerExceptionResolver.resolveException(any(HttpServletRequest.class),any(HttpServletResponse.class),any(Object.class),any(Exception.class))).thenAnswer(createModelAndView());

    }

    private Answer<ModelAndView> createModelAndView() {

        return new Answer<ModelAndView>() {
            @Override
            public ModelAndView answer(InvocationOnMock invocation) throws Throwable {
                MappingJackson2JsonView jsonView = new MappingJackson2JsonView();
                Error errorResponse = null;
                Exception exception = (Exception)invocation.getArguments()[3];
                HttpServletResponse response = (HttpServletResponse) invocation.getArguments() [1];
                if (exception instanceof HasHttpStatus ) {
                    response.setStatus(((HasHttpStatus)exception).getStatus());
                }
                    errorResponse = getResponse(exception, Error.class);
                if (exception instanceof NotFoundException) {
                    response.setStatus(HttpStatus.NOT_FOUND.value());
                }
                if (exception instanceof BadRequestException) {
                    response.setStatus(HttpStatus.BAD_REQUEST.value());
                }
                jsonView.setExtractValueFromSingleKeyModel(true);
                return new ModelAndView(jsonView, "error", errorResponse);
            }

        };
    }
    private <T> T getResponse(Exception exception, Class<T> responseClass) {
        T response = null;
        try {
            response = JsonUtils.fromJson(exception.getMessage(), responseClass);
        } catch (JsonProcessingException e) {
            try {
                response = responseClass.newInstance();
            } catch (InstantiationException | IllegalAccessException e1) {
            }
        }
        return response;

    }

}
