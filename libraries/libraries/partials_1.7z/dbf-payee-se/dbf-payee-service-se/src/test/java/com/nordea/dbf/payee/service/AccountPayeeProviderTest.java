package com.nordea.dbf.payee.service;

import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.bankinfo.facade.LegacyBankInfoFacade;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.BadRequestException;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseBanksSegment;
import com.nordea.dbf.payee.record.bankinfo.BankInfoResponseRecord;
import org.junit.Test;
import rx.Observable;

import java.util.NoSuchElementException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AccountPayeeProviderTest {

    private final LegacyBankInfoFacade legacyBankInfoFacade = mock(LegacyBankInfoFacade.class);
    private final AccountPayeeProvider provider = new AccountPayeeProvider(legacyBankInfoFacade);

    private final ServiceRequestContext context = mock(ServiceRequestContext.class);

    @Test
    public void getPayeeShouldReturnBankNameForValidAccountNumber() {
        expectExampleBanks();

        assertThat(provider.getPayee(context, AccountKey.fromString("LBAN-SE-10001231231")).toBlocking().single()).isEqualTo(new Payee().setBankName("MyBank1").setCountry("SE"));
        assertThat(provider.getPayee(context, AccountKey.fromString("LBAN-SE-15001231231")).toBlocking().single()).isEqualTo(new Payee().setBankName("MyBank1").setCountry("SE"));
        assertThat(provider.getPayee(context, AccountKey.fromString("LBAN-SE-20001231231")).toBlocking().single()).isEqualTo(new Payee().setBankName("MyBank1").setCountry("SE"));
        assertThat(provider.getPayee(context, AccountKey.fromString("LBAN-SE-20011231231")).toBlocking().single()).isEqualTo(new Payee().setBankName("MyBank2").setCountry("SE"));
        assertThat(provider.getPayee(context, AccountKey.fromString("LBAN-SE-30001231231")).toBlocking().single()).isEqualTo(new Payee().setBankName("MyBank2").setCountry("SE"));
    }

    @Test
    public void getValidAccountNumberShouldFailForInvalidClearingNumber() {
        expectExampleBanks();

        assertThatThrownBy( ()->
                provider.getPayee(context, AccountKey.fromString("LBAN-SE-00001231231")).toBlocking().single()).isInstanceOf(NoSuchElementException.class);
    }


    @Test
    public void getValidAccountNumberShouldFailForTooShortAccountNumber() {
        expectExampleBanks();

        assertThatThrownBy( () ->
                provider.getPayee(context,AccountKey.fromString("LBAN-SE-1000123123")).toBlocking().single()).isInstanceOf(BadRequestException.class);
    }

    @Test
    public void getValidAccountNumberShouldFailForTooLongAccountNumber() {
        expectExampleBanks();

        assertThatThrownBy( ()->
                provider.getPayee(context, AccountKey.fromString("LBAN-SE-100012312312")).toBlocking().single()).isInstanceOf(BadRequestException.class);
    }

    @Test
    public void getValidAccountNumberShouldFailForMalformedAccountNumber() {
        expectExampleBanks();

        assertThatThrownBy( ()->
          provider.getPayee(context, AccountKey.fromString("LBAN-SE-100012312A12")).toBlocking().single()).isInstanceOf(IllegalArgumentException.class);
    }

    private void expectExampleBanks() {
        final BankInfoResponseRecord response = new BankInfoResponseRecord();
        response.initialize();

        final BankInfoResponseBanksSegment bank1 = response.addBanks();
        bank1.setBankShortName("B1");
        bank1.setBankName("MyBank1");
        bank1.setAccountType("B");
        bank1.setFromClNo(1000);
        bank1.setToClNo(2000);

        final BankInfoResponseBanksSegment bank2 = response.addBanks();
        bank2.setBankShortName("B2");
        bank2.setBankName("MyBank2");
        bank2.setAccountType("B");
        bank2.setFromClNo(2001);
        bank2.setToClNo(3000);

        when(legacyBankInfoFacade.getBanks(any(ServiceRequestContext.class))).thenReturn(Observable.just(response));
    }

}
