package com.nordea.dbf.payee.service;

import com.nordea.dbf.payee.model.AccountType;
import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class AccountTypeTest {

    @Test
    public void legacyAccountTypeCodesShouldBeMappedCorrectly() {
        assertThat(AccountType.fromCode("B")).isEqualTo(AccountType.NORMAL_BANK_ACCOUNT);
        assertThat(AccountType.fromCode("H")).isEqualTo(AccountType.HANDELSBANKEN_ACCOUNT);
        assertThat(AccountType.fromCode("P")).isEqualTo(AccountType.PERSON_NUMBER_ACCOUNT);
        assertThat(AccountType.fromCode("S")).isEqualTo(AccountType.S);
        assertThat(AccountType.fromCode("T")).isEqualTo(AccountType.T);
        assertThat(AccountType.fromCode("G")).isEqualTo(AccountType.GIRO_ACCOUNT);
    }

    @Test
    public void fromCodeShouldFailIfCodeIsNotMapped() {
        assertThatThrownBy( ()-> AccountType.fromCode("Q")).isInstanceOf(IllegalArgumentException.class);
    }
}