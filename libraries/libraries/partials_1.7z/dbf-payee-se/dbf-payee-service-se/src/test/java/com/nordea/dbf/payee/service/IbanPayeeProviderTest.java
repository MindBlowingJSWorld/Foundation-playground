package com.nordea.dbf.payee.service;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.nordea.dbf.api.model.CrossBorderPayee;
import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.payee.iban.CrossBorderPayeeResolver;
import org.junit.Test;
import rx.Observable;

public class IbanPayeeProviderTest {

    private final CrossBorderPayeeResolver resolver = mock(CrossBorderPayeeResolver.class);
    private final IbanPayeeProvider provider = new IbanPayeeProvider(resolver);
    private final ServiceRequestContext requestContext = mock(ServiceRequestContext.class);

    @Test
    public void ibanResolverCannotBeNull() {
        assertThatThrownBy(() -> new IbanPayeeProvider(null)).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    public void ibanPayeeShouldBeLookedUpThroughResolver() {
        // given
        final String ibanNumber = "SE3630000000032022204581";
        final AccountKey accountKey = AccountKey.fromString("IBAN-NDEASESS-SE3630000000032022204581");
        final CrossBorderPayee expected = new CrossBorderPayee()
                .setCountry("SE")
                .setBicCode("NDEASESS")
                .setSepaCountry(true);

        when(resolver.lookupIbanNumber(same(requestContext), eq(ibanNumber))).thenReturn(Observable.just(expected));

        // when
        final Payee actual = provider.getPayee(requestContext, accountKey).toBlocking().single();

        // then

        assertThat(actual.getCountry()).isEqualTo("SE");
        assertThat(actual.getSepaCountry()).isTrue();

        verify(resolver).lookupIbanNumber(same(requestContext), eq("SE3630000000032022204581"));
    }

}
