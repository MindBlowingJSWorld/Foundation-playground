package com.nordea.dbf.payee.service;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by n450680 on 2016-02-02.
 */
public class PGBGValidationReturnCodeTest {

    @Test public void testReturnCodes() {
        assertThat(PGBGValidationReturnCode.fromCode(0)).isEqualTo(PGBGValidationReturnCode.OK_WITHOUT_OCR);
        assertThat(PGBGValidationReturnCode.fromCode(1)).isEqualTo(PGBGValidationReturnCode.OK_WITH_OCR);
        assertThat(PGBGValidationReturnCode.fromCode(10)).isEqualTo(PGBGValidationReturnCode.PG_BG_FLAG_MISSING);
        assertThat(PGBGValidationReturnCode.fromCode(20)).isEqualTo(PGBGValidationReturnCode.CHECK_NUMBER_ERROR);
        assertThat(PGBGValidationReturnCode.fromCode(21)).isEqualTo(PGBGValidationReturnCode.PG_BG_NUMBER_MISSING);
        assertThat(PGBGValidationReturnCode.fromCode(22)).isEqualTo(PGBGValidationReturnCode.PARAMETER_ERROR);
        assertThat(PGBGValidationReturnCode.fromCode(23)).isEqualTo(PGBGValidationReturnCode.INVALID_REFERENCE_NUMBER);
        assertThat(PGBGValidationReturnCode.fromCode(24)).isEqualTo(PGBGValidationReturnCode.DATABASE_ERROR);
        assertThat(PGBGValidationReturnCode.fromCode(25)).isEqualTo(PGBGValidationReturnCode.CHECKNUMBER_ERROR_REFERENCE_NUMBER);
        assertThat(PGBGValidationReturnCode.fromCode(26)).isEqualTo(PGBGValidationReturnCode.PERMISSION_ERROR);
        assertThat(PGBGValidationReturnCode.fromCode(27)).isEqualTo(PGBGValidationReturnCode.SOURCE_ACCOUNT_MISSING);
        assertThat(PGBGValidationReturnCode.fromCode(83947)).isEqualTo(PGBGValidationReturnCode.UNKNOWN);
    }
}
