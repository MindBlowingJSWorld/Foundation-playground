package com.nordea.dbf.payee.service.f9;

import com.nordea.dbf.api.model.Payee;
import com.nordea.dbf.api.model.accountkey.AccountKey;
import com.nordea.dbf.http.ServiceRequestContext;
import com.nordea.dbf.http.errorhandling.exception.BackendException;
import com.nordea.dbf.payee.integration.LegacyPaymentVerificationFacade;
import com.nordea.dbf.payee.record.paymentverification.VerifyPaymentResponseRecord;
import com.nordea.dbf.payee.service.LegacyPGBGPayeeProvider;
import org.junit.Test;
import rx.Observable;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class LegacyPGBGPayeeProviderTest {

  private final LegacyPaymentVerificationFacade legacyPaymentVerificationFacade =
      mock(LegacyPaymentVerificationFacade.class);

  private final LegacyPGBGPayeeProvider provider = new LegacyPGBGPayeeProvider(legacyPaymentVerificationFacade);

  @Test(expected = IllegalArgumentException.class)
  public void legacyPaymentVerificationProviderCannotBeNull() {
    new LegacyPGBGPayeeProvider(null);
  }

  @Test
  public void getPayeeShouldReturnPayeeFromLegacyResponseSoftOcr() {
    final ServiceRequestContext context = mock(ServiceRequestContext.class);
    final AccountKey accountKey = AccountKey.fromString("PG-1234");
    final VerifyPaymentResponseRecord responseRecord = new VerifyPaymentResponseRecord();

    responseRecord.initialize();
    responseRecord.setNewPaymentDate1("20150530");
    responseRecord.setOcrControl1("M");
    responseRecord.setOwnerName1("MyPayee");
    responseRecord.setReturnCode1(0);

    when(legacyPaymentVerificationFacade.verifyPayment(eq(context), eq(accountKey))).thenReturn(
        Observable.just(responseRecord));

    final Payee payee = provider.getPayee(context, accountKey).toBlocking().single();

    assertThat(payee.getOwnerName()).isEqualTo("MyPayee");
    assertThat(payee.getOcr()).isEqualTo(Payee.OcrEnum.soft);
    assertThat(payee.getNextDate()).isEqualTo(LocalDate.of(2015, 5, 30));
  }


  @Test
  public void getPayeeShouldReturnPayeeFromLegacyResponseHardOcr() {
    final ServiceRequestContext context = mock(ServiceRequestContext.class);
    final AccountKey accountKey = AccountKey.fromString("PG-1234");
    final VerifyPaymentResponseRecord responseRecord = new VerifyPaymentResponseRecord();

    responseRecord.initialize();
    responseRecord.setNewPaymentDate1("20150530");
    responseRecord.setOcrControl1("H");
    responseRecord.setOwnerName1("MyPayee");
    responseRecord.setReturnCode1(0);

    when(legacyPaymentVerificationFacade.verifyPayment(eq(context), eq(accountKey))).thenReturn(
            Observable.just(responseRecord));

    final Payee payee = provider.getPayee(context, accountKey).toBlocking().single();

    assertThat(payee.getOwnerName()).isEqualTo("MyPayee");
    assertThat(payee.getOcr()).isEqualTo(Payee.OcrEnum.hard);
    assertThat(payee.getNextDate()).isEqualTo(LocalDate.of(2015, 5, 30));
  }

  @Test
  public void getPayeeShouldReturnPayeeFromLegacyResponseNoOcrWithReturnCode0() {
    final ServiceRequestContext context = mock(ServiceRequestContext.class);
    final AccountKey accountKey = AccountKey.fromString("PG-1234");
    final VerifyPaymentResponseRecord responseRecord = new VerifyPaymentResponseRecord();

    responseRecord.initialize();
    responseRecord.setNewPaymentDate1("20150530");
    responseRecord.setOwnerName1("MyPayee");
    responseRecord.setReturnCode1(0);

    when(legacyPaymentVerificationFacade.verifyPayment(eq(context), eq(accountKey))).thenReturn(
            Observable.just(responseRecord));

    final Payee payee = provider.getPayee(context, accountKey).toBlocking().single();

    assertThat(payee.getOwnerName()).isEqualTo("MyPayee");
    assertThat(payee.getOcr()).isEqualTo(Payee.OcrEnum.no);
    assertThat(payee.getNextDate()).isEqualTo(LocalDate.of(2015, 5, 30));
  }

  @Test
  public void getPayeeShouldReturnPayeeFromLegacyResponseNoOcrWithReturnCode1() {
    final ServiceRequestContext context = mock(ServiceRequestContext.class);
    final AccountKey accountKey = AccountKey.fromString("PG-1234");
    final VerifyPaymentResponseRecord responseRecord = new VerifyPaymentResponseRecord();

    responseRecord.initialize();
    responseRecord.setNewPaymentDate1("20150530");
    responseRecord.setOwnerName1("MyPayee");
    responseRecord.setReturnCode1(1);

    when(legacyPaymentVerificationFacade.verifyPayment(eq(context), eq(accountKey))).thenReturn(
            Observable.just(responseRecord));

    final Payee payee = provider.getPayee(context, accountKey).toBlocking().single();

    assertThat(payee.getOwnerName()).isEqualTo("MyPayee");
    assertThat(payee.getOcr()).isEqualTo(Payee.OcrEnum.hard);
    assertThat(payee.getNextDate()).isEqualTo(LocalDate.of(2015, 5, 30));
  }

  @Test
  public void getPayeeShouldThrowExceptionWhenBackendErrorr() {
    final ServiceRequestContext context = mock(ServiceRequestContext.class);
    final AccountKey accountKey = AccountKey.fromString("PG-1234");
    final VerifyPaymentResponseRecord responseRecord = new VerifyPaymentResponseRecord();

    responseRecord.initialize();
    responseRecord.setResponseCode(10);

    when(legacyPaymentVerificationFacade.verifyPayment(eq(context), eq(accountKey))).thenReturn(
            Observable.just(responseRecord));

    assertThatThrownBy(()->
            provider.getPayee(context, accountKey).toBlocking().single()).isInstanceOf(BackendException .class);

  }

}
