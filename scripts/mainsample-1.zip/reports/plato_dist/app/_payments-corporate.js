'use strict';

/* eslint angular/component-limit: [0] */
angular
    .module('dbw-payments.corporate', [
        'dbw-core',
        'dbw-common',
        'dbw-localization',
        'dbw-labels',
        'dbw-payments.corporate.common',
        'dbw-payments.corporate.sendMoney',
        'dbw-payments.corporate.outgoingPayments'
    ]);
