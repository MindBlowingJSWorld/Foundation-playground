'use strict';

angular.module('dbw-payments.corporate.tpl', []);
