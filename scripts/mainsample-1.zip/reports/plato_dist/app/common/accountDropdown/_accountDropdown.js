(function () {
    'use strict';
    angular
        .module('dbw-payments.corporate.common.accountDropdownCp', [
            'dbw-payments.corporate.common.dropdownList',
            'dbw-payments.corporate.common.amountFormatter'
        ]);
})();
