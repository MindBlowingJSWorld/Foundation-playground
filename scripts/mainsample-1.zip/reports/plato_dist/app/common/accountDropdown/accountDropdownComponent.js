(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.accountDropdownCp')
        .component('dbwCorpAccountDropdown', {
            bindings: {
                name: '@name',
                selectedOption: '=ngModel',
                options: '<'
            },
            require: {
                formCtrl: '?^form'
            },
            controllerAs: 'vm',
            controller: dbwAccountDropdownControllerCp,
            templateUrl: 'common/accountDropdown/accountDropdown.tpl.html'
        });

    function dbwAccountDropdownControllerCp($element) {
        $element.addClass('dbw-account-dropdown');
        var vm = this;
        vm.formatAccountName = formatAccountName;

        function formatAccountName(account) {
            if (!account) {
                return '';
            }
            return account.getAccountNumber() + ' ' + account.getAccountName();
        }
    }
})();
