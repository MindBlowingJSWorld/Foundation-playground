'use strict';

var ndAccountNumber = function ($q) {
    return {
        restrict: 'E',
        scope: {
            name: '@',
            contentPage: '@',
            model: '=',
            backendValidation: '@',
            events: '=',
            prefix: '@',
            country: '@'
        },
        controller: function ($scope, $window, accountNumberValidatorThirdParty, accountNumberFormatter) {

            $scope.isNumberKey = function (evt) {

                var theEvent = evt || $window.event;
                var key = theEvent.keyCode || theEvent.which;
                key = String.fromCharCode(key);
                if (key.length === 0){
                    return;
                }
                var regex = /^[0-9.,\b]+$/;
                if (!regex.test(key)) {
                    theEvent.returnValue = false;
                    if (theEvent.preventDefault) {
                        theEvent.preventDefault();
                    }
                }
            };


            function hasBackendValidation() {
                return $scope.backendValidation && $scope.backendValidation === 'true' ? true : false;
            }

            /**
             * Check if a potential Swedish personal identity number is valid
             */
            $scope.isValidSwedishPersonalIdentityNumber = function (form, element, model) {
                return accountNumberValidatorThirdParty.validateSwedishPersonalIdentityNumberAccount(model.$viewValue);
            };

            /**
             * Calls the backend to verify if the account number exists
             */
            $scope.isValidAccountNumber = function (form, element, model) {

                if (!hasBackendValidation()) {
                    return $q.when();
                }


                var newValue = model.$viewValue;

                var validationPromise = accountNumberValidatorThirdParty.validateAgainstBackend(newValue, $scope.country, $scope.prefix);

                return validationPromise.then(
                    function (data) {
                        if (data.length === 0) {
                            return $q.reject();
                        }
                        return $q.resolve(data);

                    },
                    function () {
                        return $q.reject('Not a valid account number');
                    });
            };

            $scope.format = function () {
                if (!$scope.model.number) {
                    return;
                }
                $scope.model.number = accountNumberFormatter.format($scope.model.number);

            };
        },
        templateUrl: 'common/accountNumber/accountNumber.tpl.html'
    };
};

angular.module('dbw-payments.corporate.common')
    .directive('ndAccountNumber', ndAccountNumber);
