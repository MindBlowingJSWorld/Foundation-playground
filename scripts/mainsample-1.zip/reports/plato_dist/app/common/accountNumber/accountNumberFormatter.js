'use strict';

var accountNumberFormatter = function (accountNumberValidatorService, StringUtils) {

    function prependSpinWithPrefix(digits) {
        var accountNumber = digits;

        if (accountNumberValidatorService.isSwedishPersonalIdentityNumber(digits)) {
            // append missing prefix to SPIN
            return '3300' + accountNumber;
        }

        return accountNumber;
    }

    return {
        format: function (number) {
            if (!number) {
                return undefined;
            }

            return prependSpinWithPrefix(StringUtils.removeHyphensSpacesCommasAndPeriods(number));
        }
    };
};


angular.module('dbw-payments.corporate.common')
    .factory('accountNumberFormatter', accountNumberFormatter);


