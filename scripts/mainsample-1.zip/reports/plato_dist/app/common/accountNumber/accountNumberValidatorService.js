'use strict';

var accountNumberValidatorService = function () {

    /**
     * Luhn algorithm in JavaScript: validate credit card number supplied as string of numbers
     * @author ShirtlessKirk. Copyright (c) 2012.
     * @license WTFPL (http://www.wtfpl.net/txt/copying)
     */

    var luhnChkFunction = function (arr) {
        return function (ccNum) {

            var len = ccNum.length;
            var bit = 1;
            var sum = 0;
            var val;

            while (len) {
                val = parseInt(ccNum.charAt(--len), 10);
                /*eslint-disable */
                /*jslint bitwise: true */
                sum += (bit ^= 1) ? arr[val] : val;
                /*eslint-enable */
            }

            return sum && sum % 10 === 0;
        };
    };

    var luhnChk = luhnChkFunction([0, 2, 4, 6, 8, 1, 3, 5, 7, 9]);

    return {
        removeSpinAccountPrefix: function (accountDigits) {
            return accountDigits.replace(/^3300/, '');
        },

        isValidDate: function (dateStr) {
            /*eslint-disable */
            return moment(dateStr, 'YYMMDD').isValid();
            /*eslint-enable */
        },

        isValidLuhnNumber: function (digits) {
            return luhnChk(digits);
        },

        /**
         * We treat a series of digits as a 'personnummer' if the length is 10, the first 6 digits is a valid date
         * and the complete string of digits is passing a modulus 10 / luhn check.
         * @param digits
         * @returns {boolean}
         */
        isSwedishPersonalIdentityNumber: function (digits) {
            if (digits.length === 10 && this.isValidDate(digits.substring(0, 6))) {
                return luhnChk(digits);
            }
            return false;
        }
    };
};


angular.module('dbw-payments.corporate.common')
    .service('accountNumberValidatorService', accountNumberValidatorService);

