'use strict';

angular.module('dbw-payments.corporate.common')
    .factory('accountNumberValidatorThirdParty',
        function accountNumberValidatorThirdPartyFactory(PayeeService,
                                                         $timeout,
                                                         accountNumberFormatter,
                                                         accountNumberValidatorService,
                                                         StringUtils) {

            var timer;

            return {
                /**
                 * @param number string, accepting spaces and hyphens
                 * @returns true if (account) number is not a potential Swedish personal identity number,
                 *          true if number is Swedish personal identity number formatted with passed Luhn check
                 *          false if number is Swedish personal identity number formatted with failed Luhn check
                 */
                validateSwedishPersonalIdentityNumberAccount: function (number) {
                    var accountDigits = StringUtils.removeHyphensSpacesCommasAndPeriods(number);

                    var digits = accountNumberValidatorService.removeSpinAccountPrefix(accountDigits);

                    if (digits.length !== 10 || !accountNumberValidatorService.isValidDate(digits.substring(0, 6))){
                        // don't bother to luhn check
                        return true;
                    }

                    // potentially a valid Swedish personal identity number
                    return accountNumberValidatorService.isValidLuhnNumber(digits);
                },

                validateAgainstBackend: function (number, country, prefix) {
                    if (timer) {
                        $timeout.cancel(timer);
                    }
                    timer = $timeout(function () {
                        var formattedNumbers = accountNumberFormatter.format(number);

                        return PayeeService._getPayeeInfo(formattedNumbers, country, prefix);
                    }, 500);
                    return timer;
                }
            };
        });

