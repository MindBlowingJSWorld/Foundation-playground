'use strict';

function AmountController(amountFormatter, amountValidator, $element, $scope, $window) {
    $element.addClass('dbw-amount');
    var vm = this;
    vm.validPattern = function () {

        return amountValidator.allowedInputCharacters();
    };

    // sync custom validation functions -> return booleans, true means: validation is ok

    vm.checkAmountAgainstBalance = function (form, element, model) {
        var max = $scope.maxAmount;
        return amountValidator.withinBalance(model, max);
    };

    vm.checkMin = function (form, element, model) {
        return amountValidator.aboveLimit(model);
    };

    vm.checkNoOfDigits = function (form, element, model) {
        return amountValidator.withinAllowedNoOfDigits(model);
    };

    vm.checkNumberFormat = function (form, element, model) {
        return amountValidator.localeNumberFormatted(model);
    };

    vm.format = function () {
        $scope.model.amount = amountFormatter.format($scope.model.amount);
    };

    vm.isNumberKey = function (evt) {

        var theEvent = evt || $window.event;
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
        if (key.length === 0){
            return;
        }
        var regex = /^[0-9.,\b]+$/;
        if (!regex.test(key)) {
            theEvent.returnValue = false;
            if (theEvent.preventDefault) {
                theEvent.preventDefault();
            }
        }
    };
}

angular.module('dbw-payments.corporate.common')
    .controller('AmountController', AmountController);
