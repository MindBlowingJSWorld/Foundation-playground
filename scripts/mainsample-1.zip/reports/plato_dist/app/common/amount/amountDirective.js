'use strict';

var dbwAmount = function () {
    return {
        restrict: 'E',
        require: '^form',
        scope: {
            name: '@',
            contentPage: '@',
            model: '=',
            maxAmount: '@',
            showLabel: '@'
        },
        controller: 'AmountController',
        controllerAs: 'vm',
        link: function (scope, element, attrs, form) {
            scope.parentForm = form;

            if (scope.showLabel === undefined) {
                scope.showLabel = 'true';
            }

            var refresh = function () {
                var ngModelCtrl = scope.parentForm[scope.name];
                if (ngModelCtrl) {
                    ngModelCtrl.$validate();
                }
            };
            attrs.$observe('maxAmount', refresh);
        },
        templateUrl: 'common/amount/amount.tpl.html'
    };
};

angular.module('dbw-payments.corporate.common')
    .directive('dbwAmount', dbwAmount);
