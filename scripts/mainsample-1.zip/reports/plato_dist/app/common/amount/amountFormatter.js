'use strict';

angular.module('dbw-payments.corporate.common')
    .factory('amountFormatter', function amountFormatterFactory() {

        function normalizeAmount(input) {
            var amount_with_decimal = input.toString().replace(/\,/g, '.');
            var formatted_amount = parseFloat(Math.round(amount_with_decimal * 100) / 100).toFixed(2);
            var amount_with_comma = formatted_amount.toString().replace(/\./g, ',');
            return amount_with_comma;
        }

        function format(input) {
            if (!input) {
                return undefined;
            }

            var normalizedAmount = normalizeAmount(input);
            return normalizedAmount;
        }

        return {
            format: format
        };
    });
