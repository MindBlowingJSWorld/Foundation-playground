'use strict';

angular.module('dbw-payments.corporate.common')
    .factory('amountValidator', function amountValidatorFactory() {

        // stricter than EcmaScript parseFloat
        function filterFloat(value) {
            if(/^([0-9]+(\.[0-9]+)?|Infinity)$/
                    .test(value)) {
                return Number(value);
            }
            return NaN;
        }

        function getValidInputChars() {
            var groupSep = ',';
            var decimalSep = '.';

            // allow numbers, group- and decimal separators according to $locale
            var pattern = '^[\\d' +
            groupSep +
            decimalSep +
            ']*$';

            // replace any non-breaking space chars with any whitespace character
            var validWhiteSpaceChars = '\r\n\t\f\u0020\u00A0';

            return pattern.replace(/\u00A0/g, validWhiteSpaceChars);
        }

        function normalizeAmount(input) {
            var cleanup = new RegExp('[^\\d.]', 'g');
            return input.replace(cleanup, '');
        }

        function isWithinBalance(model, max) {
            var viewValue = normalizeAmount(model.$viewValue);
            var amount = parseFloat(viewValue);
            if (isNaN(amount)) {
                return true;
            }

            if (!max) {   // no validation needed
                return true;
            }

            //compare entered amount against given maxAmount, it can't be less than max amount:
            var maxAmount = parseFloat(max);

            return amount <= maxAmount;
        }

        function isAboveMinAmount (model) {
            var viewValue = normalizeAmount(model.$viewValue);
            var amount = parseFloat(viewValue);
            if (isNaN(amount)) {
                return true;
            }

            var minThreshold = 0.01;

            return amount >= minThreshold;
        }

        function isHavingMaxOneDecimalSeparator(model) {
            // normalizeAmount will remove all non-numerical characters except one decimal separator
            var viewValue = normalizeAmount(model.$viewValue);

            // allow zero or one decimal separator
            var regExp = new RegExp(/^\d*\.?\d*$/);

            return regExp.test(viewValue);
        }

        function isWithinMaxNoOfAllowedDigits(model) {
            var viewValue = normalizeAmount(model.$viewValue);
            var amount = filterFloat(viewValue);
            if (isNaN(amount)) {
                return true;
            }

            var parts = viewValue.split('.');
            // if there is no fraction, add one decimal zero
            parts[1] = parts[1] || '0';
            var amountString = parts.join('.');

            var regExp = new RegExp(/^\d{1,13}\.{1}\d{0,2}$/);
            return regExp.test(amountString);
        }

        return {
            allowedInputCharacters: function () {
                return getValidInputChars();
            },
            withinBalance: function (model, max) {
                return isWithinBalance(model, max);
            },
            aboveLimit: function (model) {
                return isAboveMinAmount(model);
            },
            withinAllowedNoOfDigits: function (model) {
                return isWithinMaxNoOfAllowedDigits(model);
            },
            localeNumberFormatted: function (model) {
                return isHavingMaxOneDecimalSeparator(model);
            }
        };
    });

