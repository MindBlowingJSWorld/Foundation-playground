'use strict';
var AmountFieldController = function(amountValidator, amountFormatter, InputUtils, $scope) {
    var vm = this;


    init();

    function init() {
        vm.amountValidator = amountValidator;
        vm.amountFormatter = amountFormatter;
        vm.inputUtils = InputUtils;
        vm.scope = $scope;
    }
};

AmountFieldController.prototype.handleKeyUp = function () {
    //angular.element('#amount-number').css('color','transparent');
    this.amount = this.scope.model;
};

AmountFieldController.prototype.selectCurrency = function (cur) {
    this.scope.selectedCurrency = cur;
    this.showCurrencyList = false;
};

AmountFieldController.prototype.handleFocus = function () {
    this.inputFocused = true;
};

AmountFieldController.prototype.validPattern = function () {
    return this.amountValidator.allowedInputCharacters();
};


angular
    .module('dbw-payments.corporate.common.amountFormatter')
    .controller('AmountFieldController', AmountFieldController);
