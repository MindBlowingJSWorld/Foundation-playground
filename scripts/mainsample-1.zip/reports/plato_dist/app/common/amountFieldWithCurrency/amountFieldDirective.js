'use strict';


var dbwAmountfield = function () {
    return {
        scope: {
            model: '=',
            currencies: '=',
            selectedCurrency: '=currency'
        },
        require: '^form',
        controller: 'AmountFieldController',
        controllerAs: 'vm',
        templateUrl: 'common/amountFieldWithCurrency/amountField.tpl.html',
        link: function (scope, element, attr, form) {
            scope.domesticTransferForm = form;
            scope.$watch('model', function(newValue, oldValue){
                var regex = /^[0-9.,\b]+$/;
                if (newValue && !regex.test(newValue)) {
                    scope.model = oldValue;
                }

            });
        }
    };
};

angular
    .module('dbw-payments.corporate.common.amountField')
    .directive('dbwAmountfield', dbwAmountfield);
