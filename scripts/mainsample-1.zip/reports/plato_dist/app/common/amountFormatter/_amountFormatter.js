(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.amountFormatter', [
            'dbw-payments.corporate.common.numberParser'
        ]);
})();
