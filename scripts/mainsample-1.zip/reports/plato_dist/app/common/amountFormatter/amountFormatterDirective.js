(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.amountFormatter')
        .directive('amountFormatter', function amountFormatterDirective($filter) {
            return {
                require: 'ngModel',
                link: function (scope, element, attr, ngModelCtrl) {
                    element.bind('blur', formatAmount);

                    function formatAmount() {
                        var value = ngModelCtrl.$viewValue;
                        if (value) {
                            var transformedValue = $filter('amountFormatterFilter')(value);
                            if (transformedValue !== value) {
                                ngModelCtrl.$setViewValue(transformedValue);
                                ngModelCtrl.$render();
                            }
                        }
                    }
                }
            };
        });
})();
