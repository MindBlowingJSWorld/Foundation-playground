(function () {
    'use strict';

    var DECIMAL_SEPARATOR = ',';
    var THOUSANDS_SEPARATOR = ' ';

    angular
        .module('dbw-payments.corporate.common.amountFormatter')
        .filter('amountFormatterFilter', function amountFormatterDirective(dbwNumberParser) {
            return function (inputValue) {
                if (!inputValue) {
                    return '0,00';
                }
                var valueNumber = dbwNumberParser.parse(inputValue);
                if(isNaN(valueNumber)) {
                    return '';
                }
                var valueParts = inputValue.toString().replace(new RegExp(',', 'g'), '.').split('.');
                var fractional = (valueParts.length <= 1) ? '00' : valueParts.pop();

                var integer = valueParts.join('');
                if (integer.length === 0) {
                    integer = '0';
                }
                // add thousands separators
                // reverse -> replace every 4th with separator -> reverse
                integer = integer.split('').reverse().join('')
                    .replace(/(.{3})/g, '$1' + THOUSANDS_SEPARATOR)
                    .split('').reverse().join('')
                    .trim();

                // fractional part:
                while (fractional.length < 2) {
                    fractional = '0' + fractional;
                }

                // whole number:
                return integer + DECIMAL_SEPARATOR + fractional.substr(0, 2);
            };
        });
})();
