'use strict';

angular
    .module('dbw-payments.corporate.common.beneficiary', ['dbw-payments.corporate.common.beneficiary.beneficiaryItem'])

    .constant('MAX_BENEFICIARY_OPTIONS', 5)

    .constant('KEY_CODES', {
        UP: 38,
        DOWN: 40,
        ENTER: 13,
        BACKSPACE: 8,
        DELETE: 46
    });
