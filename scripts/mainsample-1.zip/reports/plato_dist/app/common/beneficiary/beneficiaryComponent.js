(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.beneficiary')
        .component('dbwCorpBeneficiary', {
            bindings: {
                selectedBeneficiary: '=ngModel',
                favourites: '<?',
                beneficiaries: '<',
                onToggleEditMode: '<?'
            },
            controllerAs: 'vm',
            controller: dbwBeneficiaryController,
            templateUrl: 'common/beneficiary/beneficiary.tpl.html'
        });
    /*eslint max-statements: ["error", 45, {ignoreTopLevelFunctions: true}]*/
    function dbwBeneficiaryController(NordicBeneficiaryDbfModelService,
                                      $scope,
                                      $rootScope,
                                      $element,
                                      $document,
                                      $q,
                                      KEY_CODES,
                                      MAX_BENEFICIARY_OPTIONS) {

        $element.addClass('dbw-corp-beneficiary');
        var vm = this;
        vm.isFocused = false;
        vm.beneficiarySearchPhrase = '';
        vm.newBeneficiary = {name: ''};
        vm.showDropdown = false;
        vm.showFavouritesHeader = false;
        vm.showAddButton = false;
        vm.selectBeneficiary = selectBeneficiary;
        vm.removeSelected = removeSelected;
        vm.onMouseOverBeneficiary = onMouseOverBeneficiary;
        vm.onInputFocus = onInputFocus;
        vm.onInputBlur = onInputBlur;
        vm.onItemMouseDown = onItemMouseDown;

        $element.on('keydown', onKeyDown);
        $scope.$watch('vm.selectedBeneficiary', updateState);
        $scope.$watch('vm.beneficiarySearchPhrase', updateState);
        $document.bind('click', handleOutsideClick);
        resetHighlightedElementIndex();

        var keyActions = {};
        keyActions[KEY_CODES.UP] = moveToPreviousElement;
        keyActions[KEY_CODES.DOWN] = moveToNextElement;
        keyActions[KEY_CODES.ENTER] = onKeyboardEnter;
        keyActions[KEY_CODES.BACKSPACE] = onKeyboardRemove;
        keyActions[KEY_CODES.DELETE] = onKeyboardRemove;

        //$rootScope.$emit('beneficiaryCleared');

        $rootScope.$on('selectBeneficiary', function (event, beneficiaryId) {
            angular.forEach(vm.beneficiaries, function (beneficiary) {
                if (beneficiary.display_number === beneficiaryId) {
                    selectBeneficiary(beneficiary);
                }
            });
        });

        function onInputFocus() {
            vm.isFocused = true;
            if (vm.onToggleEditMode) {
                vm.onToggleEditMode('enter');
            }
            updateState();
        }

        function onInputBlur() {
            vm.isFocused = false;
            if (vm.onToggleEditMode) {
                vm.onToggleEditMode('leave');
            }
            updateState();
        }

        function onItemMouseDown(index) {
            vm.highlightedElementIndex = index;
            selectBeneficiary(vm.beneficiaryOptions[vm.highlightedElementIndex].beneficiary);
        }

        function updateState() {
            if (vm.selectedBeneficiary) {
                vm.beneficiarySearchPhrase = '';
                vm.showDropdown = false;
            } else if (vm.isFocused) {
                searchAndUpdateBeneficiaryOptions(vm.beneficiarySearchPhrase);
                vm.showDropdown = true;
            } else {
                vm.showDropdown = false;
            }
        }

        function onKeyDown(event) {
            var action = keyActions[event.keyCode];
            if (action) {
                action(event);
                $scope.$apply();
            }
        }

        function moveToNextElement() {
            vm.highlightedElementIndex = Math.min(
                vm.highlightedElementIndex + 1,
                (vm.beneficiaryOptions ? vm.beneficiaryOptions.length - 1 : -1)
            );
        }

        function moveToPreviousElement() {
            vm.highlightedElementIndex = Math.max(
                vm.highlightedElementIndex - 1,
                -1
            );
        }

        function onKeyboardEnter(event) {
            selectBeneficiary(vm.beneficiaryOptions[vm.highlightedElementIndex].beneficiary);
            event.preventDefault();
        }

        function onKeyboardRemove() {
            if (vm.selectBeneficiary) {
                removeSelected();
            }
        }

        function onMouseOverBeneficiary(index) {
            vm.highlightedElementIndex = index;
        }

        function removeSelected() {
            vm.selectedBeneficiary = undefined;
            $element.find('input')[0].focus();
            $rootScope.$emit('beneficiaryCleared');
        }

        function selectBeneficiary(beneficiary) {
            if (beneficiary) {
                vm.selectedBeneficiary = beneficiary;
                $rootScope.$emit('beneficiaryUpdated', vm.selectedBeneficiary);
                resetHighlightedElementIndex();
            }
        }

        function resetHighlightedElementIndex() {
            vm.highlightedElementIndex = -1;
        }

        function setBeneficiaryOptions(allBeneficiaries) {
            var beneficiaries = allBeneficiaries.slice(0, MAX_BENEFICIARY_OPTIONS);
            vm.beneficiaryOptions = beneficiaries.map(function (beneficiary) {
                return {
                    beneficiary: beneficiary
                };
            });
            if (vm.beneficiarySearchPhrase.trim() !== '' && vm.beneficiaryOptions.length === 0) {

                angular.element('#new-beneficiary').removeClass('button hollow');
                angular.element('#new-beneficiary').addClass('button');
            }else{

                angular.element('#new-beneficiary').removeClass('button');
                angular.element('#new-beneficiary').addClass('button hollow');
            }
            resetHighlightedElementIndex();
        }

        function handleOutsideClick(event) {
            //var isClickedElementChildOfPopup = $element.find(event.target).length > 0;
            //if (!isClickedElementChildOfPopup) {
            //    vm.isFocused = false;
            //    updateState();
            //    $scope.$apply();
            //}
        }

        function searchAndUpdateBeneficiaryOptions(beneficiarySearchPhrase) {
            var trimmedLowercasePhrase = beneficiarySearchPhrase.trim().toLowerCase();
            if (trimmedLowercasePhrase === '') {
                $q.when(vm.favourites)
                    .then(setBeneficiaryOptions);
                vm.showFavouritesHeader = true;
            } else {
                var filteredBeneficiaries = _.filter(vm.beneficiaries, function (beneficiary) {
                    return beneficiary.getName().toLowerCase().indexOf(trimmedLowercasePhrase) >= 0;
                });
                setBeneficiaryOptions(filteredBeneficiaries);
                vm.showFavouritesHeader = false;
            }
        }
    }
})();
