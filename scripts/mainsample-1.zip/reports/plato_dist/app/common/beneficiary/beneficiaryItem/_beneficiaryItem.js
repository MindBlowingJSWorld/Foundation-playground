(function () {
    'use strict';

    angular.module('dbw-payments.corporate.common.beneficiary.beneficiaryItem', []);
})();
