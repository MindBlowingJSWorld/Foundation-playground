(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.beneficiary.beneficiaryItem')
        .component('dbwCorpBeneficiaryItem', {
            bindings: {
                model: '<beneficiary',
                avatarText: '@?',
                labelText: '@?',
                onClose: '&?'
            },
            controllerAs: 'vm',
            controller: dbwBeneficiaryItemController,
            templateUrl: 'common/beneficiary/beneficiaryItem/beneficiaryItem.tpl.html'
        });

    function dbwBeneficiaryItemController($element) {
        var vm = this;
        $element.addClass('dbw-corp-beneficiary-item');
        vm.getInitials = getInitials;
        vm.getLabelText = getLabelText;

        function getLabelText(model) {
            if (angular.isDefined(vm.labelText) && vm.labelText !== '') {
                return vm.labelText;
            }
            if (model) {
                return model.getName();
            }
            return '';
        }

        function getInitials(model) {
            if (angular.isDefined(vm.avatarText) && vm.avatarText !== '') {
                return vm.avatarText;
            }
            if (model) {
                var nameParts = model.getName().split(' ');
                var firstLetters = nameParts.map(function (part) {
                    return part[0];
                });
                return firstLetters.join('').toUpperCase().slice(0, 2);
            }
            return '';
        }

        /*
        function getMoreInfo(model) {
        }
        */
    }
})();
