// <pay-character-counter watch="paymentForm.message.$viewValue" max="20">
// </pay-character-counter>

'use strict';

angular
    .module('dbw-payments.corporate.common')
    .directive('payCharacterCounter', function payCharacterCounterDirective() {
        return {
            restrict: 'E',
            scope: {
                watch: '<',
                max: '<'
            },
            template: '<span class="label label--secondary"></span>',
            link: function (scope, element, attrs) {
                var counterEl = element.find('span');
                scope.$watch('watch', function (newValue) {
                    if (typeof newValue === 'string') {
                        counterEl.html('&nbsp;' + '(' + newValue.length + (scope.max !== undefined ? ('/' + scope.max) : '') + ')');
                    } else {
                        counterEl.html('');
                    }
                });
            }
        };
    });
