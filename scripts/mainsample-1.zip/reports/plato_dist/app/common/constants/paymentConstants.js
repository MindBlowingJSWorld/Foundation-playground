'use strict';

var PaymentConstants = {
    'SUCCESS' : 'SUCCESS',
    'ERROR' : 'ERROR',

    'MESSAGE_LENGTH': {
        'hard': '25',
        'soft': '220',
        '3rdPartyMessage': '12',
        'bgPgMessage': '220'
    },
    'OWN_NOTES_LENGTH': {
        '3rdPartyOwnNotes': '20',
        'bgPgOwnNotes': '35'
    },
    'TYPE': {
        'HARD': 'hard',
        'SOFT': 'soft',
        'NO': 'no'
    },
    'TAB_NAMES': {
        'all': 'All',
        'unconfirmed': 'Unconfirmed',
        'notbooked': 'Rejected/Stopped',
        'confirmed': 'Confirmed'
    },
    'OUTGOING_PAYMENT_STATUS': {
        'UNCONFIRMED': 'unconfirmed',
        'NOT_BOOKED': 'rejected',
        'CONFIRMED': 'confirmed',
        'NOT_BOOKED_STATUS': 'notbooked',
        'ALL': 'all'
    },
    'OUTGOING_PAYMENT_TABS':  ['all','unconfirmed','notbooked', 'confirmed'],
    /* Keys to be fetched form phaseApp. */
    'OUTGOING_PAYMENT_KEYS': {
        'date': 'Date',
        'from': 'From',
        'amount': 'Amount',
        'to': 'To',
        'type': 'Type',
        'status': 'Status',
        'date_format': 'dd.MM.yyyy',

        'sign': 'Sign',
        'edit': 'Edit',
        'delete': 'Delete',

        'noPayments': 'No payments found !!!',
        'approve': 'Approve selected',
        'total': 'TOTAL'
    },
    'DATE_PICKER_DATE_FORMAT': 'DD.MM.YYYY',
    'CURRENCY_CONSTANTS': {
        'EUR': 'EUR',
        'SEK': 'SEK'
    }

};

angular.module('dbw-payments.corporate.common')
    .constant('paymentConstants', PaymentConstants);
