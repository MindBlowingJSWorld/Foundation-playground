(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.dropdownList', [])
        .constant('KEY_CODES', {
            UP: 38,
            DOWN: 40,
            ENTER: 13,
            BACKSPACE: 8,
            DELETE: 46,
            ESC: 27
        });
})();
