(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.dropdownList')
        .component('dbwCorpDropdownList', {
            bindings: {
                name: '@',
                fieldName: '@',
                selectedOption: '=model',
                options: '<'
            },
            require: {
                formCtrl: '?^form',
                ngModelCtrl: '?^ngModel',
                ndInputContainerCtrl: '?^ndInputContainer'
            },
            transclude: true,
            controllerAs: 'vm',
            controller: dbwDropdownListController,
            templateUrl: 'common/dropdownList/dropdownList.tpl.html'
        });

    function dbwDropdownListController($element,
                                       $scope,
                                       KEY_CODES,
                                       $timeout) {
        $element.addClass('dbw-dropdown-list');
        var vm = this;
        var activeClass = 'active';
        var keyActions = {};
        vm.$onInit = init;
        vm.isOpen = false;
        vm.selectedOptionIndex = 0;
        vm.inputModel = null;

        function init() {
            vm.onMouseDownOption = onMouseDownOption;
            vm.onInputFocus = onInputFocus;
            vm.onInputBlur = onInputBlur;

            // alternate parameter name for avoiding collisions in form naming
            vm.name = vm.name || vm.fieldName;

            $element.on('keydown', onKeyDown);
            $scope.$watch(isParentFormSubmitted, updateValidation);
            $scope.$watch('vm.options', updateIndex);
            $scope.$watch('vm.selectedOption', onSelectedOptionChange);
            $scope.$watch('vm.formCtrl[vm.name].$viewValue', onViewValueChange);
            $scope.$watch('vm.formCtrl[vm.name].$valid', updateValidation);
            $scope.$watch('vm.formCtrl[vm.name].$untouched', updateValidation);
            var inputElement = $element.find('input:first');

            $element.bind('click', function () {
                inputElement.focus();
            });

            keyActions[KEY_CODES.UP] = moveToPreviousElement;
            keyActions[KEY_CODES.DOWN] = moveToNextElement;
            keyActions[KEY_CODES.ENTER] = selectCurrentElement;
            keyActions[KEY_CODES.ESC] = closeDropdown;
        }

        function onKeyDown(event) {
            var action = keyActions[event.keyCode];
            if (action) {
                action(event);
                $scope.$apply();
            }
        }

        function moveToNextElement() {
            setIndex(
                Math.min(
                    vm.selectedOptionIndex + 1,
                    (vm.options ? vm.options.length - 1 : -1)
                )
            );
            updatePaneScroll();
        }

        function moveToPreviousElement() {
            setIndex(
                Math.max(
                    vm.selectedOptionIndex - 1,
                    -1
                )
            );
            updatePaneScroll();
        }

        function updatePaneScroll() {
            $timeout(function updateScroll() {
                var maxNumOpts = 5;
                var optionHeight = 52;
                var paneEl = $element.find('dbw-dropdown-list-options .dropdown-pane');
                var scrollPx = paneEl.scrollTop();
                var selectedEl = paneEl.find('dbw-dropdown-list-option.' + activeClass);
                var selectedElOffset = selectedEl.position() ? selectedEl.position().top : 0;

                var tooHighPx = selectedElOffset;
                if(tooHighPx < 0) {
                    paneEl.scrollTop(scrollPx + tooHighPx);
                }
                var tooLowPx = selectedElOffset - (maxNumOpts - 1) * optionHeight;
                if(tooLowPx > 0) {
                    paneEl.scrollTop(scrollPx + tooLowPx);
                }
            }, 0);
        }

        function setIndex(index) {
            vm.selectedOptionIndex = index;
            vm.selectedOption = vm.options[vm.selectedOptionIndex];
        }

        function onMouseDownOption(model) {
            $scope.$apply(function () {
                vm.selectedOption = model;
                updateIndex();
                closeDropdown();
            });
        }

        function selectCurrentElement(e) {
            closeDropdown();
            e.preventDefault();
        }

        function onSelectedOptionChange() {
            updateIndex();
            updateValidation();
            updateInputModel();
        }

        function onViewValueChange() {
            updateValidation();
            updateInputModel();
        }

        function updateInputModel() {
            // filling input with whitespace to trigger input container behaviour
            if(vm.selectedOption) {
                vm.inputModel = ' ';
            } else {
                vm.inputModel = (vm.formCtrl[vm.name] && vm.formCtrl[vm.name].$viewValue) ? ' ' : null;
            }
        }

        function updateIndex() {
            if (_.isArray(vm.options)) {
                vm.selectedOptionIndex = Array.prototype.indexOf.call(vm.options, vm.selectedOption);
            }
        }

        function updateValidation() {
            // propagate validation result to ndInputContainer
            if (vm.ngModelCtrl && vm.ndInputContainerCtrl) {
                if (vm.ngModelCtrl.$touched || isParentFormSubmitted()) {
                    $timeout(function () {
                        vm.ndInputContainerCtrl.setInvalid(
                            vm.ngModelCtrl.$invalid
                        );
                    }, 0);
                }
            }
        }

        function onInputFocus() {
            if (vm.ngModelCtrl) {
                vm.ngModelCtrl.$setTouched();
            }
            openDropdown();
        }

        function onInputBlur() {
            if (vm.ngModelCtrl) {
                vm.ngModelCtrl.$setTouched();
                updateValidation();
            }
            closeDropdown();
        }

        function openDropdown() {
            vm.isOpen = true;
        }

        function closeDropdown() {
            vm.isOpen = false;
        }

        function isParentFormSubmitted() {
            return vm.formCtrl ? vm.formCtrl.$submitted : false;
        }
    }
})();
