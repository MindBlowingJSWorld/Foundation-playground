(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.dropdownList')
        .directive('dbwCorpDropdownListInputNoView', function directive() {
            return {
                restrict: 'A',
                require: 'ngModel',
                link: function (scope, elem, attrs, ngModelCtrl) {
                    ngModelCtrl.$parsers.push(function (inputValue) {
                        var modelValue = ngModelCtrl.$modelValue;
                        var cleanInputValue = modelValue ? ' ' : '';
                        if (cleanInputValue !== inputValue) {
                            ngModelCtrl.$setViewValue(cleanInputValue);
                            ngModelCtrl.$render();
                        }
                        return modelValue;
                    });
                }
            };
        });
})();
