(function () {
    'use strict';

    var defaultActiveClass = 'active';

    angular
        .module('dbw-payments.corporate.common.dropdownList')
        .component('dbwCorpDropdownListOption', {
            require: {
                parent: '^dbwCorpDropdownList'
            },
            bindings: {
                model: '<',
                activeClass: '@?activeClass'
            },
            transclude: true,
            controller: dbwDropdownListOptionController,
            controllerAs: 'vm',
            template: '<ng-transclude></ng-transclude>'
        });

    function dbwDropdownListOptionController($scope, $element) {
        $element.addClass('dbw-dropdown-list-option');
        var vm = this;
        vm.isSelected = false;

        $element.bind('mousedown', function(e) {
            vm.parent.onMouseDownOption(vm.model);
            e.stopPropagation();
        });

        $scope.$watch('vm.parent.selectedOption', function (selectedOption) {
            vm.isSelected = selectedOption === vm.model;
            $element.toggleClass(vm.activeClass || defaultActiveClass, vm.isSelected);
        });
    }
})();
