(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.dropdownList')
        .component('dbwCorpDropdownListOptions', {
            require: {
                parent: '^dbwCorpDropdownList'
            },
            transclude: true,
            controllerAs: 'vm',
            controller: dbwDropdownListOptionsController,
            template:
                '<ng-transclude ng-class="{\'is-open\': vm.parent.isOpen}"' +
                ' class="dropdown-pane"></ng-transclude>'
        });

    function dbwDropdownListOptionsController($element) {
        $element.addClass('dbw-dropdown-list-options');
    }
})();
