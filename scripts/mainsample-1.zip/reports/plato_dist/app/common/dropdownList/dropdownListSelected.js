(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.dropdownList')
        .component('dbwCorpDropdownListSelected', {
            require: {
                parent: '^dbwCorpDropdownList'
            },
            transclude: true,
            controller: dbwDropdownListSelectedController,
            controllerAs: 'vm',
            template: '<ng-transclude></ng-transclude>'
        });

    function dbwDropdownListSelectedController($element) {
        $element.addClass('dbw-dropdown-list-selected');
    }
})();
