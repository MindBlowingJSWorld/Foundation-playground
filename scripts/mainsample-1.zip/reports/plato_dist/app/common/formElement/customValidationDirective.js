'use strict';

var ndCustomValidationDirective = function ($q) {
    return {
        require: ['ngModel', '^form'],       // get a hold of NgModelController and parent form controller
        restrict: 'A',
        scope: {
            syncValidators: '=',
            asyncValidators: '='
        },

        link: function (scope, element, attrs, controllers) {
            var model = controllers[0];
            var form = controllers[1];
            var inputElemenError = 'ndCustomValidation must be set on an input element that has a "name" attribute';
            var inputNameAttributeError = 'ndCustomValidation must be set in a form that has a "name" attribute';

            if (!attrs.name) {
                throw inputElemenError;
            }
            if (!form.$name) {
                throw inputNameAttributeError;
            }

            function registerValidators(validators, type) {
                var i = 1;
                angular.forEach(validators, function (validator) {
                    var modelValidators = type === 'sync' ? model.$validators : model.$asyncValidators;

                    scope.$parent.$parent.addValidInputFieldErrorMsg(validator.msgkey, validator.msgdata, validator.show);
                    modelValidators[validator.msgkey] = function () {
                        //$pristine tells whether the form element has not been used
                        if (model.$pristine && (!validator.ignorepristine || validator.ignorepristine !== 'true')) {
                            return type === 'async' ? $q.when(true) : true;
                        }
                        return validator.validate(form, element, model);
                    };
                    i++;
                });
            }

            registerValidators(scope.syncValidators, 'sync');
            registerValidators(scope.asyncValidators, 'async');

        }
    };
};


angular.module('dbw-payments.corporate.common')
    .directive('ndCustomValidation', ndCustomValidationDirective);
