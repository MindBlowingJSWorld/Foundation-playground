'use strict';

angular.module('dbw-payments.corporate.common')
    .directive('ndError', function ndErrorDirective() {
        return {
            restrict: 'E',
            link: function (scope) {
                scope.$on('$destroy', function () {
                    var pos = scope.$parent.listErrors.indexOf(scope.$id);
                    scope.$parent.listErrors.splice(pos, 1);
                });

                scope.$parent.listErrors.push(scope.$id);
            }
        };
    });
