'use strict';

angular.module('dbw-payments.corporate.common')
    .directive('ndErrorParent', function ndErrorParentDirective() {
        return {
            controller: function ($scope) {
                this.setAttribute = function (attribute, value) {
                    $scope.setAttr(attribute, value);
                };
            },
            link: function (scope, element, attrs) {
                scope.setAttr = function (attribute, value) {
                    attrs.$set(attribute, value);
                };
            }
        };
    });
