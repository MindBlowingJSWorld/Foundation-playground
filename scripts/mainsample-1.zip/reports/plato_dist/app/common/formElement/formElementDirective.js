'use strict';

var ndFormElementDirective = function () {
    return {
        replace: true,
        transclude: true,
        require: '^form',
        scope: {
            name: '@',
            label: '@',
            labelFor: '@',
            labelKey: '@',
            contentPage: '@',
            validationrules: '=ndValidationrules',
            showLabel: '@'
        },
        controller: function ($scope) {
            $scope.listErrors = [];
            $scope.currentPlaceholder = '';
            $scope.inputfieldvalidmsgkeys = [];
            $scope.crossFieldError = {
                show: false,
                msg: ''
            };

            if (!$scope.showLabel) {
                $scope.showLabel = 'true';
            }

            $scope.addValidInputFieldErrorMsg = function (msg, data, show) {
                $scope.inputfieldvalidmsgkeys[msg] = {
                    show: show ? show : true,
                    data: data ? data : ''
                };
            };

            $scope.errorValidToShow = function (msg) {
                // set showrule to false on all built-in validation tokens
                var showrule = $scope.inputfieldvalidmsgkeys[msg] ? $scope.inputfieldvalidmsgkeys[msg].show : false;
                return !showrule ? false : showrule === true || $scope.$eval(showrule);
            };

            $scope.hasErrors = function () {
                return $scope.crossFieldError.show || ($scope.listErrors && $scope.listErrors.length > 0);
            };

            $scope.evaluateRule = function (rule) {
                return $scope.$eval(rule);
            };

            $scope.hasMultipleErrors = function () {
                return $scope.listErrors && $scope.listErrors.length > 1;
            };

            $scope.$on('show_crossfield_error', function (event, data) {
                if (data.form === $scope.parentForm.$name && data.rule.field === $scope.name) {
                    $scope.crossFieldError = {
                        msg: data.rule.msg,
                        show: data.rule.show ? $scope.$eval(data.rule.show) : true
                    };
                    $scope.setCrossFieldValidation(false);
                }
            });

            $scope.$on('hide_crossfield_error', function (event, data) {
                if (data.form === $scope.parentForm.$name && data.rule.field === $scope.name) {
                    $scope.crossFieldError = {
                        msg: undefined,
                        show: false
                    };
                    $scope.setCrossFieldValidation(true);
                }
            });
        },
        link: function (scope, element, attrs, parentForm) {
            element.addClass('dbw-form-element');
            scope.parentForm = parentForm;
        },
        templateUrl: 'common/formElement/formElement.tpl.html'
    };
};

angular.module('dbw-payments.corporate.common')
    .directive('ndFormElement', ndFormElementDirective);
