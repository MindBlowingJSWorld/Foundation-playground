'use strict';

angular.module('dbw-payments.corporate.common')
    .directive('ndValidate', function ndValidateDirective() {
        return {
            require: ['ngModel', '^form'],       // get a hold of NgModelController and parent form controller
            restrict: 'A',
            link: function (scope, element, attrs, controllers) {
                var inputmodel = controllers[0];
                scope.parentForm = controllers[1];
                scope[attrs.ndValidate] = inputmodel;

                scope.$parent.inputfielderrors = inputmodel.$error;

                scope.$parent.setCrossFieldValidation = function (validity) {
                    inputmodel.$setValidity('CrossFieldError', validity);
                };

                angular.forEach(scope.$parent.validationrules, function (validationrule) {
                    scope.$parent.addValidInputFieldErrorMsg(validationrule.msgkey, validationrule.msgdata, validationrule.show);
                    inputmodel.$validators[validationrule.msgkey] = function () {
                        return scope.$parent.evaluateRule(validationrule.rule);
                    };
                });
            }
        };
    });
