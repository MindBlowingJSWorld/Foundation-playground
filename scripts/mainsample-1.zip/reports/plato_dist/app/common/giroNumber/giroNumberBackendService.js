'use strict';

angular.module('dbw-payments.corporate.common')

    .factory('giroNumberBackendService', function giroNumberBackendServiceFactory(PayeeService) {
        var validatorFunctions;

        return {
            /**
             * To set the necessary backend validators.
             * The functions need to return a promise.
             *
             * @param validators
             *  {
             *      findPayees: function(giroNumber}
             *  }
             */
            configure: function (validators) {
                validatorFunctions = validators;
            },

            findPayees: function (number) {
                if (!validatorFunctions || !validatorFunctions.findPayees) {
                    return PayeeService._getPayeeInfo(number);
                }
                return validatorFunctions.findPayees(number);
            }
        };
    });
