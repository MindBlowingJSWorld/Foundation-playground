'use strict';

function GiroNumberController($q, giroNumberValidator, giroNumberFormatter, $element) {
    var vm = this;
    $element.addClass('dbw-giro-number');

    function hasBackendValidation() {
        return vm.backendValidation && vm.backendValidation === 'true' ? true : false;
    }

    function hasOnFocus() {
        return vm.events && vm.events.onFocus;
    }

    function hasOnBlur() {
        return vm.events && vm.events.onBlur;
    }

    function hasOnBackendResponse() {
        return vm.events && vm.events.onBackendResponse;
    }

    function getNgModelController() {
        return vm.form[vm.name];
    }

    function setFieldAsFocused() {
        vm.payeeResponse = [];
        getNgModelController().$setUntouched();
    }

    function setFieldAsBlurred() {
        getNgModelController().$setTouched();
    }

    function fieldIsFocused() {
        return getNgModelController().$untouched;
    }

    /**
     * Returns true if the number was formatted
     * @returns {boolean}
     */
    function format() {
        if (!vm.model || !vm.model.number || vm.model.number.indexOf('-') === -1) {
            return false;
        }

        //makes a copy of the model.
        var previousModel = JSON.parse(JSON.stringify(vm.model));

        vm.model.number = giroNumberFormatter.format(vm.model.number);
        vm.model.type = giroNumberValidator.getGiroType(vm.model.number);

        return previousModel.number !== vm.model.number;
    }

    /**
     * Checks if the giro number format is valid
     */
    vm.isValidInputFormat = function (form, element, ngModelCtrl) {
        var giroNumber = ngModelCtrl.$viewValue;
        if (!giroNumberValidator.hasValidCharacters(giroNumber)) {
            return true;
        }

        var valid = giroNumberValidator.validate(giroNumber);
        //clears the type
        if (!valid) {
            vm.model.type = undefined;
        }
        return valid;
    };

    /**
     * Calls the backend to verify if the giro account number exists.
     * This validator is ignored if the backend-validation attribute is set to 'false' or if the field is still focused.
     * (We want it to be executed once the field has been blurred)
     */
    vm.isValidGiroNumber = function (form, element, ngModelCtrl) {

        if (!hasBackendValidation() || fieldIsFocused()) {
            return $q.when();
        }
        var number = ngModelCtrl.$viewValue;

        var validationPromise = giroNumberValidator.findMatchingGiroNumbers(number);

        return validationPromise.then(
            function (data) {
                vm.payeeResponse = data;

                if (data.length === 0) {
                    return $q.reject();
                }
                if (data.length === 1) {
                    vm.model.type = data[0].type;
                    vm.model.number = data[0].number;
                    format();
                }

                return $q.when();
            },
            function () {
                return $q.when();
            }).finally(function () {
                if (hasOnBackendResponse()) {
                    vm.events.onBackendResponse(validationPromise);
                }
            });
    };

    vm.select = function (giroNumber) {
        vm.model.type = giroNumber.type;
        vm.model.number = giroNumber.number;
    };

    /**
     * When the giro number input field is focused
     */
    vm.onFocus = function () {
        setFieldAsFocused();
        if (hasOnFocus()) {
            vm.events.onFocus();
        }
    };

    /**
     * When the giro number input field has lost focus
     */
    vm.onBlur = function () {
        format();
        setFieldAsBlurred();

        //if the client validation is valid we check the backend validation
        if (getNgModelController().$valid) {
            //this will trigger all validators again, including the async validators
            getNgModelController().$validate();
        }

        if (hasOnBlur()) {
            vm.events.onBlur();
        }
    };
}

angular.module('dbw-payments.corporate.common')
    .controller('giroNumberController', GiroNumberController);
