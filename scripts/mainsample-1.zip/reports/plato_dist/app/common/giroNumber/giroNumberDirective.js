'use strict';

angular.module('dbw-payments.corporate.common')
    .directive('dbwGiroNumber', function dbwGiroNumberDirective() {
        return {
            restrict: 'E',
            require: '^form',
            scope: {
                name: '@',
                contentPage: '@',
                model: '=',
                backendValidation: '@',
                events: '='
            },
            controller: 'giroNumberController',
            controllerAs: 'vm',
            link: function (scope, element, attrs, form) {
                scope.form = form;

                if (!scope.model) {
                    scope.model = {
                        number: '',
                        type: ''
                    };
                }

            },
            templateUrl: 'common/giroNumber/giroNumber.tpl.html'
        };
    });
