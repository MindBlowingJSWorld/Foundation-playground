'use strict';

angular.module('dbw-payments.corporate.common')
    .factory('giroNumberFormatter', function giroNumberFormatterFactory(StringUtils) {
        return {
            format: function (number) {
                if (!number) {
                    return undefined;
                }

                var input = StringUtils.removeSpaces(number);

                var sevenDigitPgPattern = /^(\d{7}[\-]{1}\d{1})$/g;
                var sixDigitPgPattern = /^(\d{6}[\-]{1}\d{1})$/g;
                var fiveDigitPgPattern = /^(\d{5}[\-]{1}\d{1})$/g;
                var fourDigitPgPattern = /^(\d{4}[\-]{1}\d{1})$/g;
                var threeDigitPgPattern = /^(\d{3}[\-]{1}\d{1})$/g;

                if (sevenDigitPgPattern.test(input)) {
                    return input.substring(0, 3) + ' ' + input.substring(3, 5) + ' ' + input.substring(5, input.length);
                } else if (sixDigitPgPattern.test(input)) {
                    return input.substring(0, 2) + ' ' + input.substring(2, 4) + ' ' + input.substring(4, input.length);
                } else if (fiveDigitPgPattern.test(input)) {
                    return input.substring(0, 1) + ' ' + input.substring(1, 3) + ' ' + input.substring(3, input.length);
                } else if (fourDigitPgPattern.test(input)) {
                    return input.substring(0, 2) + ' ' + input.substring(2, input.length);
                } else if (threeDigitPgPattern.test(input)) {
                    return input.substring(0, 1) + ' ' + input.substring(1, input.length);
                }
                return input;
            }
        };
    });
