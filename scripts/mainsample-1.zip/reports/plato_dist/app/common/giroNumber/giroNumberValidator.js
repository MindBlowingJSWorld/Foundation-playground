'use strict';

angular.module('dbw-payments.corporate.common')
    .factory('giroNumberValidator', function giroNumberValidatorFactory(giroNumberBackendService, StringUtils) {

        var validCharactersRegexp = /^[\d\s\-]*$/;
        var twoToEightDigitsRegexp = /^\d{2,8}$/;

        function matchPgPattern(trimmedInput) {
            var pgPattern = /^(\d{1,7}[\-]{1}\d{1})$/g;
            return pgPattern.test(trimmedInput);
        }

        function matchBgPattern(trimmedInput) {
            var bgPattern = /^(\d{3,4}[\-]{1}\d{4})$/g;
            return bgPattern.test(trimmedInput);
        }

        function containsDash(string) {
            return string.indexOf('-') !== -1;
        }

        /**
         * Checks if the trimmed input matches any of these patterns.
         * BG-pattern: 3-4 digits followed by a mandatory dash and ends with 4 digits.
         * PG-pattern: 1-7 digits followed by a mandatory dash and ends with 1 digit.
         *
         * @param input what the user have entered
         * @returns {boolean} true on match, otherwise false.
         */
        function matchGiroNumber(input) {
            var trimmedInput = StringUtils.removeSpaces(input);
            return matchBgPattern(trimmedInput) || matchPgPattern(trimmedInput);
        }

        /**
         * A property to keep track of the latest validated giroNumber, so that we do not run unnecessary backend calls.
         * @type {}
         */

        return {
            containsDash: containsDash,
            /**
             * Checks if there are valid characters in the given number string.
             * @param number
             * @returns {*|boolean}
             */
            hasValidCharacters: function (number) {
                return number && validCharactersRegexp.test(number);
            },
            /**
             * Validates the given number string strictly against a BG & PG pattern
             * @param number
             * @returns {boolean}
             */
            validate: function (number) {
                if (!number) {
                    return false;
                }

                if (containsDash(number)) {
                    return matchGiroNumber(number) ? true : false;
                }
                return false;
                //Commented below code because couldn't understand the meaning of putting this code here,
                //So, If some thing is broken since the code is commented talk to Madhur
                /*else {
                    return this.validateSimple(number);
                }*/
            },
            /**
             * Validates the given number string with a simple approach to check the number of digits.
             * @param number
             * @returns {*|boolean}
             */
            validateSimple: function (number) {
                return number && twoToEightDigitsRegexp.test(StringUtils.removeSpacesAndHyphens(number));
            },
            findMatchingGiroNumbers: function (inNumber) {
                var number = inNumber;
                var giroType = this.getGiroType(number);
                number = StringUtils.removeSpacesAndHyphens(number);
                return giroNumberBackendService.findPayees(giroType + '-' + number);

            },
            isPG: function (number) {
                return number && matchPgPattern(StringUtils.removeSpaces(number));
            },
            isBG: function (number) {
                return number && matchBgPattern(StringUtils.removeSpaces(number));
            },
            getGiroType: function (number) {
                var pgType = this.isPG(number) ? 'PG' : undefined;
                return this.isBG(number) ? 'BG' : pgType;
            }
        };
    });

