(function () {
    'use strict';

    /**
     * Allowed chars:
     * a – z, A – Z, 0 - 9
     * äöå ÄÖÅ
     * / - ? : ( ) . , ' +
     * Space
     *
     * Field must not start with a colon ':' or hyphen '-' or Space
     */
    angular
        .module('dbw-payments.corporate.common')
        .directive('dbwCorpOwnTransferMessageAllowedCharacters', dbwCorpOwnTransferMessageAllowedCharactersFormatter);

    var allowedCharactersRegex = /[^a-zA-Z0-9äöåÄÖÅ/\-\?:\(\)\.,'\+ ]/g;
    var charactersNotAllowedAtBeginningRegex = /^[ :-]*/;

    function dbwCorpOwnTransferMessageAllowedCharactersFormatter() {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                ngModelCtrl.$parsers.push(function (inputValue) {
                    if (inputValue === null) {
                        return '';
                    }
                    var cleanInputValue = inputValue
                        .replace(allowedCharactersRegex, '')
                        .replace(charactersNotAllowedAtBeginningRegex, '');
                    if (cleanInputValue !== inputValue) {
                        ngModelCtrl.$setViewValue(cleanInputValue);
                        ngModelCtrl.$render();
                    }
                    return cleanInputValue;
                });
            }
        };
    }
})();
