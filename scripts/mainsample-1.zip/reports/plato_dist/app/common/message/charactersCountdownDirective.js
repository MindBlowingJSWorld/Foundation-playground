'use strict';
angular
    .module('dbw-payments.corporate.common')
    .directive('dbwCorpCharactersCountdown', function dbwCorpCharactersCountdownDirective() {
        return {
            require: 'ngModel',
            restrict: 'A',
            scope: {
                dbwCorpCharactersCountdown: '=dbwCorpCharactersCountdown'
            },
            link: function (scope, element, attrs, ngModel) {

                function setCountdown(input) {
                    var inputLength = 0;
                    if (input) {
                        var newLines = input.match(/(\r\n|\n|\r)/g);
                        var addition = 0;
                        if (newLines !== null) {
                            addition = newLines.length;
                        }
                        inputLength = input.length + addition;
                    }
                    scope.dbwCorpCharactersCountdown = input ? inputLength : 0;
                }

                scope.$watch(
                    function () {
                        return ngModel.$viewValue;
                    },
                    function (input) {
                        setCountdown(input);
                    }
                );
            }
        };
    });
