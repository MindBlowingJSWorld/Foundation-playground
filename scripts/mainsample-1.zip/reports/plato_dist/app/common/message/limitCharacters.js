(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common')
        .directive('dbwCorpLimitCharacters', [function dbwCorpLimitCharacters() {
            return {
                restrict: 'A',
                require: 'ngModel',
                link: function(scope, elem, attrs, ctrl) {
                    var lengthLimit = parseInt(attrs.limitTo);
                    ctrl.$viewChangeListeners.push(function (){
                        if(ctrl.$viewValue.length > lengthLimit){
                            ctrl.$setViewValue(ctrl.$viewValue.substring(0,lengthLimit));
                            ctrl.$render();
                        }
                    });


                }
            };
        }]);


})();
