(function () {
    'use strict';

    /**
     * FI: 35 characters (own transfer)
     * SE: 20 characters (own transfer)
     */
    angular
        .module('dbw-payments.corporate.common')
        .directive('dbwCorpOwnTransferMessageMaxLength', maxLengthValidator);

    var maxLengthByCountry = {
        'FI': 35,
        'SE': 20
    };

    function maxLengthValidator($window) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, ele, attrs, ctrl) {
                ctrl.$validators.maxlength = function (modelValue) {
                    if (typeof modelValue === 'undefined') {
                        return true;
                    }
                    if(maxLengthByCountry[$window.COUNTRY]) {
                        return modelValue.length <= maxLengthByCountry[$window.COUNTRY];
                    }
                    return true;
                };
            }
        };
    }
})();
