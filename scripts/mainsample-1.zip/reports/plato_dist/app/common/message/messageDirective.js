'use strict';

angular.module('dbw-payments.corporate.common')
    .directive('dbwCorpMessage', function dbwCorpMessageDirective() {
        return {
            restrict: 'E',
            scope: {
                name: '@',
                contentPage: '@',
                model: '=',
                type: '@',
                maxCharacters: '@',
                placeholder: '@',
                countryCode: '@',
                rows: '@',
                cols: '@',
                required: '@',
                showLabel: '@'
            },
            controller: function ($scope, dbwCorpMessageValidator) {
                $scope.hardValidation = function (form, element, model) {
                    if ($scope.type !== 'hard') {
                        return true;
                    }
                    return dbwCorpMessageValidator.validate(model.$viewValue, $scope.type, $scope.maxCharacters, $scope.countryCode);
                };

                $scope.softValidation = function (form, element, model) {
                    if ($scope.type !== 'soft') {
                        return true;
                    }
                    return dbwCorpMessageValidator.validate(model.$viewValue, $scope.type, $scope.maxCharacters, $scope.countryCode);
                };

                $scope.messageValidation = function (form, element, model) {
                    if ($scope.type !== 'no') {
                        return true;
                    }
                    return dbwCorpMessageValidator.validate(model.$viewValue, $scope.type, $scope.maxCharacters, $scope.countryCode);
                };
            },

            link: function (scope, element) {
                element.addClass('dbw-message');
                //set default
                if (scope.type === undefined) {
                    scope.type = 'no';
                }
                if (scope.showLabel === undefined) {
                    scope.showLabel = 'true';
                }
                if (scope.rows === undefined) {
                    scope.rows = '0';
                }
                scope.getTemplate = function () {
                    return (scope.rows < 2) ? 'common/message/message.tpl.html' : 'common/message/messageTextarea.tpl.html';
                };
            },
            template: '<div ng-include="getTemplate()"></div>'
        };
    });
