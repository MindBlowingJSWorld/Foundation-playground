'use strict';
angular.module('dbw-payments.corporate.common')
    .factory('dbwCorpMessageValidator', function messageValidatorFactory() {
        var noneOcrDefault = 220;
        return {
            validate: function (input, type, inMaxChars, countryCode) {
                var maxChars = inMaxChars;
                maxChars = (typeof maxChars === 'undefined') ? noneOcrDefault : maxChars;
                if (type === 'hard') {
                    var pattern = /^[0-9]+$/g;
                    return input.length <= maxChars && pattern.test(input);
                }
                if (type === 'no') {
                    var RE_MESSAGE_CHARACTERS_PATTERN;
                    var RE_INVALID_CHARACTERS_AT_BEGIN;
                    if (countryCode === 'sw' || countryCode === undefined) {
                        RE_MESSAGE_CHARACTERS_PATTERN = /^[a-zA-Z0-9äöåÄÖÅÆæøØ\/\-\?\:\(\)\r\n .,_;\'\+]*$/;
                        RE_INVALID_CHARACTERS_AT_BEGIN = /^[^-: \/]/;
                    } else {
                        RE_MESSAGE_CHARACTERS_PATTERN = /^[a-zA-Z0-9äöåÄÖÅÆæøØ\/\-\?\:\(\)\r\n .,_;!%&*<=>\'\+]*$/;
                        RE_INVALID_CHARACTERS_AT_BEGIN = /^[^-:]/;
                    }
                    if (!input || (RE_INVALID_CHARACTERS_AT_BEGIN.test(input) && RE_MESSAGE_CHARACTERS_PATTERN.test(input))) {
                        return true;
                    }
                    return false;
                } else {
                    return input.length <= maxChars;
                }
            }
        };
    });

