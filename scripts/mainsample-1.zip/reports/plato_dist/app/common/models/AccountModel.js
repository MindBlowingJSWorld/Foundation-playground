'use strict';

function AccountModel(defaultCurrencyCode) {

    /**
     * A function to set the "not found"-key as a low prioritized account for sorting
     * @param key either account type group or account type category
     * @param orderArray the order of account type groups / categories
     * @returns {*}
     */
    function _getSortingPriority(key, orderArray) {
        var lowPriority = 100;
        var priority = orderArray.indexOf(key);

        return priority >= 0 ? priority : lowPriority;
    }

    /**
     * Defined order of type groups
     * @type {string[]}
     */
    var _accountCategory = ['TRANSACTION', 'FIXED_TERM_DEPOSIT', 'SAVINGS'];

    /**
     * Defined order of type categories
     * @type {string[]}
     */
    var _accountGroup = ['PSOID_AFFARSGIRO', 'PSOID_PLUSGIROKONTO_FORETAG', 'PSOID_PLUSGIROKONTO_FORENING', 'PSOID_FORENINGSGIRO'];


    /**
     * @param data
     * @constructor
     */
    function Account(data) {
        angular.extend(this, data);
        this.accountTypeCategoryPriority = _getSortingPriority(this.getAccountTypeCategory(), _accountCategory);
        this.accountTypeGroupPriority = _getSortingPriority(this.getAccountTypeGroup(), _accountGroup);
    }

    Account.prototype.getAccountTypeGroup = function () {
        return this.product_code;
    };

    Account.prototype.getAccountTypeCategory = function () {
        return this.product_type;
    };

    Account.prototype.getAccountName = function () {
        return this.nickname || this.product_name;
    };

    Account.prototype.getAccountNumber = function () {

        if (this.display_account_number !== undefined) {
            var accountNumber = this.display_account_number;
            var len = accountNumber.length;
            if (this.isGiroNumber()) {
                accountNumber = accountNumber.substring(0, len - 1) + '-' + accountNumber.substring(len - 1, len);
            }
            return accountNumber;
        } else {
            return this.display_account_number;
        }

    };

    Account.prototype.isGiroNumber = function () {
        return this.product_name.toUpperCase().indexOf('GIRO') > -1;
    };

    Account.prototype.getAvailableAmountIncludingCredit = function () {
        // return this.remainingCredit < 0 ? this.remainingCredit : this.availableIncludingCredit;
        return this.getBalance();
    };

    Account.prototype.getAvailableAmountExcludingCredit = function () {
        //return this.getAccountTypeCategory() !== 'FIXED_TERM_DEPOSIT' ? this.availableExcludingCredit : this.balance;
        return this.getBalance();
    };

    Account.prototype.getCurrency = function () {
        return this.currency;
    };

    Account.prototype.hasAgreedCredit = function () {
        return this.credit_limit > 0;
    };

    Account.prototype.hasAnotherCurrency = function () {
        return this.getCurrency() !== defaultCurrencyCode;
    };

    Account.prototype.isSavingsAccount = function () {
        return this.product_type === 'SAVINGS';
    };

    Account.prototype.isTransactionAccount = function () {
        return this.product_type === 'TRANSACTION';
    };

    Account.prototype.getBalance = function () {
        return this.available_balance;
    };

    Account.prototype.isFixedTermDepositAccount = function () {
        return this.product_type === 'FIXED_TERM_DEPOSIT';
    };

    Account.prototype.getCreditLimit = function () {
        return this.credit_limit;
    };

    Account.prototype.getType = function () {
        if (this.product_name.toUpperCase().startsWith('BANK')) {
            return 'BG';
        } else if (this.product_name.toUpperCase().startsWith('PLUS')) {
            return 'PG';
        } else if (this.account_number.startsWith('IBAN')) {
            return 'IBAN';
        } else if (this.account_number.startsWith('LBAN')) {
            return 'LBAN';
        } else {
            return 'NAID';
        }
    };
    return Account;
}

angular.module('dbw-payments.corporate.common.models')
    .factory('Payments_AccountModel', AccountModel)
    .constant('defaultCurrencyCode', 'SEK');
