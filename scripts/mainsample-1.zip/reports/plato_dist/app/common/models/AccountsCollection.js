'use strict';

function AccountsCollectionModel(Payments_AccountModel) {

    /**
     * Sums all savings and transaction accounts amounts based on the key, which tells us which property to summarize.
     * Negative amounts will be ignored as requested by our PO.
     *
     * @param accounts all accounts
     * @param key either 'availableExcludingCredit' or 'availableIncludingCredit'
     * @returns {number}
     */
    function totalAmount(accounts, key) {
        var sum = 0;

        angular.forEach(accounts, function (account) {
            if (account.isSavingsAccount() || account.isTransactionAccount()) {
                var amount = account[key];
                if (amount > 0) {
                    sum += amount;
                }
            }

        });
        return sum;
    }

    /**
     * @param accounts
     * @constructor
     */
    function AccountsCollection(accountsData) {
        this.accounts = [];
        this.setAccounts(accountsData);
        if (this.accounts[0] !== undefined) {
            this.accountsTotalCurrency = new Payments_AccountModel(this.accounts[0]).getCurrency();
        }
    }

    function totalAmountWithAllValues(accounts, key) {
        var sum = 0.00;
        angular.forEach(accounts, function (account) {
            var amount = 0.00;
            if (key === 'availableIncludingCredit') {
                amount = account['remainingCredit'] < 0 ? account['remainingCredit'] : account[key];
            } else {
                amount = account[key];
            }
            sum += amount;
        });
        return sum;
    }

    /**
     * Clear the accounts
     */
    AccountsCollection.prototype.clear = function () {
        this.accounts.length = 0;
    };

    AccountsCollection.prototype.hasAccounts = function () {
        return this.accounts.length > 0;
    };

    /**
     * Clear and sets all accounts
     * @param accountsData
     */
    AccountsCollection.prototype.updateAccounts = function (accountsData) {
        this.clear();
        this.setAccounts(accountsData);
    };

    /**
     * Sets all accounts
     * @param accountsData
     */
    AccountsCollection.prototype.setAccounts = function (accountsData) {
        var self = this;
        angular.forEach(accountsData, function (account) {
            var accountModel = new Payments_AccountModel(account);
            self.accounts.push(accountModel);
        });
    };

    /**
     * Calculates the sum of all accounts which are of type 'SAVINGS' and 'TRANSACTION'
     * @returns {number}
     */
    AccountsCollection.prototype.totalAmountExcludingCredit = function () {
        return totalAmount(this.accounts, 'availableExcludingCredit');
    };

    /**
     * Calculates the sum of all funds available including credit, which are of type 'SAVINGS' and 'TRANSACTION'
     * @returns {number}
     */
    AccountsCollection.prototype.totalAmountIncludingCredit = function () {
        return totalAmountWithAllValues(this.accounts, 'availableIncludingCredit');
    };

    /**
     * Loops through all the accounts and checks if any account has an agreed credit
     * @returns {boolean}
     */
    AccountsCollection.prototype.hasCredit = function () {
        var hasCredit = false;
        angular.forEach(this.accounts, function (account) {
            if (account.hasAgreedCredit()) {
                hasCredit = true;
            }
        });

        return hasCredit;
    };

    /**
     * Calculates Sum of balance fo All accounts
     * @returns {number}
     */
    AccountsCollection.prototype.totalBalance = function () {

        var balanceSum = 0;
        angular.forEach(this.accounts, function (account) {

            balanceSum += account.getBalance();
        });

        return balanceSum;
    };

    /**
     * Calculates the sum of Credit Limit
     * @returns {number}
     */
    AccountsCollection.prototype.totalCreditLimit = function () {
        return totalAmountWithAllValues(this.accounts, 'creditLimit');
    };

    return AccountsCollection;
}

angular.module('dbw-payments.corporate.common.models')
    .factory('Payments_AccountsCollectionModel', AccountsCollectionModel);
