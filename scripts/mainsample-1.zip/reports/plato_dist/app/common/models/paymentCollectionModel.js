'use strict';

function PaymentCollectionModel(PaymentPayloadModel) {

    /**
     * To create a new instance with the backend response
     *
     * @param paymentsResponse, i.e {
     * payments: [...],
     * }
     * @constructor
     */
    function PaymentCollection(paymentsResponse) {
        var payments = [];
        if (paymentsResponse) {
            angular.forEach(paymentsResponse, function (payment) {
                payments.push(new PaymentPayloadModel(payment));
            });
        }
        this.payments = payments;
    }

    PaymentCollection.prototype.isEmpty = function () {
        return this.payments.length === 0;
    };

    PaymentCollection.prototype.reset = function () {
        this.payments.length = 0;
        return this.payments.length;
    };

    PaymentCollection.prototype.add = function (payment) {
        var index = this.indexOf(payment);
        if (index === -1) {
            this.payments.push(payment);
        }
    };

    PaymentCollection.prototype.remove = function (payment) {
        var index = this.indexOf(payment);
        if (index !== -1) {
            this.payments.splice(index, 1);
        }
    };

    /**
     * Find the index of payment (id) in cache.
     * @param payment Payment to be checked.
     */
    PaymentCollection.prototype.indexOf = function (payment) {
        for (var i = 0; i < this.payments.length; i++) {
            if (this.payments[i].id === payment.id) {
                return i;
            }
        }
        return -1;
    };

    return PaymentCollection;
}


angular.module('dbw-payments.corporate.common.models')
    .factory('PaymentCollectionModel', PaymentCollectionModel);
