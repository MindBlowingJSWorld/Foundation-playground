(function () {
    angular.module('dbw-payments.corporate.common.numberParser', []);
})();
