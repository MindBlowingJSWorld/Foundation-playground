(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common.numberParser')
        .factory('dbwNumberParser', function dbwNumberParserFactory() {
            return {
                parse: dbwNumberParser
            };
        });

    function dbwNumberParser(value) {
        var integer = '0';
        var fractional = '0';

        if (typeof value !== 'string') {
            return value;
        }

        var valueParts = value.replace(/[\s]/g, '').split(/[.,]+/);
        if (valueParts.length === 1) {
            integer = valueParts[0];
        } else {
            fractional = valueParts.pop();
            integer = valueParts.join('');
        }

        while (fractional.length < 2) {
            fractional = '0' + fractional;
        }
        return Number(integer + '.' + fractional);
    }

})();
