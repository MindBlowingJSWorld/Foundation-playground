'use strict';

function AccountService(Payments_AccountsCollectionModel, $q, $resource) {
    this.$q = $q;

    var mockData =
        [
            {
                'account_number': 'NAID-SE-SEK-4805306661',
                'display_account_number': '4805306661',
                'iban': 'SE7130000000004805306661',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0.00,
                'booked_balance': -1125.67,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'PERSONKONTO',
                'product_code': '4001',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-31141014335',
                'display_account_number': '31141014335',
                'iban': 'SE5530000000031141014335',
                'account_status': 'OPEN',
                'nickname': 'ALJL -LJLSLLS ÄÄÄÄEÅÅÅÅ',
                'available_balance': 175.00,
                'booked_balance': 175.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'AKTIELIKVIDKONTO',
                'product_code': '0059',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-31141014343',
                'display_account_number': '31141014343',
                'iban': 'SE3330000000031141014343',
                'account_status': 'OPEN',
                'nickname': 'SDFDSSDGFGFGFGGGGGGGGGG',
                'available_balance': 15632.00,
                'booked_balance': 15632.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'EXTERNT KONTO',
                'product_code': '5119',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-31141700026',
                'display_account_number': '31141700026',
                'iban': 'SE1230000000031141700026',
                'account_status': 'OPEN',
                'nickname': 'VVVV FDDFDFD  DDFDD   S',
                'available_balance': 15490.00,
                'booked_balance': 15490.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'CROSS-BORDER ACCOUNT',
                'product_code': '0028',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-31141700034',
                'display_account_number': '31141700034',
                'iban': 'SE8730000000031141700034',
                'account_status': 'OPEN',
                'nickname': 'KSKFK-ÖSÖKS_KÅÄAÅÅÅÄÄFD',
                'available_balance': 24716.00,
                'booked_balance': 24716.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FÖRETAGSKONTO',
                'product_code': '0029',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172247',
                'display_account_number': '172247',
                'iban': 'SE0995000099602600172247',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 15984473.27,
                'booked_balance': 15984473.27,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'PLUSGIROKONTO FTG',
                'product_code': '0512',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172247-44260032492',
                'display_account_number': '44260032492',
                'main_account_number': '172247',
                'iban': '',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0,
                'booked_balance': 30000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FASTRÄNTEPLACERING',
                'product_code': '1329',
                'product_type': 'Placeringskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172247-44260032581',
                'display_account_number': '44260032581',
                'main_account_number': '172247',
                'iban': '',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0,
                'booked_balance': 20000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FASTRÄNTEPLACERING',
                'product_code': '1329',
                'product_type': 'Placeringskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172247-44260032611',
                'display_account_number': '44260032611',
                'main_account_number': '172247',
                'iban': '',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0,
                'booked_balance': 25000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FASTRÄNTEPLACERING',
                'product_code': '1329',
                'product_type': 'Placeringskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172247-44260032646',
                'display_account_number': '44260032646',
                'main_account_number': '172247',
                'iban': '',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0,
                'booked_balance': 35000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FASTRÄNTEPLACERING',
                'product_code': '1329',
                'product_type': 'Placeringskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            },
            {
                'account_number': 'NAID-SE-EUR-172247-44260032719',
                'display_account_number': '44260032719',
                'main_account_number': '172247',
                'iban': 'SE0995000099602600172247',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0.00,
                'booked_balance': 0.00,
                'currency': 'EUR',
                'credit_limit': 0.00,
                'product_name': 'PLUSGIROKONTO FTG',
                'product_code': '0512',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172585',
                'display_account_number': '172585',
                'iban': 'SE2695000099604200172585',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 80000.00,
                'booked_balance': 80000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'AFFÄRSGIRO',
                'product_code': '0511',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172775',
                'display_account_number': '172775',
                'iban': 'SE3795000099604200172775',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 100000.00,
                'booked_balance': 100000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'AFFÄRSGIRO',
                'product_code': '0511',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172791',
                'display_account_number': '172791',
                'iban': 'SE0495000099601800172791',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0.00,
                'booked_balance': 0.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FÖRENINGSGIRO',
                'product_code': '0521',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            },
            {
                'account_number': 'NAID-SE-SEK-172957',
                'display_account_number': '172957',
                'iban': 'SE7095000099604200172957',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 500.00,
                'booked_balance': 500.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'PLUSGIROKONTO FTG',
                'product_code': '0512',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }
        ];

    return {
        /**
         * Actual Service call, this can be replaced with Accounts Service in future
         */
        getAccounts: function () {
            //var self = this;
            var deferred = $q.defer();

            //foundationResource.getResource('/banking/accounts').query().$promise.then(
            $resource('/banking/accounts').get({}).$promise.then(
                function (accountsData) {
                    deferred.resolve(new Payments_AccountsCollectionModel(accountsData.accounts));
                },
                function (error) {
                    deferred.reject(error);

                });
            return deferred.promise;
        },

        /**
         * This is required to simulate the actual service calls of getAccounts
         * through a public API call which will be provided by Accounts Team
         */
        getAccountsMocked: function () {
            return new Payments_AccountsCollectionModel(mockData);
        }
    };
}

angular.module('dbw-payments.corporate.common')
    .factory('AccountService', AccountService);
