(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common')
        .factory('BeneficiariesService', BeneficiariesService);

    function BeneficiariesService(foundationResource, $q) {
        var mockData = [{
            'id': 'id',
            'display_number': '13213535',
            'name': 'name',
            'address': {
                'address1': 'Street 1 12345, City',
                'address2': 'Street 2 23456, City',
                'address3': 'Street 3 34567 City'
            },
            'country': 'FI',
            'bank_name': 'Nordea',
            'bic': 'NDEAFIHH',
            'branch_code': '',
            'bank_address': {
                'address1': 'Kirkkokatu 6, 90100 Oulu',
                'address2': 'Hamngatan 12',
                'address3': 'Kirkegade 3'
            },
            'nickname': 'nick',
            'category': 'pg',
            'to': 'IBAN-DNBANOKK-NO6560870520711',
            'message': 'mess',
            'reference': 'ref'
        }];

        return {
            /**
             * Actual Service call, this can be replaced with Beneficiaries Service in future
             */
            getBeneficiaries: function () {
                var deferred = $q.defer();

                foundationResource.getResource('/banking/beneficiaries').query().$promise.then(
                    function (beneficiariesData) {
                        deferred.resolve(beneficiariesData);
                    },
                    function (error) {
                        deferred.reject(error);

                    });
                return deferred.promise;
            },

            /**
             * This is required to simulate the actual service calls of getAccounts
             * through a public API call which will be provided by Accounts Team
             */
            getBeneficiariesMocked: function () {
                return mockData;
            }
        };
    }
})();
