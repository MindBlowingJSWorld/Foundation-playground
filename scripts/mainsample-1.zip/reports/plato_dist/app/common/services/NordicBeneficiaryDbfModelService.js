(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common')
        .factory('NordicBeneficiaryDbfModelService', function NordicBeneficiaryDbfModelServiceFactory() {
            return {
                create: create,
                createFromDbfObject: createFromDbfObject
            };
        });

    function BeneficiaryDbf() {
        angular.copy(getEmptyBeneficiaryObject(), this);
    }

    BeneficiaryDbf.prototype.getName = function () {
        return this.name;
    };

    BeneficiaryDbf.prototype.getAccountNumber = function () {
        return this.to;
    };

    function create() {
        return new BeneficiaryDbf();
    }

    function createFromDbfObject(data) {
        var beneficiary = new BeneficiaryDbf();
        angular.copy(data, beneficiary);
        return beneficiary;
    }

    function getEmptyBeneficiaryObject() {
        return {
            // (optional) Id of beneficiary
            'id': '',

            // (optional) Locally formated account number for this account
            'display_number': '',

            // Name of beneficiary
            'name': '',

            // (optional) Address of beneficiary
            'address': {
                'address1': '',
                'address2': '',
                'address3': ''
            },

            // (optional) Country of residence of beneficiary
            'country': '',

            // (optional) Name of the bank which the beneficiary user
            'bank_name': '',

            // (optional) BIC or Branch code is required for cross border recipients
            'bic': '',

            // (optional) Branch code, identifier for the recipient bank branch. Branch code or BIC is required
            'branch_code': '',

            // (optional) Address of the bank that the beneficiary uses
            'bank_address': {
                'address1': '',
                'address2': '',
                'address3': ''
            },

            // (optional) Nick name of beneficiary
            'nickname': '',

            // (optional) What category this beneficiary falls into aka product type
            // ['pg', 'bg', 'third_party', 'cross_border', 'pension', 'salary', 'nordea', 'mobile']
            'category': '',

            // to (string): Details of 'to where' the payment is done i.e. target,
            // e.g. IBAN-DABADKKK-DK5930004688370736 or LBAN-DK-43144688370736,
            // parts of the string may be empty so the client can use this as a placeholder
            'to': '',

            // (optional) Message that will be shown in to account transaction history
            'message': '',

            // (optional) Creditor reference
            'reference': ''
        };
    }
})();
