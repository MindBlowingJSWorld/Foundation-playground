(function () {
    'use strict';

    angular
        .module('dbw-payments.corporate.common')
        .service('NordicPaymentsBeneficiariesService', NordicPaymentsBeneficiariesService);

    function NordicPaymentsBeneficiariesService(NordicBeneficiaryDbfModelService, $resource, $q) {
        var mockData = [{
            'id': 'HHDOM-PG-49318041-HT testing Telia',
            'display_number': '49318041',
            'name': 'ZETAS DIVERSEHANDEL AB',
            'nickname': 'HT testing Telia',
            'category': 'pg',
            'to': 'PG-49318041'
        }, {
            'id': 'HHDOM-BG-802-Marcus',
            'display_number': '802',
            'name': 'STIFTELSEN RADIOHJÄLPEN',
            'nickname': 'Marcus',
            'category': 'pg',
            'to': 'PG-802'
        }, {
            'id': 'HHDOM-NA-32580077693-Eila Min vän',
            'display_number': '32580077693',
            'name': 'Eila Min vän',
            'nickname': 'Eila Min vän',
            'category': 'nordea',
            'to': 'NAID-SE-SEK-32580077693'
        }, {
            'id': 'HHDOM-EB-74311006470-Swedbank 2',
            'display_number': '74311006470',
            'name': 'FSPA',
            'nickname': 'Swedbank 2',
            'category': 'third_party',
            'to': 'LBAN-SE-74311006470'
        }, {
            'id': 'HHDOM-EB-90401005056-Citi Bank 1',
            'display_number': '90401005056',
            'name': 'CITI',
            'nickname': 'Citi Bank 1',
            'category': 'third_party',
            'to': 'LBAN-SE-90401005056'
        }, {
            'id': 'HHDOM-EB-91501526512-Skandiabanken 1',
            'display_number': '91501526512',
            'name': 'SKB',
            'nickname': 'Skandiabanken 1',
            'category': 'third_party',
            'to': 'LBAN-SE-91501526512'
        }, {
            'id': 'HHDOM-EB-91701682389-Ikano 1',
            'display_number': '91701682389',
            'name': 'IKANO',
            'nickname': 'Ikano 1',
            'category': 'third_party',
            'to': 'LBAN-SE-91701682389'
        }, {
            'id': 'HHDOM-EB-6171408577223-SHB 1',
            'display_number': '6171408577223',
            'name': 'SHB',
            'nickname': 'SHB 1',
            'category': 'third_party',
            'to': 'LBAN-SE-6171408577223'
        }, {
            'id': 'HHDOM-EB-83279741451265-Swedbank 1',
            'display_number': '83279741451265',
            'name': 'FSPA',
            'nickname': 'Swedbank 1',
            'category': 'third_party',
            'to': 'LBAN-SE-83279741451265'
        }, {
            'id': 'HHDOM-EB-91804993183369-DDB 1',
            'display_number': '91804993183369',
            'name': 'DDB',
            'nickname': 'DDB 1',
            'category': 'third_party',
            'to': 'LBAN-SE-91804993183369'
        }];


        var resource = $resource(
            '/banking/beneficiaries/:id',
            {},
            {
                get: {method: 'GET', interceptor: getInterceptor()},
                list: {method: 'GET', interceptor: getInterceptor(), isArray: true},
                create: {method: 'POST', interceptor: getInterceptor()},
                delete: {method: 'DELETE', interceptor: getInterceptor()}
            }
        );

        this.get = function (id) {
            return resource
                .get({id: id})
                .$promise
                .then(NordicBeneficiaryDbfModelService.createFromDbfObject);
        };

        /**
         * @param filter
         * @returns []
         */
        this.getList = function (filter) {
            return resource
                .list(filter)
                .$promise
                .then(mapListToDbfModel);
        };

        /**
         * Get List Mocked
         * @param filter
         * @returns {*}
         */
        this.getListMocked = function (filter) {
            return $q.when(mapListToDbfModel(mockData));
        };

        this.create = function (beneficiaryDbfModel) {
            //return resource.create(beneficiaryDbfModel).$promise;
        };

        this.delete = function (beneficiaryDbfModel) {
            //return resource.delete(beneficiaryDbfModel).$promise;
        };

        function mapListToDbfModel(list) {
            return list.map(NordicBeneficiaryDbfModelService.createFromDbfObject);
        }

        function getInterceptor() {
            return {
                'responseError': function (error) {
                    //console.log('Payments_BeneficiariesService error', error);
                    return $q.reject(error);
                }
            };
        }
    }
})();
