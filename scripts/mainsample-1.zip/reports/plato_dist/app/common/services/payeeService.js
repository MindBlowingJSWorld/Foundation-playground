'use strict';

/**
 * @class
 * 'PayeeService' acts as a singleton representing the Payee backend resource.
 */
function PayeeService($q, $resource) {
    this._$q = $q;
    this._payeeInfo = null;
    this._$resource = $resource;
}

/**
 * Given a  payee account Id, retrieves payee details
 *
 * @param PayeeAccountNo The payee account number.
 * @returns Payee details.
 */

PayeeService.prototype._getPayeeInfo = function (accountId, inCountry, inPrefix) {
    var prefix = (inPrefix === undefined) ? '' : inPrefix + '-';
    var country = (inCountry === undefined) ? '' : inCountry + '-';
    return this._$resource('/banking/payee/:accountNumber',
        {},
        {
            query: {method: 'GET', isArray: false}
        }
        )
        .query({accountNumber: prefix + country + accountId}).$promise;
};


PayeeService.prototype._parsePayee = function (rawData) {
    return {
        owner_name: rawData.owner_name,
        bank_name: rawData.bank_name,
        ocr: rawData.ocr,
        next_date: rawData.next_date,
        country: rawData.country,
        status: rawData.status,
        reason: rawData.reason
    };
};

angular.module('dbw-payments.corporate.common')
    .factory('PayeeService', function PayeeServiceFactory($q, $resource) {
        return new PayeeService($q, $resource);
    });


