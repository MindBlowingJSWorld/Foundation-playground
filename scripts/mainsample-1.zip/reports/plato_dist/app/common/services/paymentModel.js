'use strict';

/*eslint max-statements: ["error", 45, {ignoreTopLevelFunctions: true}]*/
function PaymentModel() {

    /**
     * @param data
     * @constructor
     */
    function Payment(data) {
        if (data !== undefined) {
            angular.extend(this, data);
        }
    }

    Payment.prototype.setFrom = function(accountNumber) {
        this.from = accountNumber;
    };

    Payment.prototype.setTo = function(accountNumber) {
        this.to = accountNumber;
    };

    Payment.prototype.setCurrency = function(currency) {
        this.currency = currency;
    };

    Payment.prototype.setCentralBankReportingCode = function(reportingCode) {
        this.cross_border.central_bank_reporting_code = reportingCode;
    };

    Payment.prototype.setAmount = function(amount) {
        this.amount = amount;
    };

    Payment.prototype.setDueDate = function(dueDate) {
        this.due = dueDate;
    };

    Payment.prototype.setMessage = function(message) {
        this.message = message;
    };

    Payment.prototype.setOwnMessage = function(message) {
        this.own_message = message;
    };

    Payment.prototype.setChargePaidBy = function(changePaidBy) {
        this.cross_border.charge_paid_by = changePaidBy;
    };

    Payment.prototype.setSpeed = function(speed) {
        this.speed = speed;
    };

    Payment.prototype.setCrossBorder = function (crossBorder) {
        this.cross_border = crossBorder;
    };

    Payment.prototype.setRecipientName = function (recipientName) {
        //this.cross_border.recipient_name = recipientName;

        this.recipient_name = recipientName;
    };

    Payment.prototype.setRecipientAddress = function (address) {
        this.cross_border.address = [];
        if(address) {
            this.addRecipientAddress(address);
        }
    };

    Payment.prototype.addRecipientAddress = function (address) {
        this.cross_border.address.push(address);
    };


    Payment.prototype.setReceipt = function(receipt) {
        this.receipt = receipt;
    };


    Payment.prototype.setType = function(type) {
        this.type = type;
    };


    Payment.prototype.getFrom = function() {
        return this.from;
    };

    Payment.prototype.getReceiverAccount = function() {
        return this.to;
    };

    Payment.prototype.getReceiverName = function() {
        return this.receiver_name;
    };

    Payment.prototype.getCurrency = function() {
        return this.currency;
    };

    Payment.prototype.getDueDate = function() {
        return this.due;
    };

    Payment.prototype.getStatus = function() {
        return this.status;
    };

    Payment.prototype.getReferenceNumber = function() {
        return this.message;
    };

    Payment.prototype.getAmount = function() {
        return this.amount;
    };

    Payment.prototype.getPurposeLabel = function() {
        return 'SEtaxPaymentcode.' + this.reporting_code;
    };

    Payment.prototype.getRepeatFrequency = function() {
        var freq = 0;
        if (this.repeat_frequency) {
            freq = this.repeat_frequency;
        }
        return freq;
    };

    Payment.prototype.getRepeatLabel = function() {
        var label = '';
        if (this.repeat_interval) {
            label = this.repeat_interval.toLowerCase();
            label = 'repeat' + label.charAt(0).toUpperCase() + label.substring(1);
        } else {
            label = 'repeatOnce';
        }
        return label;
    };

    Payment.prototype.getRecipientName = function () {
        return this.recipient_name;
    };

    Payment.prototype.getReceipt = function() {
        return this.receipt;
    };


    Payment.prototype.getType = function() {
        return this.type;
    };

    return Payment;
}

angular.module('dbw-payments.corporate.common').factory('PaymentPayloadModel', PaymentModel);
