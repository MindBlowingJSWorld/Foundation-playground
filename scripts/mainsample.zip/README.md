# Main Household application

This project contains resources required to produce main household web application. The Navigation & Overview team 
owns the overall build process. ALL teams are responsible for adding their code and required 3rd party libraries.


### Front-end build

The main application build handles these steps

* bundles javascript and CSS ("main", "vendor", "foundation" (framework), "mocks")
* copies static assets
* minifies javascript and CSS in production-like environments
* creates source maps
* adds revision hashes in bundle names in production-like environments
* running in local server
* watches and rebuilds main JS, CSS, and static assets (i.e. our code)
  
The build relies heavily on plugin gulp-bundle-assets: https://www.npmjs.com/package/gulp-bundle-assets. The plugin is fairly well documented with examples.
   
The main application code is located in directory `webapp`.
   
#### Running the main application locally
   
After a clean checkout, execute `npm install` in the main directory where `package.json` is located in.
   
Command `gulp run` cleans and builds the application, sets up file watching, and starts a local server at port 8080.
   
Command `gulp run-mocked` does the same as above but includes mock bundles from our packages as well as vendor mock code (ngMockE2E).
 
Command `gulp build` just cleans and builds the application.
  
Command `gulp build-mocks` does the same as above and includes the mock bundle.

By default, build is done for local development. Files are not minified nor revisioned. To build for a production like environment,
you must set `NODE_ENV` to`test`, `dev`, or `prod`. We're using `NODE_ENV` because gulp-bundle-assets plugin uses it. 

* In Windows CLI this is done in two steps by e.g `set NODE_ENV=prod` then `gulp run`. Note that the setting remains in the CLI session. 
* In Bash this can be done in one step e.g. `NODE_ENV=prod gulp run`.
* (In Gulp this can done by e.g. `process.env.NODE_ENV = 'prod'`.
* The same thing can also be achived by simply issue the shortcut `gulp p` (for production), `gulp t` (for test), and `gulp d` (for development)

#### Getting your code in

Rules for application modules

Javascript

* Provide 1 or 2 bundles
    * one for production code
    * optional bundle containing any mock code you need
* NO dependencies from any other NPM packages, neither our packages nor vendor modules
* Bundle must be minification-safe 
* Code blocks must be wrapped in iife:s. 
* If you need Angular template caching, do that in your JS bundle.
* Do NOT minify the code. 
    * Otherwise the main app cannot create source maps properly.

CSS

* Provide CSS in one CSS bundle.
    * Do not include CSS from any other packages
    * The main app handles minification.
  
Managing the dependencies is currently a manual process. The main application does not get your module's dependencies automatically. We must be specific about package versions to avoid conflicts.

Steps to include your module

* Update `package.json` to include your module and the required vendor libraries, if not already there.
    * Make sure your package uses the same versions as the main application
    * Update your package's version
* Update `webapp/config/bundle.config.js`
    * `bundle` > `modules` application module code. 
        * Include your JS bundle here
    * `bundle` > `vendor` defines vendor library code. 
        * Include required vendor libraries here, if not already there.
    * `copy` defines static assets to copy
        * Include static assets (e.g. html that is not $templateCached) to copy here. 
    * `bundle` > `main` main app module code (has its own build step). 
        * You won't need to update this.  
    * `bundle` > `foundation` contains Foundation framework code.
        * You won't not need to update this.
    * The file contains more instructions
* Update `webapp/config/bundle.config.mocks.js` to include your mock bundle, if any.
* Include your angular module(s) in the module definition in `webapp/src/main-app.js`!

IMPORTANT: Remember to publish your module in Nordea's NPM registry to get your code in the CI build and deployed to test servers!


#### Running the main application while developing your module

1. Clone the main app Git repository and run `npm install`
2. In the main app directory where `package.json` is located in, run `npm link <path to your module directory, e.g. ../navigation>`
    * This sets the main app to pick up the module from your local directory instead of the NPM registry
3. Start your module's watch task 
4. Start the main app's `gulp run` or `gulp run-mocked`. 
    * The tasks watch the module bundles. When your module's build task triggers, the main app will pick up the updated bundles (both CSS and JS).
5. Every now and then, update your local version of the main app (Git pull) and execute `npm update` to get updated versions of other teams' packages from the NPM registry. 

NOTE: Execute `npm unlink <your module's package name>` in the main app directory to pick the package from the NPM registry. 


### Navigation setup

We use angular-ui-router (https://github.com/angular-ui/ui-router) for navigation. The navigation bar has `<a ui-sref>' links to predefined states. Your module needs to implementing routing using same states. Currently the setup is based on agreed-upon strings, aka "magic strings". 

Please see `states_household.js` or `states_corporate.js` in the Navigation repository (https://ccd1is0271.ccd1.root4.net:8443/projects/DBW/repos/navigation/browse/src/navigation) for up-to-date mapping of navigation menu items to state ids. You must implement the behavior to the child state corresponding to your page. Your module can have further child states. 

The main application provides routing in case the route is simply to redirect to a menu item that opens an actual page. 
 
#### Example

You are implementing the page "Send Money" in Household Netbank. It's state defined in `states_household.js` in the Navigation repository is `household.check-and-pay.send-money`. Somewhere in your module code, you will have something like this:
 
```javascript 

angular.module('dbw-my-module')
   .config(setUpRoutes);

function setUpRoutes($stateProvider) {

    $stateProvider
        // This state you MUST implement
        .state('household.check-and-pay.send-money', {
            url: '/send-money' // For you to decide, but please check with "branding"
            templateUrl: 'my_module/send_money/view.html' // You decide whether this should be cached or taken as static asset
            controller: 'MyModuleSendMoneyController', 
            controllerAs: 'vm'
        })
        // You can have sub-states within your main page. E.g. if 'household.check-and-pay.send-money' is list view, then this could be your detail view state
        .state('household.check-and-pay.send-money.transaction-detail', {
           url: '/transactions/:id',
           templateUrl: 'my_module/send_money/detail.html',
           controller: 'MyModuleTransactionDetailController',
           controllerAs: 'vm'
        });
}

```

The main app would provide routing for states 'household' and 'household.check-and-pay' because they do not open any actual page. They only redirect to the default concrete page for the area. In the future parent states may provide common data or handle lazy loading related to a particular menu area. 

### Building self-contained Spring Boot application

For this you have to have Apache Maven installed and have correct `settings.xml` pointing to correct Nordea Nexus
repositories.

1. Run `mvn clean install`
2. Find produced `jar` file under the `target` folder
3. Either double-click or run `java -jar THEJARFILE`
4. Find the application running on localhost (by default on port 8080)

If you double-clicked then the java would launch the application in the background. To kill it write something like
`netstat -ano | find "8080"` (or another port if you provide that), find the PID and use the Windows Task Manager to
kill the process by that PID.

### Launch for different environments

All configurations are taken from `dbw-common`. By default when you run `java -jar target/main-household-1.0.0-SNAPSHOT.jar`, the `DEV` configuration will be used. There are three configurations available: `DEV`, `TEST` and `PROD`. If you want to use a specific environment, run `java -Dcom.nordea.environmenttype=TEST -jar target/main-household-1.0.0-SNAPSHOT.jar`.