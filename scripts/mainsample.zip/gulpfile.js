"use strict";

var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
var runSequence = require('run-sequence');
var requireDir = require('require-dir');

requireDir('webapp/gulp-tasks');

var buildConfig = require('./webapp/config/build.config');


gulp.task('run', function (cb) {
    runSequence('build', ['watch', 'webserver'], cb);
});

gulp.task('run-no-install', function (cb) {
    runSequence('build-no-install', ['watch', 'webserver'], cb);
});

gulp.task('run-mocked', function (cb) {
    runSequence('build-mocks', ['watch', 'watch-mocks', 'webserver'], cb);
});

gulp.task('run-mocked-no-install', function (cb) {
    runSequence('build-mocks-no-install', ['watch', 'watch-mocks', 'webserver'], cb);
});

gulp.task('webserver', function() {
    gulp.src(buildConfig.paths.build)
        .pipe($.webserver({
            port: 8080,
            livereload: true,
            proxies: [
                { source: '/api/dbf/', target: 'http://ap-rbo1s:82/api/dbf/' }
            ]
        }));
});

gulp.task('ui-test', function(cb) {
    runSequence('build-mocks', 'webserver', 'protractor', cb);
});

//bundle for environment and start running the server
var bundleForEnvironment = function (env) {
    process.env.NODE_ENV = env;
    gulp.start('run');
};

gulp.task('p', function() {
    bundleForEnvironment('prod');
});

gulp.task('t', function() {
    bundleForEnvironment('test');
});

gulp.task('d', function() {
    bundleForEnvironment('dev');
});
