package com.nordea.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by g36441 on 04/05/2016.
 */
@Controller
public class IndexPageController {

    @Autowired
    private MainAppConfiguration.Environment environment;

    @Value("${version:???")
    private String version;


    @RequestMapping(value = {"/","/{[path:[^\\.]*}","/**/{[path:[^\\.]*}"}, produces = "text/html")
    public ModelAndView indexPage(HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Cache-Control", "public, max-age=60");
        String serverName = request.getServerName();
        String country = null;
        if (serverName.contains(".dk")) {
            country = "DK";
        } else if (serverName.contains(".fi")) {
            country = "FI";
        } else if (serverName.contains(".se")) {
            country = "SE";
        } else if (serverName.endsWith(".no") || serverName.contains(".no.")) { // .no also matches .nordea
            country = "NO";
        }
        String segment = "household";
        if (serverName.contains("corporate.")) {
            segment = "corporate";
        }
        if (country == null) {
            return new ModelAndView("forward:index_dev.html");
        }
        //
        ModelAndView modelAndView = new ModelAndView("app");
        modelAndView.addObject("country", country);
        modelAndView.addObject("segment", segment);
        modelAndView.addObject("env", environment.getName());
        modelAndView.addObject("version", version);
        modelAndView.addObject("dcsid", "dcs222156awbguhi4ji3oew6u_7n8v");
        return modelAndView;
    }
}
