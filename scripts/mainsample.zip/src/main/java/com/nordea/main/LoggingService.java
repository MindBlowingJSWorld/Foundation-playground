package com.nordea.main;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * Simple remote logging receiver that sends everything to stdout for now
 */
@RestController
@RequestMapping("/log")
public class LoggingService {

    /**
     * Receive a log entry from the client
     * todo What format ? filter bad characters etc. ? limit size?
     */
    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<?> logEvent(@RequestBody String log) {
        //todo replace with logback unless this is a tempoary solution
        System.out.println(log);
        return ResponseEntity.ok("");
    }
}
