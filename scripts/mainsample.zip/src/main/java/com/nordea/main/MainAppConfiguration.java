package com.nordea.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.filter.ShallowEtagHeaderFilter;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import javax.servlet.Filter;

@Configuration
@EnableAutoConfiguration
@ComponentScan
@PropertySource(value = { "classpath:application.properties" })
public class MainAppConfiguration extends WebMvcConfigurerAdapter {

    public static void main(String args[]) {
        SpringApplication.run(MainAppConfiguration.class, args);
    }

    public enum Environment {
        DEV("DEV", "dev"),
        TEST("TEST", "test"),
        PROD("PROD", "prod");

        private final static Environment DEFAULT_ENVIRONMENT = Environment.DEV;

        private String commandLineParameterName;

        private String webFolderName;

        Environment(String commandLineParameterName, String webFolderName) {
            this.commandLineParameterName = commandLineParameterName;
            this.webFolderName = webFolderName;
        }

        public static Environment getEnvironment(String commandLineParameterName) {
            for (Environment environment : values()) {
                if (environment.commandLineParameterName.equals(commandLineParameterName)) {
                    return environment;
                }
            }

            return DEFAULT_ENVIRONMENT;
        }

        public String getCommandLineParameterName() {
            return commandLineParameterName;
        }

        public String getName() {
            return webFolderName;
        }
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/**").addResourceLocations(String.format("classpath:/web/%s/", getEnvironment().getName()));
    }

    @Bean
    public Filter shallowEtagHeaderFilter() {
        return new ShallowEtagHeaderFilter();
    }

    @Bean
    public Environment getEnvironment() {
        Environment environment = Environment.getEnvironment(System.getProperty("com.nordea.environmenttype", ""));
        return environment;
    }
}