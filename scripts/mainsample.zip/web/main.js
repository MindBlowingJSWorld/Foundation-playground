;(function() {
"use strict";

$(document).foundation();
}());

;(function() {
"use strict";

// TODO get our module's names from some config file?
// TODO separate common modules into core module (or is it in our common module)?
angular.module('mainApp', [
    // Vendor modules
    'ui.router',
    'ngResource',
    'ngAnimate',
    'ngStorage',
    'angular-velocity',
    // Add your module names here!
    'dbw-authsign',
    'dbw-core',
    'dbw-common',
    'dbw-communication',
    'dbw-navigation',
    'dbw-login',
    'dbw-taskbar',
    'dbw-savings_app',
    'dbw-payments',
    'dbw-cards',
    'dbw-corporate-liquidity',
    'dbw-beneficiaries',
    'dbw-accounts',
    'dbw-messages',
    'dbw-profile',
    'dbw-authsign',
    'dbw-loan-credit',
    'dbw-localization',
    'ngFileUpload',
    'dbw-labels',
    'dbw-search',
    'dbw-agreement',
    'dbw-catalog'
]);
}());

;(function() {
"use strict";

configureRouting.$inject = ['$stateProvider', '$urlRouterProvider', '$locationProvider'];
setUpRedirectHelper.$inject = ['$rootScope', '$state'];
angular.module('mainApp')
    .config(configureRouting)
    .run(setUpRedirectHelper);

function configureRouting($stateProvider, $urlRouterProvider, $locationProvider) {

    $locationProvider.html5Mode(!window.DisableHtml5Mode);

    // Defines default state
    // Resolves "Error: $rootScope:infdig Infinite $digest Loop" (this may be remnant of AngularAMD dependency in the prototype app)
    $urlRouterProvider.otherwise(function ($injector) {
        var $state = $injector.get("$state");
        $state.go('login');
    });

    $stateProvider
        .state('login', {
            url: '/',
            template: '<login-page></login-page>',
            public: true
        })

        //Logout needs its own state to be able to track it even if it may show the same page
        .state('logout', {
            url: '/logout',
            template: '<login-page></login-page>',
            public: true
        })
        .state('start', {
            template: '<div ui-view class="fluid-container"></div>'
        })

        .state('common', {
            templateUrl: 'main/main.tpl.html'
        })
        .state('common.noaccess', {
            template: '<noaccess-page></noaccess-page>'
        })
        .state('common.notfound', {
            template: '<notfound-page></notfound-page>'
        })
        .state('common.messages', {
            url: '/messages',
            redirectTo: 'common.messages.inbox',
            template: '<dbw-messages/>'
        })
        .state('common.talk-with-us', {
            url: '/talk-with-us',
            redirectTo: 'common.talk-with-us.talk-with-us',
            template: '<ui-view/>'
        })
}

/**
 * Allows you to use 'redirectTo: <state id>' in angular ui router state configurations.
 *
 * Note for the future: API listening to state changes is different in angular-ui-router 1.x.
 */
function setUpRedirectHelper($rootScope, $state) {
    $rootScope.$on('$stateChangeStart', function (evt, to, params) {
        if (to.redirectTo) {
            evt.preventDefault();
            $state.go(to.redirectTo, params, {reload: true})
        }
    });
}
}());

;(function() {
"use strict";

configureRouting.$inject = ['$stateProvider', '$urlRouterProvider'];
angular.module('mainApp')
    .config(configureRouting);

function configureRouting($stateProvider, $urlRouterProvider) {

    // Main app provides parent states like 'household' and states corresponding to 1st level menu items e.g. 'household.check-and-pay'.
    // Application module code provides states for 2nd level menu items e.g. 'household.check-and-pay.overview'. Those configs
    // are done within the application module's config, not here. That we we don't have any orphan routes lying around. Also,
    // an actual page may have its own sub-routes, and it's more natural to keep those in the app module.

    $stateProvider

        .state('household', {
            url: '/household',
            templateUrl: 'main/main.tpl.html',
            redirectTo: 'household.check-and-pay'
        })

        .state('household.check-and-pay', {
            url: '/check-and-pay',
            template: '<div ui-view></div>',
            redirectTo: 'household.check-and-pay.overview'
        })

        //FIXME in corresponding module
        //'household.finances.summary' is not provided by corresponding module, making app broken
        .state('household.finances.summary', {
            url: '/fixme1',
            template: '<div ui-view></div>'
        })

        .state('household.finances', {
            url: '/finances',
            template: '<div ui-view></div>',
            redirectTo: 'household.finances.summary'
        })
        .state('household.advice-and-offers', {
            url: '/advice-and-offers',
            template: '<div ui-view></div>',
            redirectTo: 'household.advice-and-offers.find-solution'
        })
        .state('household.advice-and-offers.find-solution', {
            url: '/find-solution',
            templateUrl: 'catalog.tpl.html',
            controller: 'CatalogController',
            controllerAs: 'vm'
        })
        .state('household.advice-and-offers.browse', {
            url: '/browse',
            template: '<h4>Browse</h4><p>Placeholder</p>'
        })
        .state('household.advice-and-offers.get-advice', {
            url: '/get-advice',
            template: '<h4>Get Advice</h4><p>Placeholder</p>'
        })
    ;
}
}());

;(function() {
"use strict";

angular.module('mainApp')
    .config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
        $stateProvider
            .state('corporate', {
                url: '/corporate',
                templateUrl: 'main/main.tpl.html',
                redirectTo: 'corporate.home'
            })

            //.state('corporate.home', {
            //    templateUrl: 'corporate_module/overview/overview.tpl.html'
            //})
            
            .state('corporate.payments', {
                url: '/payments',
                template: '<div ui-view></div>',
                redirectTo: 'corporate.payments.pay-and-transfers',
                roles: ['payments']
            })
            .state('corporate.payments.pay-and-transfers', {
                url: '/pay-and-transfers',
                template: '<dbw-sendmoney></dbw-sendmoney>',
                roles: ['payments']
            })
            .state('corporate.payments.incoming', {
                url: '/incoming',
                template: '<h4>Incoming Payments</h4><p>Placeholder</p>',
                roles: ['payments']
            })
            .state('corporate.payments.outgoing', {
                url: '/outgoing',
                template: '<dbw-corp-outgoing-payments></dbw-corp-outgoing-payments>',
                roles: ['payments']
            })
            .state('corporate.payments.file-handling', {
                url: '/file-handling',
                template: '<h4>File Handling</h4><p>Placeholder</p>',
                roles: ['payments']
            })
            .state('corporate.payments.financial-contracts', {
                url: '/financial-contracts',
                template: '<h4>Financial Contracts</h4><p>Placeholder</p>'
            })



            // PLAN AND FORECASTE
            .state('corporate.plan-and-forecast', {
                url: '/plan-and-forecast',
                template: '<div ui-view></div>',
                redirectTo: 'corporate.plan-and-forecast.financial-overview'
            })



            .state('corporate.portfolio', {
                url: '/portfolio',
                template: '<div ui-view></div>',
                redirectTo: 'corporate.portfolio.accounts'
            })
            .state('corporate.portfolio.cards', {
                url: '/cards',
                template: '<h4>Cards</h4><p>Placeholder</p>'
            })
            .state('corporate.portfolio.loans', {
                url: '/loans',
                template: '<h4>Loans</h4><p>Placeholder</p>'
            })



            .state('corporate.advice-and-offers', {
                url: '/advice-and-offers',
                template: '<div ui-view></div>',
                redirectTo: 'corporate.advice-and-offers.product-store'
            })
            .state('corporate.advice-and-offers.product-store', {
                url: '/product-store',
                template: '<h4>Product Store</h4><p>Placeholder</p>'
            })

            .state('start.sign-agreement', {
                url: '/sign-agreement',
                template: '<dbw-agreement></dbw-agreement>'
            })
            .state('start.overview', {
                url: '/agreement-usersoverview',
                template: '<dbw-agreement-users-overview></dbw-agreement-users-overview>'
            });
    }]);
}());

;(function() {
"use strict";

'use strict';
/*jshint -W109 */ //Use double quotes in string
angular.module('mainApp')
  .constant('RuntimeConfiguration',
    // The content below will be replaced by the build script according to the
    // json defined in dbw-config.<NODE_ENV>.json
    //START_CONFIG_BLOCK
{"environment":"DEV","logging":{"debug":true,"serverURL":"/log","sendToServer":{"debug":false,"info":false,"warn":false,"error":false},"writeToConsole":{"debug":true,"info":true,"warn":true,"error":true}},"session":{"idle":300,"timeout":30},"loginMethods":{"FI":{"household":["login-method-codeApp","login-method-code","login-method-mock"],"corporate":["login-method-codeApp","login-method-code","login-method-mock"]},"SE":{"household":["login-method-bankID","login-method-code","login-method-mock"],"corporate":["login-method-bankID","login-method-code","login-method-mock"]},"DK":{"household":["login-method-code","login-method-mock"],"corporate":["login-method-code","login-method-mock"]},"NO":{"household":["login-method-code","login-method-mock"],"corporate":["login-method-code","login-method-mock"]}},"urls":[{"url":"/security/oauth2/servicetoken","target":"http://ap-micros1t.oneadr.net/security/oauth2/servicetoken","country":"SE"},{"url":"/security/oauth2/servicetoken","target":"http://ap-micros1s.oneadr.net/security/oauth2/token","country":"FI"},{"url":"/mocktoken","target":"/api/dbf/ca/authentication-mock-v1/security/oauth/token"},{"url":"/mockagreement","target":"/api/dbf/ca/authentication-mock-v1/security/oauth/agreement"},{"url":"/etc/messages","target":"http://digital.se.nd.dev01.qaoneadr.local/api/dbf/ca/messages-v02/etc/messages"},{"url":"/etc/recommendations","target":"http://digital.se.nd.dev01.qaoneadr.local/api/dbf/ca/recommendations-v04/etc/recommendations"},{"url":"/etc/meetings","target":"http://digital.se.nd.dev01.qaoneadr.local/api/dbf/ca/meetings-v01/etc/meetings"},{"url":"/banking/cards","target":"http://ap-micros3t:9028/banking/cards","country":"SE"},{"url":"/banking/cards","target":"http://ap-micros1s/v0.2/banking/cards/fi","country":"FI"},{"url":"/banking/accounts","target":"http://digital.se.nd.dev01.qaoneadr.local/api/dbf/se/accounts-v05/accounts","country":"SE"},{"url":"/banking/accounts","target":"http://digital.fi.nd.dev01.qaoneadr.local/api/dbf/fi/accounts-v05/accounts","country":"FI"},{"url":"/banking/beneficiaries","target":"http://digital.se.nd.dev01.qaoneadr.local/api/dbf/se/beneficiaries-v05/banking/beneficiaries","country":"SE"},{"url":"/banking/beneficiaries","target":"http://ap-micros1s.oneadr.net/v0.2/banking/beneficiaries","country":"FI"},{"url":"/banking/payments","target":"http://digital.se.nd.dev01.qaoneadr.local/api/dbf/se/payments-v05/banking/payments","country":"SE"},{"url":"/banking/payments","target":"http://digital.se.nd.dev01.qaoneadr.local/api/dbf/fi/payments-v03/banking/payments","country":"FI"},{"url":"/banking/payee","target":"http://digital.se.nd.dev01.qaoneadr.local/api/dbf/se/payee-v05/banking/payee"},{"url":"/savings-api","target":"/api/dbf/ca/savings-v01"},{"url":"/banking/loans","target":"http://ap-micros1s.oneadr.net/v0.2/banking/loans"},{"url":"/banking/search","target":"/api/dbf/ca/search-v02/search"},{"url":"/utilities/bankdays","target":"http://ap-micros1s/v0/utilities/bankdays"},{"url":"/xfm/","target":"/api/dbf/ca/xfm-v06/xfm/"},{"url":"/agreements/self","target":"http://ap-rbo1s:81/aa-internal-api/v1/agreements/self","country":"SE"},{"url":"/signing/eTicket","target":"http://ap-rbo1s:81/aa-internal-api/v1/signing/eTicket","country":"SE"},{"url":"/agreement/usersOverview","target":"http://ap-rbo1s:81/aa-internal-api/v1/agreements/self/users","country":"SE"},{"url":"/users/settings","target":"http://ap-rbo1s:82/api/dbf/ca/settings-v01/users/settings"},{"url":"/catalog/products","target":"http://ap-rbo1s:82/api/dbf/ca/catalog-v01/catalog/products"}],"testCustomers":[{"name":"194008010011","style":"household","personId":"194008010011","country":"SE","channel":"RBO","authenticationMethod":"BANKID","agreement":3933747},{"name":"SE 194008010011","style":"corporate","personId":"194008010011","country":"SE","channel":"RBO","authenticationMethod":"BANKID","agreement":3933747},{"name":"Cards FI000000000394320","style":"household","personId":"FI000000000394320","country":"FI","channel":"RBO","authenticationMethod":"BANKID","agreement":2172332},{"name":"2404760133","style":"household","personId":"2404760133","country":"DK","channel":"DBW","authenticationMethod":"NEMID","agreement":0},{"name":"25241614","style":"corporate","personId":"0406640019","country":"DK","channel":"DBW","authenticationMethod":"NEMID","agreement":3100375},{"name":"Cards 152215","style":"corporate","personId":"297914-49","country":"FI","channel":"DBW","authenticationMethod":"BANKID","agreement":138800},{"name":"Cards 402727","style":"corporate","personId":"297914-49","country":"FI","channel":"DBW","authenticationMethod":"BANKID","agreement":402727},{"name":"192410010520","style":"corporate","personId":"192410010520","country":"SE","channel":"DBW","authenticationMethod":"BANKID","agreement":3933066},{"name":"297914-49,552 Unsigned","style":"corporate","personId":"297914-49","country":"SE","channel":"RBO","authenticationMethod":"BANKID","agreement":552,"start":"start.sign-agreement"},{"name":"3933066 Signed","style":"corporate","personId":"192410010520","country":"SE","channel":"DBW","authenticationMethod":"BANKID","agreement":3933066},{"name":"195801010033","style":"household","personId":"195801010033","country":"SE","channel":"RBO","authenticationMethod":"BANKID","agreement":3933865}]}
    //END_CONFIG_BLOCK
);
}());

;(function() {
"use strict";

resetFocusOnStateChange.$inject = ['$rootScope'];
angular.module('mainApp')
    .run(resetFocusOnStateChange);

/**
 * Accessibility: Resets (removes) focus on state change. This allows
 * keyboard navigation straight to the skip link, instead of the focus staying
 * at a menu item and forcing the user to tab cycle through several
 * menu items before getting to the main content.
 */
function resetFocusOnStateChange($rootScope) {
    $rootScope.$on('$stateChangeSuccess', function () {
        $('#main-content').focus().blur();
    });
}
}());

(function(){angular.module("mainApp").run(["$templateCache", function($templateCache) {$templateCache.put("main/main.tpl.html","<a class=\"show-on-focus\" nd-scroll-focus=\"main-content\" href>{{\'Accessibility_Skip_To_Main_Content\' | t}}</a>\n<nd-notification-set type=\"top\"></nd-notification-set>\n<nd-notification-set type=\"toast\"></nd-notification-set>\n<nav-navbar></nav-navbar>\n<global-search></global-search>\n<h1 id=\"main-content\" class=\"show-on-focus\" tabindex=\"-1\">Main content</h1>\n<div ui-view=\"middle\"></div>\n<main ui-view class=\"fluid-container\" role=\"main\"></main>");}]);})();
//# sourceMappingURL=maps/main.js.map