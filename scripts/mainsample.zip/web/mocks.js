(function(){
'use strict';

/* @ngInject */
TestTokenServiceMock.$inject = ['SessionService', 'AuthorisationService', '$log'];
function TestTokenServiceMock(SessionService, AuthorisationService, $log) {

    return {
        login: function (customer) {
            var result = {
                access_token: 'eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJkYmYiLCJhdWQiOlsib3NsIl0sImp0aSI6InRlc3QtMTQ2MDczMDA1MzM4NyIsImNsaWVudF9pZCI6IjE5NDAwODAxMDAxMSIsImNvdW50cnkiOiJTRSIsImFtIjoiQkFOS0lEIiwiYWwiOiJISUdIIiwiaWF0IjoxNDYxOTYxNjYxLCJleHAiOjE0NjE5NjE5NjEsImNoIjoiUkJPIiwiZ3JhbnRzIjp7ImFncmVlbWVudCI6MjE3MjMzMn19.GfJlDGUNI1gMGlg3nJ6sOsx1OTGk_9wCBxUadKSlwDjB43hpFzhhuXhAsI1G1duBLNUQ8j8pW7_pz3DTsfWZjICxtdjsigSpPq0hTZ391i7QwBsFOBCUTlkmTwITpdcoj2GZfvzYQJ0ffYQ6puKibOxjaeGV9O7gdzCdHBbFylMfAJPPcLGWCm26k5BHytj0BiUg3OKJGEiskCatvZJ2wb-T5diRxg5xG9JK2WlvIic_gHLpLHTPU0FJlUvzrTOi1v9vlwcMa6TsmfVMi2bJlHd4v73W14hf0vk7uOmh_yJNRPIuy9K-jgCo-Jkhir8uPvvobZxtJ1_i4NEDPWTJp_3nO-voyD8jpBFKqcUSvog0l-btfe2bfCue_-kBthWF-xSkoCEvzZpM2BR7zr3BQnkcceczowIDzYEyQiGKlZBvCyBH03UcA5hb0oROxpsxCmf1Y6XRNRoru2_CZJ35QoaPKCd3IEiilejWGYyYPlF7wfsWNnMwn2iNRGa6nekKyMT0Sc0wEaH3RLma9vja4vPXmH-y_5DTeb4C9vBxTkj6JoFkVESviE9wUfN5GNGhlt_xRYHCdZYdR0r0bZxBBeFf87x7pbBDTDoN2jJP4jLx55SYZPAHxjMc2X9Ts1AYbM67GJLAiAq2cPHhDPZxJBZyKQZst7DJLJ3_kI6wHb8',
                refresh_token: '4634636346346sdyrsrsg',
                expires_in: 300
            };
            SessionService.login(customer.style, result.access_token, result.refresh_token, result.expires_in);
            try {
                if (customer.start) {
                    AuthorisationService.resume(customer.start);
                } else {
                    AuthorisationService.resume(customer.style);
                }
            } catch (e) {
                $log.error(e);
            }
        }
    };
}

angular.module('dbw-core').service('TestTokenService', TestTokenServiceMock);

})();
(function(){
'use strict';

function BeneficiariesMock($httpBackend) {
    var beneficiariesCount = 100;

    var generateBeneficiaries = function() {
        var displayNumbers = ['FI0516303500058060', 'FI0516303500058060', 'NO6560870520711'];
        var foreNames = ['Mats', 'Anders', 'Jesper Friis', 'Amanda Christina', 'Topi', 'Yrjö', 'Lauri', 'Benny'];
        var surNames = ['Mickelson', 'Andersson', 'Hansen', 'Engelberg', 'Petterson', 'Nystrom', 'Pekkala', 'Lainiala', 'Torttula'];
        var nickNames = ['Mick', 'Andy', 'Bob', 'Candy', 'Landlord', 'Caroline', 'Make'];
        var categories = ['pg', 'third_party'];

        var beneficiaries = [];

        _.times(beneficiariesCount, function() {
            var beneficiary = {
                'id': _.uniqueId('fc_'),
                'display_number': _.sample(displayNumbers),
                'name': _.sample(foreNames) + ' ' + _.sample(surNames),
                'nickname': _.sample(nickNames),
                'category': _.sample(categories),
                'to': 'IBAN-DNBANOKK-NO6560870520711'
            };

            beneficiaries.push(beneficiary);
        });

        return beneficiaries;
    };

    var mockBeneficiaries = generateBeneficiaries();
    var statusCode = 200;

    return {
        getMocks: function() {
            return {
                statusCode: statusCode,
                mockBeneficiaries: mockBeneficiaries
            };
        },
        mock: function() {
            $httpBackend.whenGET(/.*\/banking\/beneficiaries$/).respond(statusCode, mockBeneficiaries);
        },
        setMocks: function(newStatusCode, newMockData) {
            statusCode = newStatusCode;
            mockBeneficiaries = newMockData;
        }
    };
}

angular.module('dbw-beneficiaries')
    .config(['$provide', function($provide) {
        $provide.decorator('benefBeneficiariesService', ['$delegate', 'benefBeneficiariesServiceMock',
            function($delegate, benefBeneficiariesServiceMock) {
                benefBeneficiariesServiceMock.mock();
                return $delegate;
        }]);
    }])
    .factory('benefBeneficiariesServiceMock', ['$httpBackend', function($httpBackend) {
        return new BeneficiariesMock($httpBackend);
    }]);

})();
(function(){
'use strict';

function BeneficiariesDetailsMock($httpBackend) {

    var generateDetails = function(beneficiary) {
        var addressNames = ['Kontiokatu 1', 'Kangasranta 8', 'Kuivakatu 7', 'Kummatinkatu 9',
            'Pyhäkatu 11', 'Jormakankatu 3', 'Matkamiehenkatu 1'];
        var postalCodes = ['90123', '12565', '94732', '92734', '65783', '12365', '99817', '99552'];
        var branchCodes = ['111111', '222222', '23423', '44345', '664643',
            '34345345', '33333', '12123123'];
        var cities = ['Oulu', 'Tampere', 'Helsinki', 'Raahe', 'Turku', 'Pyhäjoki', 'Sodankylä'];
        var bankNames = ['Nordea', 'Osuuspankki', 'Aktia', 'Sampo', 'Merita'];
        var bics = ['NDEAFIHH', 'OPEAFIHH', 'AKTIFIHH', 'SAMAFIHH', 'MEEAFIHH'];
        var countries = ['Finland', 'Sweden', 'Denmark', 'Norway'];

        return {
            'id': beneficiary.id,
            'display_number': beneficiary.display_number,
            'name': beneficiary.name,
            'address': {
                'address1': _.sample(addressNames),
                'address2': _.sample(postalCodes),
                'address3': _.sample(cities)
            },
            'country': _.sample(countries),
            'bank_name': _.sample(bankNames),
            'bic': _.sample(bics),
            'branch_code': _.sample(branchCodes),
            "bank_address": {
                'address1': _.sample(addressNames),
                'address2': _.sample(postalCodes),
                'address3': _.sample(cities)
            },
            'nickname': beneficiary.nickname,
            'category': beneficiary.category,
            'to': beneficiary.to,
            'message': 'test message',
            'reference': 'test reference'
        };
    };

    var getDetailsById = function (beneficiaryId) {
        for(var index = 0; index < mockDetails.length; ++index) {
            if(mockDetails[index].id === beneficiaryId) {
                return mockDetails[index];
            }
        }
    };

    var mockDetails = [];
    var statusCode = 200;

    return {
        getMocks: function() {
            return {
                statusCode: statusCode,
                mockDetails: mockDetails
            };
        },
        mock: function(beneficiaries) {

            for(var index = 0; index < beneficiaries.mockBeneficiaries.length; ++index) {
                mockDetails.push(generateDetails(beneficiaries.mockBeneficiaries[index]));
            }

            $httpBackend.whenGET(/.*\/banking\/beneficiaries\/.*$/).respond(function(method, url) {
                var splitUrl = url.split('/');
                return [statusCode, getDetailsById(splitUrl[splitUrl.length - 1])];
            });
        },
        setMocks: function(newStatusCode, newMockData) {
            statusCode = newStatusCode;
            mockDetails = newMockData;
        }
    };
}

angular.module('dbw-beneficiaries')
    .config(['$provide', function($provide) {
        $provide.decorator('benefBeneficiariesDetailsService', [
            '$delegate',
            'benefBeneficiariesDetailsServiceMock',
            'benefBeneficiariesServiceMock',
            function($delegate, benefBeneficiariesDetailsServiceMock, benefBeneficiariesServiceMock) {
                benefBeneficiariesDetailsServiceMock.mock(benefBeneficiariesServiceMock.getMocks());
                return $delegate;
            }]);
    }])
    .factory('benefBeneficiariesDetailsServiceMock', ['$httpBackend', function($httpBackend) {
        return new BeneficiariesDetailsMock($httpBackend);
    }]);

})();
(function(){
'use strict';

angular.module('dbw-beneficiaries.mocks', ['dbw-beneficiaries', 'ngMockE2E', 'dbw-core'])
    .run(['$httpBackend', function($httpBackend) {

        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();

    }]);
})();
(function(){
'use strict';

var PdfServiceMock = function ($httpBackend) {
    var mockPdf = (function() {
        var json = null;
        $.ajax({
            'async': false,
            'global': false,
            'url': '/acc/shared/accounts/statement/pdf.json',
            'dataType': 'json',
            'success': function (data) {
                json = data;
            }
        });
        return json;
    })();

    return {
        mock: function() {
            $httpBackend.whenGET(/.*\/pfm\/pdf\/.*/).respond(function() {
                return [200, mockPdf];
            });
        }
    };

};

angular
    .module('dbw-accounts')
    .factory('PdfFactory', ['$httpBackend', function factory($httpBackend) {
        return new PdfServiceMock($httpBackend);
    }]);


})();
(function(){
'use strict';

function config($provide) {
    $provide.decorator('pdfService', ['$delegate', 'PdfFactory',
        function delegate($delegate, PdfFactory) {
            PdfFactory.mock();
            return $delegate;
        }
    ]);
}

angular
    .module('dbw-accounts')
    .config(['$provide', config]);

})();
(function(){
'use strict';

function AccountServiceMock($httpBackend) {

    var statusCode = 200;
    var mockData =
        {
            'accounts': [{
                'account_number': 'NAID-SE-SEK-32580077669',
                'display_account_number': '32580077669',
                'iban': 'SE7430000000032580077669',
                'account_status': 'OPEN',
                'nickname': 'Lönekontooo',
                'available_balance': 98809120.90,
                'booked_balance': 98809120.90,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'PERSONKONTO',
                'product_code': '4001',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32580077936',
                'display_account_number': '32580077936',
                'iban': 'SE4330000000032580077936',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 159.90,
                'booked_balance': 159.90,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'PERSONKONTO',
                'product_code': '4001',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32580077944',
                'display_account_number': '32580077944',
                'iban': 'SE2130000000032580077944',
                'account_status': 'OPEN',
                'nickname': 'Mitt personkonto',
                'available_balance': 1811546.33,
                'booked_balance': 1811546.33,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'PERSONKONTO',
                'product_code': '4001',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32581014679',
                'display_account_number': '32581014679',
                'iban': 'SE5330000000032581014679',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 37234.11,
                'booked_balance': -12765.89,
                'currency': 'SEK',
                'credit_limit': 50000.00,
                'product_name': 'CHECKKONTO',
                'product_code': '0039',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32581030895',
                'display_account_number': '32581030895',
                'iban': 'SE7930000000032581030895',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 27054.34,
                'booked_balance': 27054.34,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'EXTERNT KONTO',
                'product_code': '5119',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32581705051',
                'display_account_number': '32581705051',
                'iban': 'SE1430000000032581705051',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 145064.54,
                'booked_balance': 145064.54,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'CROSS-BORDER ACCOUNT',
                'product_code': '0028',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32581705078',
                'display_account_number': '32581705078',
                'iban': 'SE6130000000032581705078',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 1206.39,
                'booked_balance': 1206.39,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FÖRETAGSKONTO',
                'product_code': '0029',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32581705094',
                'display_account_number': '32581705094',
                'iban': 'SE1730000000032581705094',
                'account_status': 'OPEN',
                'nickname': 'Utlandskonto',
                'available_balance': 58423.79,
                'booked_balance': 58423.79,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'CROSS-BORDER ACCOUNT',
                'product_code': '0028',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32581705108',
                'display_account_number': '32581705108',
                'iban': 'SE2730000000032581705108',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 17161.40,
                'booked_balance': 17161.40,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FÖRETAGSKONTO',
                'product_code': '0029',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119016',
                'display_account_number': '32582119016',
                'iban': 'SE7530000000032582119016',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 10000033.00,
                'booked_balance': 10000033.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'SPECIALKONTO',
                'product_code': '1175',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119024',
                'display_account_number': '32582119024',
                'iban': 'SE5330000000032582119024',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 102630.94,
                'booked_balance': 102630.94,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'SPARKONTO FÖRETAG',
                'product_code': '1150',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119032',
                'display_account_number': '32582119032',
                'iban': 'SE3130000000032582119032',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 22045591.59,
                'booked_balance': 22045591.59,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FÖRMÅNSKONTO',
                'product_code': '1145',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119032-44110003926',
                'display_account_number': '44110003926',
                'main_account_number': '32582119032',
                'iban': '',
                'account_status': 'OPEN',
                'nickname': 'Min placering 2 år XXX',
                'available_balance': 0,
                'booked_balance': 20000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FASTRÄNTEPLACERING',
                'product_code': '1329',
                'product_type': 'Placeringskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119032-44110003888',
                'display_account_number': '44110003888',
                'main_account_number': '32582119032',
                'iban': '',
                'account_status': 'OPEN',
                'nickname': 'Min placering 3 år XXX',
                'available_balance': 0,
                'booked_balance': 30000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FASTRÄNTEPLACERING',
                'product_code': '1329',
                'product_type': 'Placeringskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119032-44110003942',
                'display_account_number': '44110003942',
                'main_account_number': '32582119032',
                'iban': '',
                'account_status': 'OPEN',
                'nickname': 'Min placering 5 år XXX',
                'available_balance': 0,
                'booked_balance': 18000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FASTRÄNTEPLACERING',
                'product_code': '1329',
                'product_type': 'Placeringskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119040',
                'display_account_number': '32582119040',
                'iban': 'SE0930000000032582119040',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 2642.00,
                'booked_balance': 2642.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'SPECIALKONTO',
                'product_code': '1175',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119059',
                'display_account_number': '32582119059',
                'iban': 'SE7830000000032582119059',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 51052.68,
                'booked_balance': 51052.68,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'ÅTERVINNINGSKONTO',
                'product_code': '1160',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119067',
                'display_account_number': '32582119067',
                'iban': 'SE5630000000032582119067',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 25851.89,
                'booked_balance': 25851.89,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'SKOGSLIKVIDKONTO',
                'product_code': '1153',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119075',
                'display_account_number': '32582119075',
                'iban': 'SE3430000000032582119075',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 5.00,
                'booked_balance': 5.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'ÅTERVINNINGSKONTO',
                'product_code': '1160',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119083',
                'display_account_number': '32582119083',
                'iban': 'SE1230000000032582119083',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0.00,
                'booked_balance': 0.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'SKOGSKONTO',
                'product_code': '1181',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            }, {
                'account_number': 'NAID-SE-SEK-32582119091',
                'display_account_number': '32582119091',
                'iban': 'SE8730000000032582119091',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0.00,
                'booked_balance': 0.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'SKOGSKONTO',
                'product_code': '1181',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            }, {
                'account_number': 'NAID-SE-SEK-34221137851',
                'display_account_number': '34221137851',
                'iban': 'SE1930000000034221137851',
                'account_status': 'OPEN',
                'nickname': 'Aktielikvid nr',
                'available_balance': 505881.69,
                'booked_balance': 505881.69,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'AKTIELIKVIDKONTO',
                'product_code': '0059',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-34802139969',
                'display_account_number': '34802139969',
                'iban': 'SE1630000000034802139969',
                'account_status': 'OPEN',
                'nickname': 'Skogslikvid nr 1',
                'available_balance': 102906.99,
                'booked_balance': 102906.99,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'SKOGSLIKVIDKONTO',
                'product_code': '1153',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-EUR-34802139969-44110002172',
                'display_account_number': '44110002172',
                'main_account_number': '34802139969',
                'iban': 'SE1630000000034802139969',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 727.36,
                'booked_balance': 727.36,
                'currency': 'EUR',
                'credit_limit': 0.00,
                'product_name': 'SKOGSLIKVIDKONTO',
                'product_code': '1153',
                'product_type': 'Sparkonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-172403',
                'display_account_number': '172403',
                'iban': 'SE9095000099604200172403',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 280011.99,
                'booked_balance': 280011.99,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'PLUSGIROKONTO FTG',
                'product_code': '0512',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }, {
                'account_number': 'NAID-SE-SEK-172403-44260032573',
                'display_account_number': '44260032573',
                'main_account_number': '172403',
                'iban': '',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 0,
                'booked_balance': 20000.00,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'FASTRÄNTEPLACERING',
                'product_code': '1329',
                'product_type': 'Placeringskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': false,
                    'can_transfer_from_account': false,
                    'can_transfer_to_account': false
                }
            }, {
                'account_number': 'NAID-SE-SEK-172502',
                'display_account_number': '172502',
                'iban': 'SE1195000099602600172502',
                'account_status': 'OPEN',
                'nickname': null,
                'available_balance': 102219.05,
                'booked_balance': 102219.05,
                'currency': 'SEK',
                'credit_limit': 0.00,
                'product_name': 'AFFÄRSGIRO',
                'product_code': '0511',
                'product_type': 'Transaktionskonton',
                'remaining_free_withdrawals': null,
                'permissions': {
                    'can_view': true,
                    'can_view_transactions': true,
                    'can_pay_from_account': true,
                    'can_transfer_from_account': true,
                    'can_transfer_to_account': true
                }
            }]
        };


    return {
        mock: function () {
            $httpBackend.whenGET(/api\/dbf\/se\/accounts-v05\/accounts$/).respond(function () {
                return [statusCode, mockData];
            });
        },
        setMocks: function (newStatusCode, newMockData) {
            statusCode = newStatusCode;
            mockData = newMockData;
        }
    };

}

angular
    .module('dbw-accounts')
    .factory('AccountFactory', [
        '$httpBackend',
        AccountServiceMock
    ]);

})();
(function(){
'use strict';

function config($provide) {

    $provide.decorator('accAccountFactory', ['$delegate', 'AccountFactory',
        function mockedAccounts($delegate, AccountFactory) {
            AccountFactory.mock();
            return $delegate;
        }
    ]);

}

angular
    .module('dbw-accounts')
    .config([
        '$provide',
        config
    ]);

})();
(function(){
/**
 * Created by Z420696 on 17.2.2016.
 */

'use strict';

angular
    .module('dbw-accounts.mocks', [
        'dbw-accounts',
        'ngMockE2E'])
    .run(['$httpBackend', function($httpBackend) {
        var token = {'token':'abc','state':'VERIFIED'};
        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
        $httpBackend.whenPOST(/.*security\/oauth2\/servicetoken.*/).respond(200, token);
    }]);

})();
(function(){
'use strict';
/*
 function OwnTransferServiceMock($httpBackend){

 OwnTransferServiceMock.prototype.mock = function (responseCode, testResponse) {
 */
// $httpBackend.whenGET(/.*banking\/payments.*/).respond(responseCode, testResponse);
// $httpBackend.whenPOST(/.*banking\/payments.*/).respond(responseCode, testResponse);
/*
 };

 OwnTransferServiceMock.prototype.testResponse = function(testMessage){
 return {
 message : testMessage
 };
 };
 }

 angular.module('dbw-payments.corporate.sendMoney.ownTransfer')
 .config(function ($provide) {
 $provide.decorator('OwnTransferService', ['$delegate', 'testResponse', 'OwnTransferServiceMock',
 function ($delegate, testResponse, OwnTransferServiceMock) {
 OwnTransferServiceMock.mock(200, testResponse);
 return $delegate;
 }
 ]);
 })

 .factory('testResponse', function (OwnTransferServiceMock){
 return OwnTransferServiceMock.testResponse('Transfer Successful via mocks !!');
 })

 .factory('OwnTransferServiceMock', function ($httpBackend) {
 return new OwnTransferServiceMock($httpBackend);
 });
 */

})();
(function(){
(function () {
    'use strict';

    /* eslint angular/component-limit: [0] */
    angular
        .module('dbw-payments.common')
        .config(['$provide', function ($provide) {
            $provide.decorator('paymentService', ['$delegate', '$httpBackend', function paymentService($delegate, $httpBackend) {
                var success = {
                    'id': '1000'
                };

                var requestFailed = {
                    'type': 'unauthorized',
                    'code': 'unauthorized',
                    'message': 'payment with non-authorized account',
                    'param': ''
                };

                var payments = [
                    {
                        'id': '891354449814',
                        'title': '',
                        'from': 'NAID-SE-SEK-172403',
                        'to': 'LBAN-SE-12331422400',
                        'amount': 10,
                        'status': 'unconfirmed',
                        'type': 'lban',
                        'due': '2016-03-29',
                        'currency': 'SEK',
                        'permissions': {
                            'delete': true,
                            'copy': false,
                            'modify': {
                                'from': true,
                                'to': true,
                                'amount': true,
                                'due': true,
                                'message': true,
                                'recurring_count': true,
                                'recurring_interval': true,
                                'recurring_repeats': true,
                                'recurring_lastday': true,
                                'type': true
                            }
                        },
                        'extra_messages': [
                            {
                                'title': 'receivername',
                                'value': 'ÖGB'
                            }
                        ]
                    },
                    {
                        'id': '891381174861',
                        'title': '',
                        'from': 'NAID-SE-SEK-172403',
                        'to': 'LBAN-SE-12331422400',
                        'amount': 1.1,
                        'status': 'confirmed',
                        'type': 'lban',
                        'due': '2016-03-29',
                        'currency': 'SEK',
                        'permissions': {
                            'delete': true,
                            'copy': false,
                            'modify': {
                                'from': true,
                                'to': true,
                                'amount': true,
                                'due': true,
                                'message': true,
                                'recurring_count': true,
                                'recurring_interval': true,
                                'recurring_repeats': true,
                                'recurring_lastday': true,
                                'type': true
                            }
                        },
                        'extra_messages': [
                            {
                                'title': 'receivername',
                                'value': 'ÖGB'
                            }
                        ]
                    },
                    {
                        'id': '891408027463',
                        'title': '',
                        'from': 'NAID-SE-SEK-32580077669',
                        'to': 'BG-52315652',
                        'amount': 11,
                        'status': 'rejected',
                        'type': 'bankgiro',
                        'due': '2016-04-01',
                        'currency': 'SEK',
                        'permissions': {
                            'delete': true,
                            'copy': false,
                            'modify': {
                                'from': true,
                                'to': true,
                                'amount': true,
                                'due': true,
                                'message': true,
                                'recurring_count': true,
                                'recurring_interval': true,
                                'recurring_repeats': true,
                                'recurring_lastday': true,
                                'type': true
                            }
                        },
                        'extra_messages': [
                            {
                                'title': 'receivername',
                                'value': 'SNÖDROPPEN HB'
                            }
                        ]
                    }
                ];

                $httpBackend.whenGET(/.*banking\/payments$/)
                    .respond(function () {
                        return [200, payments, {}];
                    });

                $httpBackend.whenPOST(/.*banking\/payments$/).respond(
                    function (method, url, data) {
                        var payLoad = JSON.parse(data);
                        if (payLoad.to.endsWith('9999')) {
                            return [402, requestFailed];
                        } else {
                            return [200, success];
                        }
                    }
                );

                return $delegate;
            }]);
        }]);
})();

})();
(function(){
'use strict';

/* eslint angular/component-limit: [0] */
angular
    .module('dbw-payments.common')
    .config(['$provide', function ($provide) {
        $provide.decorator(
            'PayeeService',
            ['$delegate', '$httpBackend', function PayeeService($delegate, $httpBackend) {
                $httpBackend.whenGET(/.*banking\/payee\/LBAN-SE-101/)
                    .respond(400, {
                        'type': 'bad_request',
                        'code': 'invalid_field',
                        'message': 'Account numbers in bank Nordea (NB) must be at least 7 digits',
                        'param': 'account_key'
                    });

                $httpBackend.whenGET(/.*banking\/payee\/LBAN-SE-*.*/)
                    .respond(200, {
                        'success': true,
                        'country': 'SE',
                        'status': true,
                        'bank_name': 'Danske Bank Sverige'
                    });

                $httpBackend.whenGET(/.*banking\/payee\/PG-101/)
                    .respond(400, {
                        'type': 'bad_request',
                        'code': 'invalid_field',
                        'message': 'Invalid PG Number',
                        'param': 'account_key'
                    });

                $httpBackend.whenGET(/.*banking\/payee\/PG-*.*/)
                    .respond(200, {
                        'owner_name': 'BONNIER TIDSKRIFTER AB',
                        'ocr': 'hard',
                        'next_date': '2016-03-18',
                        'country': 'SE'
                    });

                $httpBackend.whenGET(/.*banking\/payee\/BG-101/)
                    .respond(400, {
                        'type': 'bad_request',
                        'code': 'invalid_field',
                        'message': 'Invalid BG Number',
                        'param': 'account_key'
                    });

                $httpBackend.whenGET(/.*banking\/payee\/BG-*.*/)
                    .respond(200, {
                        'owner_name': 'ST1 Sverige AB',
                        'ocr': 'soft',
                        'next_date': '2016-03-21',
                        'country': 'SE'
                    });

                return $delegate;
            }]
        );
    }]);

})();
(function(){
'use strict';

/* eslint angular/component-limit: [0] */
angular
    .module('dbw-payments.common')
    .config(['$provide', function ($provide) {
        $provide.decorator('BeneficiariesService', ['$delegate', 'mockedbeneficiaries', 'BeneficiariesServiceMock',
            function BeneficiariesServiceDecorator($delegate, beneficiaries, BeneficiariesServiceMock) {
                BeneficiariesServiceMock.mock(200, beneficiaries);
                return $delegate;
            }
        ]);
    }])
    .factory('mockedbeneficiaries', function mockedbeneficiariesFactory() {
        return [
            {
                'id': '1',
                'display_number': '13213535',
                'name': 'Name One',
                'address': {
                    'address1': 'Street 1 12345, City',
                    'address2': 'Street 2 23456, City',
                    'address3': 'Street 3 34567 City'
                },
                'country': 'FI',
                'bank_name': 'Nordea',
                'bic': 'NDEAFIHH',
                'branch_code': '',
                'bank_address': {
                    'address1': 'Kirkkokatu 6, 90100 Oulu',
                    'address2': 'Hamngatan 12',
                    'address3': 'Kirkegade 3'
                },
                'nickname': 'nick',
                'category': 'pg',
                'to': 'IBAN-DNBANOKK-NO6560870520711',
                'message': 'mess',
                'reference': 'ref'
            },
            {
                'id': '2',
                'display_number': '13213535',
                'name': 'Name Two',
                'address': {
                    'address1': 'Street 1 12345, City',
                    'address2': 'Street 2 23456, City',
                    'address3': 'Street 3 34567 City'
                },
                'country': 'FI',
                'bank_name': 'Nordea',
                'bic': 'NDEAFIHH',
                'branch_code': '',
                'bank_address': {
                    'address1': 'Kirkkokatu 6, 90100 Oulu',
                    'address2': 'Hamngatan 12',
                    'address3': 'Kirkegade 3'
                },
                'nickname': 'nick',
                'category': 'pg',
                'to': 'IBAN-DNBANOKK-NO6560870520711',
                'message': 'mess',
                'reference': 'ref'
            },
            {
                'id': '3',
                'display_number': '13213535',
                'name': 'Name Three',
                'address': {
                    'address1': 'Street 1 12345, City',
                    'address2': 'Street 2 23456, City',
                    'address3': 'Street 3 34567 City'
                },
                'country': 'FI',
                'bank_name': 'Nordea',
                'bic': 'NDEAFIHH',
                'branch_code': '',
                'bank_address': {
                    'address1': 'Kirkkokatu 6, 90100 Oulu',
                    'address2': 'Hamngatan 12',
                    'address3': 'Kirkegade 3'
                },
                'nickname': 'nick',
                'category': 'pg',
                'to': 'IBAN-DNBANOKK-NO6560870520711',
                'message': 'mess',
                'reference': 'ref'
            }
        ];
    })

    .factory('BeneficiariesServiceMock', ['$httpBackend', function BeneficiariesServiceMock($httpBackend) {
        this.mock = function (responseCode, beneficiaries) {
            //to get all beneficiaries
            $httpBackend.whenGET(/.*banking\/beneficiaries$.*/).respond(responseCode, beneficiaries);
        };
    }]);

})();
(function(){
'use strict';

function AccountServiceMockGenerator($httpBackend) {

    AccountServiceMockGenerator.prototype.getMatchingAccount = function (regexp, url, accounts) {
        var accountNumber = url.match(regexp)[1];
        var account;
        for (var i = 0; accounts[i]; i++) {
            account = accounts[i];
            if (account.urlAlias === accountNumber) {
                return account;
            }
        }
        return undefined;
    };

    AccountServiceMockGenerator.prototype.mock = function (responseCode, accounts) {
        var self = this;

        //to get all accounts
        $httpBackend.whenGET(/.*accounts$.*/).respond(responseCode, accounts);

        //to get one account
        var accountRegexp = new RegExp('/.*/accounts/([A-Za-z0-9\\-_]*[^\/]$)');
        $httpBackend.whenGET(function (url) {
            return accountRegexp.test(url);
        }).respond(function (method, url) {
            var account = self.getMatchingAccount(accountRegexp, url, accounts);
            if (account) {
                return [responseCode, account];
            }
            return [404, 'Not Found'];
        });
    };
}

/* eslint angular/component-limit: [0] */
angular
    .module('dbw-payments.common')
    .config(['$provide', function ($provide) {
        $provide.decorator('AccountService', ['$delegate', 'mockedAccounts', 'AccountServiceMock',
            function AccountServiceDecorator($delegate, accounts, AccountServiceMock) {
                AccountServiceMock.mock(200, accounts);
                return $delegate;
            }
        ]);
    }])
    .factory('mockedAccounts', ['AccountServiceMock', function mockedAccountsFactory(AccountServiceMock) {
        return {
            'accounts': [
                {
                    'account_number': 'NAID-SE-EUR-34802139969-44110002172',
                    'display_account_number': '44110002172',
                    'main_account_number': '34802139969',
                    'iban': 'SE1630000000034802139969',
                    'account_status': 'OPEN',
                    'nickname': null,
                    'available_balance': 727.36,
                    'booked_balance': 727.36,
                    'currency': 'EUR',
                    'credit_limit': 0.00,
                    'product_name': 'SKOGSLIKVIDKONTO',
                    'product_code': '1153',
                    'product_type': 'Sparkonton',
                    'remaining_free_withdrawals': null,
                    'permissions': {
                        'can_view': true,
                        'can_view_transactions': true,
                        'can_pay_from_account': false,
                        'can_transfer_from_account': true,
                        'can_transfer_to_account': true
                    }
                },
                {
                    'account_number': 'NAID-SE-SEK-4805306661',
                    'display_account_number': '4805306661',
                    'iban': 'SE7130000000004805306661',
                    'account_status': 'OPEN',
                    'nickname': null,
                    'available_balance': 0.00,
                    'booked_balance': -1125.67,
                    'currency': 'SEK',
                    'credit_limit': 0.00,
                    'product_name': 'PERSONKONTO',
                    'product_code': '4001',
                    'product_type': 'Transaktionskonton',
                    'remaining_free_withdrawals': null,
                    'permissions': {
                        'can_view': true,
                        'can_view_transactions': true,
                        'can_pay_from_account': true,
                        'can_transfer_from_account': true,
                        'can_transfer_to_account': true
                    }
                },
                {
                    'account_number': 'NAID-SE-SEK-31141014335',
                    'display_account_number': '31141014335',
                    'iban': 'SE5530000000031141014335',
                    'account_status': 'OPEN',
                    'nickname': 'ALJL -LJLSLLS ÄÄÄÄEÅÅÅÅ',
                    'available_balance': 175.00,
                    'booked_balance': 175.00,
                    'currency': 'SEK',
                    'credit_limit': 0.00,
                    'product_name': 'AKTIELIKVIDKONTO',
                    'product_code': '0059',
                    'product_type': 'Transaktionskonton',
                    'remaining_free_withdrawals': null,
                    'permissions': {
                        'can_view': true,
                        'can_view_transactions': true,
                        'can_pay_from_account': true,
                        'can_transfer_from_account': true,
                        'can_transfer_to_account': true
                    }
                },
                {
                    'account_number': 'NAID-SE-SEK-31141014343',
                    'display_account_number': '31141014343',
                    'iban': 'SE3330000000031141014343',
                    'account_status': 'OPEN',
                    'nickname': 'SDFDSSDGFGFGFGGGGGGGGGG',
                    'available_balance': 15632.00,
                    'booked_balance': 15632.00,
                    'currency': 'SEK',
                    'credit_limit': 0.00,
                    'product_name': 'EXTERNT KONTO',
                    'product_code': '5119',
                    'product_type': 'Transaktionskonton',
                    'remaining_free_withdrawals': null,
                    'permissions': {
                        'can_view': true,
                        'can_view_transactions': true,
                        'can_pay_from_account': true,
                        'can_transfer_from_account': true,
                        'can_transfer_to_account': true
                    }
                },
                {
                    'account_number': 'NAID-SE-EUR-34802139969-44110002172',
                    'display_account_number': '44110002171',
                    'main_account_number': '34802139960',
                    'iban': 'SE1630000000034802139960',
                    'account_status': 'OPEN',
                    'nickname': null,
                    'available_balance': 727.36,
                    'booked_balance': 727.36,
                    'currency': 'EUR',
                    'credit_limit': 0.00,
                    'product_name': 'SKOGSLIKVIDKONTO',
                    'product_code': '1153',
                    'product_type': 'Sparkonton',
                    'remaining_free_withdrawals': null,
                    'permissions': {
                        'can_view': true,
                        'can_view_transactions': true,
                        'can_pay_from_account': true,
                        'can_transfer_from_account': true,
                        'can_transfer_to_account': true
                    }
                },
                {
                    'account_number': 'NAID-SE-USD-34802139969-44110002174',
                    'display_account_number': '44110002174',
                    'main_account_number': '34802139963',
                    'iban': 'SE1630000000034802139963',
                    'account_status': 'OPEN',
                    'nickname': null,
                    'available_balance': 727.36,
                    'booked_balance': 727.36,
                    'currency': 'USD',
                    'credit_limit': 0.00,
                    'product_name': 'SKOGSLIKVIDKONTO',
                    'product_code': '1153',
                    'product_type': 'Sparkonton',
                    'remaining_free_withdrawals': null,
                    'permissions': {
                        'can_view': true,
                        'can_view_transactions': true,
                        'can_pay_from_account': true,
                        'can_transfer_from_account': true,
                        'can_transfer_to_account': true
                    }
                }
            ]
        };

    }])
    .factory('AccountServiceMock', ['$httpBackend', function AccountServiceMockFactory($httpBackend) {
        return new AccountServiceMockGenerator($httpBackend);
    }]);

})();
(function(){
'use strict';

angular
    .module('dbw-payments.mocks', [
        'dbw-payments',
        'ngMockE2E',
        'dbw-payments.household.mock.definitions'
    ])
    .config(function () {
        angular.MOCKDATA = {auth: true};
    })
    .run(['$httpBackend', function setMocks($httpBackend) {
        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
        $httpBackend.whenHEAD(/^.*.tpl.html/).passThrough();
    }]);

})();
(function(){
'use strict';

angular.module('dbw-login.mocks', ['dbw-login', 'ngMockE2E'])
    .run(['$httpBackend', function($httpBackend) {
        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
    }]);

})();
(function(){
'use strict';

(function () {
    'use strict';
    /*eslint-disable angular/component-limit*/

    function CardServiceMock($httpBackend) {
        var urls = {
            cardlist: ['http://localhost:8000/v0/cards/', 'http://ap-micros1s/v0.2/banking/cards/fi/']
        };

        function getCardListWrapper(cards) {
            return { cards: cards };
        }

        function doMocking(mockUrls, response) {
            var mock = function mock(url) {
                $httpBackend.whenGET(url).respond(response);
            };

            if (_.isArray(mockUrls)) {
                mockUrls.forEach(mock);
            } else {
                mock(mockUrls);
            }
        }

        return {
            mock: function mock() {
                doMocking(urls.cardlist, getCardListWrapper([{
                    'card_id': '1785001',
                    'account_number': '3270039351',
                    'cardholder_name': 'Urho Kekkonen',
                    'available_balance': 40000.00,
                    'booked_balance': 10000.00,
                    'currency': 'EUR',
                    'credit_limit': 50000.00,
                    'account_status': 'active',
                    'additional_cardholder': false,
                    'masked_card_number': '1234 XXXX XXXX 0641',
                    'card_category': 'credit',
                    'card_type': 'MCGOLD',
                    'card_provider': 'MASTERCARD',
                    'card_status': 'active',
                    'product_name': 'Nordea Gold',
                    'exp_month': '05',
                    'exp_year': '2018',
                    'interest_rate': '17.50000',
                    'invoice_day': 20,
                    'total_amount_due': '1500.00',
                    'country': 'FI'
                }]));
            }
        };
    }

    angular.module('dbw-cards.cards').factory('cardServiceMock', ['$httpBackend', function cardServiceMock($httpBackend) {
        return new CardServiceMock($httpBackend);
    }]).config(['$provide', function ($provide) {
        $provide.decorator('CardsService', ['$delegate', 'cardServiceMock', function decorator($delegate, cardServiceMock) {
            cardServiceMock.mock();
            return $delegate;
        }]);
    }]);

    angular.module('dbw-cards.mocks', ['dbw-cards', 'ngMockE2E']).run(['$httpBackend', function ($httpBackend) {
        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
    }]);

    /*eslint-enable angular/component-limit*/
})();
})();
(function(){
/*eslint-env jasmine */
/*eslint angular/no-run-logic: 0 */
'use strict';

angular.module('refauthsign.mocks', ['refauthsign', 'ngMockE2E'])
    .run(['$httpBackend', function($httpBackend) {
        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
    }]);

})();
(function(){
/* eslint angular/component-limit: 0 */
/* eslint-env jasmine */

'use strict';

AuthenticationServiceMockFactory.$inject = ['$httpBackend', 'dbfEndpointConfig'];
AuthenticationServiceDecorator.$inject = ['$delegate', 'auAuthenticationServiceMock'];
angular.module('dbw-authsign.authentication')
    .factory('auAuthenticationServiceMock', AuthenticationServiceMockFactory)
    .config(['$provide', function ($provide) {
        $provide.decorator('auAuthenticationSessionService', ['$delegate', 'auAuthenticationServiceMock', AuthenticationServiceDecorator]);
    }]);

/* @ngInject */
function AuthenticationServiceMockFactory($httpBackend, dbfEndpointConfig) {
    return new AuthenticationServiceMock($httpBackend, dbfEndpointConfig);
}

/* @ngInject */
function AuthenticationServiceDecorator($delegate, auAuthenticationServiceMock) {
    auAuthenticationServiceMock.mock();
    return $delegate;
}

function AuthenticationServiceMock($httpBackend, dbfEndpointConfig) {
    var callTimes = 0;

    var authenticationRequired = {
        'error': 'external_authentication_required',
        'error_description': 'Mock auth initialized',
        'code': 'mockCode'
    };

    var okResponse = {
        responseCode: 200,
        'access_token': 'mockToken12345678910',
        'token_type': 'bearer',
        'refresh_token': 'mockRefreshToken',
        'expires_in': 569
    };

    var oldTokenOkResponse = {
        token: 'mockToken12345678910'
    };

    var multipleAgreementsResponse = {
        responseCode: 401,
        'error': 'multiple_agreement',
        'error_description': 'Agreement selection needed',
        'access_token': 'mockToken12345678910',
        'agreements': [
            {'id': 3934109, 'status': 'inactive', 'name': 'SVENSSON SANDRA'},
            {'id': 3936878, 'status': 'active'},
            {'id': 3934487, 'status': 'active', 'name': 'DANERMARK HANS-GÖRAN'},
            {'id': 3934062, 'status': 'waiting_for_signing', 'name': 'PETERBORG KALLE'},
            {'id': 3303261, 'status': 'waiting_for_signing', 'name': 'WIKSTBORG WIRJO'},
            {'id': 3932131, 'status': 'active', 'name': 'DANERMARK HANS-GÖRAN'},
            {'id': 3932132, 'status': 'active', 'name': 'BÄRG EMMA'},
            {'id': 3333363, 'status': 'active', 'name': 'PETERBORG KALLE'},
            {'id': 1231212, 'status': 'active'}
        ]
    };

    var mockResponse = function(method, url, data, headers, param) {
        var response = param.username === '194206010011' ? multipleAgreementsResponse : okResponse;
        return [response.responseCode, response];
    };

    var bankidResponse = function() {
        callTimes++;
        var data = {
            progress_status: 'OUTSTANDING_TRANSACTION'
        };

        if (callTimes === 2) {
            data = multipleAgreementsResponse;
            callTimes = 0;
        }

        return [401, data];
    };

    var codeAppResponse = function() {
        callTimes++;
        var data = {
            error: 'external_authentication_pending'
        };

        if (callTimes === 2) {
            data = multipleAgreementsResponse;
            callTimes = 0;
        }

        return [401, data];
    };

    return {
        mock: function () {
            $httpBackend.whenPOST(/.*\/security\/oauth\/token.*auth_method=mta.*code=.*username=.*/).respond(codeAppResponse);
            $httpBackend.whenPOST(/.*\/security\/oauth\/token.*auth_method=bankid_se.*code=.*username=.*/).respond(bankidResponse);
            $httpBackend.whenPOST(/.*\/security\/oauth\/token.*code=.*username=.*/).respond(mockResponse);
            $httpBackend.whenPOST(/.*\/security\/oauth\/token.*username=.*/).respond(401, authenticationRequired);
            $httpBackend.whenPOST(/.*\/security\/oauth\/token\/cancel/).respond(401, {});
            $httpBackend.whenPOST(/.*\/security\/oauth\/agreement/).respond(200, okResponse);
            $httpBackend.whenPOST(/.*\/security\/oauth\/servicetoken/).respond(200, oldTokenOkResponse);
        }
    };
}

})();
(function(){
(function () {
    'use strict';

    function LoanListServiceMock($httpBackend) {

        var mockData = [
            {
                'id': '23280508466308',
                'error_message': null,
                'loan_data': {
                    'loan_id': null,
                    'type': 'FI60002',
                    'local_number': '23280508466308',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 5088,
                    'undrawn': 0,
                    'balance': -3410.34,
                    'purpose': 'CONSUMPTION',
                    'reference_rate': 'FICON233',
                    'reference_rate_value': null,
                    'interest': 7.29,
                    'first_drawdown_date': null,
                    'interest_period_start_date': null,
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': 5088,
                    'amount_to_be_drawn': 0,
                    'paid': 1677.66,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '1',
                    'period_between_interest_payments': '1',
                    'method_of_payment': 'EQUALINSTALMENTS',
                    'initial_payment_date': null,
                    'final_payment_date': null,
                    'instalment_free_months': [
                        '000000', '000000'
                    ],
                    'following_interest_payment': '2016-01-17T08:49:48.925+0000',
                    'following_instalment': '2016-01-17T08:49:48.925+0000',
                    'number_of_instalments': null,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': null,
                    'min_instalment_percentage': 3.5,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': 'FI5610843500021234'
                },
                'outstanding_payments': null,
                'following_payment': {
                    'date': null,
                    'equity': 461.33,
                    'interest': 60.67,
                    'default_interest': null,
                    'expences': 5,
                    'insurance': null,
                    'account_expenses': 12,
                    'total': 539,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002819|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002819|TYPE=1130',
                    'type': '204',
                    'local_number': '10472006002819',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 7500,
                    'undrawn': 0,
                    'balance': -7250,
                    'purpose': 'FI50000',
                    'reference_rate': '010',
                    'reference_rate_value': 0.5,
                    'interest': 1.75,
                    'first_drawdown_date': '2014-02-11T00:00:00.000+0000',
                    'interest_period_start_date': '2014-02-11T00:00:00.000+0000',
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 250,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '06',
                    'period_between_interest_payments': '06',
                    'method_of_payment': '03',
                    'initial_payment_date': null,
                    'final_payment_date': '2021-09-30T00:00:00.000+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-03-31T00:00:00.000+0000',
                    'following_instalment': '2016-03-31T00:00:00.000+0000',
                    'number_of_instalments': 13,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': 500,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': 1750,
                    'interest': 81.58,
                    'default_interest': 49.3,
                    'expences': 12.9,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': null,
                    'interest': null,
                    'default_interest': null,
                    'expences': null,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 0,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002827|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002827|TYPE=1130',
                    'type': '201',
                    'local_number': '10472006002827',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 235000,
                    'undrawn': 0,
                    'balance': -233750,
                    'purpose': 'FI60000',
                    'reference_rate': '242',
                    'reference_rate_value': -1,
                    'interest': 0.25,
                    'first_drawdown_date': '2014-04-25T00:00:00.000+0000',
                    'interest_period_start_date': '2014-04-25T00:00:00.000+0000',
                    'interest_term_ends': '2015-04-25T00:00:00.000+0000',
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': 0,
                    'interest_rate_cap_type': '',
                    'interest_rate_cap_code': '',
                    'interest_rate_cap_floor_percentage': 0,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 1250,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '01',
                    'period_between_interest_payments': '01',
                    'method_of_payment': '06',
                    'initial_payment_date': null,
                    'final_payment_date': '2030-12-20T00:00:00.000+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-03-20T00:00:00.000+0000',
                    'following_instalment': '2016-03-20T00:00:00.000+0000',
                    'number_of_instalments': 178,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': 1235.25,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': 17892.42,
                    'interest': 1676.82,
                    'default_interest': 488.68,
                    'expences': 36.8,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': 19080.59,
                    'interest': 1723.9,
                    'default_interest': 546.37,
                    'expences': 39.1,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 21389.96,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': '24810781146372',
                'error_message': null,
                'loan_data': {
                    'loan_id': null,
                    'type': 'FIO',
                    'local_number': '24810781146372',
                    'granted': 0,
                    'financed_object_name': 'Auto',
                    'financed_object_id': 'AAA-123',
                    'drawn': null,
                    'undrawn': null,
                    'balance': null,
                    'purpose': 'HIREPURCHASE',
                    'reference_rate': 'FIOMA000',
                    'reference_rate_value': null,
                    'interest': null,
                    'first_drawdown_date': null,
                    'interest_period_start_date': null,
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': null,
                    'currency': 'EUR',
                    'contact_information': '09-1858 9000'
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '01',
                    'period_between_interest_payments': null,
                    'method_of_payment': 'FIOMAA',
                    'initial_payment_date': '2001-12-27T08:49:53.724+0000',
                    'final_payment_date': null,
                    'instalment_free_months': null,
                    'following_interest_payment': null,
                    'following_instalment': null,
                    'number_of_instalments': null,
                    'payment_reference': '70010 86003 00080 00009',
                    'available_flexi_payment_amount': null,
                    'payment_amount': null,
                    'min_instalment_percentage': null,
                    'method_of_debiting': 'INVOICE',
                    'account_to_be_credited_number': 'FI4515593000000114'
                },
                'outstanding_payments': {
                    'date': '2003-04-04T07:49:53.724+0000',
                    'equity': null,
                    'interest': null,
                    'default_interest': null,
                    'expences': null,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 0,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': 0,
                    'interest': 0,
                    'default_interest': null,
                    'expences': 0,
                    'insurance': 0,
                    'account_expenses': null,
                    'total': 0,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': {
                    'date': null,
                    'equity': 0,
                    'interest': 0,
                    'default_interest': 0,
                    'expences': 0,
                    'insurance': 0,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null,
                    'status': true
                },
                'latest_payment': {
                    'date': null,
                    'total': 0
                },
                'received_payment': {
                    'total': 0
                },
                'parties': [
                    'Testimaksaja1 AAA-123', 'Testimaksaja2 AAA-123', 'Testimaksaja3 AAA-123', 'Testimaksaja4 AAA-123', 'Testimaksaja5 AAA-123'
                ]
            }, {
                'id': '23280504169310',
                'error_message': 'VCSAL024',
                'loan_data': null,
                'upcoming_loan_payment': null,
                'repayment_schedule': null,
                'outstanding_payments': null,
                'following_payment': null,
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': '23280503904022',
                'error_message': null,
                'loan_data': {
                    'loan_id': null,
                    'type': 'FI60100',
                    'local_number': '23280503904022',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 38253.08,
                    'undrawn': -29753.08,
                    'balance': -1074.37,
                    'purpose': 'CONSUMPTION',
                    'reference_rate': 'FICON010',
                    'reference_rate_value': null,
                    'interest': 1.25,
                    'first_drawdown_date': null,
                    'interest_period_start_date': null,
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': 8500,
                    'amount_to_be_drawn': 7425.63,
                    'paid': 37178.71,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '1',
                    'period_between_interest_payments': '1',
                    'method_of_payment': 'EQUALINSTALMENTS',
                    'initial_payment_date': null,
                    'final_payment_date': null,
                    'instalment_free_months': [
                        '201612', '000000'
                    ],
                    'following_interest_payment': '2016-01-15T08:49:54.016+0000',
                    'following_instalment': '2016-01-15T08:49:54.016+0000',
                    'number_of_instalments': null,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': null,
                    'min_instalment_percentage': 3,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': 'FI1312903500013272'
                },
                'outstanding_payments': null,
                'following_payment': {
                    'date': null,
                    'equity': 29.3,
                    'interest': 0.7,
                    'default_interest': null,
                    'expences': 0,
                    'insurance': null,
                    'account_expenses': 0,
                    'total': 30,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002751|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002751|TYPE=1130',
                    'type': '201',
                    'local_number': '10472006002751',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 175000,
                    'undrawn': 0,
                    'balance': -174299.46,
                    'purpose': 'FI11111',
                    'reference_rate': '233',
                    'reference_rate_value': 0.291,
                    'interest': 1.491,
                    'first_drawdown_date': '2014-02-11T00:00:00.000+0000',
                    'interest_period_start_date': '2014-02-11T00:00:00.000+0000',
                    'interest_term_ends': '2014-08-12T00:00:00.000+0000',
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': 0,
                    'interest_rate_cap_type': '',
                    'interest_rate_cap_code': '',
                    'interest_rate_cap_floor_percentage': 0,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 700.54,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '01',
                    'period_between_interest_payments': '01',
                    'method_of_payment': '01',
                    'initial_payment_date': null,
                    'final_payment_date': '2038-05-20T00:00:00.000+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-03-20T00:00:00.000+0000',
                    'following_instalment': '2016-03-20T00:00:00.000+0000',
                    'number_of_instalments': 267,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': 733.54,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': 7761.15,
                    'interest': 7371.23,
                    'default_interest': 367.45,
                    'expences': 36.8,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': 8285.35,
                    'interest': 7580.57,
                    'default_interest': 419.18,
                    'expences': 39.1,
                    'insurance': 17.65,
                    'account_expenses': null,
                    'total': 16341.85,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002793|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002793|TYPE=1130',
                    'type': '206',
                    'local_number': '10472006002793',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 3000,
                    'undrawn': 0,
                    'balance': -3000,
                    'purpose': 'FI50000',
                    'reference_rate': '242',
                    'reference_rate_value': 0,
                    'interest': 0.5,
                    'first_drawdown_date': '2014-04-23T00:00:00.000+0000',
                    'interest_period_start_date': '2014-04-23T00:00:00.000+0000',
                    'interest_term_ends': '2015-04-23T00:00:00.000+0000',
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 0,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '01',
                    'period_between_interest_payments': '01',
                    'method_of_payment': '03',
                    'initial_payment_date': null,
                    'final_payment_date': '2016-01-20T00:00:00.000+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-03-20T00:00:00.000+0000',
                    'following_instalment': '2016-03-20T00:00:00.000+0000',
                    'number_of_instalments': 1,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': 200,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': 3000,
                    'interest': 43.13,
                    'default_interest': 141.18,
                    'expences': 36.8,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': 3000,
                    'interest': 44.33,
                    'default_interest': 157.61,
                    'expences': 39.1,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 3241.04,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': '23280504192411',
                'error_message': null,
                'loan_data': {
                    'loan_id': null,
                    'type': 'FI60002',
                    'local_number': '23280504192411',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 14661,
                    'undrawn': 0,
                    'balance': -13295.52,
                    'purpose': 'CONSUMPTION',
                    'reference_rate': 'FICON233',
                    'reference_rate_value': null,
                    'interest': 6.29,
                    'first_drawdown_date': null,
                    'interest_period_start_date': null,
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': 14661,
                    'amount_to_be_drawn': 0,
                    'paid': 1365.48,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '1',
                    'period_between_interest_payments': '1',
                    'method_of_payment': 'EQUALINSTALMENTS',
                    'initial_payment_date': null,
                    'final_payment_date': null,
                    'instalment_free_months': [
                        '201608', '201701'
                    ],
                    'following_interest_payment': '2016-02-01T08:49:54.383+0000',
                    'following_instalment': '2016-02-01T08:49:54.383+0000',
                    'number_of_instalments': null,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': null,
                    'min_instalment_percentage': 2,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': null,
                'following_payment': {
                    'date': null,
                    'equity': 220.51,
                    'interest': 68.49,
                    'default_interest': null,
                    'expences': 0,
                    'insurance': null,
                    'account_expenses': 4,
                    'total': 293,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': '23280503883226',
                'error_message': null,
                'loan_data': {
                    'loan_id': null,
                    'type': 'FI60100',
                    'local_number': '23280503883226',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 41482.37,
                    'undrawn': -33072.97,
                    'balance': -8200.77,
                    'purpose': 'CONSUMPTION',
                    'reference_rate': 'FICON233',
                    'reference_rate_value': null,
                    'interest': 5.79,
                    'first_drawdown_date': null,
                    'interest_period_start_date': null,
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': 8409.4,
                    'amount_to_be_drawn': 208.63,
                    'paid': 33281.6,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '1',
                    'period_between_interest_payments': '1',
                    'method_of_payment': 'EQUALINSTALMENTS',
                    'initial_payment_date': null,
                    'final_payment_date': null,
                    'instalment_free_months': [
                        '201607', '000000'
                    ],
                    'following_interest_payment': '2016-01-31T08:49:54.496+0000',
                    'following_instalment': '2016-01-31T08:49:54.496+0000',
                    'number_of_instalments': null,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': null,
                    'min_instalment_percentage': 3,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': 'FI6910875000086762'
                },
                'outstanding_payments': null,
                'following_payment': {
                    'date': null,
                    'equity': 199.42,
                    'interest': 40.78,
                    'default_interest': null,
                    'expences': 0,
                    'insurance': null,
                    'account_expenses': 2.8,
                    'total': 243,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': '23280504656852',
                'error_message': null,
                'loan_data': {
                    'loan_id': null,
                    'type': 'FI60002',
                    'local_number': '23280504656852',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 5610,
                    'undrawn': 0,
                    'balance': -5009.99,
                    'purpose': 'CONSUMPTION',
                    'reference_rate': 'FICON233',
                    'reference_rate_value': null,
                    'interest': 7.284,
                    'first_drawdown_date': null,
                    'interest_period_start_date': null,
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': 5610,
                    'amount_to_be_drawn': 0,
                    'paid': 600.01,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '1',
                    'period_between_interest_payments': '1',
                    'method_of_payment': 'EQUALINSTALMENTS',
                    'initial_payment_date': null,
                    'final_payment_date': null,
                    'instalment_free_months': [
                        '201603', '201609'
                    ],
                    'following_interest_payment': '2016-01-15T08:49:54.558+0000',
                    'following_instalment': '2016-01-15T08:49:54.558+0000',
                    'number_of_instalments': null,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': null,
                    'min_instalment_percentage': 2,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': 'FI6612075000113140'
                },
                'outstanding_payments': null,
                'following_payment': {
                    'date': null,
                    'equity': 106.31,
                    'interest': 33.86,
                    'default_interest': null,
                    'expences': 0,
                    'insurance': null,
                    'account_expenses': 4,
                    'total': 144.17,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002769|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002769|TYPE=1130',
                    'type': '201',
                    'local_number': '10472006002769',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 543210.98,
                    'undrawn': 0,
                    'balance': -541987.63,
                    'purpose': 'FI11111',
                    'reference_rate': '011',
                    'reference_rate_value': 1.35,
                    'interest': 4.1,
                    'first_drawdown_date': '2014-04-23T00:00:00.000+0000',
                    'interest_period_start_date': '2014-04-23T00:00:00.000+0000',
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': 0,
                    'interest_rate_cap_type': '',
                    'interest_rate_cap_code': '',
                    'interest_rate_cap_floor_percentage': 0,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 1223.35,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '01',
                    'period_between_interest_payments': '01',
                    'method_of_payment': '03',
                    'initial_payment_date': null,
                    'final_payment_date': '2049-09-20T00:00:00.000+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-03-20T00:00:00.000+0000',
                    'following_instalment': '2016-03-20T00:00:00.000+0000',
                    'number_of_instalments': 403,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': 1295.35,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': 20797.6,
                    'interest': 61199.29,
                    'default_interest': 972.84,
                    'expences': 36.8,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': 22092.95,
                    'interest': 62960.01,
                    'default_interest': 1147.36,
                    'expences': 39.1,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 86239.42,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002835|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002835|TYPE=1130',
                    'type': '201',
                    'local_number': '10472006002835',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 27500,
                    'undrawn': 0,
                    'balance': -27500,
                    'purpose': 'FI60000',
                    'reference_rate': '011',
                    'reference_rate_value': 1.35,
                    'interest': 1.25,
                    'first_drawdown_date': '2014-04-25T00:00:00.000+0000',
                    'interest_period_start_date': '2014-04-25T00:00:00.000+0000',
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': 0,
                    'interest_rate_cap_type': '',
                    'interest_rate_cap_code': '',
                    'interest_rate_cap_floor_percentage': 0,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 0,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '01',
                    'period_between_interest_payments': '01',
                    'method_of_payment': '01',
                    'initial_payment_date': null,
                    'final_payment_date': '2024-04-20T00:00:00.000+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-03-20T00:00:00.000+0000',
                    'following_instalment': '2016-03-20T00:00:00.000+0000',
                    'number_of_instalments': 98,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': 255.96,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': 3470.27,
                    'interest': 970.85,
                    'default_interest': 152.54,
                    'expences': 40.5,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': 3698.99,
                    'interest': 998.09,
                    'default_interest': 171.18,
                    'expences': 42.8,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 4911.06,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002801|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002801|TYPE=1130',
                    'type': '206',
                    'local_number': '10472006002801',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 3000,
                    'undrawn': 0,
                    'balance': -3000,
                    'purpose': 'FI50000',
                    'reference_rate': '011',
                    'reference_rate_value': 1.35,
                    'interest': 1.85,
                    'first_drawdown_date': '2014-04-23T00:00:00.000+0000',
                    'interest_period_start_date': '2014-04-23T00:00:00.000+0000',
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 0,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '06',
                    'period_between_interest_payments': '06',
                    'method_of_payment': '01',
                    'initial_payment_date': null,
                    'final_payment_date': '2024-08-15T00:00:00.000+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-07-25T00:00:00.000+0000',
                    'following_instalment': '2016-07-25T00:00:00.000+0000',
                    'number_of_instalments': 18,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': 217.74,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': 609.99,
                    'interest': 69.37,
                    'default_interest': 20.96,
                    'expences': 9.2,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': null,
                    'interest': null,
                    'default_interest': null,
                    'expences': null,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 0,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': '24810781137751',
                'error_message': null,
                'loan_data': {
                    'loan_id': null,
                    'type': 'FIO',
                    'local_number': '24810781137751',
                    'granted': -40000,
                    'financed_object_name': 'MAZDA',
                    'financed_object_id': '___-9',
                    'drawn': null,
                    'undrawn': null,
                    'balance': null,
                    'purpose': 'HIREPURCHASE',
                    'reference_rate': 'FIOMA000',
                    'reference_rate_value': null,
                    'interest': null,
                    'first_drawdown_date': null,
                    'interest_period_start_date': null,
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': null,
                    'currency': 'EUR',
                    'contact_information': '09-1858 9000'
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '01',
                    'period_between_interest_payments': null,
                    'method_of_payment': 'FIOMAA',
                    'initial_payment_date': '1096-04-01T08:49:56.041+0000',
                    'final_payment_date': '1996-09-01T07:49:56.049+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': null,
                    'following_instalment': null,
                    'number_of_instalments': null,
                    'payment_reference': '70010 86003 00002 00001',
                    'available_flexi_payment_amount': null,
                    'payment_amount': null,
                    'min_instalment_percentage': null,
                    'method_of_debiting': 'INVOICE',
                    'account_to_be_credited_number': 'FI4515593000000114'
                },
                'outstanding_payments': {
                    'date': '2003-04-04T07:49:56.050+0000',
                    'equity': null,
                    'interest': null,
                    'default_interest': null,
                    'expences': null,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 1488.4,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': '2096-04-01T07:49:56.049+0000',
                    'equity': 6488.4,
                    'interest': 433.3,
                    'default_interest': null,
                    'expences': 10,
                    'insurance': 0,
                    'account_expenses': null,
                    'total': 6931.7,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': {
                    'date': null,
                    'equity': 0,
                    'interest': 0,
                    'default_interest': 0,
                    'expences': 0,
                    'insurance': 0,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null,
                    'status': false
                },
                'latest_payment': {
                    'date': '1997-05-21T07:49:56.050+0000',
                    'total': 1000
                },
                'received_payment': {
                    'total': 0
                },
                'parties': [
                    'Testimaksaja1 ___-9', 'Testimaksaja2 ___-9', 'Testimaksaja3 ___-9', 'Testimaksaja4 ___-9', 'Testimaksaja5 ___-9'
                ]
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002777|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002777|TYPE=1130',
                    'type': '201',
                    'local_number': '10472006002777',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 213500,
                    'undrawn': 0,
                    'balance': -212558.31,
                    'purpose': 'FI11111',
                    'reference_rate': '805',
                    'reference_rate_value': 0.63,
                    'interest': 1.38,
                    'first_drawdown_date': '2014-04-23T00:00:00.000+0000',
                    'interest_period_start_date': '2014-04-23T00:00:00.000+0000',
                    'interest_term_ends': null,
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': 0,
                    'interest_rate_cap_type': '',
                    'interest_rate_cap_code': '',
                    'interest_rate_cap_floor_percentage': 0,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 941.69,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '01',
                    'period_between_interest_payments': '01',
                    'method_of_payment': '06',
                    'initial_payment_date': null,
                    'final_payment_date': '2020-08-20T00:00:00.000+0000',
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-03-20T00:00:00.000+0000',
                    'following_instalment': '2016-03-20T00:00:00.000+0000',
                    'number_of_instalments': 54,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': 3200,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': 44817.5,
                    'interest': 8300.77,
                    'default_interest': 1242.39,
                    'expences': 40.5,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': 47785.08,
                    'interest': 8533.19,
                    'default_interest': 1392.12,
                    'expences': 42.8,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 57753.19,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }, {
                'id': 'NDEAFIHHXXX-FI1-EUR-10472006002785|TYPE=1130',
                'error_message': null,
                'loan_data': {
                    'loan_id': 'NDEAFIHHXXX-FI1-EUR-10472006002785|TYPE=1130',
                    'type': '206',
                    'local_number': '10472006002785',
                    'granted': null,
                    'financed_object_name': null,
                    'financed_object_id': null,
                    'drawn': 2000,
                    'undrawn': 0,
                    'balance': -2000,
                    'purpose': 'FI50000',
                    'reference_rate': '242',
                    'reference_rate_value': 0,
                    'interest': 0.5,
                    'first_drawdown_date': '2014-04-23T00:00:00.000+0000',
                    'interest_period_start_date': '2014-04-23T00:00:00.000+0000',
                    'interest_term_ends': '2015-04-23T00:00:00.000+0000',
                    'payment_account': null,
                    'interest_rate_cap_start_date': null,
                    'interest_rate_cap_end_date': null,
                    'interest_rate_cap_percentage': null,
                    'interest_rate_cap_type': null,
                    'interest_rate_cap_code': null,
                    'interest_rate_cap_floor_percentage': null,
                    'credit_limit': null,
                    'amount_to_be_drawn': null,
                    'paid': 0,
                    'currency': null,
                    'contact_information': null
                },
                'upcoming_loan_payment': null,
                'repayment_schedule': {
                    'period_between_instalments': '',
                    'period_between_interest_payments': '06',
                    'method_of_payment': '',
                    'initial_payment_date': null,
                    'final_payment_date': null,
                    'instalment_free_months': null,
                    'following_interest_payment': '2016-06-15T00:00:00.000+0000',
                    'following_instalment': null,
                    'number_of_instalments': null,
                    'payment_reference': null,
                    'available_flexi_payment_amount': null,
                    'payment_amount': null,
                    'min_instalment_percentage': null,
                    'method_of_debiting': null,
                    'account_to_be_credited_number': null
                },
                'outstanding_payments': {
                    'date': null,
                    'equity': null,
                    'interest': null,
                    'default_interest': null,
                    'expences': null,
                    'insurance': null,
                    'account_expenses': null,
                    'total': null,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'following_payment': {
                    'date': null,
                    'equity': null,
                    'interest': null,
                    'default_interest': null,
                    'expences': null,
                    'insurance': null,
                    'account_expenses': null,
                    'total': 0,
                    'latest_payment_total': null,
                    'payments_in_date': null,
                    'unallocated_payment_total': null,
                    'outstanding_payment_total': null
                },
                'outstandingDebt': null,
                'latest_payment': null,
                'received_payment': null,
                'parties': null
            }
        ];
        var statusCode = 200;

        return {
            getMocks: function () {
                return {
                    statusCode: statusCode,
                    mockData: mockData
                };
            },
            mock: function () {
                $httpBackend.whenGET(/.*banking\/loans/).respond(function () {
                    return [statusCode, mockData];
                });
            },
            setMocks: function (newStatusCode, newMockData) {
                statusCode = newStatusCode;
                mockData = newMockData;
            }
        };
    }

    /*eslint angular/function-type: [2,"anonymous"]*/
    /*eslint angular/component-limit: [2,3]*/
    angular.module('dbw-loan-credit.loan_list')
        // Replace LoanListService with mock
        .config(['$provide', function ($provide) {
            $provide.decorator('loanLoanListService', ['$delegate', 'loanLoanListServiceMock',
                function ($delegate, loanLoanListServiceMock) {
                    loanLoanListServiceMock.mock();
                    return $delegate;
                }
            ]);
        }])
        // Config some delay to mock response
        .config(['$httpProvider', function ($httpProvider) {
            $httpProvider.interceptors.push(['$q', '$timeout', '$log', function ($q, $timeout, $log) {
                return {
                    'request': function (config) {
                        return config;
                    },
                    'response': function (response) {
                        var getLoansPath = /.*banking\/loans\/?$/;
                        if (getLoansPath.test(response.config.url)) {
                            var fakeDelay = 300;
                            var deferred = $q.defer();
                            $log.debug('Delaying response with ' + fakeDelay + 'ms');
                            $timeout(function () {
                                deferred.resolve(response);
                            }, fakeDelay);
                            return deferred.promise;
                        } else {
                            return response;
                        }
                    }
                };
            }]);
        }])
        // Create the mock
        .factory('loanLoanListServiceMock', ['$httpBackend',
            function ($httpBackend) {
                return new LoanListServiceMock($httpBackend);
            }
        ]);
})();

})();
(function(){
(function () {
    'use strict';

    var run = function ($httpBackend) {
        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
    };
    run.$inject = ['$httpBackend'];
    angular
        .module('dbw-loan-credit.mocks', [
            'dbw-loan-credit',
            'ngMockE2E',
            'ngResource'
        ])
        .run(run);
})();

})();
(function(){
'use strict';

/* @ngInject */
MeetingTopicServiceMockConfig.$inject = ['$provide'];
function MeetingTopicServiceMockConfig($provide) {
    $provide.decorator('MeetingTopicService', ['$delegate', '$httpBackend','$window',
        function mock ($delegate, $httpBackend,$window) {
            var mockData = [];
            setMocks();
            $httpBackend.whenGET(/.*meetings\/topics/).respond(200, mockData[$window.COUNTRY]);
            return $delegate;

            /////////////////////////////

            function setMocks() {
                var mockDataDK = {
                    'max_date': '2016-12-18T18:30:00.000+0000',
                    'topics': [
                        {
                            'topic_code': 1,
                            'topic_text': 'Savings'
                        }, {
                            'topic_code': 2,
                            'topic_text': 'Mortgage (Loan & Credit)'
                        }, {
                            'topic_code': 4,
                            'topic_text': 'Insurance'
                        }, {
                            'topic_code': 5,
                            'topic_text': 'Pension'
                        }, {
                            'topic_code': 7,
                            'topic_text': 'Other'
                        }
                    ]
                };
                var mockDataFI = {
                    'max_date': '2016-12-18T18:30:00.000+0000',
                    'topics': [
                        {
                            'topic_code': 1,
                            'topic_text': 'Savings'
                        }, {
                            'topic_code': 2,
                            'topic_text': 'Mortgage'
                        }, {
                            'topic_code': 4,
                            'topic_text': 'Insurance'
                        }, {
                            'topic_code': 6,
                            'topic_text': 'Cards & Consum'
                        }, {
                            'topic_code': 7,
                            'topic_text': 'Other'
                        }
                    ]
                };
                var mockDataNO = {
                    'max_date': '2016-12-18T18:30:00.000+0000',
                    'topics': [
                        {
                            'topic_code': 1,
                            'topic_text': 'Savings'
                        }, {
                            'topic_code': 2,
                            'topic_text': 'Mortgage'
                        }, {
                            'topic_code': 4,
                            'topic_text': 'Insurance'
                        }, {
                            'topic_code': 5,
                            'topic_text': 'Pension'
                        }
                    ]
                };
                var mockDataSE = {
                    'max_date': '2016-12-18T18:30:00.000+0000',
                    'topics': [
                        {
                            'topic_code': 1,
                            'topic_text': 'Savings'
                        }, {
                            'topic_code': 2,
                            'topic_text': 'Mortgage'
                        }, {
                            'topic_code': 4,
                            'topic_text': 'Insurance'
                        }, {
                            'topic_code': 5,
                            'topic_text': 'Pension'
                        }, {
                            'topic_code': 7,
                            'topic_text': 'Other'
                        }
                    ]
                };

                mockData = {'DK': mockDataDK, 'FI': mockDataFI, 'NO': mockDataNO, 'SE': mockDataSE};
            }
        }
    ]);
}
angular.module('dbw-communication.meeting-topic')
    .config(MeetingTopicServiceMockConfig);


})();
(function(){
'use strict';

/* @ngInject */
MeetingDetailsServiceMockConfig.$inject = ['$provide'];
function MeetingDetailsServiceMockConfig($provide) {
    $provide.decorator('MeetingDetailsService', ['$delegate', '$httpBackend',
        function mock ($delegate, $httpBackend) {
            var mockData = [];
            setMocks();
            $httpBackend.whenGET(/.*meetings/).respond(200, mockData);
            return $delegate;

            /////////////////////////////

            function setMocks() {

            }
        }
    ]);
}
angular.module('dbw-communication.meeting-details')
    .config(MeetingDetailsServiceMockConfig);


})();
(function(){
'use strict';
/* eslint angular/component-limit: [0] */
/* eslint angular/no-run-logic: [0] */
angular.module('dbw-communication.mocks', ['dbw-communication', 'ngMockE2E'])
    .config(function () {
        angular.MOCKDATA = {auth: true};
    })
    .run(['$httpBackend', function ($httpBackend) {
        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
        $httpBackend.whenGET(/.*security\/oauth2\/servicetoken/).passThrough();
    }]);

})();
(function(){
/*eslint-env jasmine */
/*global module:false, inject:false */

'use strict';

angular.module('dbw-catalog.mocks', ['dbw-catalog', 'ngMockE2E'])
    .run(['$httpBackend', function($httpBackend) {
        $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
    }]);

})();
//# sourceMappingURL=maps/mocks.js.map