/*
 Copyright 2016 Webtrends Inc. All Rights Reserved.
 WEBTRENDS PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.

 For information on libraries used by the Webtrends Infinity Tag, please see
 the following link: https://producthelp.webtrends.com/data-collection/third-party-libraries/
 */
(function (m, q, P, Q) {
    function K(m, k, q, K) {
        var w = this, t = {
            major: 1,
            minor: 0,
            inc: 1
        }, e = this, E = !1, F = 2E3, A = "undefined" != typeof _wt_forceSSL && _wt_forceSSL ? "https:" : "https:" == document.location.protocol ? "https:" : "http:", L = "sizzle", G = null, H = !1, B = !1, u = !1;
        this.isBodyExtant = function () {
            try {
                return "undefined" != typeof document.getElementsByTagName("body")[0] ? !0 : !1
            } catch (a) {
                return WT.Debug.error("isBodyExtant: body detection fail, assuming false", "002", a), !1
            }
        };
        this.inHead = function () {
            return u
        };
        this.getSelector = function () {
            switch (L) {
                case "sizzle":
                    if (WT.hasVal(Sizzle))return Sizzle;
                    break;
                default:
                    if (null !== G)return G;
                    WT.Debug.error("getSelector:  No Selector found", "003");
                    return null
            }
        };
        this.setCustomSelector = function (a, b) {
            L = a;
            G = b
        };
        this.applyStyleSheet = function (a, b) {
            try {
                var c = k.getElementsByTagName("head")[0], g = k.createElement("style");
                g.type = "text/css";
                g.id = b;
                g.styleSheet ? g.styleSheet.cssText = a : g.appendChild(k.createTextNode(a));
                c.appendChild(g)
            } catch (f) {
                WT.Debug.error("applyStyleSheet:  Failed to failed to apply stylesheet", "004", f)
            }
        };
        this.removeStyleSheet = function (a) {
            try {
                var b =
                    k.getElementById(a);
                "undefined" !== typeof b && null !== b && b.parentNode.removeChild(b)
            } catch (c) {
                WT.Debug.debug("removeStyleSheet:  Failed to remove stylesheet")
            }
        };
        this.redirectElement = function (a, b) {
            b && WT.Debug.debug(b);
            null !== a && a.wt_pending && "true" === a.wt_pending ? (WT.Debug.info("click: redirecting to url [" + a.wt_href + "]"), a.href = a.wt_href, a.target = a.wt_target, a.wt_pending = "", "undefined" !== typeof a.wt_target && "" !== a.wt_target && null !== a.wt_target ? window.open(a.wt_href, a.wt_target) : setTimeout(function () {
                window.location.href =
                    a.wt_href
            }, 0)) : WT.Debug.debug("click: redirect not pending or !elm, so not redirecting")
        };
        this.hasVal = function (a) {
            return null !== a && "undefined" !== typeof a ? !0 : !1
        };
        var s = function () {
            H || (H = !0, WT.fireEvent(new WT.Event(WT.Event.DOM_READY, WT.Event.STATUS_SUCCESS), !0))
        }, C = function () {
            B || (B = !0, WT.fireEvent(new WT.Event(WT.Event.DOM_ONLOAD, WT.Event.STATUS_SUCCESS), !0))
        }, D = function (a) {
            return "undefined" !== typeof p && "undefined" !== typeof d[a].contextName && "undefined" !== typeof p[a] && p[a] === d[a].contextName ? (e.Debug.trace("LOADER:  context '" +
                d[a].contextName + "' triggered for " + a), !0) : "undefined" === typeof p || "undefined" === typeof p[a] ? (e.Debug.trace("LOADER:  published context triggered for " + a), !0) : !1
        }, y = function (a, b) {
            e.fireEvent(new WT.Event(a, WT.Event.STATUS_SUCCESS, null, b), null, null, !0)
        };
        this.collect = function (a) {
            y(WT.Event.LOADER_COLLECT, a);
            return 1
        };
        this.view = function (a) {
            y(WT.Event.LOADER_VIEW, a);
            return 1
        };
        this.click = function (a, b) {
            try {
                var c = 2;
                if ("undefined" !== typeof a && a && "object" == typeof a) {
                    var g, f;
                    a.type ? (g = a, f = a.currentTarget ? a.currentTarget :
                        a.srcElement) : a.tagName && (f = a);
                    g && (g.preventDefault ? g.preventDefault() : g.returnValue = !1);
                    if (f) {
                        if (f.href) {
                            f.wt_pending || (f.wt_pending = "true", f.wt_href = f.href, f.wt_target = f.target, f.href = "javascript:void(0);", f.target = "");
                            b.r_redirectLink = f;
                            var e = b.s_conversionTimeout ? b.s_conversionTimeout : F;
                            setTimeout(function () {
                                WT.Debug.info("Click: timed out after " + e);
                                redirectElement(f)
                            }, e)
                        }
                    } else b = a, c = 1
                }
                Array.prototype.slice.call(arguments, c);
                y(WT.Event.LOADER_CLICK, b)
            } catch (n) {
                "object" == typeof a && a.href && b.r_redirectLink ===
                a && (a.href = a.wt_href, a.target = a.wt_target), WT.Debug.error("Click: Fatal error, check error message for details.", "005", n)
            }
        };
        this.reset = function () {
            y(WT.Event.LOADER_RESET, null)
        };
        this.execute = function (a) {
            Array.prototype.slice.call(arguments, 1);
            y(WT.Event.LOADER_EXECUTE, a)
        };
        this.loaderConversionTimeoutDefault = function () {
            return F
        };
        this.setLoaderConversionTimeoutDefault = function (a) {
            F = a
        };
        this.startTimer = function (a, b) {
            WT.hasVal(d[a]) && (e.Debug.trace("LOADER:  api starting timer for " + b + " ms on " + a), WT.hasVal(b) ?
                d[a]._startTimer(b) : d[a]._startTimer(1E4))
        };
        this.clearTimer = function (a) {
            d[a] && (e.Debug.trace("LOADER:  loader clearing timer for " + a), d[a]._clearTimer(), e.fireEvent(new WT.Event(a + "_" + WT.Event.TIMER_CLEAR, WT.Event.STATUS_SUCCESS)))
        };
        this.pollForCondition = function (a, b, c) {
            var g = function (a, b, c, d) {
                setTimeout(function () {
                    d--;
                    a() ? (e.Debug.trace("pollForCondition success result\x3d" + a(), "LOADER"), e.Debug.superfine("pollForCondition success condition\x3d" + a.toString(), "LOADER"), b && (b(), e.Debug.trace("pollForCondition running callback",
                        "LOADER"), e.Debug.superfine("pollForCondition callback\x3d" + b.toString(), "LOADER"))) : 0 < d ? g(a, b, c, d) : (e.Debug.error("pollForCondition Fail on " + a.toString(), "009"), c && (c(), e.Debug.superfine("pollForCondition callbackFailure\x3d" + c.toString(), "LOADER")))
                }, e.s_pollInterval)
            };
            g(a, b, c, 100)
        };
        this.paramsMerge = function (a, b, c) {
            var g = {};
            if (WT.hasVal(a))for (var f in a)a.hasOwnProperty(f) && (g[f] = a[f]);
            for (var e in b)WT.hasVal(b[e]) && b.hasOwnProperty(e) && (WT.hasVal(c) && WT.hasVal(c[e]) ? g[e] = c[e] : g[e] = b[e]);
            return g
        };
        this.downloadLib = function (a, b, c, g, f, d) {
            e.Debug.info("LOADER:  Start download: " + A + d + " \x26 attach to " + a + ", async\x3d" + f);
            setTimeout(function () {
                var g = k.getElementsByTagName(a)[0], h = k.createElement("script");
                h.type = "text/javascript";
                h.src = A + d;
                h.setAttribute("async", f);
                h.setAttribute("defer", f);
                h.wtHasRun = !1;
                var l = function () {
                    !1 === this.wtHasRun ? (b(), this.wtHasRun = !0, e.Debug.info("Completed download: " + A + d + ", callback running, set wtHasRun\x3d" + this.wtHasRun, "LOADER"), e.Debug.superfine("downloadLib: successCallback\x3d" +
                        b.toString(), "LOADER")) : e.Debug.trace("downloadLib: not running successCallback, since wtHasRun\x3d" + this.wtHasRun, "LOADER")
                };
                b && (h.onload = l, h.onreadystatechange = l);
                h.onerror = function () {
                    e.Debug.error("FAILED download: " + A + d + " \x26 attach to " + a + ", async\x3d" + f, "010");
                    c && (c(), e.Debug.superfine("failCallback: " + c.toString(), "LOADER"))
                };
                typeof("undefined" !== g) ? g.appendChild(h) : e.Debug.info("LOADER:  Dom element: " + a + " is not found so not Downloading")
            }, g)
        };
        this.downloadLibs = function (a, b, c, g, f) {
            if ("undefined" === typeof f)e.Debug.info("LOADER:  downloadLibs srcs is empty"); else {
                var d = {}, n;
                for (n in f)f.hasOwnProperty(n) && (d[n] = "waiting", e.Debug.trace("LOADER:  downloadLibs is waiting on src:" + n + " \x3d " + f[n]), e.downloadLib(a, function (a) {
                    return function () {
                        d[a] = "complete";
                        e.Debug.trace("LOADER:  downloadLibs is complete src:" + a + " \x3d " + f[a])
                    }
                }(n), null, c, g, f[n]));
                e.pollForCondition(function () {
                    for (var a in d)if (d.hasOwnProperty(a) && "complete" !== d[a])return !1;
                    return !0
                }, function () {
                    e.Debug.debug("LOADER:  downloadLibs completed on all downloads");
                    b()
                })
            }
        };
        this.parseQueryString = function (a) {
            var b = a;
            e.hasVal(a) && e.hasVal(a.location) && e.hasVal(a.location.search) || (b = document);
            if (b.location.search) {
                b = b.location.search.substring(1, b.location.search.length);
                a = b.split("\x26");
                null !== a && 0 === a.length && (a = b.split(";"));
                for (var b = a.length - 1, c = {}, g = 0; g <= b; g++) {
                    var f = a[g].split("\x3d");
                    f[0] = unescape(f[0]);
                    f[1] = unescape(f[1]);
                    f[0] = f[0].replace(/\+/g, " ");
                    f[1] = f[1].replace(/\+/g, " ");
                    f[1] = f[1].replace(/<.*\?>/g, "");
                    c[f[0]] = f[1]
                }
                return c
            }
            return null
        };
        this.abortModuleHelper =
            function (a, b) {
                WT.fireEvent(new WT.Event(a + "_" + WT.Event.LOADER_MODULE_ABORT, WT.Event.STATUS_SUCCESS));
                WT.setExecuteState(a, WT.Event.LOADER_MODULE_ABORT);
                WT.clearTimer(a);
                WT.Debug.error("Aborting product: " + a, "011");
                WT.Debug.error("LOADER Error", "011", b)
            };
        this.Event = function (a, b, c, g) {
            a && (a = a.toLowerCase());
            this.name = a;
            this.handler = null;
            this.state = WT.Event.STATUS_UNKNOWN;
            b && (this.state = b);
            this.target = c;
            this.params = {};
            g && (this.params = g)
        };
        this.EventEngineClass = function () {
            var a = {}, b = {}, c = function (a, b, c,
                                              d) {
                E && !d && e.Debug.error("fireEvent: Loader global abort, Aborted due to prior error, check error message for details.", "012", null, "LOADER");
                b.handler = a;
                b.params.eventID = (new Date).getTime();
                e.Debug.trace("fireEvent: [name: " + b.name + "], state:" + b.state + ("undefined" !== typeof c ? ", async[" + c + "]" : ", async not set"), "LOADER");
                e.Debug.superfine("function:" + b.handler.toString() + "]", "LOADER");
                c ? setTimeout(function (a, b) {
                    return function () {
                        a(b)
                    }
                }(a, b), 0) : b.handler(b);
                return 1
            };
            a.addEventHandler = function (a, f,
                                          d, n) {
                if (!a || !f && !d)return e.Debug.debug("events: Can not add event handler, missing name or listeners. ", "LOADER"), -1;
                a = a.toLowerCase();
                b[a] || (b[a] = {});
                b[a].success || (b[a].success = []);
                b[a].fault || (b[a].fault = []);
                var h = !1;
                if (f) {
                    for (var h = !1, l = 0; l < b[a].success.length; l++)if (e.hasVal(b[a].success[l]) && b[a].success[l].toString() === f.toString() && !0 !== n) {
                        h = !0;
                        break
                    }
                    h || (b[a].success.push(f), e.Debug.superfine("addEventHandler success handler" + b[a].success.length + " for " + a + "\nhandler\x3d" + f.toString(), "LOADER"))
                }
                var k =
                    h ? 0 : 1;
                if (d) {
                    h = !1;
                    for (l = 0; l < b[a].fault.length; l++)if (e.hasVal(b[a].fault[l]) && b[a].fault[l].toString() === d.toString() && !0 !== n) {
                        h = !0;
                        break
                    }
                    h || (b[a].fault.push(d), e.Debug.superfine("addEventHandler fault handler" + b[a].fault.length + " for " + a + "\nhandler\x3d" + f.toString(), "LOADER"))
                }
                k += h ? 0 : 1;
                if (b[a].queue && 0 !== b[a].queue.length)for (l = b[a].queue.length - 1; 0 <= l; l--)n = b[a].queue[l], f && "success" === n.event.state ? c(f, n.event, n.async, n.override) : d && "fault" === n.event.state && c(d, n.event, n.async, n.override), b[a].queue.splice(l,
                    1);
                return k
            };
            a.removeEventHandler = function (a, f, c) {
                if (!a)return e.Debug.trace("LOADER removeEventHandler:  events: Can not remove event handler, missing name."), -1;
                a = a.toLowerCase();
                if (!b[a])return 0;
                if (!f && !c)return delete b[a], 0;
                var d = 0;
                if (f)for (var h = 0; h < b[a].success.length; h++)if (e.hasVal(b[a].success[h]) && b[a].success[h].toString() == f.toString()) {
                    b[a].success.splice(h, 1);
                    d = 1;
                    break
                }
                if (c)for (f = 0; f < b[a].fault.length; f++)if (e.hasVal(b[a].fault[f]) && b[a].fault[f].toString() == c.toString()) {
                    b[a].fault.splice(h,
                        1);
                    d++;
                    break
                }
                return d
            };
            a.fireEvent = function (a, f, d, n) {
                if (E && !d)return e.Debug.error("fireEvent: Loader global abort, Aborted due to prior error, check error message for details.", "012", null, "LOADER"), a.name ? e.Debug.error("fireEvent(event\x3d'" + a.name + "'): g_loaderAborted due to prior error, check error message for details.", "012", null, "LOADER") : e.Debug.error("fireEvent: Aborted due to prior error, check error message for details.", "012"), -1;
                var h = a.name, l = a.state, k = b[h] ? !0 : !1, m = k && b[h][l] ? !0 : !1, q =
                    k && b[h].queue ? !0 : !1;
                if (m && 0 !== b[h][l].length || !n) {
                    if (!k)return e.Debug.trace("fireEvent: [name: " + h + "], no registered event was found", "LOADER"), -1;
                    if (!m)return e.Debug.trace("fireEvent: [name:" + h + ", state:" + l + "] no event handler was found", "LOADER"), -1
                } else return e.Debug.trace("fireEvent: [name: " + h + "], no registered event was found, enqueueing", "LOADER"), k || (b[h] = {}), q || (b[h].queue = []), b[h].queue.push({
                    event: a,
                    async: f,
                    override: d
                }), 0;
                n = b[h][l];
                for (m = k = 0; m < n.length; m++)if (n[m])try {
                    c(n[m], a, f, d),
                        k++
                } catch (p) {
                    e.Debug.error("Unhandled Event Exception, [name: " + h + ", state: " + l + ", function: " + a.handler.toString() + "]", "013", p)
                }
                return k
            };
            a.getEventHandlers = function () {
                return b
            };
            a.length = function () {
                var a = 0, c;
                for (c in b)b.hasOwnProperty(c) && a++;
                return a
            };
            a.addFireOnce = function (b, c, d) {
                var e = function () {
                    c();
                    a.removeEventHandler(b, e, d)
                };
                a.addEventHandler(b, e, d)
            };
            return a
        };
        q = new this.EventEngineClass;
        this.addEventHandler = q.addEventHandler;
        this.removeEventHandler = q.removeEventHandler;
        this.fireEvent = q.fireEvent;
        this.addFireOnce = q.addFireOnce;
        this.Event.PREINIT = "preinit";
        this.Event.INIT = "init";
        this.Event.PRELOAD = "preload";
        this.Event.LOAD = "load";
        this.Event.POSTLOAD = "postload";
        this.Event.LOADER_ABORT = "loader_abort";
        this.Event.LOADER_MODULE_ABORT = "loader_module_abort";
        this.Event.LOADER_CLICK = "loader_click";
        this.Event.LOADER_EXECUTE = "loader_execute";
        this.Event.LOADER_RESET = "loader_reset";
        this.Event.LOADER_COLLECT = "loader_collect";
        this.Event.LOADER_VIEW = "loader_view";
        this.Event.DEBUGGER_CLEAR_COOKIES = "debugger_clear_cookies";
        this.Event.DEBUGGER_DUMP_PARAMS = "debugger_dump_params";
        this.Event.DEBUG_ERROR_OUT = "debug_error_out";
        this.Event.DOM_READY = "dom_ready";
        this.Event.DOM_ONLOAD = "dom_onload";
        this.Event.TIMER_EXPIRE = "timer_expire";
        this.Event.TIMER_CLEAR = "timer_clear";
        this.Event.STATUS_SUCCESS = "success";
        this.Event.STATUS_FAULT = "fault";
        this.Event.STATUS_UNKNOWN = "unknown";
        this.Event.OPT_LOAD_COMPLETE = "opt_load_complete";
        this.Event.HIDESHOW = "hide_show";
        this.Event.OPT_COMPLETE = "opt_complete";
        this.Event.PAGEVIEW = "pageview";
        this.Event.CONVERSION =
            "conversion";
        this.Event.DEBUGGER_CHECK_MODE = "debugger_check_mode";
        this.Event.ANA_LOAD_COMPLETE = "ana_load_complete";
        this.Event.ANA_PLUGINS_LOADED = "ana_plugins_loaded";
        this.Event.ANA_PLUGINS_INIT = "ana_plugins_init";
        this.Event.ANA_BEFORE_PAGE_ANALYSIS = "ana_before_page_analysis";
        this.Event.ANA_AFTER_PAGE_ANALYSIS = "ana_after_page_analysis";
        this.Event.ANA_BEFORE_GETID = "ana_before_getid";
        this.Event.ANA_AFTER_GETID = "ana_after_getid";
        this.Event.COMMON_LOAD_COMPLETE = "common_load_complete";
        this.Event.COMMON_PLUGINMGR_READY =
            "common_pluginmgr_ready";
        this._Debug = function () {
            var a = -1;
            this._shutdown = !1;
            var b = [], c = this, d = function (c, d, e) {
                e && (d = e + ":  " + d);
                this._shutdown || b.push([c, d]);
                if (this._shutdown)b = []; else if (!(a < c) && "undefined" !== typeof console && console) {
                    e = !0;
                    switch (c) {
                        case 0:
                            console.error && (console.error(d), e = !1);
                            break;
                        case 1:
                            console.warn && (console.warn(d), e = !1);
                            break;
                        case 2:
                            console.info && (console.info(d), e = !1);
                            break;
                        case 3:
                        case 4:
                        case 5:
                            console.log && (console.log(d), e = !1)
                    }
                    !0 === e && console.log && console.log(d)
                }
            };
            c.superfine =
                function (a, b) {
                    d(5, a, b)
                };
            c.trace = function (a, b) {
                d(4, a, b)
            };
            c.debug = function (a, b) {
                d(3, a, b)
            };
            c.warn = function (a, b) {
                d(1, a, b)
            };
            c.info = function (a, b) {
                d(2, a, b)
            };
            c.error = function (a, b, c, e) {
                var l = "";
                c && ("string" === typeof c ? l = "\n" + c : c.toString ? (l = c.toString(), c.stack && (l += ", [stack]: " + c.stack)) : l = "\n" + (c.message ? c.message : "") + (c.name ? " [" + c.name + "]" : "") + (c.fileName ? "\n (" + c.fileName + ":" + c.lineNumber + ")\n" + c.stack : ""));
                d(0, (b ? b + ": " : "") + a + l, e);
                WT.fireEvent(new WT.Event(WT.Event.DEBUG_ERROR_OUT, WT.Event.STATUS_SUCCESS,
                    c))
            };
            c.dir = function (a, b, e) {
                b && d(2, b, e);
                console && "function" === typeof console.dir ? console.dir(a) : c.dirStr(a)
            };
            c.dirStr = function (a, b) {
                a = a || {};
                b = b || "";
                for (var d in a)a.hasOwnProperty(d) && "function" !== typeof a[d] && c.debug("\t" + d + " : " + a[d], b)
            };
            c.setDebugLevel = function (b) {
                a = b
            };
            c.getDebugLevel = function () {
                return a
            };
            c.clearCookies = function () {
                WT.fireEvent(new WT.Event(WT.Event.DEBUGGER_CLEAR_COOKIES, WT.Event.STATUS_SUCCESS))
            };
            c.dumpParams = function () {
                var a = c.getConfigParams();
                a.loader && c.dir(a.loader, "Config parameters",
                    "Loader");
                a.analytics && c.dir(a.analytics, "Config parameters", "Analytics");
                a.optimize && c.dir(a.optimize, "Config parameters", "Optimize");
                return a
            };
            c.getConfigParams = function () {
                var a = {loader: null, optimize: null, analytics: null};
                a.loader = {version: t, versionStr: [t.major, t.minor, t.inc].join(".")};
                w.analytics && (a.analytics = w.analytics.getConfigParams && w.analytics.getConfigParams());
                w.optimize && (a.optimize = w.optimize.getParams && w.optimize.getParams());
                return a
            };
            c.checkMode = function (a) {
                WT.fireEvent(new WT.Event(WT.Event.DEBUGGER_CHECK_MODE,
                    WT.Event.STATUS_SUCCESS, {resetFlag: a}))
            };
            c.getHistory = function () {
                return b
            }
        };
        var M = function (a, b) {
            this._name = a;
            this._state = b;
            this._met = !1
        }, r = function (a, b, c) {
            this.prodId = a;
            this.plugin = new b;
            this.executeState = r.WAITING;
            this.setRunningFlag = !1;
            this.stopTime = this.startTime = this.timer = null;
            this.contextName = "default";
            "undefined" !== typeof c && (this.contextName = c);
            var g = this, f = {}, k = [];
            this.putDependency = function (a) {
                f[a._name] = a
            };
            this.clearDependencies = function () {
                f = {}
            };
            this.getDependency = function (a) {
                for (var b in f)if (f.hasOwnProperty(b) &&
                    f[b]._name === a)return f[b];
                return null
            };
            this.getDependents = function () {
                0 == k.length && (k = WT.getDependents(g.prodId));
                return k
            };
            this.updateDependents = function () {
                k = WT.getDependents(g.prodId)
            };
            this.getExecuteState = function () {
                return this.executeState
            };
            this.hasMetDeps = function () {
                for (var a in f)if (f.hasOwnProperty(a) && "" !== a && !0 !== f[a]._met)if (d[a].getExecuteState() === f[a]._state)f[a]._met = !0; else return !1;
                return !0
            };
            this.updateDependencyState = function (a, b) {
                var c = g.getDependency(a);
                null !== c && c._state === b &&
                (c._met = !0)
            };
            this._startTimer = function (a) {
                this.timer ? e.Debug.info("LOADER:  " + this.prodId + " timer already started, using current timer.") : (e.Debug.debug("LOADER:  starting timer for " + g.prodId), this.timer = setTimeout(function () {
                    e.Debug.error("LOADER:  " + g.prodId + "module timer expired calling Abort", "015");
                    e.fireEvent(new WT.Event(g.prodId + "_" + WT.Event.TIMER_EXPIRE, WT.Event.STATUS_SUCCESS));
                    e.fireEvent(new WT.Event(g.prodId + "_" + WT.Event.LOADER_MODULE_ABORT, WT.Event.STATUS_SUCCESS))
                }, a), this.startTime =
                    new Date, e.Debug.info("LOADER:  " + this.prodId + " timer started [" + this.startTime + "]."))
            };
            this._clearTimer = function () {
                this.stopTime = new Date;
                this.timer && (clearTimeout(this.timer), this.timer = null);
                e.Debug.info("LOADER:  " + this.prodId + " timer cleared [" + this.stopTime + "]")
            };
            this.tryExecPostload = function () {
                var a = g.getExecuteState() === r.READY, b = g.hasMetDeps(), c = "undefined" !== typeof g.plugin[WT.Event.POSTLOAD];
                if (b && a && c)return e.Debug.debug("setExecuteState:  '" + g.prodId + "' has met all dependencies \x26\x26 ready, running postload"),
                    g.plugin[WT.Event.POSTLOAD](), !0;
                if (b && a && !c)return WT.Debug.superfine(g.prodId + ", has no postLoad section"), !0;
                WT.Debug.superfine(g.prodId + ", did not meet postload exec conditionals");
                return !1
            }
        };
        r.WAITING = "waiting";
        r.DOWNLOADING = "downloading";
        r.READY = "ready";
        r.RUNNING = "running";
        r.ABORTED = "aborted";
        var d = {};
        this.registerPlugin = function (a, b) {
            d[a.ProductName] = new r(a.ProductName, a, b);
            d[a.ProductName].executeState = r.WAITING;
            WT.hasVal(a.prototype.abort) && WT.addEventHandler(a.ProductName + "_" + WT.Event.LOADER_MODULE_ABORT,
                a.prototype.abort);
            if (WT.hasVal(a.prototype.wtConfigObj.s_dependencies))for (var c = a.prototype.wtConfigObj.s_dependencies.split(","), e = 0; e < c.length; e++) {
                var f = [], f = c[e].split(":");
                d[a.ProductName].putDependency(new M(f[0], f[1]))
            }
            for (var k in d)d.hasOwnProperty(k) && d[k].updateDependents();
            a.prototype && a.prototype.wtConfigObj && a.prototype.wtConfigObj.s_useTrackingPipeline && !0 === a.prototype.wtConfigObj.s_useTrackingPipeline && (d[a.ProductName].useTrackingPipeline = !0, d[a.ProductName].s_TrackingPipelineTimeout &&
            (d[a.ProductName].TrackingPipelineTimeout = d[a.ProductName].s_TrackingPipelineTimeout))
        };
        this.clearPlugins = function () {
            d = {}
        };
        this.hasMetDeps = function (a) {
            return d[a].hasMetDeps()
        };
        this.getDependents = function (a) {
            var b = [], c;
            for (c in d)d.hasOwnProperty(c) && null !== d[c].getDependency(a) && b.push(c);
            return b
        };
        this.updateDependencies = function (a, b) {
            if (!a || !d[a])return null;
            if (!b)return d[a].clearDependencies(), null;
            var c = b.split(",");
            if (!c || 0 == c.length)return null;
            d[a].clearDependencies();
            for (var e = 0; e < c.length; e++)if (nameToState =
                    c[e].split(":"), 2 === nameToState.length)d[a].putDependency(new M(nameToState[0], nameToState[1])); else return null
        };
        var N = function (a) {
            var b = d[a];
            if (b.tryExecPostload()) {
                b.executeState = "running";
                a = b.getDependents(a);
                for (var c in a)a.hasOwnProperty(c) && N(a[c])
            }
        };
        this.setExecuteState = function (a, b) {
            if (b === WT.Event.LOADER_MODULE_ABORT)d[a].executeState = r.ABORTED; else if (e.getExecuteState(a) !== WT.Event.LOADER_MODULE_ABORT) {
                d[a].executeState = b;
                e.Debug.trace("setExecuteState:  '" + a + "' to '" + b + "'");
                var c = d[a].getDependents(),
                    g;
                for (g in c)c.hasOwnProperty(g) && d.hasOwnProperty(c[g]) && d[c[g]].updateDependencyState(a, b);
                N(a)
            }
        };
        this.getExecuteState = function (a) {
            return WT.hasVal(d[a]) ? d[a].executeState === r.ABORTED ? WT.Event.LOADER_MODULE_ABORT : d[a].executeState : null
        };
        this.isDependency = function (a) {
            for (var b in d)if (d.hasOwnProperty(b) && null !== d[b].getDependency(a))return e.Debug.trace("isDependency:  '" + a + "' is dependency of '" + b + "'"), !0;
            e.Debug.trace("isDependency:  '" + a + "' is not a dependency of any product");
            return !1
        };
        this.getTrackingPipelineProducts =
            function () {
                var a = [], b;
                for (b in d)if (d.hasOwnProperty(b)) {
                    var c = d[b], e = (c.plugin.wtConfigObj || {}).s_TrackingPipelineTimeout;
                    !0 === c.useTrackingPipeline && a.push({name: b, timeout: e})
                }
                return a
            };
        this.getContextUrl = function (a, b) {
            return "//c.webtrends.com/acs/account/m0t0a3fvxx/js/" + a + "-" + b + ".js"
        };
        this.getProduct = function (a) {
            for (var b in d)if (d.hasOwnProperty(b) && a == d[b].prodId)return d[b];
            return null
        };
        this.isReady = function () {
            return H
        };
        this.isLoaded = function () {
            return B
        };
        this.addDOMEvent = function (a, b, c) {
            try {
                return a.addEventListener ?
                    a.addEventListener(b, c, !1) : a.attachEvent ? a.attachEvent(b, c) : eval("elm." + b + "\x3dfunc;"), 0
            } catch (d) {
                return -1
            }
        };
        this.removeDOMEvent = function (a, b, c) {
            try {
                return a.removeEventListener ? a.removeEventListener(b, c, !1) : a.detachEvent && a.detachEvent(b, c), 0
            } catch (d) {
                return -1
            }
        };
        this.getSafeEventName = function (a, b) {
            var c = b.substr(0, 2);
            if (a.addEventListener) {
                if ("on" === c)return b.substring(2)
            } else if (a.attachEvent && "on" !== c)return "on" + b;
            return b
        };
        this.regPlugin = function (a, b, c) {
            var d = function () {
                WT.Debug.debug("regPlugin - call of deferred register of " +
                    a, "LOADER");
                WT.common.pluginMgr.regPlugin(a, b, c)
            };
            WT.common && WT.common.pluginMgr && WT.common.pluginMgr.isReady && !0 === WT.common.pluginMgr.isReady() ? (WT.Debug.debug("WT.common.pluginMgr exists so register is possible"), d()) : (WT.Debug.debug("regPlugin - deferred register of " + a, "LOADER"), WT.addEventHandler(WT.Event.COMMON_PLUGINMGR_READY, d, null, !0))
        };
        var v = [];
        this.delaySetup = function (a) {
            a.timer = setTimeout(function () {
                WT.Debug.warn(a.prod + ": setup delay timeout after " + a.timeout + "ms");
                a.callback();
                for (var b =
                    0, c = v.length; b < c; b++)if (v[b].callback === a.callback) {
                    v.splice(b, 1);
                    break
                }
            }, a.timeout);
            v.push(a)
        };
        this.resumeSetup = function () {
            for (var a = 0, b = v.length; a < b; a++) {
                var c = v[a];
                "function" === typeof c.callback && c.callback();
                c.timer && clearTimeout(c.timer)
            }
            v = []
        };
        this.hideAndShow = function (a, b, c, d) {
            try {
                if ((WT.hasVal(a) || "shift" == b || u) && WT.hasVal(b) && WT.hasVal(c)) {
                    e.Debug.debug("hideAndShow:  " + (u ? "tag 'inHead'" : "tag 'not inHead'") + ", " + (c ? "showing" : "hiding") + " '" + (a && a.nodeName ? a.nodeName : "unnamed elem") + "' with type '" +
                        b + "'");
                    var f = function (a) {
                        c ? WT.removeStyleSheet("wt_StyleSheet") : WT.applyStyleSheet(a, "wt_StyleSheet")
                    };
                    if ("display" == b)u ? f("body{ display: none !important}") : (a.style.display = c ? "" : "none", a == k.body || c || (k.body.style.display = "")); else if ("visibility" == b)u ? f("body{ visibility: hidden !important}") : (a.style.visibility = c ? "visible" : "hidden", a.style.hidden = !c, a == k.body || c || (k.body.style.visibility = "visible", k.body.style.hidden = !1)); else if ("shift" == b || "supershift" == b)if (!c) {
                        var m = k.getElementsByTagName("head")[0];
                        style = k.createElement("style");
                        style.type = "text/css";
                        style.id = "wt_shiftStyle";
                        style.styleSheet ? style.styleSheet.cssText = "body{position:absolute !important; left: -1000% !important; visibility: hidden}" : style.appendChild(k.createTextNode("body{position:absolute !important; left: -1000% !important;}"));
                        m.appendChild(style)
                    } else {
                        if (c) {
                            var n = k.getElementById("wt_shiftStyle");
                            n && n.parentNode.removeChild(n)
                        }
                    } else if ("overlay" == b) {
                        var h = k.getElementById("wt_overlay"), l = k.getElementById("wt_overlayStyle"),
                            q = e.hasVal(d) ? d : "#ffffff";
                        if (c && h)h.parentNode.removeChild(h), l && l.parentNode.removeChild(l); else if (!c && !h) {
                            u && e.Debug.error("hideAndShow:  Warning! wt tag detected in head, overlay mode may error out or cause flickering", "007");
                            if (!l) {
                                var p = k.createElement("style");
                                p.setAttribute("type", "text/css");
                                p.setAttribute("id", "wt_overlayStyle");
                                f = "#wt_overlay{position:absolute;width:100%;height:100%;top:0px;right:0px;bottom:0px;left:0px;background-color:" + q + ";z-index:2147483646}";
                                p.styleSheet ? p.styleSheet.cssText =
                                    f : p.appendChild(k.createTextNode(f));
                                k.getElementsByTagName("head")[0].appendChild(p)
                            }
                            e.hasVal(d) ? h = k.createElement("div") : (h = k.createElement("iframe"), h.frameBorder = 0);
                            h.id = "wt_overlay";
                            k.getElementsByTagName("body")[0].appendChild(h)
                        }
                    } else"none" == b ? e.Debug.trace("LOADER: type: none") : e.Debug.debug("hideAndShow did not contain a matching type, so not hiding/showing");
                    d = {};
                    d.displayType = b;
                    d.display = c;
                    WT.fireEvent(new WT.Event(WT.Event.HIDESHOW, WT.Event.STATUS_SUCCESS, a, d))
                } else e.Debug.error("hideAndShow param list incomplete",
                    "006")
            } catch (r) {
                WT.Debug.error("Failure in hide/show functionality.  Verify valid HTML syntax", "008", r)
            }
        };
        var O = function () {
            try {
                if (document.addEventListener && ("complete" !== document.readyState && "undefined" !== typeof document.readyState || s(), document.addEventListener("DOMContentLoaded", function () {
                        document.removeEventListener("DOMContentLoaded", arguments.callee, !1);
                        s()
                    }, !1), /WebKit|Opera/i.test(navigator.userAgent)))var a = setInterval(function () {
                    /loaded|complete/.test(document.readyState) && (clearInterval(a),
                        s())
                }, 10);
                document.attachEvent && ("complete" !== document.readyState && "loading" !== document.readyState || s(), document.attachEvent("onreadystatechange", function () {
                    if ("complete" === document.readyState || "loading" === document.readyState)document.detachEvent("onreadystatechange", arguments.callee), s()
                }));
                window.addEventListener ? window.addEventListener("load", function () {
                    window.removeEventListener("load", arguments.callee, !1);
                    s()
                }, !1) : window.attachEvent && window.attachEvent("onload", function () {
                    window.detachEvent("onload",
                        arguments.callee, !1);
                    s()
                });
                B ? C() : window.addEventListener ? window.addEventListener("load", function () {
                    window.removeEventListener("load", arguments.callee, !1);
                    C()
                }, !1) : window.attachEvent && window.attachEvent("onload", function () {
                    window.detachEvent("onload", arguments.callee, !1);
                    C()
                })
            } catch (b) {
                s(), C()
            }
        };
        e.Debug = new e._Debug;
        u = function () {
            try {
                var a = k.getElementsByTagName("script");
                return "HEAD" == a[a.length - 1].parentNode.nodeName ? !0 : !1
            } catch (b) {
                return WT.Debug.error("inHead: Failed to detect if in head, assuming inHead",
                    "001", b), !0
            }
        }();
        e.isBodyExtant();
        var x = this.parseQueryString(m);
        m = function (a, b) {
            e.hasVal(x[a]) && e.hasVal(b) && b(x[a])
        };
        e.hasVal(x) && (m("_wt.accountRoot", function (a) {
            accountRoot = a
        }), m("_wt.s_jsonUrl", function (a) {
        }), m("_wt.debug", function (a) {
            e.Debug.setDebugLevel(a.length)
        }));
        var I = function (a) {
            var b = {};
            a = a.split(";");
            for (var c in a)if (a.hasOwnProperty(c)) {
                var d = a[c].split(":");
                b[d[0]] = d[1]
            }
            return b
        }, p = function () {
            if (null !== x && x["_wt.context"])return I(x["_wt.context"]);
            var a;
            a:{
                a = document.cookie.split(";");
                for (var b = 0; b < a.length; b++) {
                    var c = [];
                    c[0] = a[b].substring(0, a[b].indexOf("\x3d"));
                    for (c[1] = a[b].substring(a[b].indexOf("\x3d") + 1); " " === c[0].charAt(0);)c[0] = c[0].substring(1, c[0].length);
                    if ("_wt.context" == c[0]) {
                        a = c[1];
                        break a
                    }
                }
                a = null
            }
            if ("undefined" !== typeof a && null !== a)return I(a);
            a:{
                a = document.getElementsByTagName("meta");
                for (b = 0; b < a.length; b++)if ("_wt.context" == a[b].name) {
                    a = a[b].content;
                    break a
                }
                a = null
            }
            if ("undefined" != typeof a && null !== a)return I(a)
        }();
        if ("undefined" !== typeof p) {
            e.Debug.info("LOADER:  Found one or more context(s)");
            for (var J in p)p.hasOwnProperty(J) && e.Debug.trace("LOADER:  triggers have set contextTriggerMap '" + J + "':'" + p[J] + "'")
        }
        var z = function (a) {
            e.Debug.error("Loader Error: " + a, "016")
        };
        e.Debug.info("LOADER:  Version " + [t.major, t.minor, t.inc].join("."));
        this.addEventHandler(this.Event.PREINIT, function () {
            try {
                for (var a in d)d.hasOwnProperty(a) && WT.hasVal(d[a].plugin) && WT.hasVal(d[a].plugin[WT.Event.PREINIT]) && D(a) && WT.getExecuteState(a) !== WT.Event.LOADER_MODULE_ABORT && (e.Debug.trace("LOADER:  product '" + a + "' with context name '" +
                    d[a].contextName + "' _preinit phase start"), d[a].plugin[WT.Event.PREINIT](), e.Debug.trace("LOADER:  product '" + a + "' with context name '" + d[a].contextName + "' _preinit phase complete"))
            } catch (b) {
                WT.abortModuleHelper(a, b)
            }
        }, function () {
            z("preinit fail")
        });
        this.addEventHandler(this.Event.INIT, function () {
            try {
                for (var a in d)d.hasOwnProperty(a) && WT.hasVal(d[a].plugin) && WT.hasVal(d[a].plugin[WT.Event.INIT]) && D(a) && WT.getExecuteState(a) !== WT.Event.LOADER_MODULE_ABORT && (e.Debug.trace("LOADER:  product '" + a + "' with context name '" +
                    d[a].contextName + "' _init phase start"), d[a].plugin[WT.Event.INIT](), e.Debug.trace("LOADER:  product '" + a + "' with context name '" + d[a].contextName + "' _init phase complete"))
            } catch (b) {
                WT.abortModuleHelper(a, b)
            }
        }, function () {
            z("init fail")
        });
        this.addEventHandler(this.Event.PRELOAD, function () {
            try {
                for (var a in d)d.hasOwnProperty(a) && WT.hasVal(d[a].plugin) && WT.hasVal(d[a].plugin[WT.Event.PRELOAD]) && WT.hasVal(d[a].plugin.wtConfigObj) && !0 === d[a].plugin.wtConfigObj.doLoad && D(a) && WT.getExecuteState(a) !== WT.Event.LOADER_MODULE_ABORT &&
                (e.Debug.trace("LOADER:  product '" + a + "' with context name '" + d[a].contextName + "' _preload phase start"), d[a].plugin[WT.Event.PRELOAD](), e.Debug.trace("LOADER:  product '" + a + "' with context name '" + d[a].contextName + "' _preload phase complete"))
            } catch (b) {
                WT.abortModuleHelper(a, b)
            }
        }, function () {
            z("preload fail")
        });
        this.addEventHandler(this.Event.LOAD, function () {
            try {
                for (var a in d)d.hasOwnProperty(a) && WT.hasVal(d[a].plugin) && WT.hasVal(d[a].plugin[WT.Event.LOAD]) && WT.hasVal(d[a].plugin.wtConfigObj) && !0 ===
                d[a].plugin.wtConfigObj.doLoad && D(a) && WT.getExecuteState(a) !== WT.Event.LOADER_MODULE_ABORT && (WT.setExecuteState(a, r.DOWNLOADING), e.Debug.trace("LOADER:  product '" + a + "' with context name '" + d[a].contextName + "' _load phase start"), d[a].plugin[WT.Event.LOAD](function (a) {
                    return function () {
                        WT.Debug.debug(a + " downloaded successfully")
                    }
                }(a)), e.Debug.trace("LOADER:  product '" + a + "' with context name '" + d[a].contextName + "' _load phase complete"))
            } catch (b) {
                WT.abortModuleHelper(a, b)
            }
        }, function () {
            z("load fail")
        });
        this.addEventHandler(this.Event.LOADER_ABORT, function () {
            E = !0;
            e.Debug.error("Loader global abort event", "017");
            try {
                for (var a in d)d.hasOwnProperty(a) && WT.hasVal(d[a].plugin) && !0 === d[a].plugin.wtConfigObj.doLoad && (WT.fireEvent(new WT.Event(a + "_" + WT.Event.LOADER_MODULE_ABORT, WT.Event.STATUS_SUCCESS), !1, !0), WT.setExecuteState(a, WT.Event.LOADER_MODULE_ABORT), WT.clearTimer(a), WT.Debug.error("Aborting product: " + a, "018"))
            } catch (b) {
                WT.abortModuleHelper(a, b)
            }
        }, function () {
            z("abort fail")
        });
        this.start = function () {
            try {
                O();
                var a = function () {
                    e.fireEvent(new WT.Event(WT.Event.PREINIT, WT.Event.STATUS_SUCCESS));
                    e.fireEvent(new WT.Event(WT.Event.INIT, WT.Event.STATUS_SUCCESS));
                    e.fireEvent(new WT.Event(WT.Event.PRELOAD, WT.Event.STATUS_SUCCESS));
                    e.fireEvent(new WT.Event(WT.Event.LOAD, WT.Event.STATUS_SUCCESS));
                    e.Debug.debug("LOADER:  Synchronous functionality has finished firing")
                };
                if (WT.hasVal(p)) {
                    e.Debug.debug("LOADER:  contextTriggerMap contains contexts");
                    var b = [], c;
                    for (c in p)if (p.hasOwnProperty(c)) {
                        var d = e.getContextUrl(c,
                            p[c]);
                        "undefined" !== typeof d && (e.Debug.debug("LOADER:  adding " + d + " to download"), b.push(d))
                    }
                    e.downloadLibs("head", a, 0, !0, b)
                } else a()
            } catch (f) {
                e.fireEvent(new WT.Event(WT.Event.LOADER_ABORT, WT.Event.STATUS_SUCCESS))
            }
        };
        e.Debug.debug("WT object created", "LOADER");
        e.Debug.info("To clear Optimize cookies use: 'WT.Debug.clearCookies()'");
        e.Debug.info("To dump config params use: 'WT.Debug.dumpParams()'");
        e.Debug.info("To check the mode use: 'WT.Debug.checkMode(false)' - Use true if you wish to reset the mode.")
    }

    "undefined" == typeof WT && (WT = new K(window, window.document, window.navigator, window.location))
})(window, window.document, window.navigator, window.location);
WT.sizzleModule = function () {
};
WT.sizzleModule.prototype.wtConfigObj = {libUrl: "/webtrends/sizzle.min.js", doLoad: !0, s_dependencies: ""};
WT.sizzleModule.prototype.load = function (m) {
    try {
        WT.updateDependencies("sizzle", this.wtConfigObj.s_dependencies), "undefined" != typeof Sizzle && WT.hasVal(Sizzle) || !WT.isDependency("sizzle") ? WT.setExecuteState("sizzle", "ready") : WT.downloadLib("head", m, function () {
            WT.abortModuleHelper("sizzle", "failed to download sizzle");
            WT.abortModuleHelper("optimize", "failed to download sizzle")
        }, 0, !0, this.wtConfigObj.libUrl)
    } catch (q) {
        WT.abortModuleHelper("optimize", q)
    }
};
WT.sizzleModule.prototype.postload = function () {
};
WT.sizzleModule.ProductName = "sizzle";
WT.registerPlugin(WT.sizzleModule, "default");
WT.jsonModule = function () {
};
WT.jsonModule.prototype.wtConfigObj = {libUrl: "/webtrends/json2.js", doLoad: !0};
WT.jsonModule.prototype.load = function (m) {
    try {
        WT.updateDependencies("json", this.wtConfigObj.s_dependencies), "undefined" === typeof JSON && WT.isDependency("json") ? (WT.Debug.debug("JSON not detected"), s_jsonLoaded = !1, WT.downloadLib("head", m, function () {
            WT.abortModuleHelper("json", "failed to download json");
            WT.abortModuleHelper("optimize", "failed to download json");
            WT.abortModuleHelper("analytics", "failed to download json")
        }, 0, !0, this.wtConfigObj.libUrl)) : (s_jsonLoaded = !0, WT.setExecuteState("json", "ready"))
    } catch (q) {
        WT.abortModuleHelper("optimize",
            q), WT.abortModuleHelper("analytics", q)
    }
};
WT.jsonModule.prototype.postload = function () {
};
WT.jsonModule.ProductName = "json";
WT.registerPlugin(WT.jsonModule, "default");
WT.commonModule = function () {
};
WT.commonModule.prototype.wtConfigObj = {
    libUrl: "/webtrends/common.js",
    doLoad: !0,
    s_dependencies: "json:running"
};
WT.commonModule.prototype.load = function (m) {
    try {
        !WT.common && WT.isDependency("common") && WT.downloadLib("head", m, function () {
            WT.fireEvent(new WT.Event("common" + WT.Event.LOADER_MODULE_ABORT, WT.Event.STATUS_SUCCESS))
        }, 0, !0, this.wtConfigObj.libUrl)
    } catch (q) {
        WT.abortModuleHelper("common", q)
    }
};
WT.commonModule.prototype.postload = function () {
    WT.common.setup()
};
WT.commonModule.ProductName = "common";
WT.registerPlugin(WT.commonModule, "default");
WT.analyticsModule = function () {
};

var split = document.location.hostname.split('.');
if (split.length > 2) {
    window.TRACKING_DOM = '.' + split[split.length - 2] + '.' + split[split.length - 1]
} else {
    window.TRACKING_DOM = document.location.hostname;
}

WT.analyticsModule.prototype.wtConfigObj = {
    i18n: !0,
    delaySetupTimeout: 4E3,
    enableHybrid: !1,
    alwaysLoad: !1,
    doLoad: !1,
    timezone: 1,
    onsitedoms: window.TRACKING_DOM,
    s_dependencies: "common:running",
    defaultCollectionServer: "statse.webtrendslive.com",
    s_useTrackingPipeline: !0,
    downloadtypes: "xls,doc,pdf,txt,csv,zip,exe,svg,mp3,mpeg,mpg,mp4,avi,swf,docx,xlsx,ppt,pptx,mov,pps,rar",
    libUrl: "/webtrends/analytics.js",
    fpcdom: window.TRACKING_DOM,
    accountGuid: "qip6kzrs4b",
    delaySetup: !1,
    offsite: !0,
    cookieTypes: "all",
    download: !0,
    destinations: [{
        dcsid: window.TRACKING.dcsid,
        collectionServer: "statse.webtrendslive.com"
    }],
    s_TrackingPipelineTimeout: 4E3,
    s_disableHeatMaps: true
};
WT.analyticsModule.prototype.preinit = function () {
};
WT.analyticsModule.prototype.init = function () {
    try {
        this.wtConfigObj.key = "value", this.wtConfigObj.doLoad = !0, this.wtConfigObj.doLoad = this.wtConfigObj.doLoad || this.wtConfigObj.alwaysLoad
    } catch (m) {
        WT.abortModuleHelper("analytics", m)
    }
};
WT.analyticsModule.prototype.preload = function () {
    try {
        var m = 0;
        WT.analyticsModule.prototype.wtConfigObj.s_conversionTimeout && (m = WT.analyticsModule.prototype.wtConfigObj.s_conversionTimeout);
        WT.setLoaderConversionTimeoutDefault(Math.max(m, WT.loaderConversionTimeoutDefault()));
        WT.Debug.debug("PRELOAD:  Executing preload script")
    } catch (q) {
        WT.abortModuleHelper("analytics", q)
    }
};
WT.analyticsModule.prototype.load = function (m) {
    try {
        WT.Debug.debug("LOAD:  Executing load phase"), WT.downloadLib("head", m, function () {
            WT.fireEvent(new WT.Event("analytics_" + WT.Event.LOADER_MODULE_ABORT, WT.Event.STATUS_SUCCESS))
        }, 0, !0, this.wtConfigObj.libUrl)
    } catch (q) {
        WT.abortModuleHelper("analytics", q)
    }
};
WT.analyticsModule.prototype.postload = function () {
    WT.Debug.debug("POSTLOAD:  Executing postload analytics complete");
    try {
        WT.Debug.info("LOADER:  WT.analyticsModule.prototype: postload"), WT.analytics.setup(WT.analyticsModule.prototype.wtConfigObj)
    } catch (m) {
        WT.abortModuleHelper("analytics", m)
    }
};
WT.analyticsModule.prototype.abort = function () {
    try {
        WT.Debug.debug("ABORT:  Executing analyticsModule abort")
    } catch (m) {
        WT.abortModuleHelper("analytics", m)
    }
};
WT.analyticsModule.ProductName = "analytics";
WT.registerPlugin(WT.analyticsModule, "nordeaANA");
WT.start();