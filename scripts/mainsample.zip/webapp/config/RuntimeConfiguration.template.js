'use strict';
/*jshint -W109 */ //Use double quotes in string
angular.module('mainApp')
  .constant('RuntimeConfiguration',
    // The content below will be replaced by the build script according to the
    // json defined in dbw-config.<NODE_ENV>.json
    //START_CONFIG_BLOCK
      {}
    //END_CONFIG_BLOCK
);
