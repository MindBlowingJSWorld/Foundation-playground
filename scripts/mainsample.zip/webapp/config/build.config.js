var joinPath = require('join-path');
var configUtil = require('./config.util');

var appName = 'mainApp';


var paths = {
    main: {
        src: joinPath(__dirname, '..', 'src'),
        index: joinPath(__dirname, '..', 'src/main/**/*.html'),
        templates: joinPath(__dirname, '..', 'src/**/*.tpl.html')
    },
    build: joinPath(__dirname, '../..', 'web'),
    temp: joinPath(__dirname, '../..', 'temp'),
    inject: {
        injectingFilePath: 'webapp/src/config/dbw-config.json',
        injectedFileTemplate: 'webapp/config/RuntimeConfiguration.template.js',
        injectedFilePath: 'webapp/src/main/',
        injectedFileName: 'RuntimeConfiguration.js'
    }
};

var assetsBundle = {
    configPath: joinPath(__dirname, 'bundle.config.js'),
    dest: paths.build,
    results: {
        dest: paths.temp,
        fileName: 'bundle.result',
        filePath: joinPath(paths.temp,'bundle.result.json') // for us, not for gulp-bundle-assets
    }
};

var mockedAssetsBundle = {
    configPath: joinPath(__dirname, 'bundle.config.mocks.js'),
    dest: paths.build,
    results: {
        dest: paths.temp,
        fileName: 'bundle.result.mocks',
        filePath: joinPath(paths.temp,'bundle.result.mocks.json') // for us, not for gulp-bundle-assets
    }
};

// TODO what do we actually have? These need to be coordinated with Crowbar team
var productionLikeEnvironments = ['test', 'dev', 'prod']; //dev, test, prod


module.exports = {
    appName: appName,
    paths: paths,
    assetsBundle: assetsBundle,
    mockedAssetsBundle: mockedAssetsBundle,
    productionLikeEnvironments: productionLikeEnvironments
};