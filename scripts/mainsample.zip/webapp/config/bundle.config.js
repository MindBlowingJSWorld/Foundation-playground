var joinPath = require('join-path');
var buildConfig = require('./build.config');
var configUtil = require('./config.util');
var mainTransforms = require('./main-transforms');
var getModule = configUtil.getModule;

module.exports = {
    bundle: {

        modules: {
            scripts: [
                // Add your app's JS bundle here.
                // The bundle must contain only the application's own "production" code. No mocks, no tests.
                // The bundle must not be minified, otherwise we won't get proper source maps.
                // Order = load order.
                getModule('dbw-core/dist/dbw-core.js'),
                getModule('dbw-common/build/dbw-common.js'),
                getModule('dbw-communication/dist/dbw-communication.js'),
                getModule('dbw-navigation/dist/dbw-navigation.js'),
                getModule('dbw-login/dist/dbw-login.js'),
                getModule('dbw-taskbar/dist/dbw-taskbar.js'),
                getModule('dbw-payments/dist/dbw-payments.js'),
                getModule('dbw-cards/dist/dbw-cards.js'),
                getModule('dbw-savings/dist/dbw-savings.js'),
	    	    getModule('dbw-corporate-liquidity/dist/dbw-corporate-liquidity.js'),
		        getModule('dbw-beneficiaries/dist/dbw-beneficiaries.js'),
                getModule('dbw-messages/dist/dbw-messages.js'),
                getModule('dbw-accounts/dist/dbw-accounts.js'),
                getModule('dbw-profile/dist/dbw-profile.js'),
                getModule('dbw-authsign/dist/dbw-authsign.js'),
                getModule('dbw-loan-credit/dist/dbw-loan-credit.js'),
                getModule('dbw-labels/dist/TranslationLabels.js'),
                getModule('dbw-localization/dist/dbw-localization.js'),
                getModule('dbw-agreement/dist/dbw-agreement.js'),
                getModule('dbw-search/dist/dbw-search.js'),
                getModule('dbw-catalog/dist/dbw-catalog.js')
            ],
            styles: [
                // Add your app's CSS entry file here (if any).
                // CSS files will be included as is.
                // Order matters.
                getModule('dbw-vendor/dist/vendor.css'),
                getModule('dbw-common/build/dbw-common.css'),
                getModule('dbw-communication/dist/dbw-communication.css'),
                getModule('dbw-navigation/dist/dbw-navigation.css'),
                getModule('dbw-login/dist/dbw-login.css'),
                getModule('dbw-taskbar/dist/dbw-taskbar.css'),
                getModule('dbw-payments/dist/dbw-payments.css'),
                getModule('dbw-cards/dist/dbw-cards.css'),
                getModule('dbw-savings/dist/dbw-savings.css'),
                getModule('dbw-corporate-liquidity/dist/dbw-corporate-liquidity.css'),
		        getModule('dbw-beneficiaries/dist/dbw-beneficiaries.css'),
		        getModule('dbw-accounts/dist/dbw-accounts.css'),
                getModule('dbw-profile/dist/dbw-profile.css'),
                getModule('dbw-messages/dist/dbw-messages.css'),
                getModule('dbw-authsign/dist/dbw-authsign.css'),
		        getModule('dbw-loan-credit/dist/dbw-loan-credit.css'),
		        getModule('dbw-search/dist/dbw-search.css'),
                getModule('dbw-catalog/dist/dbw-catalog.css'),
                getModule('dbw-agreement/dist/dbw-agreement.css')
            ],
            options: {
                useMin: buildConfig.productionLikeEnvironments, // use pre-minified files if available (need to be declared as {src: <path>, minSrc: <path>})?
                uglify: buildConfig.productionLikeEnvironments, // minify js?
                minCss: buildConfig.productionLikeEnvironments, // minify CSS?
                rev: false, // file revisioning?
                watch: {
                    scripts: true,
                    styles: true
                },
                transforms: {
                    styles: configUtil.transformStyle
                }
            }
        },

        // Main app bundle -- separated from modules because it requires its own script transforms
        main: {
            scripts: [
                joinPath(buildConfig.paths.main.src, 'main/foundation-init.js'),
                joinPath(buildConfig.paths.main.src, 'main/main.js'),
                joinPath(buildConfig.paths.main.src, 'main/routing.js'),
                joinPath(buildConfig.paths.main.src, 'main/routing-household.js'),
                joinPath(buildConfig.paths.main.src, 'main/routing-corporate.js'),
                joinPath(buildConfig.paths.main.src, 'main/RuntimeConfiguration.js'),
                joinPath(buildConfig.paths.main.src, 'main/accessibility-reset-focus-on-state-change.js'),
                buildConfig.paths.main.templates
            ],
            styles: [
                joinPath(buildConfig.paths.main.src, 'main/main.css'),
            ],
            options: {
                useMin: buildConfig.productionLikeEnvironments,
                uglify: buildConfig.productionLikeEnvironments,
                minCss: buildConfig.productionLikeEnvironments,
                rev: false,
                watch: {
                    scripts: true,
                    styles: true
                },
                transforms: {
                    scripts: mainTransforms.transformScripts,
                    styles: configUtil.transformStyle
                }
            }
        },

        vendor: {
            scripts: [
                // Add vendor libraries here.
                // Order = load order.
                // Remember to update dependencies in package.json.
                {
                    src: getModule('dbw-vendor/dist/vendor.js'),
                    minSrc: getModule('dbw-vendor/dist/vendor.min.js')
                }

            ],
            styles: [
                {
                    src: getModule('dbw-vendor/dist/vendor.css'),
                    minSrc: getModule('dbw-vendor/dist/vendor.min.css')
                }
            ],
            options: {
                useMin: buildConfig.productionLikeEnvironments,
                uglify: buildConfig.productionLikeEnvironments,
                minCss: buildConfig.productionLikeEnvironments,
                rev: false,
                watch: {
                    scripts: false,
                    styles: false
                }
            }
        },

        foundation: {
            scripts: [
                getModule('dbw-common/build/dbw-foundation-nordea.js')
            ],
            styles: [
                getModule('dbw-common/build/dbw-foundation-nordea.css')
            ],
            options: {
                useMin: buildConfig.productionLikeEnvironments,
                uglify: buildConfig.productionLikeEnvironments,
                minCss: buildConfig.productionLikeEnvironments,
                rev: false,
                watch: {
                    scripts: false,
                    styles: true
                },
                transforms: {
                    styles: configUtil.transformStyle
                }
            }
        },
        tracking: {
            scripts: [
                getModule('dbw-core/dist/webtrends/loader.js'),
            ],
            styles: [],
            options: {
                useMin: buildConfig.productionLikeEnvironments,
                uglify: buildConfig.productionLikeEnvironments,
                minCss: buildConfig.productionLikeEnvironments,
                rev: false,
                watch: {
                    scripts: false,
                    styles: false
                },
                transforms: {
                    styles: configUtil.transformStyle
                }
            }
        }
    },

    copy: [
        // Add assets to simply copy. Make sure the what's left after base path is removed matches your templateUrl reference.

        // Note: don't use getModule() here. For some reason Jenkins build fails when copying (maybe somehow related to absolute paths generated by getModule)

        // TODO should these be files revisioned, too?

        // Example
        // You have templateUrl: 'example/stuff/view.html'
        // src matches e.g. ./node_modules/example-app/src/example/stuff/view.html.
        // With given base the file is copied to <build>/example/stuff/view.html.
        {
            src: './node_modules/dbw-common/build/fonts/**/*.*',
            base: './node_modules/dbw-common/build',
            watch: false
        },
        {
            src: './node_modules/dbw-common/build/images/**/*.{gif,png}',
            base: './node_modules/dbw-common/build',
            watch: false
        },
        {
            src: './node_modules/dbw-navigation/dist/**/*.{jpg,svg,png}',
            base: './node_modules/dbw-navigation/dist',
            watch: true
        },
        {
            src: './node_modules/dbw-login/dist/**/*.{jpg,svg,png}',
            base: './node_modules/dbw-login/dist',
            watch: false
        },
        {
            src: './node_modules/dbw-savings/dist/**/*.{jpg,svg,png,gif}',
            base: './node_modules/dbw-savings/dist',
            watch: true
        },
        {
            src: './node_modules/dbw-cards/dist/cards/**/*.{jpg,svg,png,gif}',
            base: './node_modules/dbw-cards/dist',
            watch: true
        },
        {
            src: './node_modules/dbw-core/dist/webtrends/**/*.js',
            base: './node_modules/dbw-core/dist',
            watch: false
        },
        {
            src: './node_modules/dbw-authsign/dist/assets/**/*.{jpg,svg,otf}',
            base: './node_modules/dbw-authsign/dist',
            watch: false
        },
        {
            src: './node_modules/dbw-messages/dist/**/*.{jpg,svg,png,css,woff, woff2}',
            base: './node_modules/dbw-messages/dist',
            watch: true
        },
        {
            src: './node_modules/dbw-communication/dist/**/*.{jpg,svg,png,gif}',
            base: './node_modules/dbw-communication/dist',
            watch: true
        },
        {
            src: './node_modules/dbw-messages/dist/**/*.{pdf}',
            base: './node_modules/dbw-messages/dist',
            watch: true
        },
        {
            src: './node_modules/dbw-loan-credit/dist/**/*.{jpg,svg,png,gif}',
            base: './node_modules/dbw-loan-credit/dist',
            watch: true
        },
        {
            src: './node_modules/dbw-catalog/dist/**/*.{jpg,svg,png}',
            base: './node_modules/dbw-catalog/dist',
            watch: true
        },
        {
            src: './webapp/src/main/favicon.ico',
            base: './webapp/src/main',
            watch: false
        }
    ]
};
