var joinPath = require('join-path');
var buildConfig = require('./build.config');
var configUtil = require('./config.util');
var mainTransforms = require('./main-transforms');
var getModule = configUtil.getModule;

module.exports = {
    bundle: {
        mocks: {
            scripts: [
                // Add your app's mock service JS bundle here.
                // The bundle must contain only the application's own mock service code. No tests, nothing that is needed in production.
                // The bundle must not be minified, otherwise we won't get proper source maps.
                // Order = load order.

                //configUtil.getModule('example-module/dist/mocks/dbw-example.mock.js'),
                configUtil.getModule('dbw-core/dist/mocks/dbw-core.mock.js'),
		        configUtil.getModule('dbw-beneficiaries/dist/mocks/dbw-beneficiaries.mock.js'),
		        configUtil.getModule('dbw-accounts/dist/mocks/dbw-accounts.mock.js'),
		        configUtil.getModule('dbw-payments/dist/mocks/dbw-payments.mock.js'),
                configUtil.getModule('dbw-login/dist/mocks/dbw-login.mock.js'),
                configUtil.getModule('dbw-cards/dist/mocks/dbw-cards.mock.js'),
                configUtil.getModule('dbw-authsign/dist/mocks/dbw-authsign.mock.js'),
                configUtil.getModule('dbw-loan-credit/dist/mocks/dbw-loan-credit.mock.js'),
                configUtil.getModule('dbw-communication/dist/mocks/dbw-communication.mock.js'),
                configUtil.getModule('dbw-catalog/dist/mocks/dbw-catalog.mock.js')
            ],
            options: {
                useMin: buildConfig.productionLikeEnvironments,
                uglify: false,
                minCSS: buildConfig.productionLikeEnvironments,
                rev: buildConfig.productionLikeEnvironments,
                watch: {
                    scripts: true
                }
            }
        },
        mainMocks: {
            scripts: [
                joinPath(buildConfig.paths.main.src, 'main/main.mock.js')
            ],
            styles: [

            ],
            options: {
                useMin: buildConfig.productionLikeEnvironments,
                uglify: buildConfig.productionLikeEnvironments,
                minCSS: buildConfig.productionLikeEnvironments,
                rev: buildConfig.productionLikeEnvironments,
                watch: {
                    scripts: true,
                    styles: true
                },
                transforms: {
                    scripts: mainTransforms.transformScripts,
                    styles: configUtil.transformStyle
                }
            }
        },
        vendorMocks: {
            scripts: [
                // Add vendor mock libraries here.
                // Order = load order.
                // Remember to update dependencies in package.json.
                getModule('angular-mocks/angular-mocks.js')
            ],
            styles: [
            ],
            options: {
                useMin: buildConfig.productionLikeEnvironments,
                uglify: buildConfig.productionLikeEnvironments,
                minCSS: buildConfig.productionLikeEnvironments,
                rev: buildConfig.productionLikeEnvironments,
                watch: {
                    scripts: false,
                    styles: false
                }
            }
        }
    }
};
