var $ = require('gulp-load-plugins')();
var joinPath = require('join-path');
var lazypipe = require('lazypipe');

// Returns a path/pattern prefixed to point to node_modules of this project.
// Independent of the current working directory (as long as this file is not moved).
var getModule = function (globPattern) {
    return joinPath(__dirname, '../..', 'node_modules', globPattern);
};

var isStringEndsWith = function(str, suffix) {
    return str.indexOf(suffix, str.length - suffix.length) !== -1;
};

var isFileSuffix = function(file, suffix) {
    return isStringEndsWith(file.relative, suffix);
};


var transformStyle = lazypipe()
    .pipe(function() {
        return $.autoprefixer({
            browsers: ['last 2 versions', 'ie >= 10', 'and_chr >= 4.4'] // Foundation flexbox requires ie 10 and android chrome >= 4.4
        })
    });

var getNodeEnv = function () {
    return process.env.NODE_ENV || 'undefined';
};

module.exports = {
    getModule: getModule,
    isFileSuffix: isFileSuffix,
    getNodeEnv:getNodeEnv,
    transformStyle: transformStyle
};