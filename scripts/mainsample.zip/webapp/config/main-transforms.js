/** This file defines transforms specific to the main app build */

var $ = require('gulp-load-plugins')();
var lazypipe = require('lazypipe');
var configUtil = require('./config.util');
var buildConfig = require('./build.config');


var isJsFile = function(file) {
    return configUtil.isFileSuffix(file, 'js');
};

var isAngularTemplateFile = function(file) {
    return configUtil.isFileSuffix(file, 'tpl.html');
};

var transformScripts = lazypipe()
    .pipe(function() {
        return $.if(isJsFile, $.iife());
    })
    .pipe(function() {
        return $.if(isJsFile, $.ngAnnotate({ single_quotes: true }));
    })
    .pipe(function() {
        return $.if(isAngularTemplateFile, $.angularTemplatecache({
            module: buildConfig.appName,
            standalone: false,
            moduleSystem: 'IIFE',
            base: buildConfig.paths.main.src
        }));
    });

module.exports = {
    transformScripts: transformScripts
};