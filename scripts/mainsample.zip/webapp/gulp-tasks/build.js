'use strict';

var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
var runSequence = require('run-sequence');
var _ = require('lodash');

var buildConfig = require('../config/build.config.js');
var assetsBundle = buildConfig.assetsBundle;
var mockedAssetsBundle = buildConfig.mockedAssetsBundle;
var paths = buildConfig.paths;
var joinPath = require('join-path');
var configUtil = require('../config/config.util');
var getNodeEnv = configUtil.getNodeEnv;

gulp.task('clean', function () {
    return gulp.src([paths.build, paths.temp], {read: false}).pipe($.clean());
});

gulp.task('noop', []);

gulp.task('build-all', function (cb) {
    process.env.bundleFor = 'all';
    runSequence(
        'clean',
        'install',
        //
        'env-dev',
        'inject-config',
        'bundle',
        'render-html',
        //
        'env-test',
        'inject-config',
        'bundle',
        'render-html',
        //
        //'env-prod',
        //'inject-config',
        //'bundle',
        //'render-html',
        cb
    )
    ;
});

var changeEnv = function (env) {
    process.env.NODE_ENV = env;
};

gulp.task('env-test', function () {
    changeEnv('test');
});
gulp.task('env-dev', function () {
    changeEnv('dev');
});
gulp.task('env-prod', function () {
    changeEnv('prod');
});

gulp.task('build', function (cb) {
    runSequence([
            process.env.bundleFor === 'all' ? 'noop' : 'clean',
            'install',
            'inject-config'
        ],
        'bundle',
        'render-html',
        cb);
});

gulp.task('build-mocks', function (cb) {
    runSequence([
            'clean',
            'install',
            'inject-config'
        ], [
            'bundle',
            'bundle-mocks'
        ],
        'render-html',
        cb);
});

gulp.task('build-no-install', function (cb) {
    runSequence('clean', 'bundle', 'render-html', cb);
});

gulp.task('build-mocks-no-install', function (cb) {
    runSequence('clean', ['bundle', 'bundle-mocks'], 'render-html', cb);
});

var bundleAsset = function (srcs_path, results_config) {
    var buildPath = paths.build;
    var bundleAssetStream = gulp.src(srcs_path)
        .pipe($.bundleAssets())
        .pipe($.bundleAssets.results(results_config));

    if (process.env.bundleFor === 'all') {
        return bundleAssetStream.pipe(gulp.dest(joinPath(buildPath, getNodeEnv())));
    } else {
        return bundleAssetStream.pipe(gulp.dest(buildPath));
    }
};

gulp.task('bundle', function () {
    assetsBundle.results.dest = joinPath(paths.temp, getNodeEnv());
    return bundleAsset(assetsBundle.configPath, assetsBundle.results);
});

gulp.task('bundle-mocks', function () {
    mockedAssetsBundle.results.dest = joinPath(paths.temp, getNodeEnv());
    return bundleAsset(mockedAssetsBundle.configPath, mockedAssetsBundle.results);
});

gulp.task('watch', function () {
    $.bundleAssets.watch(assetsBundle);
    gulp.watch(paths.main.index, ['render-html']);
});

gulp.task('watch-mocks', function () {
    $.bundleAssets.watch(mockedAssetsBundle);
});

gulp.task('render-html', function () {
    var temp = paths.temp;
    $.nunjucksRender.nunjucks.configure([paths.main.src], {autoescape: false, watch: false});

    var assetsBundleFilePath = joinPath(temp, getNodeEnv(), assetsBundle.results.fileName + '.json');
    var mockedAssetsBundleFilePath = joinPath(temp, getNodeEnv(), mockedAssetsBundle.results.fileName + '.json');

    var renderHtmlStream = gulp.src([paths.main.index, '!' + paths.main.templates])
        .pipe($.data(function (file) {
            var bundleResultsApp = require(assetsBundleFilePath);
            var bundleResultsMock;
            try {
                bundleResultsMock = require(mockedAssetsBundleFilePath);
            } catch (e) {
                bundleResultsMock = {};
            }
            return _.extend({}, bundleResultsApp, bundleResultsMock);
        }))
        .pipe($.nunjucksRender());

    if (process.env.bundleFor === 'all') {
        return renderHtmlStream.pipe(gulp.dest(joinPath(paths.build, getNodeEnv())));
    } else {
        return renderHtmlStream.pipe(gulp.dest(paths.build));
    }

});
