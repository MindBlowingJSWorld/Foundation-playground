'use strict';

var gulp = require('gulp');
var argv = require('yargs').argv;
var fs = require('fs');
var replace = require('gulp-replace');
var path = require('path');
var rename = require('gulp-rename');
var runsequence = require('run-sequence');

var paths = require('../config/build.config.js').paths;

/*
 Takes the contents in dbw-config.<NODE_ENV>.json and injects them into
 the RuntimeConfiguration.template.js to be used as a constant.
 */

var replaceSection = /\/\/START_CONFIG_BLOCK([\s\S]*?)\/\/END_CONFIG_BLOCK/g;

gulp.task('inject-config', function(cb) {
   runsequence('copy-runtimeconfig-template', 'inject-config-data', cb);
});

gulp.task('copy-runtimeconfig-template', function() {
    return gulp.src(paths.inject.injectedFileTemplate).pipe(rename(paths.inject.injectedFileName)).pipe(gulp.dest(paths.inject.injectedFilePath));
});

gulp.task('inject-config-data', function () {
    // These logic checks to see whether injectingFilePath together with your chosen environment variable form an exist file pahth
    var defaultEnv = 'local';
    var currentEnv = process.env.NODE_ENV || argv.env || defaultEnv;
    var _injectingFilePath = path.dirname(paths.inject.injectingFilePath) + '/' + path.basename(paths.inject.injectingFilePath).replace('.', '.' + currentEnv + '.');
    var injectNewContent = function (tobeReplacedContent) {
        var newContent = tobeReplacedContent.split('\n');
        newContent[1] = JSON.stringify(JSON.parse(fs.readFileSync(_injectingFilePath)));
        return newContent.join('\n');
    };

    if (!fs.existsSync(_injectingFilePath)) {
        console.log('Config for [' + currentEnv + '] not found. Using ' + defaultEnv);
        _injectingFilePath = paths.inject.injectingFilePath;
    }

    return gulp.src(paths.inject.injectedFilePath + paths.inject.injectedFileName)
        .pipe(replace(replaceSection, injectNewContent))
        .pipe(gulp.dest(path.dirname(paths.inject.injectedFilePath + paths.inject.injectedFileName)));
});
