'use strict';

var gulp = require('gulp');
var protractor = require('gulp-protractor').protractor;
var argv = require('yargs').argv;
var preprocess = require('gulp-preprocess');

// Setting up the test task
gulp.task('protractor', [], function (cb) {
    var specs = argv.specs ? argv.specs : 'webapp/test/features/features_ui/*.feature';
    var tags = argv.tags ? argv.tags : '';

    gulp.src('webapp/config/protractor.conf.js')
        .pipe(preprocess({context: { TAGS: tags}}))
        .pipe(gulp.dest('temp'));

    gulp.src([specs]).pipe(protractor({
        configFile: 'temp/protractor.conf.js',
        args: ['--baseUrl', 'http://localhost:8080'],
        keepAlive: false,
        cucumberOpts: {
            tags : tags
        }
    })).on('error', function (e) {
        console.log('Errrrro', e)
        process.exit(1);
    }).on('end', function () {
        process.exit();
        cb();
    });
});
