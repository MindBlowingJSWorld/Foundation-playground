angular.module('mainApp')
    .run(resetFocusOnStateChange);

/**
 * Accessibility: Resets (removes) focus on state change. This allows
 * keyboard navigation straight to the skip link, instead of the focus staying
 * at a menu item and forcing the user to tab cycle through several
 * menu items before getting to the main content.
 */
function resetFocusOnStateChange($rootScope) {
    $rootScope.$on('$stateChangeSuccess', function () {
        $('#main-content').focus().blur();
    });
}