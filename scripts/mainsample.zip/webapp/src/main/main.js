// TODO get our module's names from some config file?
// TODO separate common modules into core module (or is it in our common module)?
angular.module('mainApp', [
    // Vendor modules
    'ui.router',
    'ngResource',
    'ngAnimate',
    'ngStorage',
    'angular-velocity',
    // Add your module names here!
    'dbw-authsign',
    'dbw-core',
    'dbw-common',
    'dbw-communication',
    'dbw-navigation',
    'dbw-login',
    'dbw-taskbar',
    'dbw-savings_app',
    'dbw-payments',
    'dbw-cards',
    'dbw-corporate-liquidity',
    'dbw-beneficiaries',
    'dbw-accounts',
    'dbw-messages',
    'dbw-profile',
    'dbw-authsign',
    'dbw-loan-credit',
    'dbw-localization',
    'ngFileUpload',
    'dbw-labels',
    'dbw-search',
    'dbw-agreement',
    'dbw-catalog'
]);
