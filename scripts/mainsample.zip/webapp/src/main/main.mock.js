// You do should NOT need to add your mock bundle here. It's automatically included in the mock run if your
// mock service simply replaces a production service (same name, adds to the same module).
// This for mock-related modules that the main app provides in the mocked run.
window.WT = {};//Disable webtrends
angular.module('mainApp.mock', [
    'mainApp',
    'ngMockE2E'
]);