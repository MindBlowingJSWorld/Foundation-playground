angular.module('mainApp')
    .config(function ($stateProvider, $urlRouterProvider) {
        $stateProvider
            .state('corporate', {
                url: '/corporate',
                templateUrl: 'main/main.tpl.html',
                redirectTo: 'corporate.home'
            })

            //.state('corporate.home', {
            //    templateUrl: 'corporate_module/overview/overview.tpl.html'
            //})
            
            .state('corporate.payments', {
                url: '/payments',
                template: '<div ui-view></div>',
                redirectTo: 'corporate.payments.pay-and-transfers',
                roles: ['payments']
            })
            .state('corporate.payments.pay-and-transfers', {
                url: '/pay-and-transfers',
                template: '<dbw-sendmoney></dbw-sendmoney>',
                roles: ['payments']
            })
            .state('corporate.payments.incoming', {
                url: '/incoming',
                template: '<h4>Incoming Payments</h4><p>Placeholder</p>',
                roles: ['payments']
            })
            .state('corporate.payments.outgoing', {
                url: '/outgoing',
                template: '<dbw-corp-outgoing-payments></dbw-corp-outgoing-payments>',
                roles: ['payments']
            })
            .state('corporate.payments.file-handling', {
                url: '/file-handling',
                template: '<h4>File Handling</h4><p>Placeholder</p>',
                roles: ['payments']
            })
            .state('corporate.payments.financial-contracts', {
                url: '/financial-contracts',
                template: '<h4>Financial Contracts</h4><p>Placeholder</p>'
            })



            // PLAN AND FORECASTE
            .state('corporate.plan-and-forecast', {
                url: '/plan-and-forecast',
                template: '<div ui-view></div>',
                redirectTo: 'corporate.plan-and-forecast.financial-overview'
            })



            .state('corporate.portfolio', {
                url: '/portfolio',
                template: '<div ui-view></div>',
                redirectTo: 'corporate.portfolio.accounts'
            })
            .state('corporate.portfolio.cards', {
                url: '/cards',
                template: '<h4>Cards</h4><p>Placeholder</p>'
            })
            .state('corporate.portfolio.loans', {
                url: '/loans',
                template: '<h4>Loans</h4><p>Placeholder</p>'
            })



            .state('corporate.advice-and-offers', {
                url: '/advice-and-offers',
                template: '<div ui-view></div>',
                redirectTo: 'corporate.advice-and-offers.product-store'
            })
            .state('corporate.advice-and-offers.product-store', {
                url: '/product-store',
                template: '<h4>Product Store</h4><p>Placeholder</p>'
            })

            .state('start.sign-agreement', {
                url: '/sign-agreement',
                template: '<dbw-agreement></dbw-agreement>'
            })
            .state('start.overview', {
                url: '/agreement-usersoverview',
                template: '<dbw-agreement-users-overview></dbw-agreement-users-overview>'
            });
    });
