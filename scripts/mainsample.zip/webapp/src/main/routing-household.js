angular.module('mainApp')
    .config(configureRouting);

function configureRouting($stateProvider, $urlRouterProvider) {

    // Main app provides parent states like 'household' and states corresponding to 1st level menu items e.g. 'household.check-and-pay'.
    // Application module code provides states for 2nd level menu items e.g. 'household.check-and-pay.overview'. Those configs
    // are done within the application module's config, not here. That we we don't have any orphan routes lying around. Also,
    // an actual page may have its own sub-routes, and it's more natural to keep those in the app module.

    $stateProvider

        .state('household', {
            url: '/household',
            templateUrl: 'main/main.tpl.html',
            redirectTo: 'household.check-and-pay'
        })

        .state('household.check-and-pay', {
            url: '/check-and-pay',
            template: '<div ui-view></div>',
            redirectTo: 'household.check-and-pay.overview'
        })

        //FIXME in corresponding module
        //'household.finances.summary' is not provided by corresponding module, making app broken
        .state('household.finances.summary', {
            url: '/fixme1',
            template: '<div ui-view></div>'
        })

        .state('household.finances', {
            url: '/finances',
            template: '<div ui-view></div>',
            redirectTo: 'household.finances.summary'
        })
        .state('household.advice-and-offers', {
            url: '/advice-and-offers',
            template: '<div ui-view></div>',
            redirectTo: 'household.advice-and-offers.find-solution'
        })
        .state('household.advice-and-offers.find-solution', {
            url: '/find-solution',
            templateUrl: 'catalog.tpl.html',
            controller: 'CatalogController',
            controllerAs: 'vm'
        })
        .state('household.advice-and-offers.browse', {
            url: '/browse',
            template: '<h4>Browse</h4><p>Placeholder</p>'
        })
        .state('household.advice-and-offers.get-advice', {
            url: '/get-advice',
            template: '<h4>Get Advice</h4><p>Placeholder</p>'
        })
    ;
}