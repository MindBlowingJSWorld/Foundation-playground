angular.module('mainApp')
    .config(configureRouting)
    .run(setUpRedirectHelper);

function configureRouting($stateProvider, $urlRouterProvider, $locationProvider) {

    $locationProvider.html5Mode(!window.DisableHtml5Mode);

    // Defines default state
    // Resolves "Error: $rootScope:infdig Infinite $digest Loop" (this may be remnant of AngularAMD dependency in the prototype app)
    $urlRouterProvider.otherwise(function ($injector) {
        var $state = $injector.get("$state");
        $state.go('login');
    });

    $stateProvider
        .state('login', {
            url: '/',
            template: '<login-page></login-page>',
            public: true
        })

        //Logout needs its own state to be able to track it even if it may show the same page
        .state('logout', {
            url: '/logout',
            template: '<login-page></login-page>',
            public: true
        })
        .state('start', {
            template: '<div ui-view class="fluid-container"></div>'
        })

        .state('common', {
            templateUrl: 'main/main.tpl.html'
        })
        .state('common.noaccess', {
            template: '<noaccess-page></noaccess-page>'
        })
        .state('common.notfound', {
            template: '<notfound-page></notfound-page>'
        })
        .state('common.messages', {
            url: '/messages',
            redirectTo: 'common.messages.inbox',
            template: '<dbw-messages/>'
        })
        .state('common.talk-with-us', {
            url: '/talk-with-us',
            redirectTo: 'common.talk-with-us.talk-with-us',
            template: '<ui-view/>'
        })
}

/**
 * Allows you to use 'redirectTo: <state id>' in angular ui router state configurations.
 *
 * Note for the future: API listening to state changes is different in angular-ui-router 1.x.
 */
function setUpRedirectHelper($rootScope, $state) {
    $rootScope.$on('$stateChangeStart', function (evt, to, params) {
        if (to.redirectTo) {
            evt.preventDefault();
            $state.go(to.redirectTo, params, {reload: true})
        }
    });
}
