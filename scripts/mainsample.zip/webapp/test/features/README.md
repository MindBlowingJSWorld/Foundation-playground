# Main houshold application UI test

You can find instruction how to write tests here

https://confluence.oneadr.net:8443/display/DBNS/4.+Writing+and+running+tests


Gulp tasks

gulp ui-test        Runs all UI tests


Usage of tags

gulp ui-test --tags=@current                Runs all with tag @current
gulp ui-test --tags=@current,@thistoo       Runs all with tags @curent and @thistoo


Tag in front of feature runs all tests in that feature

    @current
    Feature: Login

Tag in front of scenario, runs that test

    @current
    Scenario: Login household


Usage of specs

gulp ui-test --specs=webapp/test/features/features_ui/Login.feature         Runs specified test file


Basic instructions

- Write your UI tests inside features_ui in own feature file
- Implement required steps and pages in own folders
- Remember to construct mocks correctly. Use same mock creation code for mocked mode and UI tests.