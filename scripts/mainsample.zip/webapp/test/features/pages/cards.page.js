'use strict';

var CardsPage = function () {

    this.visit = function () {
        return browser.setLocation('/household/finances/cards');
    };
};

module.exports = new CardsPage();
