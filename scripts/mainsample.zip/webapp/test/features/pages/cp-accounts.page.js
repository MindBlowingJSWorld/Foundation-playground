/**
 * Created by Z420696 on 21.3.2016.
 */

'use strict';

var AccountsPage = function() {
    this.isPresent = function() {
        return element(by.id('acc-cp-accountlist')).isPresent();
    };

    this.openPortfolio = function() {
        return element(by.css('a[ui-sref="corporate.portfolio"]')).click();
    };

};

module.exports = new AccountsPage();
