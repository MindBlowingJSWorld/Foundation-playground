'use strict';

var DomesticPaymentsPage = function() {
    this.isPresent = function() {
        return element(by.name('domesticTransferForm')).isPresent();
    };

    this.clickExpandOwnTransferFromAccount = function () {
        return element(by.name('fromAccount')).click();
    };

    this.enterTheAccountNoInToAccount = function (toAccountNo) {
        return element(by.name('toAccount')).clear().sendKeys(toAccountNo);
    };

    this.clickOwnTransferFromAccountAtIndex = function (accountIndex) {
        return element.all(by.name('fromAccount')).get(accountIndex).click();
    };

    this.ordinalToNumber = function (ordinal) {
        var index = ['first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth'].indexOf(ordinal);
        if (index === -1)
            throw 'Unrecogized ordinal: \'' + ordinal + '\'';
        return index;
    };

    this.enterTransferAmount = function (amount) {
        return element(by.id('amount')).clear().sendKeys(amount);
    };

    this.enterOcrOrMessage = function (message) {
        return element(by.id('message')).clear().sendKeys(message);
    };

    this.enterOwnMessage = function (ownNote) {
        return element(by.id('ownNote')).clear().sendKeys(ownNote);
    };


    this.clickSendOnlyButton = function () {
        return element(by.css('button--primary')).click();
    };

    this.clickSendAndSaveButton = function () {
        return element(by.css('.button--secondary')).click();
    };

    this.getOwnTransferDone = function () {
        return element(by.css(''));
    };
};

module.exports = new DomesticPaymentsPage();
