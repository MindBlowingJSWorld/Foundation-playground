'use strict';

var OwnTransferPage = function() {
    this.isPresent = function() {
        return element(by.name('ownTransferForm')).isPresent();
    };

    this.clickExpandOwnTransferFromAccount = function () {
        return element(by.name('fromAccount')).click();
    };

    this.clickExpandOwnTransferToAccount = function () {
        return element(by.name('toAccount')).click();
    };

    this.clickOwnTransferFromAccountAtIndex = function (accountIndex) {
        return element.all(by.name('fromAccount')).get(accountIndex).click();
        //return element.all(by.name('fromAccount')).get(accountIndex).mouseDown();
    };

    this.clickOwnTransferToAccountAtIndex = function (accountIndex) {
        //return element.all(by.name('toAccount')).get(accountIndex).click();
        //return element.all(by.name('toAccount')).get(accountIndex).mouseDown();

        var elementToClick = element.all(by.name('toAccount')).get(accountIndex);
        return browser.executeScript('arguments[0].click()', elementToClick);
    };

    this.ordinalToNumber = function (ordinal) {
        var index = ['first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth'].indexOf(ordinal);
        if (index === -1)
            throw 'Unrecogized ordinal: \'' + ordinal + '\'';
        return index;
    };

    this.enterTransferAmount = function (amount) {
        return element(by.id('amount-number')).clear().sendKeys(amount);
    };

    this.clickOwnTransferSend = function () {
        return element(by.id('send-money-button')).click();
    };

    this.getOwnTransferDone = function () {
        return element(by.css(''));
    };


};

module.exports = new OwnTransferPage();
