'use strict';

var PaymentsPage = function() {
    this.isPresent = function() {
        return true;
    };

    this.checkIfOwnTransferSelectButtonEnabled = function() {
        return element(by.css('.owntransfer--payments--select')).isEnabled();
    };

    this.clickOwnTransferSelectButton = function () {
        if(this.checkIfOwnTransferSelectButtonEnabled()) {
            return element(by.css('.owntransfer--payments--select')).click();
        }
    };
};

module.exports = new PaymentsPage();
