/**
 * Created by Z420696 on 21.3.2016.
 */

'use strict';

var AccountsPage = function() {
    this.isPresent = function() {
        return element(by.id('acc-hh-accountlist')).isPresent();
    };

    this.openManageMyFinance = function() {
        return element(by.css('a[ui-sref="household.finances"]')).click();
    };

    this.selectAccountsTab = function() {
        return element(by.css('a[ui-sref="household.finances.accounts"]')).click();
    };
};

module.exports = new AccountsPage();
