'use strict';

var LoanList = function () {

    this.openManageMyFinance = function() {
        return element(by.css('a[ui-sref="household.finances"]')).click();
    };

    this.visit = function () {
        return element(by.css('a[ui-sref="household.finances.loans"]')).click();
    };

};

module.exports = new LoanList();
