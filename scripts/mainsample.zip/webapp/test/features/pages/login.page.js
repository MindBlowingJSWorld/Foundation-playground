'use strict';

var LoginPage = function () {

    this.openHouseholdLogin = function () {
        browser.driver.manage().window().setSize(1240, 800);
        browser.get('fi.html');
        browser.executeScript("window.localStorage.setItem('loginSettings', JSON.stringify({segment: 'household'}));");
        return browser.refresh();
    };

    this.openHouseholdLoginSE = function () {
        browser.driver.manage().window().setSize(1240, 800);
        browser.get('se.html');
        browser.executeScript("window.localStorage.setItem('loginSettings', JSON.stringify({segment: 'household'}));");
        return browser.refresh();
    };

    this.openCorporatedLogin = function () {
        browser.driver.manage().window().setSize(1240, 800);
        browser.get('fi.html');
        browser.executeScript("window.localStorage.setItem('loginSettings', JSON.stringify({segment: 'corporate'}));");
        return browser.refresh();
    };

    this.enterCustomerID = function (customerId) {
        return element(by.id('userID')).clear().then(function () {
            return element(by.id('userID')).sendKeys(customerId);
        });
    };

    this.login = function () {
        return element(by.id('loginbutton')).click();
    };

    this.isAgreementPageVisible = function () {
        return element(by.id('agreement_selection_page')).isPresent();
    };

    this.isBankidWaitingPageVisible = function () {
        return element(by.id('bankid_waiting_page')).isPresent();
    };

    this.searchAgreement = function(agreementNumber) {
        return element(by.id('agreements-search')).sendKeys(agreementNumber);
    };

    this.selectAgreement = function(agreementNumber) {
        var el = element(by.id('agreement-' + agreementNumber));
        return el.click();
    };

    this.selectLoginMethod = function (option) {
        return element.all(by.tagName('option'))
            .then(function (options) {
                return options[option].click();
            });
    };

    this.cancelLogin = function() {
        var el = element(by.id('cancel-agreement-selection'));
        return el.click();
    };

};

module.exports = new LoginPage();
