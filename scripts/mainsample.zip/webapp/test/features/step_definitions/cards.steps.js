'use strict';

module.exports = function () {

    this.World = require('./world.js').World;
    var CardsPage = require('../pages/cards.page.js');

    var cardSelector = '.cards-list__card';

    this.Given(/^User navigates to cards$/, function (cb) {
        browser.driver.manage().window().setSize(1240, 800);
        CardsPage.visit().then(cb);
    });

    this.Given(/^User opens card details for card ([0-9]+)$/, function (cardNo, cb) {
        // TODO this is way too fragile
        $$(cardSelector).get(parseInt(cardNo) - 1).$('nd-moneybar').click().then(function() {
            cb();
        });
    });

    this.Then(/^User sees card list$/, function (cb) {
        this.expect($(cardSelector).getText()).to.eventually.contain('Nordea Gold').and.notify(cb);
    });

    this.Then(/^User sees card details$/, function (cb) {
        this.expect($(cardSelector + ' .moneybar__details-container').isPresent()).to.eventually.be.true.and.notify(cb);
    });
};
