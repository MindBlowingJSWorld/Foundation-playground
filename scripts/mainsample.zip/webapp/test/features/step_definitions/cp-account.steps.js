/**
 * Created by Z420696 on 21.3.2016.
 */

'use strict';

module.exports = function () {

    this.World = require('./world.js').World;
    
    var AccountsPage = require('../pages/cp-accounts.page.js');

    this.Given(/^User selects portfolio/, function (callback) {
       AccountsPage.openPortfolio().then(function() {
           callback();
       });
    });

    this.Then(/^User lands corporate accounts overview$/, function (callback) {
        this.expect(AccountsPage.isPresent()).to.eventually.equal(true).and.notify(callback);
    });

};


