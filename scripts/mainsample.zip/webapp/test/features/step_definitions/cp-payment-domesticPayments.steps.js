'use strict';

module.exports = function () {

    this.World = require('./world.js').World;

    var domesticPaymentsPage = require('../pages/cp-payments-domesticPayments.page.js');

    this.When(/^I see the domestic payments screen$/, function (callback) {
        this.expect(domesticPaymentsPage.isPresent()).to.eventually.equal(true).and.notify(callback);
    });
};
