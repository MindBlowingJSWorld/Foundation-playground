'use strict';

module.exports = function () {

    this.World = require('./world.js').World;

    var ownTransferPage = require('../pages/cp-payments-ownTransfer.page.js');

    var accounts = require('../uimocks/accounts.mocks.js');

    this.When(/^I see the own transfer screen$/, function (callback) {
        this.expect(ownTransferPage.isPresent()).to.eventually.equal(true).and.notify(callback);
    });

    this.When(/^I choose to expand the from account list$/, function (callback) {
        ownTransferPage.clickExpandOwnTransferFromAccount();
        callback();
    });

    this.When(/^I choose to expand the to account list$/, function (callback) {
        ownTransferPage.clickExpandOwnTransferToAccount();
        callback();
    });

    this.When(/^I choose the from account to be the (\w+) account$/, function (index, callback) {
        //ownTransferPage.clickOwnTransferFromAccountAtIndex(ownTransferPage.ordinalToNumber(index));
        ownTransferPage.clickOwnTransferFromAccountAtIndex(ownTransferPage.ordinalToNumber(index));
        callback();
    });

    this.When(/^I choose the to account to be the (\w+) account$/, function (index, callback) {
        ownTransferPage.clickOwnTransferToAccountAtIndex(ownTransferPage.ordinalToNumber(index));
        ownTransferPage.clickOwnTransferToAccountAtIndex(ownTransferPage.ordinalToNumber(index));
        callback();
    });

    this.When(/^I enter transfer amount (\w+)$/, function (amount, callback) {
        //ownTransferPage.enterTransferAmount(amount);//.then(callback);
    });

    this.When(/^I click the send money button$/, function (callback) {
        ownTransferPage.clickOwnTransferSend().then(callback);
    });

    this.Then(/^I should see the transfer done window$/, function (next) {
        browser.wait(function () {
            return ownTransferPage.getOwnTransferDone().isDisplayed().then(function (displayed) {
                return displayed;
            });
        }, 5000);
        next();
    });

    this.Given(/^I have the following accounts:$/, function (table, callback) {
        var accounts = accounts.generateAccountsFromTable(table);
        browser.addMockModule('accountsMock', accounts.backendMockModule, 200, accounts);
        callback();
    });


};
