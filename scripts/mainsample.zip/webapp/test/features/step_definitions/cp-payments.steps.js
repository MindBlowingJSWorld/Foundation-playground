'use strict';

module.exports = function () {

    this.World = require('./world.js').World;

    var PaymentsPage = require('../pages/cp-payments.page.js');

    this.When(/^I go to payments/, function (callback) {
        element(by.xpath('//a[@ui-sref="corporate.payments"]')).click();
        callback();
    });

    this.When(/^I click on own transfer button$/, function (callback) {
        this.expect(PaymentsPage.clickOwnTransferSelectButton()).and.notify(callback);
    });
};
