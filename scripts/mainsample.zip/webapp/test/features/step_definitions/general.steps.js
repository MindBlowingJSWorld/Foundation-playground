'use strict';

var LoginPage = require('../pages/login.page.js');

module.exports = function () {
    this.Then(/^I want to pause to debug$/, function () {
        browser.pause();
    });

    this.Then(/^debug$/, function () {
        browser.pause();
    });

    this.Given(/^User is logged in to household as user (.*)$/, function(userId, cb) {
        LoginPage.openHouseholdLogin()
            .then(LoginPage.enterCustomerID(userId))
            .then(LoginPage.login())
            .then(function() {
                cb();
            });
    });

    this.Given(/^User is logged in to corporate as user (.*)$/, function(userId, cb) {
        LoginPage.openCorporatedLogin()
            .then(LoginPage.enterCustomerID(userId))
            .then(LoginPage.login())
            .then(function() {
                cb();
            });
    });
};
