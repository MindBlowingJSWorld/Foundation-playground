/**
 * Created by Z420696 on 21.3.2016.
 */

'use strict';

module.exports = function () {

    this.World = require('./world.js').World;
    
    var AccountsPage = require('../pages/hh-accounts.page.js');
    var Accounts = require('../uimocks/accounts.mocks.js');

    this.Given(/^User selects my finances$/, function(callback) {
        AccountsPage.openManageMyFinance().then(function() {
            callback();
        });
    });

    this.Given(/^User selects accounts tab/, function (callback) {
        AccountsPage.selectAccountsTab().then(function() {
            callback();
        });
    });

    this.Then(/^User lands household accounts overview$/, function (callback) {
        this.expect(AccountsPage.isPresent()).to.eventually.equal(true).and.notify(callback);
    });

    this.Given(/^User have the following accounts:$/, function (table, callback) {
        var accounts = Accounts.generateAccountsFromTable(table);
        browser.addMockModule('accountsMock', Accounts.backendMockModule, 200, accounts);
        callback();
    });
};
