'use strict';

module.exports = function () {

    this.World = require('./world.js').World;
    var LoanListPage = require('../pages/loanList.page.js');
    var LoanMock = require('../uimocks/loan.mocks');
    var moment = require('moment');

    this.Given(/^User fetches following loans with status (\d+):$/, function (status, table, cb) {
        var mockData = LoanMock.generateMockDataFromGherkinTable(table);
        browser.addMockModule('loanListMock', LoanMock.backendMockModule, status, mockData);
        cb();
    });

    this.When(/^User opens Manage My Finance$/, function(cb) {
        LoanListPage.openManageMyFinance().then(function() {
            cb();
        });
    });

    this.When(/^User opens loan dashboard page$/, function(cb) {
        LoanListPage.visit().then(function() {
            cb();
        });
    });

    this.When(/^User opens loan with id "([^"]+)"$/, function(loanId, cb) {
        element(by.css("#loan-moneybar-" + loanId)).click().then(function () {
            cb();
        });
    });

    this.When(/^User opens additional loan details of loan "([^"]+)"$/, function(loanId, cb) {
        element(by.css("#loan-" + loanId + ' .loan-details__show-more-toggle-text')).click().then(function () {
            cb();
        });
    });

    this.Then(/^User lands on loan dashboard page$/, function(cb) {
        // turn synchronization off to not to wait until page is fully loaded.
        browser.ignoreSynchronization = true;
        this.expect(browser.getCurrentUrl()).to.eventually.contain('#/household/finances/loans').and.notify(function() {
            browser.ignoreSynchronization = false;
            cb();
        });
    });

    function elementIsPresent(locator) {
        return this.expect(element(locator).isPresent()).to.eventually.be.true;
    }

    this.Then(/^User sees text "([^"]*)" under element with css "([^"]+)"$/, function(text, elementSelector, cb) {
        elementIsPresent.call(this, by.cssContainingText(elementSelector, text)).and.notify(cb);
    });

    // Copied from dbw-common/src/common-ui/moneybar/MoneybarServiceProvider.js
    function calculateDueDays(aDate) {
        var theDate = moment(aDate);
        if(!theDate.isValid()) {
            return 'soon';
        }
        if(theDate.isSame(moment(), 'day')) {
            return ' today';
        }
        if(theDate.isSame(moment().add(1,'days'), 'day')) {
            return ' tomorrow';
        }
        if(theDate.isSame(moment().subtract(1,'days'), 'day')) {
            return ' yesterday';
        }
        return ' ' + theDate.fromNow();
    }

    this.Then(/^User sees due in text of date "([^"]*)" under element with css "([^"]+)"$/, function(date, elementSelector, cb) {
        var text = calculateDueDays(date);
        elementIsPresent.call(this, by.cssContainingText(elementSelector, text)).and.notify(cb);
    });

    this.Then(/^User sees value "([^"]+)" under loan "([^"]+)" detail "([^"]+)"$/, function(text, loanId, loanDetailSelector, cb) {
        var detailValueSelector = '#loan-' + loanId + '-' + loanDetailSelector + ' .detail-entry-value';
        elementIsPresent.call(this, by.cssContainingText(detailValueSelector, text)).and.notify(cb);
    });

    this.Then(/^User sees loading animation$/, function(cb) {
        // turn synchronization off to not to wait until page is fully loaded because
        // loading animation is not available anymore at that point.
        browser.ignoreSynchronization = true;
        elementIsPresent.call(this, by.id('loans-loading-info')).and.notify(function() {
            browser.ignoreSynchronization = false;
            cb();
        });
    });

    this.Then(/^User sees element with id "([^"]+)"$/, function(elementId, cb) {
        elementIsPresent.call(this, by.id(elementId)).and.notify(cb);
    });


    function getLoanGroup(groupTitle) {
        var groupTitleElement = element(by.cssContainingText('.loan-group__title', groupTitle));
        return groupTitleElement.element(by.xpath('ancestor::div[contains(@class, "loan-group")]'));
    }

    this.Then(/^User sees loan product name "([^"]+)" under loan group "([^"]+)"$/,
        function (loanProductName, groupTitle, cb) {
            var groupParent = getLoanGroup(groupTitle);
            var loanElement = groupParent.element(by.cssContainingText('loan-list-entry', loanProductName));

            this.expect(loanElement.isPresent()).to.eventually.be.true.and.notify(cb);
        }
    );

    this.Then(/^User sees total amount "([^"]+)" under loan group "([^"]+)"$/, function (totalAmount, groupTitle, cb) {
        var groupParent = getLoanGroup(groupTitle);
        var totalSum = groupParent.element(by.cssContainingText('.loan-group__total-amount', totalAmount));

        this.expect(totalSum.isPresent()).to.eventually.be.true.and.notify(cb);
    });
};
