'use strict';

module.exports = function () {
    this.setDefaultTimeout(60*1000);

    this.World = require('./world.js').World;
    var LoginPage = require('../pages/login.page.js');

    this.Given(/^User opens login page for household$/, function (cb) {
        LoginPage.openHouseholdLogin().then(cb);
    });

    this.Given(/^User opens login page for household in SE$/, function (cb) {
        LoginPage.openHouseholdLoginSE().then(cb);
    });

    this.Given(/^User opens login page for corporate/, function (cb) {
        LoginPage.openCorporatedLogin().then(cb);
    });

    this.Given(/^User gives userid (.*)$/, function (userId, cb) {
        LoginPage.enterCustomerID(userId).then(cb);
    });

    this.Given(/^User logs in$/, function (cb) {
        LoginPage.login().then(function() {
            cb();
        });
    });

    this.Then(/^User selects personal code login$/, function (cb) {
        LoginPage.selectLoginMethod(0).then(function() {
            cb();
        });
    });

    this.Then(/^User selects bankid login$/, function (cb) {
        LoginPage.selectLoginMethod(1).then(function() {
            cb();
        });
    });

    this.Then(/^User selects codeapp login$/, function (cb) {
        LoginPage.selectLoginMethod(1).then(function() {
            cb();
        });
    });

    this.Then(/^User lands on bankid waiting page$/, function (cb) {
        browser.ignoreSynchronization = true;
        this.expect(LoginPage.isBankidWaitingPageVisible()).to.eventually.equal(true).and.notify(function() {
            browser.ignoreSynchronization = false;
            cb();
        });
    });

    this.Then(/^User lands on household page$/, function (cb) {
        this.expect(browser.getCurrentUrl()).to.eventually.contain('#/household').and.notify(cb);
    });

    this.Then(/^User lands on corporate page$/, function (cb) {
        this.expect(browser.getCurrentUrl()).to.eventually.contain('#/corporate').and.notify(cb);
    });

    this.Then(/^User lands on agreements page$/, function (cb) {
        this.expect(LoginPage.isAgreementPageVisible()).to.eventually.equal(true).and.notify(cb);
    });

    this.Then(/^User lands on logout\/login page$/, function (cb) {
        this.expect(browser.getCurrentUrl()).to.eventually.contain('#/').and.notify(cb);
    });

    this.Then(/^User selects agreement (\d+)$/, function (agreementNumber, cb) {
        LoginPage.selectAgreement(agreementNumber).then(function() {
            cb();
        });
    });

    this.Then(/^User searches agreement by id (\d+)$/, function (agreementNumber, cb) {
        LoginPage.searchAgreement(agreementNumber).then(function() {
            cb();
        });
    });

    this.Then(/^User cancels login process$/, function (cb) {
        LoginPage.cancelLogin().then(function() {
            cb();
        });
    });

};
