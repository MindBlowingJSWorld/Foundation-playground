'use strict';

//chai is an assertion library
var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);

var World = function () {
    this.expect = chai.expect;
};

exports.World = World;
