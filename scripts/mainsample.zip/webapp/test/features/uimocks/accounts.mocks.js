
'use strict';

var Accounts = function () {

    function _createAccount(account) {
        var currencyCode = account.currency || 'EUR';

        return {
            'account_number': account.accountNumber,
            'display_account_number': account.displayAccountNumber,
            'iban': account.iban,
            'account_status': account.status,
            'nickname': account.nickname,
            'available_balance': account.availableBalance,
            'booked_balance': account.bookedBalance,
            'currency': currencyCode,
            'credit_limit':account.creditLimit,
            'product_name': account.productName,
            'product_code': account.productCode,
            'product_type': account.productType,
            'remaining_free_withdrawals': null,
            'permissions': {
            'can_view': true,
                'can_view_transactions': true,
                'can_pay_from_account': true,
                'can_transfer_from_account': true,
                'can_transfer_to_account': true
            }
        };


    }

    this.backendMockModule = function (responseCode, accounts) {
        angular.module('accountsMock', ['dbw-accounts'])
            .run(function (AccountServiceMock) {
                AccountServiceMock.mock(responseCode, accounts);
            });
    };

    this.generateAccountsFromTable = function (table) {
        var accounts = [];
        var accountsResponseObject = { accounts: accounts };

        for (var account, i = 0; account = table.hashes()[i]; i++) {
            accounts.push(_createAccount(account));
        }
        return accountsResponseObject;
    };

};

module.exports = new Accounts();
