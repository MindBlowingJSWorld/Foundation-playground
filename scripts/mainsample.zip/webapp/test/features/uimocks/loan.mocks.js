'use strict';

var LoanMock = function () {

    this.generateMockDataFromGherkinTable = function (table) {
        var loans = [];
        for (var i = 0; i < table.hashes().length; i++) {
            var loanItem = table.hashes()[i];
            var instalmentFreeMonths = loanItem.instalment_free_periods ? loanItem.instalment_free_periods.split(',') : undefined;
            var owners = loanItem.owners ? loanItem.owners.split(', ') : undefined;
            var loan =
            {
                id: loanItem.id,
                loan_data: {
                    local_number: loanItem.id,
                    type: loanItem.purpose,
                    purpose: loanItem.purpose,
                    balance: -loanItem.balance,
                    granted: -loanItem.balance,
                    interest: loanItem.interest,
                    reference_rate: loanItem.reference_rate,
                    first_drawdown_date: loanItem.start_date
                },
                repayment_schedule: {
                    account_to_be_credited_number: loanItem.debit_account,
                    following_instalment: loanItem.instalment_date,
                    instalment_free_months: instalmentFreeMonths,
                    method_of_payment: loanItem.method_of_payment,
                    initial_payment_date: loanItem.start_date,
                    final_payment_date: loanItem.end_date,
                    payment_amount: loanItem.instalment_amount
                },
                following_payment: {
                    total: loanItem.instalment_amount
                },
                parties: owners
            };
            loans.push(loan);
        }
        return loans;
    };

    this.backendMockModule = function (responseCode, mockdata) {
        angular.module('loanListMock', ['dbw-loan-credit.loan_list'])
            .run(function (loanLoanListServiceMock) {
                loanLoanListServiceMock.setMocks(responseCode, mockdata);
            });
    };
};

module.exports = new LoanMock();