# The `selenium` Directory

## Overview

Due to the fact the we can't get the Chromedriver to get automatically downloaded using `webdriver-manager update`
(even with --proxy option) we have these checked in.

Please note that the linux version needs to be checked in with
executable permissions, i.e. `git update-index --chmod=+x chromedriver_2.18`
