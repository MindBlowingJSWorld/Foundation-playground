# Module template - template for feature team modules

## How to get started
1. Check front-end development guides from here: https://confluence.oneadr.net:8443/x/mxtmBQ
2. Clone this repository
3. Create a new repository
4. Copy all files to your empty repository
5. Change all "example_app" references from every file to be your "main" module
6. Change the package name from package.json from "example_package" to your package name
7. Change states etc. from index.tpl.html to suit your module
8. Run: npm install
9. Remember to run once in a while: npm update

## Run tests
gulp test-ci // runs tests and provides coverages to reports-folder continuosly

gulp test-release // runs all tests once in every configured browser

## Run webserver for development/demo purposes
gulp run // creates a release build and runs webserver against it. Live reload not available.

gulp run-demo // creates a development/demo build and runs webserver against it. Live reload available whenever you change your source codes / styles.

gulp run-demo-mocked // same as gulp run-demo but with mocks enabled

## Change stylesheet auto reload port if conflicts with another running application
gulp run-demo --lp=35727 or --lp 35727

## Change server port if conflicts with another running application
gulp run-demo --p=9001 or --p 9001

## More information
More information regarding the module template can be found from here: https://confluence.oneadr.net:8443/x/vR9bBQ

## Embed module to main-household

This way your module will be included in main-household app (that you run locally), and changes will be livereloaded.
Cons: you need to relogin to app after every update.

1. cd main-household
2. npm link <path to your module>
3. gulp run
4. cd <your module>
5. gulp watch

## releasing module

Releasing module is simple:

1. gulp release
2. It  will run test and bump patch (0.0.x) version
3. Verify that build is fine:
    https://intservices-aite.sed1.root4.net/dbw/view/All/builds
    http://ap-rbo1s:12200/#/
4. Add module to main-household. Example of files to be changed: https://ccd1is0271.ccd1.root4.net:8443/projects/DBW/repos/main-household/pull-requests/12/diff

## ES6 transpilation

ES6->ES5 transpilation can be enabled with the following procedure:

1. install babel and other needed packages with `npm install -D babel@6 babel-preset-es2015@6 gulp-babel@6 karma-babel-preprocessor@6`
2. enable transpilation in `build-js` task in `gulp-tasks/build.js:82` (tip: search for "uncomment this to enable ES6 transpilation")
3. enable transpilation for `plato` in `gulp-tasks/analyze.js:34` (tip: search for "uncomment this to enable ES6 transpilation")
4. enable transpilation for tests in `config/karma.config.js:32` (tip: search for "uncomment this to enable ES6 transpilation")
5. configure `eslint` to support ES6 in `.eslintrc`:
    * change `es6` option to true in `env` section
    * change `ecmaVersion` to 6 in `parserOptions` section
    * (optional) enable `no-var` and `prefer-const` rules by setting them to 1 (warning) or 2 (error)
6. To verify that transpilation works correctly, add `console.log(...['test', 'another']);` to ExampleController and check `dist/dbw-example_package.js`. The resulting code should be similar to `(_console = console).log.apply(_console, ['test', 'another']);`.
