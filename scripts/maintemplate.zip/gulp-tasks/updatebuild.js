'use strict';

var gulp = require('gulp');
var git = require('gulp-git');
var del = require('del');
var runSequence = require('run-sequence');
var rename = require('gulp-rename');

gulp.task('update-build', function() {
    runSequence(
        'update-clone',
        'update-copy-tasks',
        'update-clean'
    );
});

gulp.task('update-clone', function(done) {
    git.clone('ssh://git@ccd1is0271.ccd1.root4.net:7999/dbw/module-template.git', {args: './.module'}, function() {
        done();
    });
});

gulp.task('update-copy-tasks', function() {
    gulp.src('./config/build.config.js').pipe(rename('build.config.old.js')).pipe(gulp.dest('./config/'));
    gulp.src('./config/karma.config.js').pipe(rename('karma.config.old.js')).pipe(gulp.dest('./config/'));
    gulp.src('./config/file.config.js').pipe(rename('file.config.old.js')).pipe(gulp.dest('./config/'));
    gulp.src('./.module/config/*').pipe(gulp.dest('./config/'));
    gulp.src('./.module/gulp-tasks/*').pipe(gulp.dest('./gulp-tasks/'));
    gulp.src('./gulpfile.js').pipe(rename('gulpfile.old.js')).pipe(gulp.dest('./'));
    gulp.src('./.module/.stylelintrc').pipe(gulp.dest('./'));
    gulp.src('./.module/.eslintrc').pipe(gulp.dest('./'));
    gulp.src('./.module/.babelrc').pipe(gulp.dest('./'));
    gulp.src('./.module/gulp-tasks/.eslintrc').pipe(gulp.dest('./gulp-tasks/'));
    gulp.src('./.module/config/.eslintrc').pipe(gulp.dest('./config/'));
    del('./gulpfile.js');
    del('./.jshintrc');
    return gulp.src('./.module/gulpfile.js').pipe(rename('gulpfile.js')).pipe(gulp.dest('./'));
});

gulp.task('update-clean', function() {
    del('./.module');
});

gulp.task('update-clean-olds', function() {
    del('./gulpfile.old.js');
    del('./config/build.config.old.js');
    del('./config/karma.config.old.js');
    del('./config/file.config.old.js');
});

