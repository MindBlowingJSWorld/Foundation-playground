'use strict';

angular.module('example_app', ['ngResource', 'example_app.tpl', 'example_app.example_module', 'dbw-core']);
