/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

angular.module('example_app.mocks', ['example_app','ngMockE2E']).config(function () {
    angular.MOCKDATA = {auth: true};
}).run(function ($httpBackend) {
    $httpBackend.whenGET(/^.*.tpl.html/).passThrough();
});
