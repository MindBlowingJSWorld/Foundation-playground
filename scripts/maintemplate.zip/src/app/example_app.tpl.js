'use strict';

angular.module('example_app.tpl', []);
