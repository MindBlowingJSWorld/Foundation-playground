'use strict';

angular.module('example_app.example_module')
  .controller('ExampleController', ExampleController);

/* @ngInject */
function ExampleController(ExampleService) {

    var vm = this;
    vm.exampleCollection = ['Initial example data one', 'Initial example data two'];

    ExampleService.getData().then(
        function (exampleData) {
            vm.exampleCollection = exampleData;
        },
        function() {
            console.log('Handle get data UI error');
        }
    );

}
