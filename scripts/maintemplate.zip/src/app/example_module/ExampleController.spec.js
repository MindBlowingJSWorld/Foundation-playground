/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('ExampleController', function () {
    var controller;
    var exampleCollection;

    beforeEach(module('example_app.example_module'));

    beforeEach(
        inject(function(_$controller_) {
            controller = _$controller_('ExampleController');
            exampleCollection = ['Initial example data one', 'Initial example data two'];
        })


    );

    it('should be defined', inject(function() {
        expect(controller).toBeTruthy();
        expect(exampleCollection).toEqual(controller.exampleCollection);
    }));

});
