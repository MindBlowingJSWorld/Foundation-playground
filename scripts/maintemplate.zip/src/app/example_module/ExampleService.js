'use strict';

angular.module('example_app.example_module')
    .factory('ExampleService', ExampleService);

/* @ngInject */
function ExampleService ($resource, $q) {

    var getData = function() {
        var deferred = $q.defer();

        // TODO: update when resourcing logic is clarified.
        $resource('/v0.4/banking/accounts/NAID-SE-SEK-32580077936/transactions').query().$promise.then(
            function(json) {
                deferred.resolve(json);
            },
            function(error) {
                deferred.reject(error);
            }
        );

        return deferred.promise;
    };

    return {
        getData: getData
    };
}
