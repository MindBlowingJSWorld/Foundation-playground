/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

angular.module('example_app.example_module')
  .config(config)
  .factory('ExampleServiceMock', ExampleServiceMock);

/* @ngInject */
function config ($provide) {
    /*eslint-disable angular/function-type*/
    $provide.decorator('ExampleService', ['$delegate', 'ExampleServiceMock',
        function ($delegate, ServiceMock) {
            ServiceMock.mock();
            return $delegate;
        }
    ]);
    /*eslint-enable angular/function-type*/

}

/* @ngInject */
function ExampleServiceMock($httpBackend) {

    var mockData = ['Hello Mock','Hello Mock 2'];
    var statusCode = 200;

    return {
        getMocks: function () {
            return {
                statusCode: statusCode,
                mockData: mockData
            };
        },
        mock: function () {
            $httpBackend.whenGET('/v0.4/banking/accounts/NAID-SE-SEK-32580077936/transactions').respond(statusCode, mockData);
        },
        setMocks: function (newStatusCode, newMockData) {
            statusCode = newStatusCode;
            mockData = newMockData;
        }
    };
}
