/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('ExampleService', function () {
    var $httpBackend;
    var service;
    var $rootScope;

    beforeEach(module('example_app.example_module'));

    beforeEach(
        inject(function(ExampleService, _$httpBackend_, _$rootScope_) {
            service = ExampleService;
            $httpBackend = _$httpBackend_;
            $rootScope = _$rootScope_;
        })
    );

    it('should be defined', inject(function() {
        expect(service).toBeTruthy();
    }));

    it('should provide happy greeting', inject(function() {
        var testData = ['Hello Mock','Hello Mock 2'];

        $httpBackend.expectGET('/v0.4/banking/accounts/NAID-SE-SEK-32580077936/transactions').respond(
            ['Hello Mock','Hello Mock 2']
        );

        service.getData().then(function(result) {
            expect(result[0]).toEqual(testData[0]);
            expect(result[1]).toEqual(testData[1]);
        });

        $httpBackend.flush();
    }));
});
