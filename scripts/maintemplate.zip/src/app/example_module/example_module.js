'use strict';

angular.module('example_app.example_module', ['ui.router', 'ngResource'])

    .config(function ($stateProvider) {

        $stateProvider
            // This is how it's done with named views
            .state('mainstate.substate.examplestate', {
                url: '/examplestate',
                views: {
                    '': { // this injects the view to correct unnamed view. Do not use @ since it overrides top menu.
                        templateUrl: 'example_module/example.tpl.html',
                        controller: 'ExampleController',
                        controllerAs: 'exampleController'
                    }
                }
            });

            /*
            // This is how it's done without views
            .state('mainstate.substate.examplestate', {
                url: '/examplestate',
                templateUrl: 'example_module/example.tpl.html',
                controller: 'ExampleController',
                controllerAs: 'exampleController'
            })
            */
    });
