# <a id="2.7.0">2.7.0 (ongoing, sprint 2.5)</a>

## Features

Angular UI components

* (Replace with something) 

Foundation styles

* (Replace with something)


## Bug fixes

Angular UI components

* (Replace with something)

Foundation styles

* (Replace with something)

Build

* (Replace with something)


## Breaking changes

Angular UI components

* (Replace with something)

Foundation styles

* (Replace with something)



# <a id="2.6.0">2.6.0 (2016-05-31)</a>

## Features

Angular UI components

* `NotificationService`: `setId` parameter in methods `showToast` and `hideToast` is now optional. 
    * In fact, it's recommended to have just one set for top notifications and another for toasts in an application. 
    * With multiple sets notifications in different sets may overlap each other.
* `nd-spinner`: Added support for re-enabling spinning.
* `nd-date-picker`: Passed in data object to `on-select` callback providing information about the selected date, and user interactions.
* `nd-moneybar`: Added support for custom title in main content (center of moneybar).
* `MoneybarServiceProvider`: new method `MoneybarServiceProvider.configureTypes` allows feature teams to customize titles of their Moneybar types 

Foundation styles

* Helper CSS class `fluid-container-background` for wrapping `fluid-container` in a full width container with custom background color (use case e.g. navbar)
* Updated icons


## Bug fixes

Angular UI components

* `nd-spinner`: Fixed opacity remaining on spinned component when initial conditions did not require spinning.
* `nd-button-expand`: Fixed alignment of text with icon
* `nd-date-picker`: on-change callback is now called after model value is updated

Foundation styles

* `fluid-container`: content width no longer start shrinking when expanding the viewport past 1680px

Build

* Prevent npm to automatically update dbw-vendor on npm install
* Updated to sc5-styleguide version 1.0.0. This gives a performance improvement in sections with lots of style panels, e.g. in the Icons section.

## Breaking changes

Angular UI components

* `NotificationService`: method signatures changed
    * Now: `showToast(notification[, setId])`, `showToast(notification[, setId])`, previously: `showToast(setId, notification)`, `showToast(setId, notification)`.

Foundation styles

* Variables `$nordea-min-width` and `$nordea-max-width` renamed to `$nordea-content-min-width` and `$nordea-content-max-width` because their semantics has changed
* Changes in icon names
    * `confirm_sign` => `confirmSign`
    

# <a id="2.5.1">2.5.1 (2016-05-16)</a>

## Bug fixes

Build

* Build script's postinstall updated to prevent dbw-common installation from failing if tooling update using dbw-vendor fails (e.g. when not using gulp)


# <a id="2.5.0">2.5.0 (2016-05-16)</a>

## Features

Angular UI components

* Modal - Added preliminary Nordea defaults to component CSS.
* `nd-button-expand`: Added support for customized classnames on button.
* `nd-moneybar`
    * When maincontent or subcontent value is undefined or null, neither the amount nor its label is displayed  
* `nd-input-container`
    * `placeholder` attribute now supported (as in Angular Material input container)
* `md-menu`: pop-up menu component included from angular-material and re-styled
* `md-select`: drop down menu component included from angular-material and re-styled    


## Bug fixes

 Angular UI components

* `nd-moneybar`
    * Fixed: When maincontent or subcontent-left value was zero, no value was displayed 
    * Fixed: Subcontent-right showed 0,00 when the value was undefined or null. Now the placeholder is empty when the input is undefined. This is consistent with how maincontent and subcontent-left behave.

Foundation styles

* Removed double border between elements in `.button-group` and `.button-multiselect` 


# <a id="2.4.1">2.4.1 (2016-05-03)</a>

## Features

Angular UI components

* Introduced `nd-button-expand`
    * Button that toggles on click that changes state with icon arrow up and down

## Bug fixes

Angular UI components

* `nd-date-picker`
    * Minor layout fix: calendar icon in header
* `nd-moneybar`
    * Fixed: Clicking a button within moneybar expanded content toggled the expanded state of another moneybar below if cursor was also over the other moneybar  

Foundation styles

* Fixed `.button.flat` style
* Text alignment classes (e.g. `text-center`) imported after other styles to give them more specificity


# <a id="2.4.0">2.4.0 (2016-04-29)</a>

## Features

Angular UI components

* Modal
    * A component for displaying modal.
    * Custom modal has a promises and can be easily styled and connected to custom cotroller.
    * For example, custom modal might be tuned to full-screen or alert like.
    * `zf-modal` directive is used while editing modal's custom template
* `nd-scroll-focus`: Similar functionality as an old-school `<a href="#target-id">` element (which does not work in AngularJS): scrolls and focuses on target element and adds target hash to browser URL.
* `nd-spinner`: Prevents interacting with contained element while bound variable value is undefined or false and displays a spinner image
* Top notifications and toast notifications

Foundation styles

* PFM colors added as variables in `_colors.scss` (imported by `_nordea_settings.scss`)
* PFM icons: some new and some updated 
* Styles for a button containing an icon (on the left side or on the right side)


## Breaking changes

Foundation styles

* `_nordea_sttings.scss`: relative paths to Foundation for Sites and Motion UI scss files converted to file names. You are using this file in your SASS build process, you must
    1. Include npm packages foundation-sites version 6.2.0 and motion-ui 1.2.0 in your build.
    1. Include the following in your gulp-sass plugin's settings: `includePaths: ['node_modules/foundation-sites/scss', 'node_modules/motion-ui/src']`. 
* .button-group, .button-group--large
* .button-multiselect
    * .button-group was removed from previous version of .button-group as previous Nordea .button-groups made no use of the additional markup Foundation provides for this class. Foundation's markup is similar to our markup for .button-multiselect, please ADD the .button-group classname to achieve the visual style for .button-multiselect. .button-multiselect will take care of only the checkbox trickery in the future.
* .toast *.toast was renamed. Check .callout and .notification.
* .button--primary, .button--secondary, .button--large
    * BEM synonyms for classes that are already defined by Foundation will be removed, except in cases where stated otherwise.
* .active/.is-active, .selected/.is-selected, etc.
    * Use .is-state classnames to demonstrate dynamic components.
* Checkbox: markup has been updated (no wrapper element, class on label element required). Please see Checkboxes section in the Styleguide app. 


# <a id="2.3.1">2.3.1 (2016-04-15)</a>

## Features

Angular UI components

* Moneybar
    * Compact view, in addition to collapsed and expanded views.
    * $nordea-moneybar-palette SCSS variable to change moneybar colors depending on moneybar type. Currently defined colors in palette are temporary placeholders, and will be changed to correct colors, prepare your classes, but don't override colors, yet.
    * Added new field for cardStatus. (is-inactive, is-blocked, etc.) All variations are not known, but there is a SCSS variable to hold them.
    * Card images.
    * `nd-moneybar` can display different transcluded content in expanded and collapsed modes. In addition, it can display transcluded content displayd in both modes.
    * `nd-moneybar` attribute value `collapse-mode="compact"` for displaying a Moneybar in compact, collapsed layout.

Foundation styles

* Variables now exist for $nordea-padding, as we had only $nordea-margin before.
* Grid overlay - For debugging the grid. This is not a perfect solution, but it helps. Use one of these options:
  * Add .debug to any row class to debug that row.
  * Remove .debug from src/foundation-styles/scss/layout/_grid-overlay.scss to get a rough overview of all rows.
* New variables and functionalities availabled from upgrade Foundation 6.2, including foundation-flex-classes.


## Bug fixes

Angular UI components

* constants: `nordeaPalette`
* `nd-notification-set`
    * A directive for displaying (a set) of notification(s). Depending on the notification type, when show, it will float (type='toast') or take space and pushes other elements/contents below it (type='top').
* Moneybar
    * `additional-info` is now displayed in collapsed mode

Foundation styles

* Foundation `row` class: rem-calc not parsed in SCSS, instead it appeared in CSS


## Breaking changes

Angular UI components

* Moneybar
    * Many things with moneybar have changed.
    * Check all alignments.
    * Classnames that were previously run together are now kebab-cased. E.g. moneybar__productnumber -> moneybar__product-number.
    * New features added.
    * Check moneybars for breaks.
    * `nd-moneybar` content to be displayed in expanded mode must be enclosed in element `nd-moneybar-expanded-content` (see documentation for details)
    * `nd-moneybar-container` transcluded content must now be provided in elements `nd-moneybar-container-left-content`, `nd-moneybar-container-right-content`, and `nd-moneybar-container-details`

Foundation styles

* Upgraded Foundation for Sites from version 6.1 to 6.2.
    * changed to flex-grid. If you have used flexbox yourself, you can now use foundation features instead. Meanwhile, make sure your grid is correct.
    * If you are using $primary-color, $secondary-color, $negative-color, $success-, $warning-, or $alert-color directly in your own SCSS, change them to new $foundation-palette variables using map-get.
* `foundation-colors`
    * $foundation-palette wrapper has been introduced for what was previously foundation-colors. If you are using foundation-colors, see these instructions. https://github.com/zurb/foundation-sites/wiki/Upgrading-to-Foundation-6.2


# <a id="2.2.0">2.2.0 (2016-04-01)</a>

## Features

Angular UI components

* Introduced `ndButtonExpand`
    * Button that toggles on click that changes state with icon arrow up and down
* `nd-input-container`
    * Can now contain a `textarea` element. The textarea height is sized automatically.
* `nd-icon` 
    * New size attribute values `l` (64px x 64px) and `xl` (128px x 128px)
    * Icon color can be overridden using CSS `color`
* `nd-date-picker`
    * Bind selected date to model
    * "on change" callback
    * Allow user to pick a any date in the past as well as in the future by default (without limitation)
    * Allow client code to define a function that determines disabled dates (e.g non-banking dates)
    * Easier to use, can be simply use as `<nd-date-picker model="vm.myModel"></nd-date-picker>`
    * Employs input-container component - user can manually type in date string and get validation / datePicker updated at the same time    
    * Less memory intensive and better performance
    * New animation & layout
* `multi-select-buttons`
    * Show different strategies to create multi-select buttons    
* `nd-moneybar`
    * Default collapsed: true
* `nd-moneybar-collection`: A directive for handling a collection of `nd-moneybar` or `nd-moneybar-container` components
    * Collapses others when one is expanded
* `nd-amount`
    * A directive for displaying amounts (formatted e.g. like "12 000,00") 
* Linkable section headers in component demo app

Foundation styles

* Checkbox styles implemented.
* Separated amount labels from labels into span elements with classes
* Icons 
    * Icon color can be overridden using CSS `color`.
    * Styleguide section for icons: Styleguide > Base > Icons.
    * Added new icons for various categories. Please see Styleguide.
* Adopted Foundation button styles.
* Input container: Can now contain an icon.

## Breaking changes

* `nd-icon`
    * Directive now has `replace: true`. If you have applied styles on `nd-icon` change them to `svg.icon`.
* `nd-date-picker`
    * Many changes. Old settings probably won't work anymore.
* `nd-moneybar-container`
    * Attribute `collapsed` removed
    * The collapsed state of the contained `nd-moneybar` now determines the initial collapsed state of the container. Previously it was vice versa.
    
## Bug fixes

* Checkbox: Keyboard navigation and focus state fixed
* `nd-date-picker`
    * still able to navigate around using keyboard even after click on date picker
    * max-date logic is now consistent between odd and even month views
* `nd-moneybar`
    * Two-way data binding of collapsed state did not work. The `collapsed` attribute value was only used as an initial value



# <a id="2.1.0">2.1.0 (2016-03-10)</a>

## Features

Angular UI components

* First version of Moneybar container: combines Moneybar with details section and left and right controls
* moneybar
    * Now accepts number inputs in addition to text as left and right content and main content 
* `nd-icon` directive
    * default size 32x32 px except 16x16 px for icons with prefix `_sml`
    * icon size attribute `s` for 16x16 px, `m` for 32x32 px
* `nd-input-container`: Angular input container
    * Implementation ripped from Angular Material
    * supports `<input>` elements only, not `<textarea>` 
* `nd-date-picker` directive: 1st version of a date picker component

Foundation styles

* Dividers: default, with labels, with button groups
* Labels: default, primary, secondary
* Badges
* Nordea Sans font
* Input container
    * By default takes 100% of width (block element)
    * .input-container--inline modifier for making it an inline block element whose size is determined by the `<input>` element size 


## Breaking changes

* `nd-icon` directive
    * removed size attribute `l`
* Log configuration moved to `core` repository
* Runtime configuration moved to `main-household` repository
    
    
## Bug fixes

* Moneybar recalculates fill percentage when left or right sub-content are updated
* Fluid container ensures maximum width of 1024px for the entire container, including padding



# <a id="2.0.1">2.0.1 (2016-03-03)</a>

## Bug fixes

* Moved package.json dependencies that the package requires to run, especially `foundation-sites`, from `devDependencies` to `dependencies`
    * This enables the use of `_nordea-settings.scss` in other builds



# <a id="2.0.0">2.0.0 (2016-03-02)</a>

## Features

Foundation styles

* Merged "foundation" styles from another repository (foundation CSS, some based on Foundation framework)
   * "Fluid" container that enforces minimum width 1024px and maximum width 1680px'
   * Grid based on flexbox
   * Brand colors
   * Typography: body text, headers, paragraphs, links
   * Buttons: primary, secondary, flat, button groups, negative colors
   * Close button 
   * Multiselect buttons basic CSS
   * Input container CSS: default state, empty state, error state (no Angular)
   * Checkboxes: normal, large, checked vs uncheked states (no animations)
   * "Static" toasts CSS (no Angular integration)   
   * Visibility classes
   * Float classes
* Styleguide app for foundation styles



# <a id="1.1.25">1.1.25 (2016-02-29) and below</a>

## Features

Angular UI components

* `nd-icon` directive and a set of icons
* A basic `nd-avatar` directive
* The first version of the Moneybar 
* Accordion list

Angular infrastructure components

* Angular logging configuration provider
* Runtime configurations for different environments
    * Loaded as Angular constant
    * Configuration chosen during build