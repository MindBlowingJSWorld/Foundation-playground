# Common UI Components for Nordea Digital Banking Web (both for Household & Corporate)

This is a repository for re-usable common components. The idea is to avoid duplications, simplification, ease and speedup development of all teams. Common component can be anything in common; they can be CSS classes, utility functions, contants, services, directives, modules etc.

CI: https://intservices-aite.sed1.root4.net/ci/dbw/job/common/

Public Web: http://ap-rbo1s/#/home

<br/>
## Installing

1. Get the latest package from Nordea's local Npm registry (http://vda1cs0236:4873/)

    `npm install dbw-common --save-dev`

2. Include script in your HTML page (path may vary depending on the file serving mechanism)

    `<script type="text/javascript" src="node_modules/dbw-common/build/dbw-common.js"></script>`

3. Add reference to dbw-common in your AngularJS module definition
    
    `angular.module('Your_app', ['dbw-common']);`

<br/>
## Up and running with common component

1. Clone the repo: `git clone https://Z572108@ccd1is0271.ccd1.root4.net:8443/scm/dbw/common.git`

2. Install dependencies: `npm install`

3. Run the demo app: either issuing `gulp tdd` or just simply `gulp`  

<br/>
## How to add your component

**Short answer**: see other components for examples.

**Long answer**:

The idea is you develop your component under `src`, and add your documentation(s)/demo application(s) under `demo/docs`. This is a bit different from other module repository since common repository is supposed to contain only common components from different domains, but not really a full-fledged, monolithic module/feature. The `demo` only servers as a place for documentation and demo applications (if necessary).

_ Under `src/<component-type>`, create a directory for your component. That is the place where you put all of the files (js, specs, scss, html, ...) that are relevant to that component

_ There may be cases that you find some common functionalities amongst common elements, those can be put under `common` folder.

_ To document your component, see **Painlessly document your components** section below.

<br/>
## Painlessly document your components

1. Under `demo/docs/<component-type>`, add demo folder for your component, named the folder as the one that you put in `demo/src/layout/listService.js`

2. By default, create a `docs.md` and start writing your docs. When you run `gulp`, gulp task will convert all `*.md` to `*.html` with all necessary styling, which will then be visible in the main demo documentation web page

3. To create more docs, just create `docs-<whatevernameuwant>.md` (gitignore will ignore generated `docs*.html` so that's why I recommend you to choose that naming convention where you have a `docs` prefix in the file name), then define that in routing config inside `demo/src/app.js`

<b>Notes: </b> 

_ Currently if you wanna type a heading, you should type it like so `# heading`, not `#heading`.

_ Please use the `demo-header` directive to add a header. It adds an anchor tag and makes your section linkable. E.g. `<demo-header id="ndMoneyBar">Moneybar</demo-header>`.

_ The idea of docs.md is you write something that explains to other people how to use your component. 

_ You may need docs-extra.md if your component needs its own demo application, where there is mocked services/controllers to demonstrate how your component behaves in different scenarios / environments. You may also need to use it if your component, for some reasons, fails to work with the docs.md due to conflicts with the demo application main page.

_ To display your component's API, a good way is to create an API Table. API Table is just plain old Markdown table, only that, you also need to add `<div class="api-table"></div>` and `<div class="api-table-end"></div>` before and after it.

<br/>
## Some most used Gulp tasks

_ `gulp`: Run demo app

_ `gulp <task-name> --sr`: By default, live reload will be on when demo app is run. Run a gulp task with `sr` (static reload) option will disable live reload (user have to manually reload the page to see the changes)

_ `gulp tdd`: Run unit tests and demo app (`tdd` can mean test-develop-demo or test-driven-development)

_ `gulp unit-test`: Run unit tests only (without run demo app)

_ `gulp release`: Release from `develop` branch. For more details, see **Releasing** below.

<br/>
## Releasing

1. Make your changes

2. Make sure your changes is on develop (after pull request etc.)

3. From `develop` branch, issue `gulp release`, by default it will publish a patch version

To release a minor or major version, run `gulp release-minor` or `gulp release-major` correspondingly