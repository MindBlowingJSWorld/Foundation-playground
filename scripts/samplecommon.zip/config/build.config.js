module.exports = {

    DIRS:{
        build: 'build',
        build_images: 'build/images',
        demo: 'demo',
        src: 'src'
    },

    OTHER:{
        gulp : 'gulp/*.js'
    },

    VENDOR: {
        javascript: [
            // Other teams need to include the same dependencies, since this is what our common frame work depends on
            'node_modules/dbw-vendor/dist/vendor.js'
        ],
        mocks: [
            'node_modules/angular-mocks/angular-mocks.js',

            'src/angular-material/**/test/*.js',
            'src/angular-material/**/*.spec.js'
        ]
    },

    SOURCES:{
        // Common-ui
        name:            'dbw-common',
        templates_name:  'dbw-common.tpl',
        javascript_main: 'src/common-ui/dbw-common.js',
        sass :           'src/common-ui/dbw-common.scss',
        all_sass:        'src/common-ui/**/*.scss',
        images:          'src/common-ui/**/*.{png,gif,jpg}',
        svg_icons:       'assets/svg/*',
        javascript:      [
            'src/common-ui/dbw-common.js',
            'src/common-ui/**/*.js'
        ],
        javascript_vendors: [
            'node_modules/foundation-apps/js/angular/services/foundation.core.js',
            'node_modules/foundation-apps/js/angular/services/foundation.core.animation.js',
            'node_modules/foundation-apps/js/angular/components/common/common.js',
            'node_modules/foundation-apps/js/angular/components/modal/modal.js',

            'src/angular-material/**/src/core/**/*.js',
            'src/angular-material/**/src/components/menu/menu.js',
            'src/angular-material/**/src/**/*.js'
        ],
        templates: [
            'src/common-ui/**/*.tpl.html'
        ],
        templates_vendors: [
            'node_modules/foundation-apps/js/angular/**/components/modal/modal.html'
        ],
        specs :          [
            'src/common-ui/**/*.spec.js'
        ],
        specs_vendors: [
            'src/angular-material/**/test/**/*.js',
            'src/angular-material/**/*.spec.js'
        ]
        
    },

    DEMO: { // Or BUILD
        name:       'commonElements.demo',
        all_src:    'demo/common-ui/src/**/*.*',
        docs:       'demo/common-ui/docs/**/*.md',
        docs_tpl:   'demo/common-ui/src/template.hbs',
        sass:       'demo/common-ui/**/*.scss',
        // Get injected to index.tpl.html
        javascript:[
            //inject in reverse order, meaning FILO
            'demo/common-ui/docs/**/*.js',
            'demo/common-ui/src/**/*.js',
            'demo/build/**/*.js'
        ],
        vendor_js:[
            // Only vendor files specific to demo. Others are in VENDOR property
        ],
        css: [
            // FIFO
            'demo/build/**/*.css',
            'demo/common-ui/src/**/*.css'
        ]
    }
};
