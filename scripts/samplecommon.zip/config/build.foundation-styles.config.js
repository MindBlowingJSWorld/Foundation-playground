module.exports = {
    distName: 'dbw-foundation-nordea',
    browserCompatibility: ['last 2 versions', 'ie >= 10'],
    sass: {
        dir: './src/foundation-styles/scss',
        main: './src/foundation-styles/scss/styles.scss',
        all: ['./src/foundation-styles/scss/**/*.scss']
    },
    javascript: [
        './node_modules/foundation-sites/js/foundation.core.js',
        './node_modules/foundation-sites/js/foundation.util.*.js',
        './node_modules/foundation-sites/js/foundation.toggler.js'
    ],
    images: './src/foundation-styles/images/**/*',
    fonts: './src/foundation-styles/scss/base/fonts/**/*.*',
    dist: {
        mainDir: './build',
        imgDir: './build/images',
        fontDir: './build/fonts'
    },
    styleguide: {
        htmlDocs: './src/foundation-styles/scss/**/*.html',
        overview: './src/foundation-styles/scss/styleguide.md',
        outputDir: './demo/foundation-styles',
        resources: [
            './node_modules/jquery/dist/jquery.js',
            './node_modules/what-input/what-input.js',
            './node_modules/svg4everybody/dist/svg4everybody.min.js',
            './src/foundation-styles/js/init-foundation.js',
            './src/foundation-styles/scss/base/**/fonts/**/*.*'
        ]
    }
}
;