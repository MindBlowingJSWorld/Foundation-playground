var _ = require('lodash');
var glob = require('glob');
var joinPath = require('join-path');
var build_config = require('../config/build.config.js');
var sourceFiles = [];

_.each(_.flatten([build_config.SOURCES.javascript_vendors, build_config.SOURCES.javascript]), function(pattern) {
    pattern = joinPath(__dirname, '../', pattern);
    sourceFiles = sourceFiles.concat(glob.sync(pattern, {ignore: '**/*.spec.js'}));
});

module.exports = function(karma) {
    karma.set({
        frameworks: ['jasmine'],
        browsers: ['PhantomJS'],
        basePath: '../',
        files: _.flattenDeep([
            build_config.VENDOR.javascript,
            build_config.VENDOR.mocks,
            sourceFiles,
            build_config.SOURCES.templates_vendors,
            build_config.SOURCES.templates,
            build_config.SOURCES.specs_vendors,
            build_config.SOURCES.specs
        ]),
        exclude: [],
        port: 9018, // port browser connects
        runnerPort: 9100, //port test runner operates
        urlRoot: '/',
        reporters: ['dots', 'progress', 'coverage'],
        logLevel: karma.LOG_DEBUG,
        preprocessors: {
            '**/*.html': 'ng-html2js',
            'src/common-ui/**/!(spec).js': ['coverage']
        },
        angularFilesort: {
            whitelist: [
                'src/**/*.js'
            ]
        },
        ngHtml2JsPreprocessor: {
            stripPrefix: 'src/common-ui/',
            moduleName: build_config.SOURCES.templates_name
        },

        coverageReporter: {
            dir: 'reports/coverage',
            reporters: [
                {type: 'cobertura', subdir: 'cobertura'},
                {type: 'html', subdir: 'html'},
                {type: 'lcov', subdir: 'lcov'}
            ]
        }

    });
};