var _ = require('lodash');
var build_config = require('../config/build.config.js');


module.exports = function (karma) {
    karma.set({
        frameworks: ['jasmine'],
        browsers: process.platform === 'win32' ? ['Chrome', 'PhantomJS', 'IE', 'Firefox'] : ['PhantomJS', 'Firefox'],
        basePath: '../',
        files: _.flattenDeep([
            build_config.VENDOR.javascript,
            build_config.VENDOR.mocks,
            build_config.DIRS.build + '/**/*.js',
            build_config.SOURCES.specs_vendors,
            build_config.SOURCES.specs
        ]),
        exclude: [],
        port: 9018, // port browser connects
        runnerPort: 9100, //port test runner operates
        urlRoot: '/',
        reporters: ['dots', 'progress', 'coverage'],
        logLevel: karma.LOG_DEBUG,
        singleRun: true,
        autoWatch: false,
        preprocessors: {
            'src/common-ui/**/!(spec).js': ['coverage']
        },
        coverageReporter: {
            dir: 'reports/coverage',
            reporters: [
                {type: 'cobertura', subdir: 'cobertura'},
                {type: 'html', subdir: 'html'},
                {type: 'lcov', subdir: 'lcov'}
            ]
        }
    });
};