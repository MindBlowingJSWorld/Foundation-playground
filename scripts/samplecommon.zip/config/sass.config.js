module.exports = {
    includePaths: [
        './node_modules/foundation-sites/scss',
        './node_modules/motion-ui/src',
        './node_modules'
    ],
    errLogToConsole: true
};