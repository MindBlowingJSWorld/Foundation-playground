'use strict';

angular.module('commonElements.demo')
    .factory('MockedNonBankingDaysService', MockedNonBankingDaysService)
    .factory('MockedNonAdvisorDaysService', MockedNonAdvisorDaysService)
    .controller('DatePickerExampleController', DatePickerExampleController);

function MockedNonBankingDaysService($q, $timeout, $log) {

    return {
        getNonBankingDays: getNonBankingDays
    };

    function getNonBankingDays(from, to) {
        var deferredDisabledDates = $q.defer();
        var disabledDates = [];
        from = moment(from).format('YYYY-MM-DD');
        to = moment(to).format('YYYY-MM-DD');

        // Incomplete logic, hard-coded, but will do for demo
        if (from === '2016-04-01' && to === '2016-04-30') {
            disabledDates = [
                '2016-04-21',
                '2016-04-22',
                '2016-04-23'
            ];
        } else if (from === '2016-05-01' && to === '2016-05-31') {
            disabledDates = [
                '2016-05-01',
                '2016-05-02',
                '2016-05-03'
            ];
        }

        $timeout(function () {
            $log.debug('Non banking dates resolved: ', disabledDates);
            deferredDisabledDates.resolve(disabledDates);
        }, 2000, false);

        return deferredDisabledDates.promise;
    }


}


function MockedNonAdvisorDaysService($q, $log) {

    return {
        getNonAdvisorDates: getNonAdvisorDates
    };

    function getNonAdvisorDates(from, to) {
        var deferredDisabledDates = $q.defer();
        from = moment(from).format('YYYY-MM-DD');
        to = moment(to).format('YYYY-MM-DD');
        var disabledDates = [];

        if (from === '2016-04-01' && to === '2016-04-30') {
            disabledDates = [
                '2016-04-18',
                '2016-04-19',
                '2016-04-20'
            ];
        }
        // In case of 2 months view.
        if (from === '2016-03-01' && to === '2016-04-30') {
            disabledDates = [
                '2016-04-18',
                '2016-04-19',
                '2016-04-20'
            ];

        }

        $log.debug("Non advisor dates resolved: ", disabledDates);
        deferredDisabledDates.resolve(disabledDates);

        return deferredDisabledDates.promise;
    }
}

function DatePickerExampleController(MockedNonBankingDaysService, MockedNonAdvisorDaysService, $q, $scope) {
    var _this = this;

    _this.getDisabledDates = function (from, to) {

        var nonAdvisorDaysPromise = MockedNonAdvisorDaysService.getNonAdvisorDates(from, to),
            nonBankingDaysPromise = MockedNonBankingDaysService.getNonBankingDays(from, to);

        return $q.all([nonAdvisorDaysPromise, nonBankingDaysPromise]).then(function (res) {
            var finalResult = res[0].concat(res[1]);
            return finalResult;
        });
    };

    _this.getNonAdvisorDates = function (from, to) {
        return MockedNonAdvisorDaysService.getNonAdvisorDates(from, to).then(function (res) {
            return res;
        });
    };

    _this.onChange = function (data) {
        console.log('onChange parameter: ', data, 'or arguments', arguments);
    };

}