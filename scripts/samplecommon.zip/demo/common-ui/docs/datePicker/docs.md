## Usage

<div class="api-table"></div>

| Attributes        | Definition                                                                                                                                                                                                                                                                                                                                                                                                                                                |
|-------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| model             | The date model. The value is a string formatted according to `date-format`.                                                                                                                                                                                                                                                                                                                                                                               |
| date-format       | Format of the date. Date formats supported by momentjs. Default: `YYYY-MM-DD`.                                                                                                                                                                                                                                                                                                                                                                            |
| on-change         | Pass in a call back of your choice like so `on-change = myCallBack(data)`. It will be executed whenever the user interacts with datePicker (select a date, click `ok` or `cancel`). The `data` parameter has the following format: `{selectedDate: <selected date as string pattern YYYY-MM-DD>, event: <"select", "ok" or "cancel">}`. |
| month-view-count  | Number of months to be displayed to the user. (`1` or `2`). Default: `1`.                                                                                                                                                                                                                                                                                                                                                                                 |
| max-date-range    | Limiting the selectable calendar days from today (current day) into the future. Numeric value in terms of months.                                                                                                                                                                                                                                                                                                                                         |
| min-date-range    | Limiting the selectable calendar days from today (current day) into the past. Numeric value in terms of months.                                                                                                                                                                                                                                                                                                                                           |
| position          | The position of the fixed corner of the date picker panel.<br/>This controls to which direction the panel opens. Allowed values `top left` (default), `top right`, `bottom left`, `bottom right`.                                                                                                                                                                                                                                                         |
| get-disabled-days | An optional callback `function(from, to)` that returns a promise of an array that contains dates (ISO date strings or moment.js objects) to be disabled within date range `from` and `to` inclusive. <br/> The `from` and `to` arguments are moment.js objects.                                                                                                                                                                                           |

<div class="api-table-end"></div>

To add a calendar icon that pops up a date picker and binds the selected date to your model:
    
    <nd-date-picker model="vm.myDate"></nd-date-picker>

Result: <nd-date-picker model="vm.myDate"></nd-date-picker>.

Alternatively, you can make any element pop up a date picker by wrapping a date picker around it. For example
    
    <nd-date-picker model="myDate">{{myDate}}</nd-date-picker>

Result: <nd-date-picker model="myDate">{{myDate}}</nd-date-picker>

Just don't enclose elements that handle clicks within a date picker. Date picker takes over click handling. 

## Non-banking Days

Module `dbw-core` starting from version `0.2.32` includes `NonBankingDaysService`, which you can use to set non-banking
days on the date picker widget.

For example, you can have the following in your template:
```html
    <nd-date-picker get-disabled-days="vm.getNonBankingDays"></nd-date-picker>
```

And your controller:
```javascript
function MyController(NonBankingDaysService) {
    var vm = this;
    
    vm.getNonBankingDays = getNonBankingDays;
    
    function getNonBankingDays(from, to) {
        return NonBankingDaysService.getNonBankingDays(from, to);
    }

    ...
}
```

## Notes

* Keyboard navigation: Left, Right, Up, Down, Enter, Escape.
* Month name, first day of week, etc. depend on the global locale settings of moment.js. Date picker does not modify them. They should be application settings.

## Examples

Examples: <a ui-sref="ndDatePicker">See more examples of date pickers here</a><br>





