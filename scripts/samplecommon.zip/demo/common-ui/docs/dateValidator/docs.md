A constructor to create ndDateValidator object, which provides a set of API to validate a date.

### Usage

Include ndDateValidatorFactory as a dependency. Then create an instance of ndDateValidator like so:

    var ndDateValidator = ndDateValidatorFactory.createDateValidator(maxDateRange, minDateRange, dateFormat);

maxDateRange, minDateRange, dateFormat are **optional**.

<div class="api-table"></div>

| Methods                | Parameters Type                                         | Definition                                                                                             |
|------------------------|---------------------------------------------------------|--------------------------------------------------------------------------------------------------------|
| maxDateRange           | date string / date object / moment date object / number | See setMaxDateRange below                                                                              |
| minDateRange           | date string / date object / moment date object / number | See setMinDateRange below                                                                              |
| dateFormat             | string. Default: 'YYYY-MM-DD'                           | Format of the date supported for display. Date formats supported by momentjs. Default: 'YYYY-MM-DD'    |

<div class="api-table-end"></div>

<p></p>

You can also get / set max and min date range even after you create the ndDateValidator instance like so:
    
    ndDateValidator.setMinDateRange(maxDateRange);
    ndDateValidator.setMinDateRange(minDateRange);
    
Then after that you can validate a date to see whether it is within a range:

    ndDateValidator.isWithinAvailableRange(moment(today)); // return true / false

ndDateValidator API

[//]: # (It is recommended that you edit these tables by upload the corresponding dateVlidator-api tgn files to http://www.tablesgenerator.com/markdown_tables)

<div class="api-table"></div>

| Methods                | Parameters Type                                         | Definition                                                                                                                                                                                                                                                                                                                                                                                          |
|------------------------|---------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| setDisabledDates       | date string array                                       | Set an array of disabled days                                                                                                                                                                                                                                                                                                                                                                       |
| addDisabledDate        | string                                                  | Add a single date string to disabledDates array                                                                                                                                                                                                                                                                                                                                                     |
| addDisabledDates       | date string array                                       | Add an array of date strings to disabledDates array                                                                                                                                                                                                                                                                                                                                                 |
| resetDisabledDates     |                                                         | Make the disable days become an empty array                                                                                                                                                                                                                                                                                                                                                         |
| getMaxDateRange        |                                                         | Get max date which is set by setMaxDate                                                                                                                                                                                                                                                                                                                                                             |
| setMaxDateRange        | date string / date object / moment date object / number | Set the maxDate and maxDateRange.<br/><br/> maxDateRange: the number of months ahead of the current date.<br/><br/> maxDate: the upperbound date (in ndDateValidator date range).<br/><br/>   If parameter is a number, maxDateRange will be set in term of months.<br/><br/>  If the parameter is a date string, date object or moment date object, maxDate will be set.<br/><br/>   maxDate can be calculated based on maxDateRange and vice versa. |
| getMinDateRange        |                                                         | Get min date which is set by setMinDate                                                                                                                                                                                                                                                                                                                                                             |
| setMinDateRange        | date string / date object / moment date object / number | Same as setMaxDateRange, but for minDate and minDateRange.                                                                                                                                                                                                                                                                                                                                          |
| setFormat              | string                                                  | Set the date format (that reckoned by moment, e.g 'DD-MM-YY')                                                                                                                                                                                                                                                                                                                                       |
| isSameDate             | date object 1, date object 2                            | Set min date                                                                                                                                                                                                                                                                                                                                                                                        |
| isToday                | date object                                             | Check if a date is today                                                                                                                                                                                                                                                                                                                                                                            |
| isWeekend              | date object                                             | Check if a date is weekend day (Saturday or Sunday)                                                                                                                                                                                                                                                                                                                                                 |
| isPastDate             | date object                                             | Check if a date is before today                                                                                                                                                                                                                                                                                                                                                                     |
| isBeforeMaxDate        | date object                                             | Check if a date is before max date, which is defined by maxDateRange                                                                                                                                                                                                                                                                                                                                |
| isAfterMinDate         | date object                                             | Check if a date is after min date, which is defined by minDateRange                                                                                                                                                                                                                                                                                                                                 |
| isWithinAvailableRange | date object                                             | Check if a date is within available min and max date range                                                                                                                                                                                                                                                                                                                                          |
| isValidDate            | date object                                             | Check if the string can be parsed to a real date object                                                                                                                                                                                                                                                                                                                                             |

<div class="api-table-end"></div>

Some utility functions which are used internally inside ndDatevalidator (which could also be used publicly)

<div class="api-table"></div>

| Methods               | Parameters Type | Definition                                                                                                                                                                                       |
|-----------------------|-----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| convertStringToMoment | date object     | convert a date string to date string, using the date format that is set by setFormat or the default one , which is 'YYYY-MM-DD'. Return undefined if the dateString does not match date pattern. |
| isNonEmptyString      | string          | check if a string is not empty                                                                                                                                                                   |
| isScandinavianLocale  | string          | check if a string is a Scandinavian Locale eg. se,fi,dk,no,sv,da                                                                                                                                 |
| isAcceptedDatePattern | string          | check if a string has a valid date pattern                                                                                                                                                       |

<div class="api-table-end"></div>

### Notes
    
The date picker is heavily relied on this, and any date related components can also use this one in its implementation. Check out the source code of ndDateValidator to see what kind of methods it provides. And feel free to contribute to it if you feel there is something needed to be added.

