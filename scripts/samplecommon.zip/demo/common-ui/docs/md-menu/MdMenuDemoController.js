'use strict';

angular.module('commonElements.demo')
    .controller('MdMenuDemoController', MdMenuDemoController)
    .config(configureModal);

function MdMenuDemoController($log, ModalService) {
    var vm = this;

    vm.triggerMenuItem = triggerMenuItem;
    vm.openModal = openModal;
    

    function triggerMenuItem(text, $event) {
        alert(text);
        $log.debug($event);
    }

    function openModal() {
        ModalService.open('mdMenuInModal');
    }
    
}

function configureModal(ModalServiceProvider) {
    ModalServiceProvider.register('mdMenuInModal', {
        controller: 'MdMenuDemoController as vm',
        templateUrl: 'common-ui/docs/md-menu/modal-with-menu.tpl.html'
    });
}