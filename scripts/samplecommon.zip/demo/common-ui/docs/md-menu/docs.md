The [md-menu](https://material.angularjs.org/1.0.8/api/directive/mdMenu) component is taken from Angular Material.
 
Basic use

    <md-menu>
        <button type="button" class="button button--icon-left flat" aria-label="Open menu" ng-click="$mdOpenMenu($event)">
            <nd-icon icon="home" size="s"></nd-icon> Open menu
        </button>
        <md-menu-content>
            <md-menu-item>
                <button class="md-button" ng-click="vm.triggerMenuItem1()">Item 1</button>
            </md-menu-item>
            <md-menu-item>
                <button class="md-button" disabled="disabled" ng-click="vm.triggerMenuItem2()">
                    <nd-icon icon="boat"></nd-icon> Item 2
                </button>
            </md-menu-item>
            <md-menu-divider></md-menu-divider>
            <md-menu-item>
                <button class="md-button" ng-click="vm.triggerMenuItem3()">
                    <nd-icon icon="income"></nd-icon> Item 3
                </button>
            </md-menu-item>
        </md-menu-content>
    </md-menu>
    
<md-menu>
    <button type="button" class="button button--icon-left flat" aria-label="Open menu" ng-click="$mdOpenMenu($event)">
        <nd-icon icon="home" size="s"></nd-icon> Open menu
    </button>
    <md-menu-content>
        <md-menu-item>
            <button class="md-button" ng-click="vm.triggerMenuItem1()">Item 1</button>
        </md-menu-item>
        <md-menu-item>
            <button class="md-button" disabled="disabled" ng-click="vm.triggerMenuItem2()">
                <nd-icon icon="boat"></nd-icon> Item 2
            </button>
        </md-menu-item>
        <md-menu-divider></md-menu-divider>
        <md-menu-item>
            <button class="md-button" ng-click="vm.triggerMenuItem3()">
                <nd-icon icon="income"></nd-icon> Item 3
            </button>
        </md-menu-item>
    </md-menu-content>
</md-menu>

More <a ui-sref="mdMenu">md-menu examples</a>. 