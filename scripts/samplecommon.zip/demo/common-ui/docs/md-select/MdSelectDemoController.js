'use strict';

angular.module('commonElements.demo')
    .controller('MdSelectDemoController', MdSelectDemoController);


function MdSelectDemoController($timeout, $element) {
    var vm = this;

    vm.init = init();
    vm.loadUsers = loadUsers;
    vm.clearSearchTerm = clearSearchTerm;
    vm.displayFavoriteColor = displayFavoriteColor;

    init();

    function init() {
        vm.states = ('AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS ' +
        'MO MT NE NV NH NJ NM NY NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI ' +
        'WY').split(' ').map(function (state) { return { abbrev: state }; });

        vm.toppings = [
            { category: 'meat', name: 'Pepperoni' },
            { category: 'meat', name: 'Sausage' },
            { category: 'meat', name: 'Ground Beef' },
            { category: 'meat', name: 'Bacon' },
            { category: 'veg', name: 'Mushrooms' },
            { category: 'veg', name: 'Onion' },
            { category: 'veg', name: 'Green Pepper' },
            { category: 'veg', name: 'Green Olives' }
        ];

        vm.vegetables = ['Corn' ,'Onions' ,'Kale' ,'Arugula' ,'Peas', 'Zucchini'];

        $element.find('.demo-header-searchbox').on('keydown', function(e) {
            e.stopPropagation();
        });
    }

    function loadUsers() {
        // Use timeout to simulate a 1500 ms request.
        return $timeout(function () {
            vm.users = vm.users || [
                    {id: 1, name: 'Scooby Doo'},
                    {id: 2, name: 'Shaggy Rodgers'},
                    {id: 3, name: 'Fred Jones'},
                    {id: 4, name: 'Daphne Blake'},
                    {id: 5, name: 'Velma Dinkley'}
                ];
        }, 1500);
    }


    function clearSearchTerm() {
        vm.searchTerm = '';
    }

    function displayFavoriteColor() {
        if (vm.favoriteColor) {
            return 'Your favorite color is ' + vm.favoriteColor;
        } else {
            return 'Please select your favorite color';
        }
    }

}