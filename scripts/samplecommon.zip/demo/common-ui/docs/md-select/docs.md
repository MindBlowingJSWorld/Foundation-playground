The [md-select](https://material.angularjs.org/1.0.8/api/directive/mdSelect) component is taken from Angular Material.
It can be used within an `nd-input-container` or without a container. Using it in an `nd-input-container` enables the use of labels, error messages, etc.

Basic use

    <nd-input-container>
        <label>Color</label>
        <md-select ng-model="selectDemoModel">
            <md-option value="black">Black</md-option>
            <md-option value="other">Other</md-option>
        </md-select>
    </nd-input-container>
   
<nd-input-container>
    <label>Color</label>
    <md-select ng-model="selectDemoModel" required>
        <md-option value="black">Black</md-option>
        <md-option value="other">Other</md-option>
    </md-select>
</nd-input-container>       
 
More <a ui-sref="mdSelect">md-select examples</a>.