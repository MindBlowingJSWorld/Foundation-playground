# Custom modal

## Usage

<a class="button" ng-click="vm.openModal()">Open modal</a>

```html
<a class="button" ng-click="vm.openModal()">Open modal</a>
```

## How to create custom modal

__Note: you don't have to follow this order strictly, order is up to you.__ Modal uses [Foundation for Apps](http://foundation.zurb.com/apps/docs/#!/modal) and custom provider `zfaModalProvider`.

1) Set up your controller to use modal:

```javascript
angular.module('dbw-common')
    .controller('PageExampleController', PageExampleController);

    function PageExampleController(ModalService) { // <-- inject modal provider into controller

        var vm = this;

        vm.openModal = function () {

        var modalPromise = ModalService.open('exampleModal', {
            exampleGreeting: 'Good morning!'
        });

        modalPromise.then(function (res) { // <-- example of handling promises
            vm.result = res;
        })
        .catch(function (rej) {
            vm.result = rej;
        });
        }
    }
```

2) Define provider's config of your modal. You are free to choose any name of the modal, controller, template and local variables:

```javascript
angular.module('dbw-common')
    .controller('ModalExampleController', ModalExampleController)
    .config(function(ModalServiceProvider) {

        ModalServiceProvider.register('exampleModal', { // <-- modal name
            controller: 'ModalExampleController', // <-- link to modal controller
            templateUrl: 'common-ui/docs/modal/exampleModal.tpl.html', // <-- link to modal template
            locals: {
                exampleGreeting: '' // <-- injection locals for modal controller
            }
        });
    });
```

As you noticed, we use ModalService wrapper (it wraps modal provider). Here are details about it.

<div class="api-table"></div>

|      Attributes      | Definition                                                                                                                                     |
|:--------------------|------------------------------------------------------------------------------------------------------------------------------------------------|
| ModalServiceProvider | Inject it into the .config of your custom modal                                                                                                |
| register (controller, templateUrl, locals);| Method that registers custom modal in .config. You also define modal name here. See example above                                              |
|&emsp;&emsp;&emsp;&emsp;&emsp; controller: | Link to modal controller                                                                                          |
|&emsp;&emsp;&emsp;&emsp;&emsp; templateUrl: | Link to modal template                                                                                            |
|&emsp;&emsp;&emsp;&emsp;&emsp; locals: | Injection locals for modal controller                                                                              |
| ModalService         | Inject it into your custom controller to be able to use provider                                                                               |
|&emsp;&emsp;&emsp;&emsp;&emsp; open(); | Method that is used to push values from your custom controller to modal provider. Requires modal name and local-value pairs. See example above |

<div class="api-table-end"></div>


3) Set up modal controller this way:

```javascript
function ModalExampleController($scope, exampleGreeting, zfaModalDefer) {
    $scope.exampleGreeting = exampleGreeting; // <-- $scope locals you may need in modal

    $scope.send = function (input) {
        zfaModalDefer.resolve(input); // <-- zfaModalDefer.resolve - resolve promise
    };

    $scope.close = function () {
        zfaModalDefer.reject($scope.exampleGreeting); // <-- zfaModalDefer.reject - reject promise
    }
}
```

Use `zfaModalDefer.resolve();` and `zfaModalDefer.reject();` inside modal controller to close modal programmatically.

4) Set up modal template this way:

```html
<div zf-modal="" class="example-modal">  <!-- <-- your modal name, which you defined in .config -->
    <button class="close-button" aria-label="Close alert" type="button" zf-close>
        <span aria-hidden="true">&times;</span>
    </button>
    <h3>This is an example modal</h3>
        <p>
            Enter some text here and press OK:
            <input type="text" ng-model="input">
        </p>
        <p>Otherwise you can cancel it. </p>
        <a class="button primary" ng-click="send(input)">OK</a>
        <a class="button primary" ng-click="close()">Cancel</a>
</div>
```

__Note: don't use `zf-modal` attribute in the same tag with `row` attribute (it comes from grid)__. Remember to include `zf-modal` attribute to parent tag of your template. Besides it, there is set of predefined attributes, which you are free to use inside modal templates. Check also Foundation for Apps [site](http://foundation.zurb.com/apps/docs/#!/modal).
* zf-close
* zf-open
* zf-toggle
* zf-esc-close
* zf-swipe-close
* zf-hard-toggle
* zf-close-all

5) Change styling of modal:

```
.example-modal { // <-- styling of overlay
  .modal { // <-- styling of modal
  }
}
```