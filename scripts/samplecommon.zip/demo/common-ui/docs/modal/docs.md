<div ng-controller="PageExampleController as vm">
    <a class="button" ng-click="vm.openModal()">Open modal</a>
    <p>Modal promise result: {{ vm.result }}</p>
</div>

## How to create custom modal

See example <a ui-sref="modal">here</a>.
