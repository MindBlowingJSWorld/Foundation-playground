'use strict';

angular.module('commonElements.demo')
    .controller('PageExampleController', PageExampleController)
    .controller('ModalExampleController', ModalExampleController)
    .config(function (ModalServiceProvider) {
        ModalServiceProvider.register('exampleModal', {
            controller: 'ModalExampleController',
            templateUrl: 'common-ui/docs/modal/exampleModal.tpl.html',
            locals: {
                exampleGreeting: ''
            }
        });
    });

function PageExampleController(ModalService) {

    var vm = this;

    vm.openModal = function () {

        var modalPromise = ModalService.open('exampleModal', {
            exampleGreeting: 'you just cancelled the modal.'
        });

        modalPromise.then(function (res) {
                vm.result = res;
            })
            .catch(function (rej) {
                vm.result = rej;
            });
    }
}

function ModalExampleController($scope, exampleGreeting, zfaModalDefer) {
    $scope.exampleGreeting = exampleGreeting;

    $scope.send = function (input) {
        zfaModalDefer.resolve(input);
    };

    $scope.close = function () {
        zfaModalDefer.reject($scope.exampleGreeting);
    }
}