'use strict';

angular.module('commonElements.demo')
  .controller('MoneybarContainerExampleController', MoneybarContainerExampleController);

function MoneybarContainerExampleController($scope, $log){
  $scope.dueDate = new Date();
  $scope.name = 'MoneybarContainerExampleController';
  $scope.loanData = 'This is data';
  $scope.logGreeting = function(nbr) {
    $log.info('Hi from', nbr);
  };

  // Create data for three moneybars
  $scope.allData = [
    {
      id: 1,
      loanData : 'Loan data 1',
      savingsData : 'Savings data 1',
      dueDate : new Date(),
      title: 'My VISA card',
      subtitle : '9854 **** **** 1048',
      type : 'cards-credit',
      maincontent : '1 250,00',
      subcontentLeft : '3 000,00',
      subcontentRight : '7 000,00',
      details : 'Details for number 1',
      isCollapsed : false
    },{
      id: 2,
      loanData : 'Loan data 2',
      savingsData : 'Savings data 2',
      title: 'Grundkonto',
      subtitle : '45 1234 5678 0000 4567 1234',
      type : 'accounts',
      cardStatus : 'Blocked',
      maincontent : '10 000,00',
      subcontentLeft : '6 000,00',
      subcontentRight : '4 000,00',
      details : 'Details for number 2',
      isCollapsed : true
    },{
      id: 3,
      loanData : 'Loan data 3',
      savingsData : 'Savings data 3',
      title: 'My debit card',
      subtitle : '1048 **** **** 9854',
      type : 'cards-debit',
      cardStatus : 'New!',
      subcontentRight : '16 800,00',
      details : 'Details for number 3',
      attachedInfo: 'Grundkonto 10 ... 7557 6556',
      isCollapsed : true
    }
  ];
}

