'use strict';

angular.module('commonElements.demo')
  .config(configureCustomMoneybar);

function configureCustomMoneybar(MoneybarServiceProvider) {
  MoneybarServiceProvider.configureTypes({
    'demo-type': {
      maincontent: 'Title of main content',
      subcontentLeft: 'Title of left sub-content',
      subcontentRight: 'Title of right sub-content',
      subcontentTopRight: 'Title of top right sub-content',
      hasDueDate: false
    }
  });
}