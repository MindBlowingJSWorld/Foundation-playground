The public interface of Moneybar includes the following components: 

* `nd-moneybar`: The base component. Takes input and displays it in the correct locations.
* `nd-moneybar-container`: (Optional) Wraps a single `nd-moneybar` and adds additional elements and controls (Loan bar, Savings bar and Details). 
* `nd-moneybar-collection`: (Optional) Wraps multiple `nd-moneybar` or `nd-moneybar-collection` components. Handles collapsing others when one is expanded.  
* `MoneybarServiceProvider`: Configuration of Moneybar types

##  Moneybar usage

    <nd-moneybar
        collapsed="vm.collapsed"
        collapse-mode="vm.collapseMode"
        title="vm.accountName" 
        subtitle="vm.accountNumber" 
        type="vm.moneybarType"
        maincontent="vm.total" 
        maincontent-title="custom title for main content to be used without maincontent"
        subcontent-left="vm.spentAmount" 
        subcontent-right="vm.availableToSpend"
        due-date="vm.dueDate">
       
        <nd-moneybar-expanded-content> ... </nd-moneybar-expanded-content>
        <nd-moneybar-collapsed-content> ... </nd-moneybar-collapsed-content>
        <nd-moneybar-static-content> ... </nd-moneybar-static-content>
        
    </nd-moneybar>

See <a ui-sref="moneybar">examples of individual moneybars</a>. 

The Moneybar has two main modes: collapsed and expanded. By default it is collapsed. When you click on an individual Moneybar, the mode toggles. 
The attribute is watched so it can also be changed programmatically. If `collapse-mode` evaluates to string `compact`, the Moneybar is displayed
in a small collapsed mode (see <a ui-sref="moneybar">examples</a>). In the collapsed mode, the Moneybar displays like an element in a list.
 
The expanded and collapsed modes can be supplied with optional transcluded content, such as buttons or dividers, in elements 
`nd-moneybar-expanded-content` and `nd-moneybar-collapsed-content`. The content appears inside the `nd-moneybar` element after all its other content.
See examples <a ui-sref="moneybar-container">here</a>.

Furthermore, an optional `nd-moneybar-static-content` element can be used for providing content for both modes. 
It appears after both `nd-moneybar-expanded-content` and `nd-moneybar-collapsed-content`. You can access the expanded/collapsed status 
in your transcluded content by referring to variable `$parent.ctrl.collapsed` (yourScope.$parent.ctrl.collapsed). This way you can build more 
customized behavior depending on the expanded/collapsed state into the `nd-moneybar-static-content` element. 

Event propagation is stopped for all of the three contents, so that clicking a button inside the content works, but the moneybar does not "know"
that is has been clicked and therefore does not collapse. If you need clicking a button/link within you content to also collapse the moneybar, 
you need to collapse it programmatically.


##  Moneybar Container usage

     <div ng-repeat="data in allData">
         <nd-moneybar-container>
             <nd-moneybar title="data.title" 
                          subtitle="data.subtitle" 
                          type="data.type" 
                          due-date="data.dueDate"
                          maincontent="data.maincontent" 
                          subcontent-left="data.subcontentLeft" 
                          subcontent-right="data.subcontentRight">     
                <nd-moneybar-expanded-content>             
                     <div class="moneybar__buttons divider">
                         <button type="button" 
                                 class="button colors-negative" 
                                 ng-click="logGreeting('A-'+data.id)">
                                    Button 1
                         </button>
                         <button type="button"
                                 class="button colors-negative" 
                                 ng-click="logGreeting('B-'+data.id)">
                                    Button 2
                         </button>
                         <button type="button" 
                                 class="button colors-negative"
                                 ng-click="logGreeting('C-'+data.id)">
                                    Button 3
                         </button>
                     </div>
                <nd-moneybar-expanded-content>
             </nd-moneybar>
             <nd-moneybar-container-left-content>Loan data</nd-moneybar-container-left-content>
             <nd-moneybar-container-right-content>Savings data</nd-moneybar-container-right-content>
             <nd-moneybar-container-details>Hello from details!</nd-moneybar-container-details>
         </nd-moneybar-container>
     </div>

The collapsed state of a Moneybar Container depends fully on the state of the contained Moneybar.

<a ui-sref="moneybar-container">See a working example of Moneybar Container here</a>.

## Moneybar Collection usage

    <nd-moneybar-collection close-others="vm.closeOthers">
        ...
    </nd-moneybar-collection>

<a ui-sref="moneybar-container">See a working example of Moneybar Collection here</a>.

## Moneybar configuration

You can use `MoneybarServiceProvider.configureMyTypes(config)` to set up new Moneybar types and their data placeholder titles or customize existing types. 
The keys of the `config` hash correspond to `nd-moneybar` `type` attribute values. Type values are objects as shown in the example below.
 Default configurations exists for most moneybar types (See <a ui-sref="moneybar">here</a>). You do not need to provide all the titles for those that have defaults.
Also, you can leave a title empty if it's not applicable or no title should be displayed.
  
    angular.module('my-module')
      .config(configureMyTypes);
      
    function configureMyTypes(MoneybarServiceProvider) {
        MoneybarServiceProvider.configureTypes({
            'my-moneybar-type': {
                maincontent: 'Title of main content',
                subcontentLeft: 'Title of left sub-content',
                subcontentRight: 'Title of right sub-content',
                subcontentTopRight: 'Title of top right sub-content',
                hasDueDate: true // If true, this type uses the nd-moneybar due-date attribute and displays it in the main content.
            }
        });
    }