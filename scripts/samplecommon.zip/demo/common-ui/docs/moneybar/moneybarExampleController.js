'use strict';

angular.module('commonElements.demo')
  .controller('MoneybarExampleController', MoneybarExampleController);

function MoneybarExampleController($scope){
  $scope.type = 'demo-type';
  $scope.title = 'Grundkonto';
  $scope.subtitle = '45 1234 5678 0000 4567 1234';
  $scope.maincontent = 12000;
  $scope.subcontentLeft = 5000;
  $scope.subcontentRight= 7000;
  $scope.subcontentTopRight = 'Top right content';
  $scope.isCollapsed = true;
  $scope.collapseMode = undefined;
}

