## Multiselect using checkbox

<p>Using checkboxes for multiselect allows for multiple options to be selected at once.</p>

    <div class="button-group button-multiselect">
        <label class="button" ng-class="{'is-active': vm.checkboxModel.opt1}">
            <input type="checkbox" ng-model="vm.checkboxModel.opt1"/>Option 1 {{vm.opt1}}
        </label>
        <label class="button" ng-class="{'is-active': vm.checkboxModel.opt2}">
            <input type="checkbox" ng-model="vm.checkboxModel.opt2"/>Option 2 {{vm.opt2}}
        </label>
        <label class="button" ng-class="{'is-active': vm.checkboxModel.opt3}">
            <input type="checkbox" ng-model="vm.checkboxModel.opt3"/>Option 3 {{vm.opt3}}
        </label>
    </div>
    
<div class="row">
    <div class="button-group button-multiselect">
        <label class="button" ng-class="{'is-active': vm.checkboxModel.opt1}">
            <input type="checkbox" ng-model="vm.checkboxModel.opt1"/>Option 1 {{vm.opt1}}
        </label>
        <label class="button" ng-class="{'is-active': vm.checkboxModel.opt2}">
            <input type="checkbox" ng-model="vm.checkboxModel.opt2"/>Option 2 {{vm.opt2}}
        </label>
        <label class="button" ng-class="{'is-active': vm.checkboxModel.opt3}">
            <input type="checkbox" ng-model="vm.checkboxModel.opt3"/>Option 3 {{vm.opt3}}
        </label>
    </div>
</div>

<p>You selected: {{vm.checkboxModel}}</p>

## Multiselect using radio button

<p>Using radio buttons instead of checkboxes restricts the selection to only one option.</p>

    <div class="button-group button-multiselect">
        <label class="button" ng-class="{'is-active': 'male' === radioModel}">
            <input type="radio" name="gender" value="male" ng-model="radioModel"> Male
        </label>
        <label class="button" ng-class="{'is-active': 'female' === radioModel}">
            <input type="radio" name="gender" value="female" ng-model="radioModel"> Female
        </label>
        <label class="button" ng-class="{'is-active': 'other' === radioModel}">
            <input type="radio" name="gender" value="other" ng-model="radioModel"> Other
        </label>
    </div>

<div class="row">
    <div class="button-group button-multiselect">
        <label class="button" ng-class="{'is-active': 'male' === radioModel}">
            <input type="radio" name="gender" value="male" ng-model="radioModel"> Male
        </label>
        <label class="button" ng-class="{'is-active': 'female' === radioModel}">
            <input type="radio" name="gender" value="female" ng-model="radioModel"> Female
        </label>
        <label class="button" ng-class="{'is-active': 'other' === radioModel}">
            <input type="radio" name="gender" value="other" ng-model="radioModel"> Other
        </label>
    </div>
</div>

<p>You selected: {{radioModel}}</p>

<p>You can also use ng-repeat in conjunction with radio buttons.</p>

    <div class="button-group button-multiselect" ng-init="genders=['male','female','other']">
        <label ng-repeat="opt in genders"  ng-class="{'is-active': opt === vm.radioModel}" class="button">
            <input type="radio" name="radio" id="opt" ng-value="opt" ng-model="vm.radioModel"> Radio {{opt}}
        </label>
    </div>

<p>For some reason, the example does not work in this demo app page, so click on <a ui-sref="multiSelectExample">this page</a> to see a working example:</p>
