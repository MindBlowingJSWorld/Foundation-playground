angular.module('commonElements.demo')
    .controller('multiSelectExampleController', multiSelectExampleController);

function multiSelectExampleController() {}