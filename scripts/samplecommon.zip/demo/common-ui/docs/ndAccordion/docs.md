Similar to angular-ui-accordion, but header is hidden when expands. Also if multiple lists exist on a page, expanding one item, will collapse items in other lists.

item.id is required, so expanded list is not collapsed when events propagates

```html
  <div class="list-one" nd-accordion-list >
    <div ng-repeat="item in ctrl.items">
      <div nd-accordion-list-item-collapsed="item.id" class="row"></div>
      <div nd-accordion-list-item-expanded="item.id" class="row"></div>
    </div>
  </div>

  <div class="list-two" nd-accordion-list >
      <div ng-repeat="item in ctrl.items">
          <div nd-accordion-list-item-collapsed="item.id" class="row"></div>
          <div nd-accordion-list-item-expanded="item.id" class="row"></div>
      </div>
  </div>
```

Example:

  <div class="list-one" nd-accordion-list >
    <div ng-repeat="item in [1,2,3,4,5]">
      <div nd-accordion-list-item-collapsed="item" class="row">Item header: {{item}}</div>
      <div nd-accordion-list-item-expanded="item" class="row">Expanded item view: {{item}}</div>
    </div>
  </div>

  <div class="list-two" nd-accordion-list >
      <div ng-repeat="item in [11,12,13]">
          <div nd-accordion-list-item-collapsed="item" class="row">Second list item header: {{item}}</div>
          <div nd-accordion-list-item-expanded="item" class="row">Expanded item view: {{item}}</div>
      </div>
  </div>








