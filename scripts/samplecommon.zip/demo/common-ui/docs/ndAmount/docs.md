ndAmount takes a value and displays it according to the UI design for amounts. You can set modifier classes that are 
passed to the underlying `<span>`, as described here: [Amount](/foundation-styles/#/section/2.9)


    <nd-amount value="12 000,00"></nd-amount>
<nd-amount value="'12 000,00'"></nd-amount>

<p></p>

    <nd-amount class="amount--primary" value="12 000,00"></nd-amount>
<nd-amount class="amount--primary" value="12 000,00"></nd-amount>

<p></p>

    <nd-amount class="positive" value="12 000,00"></nd-amount>
<nd-amount class="positive" value="12 000,00"></nd-amount>

<p></p>

Free input: <input type="text" ng-model="myValue" />
<p></p>
<nd-amount value="{{myValue}}"></nd-amount>
<nd-amount class="amount--primary" value="{{myValue}}"></nd-amount>

