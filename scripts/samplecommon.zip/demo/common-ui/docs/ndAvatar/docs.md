You can use it the following way:

```html
    <nd-avatar name="Nordea" img="common-ui/docs/ndAvatar/nordea.jpg"/>
    <nd-avatar name="LE" color="#38a68d"/>
```

<nd-avatar name="Nordea" img="common-ui/docs/ndAvatar/nordea.jpg"/>
<nd-avatar name="LE" color="#38a68d"/>


