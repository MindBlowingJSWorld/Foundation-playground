## usage

On click the state toggles from true to false or false to true.

<div class="api-table"></div>

| Attributes              | Definition                                                                                                                       |
| ------------------------|----------------------------------------------------------------------------------------------------------------------------------|
| is-expanded="true"      | `(boolean)` => text on button is value of attribute text-expanded.                                                               |
| is-expanded="false"     | `(boolean)` => text on button is value of attribute text-collapsed.                                                              |
| text-collapsed="value"  | value is a string like `"Click to expand"` or `"filtersVm.getFilteredCount('Credit')"`.                                          |
| text-expanded="value"   | value is a string like `"Click to collapse"` or `"vm.accounts.length accounts"`.                                                 |
| button-class="value"    | value is a string of additional button modifier classes separated by spaces, such as `"button--icon-left"` or `"button--icon-left hollow"`. `"button"`, `"button--expand"` and `"button--icon-right"` are always included automatically, specifying`"button--icon-left"` will override right icon alignment, adding `"secondary"`, `"hollow"` and other classes will have their expected effect on buttons. |

<div class="api-table-end"></div>

Code to add an expand button:

```html
<nd-button-expand is-expanded="vm.isMySectionExpanded" text-collapsed="Expand" text-expanded="Collapse"></nd-button-expand>
```

Example:

<div ng-init="ndButtonIsExpanded = true"></div>
<nd-button-expand is-expanded="ndButtonIsExpanded" text-collapsed="Expand" text-expanded="Collapse" button-class="button--icon-right"></nd-button-expand>
<div class="callout" ng-if="ndButtonIsExpanded">Expanded content</div>


