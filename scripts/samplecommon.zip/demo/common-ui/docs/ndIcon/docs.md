Basic usage

    <nd-icon icon="<icon name>"></nd-icon>

results in <nd-icon icon="home"></nd-icon>.

The Styleguide contains lists of <a href="/foundation-styles/#/section/1.5.3">standard-sized icons</a> and <a href="/foundation-styles/#/section/1.5.4">small icons</a>.

## Icon sizes

Icons with suffix `_sml` in their name should only be displayed in size 16px x 16 px. All other icons should be displayed in size 32px x 32px by default.
`nd-icon` sets the correct size based on the icon name. For example `<nd-icon icon="error_sml"></nd-icon>` produces <nd-icon icon="error_sml"></nd-icon> 
and `<nd-icon icon="advice"></nd-icon>` produces <nd-icon icon="advice"></nd-icon>.

To force icon size, supply one of the following `size` attributes:

* `s`: 16px x 16px
* `m`: 32px x 32px
* `l`: 64px x 64px
* `xl`: 128px x 128px


    <nd-icon icon="home" size="s"></nd-icon>
    <nd-icon icon="home" size="m"></nd-icon>
    <nd-icon icon="home" size="l"></nd-icon>
    <nd-icon icon="home" size="xl"></nd-icon>

<nd-icon icon="home" size="s"></nd-icon>
    <nd-icon icon="home" size="m"></nd-icon>
    <nd-icon icon="home" size="l"></nd-icon>
    <nd-icon icon="home" size="xl"></nd-icon>

## Icon colors
    
You can override the default icon color using the CSS `color` attribute. For example:

    <nd-icon icon="ok" class="text--success"></nd-icon>
    <nd-icon icon="home" class="negative-colors" 
             style="background-color: blue;"></nd-icon>
    
    
<nd-icon icon="ok" class="text--success"></nd-icon>
    <nd-icon icon="home" class="colors-negative" style="background-color: blue;"></nd-icon>