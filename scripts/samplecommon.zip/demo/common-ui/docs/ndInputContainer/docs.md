## Basic inputs and text areas

The `ndInputContainer` directive provides look and feel as well as functionality to `input` and `textarea` elements.
By default, an input container takes 100% of the available width. Input id and label reference are set automatically.

    <nd-input-container>
        <label>Input label</label>
        <input type="text" ng-model="ndInputContainerText1"/>
    </nd-input-container>
    <nd-input-container>
        <label>Textarea label</label>
        <textarea ng-model="ndInputContainerTextArea1"></textarea>
    </nd-input-container>


<nd-input-container>
    <label>Label</label>
    <input type="text" ng-model="ndInputContainerText1"/>
</nd-input-container>
    <nd-input-container>
        <label>Textarea label</label>
        <textarea ng-model="ndInputContainerTextarea1"></textarea>
    </nd-input-container>

The modifier class `input-container--inline` makes the container an inline element:

    <nd-input-container class="input-container--inline">
        <label>Label 1</label>
        <input type="text" ng-model="ndInputContainerText2"/>
    </nd-input-container>
    <nd-input-container class="input-container--inline">
        <label>Label 2</label>
        <input type="text" ng-model="ndInputContainerText3"/>
    </nd-input-container>

<nd-input-container class="input-container--inline">
    <label>Label 1</label>
    <input type="text" ng-model="ndInputContainerText2"/>
</nd-input-container>
    <nd-input-container class="input-container--inline">
        <label>Label 2</label>
        <input type="text" ng-model="ndInputContainerText3"/>
    </nd-input-container>
   
You can also leave the `label` element out and use `placeholder` attribute instead. You can also use both.  

    <nd-input-container class="input-container--inline">
        <input type="text" ng-model="ndInputContainerText4" placeholder="Placeholder only"/>
    </nd-input-container>
    <nd-input-container class="input-container--inline">
        <label>Label</label>
        <input type="text" ng-model="ndInputContainerText5" placeholder="Placeholder"/>
    </nd-input-container>
    
<nd-input-container class="input-container--inline">
    <input type="text" ng-model="ndInputContainerText4" placeholder="Placeholder only"/>
</nd-input-container>
    <nd-input-container class="input-container--inline">
        <label>Label</label>
        <input type="text" ng-model="ndInputContainerText5" placeholder="Placeholder"/>
    </nd-input-container>    

## Textareas

### `nd-no-autogrow`

By default, textareas start enough rows to display all the content (minimum 1 row). By adding attribute `nd-no-autogrow` in a `textarea` element its height
is determined by the `rows` attribute only.

    <nd-input-container>
        <label>Textarea label</label>
        <textarea ng-model="ndInputContainerTextArea2" nd-no-autogrow rows="2"></textarea>
    </nd-input-container>

<nd-input-container>
    <label>Textarea label</label>
    <textarea ng-model="ndInputContainerTextArea2" nd-no-autogrow rows="2"></textarea>
</nd-input-container>

### `nd-detect-hidden`

When attribute `nd-detect-hidden` present in a `textarea` element, it will be sized properly when it is revealed after being hidden. This is off by default for performance reasons.


## Input validation

Initially an input is displayed in the valid state. It's displayed in the invalid state after "submitting" an invalid value.
 
    <nd-input-container>
        <label>Required field</label>
        <input type="text" ng-model="ndInputContainerRequired" required/>
    </nd-input-container>
    
<nd-input-container>
    <label>Required field</label>
    <input type="text" ng-model="ndInputContainerRequired" required/>
</nd-input-container>  
  
Alternatively, you can control the error state of an input container using the `nd-is-error` attribute:

    <nd-input-container nd-is-error="ndInputContainerCustomErrorBoolean">
        <label>Some field</label>
        <input type="text" ng-model="ndIsErrorExample"/>
    </nd-input-container>
    
<nd-input-container nd-is-error="ndInputContainerCustomErrorBoolean">
    <label>Some field</label>
    <input type="text" ng-model="ndIsErrorExample"/>
</nd-input-container>
<div class="checkbox">
    <input id="checkbox-1" type="checkbox" ng-model="ndInputContainerCustomErrorBoolean"/>
    <label for="checkbox-1">Error in 'Some field'</label>
</div>      

### Error messages

Use <a href="https://docs.angularjs.org/api/ngMessages/directive/ngMessages">ng-messages</a> on a <code>input-container__error</code> element. 
It works quite nicely with Angular form input errors:

    <form name="ndInputContainerForm" novalidate>
        <nd-input-container>
            <label>Number value >= 1 required</label>
            <input type="number" name="ndInputContainerNumberGreaterThanOne" 
                   ng-model="ndInputContainerNumberGreaterThanOne" 
                   required min="1"/>
            <div ng-messages="ndInputContainerForm.ndInputContainerNumberGreaterThanOne.$error" 
                 class="input-container__error" role="alert">
                <div ng-message="required">Value is missing</div>
                <div ng-message="min">The value is not >= 1</div>
            </div>
        </nd-input-container>
    </form> 
    
<form name="ndInputContainerForm" novalidate>
    <nd-input-container>
        <label>Number value >= 1 required</label>
        <input type="number" name="ndInputContainerNumberGreaterThanOne" 
               ng-model="ndInputContainerNumberGreaterThanOne" 
               required min="1"/>
        <div ng-messages="ndInputContainerForm.ndInputContainerNumberGreaterThanOne.$error" 
             class="input-container__error" role="alert">
            <div ng-message="required">Value is missing</div>
            <div ng-message="min">The value is not >= 1</div>
        </div>
    </nd-input-container>
</form>

If you are not using Angular's `form` validation, you can still use `ng-messages` but you have to control the message hash in your own controller.
 
Without `ng-messages` you can e.g. add a default error message. `input-container__error` elements only appear in the error state. 

    <nd-input-container>
        <label>Some field</label>
        <input type="text" ng-model="ndInputContainerCustomMessageExample" required/>
        <div class="input-container__error" role="alert">This field is required!</div>
    </nd-input-container>

See an example <a ui-sref="ndInputContainer">here</a> (for some reason the layout does not work in this generated page).