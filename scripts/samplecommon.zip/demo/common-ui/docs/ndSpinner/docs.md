ndSpinner will suppress wrapped elements until specified variable contains data. The elements wrapped
with it will be by default disabled, made transparent and blanketed by a spinner image to indicate for
user that these elements are not yet available for interaction.

The ndSpinner will remove itself when specified watch variable is changed to contain data.
For spinner to activate watch variable has to be undefined, null or false. Empty array, empty string or
likes are considered to be valid values. If watch variable already contains value when spinner is
being initialized spinner is not applied at all.

ndSpinner will only watch one state change to a valid value and then unregister its watch. If you later
change watch variable value to undefined or null, no spinning will occur.

## Usage

<div class="api-table"></div>

| Attributes              | Definition                                                                                                      |
| ------------------------|-----------------------------------------------------------------------------------------------------------------|
| watch                 | Variable name to watch. Spinner will end when this contains value other than undefined, null or false.            |
| spin-class            | Your custom CSS class for spinner. Specify "nd-spinner--repeat" if you want spinning image repated x-axis. If you need to add your own CSS you can add it to spinner.scss file.|
| spin-opacity          | Amount of opacity, default value is 0.2. If not set, opacity will not be changed.                                 |
| spin-animate          | "transition" animation where default value is "opacity 0.5s ease 0s". This slowly changes opacity to one when spinner completes.|
| spin-image            | Spinner image size or url. Predefined spin image values are "small", "large" or "none". See examples below. |
| spin-reenable         | Enables spinner re-enable after it has completed or enabling spinner later. Without this spinner it will unregister it's watch after completion. As this requires more resources from the client don't enable unless you specifically need this feature.|

<div class="api-table-end"></div>

## Example

<div ng-controller="SpinImageExampleController as vm">

    Spin Image Value: {{vm.radioModel}}
    <div class="button-multiselect">
        <label ng-repeat="spinImg in vm.spinImgs" class="button" ng-class="{'is-active': spinImg.value === vm.radioModel}">
            <input type="radio" name="spinImage" value="{{spinImg.value}}" ng-model="vm.radioModel"> {{spinImg.label}}
        </label>
    </div>
    
<nd-spinner watch="vm.spinState" spin-animate spin-opacity="0.2" spin-class="nd-spinner--repeating" spin-image="{{vm.radioModel}}" spin-reenable>
    <nd-input-container>
        <label>Spinned Input label</label>
        <input type="text" ng-model="ndInputContainerText1"/>
    </nd-input-container>
</nd-spinner>

<button type="button" class="button" ng-click="vm.spinState = !vm.spinState;">Toggle spinning!</button>

</div>

## Spinner usage example
	<nd-spinner watch="wm.spinState"
				spin-animate 
				spin-opacity="0.2" 
				spin-class="nd-spinner--repeating" 
				spin-image="small"
				spin-reenable>
		<nd-input-container>
			<label>Spinned Input label</label>
			<input type="text" ng-model="ndInputContainerText1"/>
		</nd-input-container>
	</nd-spinner>









