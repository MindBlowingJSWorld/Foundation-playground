'use strict';

angular.module('commonElements.demo')
    .controller('SpinImageExampleController',SpinImageExampleController);

function SpinImageExampleController(){
    this.spinState = false;
    this.spinImgs = [
        {
            value: 'large',
            label: 'large'
        },
        {
            value: 'small',
            label: 'small'
        },
        {
            value: 'none',
            label: 'none'
        },
        {
            value: '/common-ui/docs/ndSpinner/simpson.gif',
            label: 'customized image url'
        },
        {
            value: 'invalid',
            label: 'invalid image url'
        },
        {
            value: 'http://simpson.gif',
            label: 'another invalid image url'
        }
    ];
}
