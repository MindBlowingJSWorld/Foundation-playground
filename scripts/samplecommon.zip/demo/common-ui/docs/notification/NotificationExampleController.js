'use strict';

angular.module('commonElements.demo')
    .factory('notificationSample', notificationSample)
    .controller('NotificationExampleController', NotificationExampleController);

function notificationSample() {

    var dynamicNotification = {
        title: '<a href="https://www.google.se/" target="_blank">Title</a>', //You can even pass in HTML here!!!
        image: 'http://www.sebastianzieba.com/wp-content/uploads/2015/04/4df035b1-4679-486f-86f8-38f4e54ecdc1.png'
    };

    var create = function (autoClose, color) {
        return _.defaults(_.clone(dynamicNotification), {
            autoclose: autoClose,
            content: 'This is a notification',
            color: color ? color : autoClose ? 'alert' : 'success'
        });
    };

    return {
        create: create
    }
}

function NotificationExampleController(nordeaPalette, NotificationService, notificationSample) {
    var i,
        _this = this,
        notificationId = 0,
        topNotificationId = 0;

    _this.colors = nordeaPalette.slice(0);
    _this.colors.push('undefined');
    _this.sampleNotifications = [];
    _this.positions = ['top-left', 'top-right', 'bottom-left', 'bottom-right'];

    // TOAST
    _this.showToast = function (toastPosition, autoClose, withId) {
        var setId;
        var notification = notificationSample.create(autoClose, withId ? 'warning' : '');

        if (withId) {
            notificationId++;
            notification.id = notificationId;
        }

        if (toastPosition) {
            setId = toastPosition === 'bottom-left' ? 'toast' : toastPosition;
        }

        NotificationService.showToast(notification, setId);

    };

    _this.hideToast = function (toastPosition) {
        var setId;
        if (toastPosition) {
            setId = toastPosition === 'bottom-left' ? 'toast' : toastPosition;
        }
        NotificationService.hideToast(notificationId, setId);
        notificationId--;
        notificationId = Math.max(notificationId, 0);
    };

    _this.showTopNotifcation = function (color, autoClose, withId) {

        var notification = notificationSample.create(autoClose, color);

        if (withId) {
            topNotificationId++;
            notification.id = topNotificationId;
        }

        NotificationService.showTopNotification(notification);
    };

    _this.hideTopNotification = function () {
        NotificationService.hideTopNotification(topNotificationId);
        topNotificationId--;
        topNotificationId = Math.max(topNotificationId, 0);
    };


}

