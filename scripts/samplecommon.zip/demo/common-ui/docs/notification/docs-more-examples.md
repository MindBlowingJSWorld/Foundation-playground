# Notification Playground

<div ng-controller="NotificationExampleController as vm"> 
    <div ng-include="'common-ui/docs/notification/docs-toast.html'"></div>
    <div ng-include="'common-ui/docs/notification/docs-topNotification.html'"></div>
</div>

## Usage

Use `<nd-notification-set>` tag in conjunction with  `NotificationService` to control notifications' visibility.

1. Depending on what type of notification you want to use, place these in your HTML:

    For top notification: `<nd-notification-set type="top"></nd-notification-set>` OR just simply `<nd-notification-set></nd-notification-set>`.
    
    For toast notification: `<nd-notification-set type="toast"></nd-notification-set>`.
    
    Where to put `<nd-notification-set>` tag on your HTML page does NOT matter because the notification's positions are defined based on the `position` property.
    
    Here is a verbose version of nd-notification-set, where you manually define the your notification-set's id and position:
        
        <nd-notification-set type="toast" id="mySetId" position="top-left"></nd-notification-set>
        
2. Use `NotificationService` in your controller. In the example below, I will demonstrate how to show a toast:

    First make your notification object:

        var myNotification = {
            id: 'myNotiId', // optional, without it, NotificationService will auto generate one for you
            title: '<a href="https://www.google.se/" target="_blank">Notification Title</a>', //You can even pass in HTML here!!!
            content: 'Notification message.',
            color: 'success', // other options are in nordeaPalette constant ( 'primary', 'secondary', 'info', 'warning', alert')
            image: 'http://www.sebastianzieba.com/wp-content/uploads/2015/04/4df035b1-4679-486f-86f8-38f4e54ecdc1.png',
            // autoclose: 3000 // optional, defining miliseconds before notification will be faded away (default 5 sec)
        };
        
    If you have this in your HTML:
        
        <nd-notification-set type="toast"></nd-notification-set>
        
    This is enough:
        
        NotificationService.showToast(myNotification);
    
    If you have manually defined the notification-set's id in your HTML:
    
        <nd-notification-set type="toast" id="mySetId" position="top-left"></nd-notification-set>
    
    And you only want to show toast on that set then you need to pass in the notification-set id as the 2nd parameter of showToast:
    
        NotificationService.showToast(myNotification, 'mySetId'); // 'mySetId' is the nd-notification-set's id.
        
3. To hide a notification programmatically (remove it from the notification set stack), you can do like so:
        
        NotificationService.hideToast('myNotiId', 'mySetId');
        
    OR:
        
        NotificationService.hideToast(myNotification, 'mySetId'); // Pass in the notification obj itself, this only work if myNotification has already an id
        
    Again the second parameter (set's id) is optional just like in the showToast case.
        
The same process will be applied for top notification, only that instead of using `showToast`, you use `showTopNotification`; instead of `hideToast`, you use `hideTopNotification`.

## API

# ndNotificationSet directive API:

Notification set is a set of notifications, which is a placeholder where notifications will be instantiated.

<div class="api-table"></div>

| Attributes | Type                                                                             | Definition                                                                                                        |
|------------|----------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| type       | string (`toast`/`top` (default))                                                 | `toast` and `top` means the set will be a set of `toast` or `top` notification correspondingly .                  |
| position   | string (either `top-left`, `top-right`, `bottom-right`, `bottom-left` (default)) | For now, `position` is only relevant with notification type `toast`, since top notification is always in the top. |

<div class="api-table-end"></div>

# NotificationService API:

You can control show/hide notifications by using NotificationService.

<div class="api-table"></div>

| Methods             | Parameters                                           | Definition                                                                                      |
|---------------------|------------------------------------------------------|-------------------------------------------------------------------------------------------------|
| showToast           | toastId / notification object, toastSetId (optional) | Show notification type toast. `toastSetId` is the nd-notification-set's id                      |
| hideToast           | toastId (optional), toastSetId (optional)            | Hide notification type toast. If `toastId` is undefined, it will hide all the toast in that set |
| showTopNotification | toastId / notification object                        | Show top notification                                                                           |
| hideTopNotification | toastId (optional)                                   | Hide top notification. If `toastId` is undefined, it will hide all the top notification         |

<div class="api-table-end"></div>

`Notification Object` is a literal object with following properties:

<div class="api-table"></div>

| Properties | Types               | Definition                                                                                                                              |
|------------|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| id         | string (optional)        | If id is undefined, it will be auto generated by the framework. If it is defined then later you can use this `id` hide it explicitly, check `hideToast` and `hideTopNotification` API for this feature |
| color      | string                   | notification color: 'primary','secondary','alert','warning','success','info'. If undefined, notification will have a color of transparent |
| title      | string                   | notification title                                                                                                                      |
| content    | string                   | notification content                                                                                                                    |
| autoclose  | number (milliseconds)    | Time that notification is shown. The default is 5000 ms. Use a negative value or a non-number value (e.g. false) to disable auto-closing. |
| image      | url                      | url to the image that you want to put inside the notification                                                                                                                            | 

<div class="api-table-end"></div>
