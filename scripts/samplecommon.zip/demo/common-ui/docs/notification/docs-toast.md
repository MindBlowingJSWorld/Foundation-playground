## Toast notification

<span ng-init="vm.positions = (vm.version === 'simplified') ? ['bottom-left'] : vm.positions"></span>

Auto-closing notification (the notification closes after 3s): 
<button ng-repeat="position in vm.positions.slice(0,2)" class="button" ng-click="vm.showToast(position)" style="width:170px">{{position}}</button>
<br>
<button ng-repeat="position in vm.positions.slice(2,4)" class="button" ng-click="vm.showToast(position)" style="width:170px">{{position}}</button>


You can also define the time for notification to be faded out, for example, 1.5s like example below:
<button ng-repeat="position in vm.positions.slice(0,2)" class="button" ng-click="vm.showToast(position, 1500)" style="width:170px">{{position}}</button>
<br>
<button ng-repeat="position in vm.positions.slice(2,4)" class="button" ng-click="vm.showToast(position, 1500)" style="width:170px">{{position}}</button>

Non-auto-closing notification (notification that won't close itself unless you explicitly close it):
<button class="button"  ng-click="vm.showToast(undefined, false, true)">Show a toast</button> <!-- Change undefined to 'top-left', 'bottom-right' etc. to change the position of the toast -->
<button class="button"  ng-click="vm.hideToast()">Click here to hide it</button>

<nd-notification-set type='toast'></nd-notification-set>
<nd-notification-set type='toast' id="top-left" position="top-left"></nd-notification-set>
<nd-notification-set type='toast' id="top-right" position="top-right"></nd-notification-set>
<nd-notification-set type='toast' id="bottom-right" position="bottom-right"></nd-notification-set>


