## Top notification

Same behavior as toast notification, except that the style is a bit different.

Auto-closing top notifications:

<button ng-repeat="color in vm.colors" color="button" class="button {{color}}" 
ng-style="{'background': color === 'info' ? '#3399ff' :  color === 'undefined' ? 'rgba(0, 0, 0, 0.1)' : ''}" 
ng-click="vm.showTopNotifcation(color)">{{color}}</button>

Non-auto-closing top notification:

<button class="button"  ng-click="vm.showTopNotifcation('primary', false, true)">Show a notification on the top</button>
<button class="button"  ng-click="vm.hideTopNotification()">Click here to hide it</button>
