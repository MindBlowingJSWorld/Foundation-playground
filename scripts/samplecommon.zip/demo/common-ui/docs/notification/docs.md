There are several types of notifications, currently we have top notification and toast notification.

## Examples

<div ng-controller="NotificationExampleController as vm" ng-init="vm.version='simplified'"> 
    <div ng-include="'common-ui/docs/notification/docs-toast.html'"></div>
    <div ng-include="'common-ui/docs/notification/docs-topNotification.html'"></div>
</div>


## Usage

All you need to do is use `NotificationService` in your controller. In the example below, I will demonstrate how to show a toast:

1. Make your notification object:

        var myNotification = {
            id: 'myNotiId', // optional, without it, NotificationService will auto generate one for you
            title: '<a href="https://www.google.se/" target="_blank">Notification Title</a>', //You can even pass in HTML here!!!
            content: 'Notification message.',
            color: 'success', // other options are in nordeaPalette constant ( 'primary', 'secondary', 'info', 'warning', alert')
            image: 'http://www.sebastianzieba.com/wp-content/uploads/2015/04/4df035b1-4679-486f-86f8-38f4e54ecdc1.png',
            // autoclose: 3000 // optional, defining miliseconds before notification will be faded away (default 5 sec)
        };
        
2. Then call showToast:
        
        NotificationService.showToast(myNotification);
    
You have to use, for example, `_.clone(myNotification)` if you want to reuse myNotification object, otherwise it may throw `Error: ngRepeat:dupes Duplicate Key in Repeater`.
        
The same process will be applied for top notification, only that instead of using `showToast`, you use `showTopNotification`; instead of `hideToast`, you use `hideTopNotification`.

To see more ndNotificationSet & NotificationService examples and learn more about its API, click <a ui-sref="notificationsExamples">here</a>.

