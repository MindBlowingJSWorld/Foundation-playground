Usage:

    <a nd-scroll-focus="target-id">Scroll to target-id</a>
    <button nd-scroll-focus="{{targetId}}">Scroll to target-id</button>

Example: <a nd-scroll-focus="ndInputContainer">Scroll to input container</a>
 

When the directive element is clicked

* Tells Angular to scroll to the target element
* Sets focus on the target. (You can make an element not focusable cy default using the [tabindex](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/tabindex) attribute.)
* Sets the `$location` hash value as the target element id (e.g. `http://my-app/#/feature-path#target-id` in the usage example).

The purpose of this directive is to enable similar behavior as a regular anchor tag with an id reference (`<a href="#target-id">`). Those do not work with Angular and routing.