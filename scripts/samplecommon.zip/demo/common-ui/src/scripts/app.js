'use strict';

angular.module('commonElements.demo', ['dbw-common', 'ui.router', 'ngMessages'])
    .config(configureStates)
    .run(setUpFoundationWorkaround)
    .run(setUpScrollingToAnchors);

function configureStates($stateProvider, $urlRouterProvider) {

    //Set a catch.all url redirect
    $urlRouterProvider.otherwise('/home');

    $stateProvider
        .state('index', {
            abstract: true,
            url: '/',
            templateUrl: 'index.html'
        })
        .state('home', {
            url: '/home',
            templateUrl: 'common-ui/src/list.tpl.html',
            controller: 'ListController',
            controllerAs: 'listCtrl'
        })
        .state('moneybar', {
            url: '/ndMoneybar',
            templateUrl: 'common-ui/docs/moneybar/moneybar-example.html',
            controller: 'MoneybarExampleController'
        })
        .state('moneybar-container', {
            url: '/ndMoneybarContainer',
            templateUrl: 'common-ui/docs/moneybar/moneybar-container-example.html',
            controller: 'MoneybarContainerExampleController',
            controllerAs: 'vm'
        })
        .state('ndDatePicker', {
            url: '/ndDatePicker',
            templateUrl: 'common-ui/docs/datePicker/datePicker-example.html',
            controller: 'DatePickerExampleController',
            controllerAs: 'vm'
        })
        .state('play', {
            url: '/play',
            templateUrl: 'common-ui/src/play.html',
            controller: function ($scope, styleSheetsService) {
                styleSheetsService.disableStyleSheets(document.styleSheets);
                $scope.$on('$destroy', function () {
                    styleSheetsService.enableStyleSheets();
                });
            }
        })
        .state('ndInputContainer', {
            url: '/ndInputContainer',
            templateUrl: 'common-ui/docs/ndInputContainer/example.html'
        })
        .state('multiSelectExample', {
            url: '/multiSelectExample',
            templateUrl: 'common-ui/docs/multiSelect/multiSelect-example.html',
            controller: 'multiSelectExampleController',
            controllerAs: 'vm'
        })
        .state('modal', {
            url: '/modal',
            templateUrl: 'common-ui/docs/modal/docs-modal.html',
            controller: 'PageExampleController',
            controllerAs: 'vm'
        })
        .state('notificationsExamples', {
            url: '/notificationsExamples',
            templateUrl: 'common-ui/docs/notification/docs-more-examples.html',
            controller: 'NotificationExampleController',
            controllerAs: 'vm'
        })
        .state('mdSelect', {
            url: '/mdSelect',
            templateUrl: 'common-ui/docs/md-select/md-select.html',
            controller: 'MdSelectDemoController',
            controllerAs: 'vm'
        })
        .state('mdMenu', {
            url: '/mdMenu',
            templateUrl: 'common-ui/docs/md-menu/md-menu.html',
            controller: 'MdMenuDemoController',
            controllerAs: 'vm'
        })
    ;
}

// A workaround to init foundation on ui-route changes -->
function setUpFoundationWorkaround($rootScope, $timeout) {
    $rootScope.$on('$stateChangeSuccess', function () {
        $timeout(function () {
            $(document).ready(function () {
                $(document).foundation();
            });

            $(document).scroll(function() {
                var y = $(this).scrollTop();
                if (y > 800) {
                    $('.back-to-top').fadeIn();
                    $('.back-to-top').css('display','inline');
                } else {
                    $('.back-to-top').fadeOut();
                }
            });
        });
    });
}

function setUpScrollingToAnchors($rootScope, $location, $timeout, $anchorScroll) {
    $rootScope.$on('$stateChangeSuccess', function () {
        if ($location.hash()) {
            $timeout(function () {
                $anchorScroll($location.hash());
            }, 100);
        }
    });
}
