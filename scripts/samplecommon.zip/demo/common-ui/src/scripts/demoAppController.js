'use strict';

angular.module('commonElements.demo')
    .controller('DemoAppController', DemoAppController);

function DemoAppController($rootScope, $location, $anchorScroll, $log) {
    $rootScope.scrollTo = scrollTo;

    function scrollTo(id) {
        $log.debug('Scroll to ' + id);
        $location.hash(id);
        $anchorScroll();
    }

    this.goToTop = function () {
        scrollTo('top');
    }
}