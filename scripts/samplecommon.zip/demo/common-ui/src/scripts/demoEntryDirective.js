'use strict';

angular.module('commonElements.demo')
    .directive('demoEntry', demoEntry);

function demoEntry() {
    return {
        restrict: 'A',
        link: function(scope, elem, attrs) {
            elem.find('div.api-table').nextUntil('div.api-table-end').addClass('nd-api-table');
        }
    };
}