'use strict';

angular.module('commonElements.demo')
    .directive('demoHeader', demoHeader);

function demoHeader() {
    return {
        restrict: 'E',
        transclude: true,
        template: '<a id="{{id}}" nd-scroll-focus="{{id}}"><span ng-transclude></span></a>',
        link: function($scope, iElem, iAttrs) {
            $scope.id = iAttrs.id;
            $scope.header = iAttrs.header || iAttrs.id;
        }
    };
}