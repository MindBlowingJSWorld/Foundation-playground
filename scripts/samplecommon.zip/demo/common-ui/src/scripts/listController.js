angular.module('commonElements.demo')
    .controller('ListController', ListController);

function ListController(listService) {
   this.componentlist = listService.getList();
}