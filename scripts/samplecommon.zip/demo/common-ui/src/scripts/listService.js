'use strict';

angular.module('commonElements.demo')
    .factory('listService', listService);

function listService() {

    // This is the place whenever we have new ui elements ready, we add it to this list
    var componentList = [
        {
            name: 'datePicker',
            prettyName: 'Date Picker',
            contactList: ['z986961']
        },
        {
            name: 'modal',
            prettyName: 'Modal'
        },
        {
            name: 'moneybar',
            prettyName: 'Money Bar'
        },
        {
            name: 'multiSelect',
            prettyName: 'Multi Select Button',
            sourceUrl: '#'
        },
        {name: 'ndAccordion'},
        {name: 'ndAmount'},
        {name: 'ndAvatar'},
        {name: 'ndButtonExpand'},
        {
            name: 'ndIcon',
            sourceUrl: '#'
        },
        {name: 'ndInputContainer'},
        {name: 'ndSpinner'},
        {name: 'notification'},
        {name: 'scrollFocus'},
        {
            name: 'md-menu',
            sourceUrl: '#'
        },
        {
            name: 'md-select',
            sourceUrl: '#'
        },
        {name: 'dateValidator'}
    ];

    var baseUrl = 'https://ccd1is0271.ccd1.root4.net:8443/projects/DBW/repos/common/browse/src/common-ui/';
    var getList = function () {
        var i;
        for (i = 0; i < componentList.length; i++) {
            componentList[i].url = 'common-ui/docs/' + componentList[i].name + '/docs.html';
            componentList[i].sourceUrl = componentList[i].sourceUrl || baseUrl + componentList[i].name;
        }
        return componentList;
    };

    return {
        getList: getList
    };
}
