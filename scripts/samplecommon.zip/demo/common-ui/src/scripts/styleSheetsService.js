'use strict';

function styleSheetsService(){
    var disabledStyleSheetsIndex = [];
    var disableStyleSheets = function (styleSheets) {
        for(var i in styleSheets){
            if(styleSheets.hasOwnProperty(i)){
                var style = styleSheets[i];
                var hrefArr = style.href && style.href.split('/') || [];
                var cssName = hrefArr[hrefArr.length-1];
                if(cssName && cssName !== 'dbw-foundation-nordea.css' && cssName !== 'dbw-common.css' ){ // If it is not foundation, or our own common css then disable it
                    document.styleSheets[i].disabled = true;
                    disabledStyleSheetsIndex.push(i);
                }
            }
        }
    };
    var enableStyleSheets = function () {
        for(var i=0;i < disabledStyleSheetsIndex.length; i++){
            document.styleSheets[disabledStyleSheetsIndex[i]].disabled = false;
        }
        disabledStyleSheetsIndex.length = 0;
    };
    return {
        disableStyleSheets:disableStyleSheets,
        enableStyleSheets:enableStyleSheets
    }
}

angular.module('commonElements.demo').factory('styleSheetsService',styleSheetsService);