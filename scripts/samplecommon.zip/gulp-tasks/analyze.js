'use strict';

var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
var runSequence = require('run-sequence');
var stylelint = require('stylelint');
var styleReporter = require('postcss-reporter');
var syntaxScss = require('postcss-scss');
var open = require('gulp-open');

var build_config = require('../config/build.config.js'),
    other = build_config.OTHER,
    srcs = build_config.SOURCES;

var dev_srcs = srcs.javascript.concat(other.gulp);
var plato_srcs = srcs.javascript.concat('!**/*.spec.js');
var plato_dist = 'reports/plato_dist';
var plato_dist_src = plato_dist + '/**';

gulp.task('lint-styles', function() {
    return gulp.src(srcs.all_sass)
        .pipe($.postcss([
            stylelint(),
            styleReporter({ clearMessages: true })
        ], { syntax: syntaxScss }));
});

gulp.task('eslint', function() {
    // ESLint ignores files with "node_modules" paths.
    // So, it's best to have gulp ignore the directory as well.
    // Also, Be sure to return the stream from the task;
    // Otherwise, the task may end before the stream has finished.
    return gulp.src(dev_srcs)
        // eslint() attaches the lint output to the "eslint" property
        // of the file object so it can be used by other modules.
        .pipe($.eslint())
        // eslint.format() outputs the lint results to the console.
        // Alternatively use eslint.formatEach() (see Docs).
        .pipe($.eslint.format())
        // To have the process exit with an error code (1) on
        // lint error, return the stream and pipe to failAfterError last.
        .pipe($.eslint.failAfterError());
});


gulp.task('plato-transpile', function() {
    return gulp.src(plato_srcs)

        // uncomment this to enable ES6 transpilation
        //.pipe($.babel())

        .pipe(gulp.dest(plato_dist));
});

gulp.task('plato', ['plato-transpile'], function() {
    var DEST_DIR = 'reports/plato';
    return gulp.src(plato_dist_src)
        .pipe($.plato(DEST_DIR));
});

gulp.task('analyze', function(cb) {
    runSequence(['lint-styles','eslint', 'plato'], cb);
});


gulp.task('analyze-ci', function() {
    return gulp.watch(dev_srcs, ['analyze']);
});


// Open report
gulp.task('open-unit-test-report', function () {
    gulp.src('./reports/coverage/html/index.html').pipe(open());
});

gulp.task('open-plato-report', function () {
    gulp.src('./reports/plato/index.html').pipe(open());
});

gulp.task('open-report', ['open-plato-report', 'open-unit-test-report']);