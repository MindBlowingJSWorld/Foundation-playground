'use strict';

var gulp = require('gulp');
var $ = require('gulp-load-plugins')();

var mergeStream = require('merge-stream');
var series = require('stream-series');
var runSequence = require('run-sequence');
var angularTemplateCache = require('gulp-angular-templatecache');
var sherpa = require('style-sherpa');
var glob = require('glob');
var gutil = require('gulp-util');
var _ = require('lodash');
var joinPath = require('join-path');
var doPlumber = require('./util').doPlumber;

var FOUNDATION_CONFIG = require('../config/build.foundation-styles.config.js');
var SASS_CONFIG = require('../config/sass.config');

var build_config = require('../config/build.config.js'),
    dirs = build_config.DIRS,
    demo = build_config.DEMO,
    srcs = build_config.SOURCES;

var util = require('./util.js');

// DEMO APP TASKS
gulp.task('run-demo', function (done) {
    return runSequence(
        'build-demo',
        'webserver',
        'watch-demo',
        'process-icons',
        ['build-sass', 'build-js', 'build-images'],
        'styleguide',
        'remind-update-change-log',
        done
    );
});

gulp.task('remind-update-change-log', function () {
    gutil.log(gutil.colors.yellow('****************************************************************************'));
    gutil.log(gutil.colors.yellow('**                                                                        **'));
    gutil.log(gutil.colors.yellow('**                PLEASE REMEMBER TO UPDATE THE CHANGELOG!                **'));
    gutil.log(gutil.colors.yellow('**                                                                        **'));
    gutil.log(gutil.colors.yellow('****************************************************************************'));
});

gulp.task('build-demo', function (done) {
    return runSequence(
        'build',
        ['copy-build', 'copy-dependencies-to-demo'],
        'build-docs',
        'build-docs-sass',
        'index-demo',
        done
    );
});

gulp.task('build-docs', function (cb) {
    var file, i;

    glob(demo.docs, {}, function (err, files) {

        for (i = 0; i < files.length; i++) {
            var isFinalFile = ( i === (files.length - 1) );
            file = files[i];

            try {
                sherpa(file, {
                    output: file.split('.')[0] + '.html',
                    template: demo.docs_tpl
                }, isFinalFile ? cb : null);
            }
            catch (err) {
                gutil.log(gutil.colors.red('The build docs fail at: ', file));
                gutil.log(gutil.colors.red(err));
                gutil.log(gutil.colors.yellow('A previous version of ' + file.split('.')[0] + '.html' + ' will be serverd.'));
                gutil.log(gutil.colors.yellow('Read more instruction at: https://ccd1is0271.ccd1.root4.net:8443/projects/DBW/repos/common/browse'));

            }

        }
    });

});

gulp.task('build-docs-sass', function () {
    return gulp.src(build_config.DEMO.sass)
        .pipe($.sass(SASS_CONFIG).on('error', $.sass.logError))
        .pipe($.concat('style.css'))
        .pipe(gulp.dest(dirs.demo+'/common-ui/src'));
});

gulp.task('watch-demo', function () {
    gulp.watch(_.flattenDeep([
        srcs.javascript,
        srcs.templates,
        srcs.javascript_vendors,
        '!src/**/*.spec.js'
    ]), ['build-js']);

    gulp.watch(_.flattenDeep([
        srcs.all_sass,
        joinPath(FOUNDATION_CONFIG.sass.dir, '**/*.*'),
        'src/angular-material/**/*.scss'
    ]), ['build-sass']);

    // Component documentation + styleguide
    gulp.watch([demo.docs], ['build-docs']);
    gulp.watch([dirs.build + '/*.*'], ['copy-build']);
    gulp.watch([demo.all_src], ['index-demo']);
    gulp.watch([build_config.DEMO.sass], ['build-docs-sass']);
    gulp.watch([joinPath(FOUNDATION_CONFIG.sass.dir, '**/*.*')], ['styleguide']);
});

gulp.task('index-demo', function () {
    var target = gulp.src('demo/common-ui/src/index.tpl.html');

    // Vendor files in the correct order (build.config.js)
    var vendorPaths = _.chain(build_config.VENDOR.javascript)
            .concat(build_config.DEMO.vendor_js)
            .map(function (vendorPath) {
                return _.replace(vendorPath, 'node_modules', dirs.demo + '/vendors');
            })
            .value()
        ;
    var vendorStream = gulp.src(vendorPaths, {read: false});


    var appStream = gulp.src(demo.javascript).pipe($.angularFilesort());
    var cssStream = gulp.src(demo.css);

    return target.pipe(doPlumber())
        .pipe($.inject(series(vendorStream, appStream, cssStream), {ignorePath: [dirs.demo]}))
        .pipe($.template({app_module: demo.name}))
        .pipe($.rename('index.html'))
        .pipe(gulp.dest(dirs.demo));
});


// SOURCE TASKS
gulp.task('build', function (done) {
    return runSequence(
        'clean',
        'analyze',
        'process-icons',
        ['build-sass', 'build-js', 'build-images'],
        'styleguide',
        done
    );
});

gulp.task('build-images', function () {
    return gulp.src(srcs.images)
        .pipe(gulp.dest(dirs.build_images));
});

gulp.task('build-sass', ['build-sass-styleguide'], function () {

    var materialSassConfig = _.cloneDeep(SASS_CONFIG);
    materialSassConfig.includePaths = materialSassConfig.includePaths.concat(['src/angular-material/original/src', 'src/angular-material/custom/src']);
    var materialCssStream = gulp.src('src/angular-material/custom/src/angular-material.scss')
        .pipe(process.env.mode === 'RELEASING' ? $.sass(materialSassConfig) : $.sass(materialSassConfig).on('error', $.sass.logError));

    var commonUiCssStream = gulp.src(build_config.SOURCES.sass)
        .pipe(process.env.mode === 'RELEASING' ? $.sass(SASS_CONFIG) : $.sass(SASS_CONFIG).on('error', $.sass.logError));

    return mergeStream(materialCssStream, commonUiCssStream)
        .pipe($.concat(build_config.SOURCES.name + '.css'))
        .pipe(gulp.dest(dirs.build));
});

gulp.task('build-js', function () {

    var jsGlobs = _.flattenDeep([build_config.SOURCES.javascript_vendors, build_config.SOURCES.javascript, '!src/**/*.spec.js']);
    var sources = gulp.src(jsGlobs)
        .pipe(doPlumber())
        .pipe($.ngAnnotate({single_quotes: true}));

    var templateGlobs = _.flattenDeep([build_config.SOURCES.templates_vendors, build_config.SOURCES.templates, dirs.build + '/icons/icon-pack.svg']);
    var templates = gulp.src(templateGlobs)
        .pipe(doPlumber())
        .pipe($.htmlmin({
            removeComments: true,
            collapseWhitespace: true
        }))
        .pipe(angularTemplateCache({
            filename: build_config.SOURCES.templates_name + '.js',
            module: build_config.SOURCES.templates_name,
            standalone: true
        }))
        .pipe($.wrap('\'use strict\';\n\n<%= contents %>\n\n'));

    return mergeStream(series(templates, sources))
        .pipe($.wrap('(function(){\n<%= contents %>\n})();'))
        .pipe($.concat(build_config.SOURCES.name + '.js'))
        .pipe(gulp.dest(dirs.build));

});
