'use strict';

var gulp = require('gulp'),
    $ = require('gulp-load-plugins')(),
    del = require('del');
var build_config = require('../config/build.config.js'),
    dirs = build_config.DIRS;
var coverage = 'reports/coverage';

gulp.task('clean', function (done) {
    var demo = dirs.demo;
    return del([ // clean everything in demo EXCEPT common-ui folder
        dirs.build,
        demo + '/**/*',
        '!' + demo + '/common-ui',
        '!' + demo + '/common-ui/**/*'
    ], done);
});

gulp.task('clean-coverage', function() {
    return del(coverage);
});