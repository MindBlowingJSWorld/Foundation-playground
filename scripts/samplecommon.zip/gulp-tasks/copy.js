var gulp = require('gulp');
var _ = require('lodash');
var joinPath = require('join-path');

var build_config = require('../config/build.config.js'),
    dirs = build_config.DIRS,
    demo = build_config.DEMO;

var CONFIG =  require('../config/build.foundation-styles.config.js');

gulp.task('copy-build',function(){
    return gulp.src(joinPath(dirs.build, '**/*.*'), {base: dirs.build})
        .pipe(gulp.dest(joinPath(dirs.demo, 'build')));
});

gulp.task('copy-styleguide-resources', function() {
    return gulp.src(CONFIG.styleguide.resources)
        .pipe(gulp.dest(CONFIG.styleguide.outputDir));
});

gulp.task('copy-dependencies-to-demo', function() {
    var paths = _.concat(build_config.VENDOR.javascript, build_config.DEMO.vendor_js);
    return gulp.src(paths, {base: 'node_modules'})
        .pipe(gulp.dest(joinPath(dirs.demo, 'vendors')));
});