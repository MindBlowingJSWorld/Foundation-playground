var gulp = require('gulp');
var runSequence = require('run-sequence');
var styleguide = require('sc5-styleguide');
var $ = require('gulp-load-plugins')();
var CONFIG = require('../config/build.foundation-styles.config.js');
var SASS_CONFIG = require('../config/sass.config');

var util = require('./util.js');

var styleguideSettings = {
    title: 'Nordea Styles',
    server: false,
    rootPath: CONFIG.styleguide.outputDir,
    appRoot: './', // demo/foundation-styles
    overviewPath: CONFIG.styleguide.overview,
    commonClass: ['styleguide'],
    disableEncapsulation: true,
    disableHtml5Mode: true,
    extraHead: [
        '<script src="./jquery.js"></script>',
        '<script src="./what-input.js"></script>',
        '<script src="./svg4everybody.min.js"></script>',
        '<script>svg4everybody()</script>',
        '<script src="../build/dbw-foundation-nordea.js"></script>',
        '<script src="./init-foundation.js"></script>'
    ],
    parsers: {
        'sass': 'scss'
    }
};

gulp.task('generate-styleguide', function () {
    return gulp.src(CONFIG.sass.all)
        .pipe($.plumber())
        .pipe(styleguide.generate(styleguideSettings))
        .pipe(gulp.dest(CONFIG.styleguide.outputDir));
});

gulp.task('apply-styleguide-styles', function () {
    return gulp.src(CONFIG.sass.main)
        .pipe($.plumber())
        .pipe($.sass(SASS_CONFIG))
        .pipe($.autoprefixer({
            browsers: CONFIG.browserCompatibility
        }))
        .pipe(styleguide.applyStyles())
        .pipe(gulp.dest(CONFIG.styleguide.outputDir));
});

gulp.task('build-sass-styleguide', function () {
    return util.buildSass(false);
});

gulp.task('javascript', function () {
    return util.buildJavascript(false);
});

gulp.task('images', function () {
    return gulp.src(CONFIG.images)
        .pipe(gulp.dest(CONFIG.dist.imgDir));
});


gulp.task('fonts', function () {
    return gulp.src(CONFIG.fonts)
        .pipe(gulp.dest(CONFIG.dist.fontDir));
});

gulp.task('styleguide', function (cb) {
    runSequence(
        ['javascript', 'images', 'fonts'],
        'copy-styleguide-resources',
        ['generate-styleguide', 'apply-styleguide-styles'], cb);
});