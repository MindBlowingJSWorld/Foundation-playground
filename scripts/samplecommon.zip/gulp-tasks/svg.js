'use strict';

var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
var joinPath = require('join-path');
var build_config = require('../config/build.config.js'),
    dirs = build_config.DIRS,
    srcs = build_config.SOURCES;


gulp.task('process-icons', function () {
    var svgSpriteConfig = {
        mode: {
            symbol: true // Don't use defs. Chrome bug prevents overriding color using the currentColor method.
        },
        svg: {
            xmlDeclaration: false,
            dimensionAttributes: true
        },
        shape: {
            transform: [
                {
                    svgo: {
                        plugins: [
                            {
                                removeTitle: true // At least currently titles are useless (e.g. 'NORDEA_icons_32_1')
                            },
                            {
                                removeAttrs: {
                                    attrs: '*:(stroke|fill)'
                                }
                            }
                        ]
                    }
                }
            ]
        }
    };

    return gulp.src(srcs.svg_icons)
        .pipe($.svgSprite(svgSpriteConfig))
        .pipe($.replace(/^(<svg)/, '$1 style="height:0;width:0;position:absolute;visibility:hidden;"'))
        .pipe($.rename('icon-pack.svg'))
        .pipe(gulp.dest(joinPath(dirs.build, 'icons')));
});