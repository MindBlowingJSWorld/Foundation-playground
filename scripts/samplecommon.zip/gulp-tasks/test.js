'use strict';
var gulp = require('gulp');
var karma = require('karma');
var path = require('path');
var _ = require('lodash');
var runSequence = require('run-sequence');

var karmaDefaults = {
    configFile: path.join(__dirname, '../config/karma.config.js'),
    logLevel: 'INFO',
    singleRun: true,
    autoWatch: false
};

var karmaReleaseDefaults = _.extend(_.clone(karmaDefaults), {
    configFile: path.join(__dirname, '../config/karma.config.release.js')
});

var startKarmaServer = function (karmaConfig, done) {
    var server = new karma.Server(karmaConfig, done);
    server.start();
};

gulp.task('test-release', ['build-demo'], function (done) { // run once
    startKarmaServer(karmaReleaseDefaults, done);
});

gulp.task('test-ci', ['clean-coverage', 'analyze-ci'], function (cb) {
    var karmaConfig = _.defaults({
        singleRun: false,
        autoWatch: true,
        logLevel: 'DEBUG'
    }, karmaReleaseDefaults);
    startKarmaServer(karmaConfig, cb);
});

gulp.task('test-jenkins', ['build'], function (cb) {
    var karmaConfig = _.defaults({
        browsers: ['Firefox']
    }, karmaReleaseDefaults);
    startKarmaServer(karmaConfig, cb);
});

gulp.task('unit-test', function (done) {
    var karmaConfig = _.extend(karmaDefaults, {
        singleRun: false,
        autoWatch: true
    });
    startKarmaServer(karmaConfig, done);
});

// test driven development / test develop demo/documents
gulp.task('tdd', function (done) {
    return runSequence(
        ['run-demo', 'unit-test'],
        done
    );
});
