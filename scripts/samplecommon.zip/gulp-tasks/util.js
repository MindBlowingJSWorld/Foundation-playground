var gulp = require('gulp');
var plumber = require('gulp-plumber');
var gulpif = require('gulp-if');
var $ = require('gulp-load-plugins')();
var rename = require('gulp-rename');

var CONFIG = require('../config/build.foundation-styles.config.js');
var SASS_CONFIG = require('../config/sass.config');

var doPlumber = function () {
    return gulpif(process.env.mode === 'RELEASING', plumber());
};

// TODO additional minification when doMinify === true
var buildJavascript = function (doMinify) {
    var uglify = $.uglify()
        .on('error', function (e) {
            console.log(e);
        });

    return gulp.src(CONFIG.javascript)
        .pipe($.if(doMinify, $.sourcemaps.init()))
        .pipe($.babel({
            presets: ['es2015'],
            babelrc: false
        }))
        .pipe($.concat(CONFIG.distName + '.js'))
        .pipe(gulp.dest(CONFIG.dist.mainDir));
};

var buildSass = function (doMinify) {
    return gulp.src(CONFIG.sass.main)
        .pipe($.if(doMinify, $.sourcemaps.init()))
        .pipe($.sass(SASS_CONFIG))
        .pipe($.autoprefixer({
            browsers: CONFIG.browserCompatibility
        }))
        .pipe(rename({basename: CONFIG.distName}))
        .pipe(gulp.dest(CONFIG.dist.mainDir))
        //min css
        .pipe($.if(doMinify, $.minifyCss()))
        .pipe($.if(doMinify, rename({extname: '.min.css'})))
        .pipe($.if(doMinify, $.sourcemaps.write('./')))
        .pipe(gulp.dest(CONFIG.dist.mainDir));
};

module.exports = {
    doPlumber: doPlumber,
    buildJavascript: buildJavascript,
    buildSass: buildSass
};