'use strict';

var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
var build_config = require('../config/build.config.js'),
    dirs = build_config.DIRS;
var argv = require('yargs').argv;
var base_dirs = [dirs.demo];

gulp.task('webserver', function() {
    var isStaticReload = argv.sr;
    return gulp.src(base_dirs)
        .pipe($.webserver({
            port: 9000,
            livereload: isStaticReload ? false : true,
            open:true
        }));
});