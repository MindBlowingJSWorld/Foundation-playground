var gulp = require('gulp');
var requireDir = require('require-dir');
requireDir('gulp-tasks', {recurse: true});
var $ = require('gulp-load-plugins')();

// shortcuts
gulp.task('tr', ['test-release']);

gulp.task('u', ['unit-test']);

gulp.task('default', ['run-demo']);