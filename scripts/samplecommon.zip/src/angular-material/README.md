# Angular Material components

Based on version: 1.1.0-RC4

Unfortunately `angular-material` NPM package is a compiled distribution and even though it's somewhat modular, 
it's not enough to cherrypick components without adding a lot of other stuff. Therefore we have to pick source code manually
and modify them 
 
Directory `original` contains hand-picked files that have not been modified. Not all files from the source are included -- just those 
that are essential for other components or dependencies that are just difficult to remove. If you need to modify a file here, please move to a corresponding directory in `custom`.

Directory `custom` contains angular material source files that we have modified in some way, as well as extra files by us. The extra files are

* angular-material.scss: produces our custom angular material CSS bundle
* _input_container.scss: augments our `.input-container` style to make it work with angular material's classes

When updating to a new Angular Material version, be sure to update all files, including modified files in `custom`. 
This means that whenever possible, create unit tests for the customizations in your own files.
