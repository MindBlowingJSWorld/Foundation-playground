angular.module('material.core.theming', [])
    .factory('$mdTheming', dummyThemingFactory);

function dummyThemingFactory() {

    var dummyTheming = function () {};
    dummyTheming.inherit = function () {};

    return dummyTheming;
}