angular.module('dbw-common')
    .constant('nordeaPalette', [
        'primary',
        'secondary',
        'success',
        'info',
        'warning',
        'alert'
    ])
    .constant('keyBoardMap', {
        13: 'enter',
        27: 'escape',
        33: 'pageup',
        34: 'pagedown',
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    });