'use strict';

angular.module('dbw-common')
    .factory('CalendarFactory', function (SingleMonthCalendarModel) {

        // A holder for several SingleMonthCalendars
        var MonthsCalendar = function (monthViewCount, ndDateValidator, currentDate, selectedDate) {
            this.monthViewCount = monthViewCount;
            this.ndDateValidator = ndDateValidator;
            this.currentDate = moment(currentDate); // the current displayed visible date/month
            this.selectedDate = moment(selectedDate);
            this.previousSelectedDate = moment(selectedDate); // originally previousSelectedDate is selectedDate
            this.maxDateRange = ndDateValidator.getMaxDateRange();
            this.minDateRange = ndDateValidator.getMinDateRange();
            this.monthsCache = {};
        };

        MonthsCalendar.prototype.getMonthFromCache= function (currentMonth) {
            return this.monthsCache[currentMonth.year() + '-' + currentMonth.month()];
        };

        MonthsCalendar.prototype.saveMonthToCache= function (currentMonth, singleMonthCalendar) {
            this.monthsCache[currentMonth.year() + '-' + currentMonth.month()] = singleMonthCalendar;
        };

        MonthsCalendar.prototype.isNextMonthNavigable= function (currentDate) {
            return this.maxDateRange ? moment(currentDate).isBefore(moment().add(this.maxDateRange, 'months'), 'month') : true;
        };

        MonthsCalendar.prototype.isPrevMonthNavigable= function (currentMonth) {
            return this.minDateRange ? moment(currentMonth).isAfter(moment().subtract(this.minDateRange, 'months'), 'month') : true;
        };

        MonthsCalendar.prototype.getMonthsView= function () {

            var firstTileIndex = 0,
                lastTileIndex = this.monthViewCount - 1,
                displayedMonths = {};

            // create and return months. return months from cached if they are already created
            for (var monthId = 0; monthId < this.monthViewCount; monthId++) {
                var currentMonth = moment(this.currentDate).add(monthId, 'month');
                // the monthViewCount % 2 is tricky
                var currentDate = this.monthViewCount % 2 === 0 ? currentMonth : this.currentDate;
                var isNextLinkVisible = monthId === lastTileIndex && this.isNextMonthNavigable(currentDate);
                var isPrevLinkVisible = monthId === firstTileIndex && this.isPrevMonthNavigable(currentMonth);

                var singleMonthCalendar = this.getMonthFromCache(currentMonth);
                if (singleMonthCalendar) {
                    singleMonthCalendar.isNextLinkVisible = isNextLinkVisible;
                    singleMonthCalendar.isPrevLinkVisible = isPrevLinkVisible;
                } else {
                    singleMonthCalendar = new SingleMonthCalendarModel(currentMonth, isNextLinkVisible, isPrevLinkVisible, this.ndDateValidator,this.selectedDate);
                    singleMonthCalendar.setSelectedDate(this.selectedDate);
                    singleMonthCalendar.initWeeksTable();
                    this.saveMonthToCache(currentMonth, singleMonthCalendar);
                }
                displayedMonths[monthId] = singleMonthCalendar;
            }

            return displayedMonths;

        };

        MonthsCalendar.prototype.getMonthsViewByType= function (type) {

            switch (type) {
                case 'previous_month':
                    if (this.isPrevMonthNavigable(this.currentDate)) {
                        // check if date is disabled here, otherwise it could be possible to move back to one month
                        this.currentDate.subtract(1, 'month');
                    }
                    break;

                case 'next_month':
                    if (this.isNextMonthNavigable(this.currentDate)) {
                        this.currentDate.add(1, 'month');
                    }
                    break;

                case 'current_selected_month': // Note that current_selected_month means the month view which is currently being visible/selected
                    this.currentDate.set({'month': this.selectedDate.month()});
                    break;

                default:
                    return;
            }

            return this.getMonthsView();

        };

        MonthsCalendar.prototype.updateSelectedDate= function (newSelectedDate) {

            var cachedMonth = this.getMonthFromCache(this.selectedDate);

            if(cachedMonth){
                cachedMonth.updateWeeksTable(this.selectedDate, 'isSelected', false);
                cachedMonth = this.getMonthFromCache(newSelectedDate);
                cachedMonth.updateWeeksTable(newSelectedDate, 'isSelected', true);

                this.selectedDate.set({
                    'year': newSelectedDate.year(),
                    'month': newSelectedDate.month(),
                    'date': newSelectedDate.date()
                });

                this.currentDate = moment(this.selectedDate);
            }

        };

        MonthsCalendar.prototype.confirmSelectedDate= function () {
            this.previousSelectedDate = moment(this.selectedDate);
        };

        var initWeeksDay = function () {

            var weeksDay = [0, 1, 2, 3, 4, 5, 6].map(function (el, index) {
                return moment().weekday(index).format('ddd').charAt(0);
            });
            SingleMonthCalendarModel.prototype.setWeekDays(weeksDay);

        };

        return {
            initWeeksDay: initWeeksDay,
            getInstance: function (monthViewCount, ndDateValidator, currentDate, selectedDate) {
                initWeeksDay();
                return new MonthsCalendar(monthViewCount, ndDateValidator, currentDate, selectedDate);
            }
        };

});
