describe('CalendarFactory', function () {
    beforeEach(module('dbw-common'));

    var calendar,
        CalendarFactory, SingleMonthCalendarModel,
        ndDateValidator = {
            getMaxDateRange: function () {
                return false;
            },
            getMinDateRange: function () {
                return false;
            }
        };

    beforeEach(function() {
        module('dbw-common',function($provide) {

            SingleMonthCalendarModel = function (currentMonth, isNextLinkVisible, isPrevLinkVisible, ndDateValidator) {
                this.date = currentMonth;
                this.isNextLinkVisible = isNextLinkVisible;
                this.isPrevLinkVisible = isPrevLinkVisible;
                this.ndDateValidator = ndDateValidator;
            };

            SingleMonthCalendarModel.prototype = {
                setSelectedDate: function () {},
                initWeeksTable: function () {},
                setWeekDays: function () {},
                updateWeeksTable: function () {}
            };
            $provide.value('SingleMonthCalendarModel', SingleMonthCalendarModel);
        });
    });

    beforeEach(inject(function (_CalendarFactory_) {
        CalendarFactory = _CalendarFactory_;
    }));

    it('should setWeekDays on SingleMonthCalendarModel prototype on initWeeksDay', function () {
        spyOn(SingleMonthCalendarModel.prototype,'setWeekDays');
        CalendarFactory.initWeeksDay();
        expect(SingleMonthCalendarModel.prototype.setWeekDays).toHaveBeenCalled();
    });

    describe('getMonthsView', function () {
        var monthViews;

        it('should be able to get 1 month view', function () {
            calendar = CalendarFactory.getInstance(1,ndDateValidator,moment(), moment());
            monthViews= calendar.getMonthsView();

            expect(monthViews[0].isNextLinkVisible).toBeDefined();
            expect(Object.keys(monthViews).length).toBe(1);
        });

        it('should be able to get 2 month views', function () {
            calendar = CalendarFactory.getInstance(2,ndDateValidator,moment(), moment());
            monthViews= calendar.getMonthsView();

            expect(monthViews[0].isNextLinkVisible).toBeDefined();
            expect(Object.keys(monthViews).length).toBe(2);
        });

    });

    describe('getMonthsViewByType', function () {
        var currentMonth;

        beforeEach(function () {
            calendar = CalendarFactory.getInstance(1,ndDateValidator,moment(), moment());
            currentMonth = calendar.currentDate.month();
            spyOn(calendar,'isPrevMonthNavigable').and.returnValue(true);
            spyOn(calendar,'isNextMonthNavigable').and.returnValue(true);
        });

        it('should be able to get previous month view', function () {
            calendar.getMonthsViewByType('previous_month');
            expect(calendar.currentDate.month()).toEqual(currentMonth-1);
        });

        it('should be able to get next month view', function () {
            currentMonth = calendar.currentDate.month();
            calendar.getMonthsViewByType('next_month');
            expect(calendar.currentDate.month()).toEqual(currentMonth+1);
        });

        it('should be able to get the current month view', function () {
            currentMonth = calendar.currentDate.month();
            calendar.getMonthsViewByType('current_selected_month');
            expect(calendar.currentDate.month()).toEqual(currentMonth);
        });
    });

    describe('check if able to navigate to next or previous month', function () {

        beforeEach(function () {
            spyOn(ndDateValidator,'getMaxDateRange').and.returnValue(2);
            spyOn(ndDateValidator,'getMinDateRange').and.returnValue(2);
            calendar = CalendarFactory.getInstance(1,ndDateValidator,moment(), moment());
        });
        it('should be able to navigate to upcoming month within range', function () {
            expect(calendar.isNextMonthNavigable(moment())).toBe(true);
            expect(calendar.isNextMonthNavigable(moment().add(1,'month'))).toBe(true);
            expect(calendar.isNextMonthNavigable(moment().add(2,'month'))).toBe(false);
        });

        it('should be able to previous month within range', function () {
            expect(calendar.isPrevMonthNavigable(moment())).toBe(true);
            expect(calendar.isPrevMonthNavigable(moment().subtract(1,'month'))).toBe(true);
            expect(calendar.isPrevMonthNavigable(moment().subtract(2,'month'))).toBe(false);
        });

    });

    it('should be able to updateSelectedDate', function () {
        spyOn(SingleMonthCalendarModel.prototype, 'updateWeeksTable');
        calendar = CalendarFactory.getInstance(1,ndDateValidator,moment(), moment());
        calendar.getMonthsView();
        var currentSelectedDate = calendar.selectedDate.date();
        calendar.updateSelectedDate(moment());

        // call twice, once for update old selected value to false, once for update new selected date to tru
        expect(SingleMonthCalendarModel.prototype.updateWeeksTable.calls.count()).toBe(2);
        expect(calendar.currentDate.date()).toEqual(currentSelectedDate);
    });

});