'use strict';

angular.module('dbw-common')
    .factory('SingleMonthCalendarModel', SingleMonthCalendarModel);

function SingleMonthCalendarModel(datePickerUtil){

    var SingleMonthCalendar = function (currentMonth, isNextLinkVisible, isPrevLinkVisible, ndDateValidator,selectedDate) {
        currentMonth = currentMonth || moment();
        this.date = currentMonth;
        this.year = currentMonth.year();
        this.month = moment(currentMonth).format('MMMM');
        this.isNextLinkVisible = isNextLinkVisible;
        this.isPrevLinkVisible = isPrevLinkVisible;
        this.ndDateValidator = ndDateValidator;
        this.selectedDate = selectedDate || '';
        this.weekDays = this.weekDays || [];
        this.weeksTable = this.weeksTable || [];
    };

    // PRIVATE FUNCTIONS
    SingleMonthCalendar.prototype.monthDaysMap = function (d) {

        var momentDate = moment(this.date);

        return {
            date: momentDate,
            day: d,
            isToday: d && this.ndDateValidator.isToday(momentDate.date(d)),
            isSelected: d && this.ndDateValidator.isSameDate(momentDate.date(d), this.selectedDate),
            isDisabled: d ? (this.ndDateValidator.isDisabledDate(momentDate.date(d)) || !this.ndDateValidator.isWithinAvailableRange(momentDate.date(d)) ) : true
        };

    };

    SingleMonthCalendar.prototype.findDateIndexInWeeksTable = function (momentDate) {

        var overlappingDaysPrev = datePickerUtil.getPreviousMonthOverlappingDays(momentDate).length;
        var col = momentDate.weekday();
        // take into overlappingDaysPrev when we try to find out week of month
        var row = Math.ceil(momentDate.date() / 7) - 1 + (col < overlappingDaysPrev ? 1 : 0);

        return {
            row: row,
            col: col
        };

    };

    SingleMonthCalendar.prototype.getMonthCalendarDays = function () {

        var momentDate = moment(this.date);
        var pOMonthDays = datePickerUtil.getPreviousMonthOverlappingDays(momentDate);
        var monthDays = datePickerUtil.getDaysOfMonth(momentDate);
        var nOMonthDays = datePickerUtil.getNextMonthOverlappingDays(momentDate);
        return pOMonthDays.concat(monthDays).concat(nOMonthDays).map(this.monthDaysMap, this);

    };

    // PUBLIC FUNCTIONS
    SingleMonthCalendar.prototype.initWeeksTable = function () {

        var oneMonthCalendarDays = this.getMonthCalendarDays(),
            weeksTable = [];

        for (var j = 0; j < oneMonthCalendarDays.length; j = j + 7) {
            weeksTable.push(oneMonthCalendarDays.slice(j, j + 7));
        }

        this.weeksTable = weeksTable;

    };


    SingleMonthCalendar.prototype.setSelectedDate = function (selectedDate) {
        this.selectedDate = selectedDate;
    };

    SingleMonthCalendar.prototype.setWeekDays = function (weekDays) {
        this.weekDays = weekDays;
    };

    SingleMonthCalendar.prototype.updateWeeksTable = function (momentDate, property, value) {
        var dateIndex = this.findDateIndexInWeeksTable(momentDate);
        // if the date is currently disabled, no need to update it
        if (this.weeksTable[dateIndex.row][dateIndex.col].isDisabled) {
            return;
        }
        this.weeksTable[dateIndex.row][dateIndex.col][property] = value;
    };

    return SingleMonthCalendar;
}
