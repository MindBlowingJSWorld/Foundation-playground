describe('SingleMonthCalendarModel', function () {
    beforeEach(module('dbw-common'));

    var singleMonthCalendar,
        sampleSelectedDate = '2016-03-18',
        sampleWeeksTable = [ // Sample weeks table for 2016 March
            ['', '',  1,  2,  3,  4,  5 ],
            [6,  7,   8,  9,  10, 11, 12],
            [13, 14, 15, 16,  17, 18, 19],
            [20, 21, 22, 23,  24, 25, 26],
            [27, 28, 29, 30,  31, '', '']
        ],
        expectedSelectedDateIndex = { // row 2, col 6 is 18
            row: 2,
            col: 5
        },
        mockedNdDateValidator = {
            isToday: function () {
                return false;
            },
            isSameDate: function () {
                return false;
            },
            isDisabledDate: function () {
                return false;
            },
            isWithinAvailableRange: function () {
                return true;
            }
        };

    beforeEach(function() {
        module('dbw-common',function($provide) {
            $provide.value('datePickerUtil', {
                getPreviousMonthOverlappingDays: function () {
                    return [''];
                },
                getDaysOfMonth: function () {
                    return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31];
                },
                getNextMonthOverlappingDays: function () {
                    return ['', '', ''];
                }
            });
        });
    });

    beforeEach(inject(function (SingleMonthCalendarModel) {
        singleMonthCalendar = new SingleMonthCalendarModel(moment(sampleSelectedDate),true,true,mockedNdDateValidator);
        singleMonthCalendar.initWeeksTable(); // init weeksTable
    }));


    it('should be able to return a correct weeksTable', function () {
        expect(singleMonthCalendar.weeksTable.length).toEqual(sampleWeeksTable.length);
    });

    it('should return a correct position (index) on weeks table for a specific date', function () {
        // row 2, col 5
        expect(singleMonthCalendar.findDateIndexInWeeksTable(moment(sampleSelectedDate))).toEqual(expectedSelectedDateIndex);
        
        // increase current sampleSelectedDate by 1 day, 19/03/2016
        // row 2, col 6
        expectedSelectedDateIndex.col++;
        expect(singleMonthCalendar.findDateIndexInWeeksTable(moment(sampleSelectedDate).add(1,'day'))).toEqual(expectedSelectedDateIndex);
        
        // increase current sampleSelectedDate by 1 week (7 days) 25/03/2016
        // row 3, col 5
        expectedSelectedDateIndex.col--;
        expectedSelectedDateIndex.row++;
        expect(singleMonthCalendar.findDateIndexInWeeksTable(moment(sampleSelectedDate).add(7,'day'))).toEqual(expectedSelectedDateIndex);
    });

    it('should be able to update a specific date isSelect to true', function () {
        var coordinationObj = singleMonthCalendar.findDateIndexInWeeksTable(moment(sampleSelectedDate));
        var isSelected = singleMonthCalendar.weeksTable[coordinationObj.row][coordinationObj.col].isSelected;
        expect(isSelected).toBeFalsy();

        singleMonthCalendar.updateWeeksTable(moment(sampleSelectedDate),'isSelected',true);
        isSelected = singleMonthCalendar.weeksTable[coordinationObj.row][coordinationObj.col].isSelected;
        expect(isSelected).toBeTruthy();

        singleMonthCalendar.updateWeeksTable(moment(sampleSelectedDate),'isSelected',false);
        isSelected = singleMonthCalendar.weeksTable[coordinationObj.row][coordinationObj.col].isSelected;
        expect(isSelected).toBeFalsy();
    });
});