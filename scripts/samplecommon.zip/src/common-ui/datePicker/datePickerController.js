'use strict';

angular.module('dbw-common')
    .controller('DatePickerController', DatePickerController);

function DatePickerController($scope, CalendarFactory, datePickerNavigationHandler, ndDateValidatorFactory, $timeout) {
    var datePicker = this;

    datePicker.init = init;
    datePicker.getTimePeriod = getTimePeriod;
    datePicker.updateMonthsView = updateMonthsView;
    datePicker.validateInputDate = validateInputDate;
    datePicker.goToPreviousMonth = goToPreviousMonth;
    datePicker.goToNextMonth = goToNextMonth;
    datePicker.selectDate = selectDate;
    datePicker.close = close;
    datePicker.open = open;
    datePicker.cancel = cancel;
    datePicker.onFocus = onFocus;

    datePicker.init();

    ///////////////////////////////////////

    function init() {

        datePicker.maxDateRange = datePicker.maxDateRange && Number(datePicker.maxDateRange);
        datePicker.minDateRange = datePicker.minDateRange && Number(datePicker.minDateRange);
        datePicker.show = false;
        datePicker.displayedMonths = {0: 0};
        datePicker.monthViewCount = datePicker.monthViewCount && Number(datePicker.monthViewCount) || 1;
        datePicker.dateFormat = datePicker.dateFormat || 'YYYY-MM-DD';
        datePicker.onChange = datePicker.onChange || angular.noop;
        datePicker.ndDateValidator = ndDateValidatorFactory.createDateValidator(datePicker.maxDateRange, datePicker.minDateRange);
        datePicker.monthsCalendar = datePicker.monthsCalendar || CalendarFactory.getInstance(datePicker.monthViewCount, datePicker.ndDateValidator, moment(), datePicker.model);
        datePicker.model = moment(datePicker.model).format(datePicker.dateFormat);

        $scope.$on('$destroy', function () {
            datePickerNavigationHandler.reset();
        });
    }

    function getTimePeriod(startingTime, viewCount, direction) {

        var month = moment(startingTime).add(direction === 'next_month' ? 1 : 0, 'month');
        var endDate = moment(month).endOf('month');

        if (Number(viewCount) >= 2) {
            endDate = (direction === 'next_month') ? moment(startingTime).add(viewCount, 'month').endOf('month') : moment(startingTime).add(viewCount - 1, 'month').endOf('month');
        }

        return {
            month: month,
            start: moment(month).startOf('month'),
            end: endDate
        };

    }

    function updateMonthsView(monthsCalendar, monthViewType) {

        if (typeof datePicker.getDisabledDays === 'function') {

            var navigatedToMonth = datePicker.getTimePeriod(moment(monthsCalendar.currentDate), datePicker.monthViewCount, monthViewType);
            var startDate = navigatedToMonth.start;
            var endDate = navigatedToMonth.end;

            var cachedMonth = monthsCalendar.getMonthFromCache(moment(new Date(startDate))) && monthsCalendar.getMonthFromCache(moment(new Date(endDate)));

            if (!cachedMonth) {

                datePicker.onLoading = true;
                datePicker.getDisabledDays(startDate, endDate).then(function (disabledDates) {
                    datePicker.onLoading = false;
                    if (disabledDates) {
                        datePicker.ndDateValidator.addDisabledDates(disabledDates);
                    }
                    datePicker.displayedMonths = monthsCalendar.getMonthsViewByType(monthViewType);
                });

                return;
            }
        }

        datePicker.displayedMonths = monthsCalendar.getMonthsViewByType(monthViewType);

    }

    function validateInputDate() { //TODO datePicker one should be removed since input field will not be a part of datePicker
        return !datePicker.ndDateValidator.isDisabledDate(datePicker.model);
    }

    // USER INTERACTIONS
    function goToPreviousMonth() {
        datePicker.updateMonthsView(datePicker.monthsCalendar, 'previous_month');
    }

    function goToNextMonth() {
        datePicker.updateMonthsView(datePicker.monthsCalendar, 'next_month');
    }

    function selectDate(newSelectedDate, event) { // Called when user select a date by clicking or press key
        datePicker.monthsCalendar.updateSelectedDate(moment(newSelectedDate));
        datePicker.model = moment(datePicker.monthsCalendar.selectedDate).format(datePicker.dateFormat).toUpperCase();
        $timeout(function () {
            datePicker.onChange({data: {selectedDate: datePicker.model, event: event || 'select'}});
        });
    }

    function close(e) {
        if (e) {
            e.stopPropagation();
        }
        datePickerNavigationHandler.reset();
        datePicker.show = false;
    }

    function open() {
        datePicker.updateMonthsView(datePicker.monthsCalendar, 'current_selected_month');
        datePicker.show = true;
    }

    function cancel(e) { // Select the previous selectedDate and close
        datePicker.selectDate(datePicker.monthsCalendar.previousSelectedDate, 'cancel');
        datePicker.close(e);
    }

    datePicker.ok = function (e) { // Confirm the selectedDate and close
        datePicker.monthsCalendar.confirmSelectedDate();
        datePicker.onChange({data: {selectedDate: datePicker.model, event: 'ok'}});
        datePicker.close(e);
    };

    // EVENTS
    function navigateToNewSelectDate(currentDate) {

        var isSelectedDateVisible = false, i = 0;

        while (i < Object.keys(datePicker.displayedMonths).length) {
            if (datePicker.displayedMonths[i].date.month() === currentDate.month()) {
                isSelectedDateVisible = true;
                break;
            }
            i++;
        }

        // Output
        if (isSelectedDateVisible) {
            datePicker.selectDate(currentDate);
        } else {
            datePicker.displayedMonths = datePicker.monthsCalendar.getMonthsView();
            datePicker.selectDate(currentDate);
        }

    }

    function keyDownHandler(e, flag, getNewSelectedDate) {

        if (datePicker.show) {

            switch (flag) {
                case 'navigable':
                    var _currentDate = getNewSelectedDate(datePicker.monthsCalendar.currentDate);
                    navigateToNewSelectDate(_currentDate);
                    break;

                case 'enter':
                    datePicker.ok();
                    break;

                case 'escape':
                    datePicker.cancel();
                    break;
            }

            $scope.$apply();
        }
    }

    function onFocus(e) {
        datePickerNavigationHandler.setDateValidator(datePicker.ndDateValidator);
        datePickerNavigationHandler.addHandler(keyDownHandler); // Register callbacks
    }


}

