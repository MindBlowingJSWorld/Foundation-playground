'use strict';

describe('datePickerController', function () {
    beforeEach(module('dbw-common'));
    var datePickerController, scope, $timeout;

    beforeEach(function () {
        module(function ($provide) {

            var MockedMonthsCalendar = function () {
                var _this = this;
                this.getMonthsViewByType = angular.noop;
                this.getMonthFromCache = angular.noop;
                this.updateSelectedDate = function (selectedDate) {
                    _this.previousSelectedDate = selectedDate;
                    _this.selectedDate = selectedDate;
                };
                this.confirmSelectedDate = angular.noop;
            };

            var MockedNdDateValidator = function () {
                this.isScandinavianLocale = angular.noop;
                this.addDisabledDates = angular.noop;
            };

            $provide.value('CalendarFactory', {
                initWeeksDay: angular.noop,
                getInstance: function () {
                    return new MockedMonthsCalendar();
                }
            });

            $provide.value('ndDateValidatorFactory', {
                createDateValidator: function () {
                    return new MockedNdDateValidator();
                }
            });

            $provide.value('datePickerNavigationHandler', {
                reset: angular.noop
            });
        });
    });

    beforeEach(inject(function ($controller, $rootScope, $locale, CalendarFactory, datePickerNavigationHandler, ndDateValidatorFactory, _$timeout_) {
        scope = $rootScope.$new();
        datePickerController = $controller('DatePickerController', {
            $scope: scope,
            $locale: $locale,
            CalendarFactory: CalendarFactory,
            datePickerNavigationHandler: datePickerNavigationHandler,
            ndDateValidatorFactory: ndDateValidatorFactory
        });
        $timeout = _$timeout_;
    }));

    it('should exist', function () {
        expect(datePickerController).toBeDefined();
    });

    it('should be able to get next time period in the case of monthViewCount = 1', function () {
        var startingTime = moment(),
            viewSpan = 1,
            direction = 'next_month';

        var expectedResult = {
            start: moment().add(1, 'month').startOf('month'),
            end: moment().add(1, 'month').endOf('month')
        };

        var result = datePickerController.getTimePeriod(startingTime, viewSpan, direction);

        expect(result.start).toEqual(expectedResult.start);
        expect(result.end).toEqual(expectedResult.end);
    });

    it('should be able to get next time period in the case of monthViewCount = 2', function () {
        var startingTime = moment(),
            viewSpan = 2,
            direction = 'next_month';

        var expectedResult = {
            start: moment().add(1, 'month').startOf('month'),
            end: moment().add(2, 'month').endOf('month')
        };

        var result = datePickerController.getTimePeriod(startingTime, viewSpan, direction);

        expect(result.start).toEqual(expectedResult.start);
        expect(result.end).toEqual(expectedResult.end);

        viewSpan = 2;
        direction = 'current_selected_month';
        expectedResult = {
            start: moment().add(0, 'month').startOf('month'),
            end: moment().add(1, 'month').endOf('month')
        };

        result = datePickerController.getTimePeriod(startingTime, viewSpan, direction);

        expect(result.start).toEqual(expectedResult.start);
        expect(result.end).toEqual(expectedResult.end);
    });


    it('should update months view correctly', inject(function ($q) {

        spyOn(datePickerController.monthsCalendar, 'getMonthsViewByType');
        spyOn(datePickerController, 'getTimePeriod').and.callThrough();
        spyOn(datePickerController.monthsCalendar, 'getMonthFromCache');
        spyOn(datePickerController.ndDateValidator, 'addDisabledDates');
        datePickerController.getDisabledDays = undefined;

        datePickerController.updateMonthsView(datePickerController.monthsCalendar, 'next_month');

        expect(datePickerController.getTimePeriod).not.toHaveBeenCalled();
        expect(datePickerController.monthsCalendar.getMonthFromCache).not.toHaveBeenCalled();
        expect(datePickerController.ndDateValidator.addDisabledDates).not.toHaveBeenCalled();
        expect(datePickerController.monthsCalendar.getMonthsViewByType).toHaveBeenCalled();

        datePickerController.getDisabledDays = angular.noop;
        spyOn(datePickerController, 'getDisabledDays').and.returnValue($q.when(['2016-03-22', '2016-03-23']));

        datePickerController.updateMonthsView(datePickerController.monthsCalendar, 'next_month');
        scope.$apply();

        expect(datePickerController.getTimePeriod).toHaveBeenCalled();
        expect(datePickerController.monthsCalendar.getMonthFromCache).toHaveBeenCalled();
        expect(datePickerController.getDisabledDays).toHaveBeenCalled();
        expect(datePickerController.ndDateValidator.addDisabledDates).toHaveBeenCalledWith(['2016-03-22', '2016-03-23']);
        expect(datePickerController.monthsCalendar.getMonthsViewByType).toHaveBeenCalled();

    }));

    it('should be able to select date', function () {

        spyOn(datePickerController.monthsCalendar, 'updateSelectedDate');
        var newSelectedDate = '2016-03-24';
        datePickerController.selectDate(newSelectedDate);
        expect(datePickerController.monthsCalendar.updateSelectedDate).toHaveBeenCalledWith(moment(newSelectedDate));

    });

    it('should format date according to date format', function () {
        datePickerController.model = '2016-03-22';
        datePickerController.dateFormat = 'DD-MM-YYYY';

        datePickerController.init();

        expect(datePickerController.model).toEqual('22-03-2016');
    });

    describe('onChange callback should receive correct parameter', function () {
        var newSelectedDate, expectedParam;

        beforeEach(function () {
            newSelectedDate = '2016-03-22';
            expectedParam = {
                data: {
                    selectedDate: newSelectedDate,
                    event: 'select'
                }
            };
            spyOn(datePickerController, 'onChange');
            datePickerController.selectDate(newSelectedDate);
            $timeout.flush();
            scope.$apply();
        });

        it('onSelect and ok', function () {
            expect(datePickerController.onChange).toHaveBeenCalledWith(expectedParam);
            datePickerController.ok();
            scope.$apply();
            expectedParam.data.event = 'ok';
            expect(datePickerController.onChange).toHaveBeenCalledWith(expectedParam);
        });

        it('onSelect and cancel', function () {
            expect(datePickerController.onChange).toHaveBeenCalledWith(expectedParam);
            datePickerController.cancel();
            $timeout.flush();
            scope.$apply();
            expectedParam.data.event = 'cancel';
            expect(datePickerController.onChange).toHaveBeenCalledWith(expectedParam);
        });
    })

});
