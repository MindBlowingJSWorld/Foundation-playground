'use strict';

angular.module('dbw-common')
    .directive('ndDatePicker', datePickerDirective);

function datePickerDirective($interpolate) {
    var PANEL_POSITION_CLASSES = {
        'top left': 'datePicker-panel--top-left',
        'top right': 'datePicker-panel--top-right',
        'bottom left': 'datePicker-panel--bottom-left',
        'bottom right': 'datePicker-panel--bottom-right'
    };

    return {
        templateUrl: 'datePicker/datePicker.tpl.html',
        restrict: 'E',
        transclude: true,
        scope: {
            getDisabledDays: '=',
            monthViewCount: '@',
            dateFormat: '@',
            maxDateRange: '@',
            minDateRange: '@',
            onChange: '&',
            model: '=?',
            position: '@'
        },
        link: link,
        controller: 'DatePickerController',
        controllerAs: 'datePicker',
        bindToController: true
    };

    function link($scope, iElem, iAttrs, controller, transclude) {
        var positionKey = parsePositionKey();
        $scope.panelPositionClass = PANEL_POSITION_CLASSES[positionKey];

        transclude(function(clone) {
            if (clone.length > 0 && _.trim(clone[0].outerHTML).length > 0) {
                $scope.hasTranscludedContent = true;
            }
        });

        function parsePositionKey() {
            var position = $interpolate(iAttrs.position || 'top left')($scope);
            var matches = /\s*(top|bottom)\s+(left|right)\s*/.exec(position);
            if (!matches || matches.length !== 3) {
                return 'top left';
            } else {
                return matches[1] + ' ' + matches[2];
            }
        }
    }

}

