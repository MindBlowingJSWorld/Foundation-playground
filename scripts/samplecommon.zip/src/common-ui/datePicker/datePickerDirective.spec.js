'use strict';

describe('Date picker', function() {

    var $rootScope, $compile, $timeout, pageScope;

    beforeEach(module('dbw-common'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        pageScope = $injector.get('$rootScope').$new();
    }));

    beforeEach(inject(function($injector) {
        $rootScope = $injector.get('$rootScope');
        $compile = $injector.get('$compile');
        $timeout = $injector.get('$timeout');
    }));

    function compile(template) {
        var container;
        container = $compile(template)(pageScope);
        pageScope.$apply();
        return container;
    }

    function findSvgIconName(element) {
        var iconRef = element.find('svg use').attr('xlink:href');
        if (iconRef) {
            return iconRef.split('#')[1];
        } else {
            return undefined;
        }
    }

    it('when no content to transclude given it displays calendar icon in the closed mode', function() {
        var directiveEl = compile('<nd-date-picker></nd-date-picker>');

        expect(findSvgIconName(directiveEl.find('a'))).toEqual('calendar');
    });

    it('when content to transclude is given it displays the content only', function() {
        var directiveEl = compile('<nd-date-picker><span>FOO</span></nd-date-picker>');
        expect(findSvgIconName(directiveEl.find('a'))).toBeUndefined();
        expect(directiveEl.find('a').html()).toMatch(/^.*FOO.*$/);

        directiveEl = compile('<nd-date-picker><nd-icon icon="arrow_down_sml"></nd-icon></nd-date-picker>');
        expect(findSvgIconName(directiveEl.find('a'))).toEqual('arrow_down_sml');
    });

    it('does not consider whitespaces only to be content to transclude', function() {
        var directiveEl = compile('<nd-date-picker>   </nd-date-picker>');
        expect(findSvgIconName(directiveEl.find('a'))).toEqual('calendar');
    });

    it('sets default panel position class when position attribute not defined', function() {
        var directiveEl = compile('<nd-date-picker></nd-date-picker>');
        expect(directiveEl.find('.datePicker-panel')).toHaveClass('datePicker-panel--top-left');
    });

    it('sets panel position class according to position attribute', function() {
        var directiveEl = compile('<nd-date-picker position="top left" ng-model="foo"></nd-date-picker>');
        expect(directiveEl.find('.datePicker-panel')).toHaveClass('datePicker-panel--top-left');

        directiveEl = compile('<nd-date-picker position="top right"></nd-date-picker>');
        expect(directiveEl.find('.datePicker-panel')).toHaveClass('datePicker-panel--top-right');

        pageScope.position = ' bottom left ';
        directiveEl = compile('<nd-date-picker position="{{position}}"></nd-date-picker>');
        expect(directiveEl.find('.datePicker-panel')).toHaveClass('datePicker-panel--bottom-left');

        pageScope.position = ' bottom    right';
        directiveEl = compile('<nd-date-picker position="{{position}}"></nd-date-picker>');
        expect(directiveEl.find('.datePicker-panel')).toHaveClass('datePicker-panel--bottom-right');
    });

    it('sets default panel position class when position attribute is invalid', function() {
        // Invalid position tokens
        var directiveEl = compile('<nd-date-picker position="foo bar"></nd-date-picker>');
        expect(directiveEl.find('.datePicker-panel')).toHaveClass('datePicker-panel--top-left');

        // Wrong order
        directiveEl = compile('<nd-date-picker position="right top"></nd-date-picker>');
        expect(directiveEl.find('.datePicker-panel')).toHaveClass('datePicker-panel--top-left');
    });
});