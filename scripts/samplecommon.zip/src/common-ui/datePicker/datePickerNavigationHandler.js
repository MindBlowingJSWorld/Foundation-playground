'use strict';

angular.module('dbw-common')
    .factory('datePickerNavigationHandler', DatePickerNavigationHandler);

function DatePickerNavigationHandler($document, keyBoardMap) {
    var keyDownHandler, ndDateValidator, duration = 0,
        durationMap = {left: -1, right: 1, up: -7, down: 7};

    var getNewSelectedDate = function (currentDate) {
        var navigateToDate = moment(currentDate).add(duration, 'day');
        if (ndDateValidator.isWithinAvailableRange(navigateToDate)) {
            currentDate.add(duration, 'day');
            while (ndDateValidator.isDisabledDate(navigateToDate)) { // advance to the next banking day
                duration = (duration === 0) ? 1 : duration;
                currentDate.add(duration, 'day');
                navigateToDate = currentDate;
            }
        }
        return currentDate;
    };

    var keyDownHandlerWrapper = function (e) { // Decorate keyDownHandler
        if (typeof keyDownHandler === 'function') {
            e.preventDefault();
            var keyName = keyBoardMap[event.which];
            duration = durationMap[keyName]; // update the duration
            var flag = duration ? 'navigable' : keyName;
            keyDownHandler(e, flag, getNewSelectedDate);
        }
    };

    var removeHandler = function () {
        keyDownHandler = undefined;
        $document.off('keydown', keyDownHandlerWrapper);
    };

    var addHandler = function (fn) {
        if (keyDownHandler) {
            removeHandler();
        }
        keyDownHandler = fn;
        $document.on('keydown', keyDownHandlerWrapper);

    };

    var reset = function () {
        ndDateValidator = undefined;
        removeHandler();
    };

    var setDateValidator = function (_ndDateValidator_) {
        ndDateValidator = _ndDateValidator_;
    };

    return {
        addHandler: addHandler,
        reset: reset,
        setDateValidator: setDateValidator
    };
}
