'use strict';

angular.module('dbw-common')
    .factory('datePickerUtil', DatePickerUtil);

function DatePickerUtil() { //TODO change this to a reusable date and month services

    // get array of days in month (e.g [1,2,3...31])
    var getDaysOfMonth = function (momentObj) {
        var numberOfDays = momentObj.daysInMonth();
        var daysArray = [];
        for (var i = 1; i <= numberOfDays; i++) {
            daysArray.push(i);
        }
        return daysArray;
    };

    /**
     * Get number of days from previous month overlapping current month
     * @param momentDate
     * @returns {Array}
     * eg: input = 1st Sep, 2015
     *     output =  number of last week days from August 2015 overlapping first week of September
     */
    var getPreviousMonthOverlappingDays = function (momentDate) {
        var firstWeekDay = moment(momentDate).startOf('month').weekday();
        var prevMonthDays = [];
        for (var i = 1; i <= firstWeekDay; i += 1) {
            prevMonthDays.push('');
        }
        return prevMonthDays;
    };

    /**
     * Get number of next month days overlapping in current month
     * @param momentDate
     * @returns {Array}
     * eg: input = 1st Sep, 2015
     *     output =  number of first week days from October 2015 overlapping last week of September
     */
    var getNextMonthOverlappingDays = function (momentDate) {
        var lastWeekDay = moment(momentDate).endOf('month').weekday();
        var nextMonthDays = [];
        var howManyNextDays = 6 - lastWeekDay;
        for (var i = 1; i <= howManyNextDays; i += 1) {
            nextMonthDays.push('');
        }
        return nextMonthDays;
    };


    return {
        getDaysOfMonth: getDaysOfMonth,
        getPreviousMonthOverlappingDays: getPreviousMonthOverlappingDays,
        getNextMonthOverlappingDays: getNextMonthOverlappingDays
    };
}
