'use strict';

describe('ndDatePicker util', function () {
    beforeEach(module('dbw-common'));
    var datePickerUtil;

    beforeEach(function () {
        module(function ($provide) {
            $provide.value('dueDateValidator', {
                validate: function () {
                    // given input already in normalized format
                    return true;
                }
            });
        });
    });
    beforeEach(
        inject(function (_datePickerUtil_) {
            datePickerUtil = _datePickerUtil_;
        })
    );
    it('should exist', function () {
        expect(datePickerUtil).toBeDefined();
    });

    it('should return number of days in current month if moment object is passed', function () {
        var numberOfDays = moment().endOf('month').date();
        var today = moment();
        expect(datePickerUtil.getDaysOfMonth(today).length).toBe(numberOfDays);
    });

    it('should return previous month overlapping days in first week of current month', function () {
        var firstMonthOfYear = moment([2016, 0]), previousMonthDays = 5;
        expect(datePickerUtil.getPreviousMonthOverlappingDays(firstMonthOfYear).length).toBe(previousMonthDays);
    });

    it('should return next month overlapping days in last week of current month', function () {
        var lastMonthOfYear = moment([2015, 11]), nextMonthDays = 2;
        expect(datePickerUtil.getNextMonthOverlappingDays(lastMonthOfYear).length).toBe(nextMonthDays);
    });
});
