angular.module('dbw-common')
    .factory('ndDateValidatorFactory', NdDateValidatorFactory);

function NdDateValidator(maxDateRange, minDateRange, dateFormat) {
    this.setMinDateRange(minDateRange);
    this.setMaxDateRange(maxDateRange);
    this.dateFormat = dateFormat || 'YYYY-MM-DD';
    this.disabledDates = [];
}

NdDateValidator.prototype = {
    acceptedDatePattern: /^\d{1,4}[-\.\/\s]{0,1}\d{1,2}[-\.\/\s]{0,1}\d{1,4}$/,
    scandinavianLocalePattern: /(se|fi|dk|no|sv|da)/i,

    // GET / SET
    setDisabledDates: function (disabledDates) {
        this.disabledDates = disabledDates;
    },

    addDisabledDate: function (disabledDate) {
        if (this.disabledDates.indexOf(disabledDate) === -1) {
            this.disabledDates.push(disabledDate);
        }
    },

    addDisabledDates: function (disabledDates) {

        if (disabledDates.constructor === Array) {

            var i;
            for (i = 0; i < disabledDates.length; i++) {
                this.addDisabledDate(disabledDates[i]);
            }

        } else if (this.isValidDate(disabledDates)) {
            this.addDisabledDate(disabledDates);
        }

    },

    resetDisabledDates: function () {
        this.disabledDates.length = 0;
    },

    // get, set maxDateRange
    getMaxDateRange: function () {
        return this.maxDateRange;
    },

    setMaxDateRange: function (maxDateRange) { // can be Number, String, moment obj. convert into a maxDate
        if(maxDateRange === undefined){
            this.maxDateRange = maxDateRange;
        }else if(typeof maxDateRange === 'number'){
            this.maxDateRange = Math.round(maxDateRange);
            this.maxDate = moment().add(Number(this.maxDateRange), 'months').startOf('day');
        }else if( ( typeof maxDateRange === 'string' && this.isValidDate(maxDateRange) ) || moment(new Date(maxDateRange)).isValid()){
            this.maxDate = moment( new Date(maxDateRange) );
            this.maxDateRange = Math.round(moment(moment(this.maxDate)).diff(moment(), 'months', true));
        }

    },

    // get, set minDateRange
    getMinDateRange: function () {
        return this.minDateRange;
    },

    setMinDateRange: function (minDateRange) {

        if(minDateRange === undefined){
            this.minDateRange = minDateRange;
        }else if(typeof minDateRange === 'number'){
            this.minDateRange = Math.round(minDateRange);
            this.minDate = moment().subtract(Number(this.minDateRange), 'months').startOf('day');
        }else if( ( typeof minDateRange === 'string' && this.isValidDate(minDateRange) ) || moment(new Date(minDateRange)).isValid()){
            this.minDate = moment( new Date(minDateRange));
            this.minDateRange = Math.round(moment().diff(moment(this.minDate), 'months', true));
        }

        //console.log('minDate: ',this.minDate);
        //console.log('minDateRange: ',this.minDateRange);
    },

    setFormat: function (format) {
        this.dateFormat = format;
    },

    // UTILITIES
    convertStringToMoment: function (dateString) {
        if (!this.isAcceptedDatePattern(dateString)) {
            return undefined;
        }
        return moment(dateString, this.dateFormat);
    },

    // ---- MAIN FEATURES ---- //
    // BASIC VALIDATIONS
    isNonEmptyString: function (str) {
        return !!(str && typeof str === 'string' && str.length > 0);
    },

    isScandinavianLocale: function (locale) {
        return this.isNonEmptyString(locale) && this.scandinavianLocalePattern.test(locale.toLowerCase());
    },

    isAcceptedDatePattern: function (dateString) {
        return this.acceptedDatePattern.test(dateString);
    },

    isValidDate: function (dateString) {
        if (this.isAcceptedDatePattern(dateString)) {
            var isValid = this.convertStringToMoment(dateString).isValid();
            return isValid;
        }

        return false;
    },

    isSameDate: function (date1, date2) {
        return moment(date1).isSame(moment(date2), 'day'); // if selectedDate is undefined, the today date will be returned
    },

    isToday: function (date) {
        return moment(date).isSame(new Date(), 'day');
    },

    isWeekend: function (date) {
        return date.isoWeekday() === 6 || date.isoWeekday() === 7;
    },

    isPastDate: function (date) {
        return moment(date).isBefore(new Date(), 'day');
    },


    // DISABLED DATES VALIDATIONS
    isDisabledDate: function (dateParam) {
        if (!moment.isMoment(dateParam) && !this.isValidDate(dateParam)) {
            throw new Error('Not a valid date: ' + dateParam);
        }

        var momentDate = moment.isMoment(dateParam) ? dateParam : this.convertStringToMoment(dateParam);
        return this.disabledDates.length > 0 ? this.disabledDates.indexOf(momentDate.format('YYYY-MM-DD')) !== -1 : false;
    },

    // RANGE VALIDATIONS
    isBeforeMaxDate: function (dateParam) {

        if(this.maxDateRange !== undefined) {
            if (!moment.isMoment(dateParam) && !this.isValidDate(dateParam)) {
                throw new Error('Not a valid date: ' + dateParam);
            }

            var momentDate = moment.isMoment(dateParam) ? dateParam : this.convertStringToMoment(dateParam);
            return momentDate.isSame(this.maxDate) || momentDate.isBefore(this.maxDate);
        }

        return true;
    },

    isAfterMinDate: function (dateParam) {

        if(this.minDateRange !== undefined){
            if (!moment.isMoment(dateParam) && !this.isValidDate(dateParam)) {
                throw new Error('Not a valid date: ' + dateParam);
            }

            var momentDate = moment.isMoment(dateParam) ? dateParam : this.convertStringToMoment(dateParam);
            return momentDate.isSame(this.minDate) || momentDate.isAfter(this.minDate);
        }

        return true;
    },

    isWithinAvailableRange: function (dateParam) {
        return this.isAfterMinDate(dateParam) && this.isBeforeMaxDate(dateParam);
    }

};

function NdDateValidatorFactory() {
    var createDateValidator = function (maxDateRange, minDateRange, dateFormat) {
        return new NdDateValidator(maxDateRange, minDateRange, dateFormat);
    };
    return {
        createDateValidator: createDateValidator
    };
}
