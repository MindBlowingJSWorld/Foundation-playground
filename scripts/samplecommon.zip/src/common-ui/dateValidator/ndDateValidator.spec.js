describe('ndDateValidator', function () {
    beforeEach(module('dbw-common'));
    var ndDateValidatorFactory, ndDateValidator,today = new Date(), maxDateRange = 3, minDateRange = 0;

    beforeEach(inject(function (_ndDateValidatorFactory_) {
        ndDateValidatorFactory = _ndDateValidatorFactory_;
        ndDateValidator =  ndDateValidatorFactory.createDateValidator(maxDateRange,minDateRange);
    }));


    it('should exist', function () {
        expect(ndDateValidator).toBeDefined();
    });

    // BASIC VALIDATIONS
    describe('basic validations', function () {

        it('should validate a non empty string', function () {
            expect(ndDateValidator.isNonEmptyString('')).toBe(false);
            expect(ndDateValidator.isNonEmptyString(null)).toBe(false);
            expect(ndDateValidator.isNonEmptyString(undefined)).toBe(false);
            expect(ndDateValidator.isNonEmptyString('.')).toBe(true);
        });

        it('should validate acceptedPattern', function () {
            expect(ndDateValidator.isAcceptedDatePattern('2020-20-1')).toBe(true);
            expect(ndDateValidator.isAcceptedDatePattern('2020201')).toBe(true);
            expect(ndDateValidator.isAcceptedDatePattern('myemail@gmail.com')).toBe(false);
        });

        it('should validate scandanavian locale pattern', function () {
            expect(ndDateValidator.isScandinavianLocale('sv-SE')).toBe(true);
            expect(ndDateValidator.isScandinavianLocale(null)).toBe(false);
            expect(ndDateValidator.isScandinavianLocale('en-US')).toBe(false);
        });

        it('should validate same date', function () {
            expect(ndDateValidator.isSameDate(today, moment(today).add(-1,'day'))).toBeFalsy();
            expect(ndDateValidator.isSameDate(today, moment())).toBeTruthy();
        });

        it('should validate today', function () {
            expect(ndDateValidator.isToday(today)).toBeTruthy();
            expect(ndDateValidator.isToday(moment(today).add(-1,'day'))).toBeFalsy();
        });

        it('should validate past date', function () {
            expect(ndDateValidator.isPastDate(today)).toBeFalsy();
            expect(ndDateValidator.isPastDate(moment(today).add(-1,'day'))).toBeTruthy();
        });

        it('should validate valid date', function () {
            expect(ndDateValidator.isValidDate('2020-20-1')).toBeFalsy();
            expect(ndDateValidator.isValidDate('2020-01-20')).toBeTruthy();
            expect(ndDateValidator.isValidDate('a word')).toBeFalsy();
        });

        // DISABLED DATES VALIDATIONS
        it('should validate disabled dates', function () {
            ndDateValidator.addDisabledDates(['2016-03-22','2016-03-23']);
            expect(ndDateValidator.isDisabledDate('2016-03-22')).toBeTruthy();
            expect(ndDateValidator.isDisabledDate('2016-03-24')).toBeFalsy();
        });

    });

    // RANGE VALIDATIONS
    describe('range validation', function () {

        it('should validate date before max date', function () {
            expect(ndDateValidator.isBeforeMaxDate(moment(today).add(maxDateRange+1,'month'))).toBeFalsy();
            expect(ndDateValidator.isBeforeMaxDate(moment(today).add(maxDateRange-1,'month'))).toBeTruthy();
        });

        it('should validate date after min date', function () {
            // if minDateRange = 0, as long as the day is AFTER yesterday, the test will pass
            expect(ndDateValidator.isAfterMinDate(moment(today).add(-1,'day'))).toBeFalsy();
            expect(ndDateValidator.isAfterMinDate(moment(today))).toBeTruthy();
            expect(ndDateValidator.isAfterMinDate(moment(today).add(1,'day'))).toBeTruthy();

            ndDateValidator.setMinDateRange(1); // set min date 1 month ago
            expect(ndDateValidator.isAfterMinDate(moment(today).add(-1,'day'))).toBeTruthy();
            expect(ndDateValidator.isAfterMinDate(moment(today).add(1,'day'))).toBeTruthy();
            expect(ndDateValidator.isAfterMinDate(moment(today).add(-2,'month'))).toBeFalsy();
        });

        it('should validate date within available range', function () {
            expect(ndDateValidator.isWithinAvailableRange(moment(today).add(-1,'day'))).toBeFalsy();
            expect(ndDateValidator.isWithinAvailableRange(moment(today).add(1,'day'))).toBeTruthy();

            ndDateValidator.setMinDateRange(1);  // set min date 1 month ago
            expect(ndDateValidator.isAfterMinDate(moment(today).add(-1,'day'))).toBeTruthy();
            expect(ndDateValidator.isAfterMinDate(moment(today).add(1,'day'))).toBeTruthy();
            expect(ndDateValidator.isAfterMinDate(moment(today).add(-2,'month'))).toBeFalsy();
        });

        it('should validate date within available range after set a max date', function () {
            ndDateValidator.setMaxDateRange(moment(today).add(2,'day'));
            expect(ndDateValidator.isWithinAvailableRange(moment(today).add(1,'day'))).toBeTruthy();
            expect(ndDateValidator.isWithinAvailableRange(moment(today).add(2,'day'))).toBeTruthy();  // It is inclusive
            expect(ndDateValidator.isWithinAvailableRange(moment(today).add(3,'day'))).toBeFalsy();

            ndDateValidator.setMaxDateRange(moment(today).add(2,'month'));
            expect(ndDateValidator.isWithinAvailableRange(moment(today).add(1,'month'))).toBeTruthy();
            expect(ndDateValidator.isWithinAvailableRange(moment(today).add(2,'month'))).toBeTruthy();
            expect(ndDateValidator.isWithinAvailableRange(moment(today).add(3,'month'))).toBeFalsy();
        });

        it('should validate date within available range after set a min date', function () {
            // Pass in a date object / moment date object
            ndDateValidator.setMinDateRange(moment(today).subtract(2,'day'));
            expect(ndDateValidator.isWithinAvailableRange(moment(today).subtract(1,'day'))).toBeTruthy();
            expect(ndDateValidator.isWithinAvailableRange(moment(today).subtract(2,'day'))).toBeTruthy(); // It is exclusive
            expect(ndDateValidator.isWithinAvailableRange(moment(today).subtract(3,'day'))).toBeFalsy();

            ndDateValidator.setMinDateRange(moment(today).subtract(2,'month'));
            expect(ndDateValidator.isWithinAvailableRange(moment(today).subtract(1,'month'))).toBeTruthy();
            expect(ndDateValidator.isWithinAvailableRange(moment(today).subtract(2,'month'))).toBeTruthy();
            expect(ndDateValidator.isWithinAvailableRange(moment(today).subtract(3,'month'))).toBeFalsy();

            // Pass in a date string
            ndDateValidator.setMinDateRange('2015-12-31');
            expect(ndDateValidator.isWithinAvailableRange(moment(today))).toBeTruthy();

            ndDateValidator.setMinDateRange('2999-12-31'); // unless this test is run in year 3000, we are good
            expect(ndDateValidator.isWithinAvailableRange(moment(today))).toBeFalsy();
        });

    });


});