'use strict';

function injectSvgDefsRightAfterBody($templateCache) {
    $('body').prepend($templateCache.get('icon-pack.svg'));
}

angular.module('dbw-common', [
        'dbw-common.tpl',
        'ui.router',
        'ngResource',
        'zfaModal',
        'foundation.common',
        'foundation.core',
        'foundation.modal',
        'material.core',
        'material.components.backdrop',
        'material.components.input',
        'material.components.select',
        'material.components.menu'
    ])
    .run(injectSvgDefsRightAfterBody);
