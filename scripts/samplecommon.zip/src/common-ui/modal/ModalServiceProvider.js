angular.module('dbw-common')
    .provider('ModalService', function (zfaModalProvider) {

        return {
            register: function (modalName, modalConfig) {
                zfaModalProvider.register(modalName, modalConfig);
            },
            $get: function (zfaModal) {
                return {
                    open: function (modalName, modalConfig) {
                        return zfaModal.open(modalName,modalConfig);
                    }
                };
            }
        };
    });