'use strict';

/** Internal service to extract all business logic from the moneybar directive */
angular.module('dbw-common')
  .provider('MoneybarService', moneybarServiceProvider);


function moneybarServiceProvider() {
  var config = {
    types: {
      'cards-credit': {
        maincontent: 'next invoice is due',
        subcontentRight: 'free to spend',
        subcontentLeft: 'spent',
        hasDueDate: true
      },
      'cards-debit': {
        subcontentRight: 'available'
      },
      'cards-combined': {
        maincontent: 'next invoice is due',
        subcontentRight: 'free to spend',
        subcontentLeft: 'spent',
        hasDueDate: true
      },
      'accounts': {
        maincontent: 'available funds',
        subcontentRight: 'free to spend',
        subcontentLeft: 'upcoming payments'
      },
      'savings': {
        maincontent: 'total value',
        subcontentRight: 'invested',
        subcontentLeft: 'cash'
      },
      'loans': {
        maincontent: 'next payment is due',
        subcontentRight: 'outstanding',
        subcontentLeft: 'repaid',
        hasDueDate: true
      }
    }
  };

  this.configureTypes = configureTypes;
  this.$get = MoneybarService;


  function configureTypes(customConfig) {
    _.assignWith(config.types, customConfig, function (objValue, srcValue) {
      if (_.isUndefined(objValue)) {
        return srcValue;
      } else {
        return _.assign(objValue, srcValue);
      }
    });
  }


  function MoneybarService() {

    return {
      calculateRatio: calculateRatio,
      titlesByType: titlesByType,
      calculateDueDays: calculateDueDays,
      configByType: configByType,
      processDueDate: processDueDate
    };


    function convertToInteger(value) {
      if (_.isFinite(value)) {
        return value;
      }
      var numberStr = _.toString(value);
      if (_.isEmpty(numberStr)) {
        return 0;
      }
      // Remove spaces and currencies
      // @todo: this will not work if the comma AND dot is used in the same number - 4.000,00 -> 4
      numberStr = numberStr.replace(/[^0-9.,]+/g, '');
      var retVal = parseInt(numberStr);
      if (!_.isFinite(retVal)) {
        retVal = 0;
      }
      return retVal;
    }

    function calculateRatio(left, right) {
      var firstPart = left ? convertToInteger(left) : 0;
      var secondPart = right ? convertToInteger(right) : 0;
      if (firstPart === 0) {
        // Nothing to make the ratio out of
        return 0;
      }
      return Math.round(firstPart / (firstPart + secondPart) * 100);
    }

    function titlesByType(type) {
      //@todo: localization integration
      return configByType(type);
    }

    function configByType(type) {
      var typeConfig = _.get(config, ['types', type]);
      if (!typeConfig) {
        return {};
      }
      return _.cloneDeep(typeConfig);
    }

    function calculateDueDays(aDate) {
      //@todo: use localization tools to get the " in xx days" -text
      var theDate = moment(aDate);
      if (!theDate.isValid()) {
        return '';
      }
      if (theDate.isSame(moment(), 'day')) {
        return ' today';
      }
      if (theDate.isSame(moment().add(1, 'days'), 'day')) {
        return ' tomorrow';
      }
      if (theDate.isSame(moment().subtract(1, 'days'), 'day')) {
        return ' yesterday';
      }
      return ' ' + theDate.fromNow();
    }

    function processDueDate($scope) {
      var scopeChanges = {};
      if (configByType($scope.type).hasDueDate) {
        // The main content is dependent on the availability of a "due date"
        if ($scope.dueDate) {
          scopeChanges.dueInDays = calculateDueDays($scope.dueDate);
        } else {
          // the due date was not available, so remove the maincontent-title if the maincontent was not present
          if (!$scope.maincontent) {
            // There was no mainContent so set the content
            _.set(scopeChanges, 'titles.maincontent', '');
            scopeChanges.dueInDays = '';
          } else {
            // no due date, but the sum that is due was still set.
            // For now, assume that the due date is not found and set a nice text
            scopeChanges.dueInDays = ' soon';
          }

        }
      }
      return scopeChanges;
    }
  }
}