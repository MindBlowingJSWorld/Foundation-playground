'use strict';

describe('MoneybarServiceProvider', function () {
  var MoneybarServiceProvider;
  var MoneybarService;

  describe('calculateRatio', function () {

    beforeEach(module('dbw-common'));

    beforeEach(inject(function (_MoneybarService_) {
      MoneybarService = _MoneybarService_;
    }));

    it('should work with numbers', function () {
      expect(MoneybarService.calculateRatio(4, 4)).toBe(50);
      expect(MoneybarService.calculateRatio(4000, 4000)).toBe(50);
      expect(MoneybarService.calculateRatio(4000.10, 4000.10)).toBe(50);
      expect(MoneybarService.calculateRatio(0, 4000)).toBe(0);
      expect(MoneybarService.calculateRatio(4000, 0)).toBe(100);
    });

    it('should work with number strings', function () {
      expect(MoneybarService.calculateRatio('4', '4')).toBe(50);
      expect(MoneybarService.calculateRatio('4 000', '4 000')).toBe(50);
      expect(MoneybarService.calculateRatio('4 000,10', '4 000,10')).toBe(50);
      expect(MoneybarService.calculateRatio('4 000.10', '4 000.10')).toBe(50);
      expect(MoneybarService.calculateRatio('4000.10', '4000.10')).toBe(50);
    });

    it('should work with currencies', function () {
      expect(MoneybarService.calculateRatio('4 SEK', '4 SEK')).toBe(50);
      expect(MoneybarService.calculateRatio('4 000 €', '4 000 €')).toBe(50);
      expect(MoneybarService.calculateRatio('$ 4 000,10', '$ 4 000,10')).toBe(50);
    });

    it('should work with empty strings', function () {
      expect(MoneybarService.calculateRatio('', '')).toBe(0);
      expect(MoneybarService.calculateRatio('4 000', '')).toBe(100);
      expect(MoneybarService.calculateRatio('', '4000')).toBe(0);
    });

    it('should work with bad values', function () {
      expect(MoneybarService.calculateRatio('A', 'A')).toBe(0);
      expect(MoneybarService.calculateRatio('A', '')).toBe(0);
      expect(MoneybarService.calculateRatio('', 'A')).toBe(0);
    });

  });

  describe('getTitles and configByType', function () {
    var customConfig = {
      'cards-credit': {
        subcontentRight: 'free to spend' // The rest are as per default 
      },
      'cards-a': {
        maincontent: 'limit',
        subcontentRight: 'free to spend',
        subcontentLeft: 'upcoming payments',
        hasDueDate: true
      },
      'cards-b': {
        maincontent: 'due in next invoice',
        subcontentRight: 'available',
        subcontentLeft: 'spent'
      }
    };

    beforeEach(module('dbw-common', function (_MoneybarServiceProvider_) {
      MoneybarServiceProvider = _MoneybarServiceProvider_;
      MoneybarServiceProvider.configureTypes(customConfig);
    }));

    beforeEach(inject(function () {
      MoneybarService = MoneybarServiceProvider.$get();
    }));

    it('should allow overriding config for a predefined type without changing all of its defaults', function () {
      expect(MoneybarService.titlesByType('cards-credit').subcontentRight).toEqual(customConfig['cards-credit'].subcontentRight);
      expect(MoneybarService.titlesByType('cards-credit').subcontentLeft).toEqual('spent'); // default!
    });

    it('should have configs for predefined types', function () {
      expect(MoneybarService.configByType('cards-credit')).toBeDefined();
      expect(MoneybarService.configByType('cards-debit')).toBeDefined();
      expect(MoneybarService.configByType('cards-combined')).toBeDefined();
      expect(MoneybarService.configByType('accounts')).toBeDefined();
      expect(MoneybarService.configByType('savings')).toBeDefined();
      expect(MoneybarService.configByType('loans')).toBeDefined();
    });

    it('titlesByType should return title for new custom type', function () {
      expect(MoneybarService.titlesByType('cards-a')).toEqual(customConfig['cards-a']);
    });

    it('configByType should return config for new custom type', function () {
      expect(MoneybarService.configByType('cards-a')).toEqual(customConfig['cards-a']);
    });

    it('configByType should return an empty object the type does not exist', function () {
      var typeCfg = MoneybarService.configByType('BAD-TYPE');
      expect(typeCfg).not.toBe(null);
      expect(typeCfg).not.toBe(undefined);
      expect(_.size(typeCfg)).toBe(0);
    });

  });

  describe('processDueDate', function () {
    var config = {
      'cards-a': {
        maincontent: 'limit',
        subcontentRight: 'free to spend',
        subcontentLeft: 'upcoming payments',
        hasDueDate: true
      },
      'cards-b': {
        maincontent: 'due in next invoice',
        subcontentRight: 'available',
        subcontentLeft: 'spent'
      }
    };

    beforeEach(module('dbw-common', function (_MoneybarServiceProvider_) {
      MoneybarServiceProvider = _MoneybarServiceProvider_;
      MoneybarServiceProvider.configureTypes(config);
    }));

    beforeEach(inject(function () {
      MoneybarService = MoneybarServiceProvider.$get();
    }));

    it('should work', function () {
      var afterTwoDays = moment().add(2, 'days');
      var changes = MoneybarService.processDueDate({type: 'cards-a', maincontent: '1000', dueDate: afterTwoDays});
      expect(changes.dueInDays).toBe(' in 2 days');
      expect(_.size(changes)).toBe(1);
    });

    it('should work for today', function () {
      var changes = MoneybarService.processDueDate({type: 'cards-a', maincontent: '1000', dueDate: new Date()});
      expect(changes.dueInDays).toBe(' today');
      expect(_.size(changes)).toBe(1);
    });

    it('should work for tomorrow', function () {
      var afterOneDay = moment().add(1, 'days');
      var changes = MoneybarService.processDueDate({type: 'cards-a', maincontent: '1000', dueDate: afterOneDay});
      expect(changes.dueInDays).toBe(' tomorrow');
      expect(_.size(changes)).toBe(1);
    });

    it('should work for yesterday', function () {
      var afterTwoDays = moment().subtract(1, 'days');
      var changes = MoneybarService.processDueDate({type: 'cards-a', maincontent: '1000', dueDate: afterTwoDays});
      expect(changes.dueInDays).toBe(' yesterday');
      expect(_.size(changes)).toBe(1);
    });

    it('should work for the past', function () {
      var afterTwoDays = moment().subtract(2, 'days');
      var changes = MoneybarService.processDueDate({type: 'cards-a', maincontent: '1000', dueDate: afterTwoDays});
      expect(changes.dueInDays).toBe(' 2 days ago');
      expect(_.size(changes)).toBe(1);
    });

    it('should return empty object if the type does not have hasDueDate', function () {
      var changes = MoneybarService.processDueDate({type: 'cards-b'});
      expect(changes).not.toBe(undefined);
      expect(_.size(changes)).toBe(0);
    });

    it('should set the title.maincontent to "" if the hasDueDate is true but the data is not specified', function () {
      var changes = MoneybarService.processDueDate({type: 'cards-a'});
      expect(changes.dueInDays).toBe('');
      expect(changes.titles.maincontent).toBe('');
    });

    it('should work with a bad type', function () {
      var changes = MoneybarService.processDueDate({type: 'BAD-TYPE'});
      expect(changes).not.toBe(undefined);
      expect(_.size(changes)).toBe(0);
    });

  });
});
