'use strict';

angular.module('dbw-common')
    .directive('ndMoneybarCollection', ndMoneybarCollection)
    .controller('MoneybarCollectionDirectiveController', MoneybarCollectionDirectiveController)
;


function ndMoneybarCollection() {
    return {
        restrict: 'E',
        replace: false,
        transclude : true,
        scope: {
            closeOthers: '='
        },
        template: '<div ng-transclude></div>',
        controller: 'MoneybarCollectionDirectiveController',
        controllerAS: 'vm'
    };
}

function MoneybarCollectionDirectiveController($scope) {
    var vm = this;
    var registeredControllers;

    vm.init = init;
    vm.registerController = registerController;
    vm.deregisterController = deregisterController;
    vm.notifyCollapsedState = notifyCollapsedState;

    init();

    function init() {
        registeredControllers = [];
    }

    function registerController(controller) {
        var index = _.findIndex(registeredControllers, function(c) {
            return c === controller;
        });
        if (index === -1) {
            registeredControllers.push(controller);
        }
    }

    function deregisterController(controller) {
        _.remove(registeredControllers, function(c) {
            return c === controller;
        });
    }

    function notifyCollapsedState(data) {
        var closeOthers = $scope.closeOthers !== undefined ? $scope.closeOthers : true;
        if (closeOthers) {
            _.each(registeredControllers, function (c) {
                if (c !== data.controller && !data.collapsed) {
                    c.setCollapsed(true, {notify: false});
                }
            });
        }
    }
}