'use strict';

describe('Moneybar Collection', function() {

    var $compile, $rootScope, $scope;

    beforeEach(module('dbw-common'));

    beforeEach(inject(function (_$compile_, _$rootScope_) {
        $compile = _$compile_;
        $rootScope = _$rootScope_;
        $scope = $rootScope.$new();
    }));

    function compile(directiveTpl) {
        var element = $compile(directiveTpl)($scope);
        $scope.$digest();
        return element;
    }

    function clickOnMoneybar(moneybar) {
        moneybar.find('.moneybar').trigger('click');
    }

    function isContainerCollapsed(moneybarContainerEl) {
        var scope = angular.element(moneybarContainerEl.children('div')).scope();
        var containerCollapsed = scope.vm.collapsed;
        var moneybarCollapsed = isMoneybarCollapsed(moneybarContainerEl.find('nd-moneybar'));
        return containerCollapsed && moneybarCollapsed;
    }

    function isMoneybarCollapsed(moneybarEl) {
        var scope = angular.element(moneybarEl.children('div')).scope();
        return scope.ctrl.collapsed;
    }

    describe('close-others', function () {

        it('by default it should collapse other moneybar containers when one is expanded', function () {
            var moneybarCollection = compile(
                [
                    '<nd-moneybar-collection>',
                        '<nd-moneybar-container id="container-1">',
                            '<nd-moneybar id="moneybar-1" collapsed="false"></nd-moneybar>',
                        '</nd-moneybar-container>',
                        '<nd-moneybar-container id="container-2">',
                            '<nd-moneybar id="moneybar-2" collapsed="true"></nd-moneybar>',
                        '</nd-moneybar-container>',
                        '<nd-moneybar-container id="container-3">',
                            '<nd-moneybar id="moneybar-3" collapsed="true"></nd-moneybar>',
                        '</nd-moneybar-container>',
                    '<nd-moneybar-collection>'
                ].join(' ')
            );

            expect(isContainerCollapsed(moneybarCollection.find('#container-1'))).toBe(false);
            expect(isContainerCollapsed(moneybarCollection.find('#container-2'))).toBe(true);
            expect(isContainerCollapsed(moneybarCollection.find('#container-3'))).toBe(true);

            clickOnMoneybar(moneybarCollection.find('#moneybar-1'));

            expect(isContainerCollapsed(moneybarCollection.find('#container-1'))).toBe(true);
            expect(isContainerCollapsed(moneybarCollection.find('#container-2'))).toBe(true);
            expect(isContainerCollapsed(moneybarCollection.find('#container-3'))).toBe(true);


            clickOnMoneybar(moneybarCollection.find('#moneybar-2'));

            expect(isContainerCollapsed(moneybarCollection.find('#container-1'))).toBe(true);
            expect(isContainerCollapsed(moneybarCollection.find('#container-2'))).toBe(false);
            expect(isContainerCollapsed(moneybarCollection.find('#container-3'))).toBe(true);

            clickOnMoneybar(moneybarCollection.find('#moneybar-3'));

            expect(isContainerCollapsed(moneybarCollection.find('#container-1'))).toBe(true);
            expect(isContainerCollapsed(moneybarCollection.find('#container-2'))).toBe(true);
            expect(isContainerCollapsed(moneybarCollection.find('#container-3'))).toBe(false);

        });

        it('should not collapse other moneybar containers when one is clicked and close-others="false"', function() {
            var moneybarCollection = compile(
                [
                    '<nd-moneybar-collection close-others="false">',
                        '<nd-moneybar-container id="container-1">',
                            '<nd-moneybar id="moneybar-1" collapsed="false"></nd-moneybar>',
                        '</nd-moneybar-container>',
                        '<nd-moneybar-container id="container-2">',
                            '<nd-moneybar id="moneybar-2" collapsed="true"></nd-moneybar>',
                        '</nd-moneybar-container>',
                        '<nd-moneybar-container id="container-3">',
                            '<nd-moneybar id="moneybar-3" collapsed="true"></nd-moneybar>',
                        '</nd-moneybar-container>',
                    '<nd-moneybar-collection>'
                ].join(' ')
            );

            clickOnMoneybar(moneybarCollection.find('#moneybar-2'));

            expect(isContainerCollapsed(moneybarCollection.find('#container-1'))).toBe(false);
            expect(isContainerCollapsed(moneybarCollection.find('#container-2'))).toBe(false);
            expect(isContainerCollapsed(moneybarCollection.find('#container-3'))).toBe(true);
        });

        it('should collapse other moneybars when one is expanded and close-others="true"', function () {
            var moneybarCollection = compile(
                [
                    '<nd-moneybar-collection close-others="true">',
                        '<nd-moneybar id="moneybar-1" collapsed="false"></nd-moneybar>',
                        '<nd-moneybar id="moneybar-2" collapsed="true"></nd-moneybar>',
                        '<nd-moneybar id="moneybar-3" collapsed="true"></nd-moneybar>',
                    '<nd-moneybar-collection>'
                ].join(' ')
            );

            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-1'))).toBe(false);
            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-2'))).toBe(true);
            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-3'))).toBe(true);

            clickOnMoneybar(moneybarCollection.find('#moneybar-1'));

            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-1'))).toBe(true);
            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-2'))).toBe(true);
            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-3'))).toBe(true);

            clickOnMoneybar(moneybarCollection.find('#moneybar-2'));

            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-1'))).toBe(true);
            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-2'))).toBe(false);
            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-3'))).toBe(true);

            clickOnMoneybar(moneybarCollection.find('#moneybar-3'));

            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-1'))).toBe(true);
            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-2'))).toBe(true);
            expect(isMoneybarCollapsed(moneybarCollection.find('#moneybar-3'))).toBe(false);
        });
    });

    describe('MoneybarCollectionDirectiveController', function() {

        var collectionCtrl;

        beforeEach(inject(function($controller) {
            collectionCtrl = $controller('MoneybarCollectionDirectiveController', {
                $scope: $scope
            });
        }));

        describe('notifyCollapsedState()', function() {

            var registeredCtrl;

            beforeEach(function() {
                $scope.closeOthers = true;

                registeredCtrl = jasmine.createSpyObj('ctrl', ['setCollapsed']);
                collectionCtrl.registerController(registeredCtrl);
            });

            it('should signal other registered controllers to collapse when one is expanded and closeOthers is true', function() {
                collectionCtrl.notifyCollapsedState({
                    collapsed: false,
                    controller: {}
                });
                expect(registeredCtrl.setCollapsed).toHaveBeenCalledWith(true, {notify: false}); // {notify: false} to tell the controller not to notify again
            });

            it('should not signal other registered controllers to collapse when one is collapsed', function() {
                collectionCtrl.notifyCollapsedState({
                    collapsed: true,
                    controller: {}
                });
                expect(registeredCtrl.setCollapsed).not.toHaveBeenCalled();
            });

            it('should not signal expanded controller to collapse itself', function() {
                collectionCtrl.notifyCollapsedState({
                    collapsed: false,
                    controller: registeredCtrl
                });
                expect(registeredCtrl.setCollapsed).not.toHaveBeenCalled();
            });

            it('should not signal controller to collapse itself after it has been deregistered', function() {
                collectionCtrl.deregisterController(registeredCtrl);

                collectionCtrl.notifyCollapsedState({
                    collapsed: false,
                    controller: {}
                });
                expect(registeredCtrl.setCollapsed).not.toHaveBeenCalled();
            });

        });



    });

});

