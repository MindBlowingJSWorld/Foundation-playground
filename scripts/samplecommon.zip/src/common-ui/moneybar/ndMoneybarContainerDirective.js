'use strict';

angular.module('dbw-common')
    .directive('ndMoneybarContainer', MoneybarContainerDirective)
    .controller('MoneybarContainerDirectiveController', MoneybarContainerDirectiveController);


function MoneybarContainerDirective() {
    return {
        restrict: 'E',
        replace: false,
        transclude: {
            moneybar: 'ndMoneybar',
            leftContent: '?ndMoneybarContainerLeftContent',
            rightContent: '?ndMoneybarContainerRightContent',
            details: '?ndMoneybarContainerDetails'
        },
        scope: true,  // Create new scope, but inherit scope from the parent
        controllerAs: 'vm',
        controller: 'MoneybarContainerDirectiveController',
        templateUrl: 'moneybar/ndMoneybarContainerDirective.tpl.html'
    };
}

function MoneybarContainerDirectiveController($transclude) {
    var vm = this;

    vm.init = init;
    vm.setCollapsed = setCollapsed;

    init();

    ////////////////////////

    function init() {
        vm.hasTransclusion = {
            details: $transclude.isSlotFilled('details'),
            leftContent: $transclude.isSlotFilled('leftContent'),
            rightContent: $transclude.isSlotFilled('rightContent'),
            moneybar: $transclude.isSlotFilled('moneybar')
        };
    }

    /**
     * Function defined on the controller so that the moneybar-directive can communicate
     * whether or not it is collapsed
     * @param isCollapsed
     */
    function setCollapsed(isCollapsed) {
        vm.collapsed = isCollapsed;
    }
}