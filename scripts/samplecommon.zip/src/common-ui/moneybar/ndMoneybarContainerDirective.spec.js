'use strict';

describe('nd-moneybar-container', function () {
    var $compile, $rootScope, $scope;
    var moneybarContainer;
    var vm; // Controller using moneybar container

    beforeEach(function() {
        module('dbw-common');
    });

    beforeEach(inject(function (_$compile_, _$rootScope_) {
        $compile = _$compile_;
        $rootScope = _$rootScope_;

        vm = {
            controllerFunction: jasmine.createSpy('controllerFunction')
        };
    }));

    function compileDirective(directiveTpl) {
        inject(function ($compile) {
            moneybarContainer = $compile(directiveTpl)($scope); // manually compile the template and inject the scope
            $scope.$digest(); // manually update all of the bindings
        });
    }

    function setupScope() {
        $scope = $rootScope.$new();
        $scope.vm = vm;
    }

    describe('transclusion', function () {
        beforeEach(function () {
            setupScope();

            compileDirective(
              '<nd-moneybar-container>' +
                  '<nd-moneybar collapsed="false" title="title" subtitle="subtitle" type="type"' +
                    'maincontent="maincontent" subcontent-left="subcontentLeft" subcontent-right="subcontentRight">' +
                    '<nd-moneybar-expanded-content>' +
                        '<div class="moneybar__buttons divider">' +
                            '<button type="button" class="button colors-negative" ng-click="vm.controllerFunction()">Button 1</button>' +
                        '</div>' +
                    '</nd-moneybar-expanded-content>' +
                  '</nd-moneybar>' +
              '</nd-moneybar-container>');
        });

        it('should transclude buttons inside money bar with the correct scope', function () {
            var button = moneybarContainer.find('button[ng-click]');
            button.trigger('click');
            expect(vm.controllerFunction).toHaveBeenCalled();
        });
    });

});
