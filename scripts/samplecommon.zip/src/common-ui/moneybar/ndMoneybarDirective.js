'use strict';

angular.module('dbw-common')
    .directive('ndMoneybar', moneybarDirective)
    .controller('MoneybarDirectiveController', MoneybarDirectiveController);


function moneybarDirective() {
    return {
        restrict: 'E',
        replace: false,
        require: {
            containerCtrl: '?^ndMoneybarContainer',
            collectionCtrl: '?^ndMoneybarCollection'
        },
        transclude: {
            collapsedContent: '?ndMoneybarCollapsedContent',
            expandedContent: '?ndMoneybarExpandedContent',
            staticContent: '?ndMoneybarStaticContent'
        },
        scope: {
            title: '=',
            subtitle: '=',
            maincontent: '=',
            maincontentTitle: '=',
            subcontentRight: '=',
            subcontentTopRight: '=',
            subcontentLeft: '=',
            collapsed: '=?',
            type: '=',
            cardStatus: '=',
            dueDate: '=',
            attachedInfo: '=',
            collapseMode: '=',
            imageUrl: '='
        },
        templateUrl: 'moneybar/ndMoneybarDirective.tpl.html',
        bindToController: true,
        controllerAs: 'ctrl',
        controller: 'MoneybarDirectiveController',
        link: link
    };

    function link(scope, el, attrs, requiredControllers) {
        // Store references to required controllers so that we can communicate with them in MoneybarContainerDirectiveController
        _.extend(scope, requiredControllers);

        if (scope.ctrl.collapsed === undefined) {
            scope.ctrl.collapsed = true;
        }
        scope.ctrl.init();
    }
}


function MoneybarDirectiveController(MoneybarService, $scope, $transclude) {

    var ctrl = this;

    ctrl.init = init;
    ctrl.toggleCollapsed = toggleCollapsed;
    ctrl.setCollapsed = setCollapsed;

    //////////////////////////////////////

    function calculateFillDegree() {
        var fillPercentage = MoneybarService.calculateRatio(ctrl.subcontentLeft, ctrl.subcontentRight);
        ctrl.fillDegree = {'width': fillPercentage + '%'};
    }

    function init() {
        ctrl.hasTransclusion = {
            collapsedContent: $transclude.isSlotFilled('collapsedContent'),
            expandedContent: $transclude.isSlotFilled('expandedContent'),
            staticContent: $transclude.isSlotFilled('staticContent')
        };

        if ($scope.collectionCtrl) {
            $scope.collectionCtrl.registerController(ctrl);
            $scope.$on('$destroy', function() {
                $scope.collectionCtrl.deregisterController(ctrl);
            });
        }

        setCollapsed(ctrl.collapsed);

        ctrl.titles = MoneybarService.titlesByType(ctrl.type);
        calculateFillDegree();
        var scopeChanges = MoneybarService.processDueDate(ctrl);
        if (scopeChanges) {
            _.merge(ctrl, scopeChanges);
        }

        // watch the input that influences the fill-degree
        $scope.$watch(function () {
            return ctrl.subcontentRight;
        }, function () {
            calculateFillDegree();
        });

        // watch the other input that influences the fill-degree
        $scope.$watch(function () {
            return ctrl.subcontentLeft;
        }, function () {
            calculateFillDegree();
        });

        $scope.$watch(function () {
            return ctrl.collapsed;
        }, function () {
            setCollapsed(ctrl.collapsed); // Notify container and collection
        });
    }

    function toggleCollapsed() {
        ctrl.setCollapsed(!ctrl.collapsed);
    }

    function setCollapsed(isCollapsed, options) {
        options = _.extend({notify: true}, options);
        ctrl.collapsed = isCollapsed;
        if ($scope.collectionCtrl && options.notify) {
            $scope.collectionCtrl.notifyCollapsedState({
                controller: ctrl,
                collapsed: isCollapsed
            });
        }
        if ($scope.containerCtrl) {
            $scope.containerCtrl.setCollapsed(ctrl.collapsed);
        }
    }
}
