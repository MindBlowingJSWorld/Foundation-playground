'use strict';

describe('nd-moneybar', function () {
    var $compile, $transclude;
    var $rootScope, $scope;
    var MoneybarServiceMock;
    var moneybarConfig;

    function setupMockMoneybarService(cfg) {
        MoneybarServiceMock = {};

        MoneybarServiceMock.config = cfg;
        MoneybarServiceMock.configByType = function (type) {
            return MoneybarServiceMock.config[type];
        };
        MoneybarServiceMock.calculateRatio = function () {
            return 0;
        };
        MoneybarServiceMock.titlesByType = function (type) {
            return MoneybarServiceMock.configByType(type);
        };
        MoneybarServiceMock.processDueDate = function () {
            return {dueInDays: ' today'};
        };
    }

    beforeEach(function () {
        moneybarConfig = {
            'test-type': {
                maincontent: 'next invoice is due',
                subcontentRight: 'free to spend',
                subcontentLeft: 'spent'
            }
        };
        setupMockMoneybarService(moneybarConfig);

        module('dbw-common', function ($provide) {
            $provide.value('MoneybarService', MoneybarServiceMock);
        });
    });

    beforeEach(inject(function (_$compile_, _$rootScope_) {
        $compile = _$compile_;
        $rootScope = _$rootScope_;
        $scope = $rootScope.$new();
    }));

    beforeEach(function () {
        setupScope(false);
        $transclude = jasmine.createSpyObj('$transclude', ['isSlotFilled']);
    });

    function compileDirective(directiveTpl) {
        var element = $compile(directiveTpl)($scope); // manually compile the template and inject the scope
        $scope.$digest(); // manually update all of the bindings
        return element;
    }

    function setupScope(hasDueDate) {
        $scope = $rootScope.$new();
        $scope.type = 'test-type';
        $scope.title = 'aTitle';
        $scope.subtitle = 'aSubtitle';
        $scope.maincontent = 'someMainContent';
        $scope.subcontentLeft = 'someLeftSubcontent';
        $scope.subcontentRight = 'someRightSubcontent';
        $scope.collapsed = false;
        if (hasDueDate) {
            $scope.hasDueDate = hasDueDate;
            $scope.dueDate = new Date();
        }
    }

    describe('ndMoneybar directive', function () {

        function compileMoneybar() {
            return compileDirective('<nd-moneybar ' +
                'maincontent="maincontent" ' +
                'maincontent-title="maincontentTitle" ' +
                'subcontent-left="subcontentLeft" ' +
                'subcontent-right="subcontentRight" ' +
                'type="type" ' +
                'collapsed="collapsed">' +
                '</nd-moneybar>');
        }

        it('displays labels and amounts in main and subcontents when inputs are text', function () {
            $scope.maincontent = '1000,50';
            $scope.subcontentLeft = '800,25';
            $scope.subcontentRight = '200,25';
            $scope.collapsed = false;
            var element = compileMoneybar();

            expect(element.find('.moneybar__maincontent .label').text()).toMatch(moneybarConfig['test-type']['maincontent']);
            expect(element.find('.moneybar__maincontent .amount').text()).toEqual('1 000,50');
            expect(element.find('.moneybar__subcontent--left .label').text()).toEqual(moneybarConfig['test-type']['subcontentLeft']);
            expect(element.find('.moneybar__subcontent--left .amount').text()).toEqual('800,25');
            expect(element.find('.moneybar__subcontent--right .label').text()).toEqual(moneybarConfig['test-type']['subcontentRight']);
            expect(element.find('.moneybar__subcontent--right .amount').text()).toEqual('200,25');

            $scope.collapsed = true;
            $scope.$digest();

            expect(element.find('.moneybar__maincontent .label').text()).toMatch(moneybarConfig['test-type']['maincontent']);
            expect(element.find('.moneybar__maincontent .amount').text()).toEqual('1 000,50');
            expect(element.find('.moneybar__subcontent .label').text()).toEqual(moneybarConfig['test-type']['subcontentRight']);
            expect(element.find('.moneybar__subcontent .amount').text()).toEqual('200,25');
        });

        it('displays amounts in main and subcontents when inputs are numbers', function () {
            $scope.maincontent = 1000.50;
            $scope.subcontentLeft = 800.25;
            $scope.subcontentRight = 200.25;
            $scope.collapsed = false;

            var element = compileMoneybar();

            expect(element.find('.moneybar__maincontent .label').text()).toMatch(moneybarConfig['test-type']['maincontent']);
            expect(element.find('.moneybar__maincontent .amount').text()).toEqual('1 000,50');
            expect(element.find('.moneybar__subcontent--left .label').text()).toEqual(moneybarConfig['test-type']['subcontentLeft']);
            expect(element.find('.moneybar__subcontent--left .amount').text()).toEqual('800,25');
            expect(element.find('.moneybar__subcontent--right .label').text()).toEqual(moneybarConfig['test-type']['subcontentRight']);
            expect(element.find('.moneybar__subcontent--right .amount').text()).toEqual('200,25');

            $scope.collapsed = true;
            $scope.$digest();

            expect(element.find('.moneybar__maincontent .label').text()).toMatch(moneybarConfig['test-type']['maincontent']);
            expect(element.find('.moneybar__maincontent .amount').text()).toEqual('1 000,50');
            expect(element.find('.moneybar__subcontent .label').text()).toEqual(moneybarConfig['test-type']['subcontentRight']);
            expect(element.find('.moneybar__subcontent .amount').text()).toEqual('200,25');
        });

        it('does displays amounts in main and subcontents when inputs are all number zero', function () {
            $scope.maincontent = 0;
            $scope.subcontentLeft = 0;
            $scope.subcontentRight = 0;
            $scope.collapsed = false;

            var element = compileMoneybar();
            expect(element.find('.moneybar__maincontent .amount').text()).toEqual('0,00');
            expect(element.find('.moneybar__subcontent--left .amount').text()).toEqual('0,00');
            expect(element.find('.moneybar__subcontent--right .amount').text()).toEqual('0,00');

            $scope.collapsed = true;
            $scope.$digest();

            expect(element.find('.moneybar__maincontent .amount').text()).toEqual('0,00');
            expect(element.find('.moneybar__subcontent .amount').text()).toEqual('0,00');
        });

        it('does not displays amounts nor labels in main and subcontents when inputs are undefined', function () {
            $scope.maincontent = undefined;
            $scope.subcontentLeft = undefined;
            $scope.subcontentRight = undefined;
            $scope.collapsed = false;

            var element = compileMoneybar();
            expect(element.find('.moneybar__maincontent .amount').text()).toEqual('');
            expect(element.find('.moneybar__maincontent .label').text()).toEqual('');
            expect(element.find('.moneybar__subcontent--left .amount').text()).toEqual('');
            expect(element.find('.moneybar__subcontent--left .label').text()).toEqual('');
            expect(element.find('.moneybar__subcontent--right .label').text()).toEqual('');
            expect(element.find('.moneybar__subcontent--right .amount').text()).toEqual('');

            $scope.collapsed = true;
            $scope.$digest();

            expect(element.find('.moneybar__maincontent .label').text()).toEqual('');
            expect(element.find('.moneybar__maincontent .amount').text()).toEqual('');
            expect(element.find('.moneybar__subcontent .label').text()).toEqual('');
            expect(element.find('.moneybar__subcontent .amount').text()).toEqual('');
        });

        it('does not display custom title on main content if undefined', function() {
            $scope.maincontent = undefined;
            $scope.maincontentTitle = undefined;
            $scope.collapsed = false;

            var element = compileMoneybar();
            expect(element.find('.moneybar__maincontent').text().trim()).toEqual('');

            $scope.collapsed = true;
            $scope.$digest();

            expect(element.find('.moneybar__maincontent').text().trim()).toEqual('');
        });

        it('displays custom title on main content if defined', function() {
            $scope.maincontent = undefined;
            $scope.maincontentTitle = 'custom maincontent title';
            $scope.collapsed = false;

            var element = compileMoneybar();
            expect(element.find('.moneybar__maincontent').text().trim()).toEqual('custom maincontent title');

            $scope.collapsed = true;
            $scope.$digest();

            expect(element.find('.moneybar__maincontent').text().trim()).toEqual('custom maincontent title');
        });
    });


    describe('MoneybarDirectiveController', function () {

        var moneybarCtrl, moneybarCtrlScope;
        var containerCtrl;
        var collectionCtrl;

        beforeEach(inject(function ($controller) {
            // Simulate bindToController where controllerAs = 'ctrl'
            moneybarCtrlScope = $rootScope.$new();
            moneybarCtrl = $controller('MoneybarDirectiveController', {
                $scope: moneybarCtrlScope,
                $transclude: $transclude
            });
            moneybarCtrl.ctrl = moneybarCtrl;
            _.extend(moneybarCtrl.ctrl, $scope); // $scope plays no further role. We just use it for initial values.

            containerCtrl = jasmine.createSpyObj('containerCtrl', ['setCollapsed']);
            collectionCtrl = jasmine.createSpyObj('collectionCtrl', ['registerController', 'deregisterController', 'notifyCollapsedState']);

            moneybarCtrl.init();
        }));

        it('should tell container controller to change its collapsed state when own property changes', function () {
            moneybarCtrlScope.containerCtrl = containerCtrl;
            moneybarCtrl.collapsed = true;

            moneybarCtrl.init();
            expect(containerCtrl.setCollapsed).toHaveBeenCalledWith(true);

            moneybarCtrl.collapsed = false;
            moneybarCtrlScope.$digest();
            expect(containerCtrl.setCollapsed).toHaveBeenCalledWith(false);
        });

        it('should register itself with MoneybarCollectionDirectiveController when initialized', function () {
            moneybarCtrlScope.collectionCtrl = collectionCtrl;

            moneybarCtrl.init();

            expect(collectionCtrl.registerController).toHaveBeenCalledWith(moneybarCtrl);
        });

        it('should deregister itself from MoneybarCollectionDirectiveController when scope is destroyed', function () {
            moneybarCtrlScope.collectionCtrl = collectionCtrl;

            moneybarCtrl.init();
            moneybarCtrlScope.$destroy();

            expect(collectionCtrl.deregisterController).toHaveBeenCalledWith(moneybarCtrl);
        });

        it('should notify MoneybarCollectionDirectiveController about collapsed state changes', function () {
            moneybarCtrlScope.collectionCtrl = collectionCtrl;
            moneybarCtrl.init();

            moneybarCtrl.collapsed = false;
            moneybarCtrlScope.$digest();
            expect(collectionCtrl.notifyCollapsedState).toHaveBeenCalledWith({
                controller: moneybarCtrl,
                collapsed: false
            });

            moneybarCtrl.collapsed = true;
            moneybarCtrlScope.$digest();
            expect(collectionCtrl.notifyCollapsedState).toHaveBeenCalledWith({
                controller: moneybarCtrl,
                collapsed: true
            });
        });
    });

});
