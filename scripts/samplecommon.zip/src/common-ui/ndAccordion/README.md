

Example:



<div class="list-one" nd-accordion-list >

  <div ng-repeat="item in ctrl.items">
    <div nd-accordion-list-item-collapsed="item.id" class="row"></div>
    <div nd-accordion-list-item-expanded="item.id" class="row"></div>
  </div>
</div>

<div class="list-two" nd-accordion-list >
    <div ng-repeat="item in ctrl.items">
        <div nd-accordion-list-item-collapsed="item.id" class="row"></div>
        <div nd-accordion-list-item-expanded="item.id" class="row"></div>
    </div>
</div>




item.id is required, so expanded list is not collapsed when events propagates
