/**
 * Directive for handling expandable bars.
 *
 *
 * Supports multiple dependent lists on same page.
 * Scope for lists are shared, so expanding item in one list, will force other lists to collapse
 */
angular.module('dbw-common')
  .directive('ndAccordionList', function () {
    'use strict';
    return {
      restrict: 'A',
      link: function (scope) {
        //when one expands, close others (in all lists)
        scope.$on('nd-accordion-expand', function(event, val) {
          scope.$broadcast('nd-accordion-show', val);
        });
      }
    };
  });

