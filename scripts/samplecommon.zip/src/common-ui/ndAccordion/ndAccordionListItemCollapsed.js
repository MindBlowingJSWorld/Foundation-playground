/**
 * Collapsed item directive
 */
angular.module('dbw-common')
  .directive('ndAccordionListItemCollapsed', function () {
    'use strict';
    return {
      restrict: 'A',
      scope: {
        itemId: '=ndAccordionListItemCollapsed',
        ngShow: '='
      },
      link: function (scope, element) {
        //itemId is used to cancel collapsing event from list
        var itemId = scope.itemId;

        //on click notify parent that it is expanding
        element.bind('click', function(){
          scope.$emit('nd-accordion-expand', itemId);
          element.hide();
        });

        scope.$on('nd-accordion-show', function(event, val) {
          //don't collapse if originated from item with same id (expandedHeader or collapsedHeader)
          if (val !== itemId) {
            element.show();
          }
        });

      }
    };
  });
