'use strict';
describe('ndAmountController', function () {
  var $controller;
  var controller;

  beforeEach(module('dbw-common'));
  beforeEach(inject(function(_$controller_){
    // The injector unwraps the underscores (_) from around the parameter names when matching
    $controller = _$controller_;
    controller = $controller('ndAmountController', {});
  }));

  describe('breakNumberIntoParts', function() {
    it('should work with an integer', function() {
      var testValue = 10;
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('10');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('00');
    });
    it('should work with zero', function() {
      var testValue = 0;
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('0');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('00');
    });
    it('should work with a negative integer', function() {
      var testValue = -10;
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('-10');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('00');
    });
    it('should work with a float', function() {
      var testValue = 10.99;
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('10');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('99');
    });
    it('should work with a negative float', function() {
      var testValue = -10.99;
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('-10');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('99');
    });
    it('should work with float zero', function() {
      var testValue = 0.00;
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('0');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('00');
    });
    it('should work with a formatted string', function() {
      var testValue = '11 000.09';
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('11000');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('09');
    });
    it('should work with a formatted string with negative sign', function() {
      var testValue = '-11 000.09';
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('-11000');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('09');
    });
    it('should work with an empty string', function() {
      var testValue = '';
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('0');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('00');
    });
    it('should work with undefined', function() {
      expect(controller.breakNumberIntoParts().integerPart).toEqual('0');
      expect(controller.breakNumberIntoParts().decimalPart).toEqual('00');
    });
    it('should work with null', function() {
      var testValue = null;
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('0');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('00');
    });
    it('should work with a formatted string with comma', function() {
      var testValue = '11 000,09';
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('11000');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('09');
    });
    it('should work with a formatted string with a lot of decimals', function() {
      var testValue = '11 000.099999999';
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('11000');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('09');
    });
    it('should work with a formatted string with one decimal', function() {
      var testValue = '11 000.9';
      expect(controller.breakNumberIntoParts(testValue).integerPart).toEqual('11000');
      expect(controller.breakNumberIntoParts(testValue).decimalPart).toEqual('90');
    });
    it('should throw if supplied an object', function() {
      var testValue = { aProp : 'aValue'};
      expect(function() { controller.breakNumberIntoParts(testValue); }).toThrow();
    });
  });

  describe('addSpacesToNumberString', function() {
    it('should work with a zero, null and undefined', function() {
      var testValue = '0';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('0');
      testValue = null;
      expect(controller.addSpacesToNumberString(testValue)).toEqual('0');
      expect(controller.addSpacesToNumberString()).toEqual('0');
    });

    it('should work with a small integer', function() {
      var testValue = '10';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('10');
      testValue = '100';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('100');
      testValue = '-100';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('-100');
    });
    it('should break up thousands', function() {
      var testValue = '1000';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('1 000');
      testValue = '10000';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('10 000');
      testValue = '-10000';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('-10 000');
      testValue = '100000';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('100 000');
      testValue = '-100000';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('-100 000');
    });
    it('should break up millions', function() {
      var testValue = '1000000';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('1 000 000');
      testValue = '-1000000';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('-1 000 000');
      testValue = '999999999';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('999 999 999');
    });
    it('should break up gazillions', function() {
      var testValue = '999999999999999999';
      expect(controller.addSpacesToNumberString(testValue)).toEqual('999 999 999 999 999 999');
    });
  });
});


