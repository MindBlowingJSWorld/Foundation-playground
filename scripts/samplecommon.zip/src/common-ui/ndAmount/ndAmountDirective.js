'use strict';

angular.module('dbw-common')

  .directive('ndAmount', ndAmountDirective)
  .controller('ndAmountController', ndAmountController);

function ndAmountDirective() {
  return {
    restrict: 'E',
    replace: true,
    scope: {
      'value' : '@'
    },
    template : '<span class="amount">' +
    '<span class="amount__integers">{{integerPart}}</span><span class="amount__decimal-symbol">,</span>'+
    '<span class="amount__decimals">{{decimalPart}}</span></span>',
    controller : 'ndAmountController',
    link: function (scope, element, attrs, ctrl) {

      function update(value) {
        var parts = ctrl.breakNumberIntoParts(value);
        scope.integerPart = ctrl.addSpacesToNumberString(parts.integerPart);
        scope.decimalPart = parts.decimalPart;
      }

      update(attrs.value);
      attrs.$observe('value', function(value) {
        if (value) {
          update(value);
        }
      });
    }
  };
}

function ndAmountController() {
  /*jshint validthis:true */
  var ctrl = this;

  ctrl.addSpacesToNumberString = function(aNumber) {
    var numberStr =aNumber;
    var isNegative = false;
    if(_.isEmpty(numberStr)) {
      return '0';
    }
    if(numberStr[0]==='-') {
      isNegative = true;
      numberStr = numberStr.slice(1);
    }
    if(numberStr.length<=3) {
      if(isNegative) {
        return '-' + numberStr;
      }
      return numberStr;
    }

    var chunks = [];
    var i, index, charsToRemove = 3;

    for (i = numberStr.length; i > 0 ; i -= 3) {
      index = i-3;
      if(index<0) {
        charsToRemove = charsToRemove + index;
        index=0;
      }
      chunks.unshift(numberStr.substr(index, charsToRemove));
    }
    var result = chunks.join(' ');
    if(isNegative) {
      result = '-' + result;
    }
    return result;
  };

  function createNumberString(value) {
    var numberStr;
    if(_.isFinite(value)) {
      // We have a number, make it into a string
      numberStr = _.toString(value);
    } else {
      if(_.isEmpty(value)) {
        numberStr ='0.00';
      } else {
        if(!_.isString(value)) {
          // throw on value===object
          throw new Error('value has to be number or string');
        }
        // Remove spaces and currencies
        // @todo: this will not work if the comma AND dot is used in the same number - 4.000,00 -> 4
        numberStr = value.replace(/[^\-0-9.,]+/g, '');
      }
    }
    return numberStr;
  }

  /**
   * Breaks the supplied value into its integer and decimal parts
   *
   * @param value
   * @returns {object} { integerPart, decimalPart }
   */
  ctrl.breakNumberIntoParts = function(value) {
    var numberStr = createNumberString(value);
    var result = { decimalPart : '00'};

    // Break up the number string into the two parts. First try with the dot as the separator
    var separator = '.';
    var indexOfseparator = numberStr.indexOf('.');
    if(indexOfseparator<0) {
      indexOfseparator = numberStr.indexOf(',');
      if(indexOfseparator>-1) {
        separator = ',';
      }
    }
    var parts = numberStr.split(separator);
    result.integerPart = parts[0] ? parts[0] : '0';
    if(parts[1]) {
      result.decimalPart = parts[1].substring(0,2);
      if(result.decimalPart.length===1) {
        result.decimalPart += '0';
      }
    }
    return result;
  };
}