'use strict';

angular.module('dbw-common')
    .controller('ndAvatarController', function ($scope) {
        $scope.getBackGroundColor = function() {
            return $scope.hasImg() ? '' : {'background-color': $scope.color};
        };
        $scope.hasImg = function() {
            return $scope.img !== undefined && $scope.img !== '';
        };
    });
