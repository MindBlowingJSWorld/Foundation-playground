'use strict';

angular.module('dbw-common')
    .directive('ndAvatar', function () {
        return {
            restrict: 'E',
            templateUrl: 'ndAvatar/ndAvatar.tpl.html',
            controller: 'ndAvatarController',
            scope: {
                name: '@',
                img: '@',
                color: '@'
            },
            replace: false
        };
    });