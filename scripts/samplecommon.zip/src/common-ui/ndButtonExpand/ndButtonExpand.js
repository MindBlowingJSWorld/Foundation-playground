(function () {
    'use strict';

    var ndButtonExpandComponent = {
        bindings: {
            isExpanded: '=',
            textExpanded: '@',
            textCollapsed: '@',
            buttonClass: '@'
        },
        templateUrl: 'ndButtonExpand/ndButtonExpand.tpl.html'
    };

    angular.module('dbw-common')
        .component('ndButtonExpand', ndButtonExpandComponent);

})();
