'use strict';
describe('nd-button-expand', function () {
    var $compile, $rootScope, $scope, $element;

    beforeEach(module('dbw-common'));
    beforeEach(inject(function (_$compile_, _$rootScope_) {
        $compile = _$compile_;
        $rootScope = _$rootScope_;
        $scope = $rootScope.$new();
    }));

    function compileDirective(directiveTpl) {
        inject(function ($compile) {
            $element = $compile(directiveTpl)($scope); // manually compile the template and inject the scope in
            $scope.$digest(); // manually update all of the bindings
        });
    }

    describe('ndButtonExpand API', function () {

        describe('given attribute is set', function () {
            beforeEach(function () {
                $scope.isExpanded = true;
                compileDirective('<nd-button-expand is-expanded="isExpanded" text-collapsed="Expand" text-expanded="Collapse"></nd-button-expand>');
            });

            it('should have correct button text if is-expanded is true', function () {
                expect($element.find('button').text().trim()).toBe('Collapse');
            });

            it('should have correct icon if is-expanded is true', function () {
                expect($element.find('svg').attr('icon')).toBe('arrow_up_sml');
            });

            it('should have correct button text if is-expanded is false', function () {
                $scope.isExpanded = false;
                $scope.$digest();
                expect($element.find('button').text().trim()).toBe('Expand');
            });

            it('should have correct icon if is-expanded is false', function () {
                $scope.isExpanded = false;
                $scope.$digest();
                expect($element.find('svg').attr('icon')).toBe('arrow_down_sml');
            });
        });
        
    });
});
