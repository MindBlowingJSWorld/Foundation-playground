'use strict';

angular.module('dbw-common')

    .directive('ndIcon', function() {

        var ICON_SIZES = {
            's': 'icon--small',
            'm': 'icon--medium',
            'l': 'icon--large',
            'xl': 'icon--xlarge'
        };

        return {
            restrict: 'E',
            replace: true,
            scope: {
                icon: '@',
                size: '@'
            },
            templateUrl: 'ndIconDirective/ndIconDirective.tpl.html',
            link: function ($scope) {
                $scope.href = '#' + $scope.icon;

                if ($scope.size && ICON_SIZES.hasOwnProperty($scope.size)) {
                    $scope.sizeClass = ICON_SIZES[$scope.size];
                } else if ($scope.icon.match(/_sml$/)) {
                    $scope.sizeClass = ICON_SIZES['s'];
                }
            }
        };
    });