'use strict';

describe('ndIconDirective', function() {

    var compile;

    var $rootScope;
    var $scope;

    beforeEach(module('dbw-common'));

    beforeEach(inject(function(_$rootScope_, _$state_, $compile) {
        $rootScope = _$rootScope_;
        $scope = $rootScope.$new();

        compile = function(html) {
            var element = $compile(html)($scope);
            $scope.$digest();
            return element;
        };
    }));

    it('creates svg use directive with correct reference', function() {
        var element = compile('<nd-icon icon="iconName"></nd-icon>');
        expect(element.find('use').attr('xlink:href')).toBe('#iconName');
    });

    it('if size is defined it adds class for icon size', function() {
        var element = compile('<nd-icon icon="iconName" size="s"></nd-icon>');
        expect(element.hasClass('icon--small')).toBe(true);

        element = compile('<nd-icon icon="iconName" size="m"></nd-icon>');
        expect(element.hasClass('icon--medium')).toBe(true);
    });

    it('if icon name has suffix "_sml" it adds class for small icons', function() {
        var element = compile('<nd-icon icon="iconName_sml"></nd-icon>');
        expect(element.hasClass('icon--small')).toBe(true);
    });

    it('if icon name has suffix "_sml" but size is defined it adds class for corresponding to size', function() {
        var element = compile('<nd-icon icon="iconName_sml" size="m"></nd-icon>');
        expect(element.hasClass('icon--small')).toBe(false);
    });
});
