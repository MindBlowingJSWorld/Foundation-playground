'use strict';

// This is shameless rip from angular-material project

angular.module('dbw-common')
    .directive('ndInputContainer', ndInputContainerDirective)
    .directive('label', labelDirective)
    .directive('input', inputTextareaDirective)
    .directive('textarea', inputTextareaDirective);

function ndInputContainerDirective($parse) {
    return {
        restrict: 'E',
        link: postLink,
        controller: ContainerCtrl
    };

    function postLink(scope, element) {
        element.addClass('input-container');

        // Add an error element if the container does not have one to ensure consistent height between elements
        // that may display error messages and those that do not.
        if ($(element).find('.input-container__error').length === 0) {
            var errorContainer = angular.element('<div class="input-container__error">');
            element.append(errorContainer);
        }

        if (element[0].querySelector('.icon, nd-icon')) {
            element.addClass('input-container--icon');
        }
    }

    function ContainerCtrl($scope, $element, $attrs, $animate) {
        var self = this;

        self.isErrorGetter = $attrs.ndIsError && $parse($attrs.ndIsError);

        self.delegateClick = function() {
            self.input.focus();
        };
        self.element = $element;
        self.setFocused = function(isFocused) {
            $element.toggleClass('is-focused', !!isFocused);
            $element.toggleClass('md-input-focused', !!isFocused);
        };
        self.setHasValue = function(hasValue) {
            $element.toggleClass('is-empty', !hasValue);
            $element.toggleClass('md-input-has-value', !!hasValue);
        };
        self.setHasPlaceholder = function(hasPlaceholder) {
            $element.toggleClass('md-input-has-placeholder', !!hasPlaceholder);
        };
        self.setInvalid = function(isInvalid) {
            if (isInvalid) {
                $animate.addClass($element, 'is-invalid');
                $animate.addClass($element, 'md-input-invalid');
            } else {
                $animate.removeClass($element, 'is-invalid');
                $animate.removeClass($element, 'md-input-invalid');
            }
        };
        $scope.$watch(function() {
            return self.label && self.input;
        }, function(hasLabelAndInput) {
            if (hasLabelAndInput && !self.label.attr('for')) {
                self.label.attr('for', self.input.attr('id'));
            }
        });
    }
}

function labelDirective() {
    return {
        restrict: 'E',
        require: '^?ndInputContainer',
        link: function(scope, element, attr, containerCtrl) {
            if (!containerCtrl || element.hasClass('_md-container-ignore') || element.hasClass('_nd-container-ignore')) {
                return;
            }

            containerCtrl.label = element;
            scope.$on('$destroy', function() {
                containerCtrl.label = null;
            });
        }
    };
}

function inputTextareaDirective($mdUtil, $window, $mdAria) {
    return {
        restrict: 'E',
        require: ['^?ndInputContainer', '?ngModel'],
        link: postLink
    };

    function postLink(scope, element, attr, ctrls) {

        var containerCtrl = ctrls[0];
        var hasNgModel = !!ctrls[1];
        var ngModelCtrl = ctrls[1] || $mdUtil.fakeNgModel();
        var isReadonly = angular.isDefined(attr.readonly);

        if (!containerCtrl) {
            return;
        }
        if (containerCtrl.input) {
            throw new Error('<nd-input-container> can only have *one* <input>, <textarea> or <nd-select> child element!');
        }
        containerCtrl.input = element;

        setupAttributeWatchers();

        if (!containerCtrl.label) {
            $mdAria.expect(element, 'aria-label', element.attr('placeholder'));
        }

        if (!element.attr('id')) {
            element.attr('id', 'input_' + $mdUtil.nextUid());
        }

        if (element[0].tagName.toLowerCase() === 'textarea') {
            setupTextarea();
        }

        // If the input doesn't have an ngModel, it may have a static value. For that case,
        // we have to do one initial check to determine if the container should be in the
        // "has a value" state.
        if (!hasNgModel) {
            inputCheckValue();
        }

        var isErrorGetter = containerCtrl.isErrorGetter || function () {
                return ngModelCtrl.$invalid && (ngModelCtrl.$touched || isParentFormSubmitted());
            };

        function isParentFormSubmitted() {
            var parent = $mdUtil.getClosest(element, 'form');
            var form = parent ? angular.element(parent).controller('form') : null;

            return form ? form.$submitted : false;
        }

        scope.$watch(isErrorGetter, containerCtrl.setInvalid);

        ngModelCtrl.$parsers.push(ngModelPipelineCheckValue);
        ngModelCtrl.$formatters.push(ngModelPipelineCheckValue);

        element.on('input', inputCheckValue);

        if (!isReadonly) {
            element
                .on('focus', function(ev) {
                    $mdUtil.nextTick(function() {
                        containerCtrl.setFocused(true);
                    });
                })
                .on('blur', function(ev) {
                    $mdUtil.nextTick(function() {
                        containerCtrl.setFocused(false);
                        inputCheckValue();
                    });
                });
        }

        scope.$on('$destroy', function() {
            containerCtrl.setFocused(false);
            containerCtrl.setHasValue(false);
            containerCtrl.input = null;
        });

        function ngModelPipelineCheckValue(arg) {
            containerCtrl.setHasValue(!ngModelCtrl.$isEmpty(arg));
            return arg;
        }

        function setupAttributeWatchers() {
            // No-op at the moment.
        }

        function inputCheckValue() {
            // An input's value counts if its length > 0,
            // or if the input's validity state says it has bad input (eg string in a number input)
            containerCtrl.setHasValue(element.val().length > 0 || (element[0].validity || {}).badInput);
        }

        function setupTextarea() {
            if (angular.isDefined(element.attr('nd-no-autogrow'))) {
                return;
            }

            var node = element[0];
            var container = containerCtrl.element[0];

            var minRows = NaN;
            var lineHeight = null;
            // Can't check if height was or not explicity set,
            // so rows attribute will take precedence if present.
            if (node.hasAttribute('rows')) {
                minRows = parseInt(node.getAttribute('rows'));
            }

            var onChangeTextarea = $mdUtil.debounce(growTextarea, 1);

            function pipelineListener(value) {
                onChangeTextarea();
                return value;
            }

            if (ngModelCtrl) {
                ngModelCtrl.$formatters.push(pipelineListener);
                ngModelCtrl.$viewChangeListeners.push(pipelineListener);
            } else {
                onChangeTextarea();
            }
            element.on('keydown input', onChangeTextarea);

            if (isNaN(minRows)) {
                element.attr('rows', '1');

                element.on('scroll', onScroll);
            }

            angular.element($window).on('resize', onChangeTextarea);

            scope.$on('$destroy', function() {
                angular.element($window).off('resize', onChangeTextarea);
            });

            function growTextarea() {
                // Sets the nd-input-container height to avoid jumping around.
                container.style.height = container.offsetHeight + 'px';

                if (isNaN(minRows)) {
                    node.style.height = 'auto';
                    node.scrollTop = 0;
                    var height = getHeight();
                    if (height) {
                        node.style.height = height + 'px';
                    }
                } else {
                    node.setAttribute('rows', '1');

                    if (!lineHeight) {
                        node.style.minHeight = '0';

                        lineHeight = element.prop('clientHeight');

                        node.style.minHeight = null;
                    }

                    var rows = Math.min(minRows, node.scrollHeight / lineHeight);
                    node.setAttribute('rows', ''+Math.round(rows));
                    node.style.height = lineHeight * rows + 'px';
                }

                // Reset everything back to normal.
                container.style.height = 'auto';
            }

            function getHeight() {
                var line = node.scrollHeight - node.offsetHeight;
                return node.offsetHeight + (line > 0 ? line : 0);
            }

            function onScroll() {
                node.scrollTop = 0;
                // For smooth new line adding.
                var line = node.scrollHeight - node.offsetHeight;
                var height = node.offsetHeight + line;
                node.style.height = height + 'px';
            }

            // Attach a watcher to detect when the textarea gets shown.
            if (angular.isDefined(element.attr('nd-detect-hidden'))) {

                var handleHiddenChange = (function() {
                    var wasHidden = false;

                    return function() {
                        var isHidden = node.offsetHeight === 0;

                        if (isHidden === false && wasHidden === true) {
                            growTextarea();
                        }

                        wasHidden = isHidden;
                    };
                })();

                // Check every digest cycle whether the visibility of the textarea has changed.
                // Queue up to run after the digest cycle is complete.
                scope.$watch(function() {
                    $mdUtil.nextTick(handleHiddenChange, false);
                    return true;
                });
            }
        }

    }
}