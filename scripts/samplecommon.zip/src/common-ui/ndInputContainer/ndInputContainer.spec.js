'use strict';

describe('nd-input-container directive', function() {
    var $rootScope, $compile, $timeout, pageScope;

    beforeEach(module('dbw-common'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');

        pageScope = $injector.get('$rootScope').$new();
    }));

    beforeEach(inject(function($injector) {
        $rootScope = $injector.get('$rootScope');
        $compile = $injector.get('$compile');
        $timeout = $injector.get('$timeout');
    }));

    function setupInput(attrs, isForm) {
        var template = [
            '<nd-input-container>',
                '<label></label>',
                '<input ' + (attrs || '') + '/>',
            '</nd-input-container>'
        ].join(' ');

        if (isForm) {
            template = '<form>' + template + '</form>';
        }

        return compile(template);
    }

    function setupTextarea(attrs, value, isForm) {
        var template = [
            '<nd-input-container>',
                '<label></label>',
                '<textarea ' + (attrs || '') + '>' + (value || '')  + '</textarea>',
            '</nd-input-container>'
        ].join(' ');

        if (isForm) {
            template = '<form>' + template + '</form>';
        }

        return compile(template);
    }

    function compile(template) {
        var container;

        container = $compile(template)(pageScope);

        pageScope.$apply();
        return container;
    }

    it('should create correct basic markup', function() {
        var el = setupInput();
        expect(el).toHaveClass('input-container');
    });

    it('should add an input-container__error element if the container does not have one', function() {
        var el = setupInput();
        expect(el.find('.input-container__error').length).toBe(1);

        el = compile([
            '<nd-input-container>',
                '<label></label>',
                '<input/>',
                '<div class="input-container__error"/>',
            '</nd-input-container>'
        ].join(' '));
        expect(el.find('.input-container__error').length).toBe(1);
    });

    it('should match label to given input id', function() {
        var el = setupInput('id="foo"');
        expect(el.find('label').attr('for')).toBe('foo');
        expect(el.find('input').attr('id')).toBe('foo');
    });

    it('should match label to automatic input id', function() {
        var el = setupInput();
        expect(el.find('input').attr('id')).toBeTruthy();
        expect(el.find('label').attr('for')).toBe(el.find('input').attr('id'));
    });

    it('should set is-focused class on container', function() {
        var el = setupInput();
        expect(el).not.toHaveClass('is-focused');

        el.find('input').triggerHandler('focus');

        expect(el).not.toHaveClass('is-focused');
        $timeout.flush();
        expect(el).toHaveClass('is-focused');

        el.find('input').triggerHandler('blur');

        // Again, expect the change to not be immediate
        expect(el).toHaveClass('is-focused');
        $timeout.flush();
        expect(el).not.toHaveClass('is-focused');
    });

    it('should not set focus class on container if readonly', function() {
        var el = setupInput('readonly');
        expect(el).not.toHaveClass('is-focused');

        el.find('input').triggerHandler('focus');
        expect(el).not.toHaveClass('is-focused');

        el.find('input').triggerHandler('blur');
        expect(el).not.toHaveClass('is-focused');
    });

    it('should not set focus class on container if disabled', function() {
        var el = setupInput('disabled');
        expect(el).not.toHaveClass('is-focused');

        el.find('input').triggerHandler('focus');
        expect(el).not.toHaveClass('is-focused');

        el.find('input').triggerHandler('blur');
        expect(el).not.toHaveClass('is-focused');
    });

    it('should put the container in "empty" state when input has an empty static value', function() {
        var el = setupInput('value=""');
        expect(el).toHaveClass('is-empty');
    });


    it('should set is-empty class on container for non-ng-model input', function() {
        var el = setupInput();
        expect(el).toHaveClass('is-empty');

        el.find('input').val('123').triggerHandler('input');
        expect(el).not.toHaveClass('is-empty');

        el.find('input').val('').triggerHandler('input');
        expect(el).toHaveClass('is-empty');
    });

    it('should set is-empty class on container for non-ng-model texarea', function() {
        var el = setupTextarea();
        expect(el).toHaveClass('is-empty');

        el.find('textarea').val('123').triggerHandler('input');
        expect(el).not.toHaveClass('is-empty');

        el.find('textarea').val('').triggerHandler('input');
        expect(el).toHaveClass('is-empty');
    });

    it('should set is-empty class on container for ng-model input that has an empty value', function() {
        pageScope.value = 'test';
        var el = setupInput('ng-model="value"');
        expect(el).not.toHaveClass('is-empty');

        pageScope.$apply('value = undefined');
        expect(el).toHaveClass('is-empty');

        pageScope.$apply('value = null');
        expect(el).toHaveClass('is-empty');
    });

    it('should set is-empty class on container for ng-model textarea that has an empty value', function() {
        pageScope.value = 'test';
        var el = setupTextarea('ng-model="value"');
        expect(el).not.toHaveClass('is-empty');

        pageScope.$apply('value = undefined');
        expect(el).toHaveClass('is-empty');

        pageScope.$apply('value = null');
        expect(el).toHaveClass('is-empty');
    });


    it('should set input-container--icon if the container contains an icon element', function() {
        var el = setupInput();
        expect(el).not.toHaveClass('input-container--icon');

        el = compile([
            '<nd-input-container>',
            '<label></label>',
            '<input/> <nd-icon icon="calendar"></nd-icon>',
            '<div class="input-container__error"/>',
            '</nd-input-container>'
        ].join(' '));
        expect(el).toHaveClass('input-container--icon');

        el = compile([
            '<nd-input-container>',
            '<label></label>',
            '<input/> <svg class="icon"></svg>',
            '<div class="input-container__error"/>',
            '</nd-input-container>'
        ].join(' '));
        expect(el).toHaveClass('input-container--icon');
    });

    it('should by default show error on $touched and $invalid', function() {
        var el = setupInput('ng-model="foo"');

        expect(el).not.toHaveClass('is-invalid');

        var model = el.find('input').controller('ngModel');
        model.$touched = model.$invalid = true;
        pageScope.$apply();

        expect(el).toHaveClass('is-invalid');

        model.$touched = model.$invalid = false;
        pageScope.$apply();
        expect(el).not.toHaveClass('is-invalid');
    });

    it('should show error on $submitted and $invalid', function() {
        var el = setupInput('ng-model="foo"', true);

        expect(el.find('nd-input-container')).not.toHaveClass('is-invalid');

        var model = el.find('input').controller('ngModel');
        model.$invalid = true;

        var form = el.controller('form');
        form.$submitted = true;
        pageScope.$apply();

        expect(el.find('nd-input-container')).toHaveClass('is-invalid');
    });

    it('should show error on $submitted and $invalid with nested forms', function() {
        var template =
            '<form>' +
                '<div ng-form>' +
                    '<nd-input-container>' +
                        '<label></label>' +
                        '<input ng-model="foo">' +
                    '</nd-input-container>' +
                '</div>' +
            '</form>';

        var parentForm = $compile(template)(pageScope);
        pageScope.$apply();

        expect(parentForm.find('nd-input-container')).not.toHaveClass('is-invalid');

        var model = parentForm.find('input').controller('ngModel');
        model.$invalid = true;

        var form = parentForm.controller('form');
        form.$submitted = true;
        pageScope.$apply();

        expect(parentForm.find('nd-input-container')).toHaveClass('is-invalid');
    });

    it('should not show error on $invalid and not $submitted', function() {
        var el = setupInput('ng-model="foo"', true);

        expect(el.find('nd-input-container')).not.toHaveClass('is-invalid');

        var model = el.find('input').controller('ngModel');
        model.$invalid = true;

        pageScope.$apply();

        expect(el.find('nd-input-container')).not.toHaveClass('is-invalid');
    });

    it('should show error with given nd-is-error expression', function() {
        var el = $compile(
            '<nd-input-container nd-is-error="isError">' +
                '<input ng-model="foo">' +
            '</nd-input-container>')(pageScope);

        pageScope.$apply();
        expect(el).not.toHaveClass('is-invalid');

        pageScope.$apply('isError = true');
        expect(el).toHaveClass('is-invalid');

        pageScope.$apply('isError = false');
        expect(el).not.toHaveClass('is-invalid');
    });

    describe('placeholder', function() {

        it('should not add the md-input-has-placeholder class when the placeholder is transformed into a label', inject(function($rootScope, $compile) {
            var el = $compile(
                '<nd-input-container><input ng-model="foo" placeholder="some placeholder"></nd-input-container>'
            )($rootScope);

            expect(el.hasClass('md-input-has-placeholder')).toBe(false);
        }));

        it('should add the md-input-has-placeholder class when both the placeholder and label are provided', inject(function($rootScope, $compile) {
            var el = $compile(
                '<nd-input-container>' +
                '  <label>Hello</label>' +
                '  <input ng-model="foo" placeholder="some placeholder" />' +
                '</nd-input-container>'
            )($rootScope);

            expect(el.hasClass('md-input-has-placeholder')).toBe(true);
        }));

        it('should put placeholder into a label element', function() {
            var el = $compile('<nd-input-container><input ng-model="foo" placeholder="some placeholder"></nd-input-container>')(pageScope);
            var placeholder = el[0].querySelector('.md-placeholder');
            var label = el.find('label')[0];

            expect(el.find('input')[0].hasAttribute('placeholder')).toBe(false);
            expect(label).toBeTruthy();
            expect(label.textContent).toEqual('some placeholder');
        });

        it('should ignore placeholder when a label element is present', inject(function($rootScope, $compile) {
            var el = $compile(
                '<nd-input-container>' +
                '  <label>Hello</label>' +
                '  <input ng-model="foo" placeholder="some placeholder" />' +
                '</nd-input-container>'
            )(pageScope);

            var label = el.find('label')[0];

            expect(el.find('input')[0].hasAttribute('placeholder')).toBe(true);
            expect(label).toBeTruthy();
            expect(label.textContent).toEqual('Hello');
        }));

        it('should put an aria-label on the input when no label is present', function() {
            var el = $compile('<form name="form">' +
                ' <nd-input-container md-no-float>' +
                '   <input placeholder="baz" ng-model="foo" name="foo">' +
                ' </nd-input-container>' +
                '</form>')(pageScope);

            pageScope.$apply();

            var input = el.find('input');
            expect(input.attr('aria-label')).toBe('baz');
        });
    });

    describe('containing md-option', function() {

        function setupSelect(attrs, options, skipLabel, optCompileOpts) {
            var el;

            var src = '<nd-input-container>';
            if (!skipLabel) {
                src += '<label>Label</label>';
            }
            src += '<md-select ' + (attrs || '') + '>' + optTemplate(options, optCompileOpts) + '</md-select></nd-input-container>';
            var template = angular.element(src);
            el = compile(template);

            return el;
        }

        function optTemplate(options, compileOpts) {
            var optionsTpl = '';
            inject(function($rootScope) {
                if (angular.isArray(options)) {
                    $rootScope.$$values = options;
                    var renderValueAs = compileOpts ? compileOpts.renderValueAs || 'value' : 'value';
                    optionsTpl = '<md-option ng-repeat="value in $$values" ng-value="value"><div class="md-text">{{' + renderValueAs + '}}</div></md-option>';
                } else if (angular.isString(options)) {
                    optionsTpl = options;
                }
            });
            return optionsTpl;
        }

        function openSelect(el) {
            if (el[0].nodeName != 'MD-SELECT') {
                el = el.find('md-select');
            }
            try {
                el.triggerHandler('click');
                waitForSelectOpen();
                el.triggerHandler('blur');
            } catch (e) { }
        }

        function clickOption(select, index) {
            inject(function($rootScope, $document) {
                var openMenu = $document.find('md-select-menu');
                var opt = angular.element(openMenu.find('md-option')[index]).find('div')[0];

                if (!opt) throw Error('Could not find option at index: ' + index);
                var target = angular.element(opt);
                angular.element(openMenu).triggerHandler({
                    type: 'click',
                    target: target,
                    currentTarget: openMenu[0]
                });
            });
        }

        function closeSelect() {
            inject(function($document) {
                var backdrop = $document.find('md-backdrop');
                if (!backdrop.length) throw Error('Attempted to close select with no backdrop present');
                $document.find('md-backdrop').triggerHandler('click');
            });
            waitForSelectClose();
        }

        function waitForSelectOpen() {
            inject(function($material) {
                $material.flushInterimElement();
            });
        }

        function waitForSelectClose() {
            inject(function($material) {
                $material.flushInterimElement();
            });
        }

        it('should set is-empty class on container for non-ng-model select that has an empty value', function() {
            var el = setupSelect('ng-model="value"', [1, 2, 3]);
            var select = el.find('md-select');

            expect(el).toHaveClass('is-empty');

            openSelect(select);
            clickOption(select, 0);
            waitForSelectClose();

            expect(el).not.toHaveClass('is-empty');
        });

        it('should set is-empty class on container for ng-model input that has an empty value',function() {
            pageScope.value = 'test';
            var el = setupSelect('ng-model="value"', ['test', 'no-test']);
            expect(el).not.toHaveClass('is-empty');

            pageScope.$apply('value = null');
            expect(el).toHaveClass('is-empty');
        });

        it('should match label to given input id', function() {
            var el = setupSelect('ng-model="value" id="foo"');
            expect(el.find('label').attr('for')).toBe('foo');
            expect(el.find('md-select').attr('id')).toBe('foo');
        });

        it('should match label to automatic input id', function() {
            var el = setupSelect('ng-model="value"');
            expect(el.find('md-select').attr('id')).toBeTruthy();
            expect(el.find('label').attr('for')).toBe(el.find('md-select').attr('id'));
        });

    });
});