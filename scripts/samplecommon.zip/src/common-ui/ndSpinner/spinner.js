'use strict';

angular
    .module('dbw-common')
    .directive('ndSpinner', function ndSpinnerEl() {
        return {
            restrict: 'E', // Element only
            scope: {
                watch: '=',
                spinAnimate: '@',
                spinClass: '@',
                spinImage: '@',
                spinOpacity: '@',
                spinReenable: '@'
            },
            transclude: true,
            templateUrl: 'ndSpinner/spinner.tpl.html',
            bindToController: true,
            controllerAs: 'vm',
            controller: NdSpinnerController
        };
    });

function NdSpinnerController($scope) {
    var vm = this;
    var spinning = [undefined, null, false];

    // Figure out initial state.
    vm.onSpinning = spinning.indexOf(vm.watch) !== -1;

    // If we are spinning from the start or do are in reenableable state register our watch.
    if (vm.onSpinning || vm.spinReenable !== undefined) {
        //Only register the watch if we should be spinning.
        var unregisterWatch = $scope.$watchGroup(['vm.watch', 'vm.spinImage'], function (watchValue) {
            // Update whether we should be spinning.
            vm.onSpinning = spinning.indexOf(watchValue[0]) !== -1;
            vm.resetStyle(vm.onSpinning, vm);

            // If spinning should stop and we should unregister our watch ...
            if (!vm.onSpinning && vm.spinReenable === undefined) {
                unregisterWatch();
            }
        });
    } else {
      vm.resetStyle();
    }
}

NdSpinnerController.prototype = {

    isPredefinedImage: function (spinImage) {
        return ['large', 'small', 'none'].indexOf(spinImage) > -1;
    },

    setSpinImage: function () {
        this.sStyle = {};
        if (this.isPredefinedImage(this.spinImage)) {
            this.spinImageClass = this.spinImage;
        } else if (_.trim(this.spinImage).length === 0) {
            this.spinImageClass = 'small';
        } else {
            this.templateStyle = {
                'background-image': ' url(' + this.spinImage + ')',
                'background-size': 'contain'
            };
            this.spinImageClass = 'small';
        }
    },

    resetStyle: function (state, vm) {
        this.onSpinning = state;
        if (state) {
            vm.setSpinImage();
            this.templateImageClass = this.spinImageClass;
            this.templateClass = this.spinClass;
            this.templateOpacity = this.spinOpacity;
            this.templateAnimate = '';
        } else {
            this.templateStyle = {};
            this.templateImageClass = '';
            this.templateClass = '';
            this.templateOpacity = 1;
            this.templateAnimate = this.spinAnimate || 'opacity .5s ease 0s';
        }
    }
};
