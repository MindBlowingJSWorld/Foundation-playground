'use strict';

describe('Spinner', function () {

    var $rootScope, $compile, $timeout, $scope;

    beforeEach(module('dbw-common'));

    beforeEach(inject(function ($injector) {
        $rootScope = $injector.get('$rootScope');
        $compile = $injector.get('$compile');
        $timeout = $injector.get('$timeout');
        $scope = $rootScope.$new();
    }));

    function compile(template) {
        var container;
        container = $compile(template)($scope);
        $scope.$apply();
        return container;
    }

    describe('spin image', function () {

        it('sets default image if spin-image is undefined', function () {
            var directiveEl = compile('<nd-spinner>hello</nd-spinner>');
            expect(directiveEl.find('div')).toHaveClass('nd-spinner--small');
            expect(directiveEl.find('div').css('background-image')).toMatch(/(''||'none')/);
        });

        it('sets large image if spin-image is large', function () {
            var directiveEl = compile('<nd-spinner spin-image="large">hello</nd-spinner>');
            expect(directiveEl.find('div')).not.toHaveClass('nd-spinner--small');
            expect(directiveEl.find('div')).toHaveClass('nd-spinner--large');
            expect(directiveEl.find('div').css('background-image')).toMatch(/(''||'none')/);
        });

        it('sets small image if spin-image is small', function () {
            var directiveEl = compile('<nd-spinner spin-image="small">hello</nd-spinner>');
            expect(directiveEl.find('div')).not.toHaveClass('nd-spinner--large');
            expect(directiveEl.find('div')).toHaveClass('nd-spinner--small');
            expect(directiveEl.find('div').css('background-image')).toMatch(/(''||'none')/);
        });

        it('sets none image if spin-image is none', function () {
            var directiveEl = compile('<nd-spinner spin-image="none">hello</nd-spinner>');
            expect(directiveEl.find('div')).not.toHaveClass('nd-spinner--small');
            expect(directiveEl.find('div')).toHaveClass('nd-spinner--none');
            expect(directiveEl.find('div').css('background-image')).toMatch(/(''||'none')/);
        });

        it('sets spin image value as as background image url if it does not match a predefined value', function () {
            var directiveEl = compile('<nd-spinner spin-image="spinner.gif">hello</nd-spinner>');
            expect(directiveEl.find('div').css('background-image')).toMatch('url(.*spinner.gif)');

            directiveEl = compile('<nd-spinner spin-image="http://myapp.com/images/spinner.gif">hello</nd-spinner>');
            expect(directiveEl.find('div').css('background-image')).toMatch('url(.*http://myapp.com/images/spinner.gif.*)');

            directiveEl = compile('<nd-spinner spin-image="whatever">hello</nd-spinner>');
            expect(directiveEl.find('div').css('background-image')).toMatch('url(.*whatever)');
        });

    });

    describe('on watch property update', function () {

        it('reset style if watch attribute is truthy', function () {
            $scope.spinnerWatch = false;
            var directiveEl = compile('<nd-spinner watch="spinnerWatch">hello</nd-spinner>');
            $scope.$apply();
            expect(directiveEl.find('div')).toHaveClass('nd-spinner--small');

            $scope.spinnerWatch = true;
            $scope.$apply();
            expect(directiveEl.find('div')).not.toHaveClass('nd-spinner--small');
        });

        it('reset opacity if watch attribute is truthy by default', function () {
          $scope.spinnerWatch = true;
          var directiveEl = compile('<nd-spinner watch="spinnerWatch">hello</nd-spinner>');
          $scope.$apply();
          expect(directiveEl.find('div div').css('opacity')).toEqual('1');
        });
    });


});
