'use strict';

angular.module('dbw-common')
    .controller('NdNotificationSetController', NdNotificationSetController);

function NdNotificationSetController($scope, FoundationApi) {
    var controller = this;
    controller.notifications = $scope.notifications = $scope.notifications || [];

    controller.addNotification = function (notification) {
        if (notification) {
            if (!notification.id) {
                notification.id = FoundationApi.generateUuid(); // Make sure that the notification obj has an id.
            }
            $scope.notifications.push(notification);
        }
    };

    controller.removeNotification = function (id) {
        $scope.notifications.forEach(function (notification) {
            if (notification.id === id) {
                var index = $scope.notifications.indexOf(notification);
                $scope.notifications.splice(index, 1);
            }
        });
    };

    controller.clearAll = function () {
        while ($scope.notifications.length > 0) {
            $scope.notifications.pop();
        }
    };
}
