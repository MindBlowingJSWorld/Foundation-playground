'use strict';

angular.module('dbw-common')
    .factory('NotificationService', NotificationService);

function NotificationService(FoundationApi) {

    var defaulNotification = {
        title: 'Title',
        content: 'Content.'
    };

    function _showNotification(notification, notificationSetId) {
        if (notification === undefined || notification === null || typeof notification !== 'object') {
            return;
        }
        _.defaults(notification, defaulNotification);
        FoundationApi.publish(notificationSetId, notification);
    }

    function _hideNotification(notificationId, notificationSetId) {
        if (typeof notificationId === 'object' || typeof notificationId === 'string' || !isNaN(notificationId)) { // Check if id is an object, string, or a number
            if (notificationId.id) {
                notificationId = notificationId.id;
            }
            FoundationApi.publish(notificationSetId, {id: notificationId, action: 'clear'});
        } else {
            FoundationApi.publish(notificationSetId, 'clearall');
        }
    }

    // Top notification.
    function showTopNotification(notification) {
        _showNotification(notification, 'top');
    }

    function hideTopNotification(toastId) {
        _hideNotification(toastId, 'top');
    }

    // Toast notification.
    function showToast(notification, toastSetId) {
        _showNotification(notification, toastSetId || 'toast');
    }

    function hideToast(toastId, toastSetId) {
        _hideNotification(toastId, toastSetId || 'toast');
    }

    return {
        hideTopNotification: hideTopNotification,
        showTopNotification: showTopNotification,
        showToast: showToast,
        hideToast: hideToast
    };
}