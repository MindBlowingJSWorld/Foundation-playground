'use strict';

describe('Notification service', function () {

    var notificationService, FoundationApi;

    var defaulNotification = {
        title: 'Title',
        content: 'Content.'
    };

    var sampleNotification = {
        title: 'some title',
        content: 'some content.'
    };

    beforeEach(module('dbw-common'));
    beforeEach(function () {
        module(function ($provide) {
            FoundationApi = {
                publish: angular.noop
            };

            $provide.value('FoundationApi', FoundationApi);
            spyOn(FoundationApi, 'publish');
        });
    });
    beforeEach(
        inject(function (NotificationService) {
            notificationService = NotificationService;
        })
    );

    it('should exist', function () {
        expect(notificationService).toBeDefined();
    });

    describe('top notification', function () {

        var topNotificationId, setId;

        beforeEach(function () {
            setId = 'setId';
            topNotificationId = 'topNotificationId';
            sampleNotification.id = topNotificationId;
        });

        describe('show top notification behavior on ', function () {
            it('showTopNotification()', function () {
                notificationService.showTopNotification();
                expect(FoundationApi.publish).not.toHaveBeenCalled();
            });

            it('showTopNotification(sampleNotification)', function () {
                notificationService.showTopNotification(sampleNotification);
                expect(FoundationApi.publish).toHaveBeenCalledWith('top', sampleNotification);
            });
        });

        describe('hide top notification behavior on ', function () {

            it('hideTopNotification()', function () {
                notificationService.hideTopNotification();
                expect(FoundationApi.publish).toHaveBeenCalledWith('top', 'clearall');
            });

            it('showTopNotification(topNotiId)', function () {
                sampleNotification.id = topNotificationId;
                notificationService.hideTopNotification(topNotificationId); // then remove it
                expect(FoundationApi.publish).toHaveBeenCalledWith('top', {
                    id: topNotificationId,
                    action: 'clear'
                });
            });

            it('hideTopNotification(sampleNotification)', function () {
                notificationService.hideTopNotification(sampleNotification); // then remove it
                expect(FoundationApi.publish).toHaveBeenCalledWith('top', {
                    id: topNotificationId,
                    action: 'clear'
                });
            });

        });

    });

    describe('toast', function () {
        var toastId, setId;

        beforeEach(function () {
            setId = 'setId';
            toastId = 'toastId';
            sampleNotification.id = toastId;
        });

        describe('show toast behavior on ', function () {
            it('showToast()', function () {
                notificationService.showToast();
                expect(FoundationApi.publish).not.toHaveBeenCalled();
            });

            it('showToast(notification)', function () {
                notificationService.showToast(sampleNotification);
                expect(FoundationApi.publish).toHaveBeenCalledWith('toast', sampleNotification);
            });

            it('showToast({},setId)', function () {
                notificationService.showToast({}, setId);
                expect(FoundationApi.publish).toHaveBeenCalledWith(setId, defaulNotification);
            });

            it('showToast(notification,setId)', function () {
                notificationService.showToast(sampleNotification, setId);
                expect(FoundationApi.publish).toHaveBeenCalledWith(setId, sampleNotification);
            });

        });

        describe('hide toast behavior on ', function () {

            it('hideToast()', function () {
                notificationService.hideToast();
                expect(FoundationApi.publish).toHaveBeenCalledWith('toast', 'clearall');
            });

            it('hideToast(toastId)', function () {
                notificationService.hideToast(toastId);
                expect(FoundationApi.publish).toHaveBeenCalledWith('toast', {
                    id: 'toastId',
                    action: 'clear'
                });
            });

            it('hideToast(toastId, setId)', function () {
                notificationService.hideToast(toastId, setId); //pass in an id
                expect(FoundationApi.publish).toHaveBeenCalledWith(setId, {
                    id: 'toastId',
                    action: 'clear'
                });
            });

            it('hideToast(sampleNotification, setId)', function () {
                notificationService.hideToast(sampleNotification, setId); //pass in an id
                expect(FoundationApi.publish).toHaveBeenCalledWith(setId, {
                    id: 'toastId',
                    action: 'clear'
                });

            });

        });

    });

});