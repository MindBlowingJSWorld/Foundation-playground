'use strict';

angular.module('dbw-common')
    .directive('ndNotification', ndNotification)
;

function ndNotification(FoundationApi, $sce, $timeout) {
    return {
        restrict: 'EA',
        templateUrl: function (elem, attrs) {
            return attrs.type === 'toast' ? 'notification/notification-toast.tpl.html' : 'notification/notification-top.tpl.html';
        },
        replace: true,
        transclude: true,
        require: '^ndNotificationSet',
        controller: function () {
        },
        scope: {
            title: '=?',
            content: '=?',
            image: '=?',
            notifId: '=',
            color: '=?',
            autoclose: '=?'
        },
        compile: compile
    };

    function compile() {

        return {
            pre: preLink,
            post: postLink
        };

        function preLink(scope, iElement, iAttrs) {
            iAttrs.$set('zf-closable', 'notification');
            if (iAttrs['title']) {
                scope.$watch('title', function (value) {
                    if (value) {
                        scope.trustedTitle = $sce.trustAsHtml(value);
                    }
                });
            }
        }

        function postLink(scope, element, attrs, controller) {
            scope.getContentUrl = function () {
                return 'notification/toast/notification-toast.tpl.html';
            };

            scope.active = false;
            var animationIn = attrs.animationIn || 'fadeIn';
            var animationOut = attrs.animationOut || 'fadeOut';
            var animate = attrs.hasOwnProperty('zfAdvise') ? FoundationApi.animateAndAdvise : FoundationApi.animate;

            //due to dynamic insertion of DOM, we need to wait for it to show up and get working!
            $timeout(function () {
                scope.active = true;
                animate(element, scope.active, animationIn, animationOut);
            }, 50);

            scope.hide = function () {
                scope.active = false;
                animate(element, scope.active, animationIn, animationOut);
                $timeout(function () {
                    controller.removeNotification(scope.notifId);
                }, 250); // 250 since you want to give a little bit of time for fading out animation before completely removing it from the DOM.
            };

            // Close if autoclose.
            if (scope.autoclose === undefined) {
                scope.autoclose = 5000;
            }
            if (_.isNumber(scope.autoclose)) {
                $timeout(function () {
                    if (scope.active) {
                        scope.hide();
                    }
                }, parseInt(scope.autoclose));
            }
        }
    }
}
