'use strict';

angular.module('dbw-common')
    .directive('ndNotificationSet', ndNotificationSet);

function ndNotificationSet(FoundationApi) {
    var directive = {
        restrict: 'EA',
        templateUrl: 'notification/notification-set.tpl.html',
        controller: 'NdNotificationSetController',
        replace: true,
        scope: {
            position: '@',
            type: '@',
            id: '@'
        },
        link: link
    };

    return directive;

    function link(scope, element, attrs, controller) {

        scope.type = scope.type || 'top';
        scope.id = scope.id || scope.type; // if undefined, by default, scope.id will be equal to scope.type. So a set with type = 'toast' will have an id of 'toast'.

        if(scope.type != 'top'){
            scope.position = scope.position ? scope.position.split(' ').join('-') : 'bottom-left';
        }

        FoundationApi.subscribe(scope.id, function (msg) {

            if (msg === 'clearall') {

                controller.clearAll();

            } else {

                if (msg.action === 'clear') {
                    controller.removeNotification(msg.id);
                } else {
                    controller.addNotification(msg);
                }

                if (!scope.$root.$$phase) {
                    scope.$apply();
                }
            }

        });
    }
}
