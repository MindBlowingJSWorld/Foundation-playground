'use strict';

angular.module('dbw-common')
    .directive('ndScrollFocus', scrollFocusDirective);


function scrollFocusDirective($anchorScroll, $location, $document, $interpolate, $timeout) {
    return {
        restrict: 'A',
        link: link
    };

    function link($scope, iElem, iAttrs) {
        $timeout(function () {
            var hashValue = $interpolate(iAttrs.ndScrollFocus)($scope);
            if (_.startsWith(hashValue, '#')) {
                hashValue = hashValue.substr(1);
            }

            if (hashValue) {
                iElem.click(function () {
                    var target = $document.find('#' + hashValue);
                    if (target.length > 0) {
                        $location.hash(hashValue);
                        target.focus();
                        $anchorScroll(hashValue);
                        $scope.$apply(); // Update browser URL (click event not handled by Angular)
                    }
                });
            }
        });
    }
}