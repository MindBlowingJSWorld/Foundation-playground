'use strict';

describe('nd-scroll-focus directive', function () {
    var $scope;
    var $compile;
    var $anchorScroll;
    var $document;
    var $location;
    var mainContentEl;

    beforeEach(module('dbw-common', function ($provide) {
        $anchorScroll = jasmine.createSpy('$anchorScroll');
        $provide.value('$anchorScroll', $anchorScroll);

        $location = jasmine.createSpyObj('$location', ['hash']);
        $provide.value('$location', $location);

        var $timeout = function (func) {
            func();
        };
        $provide.value('$timeout', $timeout);
    }));

    beforeEach(inject(function ($injector) {
        $scope = $injector.get('$rootScope').$new();
        $compile = $injector.get('$compile');
        $document = $injector.get('$document');
    }));

    beforeEach(function () {
        mainContentEl = $('<main id="main-content"></main>');
        $(document.body).append(mainContentEl); // Use Jasmine's document body so we can test DOM stuff

        jasmine.mockElementFocus(); // Mocks the focus() method so that $document.activeElement is set as the focused element
    });

    afterEach(function () {
        $(document.body).find('#main-content').remove();
    });


    function compile(template) {
        var element = $compile(template)($scope);
        $(document.body).append(element);
        $scope.$apply();
        return element;
    }

    it('scrolls to target element using $anchorScroll when directive element is clicked', function () {
        var anchor = compile('<a nd-scroll-focus="main-content">Go to main content</a>');
        anchor.triggerHandler('click');
        expect($anchorScroll).toHaveBeenCalledWith('main-content'); // $anchorScroll must be called without the # character
    });

    it('sets focus on target element when directive element is clicked', function () {
        var anchor = compile('<a nd-scroll-focus="main-content">Go to main content</a>');
        anchor.triggerHandler('click');
        expect($document.activeElement.id).toBe('main-content');
    });

    it('sets location hash when directive element is clicked', function () {
        var anchor = compile('<a nd-scroll-focus="main-content">Go to main content</a>');
        anchor.triggerHandler('click');
        expect($location.hash).toHaveBeenCalledWith('main-content');
    });

    it('interpolates nd-scroll-focus value', function () {
        $scope.targetId = 'main-content';
        var anchor = compile('<a nd-scroll-focus="{{targetId}}">Go to main content</a>');
        anchor.triggerHandler('click');
        expect($anchorScroll).toHaveBeenCalledWith('main-content');
        expect($document.activeElement.id).toBe('main-content');
        expect($location.hash).toHaveBeenCalledWith('main-content');
    });

    it('allows target id to have # prefix', function () {
        var anchor = compile('<a nd-scroll-focus="#main-content">Go to main content</a>');
        anchor.triggerHandler('click');
        expect($anchorScroll).toHaveBeenCalledWith('main-content');
        expect($document.activeElement.id).toBe('main-content');
        expect($location.hash).toHaveBeenCalledWith('main-content');
    });

});