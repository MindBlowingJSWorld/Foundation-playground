Components
===================================

https://smacss.com/book/type-module

Components are the reusable, modular parts of our design. They are the callouts,
the sidebar sections, the product lists and so on.

Please use classnames for attribute selectors as much as possible. See README
in parent folder for more information on naming conventions.
