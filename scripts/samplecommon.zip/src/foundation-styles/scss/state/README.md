State rules
===================================

https://smacss.com/book/type-state

State rules are ways to describe how our modules or layouts will look when in
a particular state. Is it hidden or expanded? Is it active or inactive? They
are about describing how a module or layout looks on screens that are smaller
or bigger. They are also about describing how a module might look in different
views like the home page or the inside page.

Classname selectors usually would be .is-expanded or .is-active.

Minor state change styles (e.g. link color on hover) should be included in the
same partial with the styles relating to the component's default state, only
add them here as separate partials if it is a very large block of code that
would make the default component partial harder to read.