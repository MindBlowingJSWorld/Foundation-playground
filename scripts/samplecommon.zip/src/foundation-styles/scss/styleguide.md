<a href="../../index.html">Go back to Common-UI</a>

# Breaking changes to foundation styles!

If you were using any of the below components or classnames (and variations of them, such as ```--large```, you need to update your markup. Check the relevant styleguide page for details on updated usage.

* ```.button-group```, ```.button-group--large```
* ```.button-multiselect```
    * ```.button-group``` was removed from previous version of ```.button-group``` as previous Nordea ```.button-group``` made no use of the additional markup Foundation provides for this class.
    * Foundation's markup is similar to our markup for ```.button-multiselect```, please ADD the ```.button-group``` classname to achieve the visual style for ```.button-multiselect```.
    * ```.button-multiselect``` will take care of only the checkbox trickery in the future.
* ```.toast```
    * ```.toast``` was renamed. See ```.callout``` and ```.notification```.
* ```.button--primary```, ```.button--secondary```, ```.button--large```
    * BEM synonyms for classes that are already defined by Foundation will be removed, except in cases where stated otherwise. If you still need them, you can use the ```nordea-modifier-synonyms()``` mixin for now.

Reasoning - We could have continued using a lot of @extends to synchronise the terminology in the UI specs with Foundation terminology, as we were doing, but it was starting to get messy and confusing and the naming collisions were problematic.
<em>If this change causes a problem for you or if you have feedback, questions or complaints about these changes, please contact HH Navigation & Overview, Liisa Duerig-Laitinen.</em>

Other

* `_nordea_sttings.scss`: relative paths to Foundation for Sites and Motion UI scss files converted to file names. You are using this file in your SASS build process, you must
    1. Include npm packages foundation-sites version 6.2.0 and motion-ui 1.2.0 in your build.
    1. Include the following in your gulp-sass plugin's settings: `includePaths: ['node_modules/foundation-sites/scss', 'node_modules/motion-ui/src']`.
* ```.active```/```.is-active```, ```.selected```/```.is-selected```, etc.
    * Inconsistencies have been found and corrected to ```.is-active``` and ```.is-selected.``` In the future, we have decided to use ```.is-state``` to demonstrate that the classname is toggled dynamically.

<hr>

# Javascript

Some of the components in this framework require javascript libararies. You need to include the following in this order:

* jQuery
* <a href="https://www.npmjs.com/package/what-input">what-input</a>
* The `dbw-foundation-nordea.js` bundle distributed with this package
* Initialize your page by executing script `$(document).foundation()`

# Naming conventions

Let's use a button element as an example.

When available, we use Foundation's default markup classes, which will apply Foundation styles according to our settings:

    <button type="button" class="primary button">Primary button</button>

Existing Foundation setting variables in `vendor/foundation` can be changed, but do not add new ones.

If Foundation's default button element requires additional styling that cannot be achieved by just changing a variable value, add partials using BEM naming standards where it makes sense.

1. .the-component              // scss/components/_button.scss
2. .the-component--modifier    // scss/components/_button--primary.scss
3. .the-component__an-element  // scss/components/_button__image.scss
4. .the-component--modifier__an-element    // scss/components/_button--primary__image.scss
5. .the-component.is-state     // scss/state/_button.is-disabled.scss
6. .the-skin .the-component    // scss/theme/_premier-customer--button.scss

The name of the partial should match the classname and selector, to make it easier to immediately identify the
purpose of a partial.

Do not go too crazy, semantic naming should be used when it makes sense in a block context.

## Examples

We need additional styles for all buttons (Block)

* Markup: `<button type="button" class="primary button">Primary button</button>`
* Partial: `components/_button.scss`
* CSS selector: `.button` should be sufficient. If it is not, check Foundation's CSS selector for what you are trying to change and consider if the needed styles actually belong to a wrapper or child element.

We need additional styles for primary buttons.

* Markup: `<button type="button" class="button button--primary">Primary button</button>`
* Partial: `components/_button--primary.scss`
* CSS selector: `.button--primary` or `.button.button--primary`, if additional classname is needed.

We need a third style of button that should still use `.button` defaults but Foundation only offers two `.button` styles.

* Markup: `<button type="button" class="button button--tertiary">Tertiary button</button>`
* Partial: `components/_button--tertiary.scss`
* CSS selector: `.button--tertiary`
