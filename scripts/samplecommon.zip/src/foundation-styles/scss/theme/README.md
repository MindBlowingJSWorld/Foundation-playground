Theme rules
===================================

https://smacss.com/book/type-theme

Theme rules are similar to state rules in that they describe how modules or
layouts might look. Most sites don’t require a layer of theming but it is good
to be aware of it.

This directory is for variations of basic elements, perhaps if you have a
section of your website that should display a different in a different context.