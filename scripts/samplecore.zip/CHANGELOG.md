## Changelog of important changes

<a name="0.3.3"></a>
### 0.3.3 (2016-05-19)
* All /api/dbf/ urls will now get token without requiring url mapping

<a name="0.3.2"></a>
### 0.3.2 (2016-05-19)

* Refactored project with new tooling 
* Removed X-ServiceContext
* Added refreshToken parameter to SessionService.login 

<a name="0.3.1"></a>
### 0.3.1 (2016-05-15)

* TestTokenService is now using the new version of the JWT token

<a name="0.2.57"></a>
### 0.2.57 (2016-05-10)

* UserService added with dummy data

<a name="0.2.54"></a>
### 0.2.54 (2016-05-02)

* Settings service added

<a name="0.2.52"></a>
### 0.2.52 (2016-05-01)

* Idle Session detection and logout. to-do token reneval
 
<a name="0.2.47"></a>
### 0.2.47 (2016-04-22)
 
* Log out when the token is invalid/expired

 




