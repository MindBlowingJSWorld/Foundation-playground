# Core Module - dbw-core

This module contains parts that are common to all feature modules.

This is NOT a utility module.
No UI parts are expected here, they are found in the common -module.

The individual components are documented in the readme in their own folders. 

This module is maintained by Navigation & Overview.