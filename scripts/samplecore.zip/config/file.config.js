/**
 * Build process configuration file/module
 * */

module.exports = {
    vendor_js: [
        'node_modules/dbw-vendor/dist/vendor.js',
        'node_modules/dbw-common/build/dbw-foundation-nordea.js'
        //'infinity/webtrends/loader.js'
    ],
    app_js_demo: [
        'src/app/**/*.js',
        '!src/app/**/*.mock.js',
        '!src/app/**/*.spec.js'
    ],
    app_js_dist: [
        'dist/*.js',
        '!dist/*.min.js'
    ],
    mock_app_js: [
        'src/app/**/*.js',
        'src/app/**/*.mock.js',
        '!src/app/**/*.spec.js'
    ],
    css_demo: [
        'node_modules/dbw-vendor/dist/vendor.css',
        'node_modules/dbw-common/build/dbw-foundation-nordea.css',
        'node_modules/dbw-common/build/dbw-common.css',
        'demo/*.css'
    ],
    css_dist: [
        'node_modules/dbw-vendor/dist/vendor.css',
        'node_modules/dbw-common/build/dbw-foundation-nordea.css',
        'node_modules/dbw-common/build/dbw-common.css',
        'dist/*.css',
        '!dist/*.min.css'
    ],
    test_js: [
        // mocks
        'node_modules/dbw-vendor/dist/vendorMocks.js',
        // sources
        'src/app/**/*.js',
        // specs
        'src/app/**/*.spec.js'
    ],
    test_templates: [
        // templates
        'src/app/**/*.tpl.html'
    ],
    test_release_js: [
        // mocks
        'node_modules/dbw-vendor/dist/vendorMocks.js',
        // dist
        'dist/*.js',
        // specs
        'src/**/*.spec.js'
    ],
    ignore_paths_demo: ['demo', 'src/app', 'node_modules', 'infinity'],
    ignore_paths_dist: ['dist', 'node_modules']
};
