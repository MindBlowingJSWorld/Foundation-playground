'use strict';

var gulp = require('gulp');
var $ = require('gulp-load-plugins')();
var argv = require('yargs').argv;

var demo_dirs = ['src/app', 'demo', 'node_modules'];
var dist_dirs = ['dist', 'node_modules'];
var livereload_port = argv.lp || 35728; // Default is 35729 but we keep it as default port for main app
var server_port = argv.p || 9000;

gulp.task('webserver', function() {
    return gulp.src(dist_dirs)
        .pipe($.webserver({
            port: server_port,
            livereload: {
                enable: true,
                port: livereload_port
            },
            proxies: [
                { source: '/api/dbf/', target: 'http://ap-rbo1s:82/api/dbf/' }
            ]
        }));
});

gulp.task('webserver-demo', function() {
    return gulp.src(demo_dirs)
        .pipe($.webserver({
            port: server_port,
            livereload: {
                enable: true,
                port: livereload_port
            },
            proxies: [
                { source: '/api/dbf/', target: 'http://ap-rbo1s:82/api/dbf/' }
            ]
        }));
});
