'use strict';

/**
 * This is the Core Module handling all aspects to the session and other central non-ui things
 */
angular.module('dbw-core', ['dbw-core.config', 'dbw-core.session', 'dbw-core.idle', 'ui.router', 'ngResource']);
