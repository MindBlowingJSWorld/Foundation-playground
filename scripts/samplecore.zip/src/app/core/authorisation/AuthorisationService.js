'use strict';

/**
 * Core Authorisation Service for both
 */
angular.module('dbw-core')
    .service('AuthorisationService', AuthorisationService);

/* @ngInject */
function AuthorisationService($state, SessionService) {
    var service = {
        isAuthorisedToState: function (state) {
            if (state.public || _.startsWith(state.name, 'common') || _.startsWith(state.name, 'start')) {
                return true;
            } else if (!_.startsWith(state.name, SessionService.style())) {
                return false;//Never navigate between corporate and household
            } else {
                return true; //todo - check
            }
        },
        isAuthorisedToFeature: function (/*feature*/) {
            return true;//todo
        },
        resume: function (start) {
            var savedState = SessionService.pullState();
            if (savedState) {
                $state.go(savedState.toState, savedState.toParams);
            } else {
                $state.go(start);
            }
            SessionService.pushState(null, null);
        }
    };
    return service;
}

