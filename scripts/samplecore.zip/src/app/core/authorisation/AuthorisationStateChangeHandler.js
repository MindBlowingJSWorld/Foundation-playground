'use strict';

/**
 * This handler does the following checks before alloving navigation to a state:
 * check that authentication exists - unless it is a public state
 * check that the session has the needed autorisation
 */
angular.module('dbw-core')
    .run(['$log', '$rootScope', '$state', 'SessionService', 'AuthorisationService', 'Configuration', function ($log, $rootScope, $state, sessionService, autorisationService, Configuration) {
        if (Configuration.standalone !== true) {
            $rootScope.$on('$stateChangeStart', function (event, toState, toParams/*, fromState, fromParams, options*/) {
                if (toState.name === 'login') {
                    sessionService.logout();
                } else if (toState.name === 'logout') {
                    sessionService.logout();
                    $state.go('login');
                } else if (toState.public === true) {
                    //$log.info('DBW: Navigation to ' + toState.name + ' allowed - public');
                } else if (!sessionService.isAuthenticated()) {
                    $log.info('DBW: Session not valid, redirecting to login. State pushed for later ' + toState.name);
                    event.preventDefault();
                    sessionService.pushState(toState, toParams);
                    $state.go('login');
                } else if (!autorisationService.isAuthorisedToState(toState)) {
                    $log.info('DBW: Navigation not authorised ' + toState.name);
                    event.preventDefault();
                    $state.go('common.noaccess');
                } else {
                    //$log.info('DBW: Navigation to ' + toState.name + ' allowed');
                }
            });
        }
    }]);
