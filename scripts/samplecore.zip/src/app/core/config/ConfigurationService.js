'use strict';

//config needs its own module for unit testing to work with injected RunctimeConfiguration
angular.module('dbw-core.config', []);
angular.module('dbw-core.config')
    .service('Configuration', Configuration);

/* @ngInject */
function Configuration($injector, $log) {
    var defaultConfig = {
        standalone: false,
        environment: 'DEV',
        application: 'ROSME',
        channel: 'NETBANK',
        logging: {
            debug: false,
            serverURL: '/log',
            sendType: 'none', // Alternatives: 'none', 'jQuery' and 'XHR' (not implemented)
            contentType: 'application/json; charset=UTF-8',
            sendToServer: {
                debug: false,
                info: false,
                warn: true,
                error: true
            },
            writeToConsole: {
                debug: false,
                info: false,
                warn: true,
                error: true
            }
        },
        session: {
            idle: 300,
            timeout: 60
        },
        tracking: {
            dcsid: ''
        },
        dbf: {
            endpoint: '',
            baseurl: ''
        },
        urls: []
    };
    var runtimeConfiguration;
    try {
        runtimeConfiguration = $injector.get('RuntimeConfiguration');
    } catch (e) {
        $log.warn('No RuntimeConfiguration');
    }

    var config = angular.extend({}, defaultConfig, runtimeConfiguration);
    if (config.logging.debug) {
        $log.info('RuntimeConfiguration loaded', config);
    }
    return config;
}
