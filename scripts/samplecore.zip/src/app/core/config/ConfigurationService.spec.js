/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('Configuration', function () {
    var configuration;

    var runtimeConfig = {
        logging: {
            debug: true
        }
    };

    describe('override default logging debug', function () {
        beforeEach(module('dbw-core.config', function ($provide) {

            var MockRuntimeConfiguration = function() {
                return runtimeConfig;
            };

            $provide.service('RuntimeConfiguration', MockRuntimeConfiguration);
        }));
        beforeEach(inject(function (Configuration) {
            configuration = Configuration;
        }));
        it('debug to be false', function () {
            expect(configuration.logging.debug).toBeTruthy();
        });
    });
});

