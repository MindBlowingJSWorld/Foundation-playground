# Configuration

The _Configuration_ is a constant that can be injected into any service or controller. It offers system wide
configuration that can be specified for different environments.

### Usage

You can use _Configuration_ by injecting it into your service/controller:

    angular.module('myModule').controller(['Configuration'], function(runtimeConfig) {
        console.log('The system is in debug mode:', runtimeConfig.debug);
    });
    
You can create new properties into the system-wide config by editing the .json -files that are located in the 
main-module. There is one config-file for each environment.

The build-process  of the main-module injects the configuration in the .json -file into the .js file. This way we can 
configure the system from outside of the codebase and at the same time avoid complicated bootstrap-issues that arise 
if the config-file is loaded asynchronously.
