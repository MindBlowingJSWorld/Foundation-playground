'use strict';

// Configurations for error handling
// $exceptionHandler does not need to be configured, since we have already decorated $log to send errors.
//@todo: If async exceptions should show a notification to the user, we need to modify the $exceptionHandler
/*
angular.module('dbw-common')
  .config(function ($httpProvider) {
    $httpProvider.interceptors.push(function($injector) {
      return {
        responseError: function (response) {
          //injected manually (at runtime) to get around the ability to create services during config
          return $injector.get('ErrorService').handleServerError(response);
        }
      };
    });
  })
  .config(function($stateProvider) {
    $stateProvider
      .state('generalError', {
        url: '/error',
        template: '<h1>Oops! Something went wrong!</h1>'
        // @todo: define correct url & template when these are available
      })
      .state('pageNotFound', {
        url: '/pageNotFound',
        template: '<h1>Oops! The page you are looking for was not found!</h1>'
        // @todo: define correct url & template when these are available
      });
  })
  .run(function($state, $rootScope, $log) {
    $rootScope.$on('$stateChangeError', function(event, toState, toParams, fromState, fromParams, error) {
      event.preventDefault();
      $log.error('Error changing state from %s to %s with', fromState, toState, fromParams, toParams, error);
      $state.go('generalError', JSON.stringify(error)); // error has data, status and config properties
    });
  })
  .run(function ($window, $log) {
    // General script errors
    angular.element($window).on('error', function (e) {
      $log.error('script error', e.originalEvent);
    });
});
*/
