'use strict';

angular.module('dbw-core')
    .factory('ErrorService', ErrorService);

/* @ngInject */
function ErrorService($q, $log, NotificationService, $state) {

    function isResolved(promise) {
        return promise.$$state.status === 1;
    }

    function isTimeout(response) {
        var config = response.config;
        return config && config.timeout ? isResolved(config.timeout) : false;
    }

    function getUrl(serverResponse) {
        return serverResponse.config.url;
    }

    function timeoutOrUnauthorized(serverResponse) {
        return serverResponse.status === 0 || serverResponse.status === 401 || serverResponse.status === 403;
    }

    function isNotFound(serverResponse) {
        return serverResponse.status === 404;
    }

    function isInternalError(serverResponse) {
        return serverResponse.status === 500;
    }

    return {
        /**
         * A function that handles server errors sent by the http interceptor
         * @param serverResponse
         * @returns {Promise}
         */
        handleServerError: function (serverResponse) {

            if (isTimeout(serverResponse)) {
                serverResponse.data = {message: 'The request url timed out'};
                $log.error('The request url "%s" timed out', getUrl(serverResponse));
            }
            if (timeoutOrUnauthorized(serverResponse)) {
                // Is this already handled in dbw-core?
                $state.go('logout', {reason: 'unauthorized'});
                /* @todo: modify once NotificationService is ready */
                NotificationService.showTopNotification({
                    type: 'error',
                    text: 'Your session timed out. Please login again.'
                });
            }
            if (isNotFound(serverResponse)) {
                $log.error('Page was not found.', serverResponse);
                $state.go('pageNotFound', {reason: 'unauthorized'});
            }
            if (isInternalError(serverResponse)) {
                $log.error('Server returned Internal error (500).', serverResponse);
                // @todo: logging can be done here, but should the notification to the user be taken care of
                // in the feature? Otherwise we might have multiple erro notifications.
                NotificationService.showTopNotification({
                    type: 'error',
                    text: 'Something went wrong. Please try again.'
                });
                // Assume that 500 is temporary, and do not interrupt the state-flow
                //$state.go('generalerror', {reason: 'internal error'});
            }
            return $q.reject(serverResponse);
        }
    };
}
