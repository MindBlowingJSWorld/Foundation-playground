/*eslint-env jasmine */
/*global module:false, inject:false */
/*
'use strict';

describe('ErrorService', function () {
    var mockedState = {
        go: function (stateName) {
            angular.noop(stateName);
            //console.log(stateName);
        }
    };
    var notificationService;

    beforeEach(module('dbw-core'));

    beforeEach(module(function ($provide) {
        $provide.value('$state', mockedState);
    }));

    /!*@todo: complete test when NotificationService is coded*!/
    beforeEach(inject(function (_NotificationService_) {
        notificationService = _NotificationService_;
    }));

    it('should return a rejected promise when called', inject(function (ErrorService) {
        var response = ErrorService.handleServerError({status: 500, config: {url: ''}});
        expect(response.$$state.status).toBe(2);
    }));

    it('should handle timeouts', inject(function (ErrorService, $q) {
        var resolvedTimeoutPromise = $q.defer();
        resolvedTimeoutPromise.resolve('timed out');

        var serverResponse = {
            status: 0,
            config: {
                url: 'http://dummyUrl',
                timeout: resolvedTimeoutPromise.promise
            }
        };
        ErrorService.handleServerError(serverResponse);
    }));

    it('should logout when unauthorized', inject(function (ErrorService) {
        spyOn(mockedState, 'go');
        ErrorService.handleServerError({status: 401,  config: {url: 'http://dummyUrl'}});
        expect(mockedState.go).toHaveBeenCalledWith('logout', {reason: 'unauthorized'});
    }));

    /!* @todo: complete test when NotificationService is ready *!/
    it('should add warning notification if response data available', inject(function (ErrorService) {
        var warningNotification = {
            type: 'error',
            text: 'Your session timed out. Please login again.'
        };

        spyOn(notificationService, 'showTopNotification');
        ErrorService.handleServerError({status: 401, config: {url: 'http://dummyUrl'}, data:{code: 'HTTP 401 Unauthorized'}});
        expect(notificationService.showTopNotification).toHaveBeenCalledWith(warningNotification);
    }));

});

*/
