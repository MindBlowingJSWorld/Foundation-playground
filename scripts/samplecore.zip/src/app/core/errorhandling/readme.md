  
# Error handling

### Logging errors
The $log -service is set up so that errors are transferred to the server. To use this as 
a developer all you need to do is use $log.error() or $log.warn().

If you need to throw a new error, **ALWAYS** use an exception (never a string):

    throw new Error('not found')  // Correct
    throw 'not found'             // Wrong
    
Otherwise stacktraces are not preserved.


### Handling exceptions
The Angular $exceptionHandler catches all exceptions that are thrown within Angular services or controllers. The 
$exceptionHandler uses $log to log the error to the console and then rethrows the error. In DBW this will also cause
the error to be logged to the server. So you as a developer should NOT log the exception again.

### Exceptions in asynchronous methods
If an asynchronous method throws an exception, the promise chain will be broken. In other words, write all your code
within try/catch blocks if there is any chance of errors. As promises are resolved/rejected in the angular $digest -loop, 
any runtime expceptions thrown in async -code will "disappear". They will only be caught by the $exceptionHandler 
and logged. Any users of your async function will never know that something went wrong as the promise is never resolved.

Example:

    return aFuncReturningAPromise().then(function(data) {
        var name = data.propertyThatDoesNotExist.name;  // throws TypeError which "disappears" and is caught by the $exceptionHandler and then logged.
        // promise is not resolved, caller is never notified.
    });
 
### HTTP errors
HTTP calls that fail with a 500 or 404 code are automatically logged through the $httpInterceptor. 500 errors are 
currently passed on to the calling method. 404 codes are redirected to a general PageNotFound-message.
HTTP calls that fail with 401 or 403 are caught and redirected to login.

### ErrorHandling module
The ErrorHandling module configures the global error handling, for the following parts:

 - HTTP errors (request timed out, 401, 404, 500) intercepted and handled in ErrorService
 - $stateChangeError
 - Common error pages (states "generalError" and "pageNotFound")
 - Script errors on the page (3rd party libraries)