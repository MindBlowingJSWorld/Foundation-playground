'use strict';

angular.module('dbw-core')
    .provider('foundationResource', FoundationResource);

/* @ngInject */
function FoundationResource() {
    this.$get = ['$resource', 'Configuration', function ($resource, Configuration) {
        return {
            /**
             * Returns the wrapped $resource factory
             * @param path the resource path
             * @param defaultParameters
             * @param actions own defined actions
             * @returns {*}
             */
            getResource: function (path, defaultParameters, actions) {
                var endPoint = Configuration.dbf.endpoint;
                return $resource(endPoint + this.getFullPath(path), _.defaults({}, defaultParameters), actions);
            },
            /**
             * Returns the concatenated endPoint address + the given resource path
             * If the path starts with the same endPoint address, that will be returned instead of adding it on again.
             * @param path
             * @returns {*}
             */
            getFullPath: function (path) {
                var baseUrl = Configuration.dbf.baseurl;
                if (_.startsWith(path, baseUrl)) {
                    return path;
                } else {
                    return baseUrl + path;
                }
            }
        };
    }];
}


