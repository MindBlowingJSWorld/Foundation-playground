/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('foundationResource', function () {

    var mockedResource;

    beforeEach(module('dbw-core.config', function ($provide) {
        //Set runtime configuration
        var MockRuntimeConfiguration = function () {
            return {
                'dbf' : {
                    endpoint:'http://dbf.test',
                    baseurl:'/foundation/api'
                }
            };
        };

        $provide.service('RuntimeConfiguration', MockRuntimeConfiguration);

    }));


    beforeEach(module('dbw-core'));

    beforeEach(module(function (foundationResourceProvider, $provide) {
        mockedResource = jasmine.createSpy();
        $provide.value('$resource', mockedResource);
    }));

    it('should get full path when leaving out the end point', inject(function (foundationResource) {
        expect(foundationResource.getFullPath('/accounts')).toEqual('/foundation/api/accounts');
    }));

    it('should get full path if supplied with end point', inject(function (foundationResource) {
        expect(foundationResource.getFullPath('/foundation/api/accounts')).toEqual('/foundation/api/accounts');
    }));

    it('$resource should be called with full path', inject(function (foundationResource) {
        //when
        foundationResource.getResource('/accounts');
        //then
        expect(mockedResource).toHaveBeenCalledWith('http://dbf.test/foundation/api/accounts', {}, undefined);
    }));

    it('$resource should be called with full path including default params', inject(function (foundationResource) {
        //when
        foundationResource.getResource('/accounts', {max: 10});
        //then
        expect(mockedResource).toHaveBeenCalledWith('http://dbf.test/foundation/api/accounts', {max: 10}, undefined);
    }));

    it('$resource should be called with actions', inject(function (foundationResource) {
        //given
        var actions = {
            login: {method: 'POST', url: foundationResource.getFullPath('/login')}
        };
        //when
        foundationResource.getResource('/login', {}, actions);
        //then
        expect(mockedResource).toHaveBeenCalledWith('http://dbf.test/foundation/api/login', {}, actions);
    }));


});

