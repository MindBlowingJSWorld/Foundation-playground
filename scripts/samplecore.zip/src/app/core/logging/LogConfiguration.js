/*global $:false */
'use strict';

angular.module('dbw-core')
    .service('LogConfiguration', LogConfiguration);

/* @ngInject */
function LogConfiguration(Configuration) {
    var config = Configuration.logging;

    function formatLogEntry(data) {
        // @todo 1. Should we clean the data to make sure it does not contain user sensitive information?
        // @todo 2. The data is now formatted as an array for util.format()
        //  Example: ['This is run %d of data', 1, {test:'1'}]
        //  Should we convert it to a string or send it as is?

        var logEntry = {
            message: data,
            //currentURL: $location.absUrl(),  // Is this needed?
            requestId: '',  // service TBD
            sessionId: '' // service TBD
        };
        // Timestamp is added serverside as well as user-agent @todo: verify this
        return logEntry;
    }

    function shouldWriteToConsole(level) {
        var _shouldWriteToConsole = config && config.writeToConsole[level];
        return _shouldWriteToConsole !== undefined && _shouldWriteToConsole === true;
    }

    function shouldSendToServer(level) {
        var _shouldSendToServer = config && config.sendToServer[level];
        return _shouldSendToServer !== undefined && _shouldSendToServer === true;
    }

    /**
     * The angular $http service cannot be used in the $log decorator because it will cause a circular
     * dependency. To overcome this we should use jQuery.ajax() or XHR
     */
    function sendLogToServer(logEntry) {
        switch (config.sendType) {
            case 'jQuery' :
                $.ajax({
                    type: 'POST',
                    url: config && config.serverURL,
                    contentType: config.contentType,
                    data: JSON.stringify({
                        message: JSON.stringify(logEntry)
                    })
                });
                break;
            case 'XHR':
                console.error('XHR transfer not implemented');
                break;
            case 'none':
                if (config.debug) {
                    console.log('Simulating logging to server:', logEntry);
                }
                break;
            default:
                break;
        }
    }


    return {
        shouldSendToServer: shouldSendToServer,
        formatLogEntry: formatLogEntry,
        sendLogToServer: sendLogToServer,
        shouldWriteToConsole: shouldWriteToConsole
    };
}






