/*eslint-env jasmine */
/*global module:false, inject:false $:false */
'use strict';

describe('LogConfiguration', function () {
    var service;
    var configuration;

    var runTimeConfig = {
        'logging': {
            'debug': true,
            'serverURL': 'testURL',
            'sendToServer': {
                'debug': false,
                'info': false,
                'warn': false,
                'error': false
            },
            'writeToConsole': {
                'debug': false,
                'info': false,
                'warn': false,
                'error': false
            }
        }
    };

    describe('configure all levels NOT to send', function () {
        beforeEach(module('dbw-core.config', function ($provide) {
            var MockRuntimeConfiguration = function () {
                return runTimeConfig;
            };

            $provide.service('RuntimeConfiguration', MockRuntimeConfiguration);

        }));
        beforeEach(module('dbw-core'));
        beforeEach(inject(function (Configuration, LogConfiguration) {
            configuration = Configuration;
            service = LogConfiguration;
        }));
        it('debug to be false', function () {
            expect(runTimeConfig.logging.debug).toBeTruthy();
            expect(configuration.logging.debug).toBeTruthy();
        });

        it('shouldSendToServer should work', function () {
            expect(service.shouldSendToServer('debug')).toBeFalsy();
            expect(service.shouldSendToServer('info')).toBeFalsy();
            expect(service.shouldSendToServer('warn')).toBeFalsy();
            expect(service.shouldSendToServer('error')).toBeFalsy();
        });
        it('shouldWriteToConsole should work', function () {
            expect(service.shouldWriteToConsole('debug')).toBeFalsy();
            expect(service.shouldWriteToConsole('info')).toBeFalsy();
            expect(service.shouldWriteToConsole('warn')).toBeFalsy();
            expect(service.shouldWriteToConsole('error')).toBeFalsy();
        });
        it('sendLogToServer should not send', function () {
            spyOn($, 'ajax');
            service.sendLogToServer('test');
            expect($.ajax).not.toHaveBeenCalled();
        });
        it('formatLogEntry should work', function () {
            // For now we don't know what we should log, so just check that the method works
            // @todo add tests according to the logging requirements
            var result = service.formatLogEntry('test1');
            expect(result.message).toEqual('test1');
        });
    });

    describe('configure all levels to send', function () {
        beforeEach(module('dbw-core.config', function ($provide) {
            var MockRuntimeConfiguration = function () {
                var allLevelToSendLogConfig = {
                    'logging': {
                        sendType: 'jQuery',
                        serverURL : 'testURL',
                        'writeToConsole': {
                            'debug': true,
                            'info': true,
                            'warn': true,
                            'error': true
                        },
                        'sendToServer': {
                            'debug': true,
                            'info': true,
                            'warn': true,
                            'error': true
                        }
                    }
                };
                return allLevelToSendLogConfig;
            };

            $provide.service('RuntimeConfiguration', MockRuntimeConfiguration);

        }));

        beforeEach(module('dbw-core'));

        beforeEach(inject(function (LogConfiguration) {
            service = LogConfiguration;
        }));

        it('shouldSendToServer should work', function () {
            expect(service.shouldSendToServer('debug')).toBeTruthy();
            expect(service.shouldSendToServer('info')).toBeTruthy();
            expect(service.shouldSendToServer('warn')).toBeTruthy();
            expect(service.shouldSendToServer('error')).toBeTruthy();
        });
        it('shouldWriteToConsole should work', function () {
            expect(service.shouldWriteToConsole('debug')).toBeTruthy();
            expect(service.shouldWriteToConsole('info')).toBeTruthy();
            expect(service.shouldWriteToConsole('warn')).toBeTruthy();
            expect(service.shouldWriteToConsole('error')).toBeTruthy();
        });
        it('sendLogToServer should still send', function () {
            spyOn($, 'ajax');
            service.sendLogToServer('test');
            expect($.ajax).toHaveBeenCalled();

            var args = $.ajax.calls.argsFor(0);
            expect(args[0].type).toEqual('POST');
            expect(args[0].url).toEqual('testURL');
            expect(args[0].contentType).toEqual(service.contentType);
        });
    });
});

