# Logging

The logging module in `dbw-common` wraps the Angular `$log` service to provide more granular control of the 
logging and to enable the logs to be sent to a server for analysis and support.
 
### Usage

You use the logging module in the same way as you use the normal Angular `$log` service. No specific changes are 
needed to your code. Just inject `$log` and use it:

```js
        angular.module('myModule').controller(['$log'], function($log) {
            $log.debug('My oh my, what a glorious day!');
        });
```
 
 
_Ps._
  `$log.log()` _is not wrapped so please do not use that_

  
### Writing log-statements

Since `$log.debug()` can be completely switched off, you as a developer can freely use it. In the production build, 
`$log.debug()` will not print anything to the console.

Please feel free to use `$log.info()` to indicate essential user actions/notifications. We can log those to the 
server but switch them off in production.

`$log.warn()` should be used for problems in the application that are recoverable - ie. the user did something weird 
but we can still continue.

`$log.error()` should be used for problems in the application that can not be recovered from, such as bad data sent
from the server (yes, that does happen). 
However note that infrastructure errors such as network failures are automatically logged in the /errorHandling -module, 
so please do not log those for a second time.

Avoid using `console.log`.

### Configuration

The logging is configured in two places.

**Configuration .json**

The following properties can be set in the system-wide configuration files that can be set for different environments:

```js
    "logging" : {
      "serverURL" : "",
      "sendToServer":{
        "debug":false,
        "info":false,
        "warn":false,
        "error":false
      },
      "writeToConsole":{
        "debug":true,
        "info":true,
        "warn":true,
        "error":true
      }
    }  
```   

**config() block of LogConfigurationProvider**

The following properties can be set in the .config() block of the `dbw-common` -module:

```js
     sendType : 'none', // Alternatives: 'none', 'jQuery' and 'XHR' (not implemented)
     contentType : 'application/json; charset=UTF-8',
     debug : false  // if sendType === none && debug === true, will simulate the server logging by doing a console.log() 
```  
