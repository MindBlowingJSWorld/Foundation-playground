/*global moment:false */
'use strict';

angular.module('dbw-core').service('NonBankingDaysService', NonBankingDaysServiceFactory);

/* @ngInject */
function NonBankingDaysServiceFactory($resource) {
    return new NonBankingDaysService($resource);
}

function NonBankingDaysService($resource) {
    this._$resource = $resource;
}

NonBankingDaysService.prototype.getNonBankingDays = function (from, to) {
    var headers = {};
    if (moment(from, 'YYYY-MM-DD', true).isValid()) {
        headers['X-Since'] = from;
    }
    if (moment(to, 'YYYY-MM-DD', true).isValid()) {
        headers['X-Until'] = to;
    }

    return this._$resource('/utilities/bankdays', {}, headers).query().$promise;
};

