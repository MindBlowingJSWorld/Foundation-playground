'use strict';

/**
 * This service controls the state of the session
 * TODO: session timeout, token reneval, broadcast session updates..
 */
angular.module('dbw-core')
    .service('coreDBFHandler', CoreDBFHandler)
    .config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push('coreDBFHandler');
    }]);

/* @ngInject */
function CoreDBFHandler($q, $log, $injector, Configuration) {
    var dbfHandler = {
        request: function (config) {
            var session = $injector.get('SessionService');
            var map = Configuration.urls;
            var dbf = false;
            var url = config.url;
            if(!_.startsWith(url,'/')) {
                url = '/' + url;
            }
            for(var x in map) {
                if(_.startsWith(url, map[x].url) && (map[x].country === undefined || map[x].country === session.country())) {
                    var target = url.replace(map[x].url, map[x].target);
                    $log.info('Mapping ' + url + ' to ' + target);
                    config.url = target;
                    dbf = true;
                    break;
                }
            }
            if(_.startsWith(config.url,'/api/dbf/')) {
                dbf = true;
            }
            //$log.info('Injecting '+sessionService.token()+ ' '+config)
            //Only send token on dbf services - identified as being mapped
            if (dbf && session.isAuthenticated()) {
                config.headers['Authorization'] = 'Bearer ' + session.token();
                //todo - replace with X-requestId ?? next dbf version
            }
            return config;
        },
        responseError: function (responseError) {
            if (responseError.status === 401 || responseError.status === 403) {
                var session = $injector.get('SessionService');
                if(session.isAuthenticated()) {
                    $log.warn('Session invalid/expired ');
                    session.logout();
                }
            } else {
                $log.error('Response error ', responseError);
            }
            return $q.reject(responseError);
        }
    };
    return dbfHandler;
}
