'use strict';

/**
 * This service controls the state of the session
 * TODO: session timeout, token reneval, broadcast session updates..
 *
 * Information contained in the SessionService:
 * locale :
 * token : JWT Token
 * style : navigation style (household, corporate)
 * pushed : saved state while logging in to support deep links
 */
angular.module('dbw-core.session', ['dbw-core.config', 'dbw-core.idle'])
    .constant('CoreConstants', {
        'BroadcastSessionUpdated': 'CoreSessionUpdated'
    })
    .run(function ($rootScope, $log, SessionService) {
        $rootScope.$on('IdleTimeout', function () {
            // the user has timed out (meaning idleDuration + timeout has passed without any activity)
            // this is where you'd log them
            $log.info('idle timeout, logging out');
            SessionService.logout();
        });
    })
    .service('SessionService', CoreSessionService);

/* @ngInject */
function CoreSessionService($rootScope, $log, $window, $injector, CoreConstants, TokenService, Idle) {
    var session = {};
    var pushed = null;

    var broadcastSessionUpdated = function () {
        $rootScope.$broadcast(CoreConstants.BroadcastSessionUpdated);
    };

    function isAuthenticated() {
        return session.token;
    }

    function login(style, token, refresh_token, expires_in) {
        session.style = style;
        session.token = token;
        session.refresh_token = refresh_token;
        session.expires_in = expires_in;
        Idle.watch(session.expires_in);
        broadcastSessionUpdated();
        try {
            $log.debug('DBW: Logged in with token that expires in: ' + TokenService.getTokenTimeout(token) + ' seconds ', TokenService.decodeToken(token));
        } catch (e) {
            $log.error(e);
        }
    }

    function logout() {
        if (isAuthenticated()) {
            session = {};
            try {
                $injector.get('$state').transitionTo('logout');
            } catch (e) {
                $log.info('logging out error ' + e);
            }
            Idle.unwatch();
            broadcastSessionUpdated();
        }
    }

    var service = {
        isAuthenticated: isAuthenticated,
        token: function () {
            return session.token;
        },
        style: function () {
            return session.style;
        },
        country: function () {
            return $window.COUNTRY;
        },
        login: login,
        logout: logout,
        listen: function (callback) {
            return $rootScope.$on(CoreConstants.BroadcastSessionUpdated, callback);
        },
        unlisten: function (callback) {
            $rootScope.$off(CoreConstants.BroadcastSessionUpdated, callback);
        },
        pushState: function (toState, toParams) {
            if (toState) {
                pushed = {};
                pushed.toState = toState;
                pushed.toParams = toParams;
                $log.debug('Will continue after login to state ' + pushed.toState.name);
            } else {
                pushed = null;
            }
        },
        pullState: function () {
            return pushed;
        }
    };
    return service;
}
