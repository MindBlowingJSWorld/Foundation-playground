/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('SessionService', function () {

    var service;
    var rootscope;
    var testToken = 'eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJkYmYiLCJhdWQiOlsib3NsIl0sImp0aSI6InRlc3QtMTQ2MDczMDA1MzM4NyIsImNsaWVudF9pZCI6IjE5NDAwODAxMDAxMSIsImNvdW50cnkiOiJTRSIsImFtIjoiQkFOS0lEIiwiYWwiOiJISUdIIiwiaWF0IjoxNDYxOTYxNjYxLCJleHAiOjE0NjE5NjE5NjEsImNoIjoiUkJPIiwiZ3JhbnRzIjp7ImFncmVlbWVudCI6MjE3MjMzMn19.GfJlDGUNI1gMGlg3nJ6sOsx1OTGk_9wCBxUadKSlwDjB43hpFzhhuXhAsI1G1duBLNUQ8j8pW7_pz3DTsfWZjICxtdjsigSpPq0hTZ391i7QwBsFOBCUTlkmTwITpdcoj2GZfvzYQJ0ffYQ6puKibOxjaeGV9O7gdzCdHBbFylMfAJPPcLGWCm26k5BHytj0BiUg3OKJGEiskCatvZJ2wb-T5diRxg5xG9JK2WlvIic_gHLpLHTPU0FJlUvzrTOi1v9vlwcMa6TsmfVMi2bJlHd4v73W14hf0vk7uOmh_yJNRPIuy9K-jgCo-Jkhir8uPvvobZxtJ1_i4NEDPWTJp_3nO-voyD8jpBFKqcUSvog0l-btfe2bfCue_-kBthWF-xSkoCEvzZpM2BR7zr3BQnkcceczowIDzYEyQiGKlZBvCyBH03UcA5hb0oROxpsxCmf1Y6XRNRoru2_CZJ35QoaPKCd3IEiilejWGYyYPlF7wfsWNnMwn2iNRGa6nekKyMT0Sc0wEaH3RLma9vja4vPXmH-y_5DTeb4C9vBxTkj6JoFkVESviE9wUfN5GNGhlt_xRYHCdZYdR0r0bZxBBeFf87x7pbBDTDoN2jJP4jLx55SYZPAHxjMc2X9Ts1AYbM67GJLAiAq2cPHhDPZxJBZyKQZst7DJLJ3_kI6wHb8';

    beforeEach(module('dbw-core'));

    beforeEach(
        inject(function (_SessionService_, _$rootScope_) {
            service = _SessionService_;
            rootscope = _$rootScope_;
        })
    );

    it('doing login and logout', inject(function () {
        var called = 0;
        var callback = function () {
            called++;
        };
        service.listen(callback);

        service.login('teststyle', testToken, testToken, 3000);
        expect(service.isAuthenticated()).toBeTruthy();
        expect(called).toEqual(1);
        expect(service.token()).toEqual(testToken);
        expect(service.style()).toEqual('teststyle');

        service.logout();
        expect(service.isAuthenticated()).toBeFalsy();
        expect(called).toEqual(2);
        expect(service.token()).toEqual();
        expect(service.style()).toEqual();
    }));

});

