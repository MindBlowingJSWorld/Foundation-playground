'use strict';

angular.module('dbw-core.idle', ['dbw-core.token-refresh', 'dbw-core.config'])
    .provider('Idle', IdleProvider);

/* @ngInject */
function IdleProvider() {
    this.$get = IdleGet;
}

/* @ngInject */
function IdleGet($interval, $rootScope, $document, TokenRefresh, $window, Configuration) {
    var options = {
        idle: 300, // in seconds (default is 15min)
        timeout: 60, // in seconds (default is 60sec)
        refresh: 60,
        refresh_advance:30,
        autoResume: 'idle', // lets events automatically resume (unsets idle state/resets warning)
        interrupt: 'mousemove keydown DOMMouseScroll mousewheel mousedown touchstart touchmove scroll',
        windowInterrupt: null,
        keepalive: true
    };

    var state = {
        idling: false,
        running: false,
        countdown: null,
        expiry: null
    };
    options.idle = Configuration.session.idle;
    options.timeout = Configuration.session.timeout;

    function startKeepalive() {
        if (!options.keepalive) {
            return;
        }
        if(options.refresh_advance > options.refresh) {
            options.refresh_advance = options.refresh / 2;
        }
        TokenRefresh.start(options.refresh - options.refresh_advance);
    }

    function stopKeepalive() {
        if (!options.keepalive) {
            return;
        }

        TokenRefresh.stop();
    }

    function toggleState() {
        state.idling = !state.idling;
        var name = state.idling ? 'IdleStart' : 'IdleEnd';

        if (state.idling) {
            $rootScope.$broadcast(name);
            stopKeepalive();
            if (options.timeout) {
                state.countdown = options.timeout;
                countdown();
                state.timeout = $interval(countdown, 1000, options.timeout, false);
            }
        } else {
            startKeepalive();
            $rootScope.$broadcast(name);
        }

        $interval.cancel(state.idle);
    }

    function countdown() {

        // check not called when no longer idling
        // possible with multiple tabs
        if (!state.idling) {
            return;
        }

        // countdown has expired, so signal timeout
        if (state.countdown <= 0) {
            timeout();
            return;
        }

        // countdown hasn't reached zero, so warn and decrement
        $rootScope.$broadcast('IdleWarn', state.countdown);
        state.countdown--;
    }

    function timeout() {
        stopKeepalive();
        $interval.cancel(state.idle);
        $interval.cancel(state.timeout);

        state.idling = true;
        state.running = false;
        state.countdown = 0;

        $rootScope.$broadcast('IdleTimeout');
    }

    function getExpiry() {
        return state.expiry;
    }

    function setExpiry(date) {
        if (!date) {
            state.expiry = null;
        }
        else {
            state.expiry = date;
        }
    }

    var svc = {
        _options: function () {
            return options;
        },
        _getNow: function () {
            return new Date();
        },
        isExpired: function () {
            var expiry = getExpiry();
            return expiry !== null && expiry <= this._getNow();
        },
        running: function () {
            return state.running;
        },
        idling: function () {
            return state.idling;
        },
        watch: function (token_expire_in) {
            if(token_expire_in) {
                options.refresh = token_expire_in;
            }
            $interval.cancel(state.idle);
            $interval.cancel(state.timeout);

            // calculate the absolute expiry date, as added insurance against a browser sleeping or paused in the background
            setExpiry(new Date(new Date().getTime() + ((options.idle + timeout) * 1000)));

            if (state.idling) {
                toggleState();
            } // clears the idle state if currently idling
            else if (!state.running) {
                startKeepalive();
            } // if about to run, start keep alive

            state.running = true;

            state.idle = $interval(toggleState, options.idle * 1000, 0, false);
        },
        unwatch: function () {
            $interval.cancel(state.idle);
            $interval.cancel(state.timeout);

            state.idling = false;
            state.running = false;
            setExpiry(null);

            stopKeepalive();
        },
        interrupt: function (anotherTab) {
            if (!state.running) {
                return;
            }

            if (options.timeout && this.isExpired()) {
                timeout();
                return;
            }

            // note: you can no longer auto resume once we exceed the expiry; you will reset state by calling watch() manually
            if (anotherTab || options.autoResume === 'idle' || (options.autoResume === 'notIdle' && !state.idling)) {
                this.watch(anotherTab);
            }
        }
    };

    var lastMove = {
        clientX: null,
        clientY: null,
        swap: function (event) {
            var last = {clientX: this.clientX, clientY: this.clientY};
            this.clientX = event.clientX;
            this.clientY = event.clientY;
            return last;
        },
        hasMoved: function (event) {
            var last = this.swap(event);
            if (this.clientX === null || event.movementX || event.movementY) {
                return true;
            }
            else if (last.clientX !== event.clientX || last.clientY !== event.clientY) {
                return true;
            }
            else {
                return false;
            }
        }
    };

    $document.find('html').on(options.interrupt, function (event) {
        if (event.type === 'mousemove' && event.originalEvent && event.originalEvent.movementX === 0 && event.originalEvent.movementY === 0) {
            return; // Fix for Chrome desktop notifications, triggering mousemove event.
        }

        if (event.type !== 'mousemove' || lastMove.hasMoved(event)) {
            svc.interrupt();
        }
    });

    if (options.windowInterrupt) {
        var eventList = options.windowInterrupt.split(' ');
        var fn = function () {
            svc.interrupt();
        };

        for (var i = 0; i < eventList.length; i++) {
            if ($window.addEventListener) {
                $window.addEventListener(eventList[i], fn, false);
            }
            else {
                $window.attachEvent(eventList[i], fn);
            }
        }
    }

    return svc;
}

