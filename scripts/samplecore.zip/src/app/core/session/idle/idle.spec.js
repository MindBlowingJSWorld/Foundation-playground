/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('idle', function () {
    var IdleProvider;
    var $interval;
    var $rootScope;
    var $log;
    var $document;
    var TokenRefresh;
    var $injector;
    var DEFAULTIDLEDURATION = 300 * 1000;
    var DEFAULTTIMEOUT = 60 * 1000;

    beforeEach(module('dbw-core.idle'));


    beforeEach(function () {
        angular.module('app', ['dbw-core.idle']).config(['IdleProvider',
            function (_IdleProvider_) {
                IdleProvider = _IdleProvider_;
            }
        ]);

        module('app');

        inject(function (_$interval_, _$log_, _$rootScope_, _$document_, _$injector_) {
            $rootScope = _$rootScope_;
            $interval = _$interval_;
            $log = _$log_;
            $document = _$document_;
            $injector = _$injector_;
        });

        TokenRefresh = {
            start: function () {
            },
            stop: function () {
            },
            ping: function () {
            }
        };

        spyOn(TokenRefresh, 'start');
        spyOn(TokenRefresh, 'stop');
        spyOn(TokenRefresh, 'ping');
    });

    var create = function () {
        return $injector.invoke(IdleProvider.$get, null, {
            $interval: $interval,
            $log: $log,
            $rootScope: $rootScope,
            $document: $document,
            TokenRefresh: TokenRefresh
        });
    };

    describe('Idle', function () {
        var Idle;

        beforeEach(function () {
            Idle = create();

        });

        it('watch() should clear timeouts and start running', function () {
            spyOn($interval, 'cancel');

            Idle.watch();

            expect($interval.cancel).toHaveBeenCalled();
            expect(Idle.running()).toBe(true);
            expect(TokenRefresh.start).toHaveBeenCalled();
        });

        it('unwatch() should clear timeouts and stop running', function () {
            Idle.watch();

            spyOn($interval, 'cancel');

            Idle.unwatch();

            expect($interval.cancel).toHaveBeenCalled();
            expect(Idle.running()).toBe(false);
        });

        it('unwatch() should stop TokenRefresh if enabled', function () {
            Idle.watch();

            Idle.unwatch();

            expect(TokenRefresh.stop).toHaveBeenCalled();
        });

        it('should broadcast IdleStart and stop TokenRefresh', function () {
            spyOn($rootScope, '$broadcast').and.callThrough();

            Idle.watch();

            $interval.flush(DEFAULTIDLEDURATION);
            $rootScope.$digest();

            expect($rootScope.$broadcast).toHaveBeenCalledWith('IdleStart');
            expect(TokenRefresh.stop).toHaveBeenCalled();
        });

        it('should broadcast IdleStart then IdleWarn', function () {
            spyOn($rootScope, '$broadcast').and.callThrough();

            Idle.watch();

            $interval.flush(DEFAULTIDLEDURATION);
            $rootScope.$digest();

            expect($rootScope.$broadcast).toHaveBeenCalledWith('IdleStart');
            //expect($rootScope.$broadcast.mostRecentCall.args[0]).toBe('IdleWarn');
        });

        it('should broadcast IdleEnd, start TokenRefresh and ping', function () {
            spyOn($rootScope, '$broadcast').and.callThrough();

            Idle.watch();

            $interval.flush(DEFAULTIDLEDURATION);
            $rootScope.$digest();

            Idle.watch();

            expect($rootScope.$broadcast).toHaveBeenCalledWith('IdleEnd');
        });

        it('should count down warning and then signal timeout', function () {
            spyOn($rootScope, '$broadcast').and.callThrough();

            Idle.watch();

            $interval.flush(DEFAULTIDLEDURATION);
            $interval.flush(DEFAULTTIMEOUT);
            $rootScope.$digest();

            expect($rootScope.$broadcast).toHaveBeenCalledWith('IdleStart');
            expect($rootScope.$broadcast).toHaveBeenCalledWith('IdleWarn', 3);

            $interval.flush(1000);
            $rootScope.$digest();

            expect($rootScope.$broadcast).toHaveBeenCalledWith('IdleWarn', 2);

            $interval.flush(1000);
            $rootScope.$digest();

            expect($rootScope.$broadcast).toHaveBeenCalledWith('IdleWarn', 1);

            $interval.flush(1000);
            $rootScope.$digest();

            expect($rootScope.$broadcast).toHaveBeenCalledWith('IdleTimeout');

            // ensure idle interval doesn't keep executing after IdleStart
            //$rootScope.$broadcast.reset();
            $interval.flush(DEFAULTIDLEDURATION);
            $interval.flush(DEFAULTIDLEDURATION);
            //expect($rootScope.$broadcast).not.toHaveBeenCalledWith('IdleStart');
        });

        it('watch() should interrupt countdown', function () {
            spyOn($rootScope, '$broadcast').and.callThrough();

            Idle.watch();
            $interval.flush(DEFAULTIDLEDURATION);

            $interval.flush(1000);
            $rootScope.$digest();

            expect(Idle.idling()).toBe(true);

            Idle.watch();
            expect(Idle.idling()).toBe(false);
        });

        it('isExpired() should return false if the date/time is less than the idle duration', function () {
            // sets the expiry to now + idle + warning duration
            Idle.watch();

            expect(Idle.isExpired()).toBe(false);
        });

    });

});
