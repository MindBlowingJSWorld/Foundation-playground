'use strict';
/**
 *
 * TODO - renew token
 *
 *
 */
angular.module('dbw-core.token-refresh', [])
    .provider('TokenRefresh', TokenRefreshProvider);

/* @ngInject */
function TokenRefreshProvider() {
    this.$get = KeepaliveGet;
}

/* @ngInject */
function KeepaliveGet($interval, $log) {
    var options = {
        interval: 60
    };

    var state = {
        ping: null
    };

    function ping() {
        $log.debug('ping..token refresh to-do');
    }

    return {
        _options: function () {
            return options;
        },
        start: function (interval) {
            options.interval = interval;
            $interval.cancel(state.ping);
            state.ping = $interval(ping, options.interval * 1000);
            return state.ping;
        },
        stop: function () {
            $interval.cancel(state.ping);
        },
        ping: function () {
            ping();
        }
    };
}
