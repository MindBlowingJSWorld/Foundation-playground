'use strict';

/* @ngInject */
function TestTokenServiceMock(SessionService, AuthorisationService, $log) {

    return {
        login: function (customer) {
            var result = {
                access_token: 'eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJkYmYiLCJhdWQiOlsib3NsIl0sImp0aSI6InRlc3QtMTQ2MDczMDA1MzM4NyIsImNsaWVudF9pZCI6IjE5NDAwODAxMDAxMSIsImNvdW50cnkiOiJTRSIsImFtIjoiQkFOS0lEIiwiYWwiOiJISUdIIiwiaWF0IjoxNDYxOTYxNjYxLCJleHAiOjE0NjE5NjE5NjEsImNoIjoiUkJPIiwiZ3JhbnRzIjp7ImFncmVlbWVudCI6MjE3MjMzMn19.GfJlDGUNI1gMGlg3nJ6sOsx1OTGk_9wCBxUadKSlwDjB43hpFzhhuXhAsI1G1duBLNUQ8j8pW7_pz3DTsfWZjICxtdjsigSpPq0hTZ391i7QwBsFOBCUTlkmTwITpdcoj2GZfvzYQJ0ffYQ6puKibOxjaeGV9O7gdzCdHBbFylMfAJPPcLGWCm26k5BHytj0BiUg3OKJGEiskCatvZJ2wb-T5diRxg5xG9JK2WlvIic_gHLpLHTPU0FJlUvzrTOi1v9vlwcMa6TsmfVMi2bJlHd4v73W14hf0vk7uOmh_yJNRPIuy9K-jgCo-Jkhir8uPvvobZxtJ1_i4NEDPWTJp_3nO-voyD8jpBFKqcUSvog0l-btfe2bfCue_-kBthWF-xSkoCEvzZpM2BR7zr3BQnkcceczowIDzYEyQiGKlZBvCyBH03UcA5hb0oROxpsxCmf1Y6XRNRoru2_CZJ35QoaPKCd3IEiilejWGYyYPlF7wfsWNnMwn2iNRGa6nekKyMT0Sc0wEaH3RLma9vja4vPXmH-y_5DTeb4C9vBxTkj6JoFkVESviE9wUfN5GNGhlt_xRYHCdZYdR0r0bZxBBeFf87x7pbBDTDoN2jJP4jLx55SYZPAHxjMc2X9Ts1AYbM67GJLAiAq2cPHhDPZxJBZyKQZst7DJLJ3_kI6wHb8',
                refresh_token: '4634636346346sdyrsrsg',
                expires_in: 300
            };
            SessionService.login(customer.style, result.access_token, result.refresh_token, result.expires_in);
            try {
                if (customer.start) {
                    AuthorisationService.resume(customer.start);
                } else {
                    AuthorisationService.resume(customer.style);
                }
            } catch (e) {
                $log.error(e);
            }
        }
    };
}

angular.module('dbw-core').service('TestTokenService', TestTokenServiceMock);
