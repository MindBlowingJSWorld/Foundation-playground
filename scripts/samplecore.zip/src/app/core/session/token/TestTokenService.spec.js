/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('TestTokenService', function () {


    var $httpBackend;
    var testTokenService;
    var sessionService;

    beforeEach(module('dbw-core'));

    beforeEach(inject(function (_$httpBackend_, _TestTokenService_) {
        $httpBackend = _$httpBackend_;
        testTokenService = _TestTokenService_;
    }));

    beforeEach(inject(function (_SessionService_) {
        sessionService = _SessionService_;
    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it('should be defined', function () {
        expect(testTokenService).toBeDefined();
        expect(sessionService).toBeDefined();
    });

    describe('login multiple agreements', function () {
        var customer = {
            'style': 'corporate',
            'personId': '194008010011',
            'country': 'SE',
            'agreement': 2,
            'password': 'password'
        };
        var tokenResponse1 = {code: 'code'};
        var tokenResponse2 = {agreements: [{id: 1}, {id: 2}, {id: 3}]};
        var tokenResponse3 = {access_token: 't',refresh_token:'r', expiry_in:100};
        it('two post request and then we are done', function () {
            $httpBackend.expectPOST(/api\/dbf\/ca\/authentication-mock-v1\/security\/oauth\/token*/).respond(401, tokenResponse1);
            $httpBackend.expectPOST(/api\/dbf\/ca\/authentication-mock-v1\/security\/oauth\/token*/).respond(401, tokenResponse2);
            $httpBackend.expectPOST(/api\/dbf\/ca\/authentication-mock-v1\/security\/oauth\/agreement*/).respond(200, tokenResponse3);
            testTokenService.login(customer);

            expect($httpBackend.flush).not.toThrow();
            expect(sessionService.isAuthenticated()).toBeDefined();
        });

    });

    describe('login unique agreement', function () {
        var customer = {
            'style': 'corporate',
            'personId': '194008010011',
            'country': 'SE',
            'agreement': 2,
            'password': 'password'
        };
        var tokenResponse1 = {code: 'code'};
        var tokenResponse3 = {access_token: 't',refresh_token:'r', expiry_in:100};
        it('two post request and then we are done', function () {
            $httpBackend.expectPOST(/api\/dbf\/ca\/authentication-mock-v1\/security\/oauth\/token*/).respond(401, tokenResponse1);
            $httpBackend.expectPOST(/api\/dbf\/ca\/authentication-mock-v1\/security\/oauth\/token*/).respond(200, tokenResponse3);
            testTokenService.login(customer);

            expect($httpBackend.flush).not.toThrow();
            expect(sessionService.isAuthenticated()).toBeDefined();
        });

    });

});
