'use strict';

/**
 * generate jwt tokens until AA works
 */
angular.module('dbw-core.session')
    .factory('TestTokenService', TestTokenService);

/* @ngInject */
function TestTokenService($resource, SessionService, $log, $q, AuthorisationService) {

    function resume(customer) {
        try {
            if (customer.start) {
                AuthorisationService.resume(customer.start);
            } else {
                AuthorisationService.resume(customer.style);
            }
        } catch (a) {
            $log.error(a);
        }
    }


    return {
        login: function (customer) {
            /**
             * This is fake login that will not work in production
             */
            var request = {
                grant_type: 'password', scope: '*:*', auth_method: 'mock', password: 'fx98saSTk02LKncJsmwt'
            };
            request.username = customer.personId;
            request.country = customer.country;
            request.client_id = customer.style === 'household' ? 'NDHW' : 'NDCW';
            SessionService.logout();
            $log.debug('Next 401 (Unauthorized) is Normal!');
            return $resource('/api/dbf/ca/authentication-mock-v1/security/oauth/token', request).save({}).$promise.then(
                angular.noop,
                function (error) {
                    delete request['password'];
                    request.code = error.data.code;
                    $log.debug('Next 401 (Unauthorized) is Normal!');
                    return $resource('/api/dbf/ca/authentication-mock-v1/security/oauth/token', request).save({}).$promise.then(
                        function (result) {
                            SessionService.login(customer.style, result.access_token, result.refresh_token, result.expires_in);
                            resume(customer);
                        },
                        function (mock_resposne_error) {
                            if (!mock_resposne_error.data.agreements) {
                                $log.error(mock_resposne_error.data.error_description);
                                //return $q.reject(mock_resposne_error);
                            }

                            delete request['code'];
                            //Default to first agreement if requested is not matching any
                            request.agreement = mock_resposne_error.data.agreements[0].id;
                            angular.forEach(mock_resposne_error.data.agreements, function (value) {
                                if (value.id === customer.agreement) {
                                    request.agreement = customer.agreement;
                                }
                            });
                            $log.debug('Selecting aggreement ' + request.agreement);
                            var config = {
                                save: {
                                    method: 'POST',
                                    headers: {'Authorization': 'Bearer ' + mock_resposne_error.data.access_token}
                                }
                            };
                            return $resource('/api/dbf/ca/authentication-mock-v1/security/oauth/agreement', request, config).save({}).$promise.then(
                                function (result) {
                                    SessionService.login(customer.style, result.access_token, result.refresh_token, result.expires_in);
                                    resume(customer);
                                },
                                function (agreement_error_response) {
                                    $log.error('Could not select an agreement', agreement_error_response);
                                    SessionService.logout();
                                });
                        }
                    );
                }
            );
        }
    };
}

