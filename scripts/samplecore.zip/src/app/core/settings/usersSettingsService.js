'use strict';

// TODO
// do we need cache duration? currently this will be a service cache as long as there is page reload
angular.module('dbw-core')
    .provider('UsersSettingsService', UsersSettingsService);

/* @ngInject */
function UsersSettingsService() {

    return {

        $get: function ($resource, $cacheFactory) {

            var cache = $cacheFactory('UsersSettingsService');

            var Settings = $resource('users/settings', {}, {
                'get': {method: 'GET', cache: cache},
                'update': {method: 'PUT'}
            });

            return {
                get: get,
                update: update
            };

            function get() {
                return Settings.get().$promise;
            }

            function update(settings) {
                return Settings.update(settings).$promise
                    .then(function (result) {
                        cache.removeAll();
                        return result;
                    });
            }

        }
    };
}


