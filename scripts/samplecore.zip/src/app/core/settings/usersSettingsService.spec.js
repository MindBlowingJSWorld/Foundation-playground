/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('UsersSettingsService', function () {

    beforeEach(module('dbw-core'));

    var $httpBackend;
    var $timeout;
    var usersSettingsService;

    beforeEach(inject(function (_$httpBackend_, _UsersSettingsService_, _$timeout_) {
        $httpBackend = _$httpBackend_;
        $timeout = _$timeout_;
        usersSettingsService = _UsersSettingsService_;
    }));

    afterEach(function () {
        $httpBackend.verifyNoOutstandingExpectation();
        $httpBackend.verifyNoOutstandingRequest();
    });

    it('should be defined', function () {
        expect(usersSettingsService).toBeDefined();
    });

    describe('get()', function () {

        it('should GET settings when called the first time', function () {
            usersSettingsService.get();
            $httpBackend.expect('GET', 'users/settings').respond(200);
            expect($httpBackend.flush).not.toThrow();
        });

        it('should return cached settings when called the second time', function () {
            var settings = {whatever: 'mock data'};
            $httpBackend.expectGET('users/settings').respond(200, settings);

            usersSettingsService.get();
            $httpBackend.flush();
            $httpBackend.resetExpectations();

            var result;
            usersSettingsService.get()
                .then(function (data) {
                    result = data;
                });

            //$httpBackend.flush() will throw 'no pending request' error here since the service will use the cache instead of making another request
            expect($httpBackend.flush).toThrow();
            $timeout.flush(); // run the digest loop

            expect(result).toEqual(jasmine.objectContaining(settings));
        });

    });

    describe('update()', function () {

        it('should PUT settings', function () {
            var settings = {whatever: 'mock data'};
            $httpBackend.expectPUT('users/settings', settings).respond(204);

            var success;
            usersSettingsService.update(settings)
                .then(function () {
                    success = true;
                });
            $httpBackend.flush();

            expect(success).toEqual(true);
        });

        it('should update cache with updated settings when update succeed', function () {
            var updatedSettings = {whatever: 'updated data'};

            usersSettingsService.get();
            usersSettingsService.update(updatedSettings);

            var requestHandler = $httpBackend.whenGET('users/settings').respond(200);
            $httpBackend.expectPUT('users/settings', updatedSettings).respond(204);

            $httpBackend.flush(2);

            var fetchedSettings;
            usersSettingsService.get()
                .then(function (data) {
                    fetchedSettings = data;
                });

            requestHandler.respond(200, updatedSettings);
            $httpBackend.flush();

            expect(fetchedSettings).toEqual(jasmine.objectContaining(updatedSettings));
        });

        it('should NOT update cache when update fail', function () {
            var serverSettings = {whatever: 'server data'};
            var updatedSettings = {whatever: 'updated data'};

            usersSettingsService.get();
            usersSettingsService.update(updatedSettings);

            var requestHandler = $httpBackend.whenGET('users/settings').respond(200, serverSettings);
            $httpBackend.expectPUT('users/settings', updatedSettings).respond(500);

            $httpBackend.flush(2);

            var fetchedSettings;
            usersSettingsService.get()
                .then(function (data) {
                    fetchedSettings = data;
                });

            expect($httpBackend.flush).toThrow(); // expect NO get request has been made
            expect(fetchedSettings).not.toEqual(jasmine.objectContaining(updatedSettings));
            expect(fetchedSettings).toEqual(jasmine.objectContaining(serverSettings));
        });

    });
});
