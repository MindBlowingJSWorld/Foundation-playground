'use strict';
/*global WT */
/**
 * Tracker service to integrate with WebTrends
 *
 */
angular.module('dbw-core')
    .service('TrackerService', TrackerService);

angular.module('dbw-core').run(['TrackerService', function (t) {
    t.startTracking();
}]);

/* @ngInject */
function TrackerService($log, $timeout, $injector, SessionService, $window, $rootScope) {
    //Send the event delayed so the real business get a chance first
    function sendEvent(event) {
        var lang = 'en';
        try {
            lang = $injector.get('localeService').currentLanguage();
        } catch (e) {
            $log.error('Langeuage could not be resolved: ' + e);
        }

        event['lang'] = lang + '_' + $window.COUNTRY;

        var date = new Date();
        event['n_date'] = '' + date.getUTCFullYear() + ('0' + (date.getUTCMonth() + 1)).slice(-2) + ('0' + date.getUTCDate()).slice(-2);
        event['n_time'] = ('0' + date.getUTCHours()).slice(-2) + ('0' + date.getUTCMinutes()).slice(-2) + ('0' + date.getUTCSeconds()).slice(-2);

        event['n_auth'] = SessionService.isAuthenticated() ? 'yes' : 'no';
        if (SessionService.style() === 'household') {
            event['s_seg'] = 'HH';
            event['s_site'] = 'ND HH ' + $window.COUNTRY + ' WEB';
        } else if (SessionService.style() === 'corporate') {
            event['s_seg'] = 'CC';
            event['s_site'] = 'ND CC ' + $window.COUNTRY + ' WEB';
        } else {
            event['s_seg'] = 'ALL';
            event['s_site'] = 'ND ALL ' + $window.COUNTRY + ' WEB';
        }
        event['s_prop'] = 'ND';
        event['s_plat'] = 'Web';
        event['s_cc'] = $window.COUNTRY;
        event['s_state'] = $window.ENV;
        event['s_version'] = $window.APP_VERSION;

        $timeout(function () {
            try {
                // FIXME: WT is undefined here linting-wise
                if (typeof WT !== 'undefined') {
                    WT.click({data: event});
                }
            } catch (a) {
                $log.warn('WT not available ' + a);
            }
        }, 250);
        return event;
    }

    function state2url(s) {
        if (s && s.name) {
            return '/' + s.name.replace(/\./g, '/');
        } else {
            return '/';
        }
    }

    function navigateFromTo(fromState, toState) {
        var newUrl = state2url(toState);
        var previousUrl = '';
        if (fromState) {
            previousUrl = state2url(fromState);
        }
        var title = newUrl.substring(newUrl.lastIndexOf('/') + 1, newUrl.length);
        var event = {
            'dcsuri': newUrl,
            'c_uri': newUrl,
            'WT.es': location.hostname + newUrl,
            'dcsref': location.protocol + '//' + location.hostname + previousUrl,
            'c_uriref': previousUrl,
            'WT.ti': title,
            'WT.dl': '0'
        };
        var cg = toState.name.split('.');
        event['WT.cg_n'] = cg[0];
        if (cg[1]) {
            event['WT.cg_s'] = cg[1];
        }
        if (cg[2]) {
            event['cg_s3'] = cg[2];
        }
        if (cg[3]) {
            event['cg_s4'] = cg[3];
        }
        if (cg[4]) {
            event['cg_s5'] = cg[4];
        }
        return sendEvent(event);
    }

    function starttracking() {
        $rootScope.$on('$stateChangeSuccess',
            function (event, toState, toParams, fromState /* , fromParams*/) {
                navigateFromTo(fromState, toState);
            });
    }

    return {
        navigateFromTo: navigateFromTo,
        touchpointEvent: function (sku, tp_att) {
            var event = {};
            var date = new Date();
            event['WT.pn_sku'] = sku;
            event['WT.tx_i'] = date.getTime() + '_' + sku;
            event['WT.tx_u'] = 1;
            event['WT.tx_s'] = 0;
            event['WT.tx_e'] = 'p';
            if (tp_att) {
                event['tp_att'] = tp_att;
            }

            //tx_id critical format mm/dd/yyyy
            event['WT.tx_id'] = ('0' + (date.getUTCMonth() + 1)).slice(-2) + '/' + ('0' + date.getUTCDate()).slice(-2) + '/' + date.getUTCFullYear();
            event['WT.tx_it'] = ('0' + date.getUTCHours()).slice(-2) + ':' + ('0' + date.getUTCMinutes()).slice(-2) + ':' + ('0' + date.getUTCSeconds()).slice(-2);
            return sendEvent(event);
        },
        searchEvent: function (query, select, cat, selectno, resultno) {
            var event = {};
            event['oss_input'] = query;
            event['oss_select'] = select;
            event['oss_selectcat'] = cat;
            event['oss_selectno'] = selectno;
            event['oss_resultno'] = resultno;
            return sendEvent(event);
        },
        startTracking: starttracking
    };
}

