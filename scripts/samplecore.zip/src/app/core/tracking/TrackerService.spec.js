/*eslint-env jasmine */
/*global module:false, inject:false */
'use strict';

describe('TrackerService', function () {

    beforeEach(module('dbw-core'));

    var trackerService;
    var state1 = {name:'from-state',url:'from-url'};
    var state2 = {name:'to-state',url:'to-url'};

    beforeEach(inject(function (_TrackerService_) {
        trackerService = _TrackerService_;
    }));

    it('should be defined', function () {
        expect(trackerService).toBeDefined();
    });

    describe('navigateFromTo()', function () {
        it('should not make any noise', function () {
            var event = trackerService.navigateFromTo(state1, state2);
            expect(event.lang).toBeDefined();
            //can this be tested
        });
    });
    describe('touchpointEvent()', function () {
        it('should not make any noise', function () {
            var event = trackerService.touchpointEvent('sku', 'id');
            expect(event.lang).toBeDefined();
            //can this be tested
        });
    });
    describe('searchEvent()', function () {
        it('should not make any noise', function () {
            var event = trackerService.searchEvent('query', 'select', 'cat', 1, 10);
            expect(event.lang).toBeDefined();
            //can this be tested
        });
    });
});
