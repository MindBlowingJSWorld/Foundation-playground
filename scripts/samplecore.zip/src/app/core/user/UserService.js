'use strict';

/**
 * Get information about the logged in user
 */
angular.module('dbw-core')
    .service('UserService', UserService);

/* @ngInject */
function UserService() {
    function getUser() {
        return {
            fullname: 'Test User',
            avatar: {
                initials: 'AB',
                imageId: '04272107-37c3-4509-8c3a-b4ba7fb026e6'
            }
        };
    }

    function getFullName() {
        return getUser().fullname;
    }

    function getInitials() {
        return getUser().avatar.initials;
    }

    return {
        getUser: getUser,
        getFullName: getFullName,
        getInitials: getInitials
    };
}
